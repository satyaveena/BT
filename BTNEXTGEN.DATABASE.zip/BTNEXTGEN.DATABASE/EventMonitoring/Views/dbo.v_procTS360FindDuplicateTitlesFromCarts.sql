SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE VIEW [dbo].[v_procTS360FindDuplicateTitlesFromCarts]
AS
SELECT	ID,
		StartDateTime,
		Point1Duration,
		Point2Duration,
		Point3Duration,
		Point4Duration,
		TotalDuration
FROM	EventMonitoring.dbo.PE_StoredProcedureDurations
WHERE	StoredProcedure = 'procTS360FindDuplicateTitlesFromCarts'

--SELECT	* FROM v_procTS360FindDuplicateTitlesFromCarts
GO
