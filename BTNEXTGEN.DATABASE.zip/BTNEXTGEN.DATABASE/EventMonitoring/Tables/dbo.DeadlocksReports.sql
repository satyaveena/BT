CREATE TABLE [dbo].[DeadlocksReports]
(
[deadlock_id] [int] NOT NULL IDENTITY(1, 1),
[deadlock_graph] [xml] NULL,
[create_date] [datetime] NULL CONSTRAINT [DF_MonitorDeadlocksReports_CreateDate] DEFAULT (getdate())
) ON [PRIMARY]
GO
