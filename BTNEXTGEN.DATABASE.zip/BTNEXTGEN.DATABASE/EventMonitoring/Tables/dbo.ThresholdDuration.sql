CREATE TABLE [dbo].[ThresholdDuration]
(
[JobID] [uniqueidentifier] NOT NULL,
[JobName] [sys].[sysname] NOT NULL,
[ThresholdDuration] [int] NULL CONSTRAINT [DF__Threshold__Thres__03317E3D] DEFAULT ((0)),
[ResponsiblePartyName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ResponsiblePartyPhone] [nvarchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ResponsiblePartyEMail] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[ThresholdDuration].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ThresholdDuration].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[ThresholdDuration].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ThresholdDuration].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[ThresholdDuration].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ThresholdDuration].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[ThresholdDuration].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ThresholdDuration].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[ThresholdDuration].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ThresholdDuration].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[ThresholdDuration].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ThresholdDuration].[UpdatedDateTime]'
GO
