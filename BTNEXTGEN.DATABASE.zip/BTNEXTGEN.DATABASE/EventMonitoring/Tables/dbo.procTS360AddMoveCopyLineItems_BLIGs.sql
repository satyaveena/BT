CREATE TABLE [dbo].[procTS360AddMoveCopyLineItems_BLIGs]
(
[ID] [bigint] NULL,
[AgencyCodeID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemTypeID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CollectionID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode1ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode2ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode3ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode4ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode5ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode6ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CallNumberText] [varchar] (26) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Quantity] [int] NULL,
[Sequence] [int] NOT NULL,
[BTkey] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
