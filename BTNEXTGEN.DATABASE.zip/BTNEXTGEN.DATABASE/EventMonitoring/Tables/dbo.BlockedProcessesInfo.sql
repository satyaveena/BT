CREATE TABLE [dbo].[BlockedProcessesInfo]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[EventDate] [datetime] NOT NULL,
[DatabaseID] [smallint] NOT NULL,
[Resource] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[WaitTime] [int] NOT NULL,
[BlockedProcessReport] [xml] NOT NULL,
[BlockedSPID] [smallint] NOT NULL,
[BlockedXactId] [bigint] NULL,
[BlockedLockMode] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockedIsolationLevel] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockedSQLHandle] [varbinary] (64) NULL,
[BlockedStmtStart] [int] NULL,
[BlockedStmtEnd] [int] NULL,
[BlockedSql] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockedInputBuf] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockedQueryPlan] [xml] NULL,
[BlockingSPID] [smallint] NULL,
[BlockingStatus] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockingTranCount] [int] NOT NULL,
[BlockingInputBuf] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockingSql] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BlockingQueryPlan] [xml] NULL
) ON [PRIMARY]
GO
