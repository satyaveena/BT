CREATE TABLE [dbo].[procTS360FindDuplicateTitlesFromOrders_DupCheckOCSOrderList]
(
[ID] [bigint] NULL,
[TransmissionNumber] [int] NOT NULL,
[OrderNumber] [nvarchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
