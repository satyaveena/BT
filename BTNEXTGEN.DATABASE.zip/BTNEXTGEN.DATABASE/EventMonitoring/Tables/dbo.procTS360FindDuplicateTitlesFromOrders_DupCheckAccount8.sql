CREATE TABLE [dbo].[procTS360FindDuplicateTitlesFromOrders_DupCheckAccount8]
(
[ID] [bigint] NULL,
[Account8ID] [nchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CompanyCode] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
