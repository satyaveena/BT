CREATE TABLE [dbo].[procTS360FindDuplicateTitlesFromOrders_OCSProductIDList]
(
[ID] [bigint] NULL,
[RowNumber] [int] NULL,
[BTKey] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OCSProductID] [char] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
