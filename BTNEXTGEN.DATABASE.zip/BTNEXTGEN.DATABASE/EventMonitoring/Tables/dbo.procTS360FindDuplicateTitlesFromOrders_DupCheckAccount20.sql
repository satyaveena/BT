CREATE TABLE [dbo].[procTS360FindDuplicateTitlesFromOrders_DupCheckAccount20]
(
[ID] [bigint] NULL,
[ERPAccountID] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
