CREATE TABLE [dbo].[procTS360AddMoveCopyLineItems_BLIs]
(
[ID] [bigint] NULL,
[BasketLineItemID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BTKey] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[quantity] [int] NULL,
[POLineItemNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BibNumber] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PrimaryResponsiblePartyRedundant] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShortTitleRedundant] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
