SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-01-31
Description:	Purges the whoisactive table
=============================================
*/
CREATE PROCEDURE [dbo].[procWhoIsActivePurge]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CheckDate DATETIME2 = DATEADD(MONTH, -1, GETDATE())

	DELETE FROM [EventMonitoring].[dbo].[WhoIsActive]
	WHERE collection_time < @CheckDate

END
GO
