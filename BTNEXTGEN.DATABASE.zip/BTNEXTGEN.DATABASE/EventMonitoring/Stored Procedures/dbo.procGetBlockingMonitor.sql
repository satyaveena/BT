SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
=============================================
Author:			David Browne
Create date:	2018-04-13
Description:	Reads BlockingMonitor Extended Event
DECLARE	@Count int
EXEC	[dbo].[procGetBlockingMonitor]
		@StartDate = NULL,
		@EndDate = NULL,
		@count = @Count OUTPUT

		SELECT @Count 
=============================================
*/
CREATE PROCEDURE [dbo].[procGetBlockingMonitor]
	@StartDate DATETIME = NULL,
	@EndDate DATETIME = NULL,
	@Count	integer OUTPUT

AS

BEGIN
	SET NOCOUNT ON;

	IF @StartDate IS NULL
		SET @StartDate = CAST(GETDATE() as date)
	IF	@EndDate IS NULL
		SET	@EndDate = GETDATE()


	CREATE TABLE #Event(
		EventTime			DateTime,
		[Blocked Query]		varchar(500),
		[Blocking Query]	varchar(500),
		[BlockedLogin]		varchar(100),
		[BlockingLogin]		varchar(100),
		[waitresourceID]	varchar(100), 
		[Database Name]		varchar(50),
		[Duration (ms)]		bigint,
		EventXML			xml)

INSERT	#Event
SELECT	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), EventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) as [EventTime],
		--EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocked-process/process/@lasttranstarted)[1]','SYSNAME') AS [EventTime], 
		EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocked-process/process/inputbuf)[1]','SYSNAME') AS [Blocked Query],
		EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocking-process/process/inputbuf)[1]','SYSNAME') AS [Blocking Query],
		EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocked-process/process/@loginname)[1]','SYSNAME') AS [BlockedLogin], 
		EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocking-process/process/@loginname)[1]','SYSNAME') AS [BlockingLogin], 
		EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocked-process/process/@waitresource)[1]','SYSNAME') AS [waitresourceID], 		
		EventXML.Data.value('(/event/data[@name=''database_name'']/value)[1]','SYSNAME') AS [Database Name],
		EventXML.Data.value('(/event/data[@name=''duration'']/value)[1]','BIGINT')/1000 AS [Duration (ms)]
		,EventXML.Data
	FROM	(
			SELECT  CONVERT(XML, event_data) Data
			FROM	sys.fn_xe_file_target_read_file(N'BlockingMonitor*.xel', NULL, NULL, NULL) 
			WHERE   OBJECT_NAME = 'blocked_process_report') EventXML
	WHERE	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), EventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) >= @StartDate
	AND		DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), EventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) < @EndDate

--ROLLUP NUMBERS AND ISOLATE WAIT RESOURCE
CREATE TABLE	#BlockingSummary (
		EventTime			DateTime,
		[Blocked Query]		varchar(500),
		[BlockedObjectID]	varchar(500),
		[Blocking Query]	varchar(500),
		[BlockingObjectID]	varchar(500),
		[BlockedLogin]		varchar(100),
		[BlockingLogin]		varchar(100),
		[waitresourceID]	varchar(100), 
		[waitresourceDBID]	varchar(100), 
		[waitresource]		varchar(100), 
		[Database Name]		varchar(50),
		[Duration (ms)]		bigint)


INSERT		#BlockingSummary
SELECT		EventTime				as EventTime,
			COALESCE([Blocked Query], '')			as [Blocked Query],
			NULL					as [BlockedObjectID]		,
			[Blocking Query]		as [Blocking Query],
			NULL					as [BlockingObjectID]		,
			MAX([BlockedLogin])		as BlockedLogin,
			MAX([BlockingLogin])	as BlockingLogin,
			MAX(waitresourceID)		as waitresourceID,
			NULL					as [waitresourceDBID],
			NULL					as [waitresource],
			MAX([Database Name])	as [Database Name],
			MAX([Duration (ms)])	as [Duration (ms)]
FROM		#Event
GROUP BY	EventTime,
			COALESCE([Blocked Query], ''),
			[Blocking Query]

--SET OUTPUT VARIABLE
SELECT		@Count = COUNT(1) 
FROM		#BlockingSummary

UPDATE		#BlockingSummary 
SET			waitresource = SUBSTRING(WaitResourceID, 9, 999)
WHERE		WaitResourceID LIKE 'OBJECT%'

--REMOVE DB ENTRY
UPDATE		#BlockingSummary 
SET			waitresourceDBID = SUBSTRING(WaitResource, 0, charIndex(':', WaitResource))
WHERE		WaitResourceID LIKE 'OBJECT%'

UPDATE		#BlockingSummary 
SET			waitresource = SUBSTRING(WaitResource, charIndex(':', WaitResource) + 1, 999)
WHERE		WaitResourceID LIKE 'OBJECT%'

--REMOVE TRAILING ENTRY
UPDATE		#BlockingSummary 
SET			waitresource = SUBSTRING(WaitResource, 0, charIndex(':', WaitResource))
WHERE		WaitResourceID LIKE 'OBJECT%'


UPDATE		#BlockingSummary 
SET			waitresource = WaitResourceID
WHERE		WaitResourceID LIKE 'PAGE%'

--BlockedObjectID
UPDATE	#BlockingSummary
SET		[BlockedObjectID] = SUBSTRING([Blocked Query], charIndex('Object Id = ',[Blocked Query]) + 12, 99)
WHERE	charIndex('proc', [Blocked Query]) > 0

UPDATE	#BlockingSummary
SET		[BlockedObjectID] = SUBSTRING([BlockedObjectID], 0, charIndex(']', [BlockedObjectID]))
WHERE	charIndex('proc', [Blocked Query]) > 0

UPDATE	#BlockingSummary
SET		[BlockedObjectID] =NULL
WHERE	IsNumeric([BlockedObjectID]) = 0


UPDATE		#BlockingSummary
SET			[Blocked Query] = o.name
FROM		#BlockingSummary b
JOIN		ProductCatalog.sys.objects o ON b.BlockedObjectID = o.object_id
WHERE		[Database Name] = 'ProductCatalog'

UPDATE		#BlockingSummary
SET			[Blocked Query] = o.name
FROM		#BlockingSummary b
JOIN		Orders.sys.objects o ON b.BlockedObjectID = o.object_id
WHERE		[Database Name] = 'Orders'

UPDATE		#BlockingSummary
SET			[Blocked Query] = o.name
FROM		#BlockingSummary b
JOIN		BTAdmin.sys.objects o ON b.BlockedObjectID = o.object_id
WHERE		[Database Name] = 'BTAdmin'


--BlockingObjectID
UPDATE	#BlockingSummary
SET		[BlockingObjectID] = SUBSTRING([Blocking Query], charIndex('Object Id = ',[Blocking Query]) + 12, 99)
WHERE	charIndex('proc', [Blocking Query]) > 0

UPDATE	#BlockingSummary
SET		[BlockingObjectID] = SUBSTRING([BlockingObjectID], 0, charIndex(']', [BlockingObjectID]))
WHERE	charIndex('proc', [Blocking Query]) > 0

UPDATE		#BlockingSummary
SET			[Blocking Query] = o.name
FROM		#BlockingSummary b
JOIN		ProductCatalog.sys.objects o ON b.BlockingObjectID = o.object_id
WHERE		[Database Name] = 'ProductCatalog'
AND			isnumeric(b.BlockingObjectID) = 1

UPDATE		#BlockingSummary
SET			[Blocking Query] = o.name
FROM		#BlockingSummary b
JOIN		Orders.sys.objects o ON b.BlockingObjectID = o.object_id
WHERE		[Database Name] = 'Orders'
AND			isnumeric(b.BlockingObjectID) = 1

UPDATE		#BlockingSummary
SET			[Blocking Query] = o.name
FROM		#BlockingSummary b
JOIN		BTAdmin.sys.objects o ON b.BlockingObjectID = o.object_id
WHERE		[Database Name] = 'BTAdmin'
AND			isnumeric(b.BlockingObjectID) = 1

--REMOVE DB ENTRY
--UPDATE		@BlockingSummary 
--SET			waitresource = SUBSTRING(WaitResource, charIndex(':', WaitResource) + 1, 999)
--WHERE		WaitResourceID LIKE 'PAGE%'

--UPDATE		@BlockingSummary 
--SET			waitresource = SUBSTRING(WaitResource, charIndex(':', WaitResource) + 1, 999)
--WHERE		WaitResourceID LIKE 'PAGE%'

--WAIT RESOURCE
UPDATE		#BlockingSummary
SET			waitresource = o.name
FROM		#BlockingSummary b
JOIN		BTAdmin.sys.objects o ON b.waitresource = o.object_id
WHERE		waitresourceDBID = 9

UPDATE		#BlockingSummary
SET			waitresource = o.name
FROM		#BlockingSummary b
JOIN		ProductCatalog.sys.objects o ON b.waitresource = o.object_id
WHERE		waitresourceDBID = 7


UPDATE		#BlockingSummary
SET			waitresource = o.name
FROM		#BlockingSummary b
JOIN		orders.sys.objects o ON b.waitresource = o.object_id
WHERE		waitresourceDBID = 6

--SELECT	DB_name(7)

--SUMMARY RESULT SET
SELECT		EventTime,
			[Blocked Query],
			[Blocking Query],
			BlockedLogin,
			BlockingLogin,
			--[waitresourceID],
			[waitresource],
			[Database Name],
			[Duration (ms)]
FROM	#BlockingSummary
WHERE	EventTime >= @StartDate
AND		EventTime < @EndDate

----DETAILED RESULT SET
--SELECT	e.EventTime, e.eventxml 
--FROM	#Event e
--JOIN	#BlockingSummary bs ON e.EventTime = bs.eventTime


DROP TABLE #BlockingSummary
DROP TABLE #Event

END
GO
