SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-05-04	
Description:	Pulls data from other server for log reports for IO errors
=============================================
*/
CREATE PROCEDURE [dbo].[procReportIOErrors]
	@EmailResults BIT = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CheckDate DATETIME
			, @NewIORecords BIT = 0

	--Biztalk
	SELECT	@CheckDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'BizTalk'

	IF @CheckDate IS NULL
		SET @CheckDate = '4/11/2017'
		
	INSERT INTO  dbo.LogData (Server, LogDate, LogText)
	EXEC [10.100.100.19\BIZTALK].master.dbo.usp_readerrorlog @CheckDate

	IF @@ROWCOUNT > 0
		SET @NewIORecords = 1

	SET @CheckDate = NULL

	--Sharepoint
	SELECT	@CheckDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'Sharepoint'

	IF @CheckDate IS NULL
		SET @CheckDate = '4/11/2017'

	INSERT INTO dbo.LogData (Server, LogDate, LogText)
	EXEC [10.100.100.20\SPNextGen].master.dbo.usp_readerrorlog @CheckDate

	IF @@ROWCOUNT > 0
		SET @NewIORecords = 1

	SET @CheckDate = NULL

	--Axis360
	SELECT	@CheckDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'Axis360'

	IF @CheckDate IS NULL
		SET @CheckDate = '4/11/2017'

	INSERT INTO dbo.LogData (Server, LogDate, LogText)
	EXEC [10.100.100.21\SPBTDML].master.dbo.usp_readerrorlog @CheckDate

	IF @@ROWCOUNT > 0
		SET @NewIORecords = 1

	SET @CheckDate = NULL

	--TS360Repository
	SELECT	@CheckDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'TS360Repository'

	IF @CheckDate IS NULL
		SET @CheckDate = '4/11/2017'

	DECLARE @LogID      INT,
			@searchStr   VARCHAR(256),
			@startDate   DATETIME;

	DECLARE @errorLogs   TABLE (
		LogID    INT,
		LogDate  DATETIME,
		LogSize  BIGINT   );

	DECLARE @logData      TABLE (
		LogDate     DATETIME,
		ProcInfo    VARCHAR(64),
		LogText     VARCHAR(MAX)   );

	SELECT  @searchStr = 'I/O'

	INSERT INTO @errorLogs
	EXEC sys.sp_enumerrorlogs;

	SELECT TOP 1 @LogID = LogID
	FROM @errorLogs
	ORDER BY [LogDate];

	WHILE @LogID >= 0
	BEGIN
		INSERT INTO @logData
		EXEC sys.sp_readerrorlog @LogID, 1, @searchStr;
		
		IF @LogID = 0
			BREAK;

		SELECT TOP 1 @LogID = LogID
		FROM	@errorLogs
		WHERE	LogID < @LogID
		ORDER BY [LogDate];
	END

	INSERT INTO dbo.LogData (Server, LogDate, LogText)
	SELECT	'TS360Repository' as Server, [LogDate], [LogText]
	FROM	@logData
	WHERE	LogDate > @CheckDate;

	IF @@ROWCOUNT > 0
		SET @NewIORecords = 1

	--Generate email 
	DECLARE @ReportingDate DATETIME = 
		CAST(CAST(CAST(DATEADD(DAY, -1, GETDATE()) as DATE) AS VARCHAR(10)) + SPACE(1) + CAST(DATEPART(HOUR, DATEADD(HOUR,-24, GETDATE())) AS VARCHAR(2)) + ':00' as DATETIME)

	DECLARE @Axis360 TABLE
	(
		EventDate	VARCHAR(20)
		, IOEvents	INT
	)

	DECLARE @TS360 TABLE
	(
		EventDate	VARCHAR(20)
		, IOEvents	INT
	)

	DECLARE @Biztalk TABLE
	(
		EventDate	VARCHAR(20)
		, IOEvents	INT
	)

	DECLARE @Sharepoint TABLE
	(
		EventDate	VARCHAR(20)
		, IOEvents	INT
	)

	DECLARE @LastIOEvent TABLE
	(
		Server	VARCHAR(25)
		, LastIOEvent DATETIME
	)

	INSERT INTO @Axis360
	SELECT	CONVERT(VARCHAR(10), CAST(LogDate as DATE), 120) + SPACE(1) + RIGHT('0' + CAST(DATEPART(Hour, LogDate) as VARCHAR(2)), 2) + ':00' as EventDate, COUNT(*) as CountOfEvents
	FROM	dbo.LogData
	WHERE	LogDate >= @ReportingDate
	AND		Server = 'Axis360'
	GROUP BY CAST(LogDate as DATE), DATEPART(Hour, LogDate)
	ORDER BY EventDate DESC

	INSERT INTO @TS360
	SELECT	CONVERT(VARCHAR(10), CAST(LogDate as DATE), 120) + SPACE(1) + RIGHT('0' + CAST(DATEPART(Hour, LogDate) as VARCHAR(2)), 2) + ':00' as EventDate, COUNT(*) as CountOfEvents
	FROM	dbo.LogData
	WHERE	LogDate >= @ReportingDate
	AND		Server = 'TS360Repository'
	GROUP BY CAST(LogDate as DATE), DATEPART(Hour, LogDate)
	ORDER BY EventDate DESC

	INSERT INTO @BizTalk
	SELECT	CONVERT(VARCHAR(10), CAST(LogDate as DATE), 120) + SPACE(1) + RIGHT('0' + CAST(DATEPART(Hour, LogDate) as VARCHAR(2)), 2) + ':00' as EventDate, COUNT(*) as CountOfEvents
	FROM	dbo.LogData
	WHERE	LogDate >= @ReportingDate
	AND		Server = 'BizTalk'
	GROUP BY CAST(LogDate as DATE), DATEPART(Hour, LogDate)
	ORDER BY EventDate DESC

	INSERT INTO @Sharepoint
	SELECT	CONVERT(VARCHAR(10), CAST(LogDate as DATE), 120) + SPACE(1) + RIGHT('0' + CAST(DATEPART(Hour, LogDate) as VARCHAR(2)), 2) + ':00' as EventDate, COUNT(*) as CountOfEvents
	FROM	dbo.LogData
	WHERE	LogDate >= @ReportingDate
	AND		Server = 'Sharepoint'
	GROUP BY CAST(LogDate as DATE), DATEPART(Hour, LogDate)
	ORDER BY EventDate DESC

	INSERT INTO @LastIOEvent
	SELECT	Server, MAX(LogDate) as LastIOEvent
	FROM	dbo.LogData
	GROUP BY Server
	ORDER BY LastIOEvent DESC

	IF @EmailResults = 0 --assumed we're running it from SSMS
	BEGIN
		SELECT * FROM	@LastIOEvent
		SELECT 'Axis360' as Server, * FROM @Axis360
		SELECT 'TS360' as Server, * FROM @TS360
		SELECT 'Biztalk' as Server, * FROM @Biztalk
		SELECT 'Sharepoint' as Server, * FROM @Sharepoint
	END
	ELSE
	BEGIN
		DECLARE @Axis360HTML		VARCHAR(MAX)
				, @TS360HTML		VARCHAR(MAX)
				, @SharepointHTML	VARCHAR(MAX)
				, @BiztalkHTML		VARCHAR(MAX)
				, @LastEventHTML	VARCHAR(MAX)
				, @BodyHTML			VARCHAR(MAX)
				, @Importance		VARCHAR(10)
				, @Subject			VARCHAR(50)

		SELECT @Axis360HTML = 
			N'<H2>Axis360</H2>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Event Date</th>' +
			N'<th>IOEvents</th>' +
			N'</tr>' +
		CAST(
		(SELECT		td = EventDate
					, SPACE(0)
					, td = IOEvents
		FROM		@Axis360
		ORDER BY	EventDate DESC
		FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
		+ N'</table>' 

		SELECT @TS360HTML = 
			N'<H2>TS360 Repository</H2>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Event Date</th>' +
			N'<th>IOEvents</th>' +
			N'</tr>' +
		CAST(
		(SELECT		td = EventDate
					, SPACE(0)
					, td = IOEvents
		FROM		@TS360
		ORDER BY	EventDate DESC
		FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
		+ N'</table>' 

		SELECT @BiztalkHTML = 
			N'<H2>BizTalk</H2>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Event Date</th>' +
			N'<th>IOEvents</th>' +
			N'</tr>' +
		CAST(
		(SELECT		td = EventDate
					, SPACE(0)
					, td = IOEvents
		FROM		@Biztalk
		ORDER BY	EventDate DESC
		FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
		+ N'</table>' 

		SELECT @SharepointHTML = 
			N'<H2>Sharepoint</H2>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Event Date</th>' +
			N'<th>IOEvents</th>' +
			N'</tr>' +
		CAST(
		(SELECT		td = EventDate
					, SPACE(0)
					, td = IOEvents
		FROM		@Sharepoint
		ORDER BY	EventDate DESC
		FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
		+ N'</table>' 

		SELECT @LastEventHTML = 
			N'<H2>Last IO Event</H2>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Server</th>' +
			N'<th>LastIOEvent</th>' +
			N'</tr>' +
		CAST(
		(SELECT		td = Server
					, SPACE(0)
					, td = LastIOEvent
		FROM		@LastIOEvent
		ORDER BY	LastIOEvent DESC
		FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
		+ N'</table>' 

		SELECT @BodyHTML = '<p>' + ISNULL(@LastEventHTML, '') + 
			'</p><p>' + ISNULL(@TS360HTML, '') + 
			'</p><p>' + ISNULL(@Axis360HTML, '') + 
			'</p><p>' + ISNULL(@BiztalkHTML, '') + 
			'</p><p>' + ISNULL(@SharepointHTML, '') + '</p>'

		IF @NewIORecords = 1
		BEGIN
			SET @Subject = 'Sev 1: IO Error Counts'
			SET @Importance = 'High'
		END
		ELSE
		BEGIN
			SET @Subject = 'IO ErrorCounts'
			SET @Importance = 'Normal'
		END

		EXEC msdb.dbo.sp_send_dbmail
				@recipients = 'kelly.gulutz@baker-taylor.com;Dan.Johnson@baker-taylor.com;cerisa.meunier@baker-taylor.com;btsupport@intsof.com;Ivor.Addo@baker-taylor.com;DL-360Tier2Support@baker-taylor.com'
			, @reply_to = 'ProductionNoReply@baker-taylor.com'
			, @subject = @Subject
			, @body = @BodyHTML 
			, @importance = @Importance
			, @body_format = 'HTML'
	END
END
GO
