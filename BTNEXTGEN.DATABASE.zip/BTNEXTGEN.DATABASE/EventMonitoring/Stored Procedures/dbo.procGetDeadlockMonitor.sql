SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
=============================================
Author:			David Browne
Create date:	2018-04-13
Description:	Reads DeadlockMonitor Extended Event

DECLARE	@Count int
EXEC	[dbo].[procGetDeadlockMonitor] 
		@StartDate = NULL,
		@EndDate = NULL,
		@count = @Count OUTPUT

		SELECT @Count 
=============================================
*/
CREATE PROCEDURE [dbo].[procGetDeadlockMonitor]
	@StartDate DATETIME = NULL,
	@EndDate DATETIME = NULL,
	@Count	integer OUTPUT
AS

BEGIN
	SET NOCOUNT ON;

	IF @StartDate IS NULL
		SET @StartDate = CAST(GETDATE() as date)
	IF	@EndDate IS NULL
		SET	@EndDate = GETDATE()

	SELECT	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) AS [EventTime],
			DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/executionStack/frame/@procname)[1]', 'nvarchar(max)') AS KilledSP,
			DeadlockEventXML.Data.value('(//process[2]/executionStack/frame/@procname)[1]', 'nvarchar(max)') AS KillingSP,
			DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/@hostname)[1]', 'nvarchar(max)') AS KilledServer,
			DeadlockEventXML.Data.value('(//process[2]/@hostname)[1]', 'nvarchar(max)') AS KillingServer,
			DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/@hostname)[1]', 'nvarchar(max)') AS HostName,
			DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/@clientapp)[1]', 'nvarchar(max)') AS ClientApp,
			DB_NAME(DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/@currentdb)[1]', 'nvarchar(max)')) AS [DatabaseName],
			DeadlockEventXML.Data.query('(event/data[@name="xml_report"]/value/deadlock)[1]') AS DeadLockGraph
	FROM	(
			SELECT  CONVERT(XML, event_data) Data
			FROM	sys.fn_xe_file_target_read_file(N'DeadlockMonitor*.xel', NULL, NULL, NULL) 
			WHERE   OBJECT_NAME = 'xml_deadlock_report') DeadlockEventXML
	WHERE	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) >= @StartDate
	AND		DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) < @EndDate
	ORDER BY 1 DESC

	SELECT	@Count = @@ROWCOUNT 
END
GO
