SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[procMonitorOCSLoads]
AS
--**************************************************************
--CREATED BY:	David Browne (Baker & Taylor)
--CREATE DATE:	2015-07

--exec procMonitorOCSLoads
--**************************************************************
BEGIN

	SET NOCOUNT ON;
	DECLARE	@recipients		varchar(500), 
			@reply_to		varchar(500),
			@Subject		varchar(500),
			@MailBody		nvarchar(4000), 
			@OCSHTML		nVARCHAR(max),
			@importance		varchar(6) = 'High'

	DECLARE	@OCSOrdersLastRunDate	datetime,
			@OCSInvoicesLastRunDate	datetime

	SELECT	TOP (1) @OCSOrdersLastRunDate = [OCSTimestamp]
	FROM	orders.dbo.OCSExtract
	WHERE	[OCSStoredProcedure] = 'NXT.NGEXOS'

	SELECT	TOP (1) @OCSInvoicesLastRunDate = [OCSTimestamp]
	FROM	orders.dbo.OCSExtract
	WHERE	[OCSStoredProcedure] = 'NXT.NGEXVS'

	IF	DATEDIFF(hh, @OCSOrdersLastRunDate, GETDATE()) > 12
	OR	DATEDIFF(hh, @OCSInvoicesLastRunDate, GETDATE()) > 12
	BEGIN

		IF	@@SERVERNAME LIKE 'DC1XBNTAXPC%'
		BEGIN
			SET	@reply_to = 'ProductionNoReply@baker-taylor.com'
			SET @recipients = 'cerisa.meunier@baker-taylor.com;Kelly.Gulutz@baker-taylor.com;bt_app_support_group@csc.com'
			SET	@Subject = 'TS360 Production:  OCS Loads are not running.'
		END
		ELSE IF	@@ServerName LIKE 'VMROBNTTSQC%'
		BEGIN
			SET	@reply_to = 'QANoReply@baker-taylor.com'
			SET @recipients = 'cerisa.meunier@baker-taylor.com;Kelly.Gulutz@baker-taylor.com;ivor.addo@baker-taylor.com;cynthia.groh@baker-taylor.com'
			SET	@Subject = 'TS360 QA:  OCS Loads are not running.'
		END

		SELECT	@recipients
		--eMAIL  *************************************************************************************************************
		SET @OCSHTML = 	N'<p>The OCS Loads are behind schedule.  Please ensure that the scheduler has been turned on.</p>' +
			N'<table border="1">' +
				N'<tr>' + 
					N'<th>Load</th>' +
					N'<th>Last Run</th>' +
			N'</tr>' +
			N'<tr>' + 
					N'<th>Orders Load</th>' +
					N'<th>' + CAST(@OCSOrdersLastRunDate as nvarchar(50)) + '</th>' +
			N'</tr>' +
			N'<tr>' + 
					N'<th>Invoice Load</th>' +
					N'<th>' + CAST(@OCSInvoicesLastRunDate as nvarchar(50)) + '</th>' +
			N'</tr>' +
			N'</table>' ;
 

		DECLARE	@BodyHTML nvarchar(max)
		SELECT 	@BodyHTML = @OCSHTML
	
		EXEC msdb.dbo.sp_send_dbmail
			 @recipients	= @recipients
			, @reply_to		= @reply_to
			, @subject		= @Subject
			, @body			= @BodyHTML
			, @body_format	= 'HTML'

	END
END
GO
