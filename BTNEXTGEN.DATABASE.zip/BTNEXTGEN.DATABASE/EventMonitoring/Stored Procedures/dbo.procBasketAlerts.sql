SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2019-02-07
Description:	TFS 32257 Sends an alert 
				- When a basket has been in a processing state for more than 30 minutes
				- When a basket has been in an ESP submitted state for more than 30 minutes
=============================================
*/
CREATE PROCEDURE [dbo].[procBasketAlerts]	
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Baskets TABLE
	(
		 UserName		NVARCHAR(50)
		 , BasketName	NVARCHAR(80)
		 , BasketID		NVARCHAR(50)
		 , Organization	NVARCHAR(255)
		 , Reason		NVARCHAR(50)
		 , UserID		NVARCHAR(50)
		 , OrgID		NVARCHAR(50)
	)

	--Processing state that isn't ESP
	INSERT INTO @Baskets
	(
	    UserName,
	    BasketName,
	    BasketID,
	    Organization,
	    Reason,
	    UserID,
	    OrgID
	)
	SELECT	U.u_user_name, BS.BasketName, BS.BasketSummaryID, O.u_Name, ISNULL(BPC.Literal, ''), U.u_user_id, O.u_org_id
	FROM	Orders.dbo.BasketSummary AS BS
	JOIN	NextGen_Profiles.dbo.UserObject AS U
	ON		BS.BasketOwnerID = U.u_user_id
	JOIN	NextGen_Profiles.dbo.OrganizationObject AS O
	ON		U.u_org_id = O.u_org_id
	LEFT JOIN Orders.dbo.BasketProcessingCategories AS BPC
	ON		BS.BasketProcessingCategoryID = BPC.BasketProcessingCategoryID
	WHERE	BS.BasketStateID = 10 --InProcess
	AND		BS.UpdatedDateTime <= DATEADD(MINUTE, -30, GETDATE())
	AND		(BPC.Literal <> 'ESP' OR BPC.Literal IS NULL)
	
	--ESP
	INSERT INTO @Baskets
	(
	    UserName,
	    BasketName,
	    BasketID,
	    Organization,
	    Reason,
	    UserID,
	    OrgID
	)
	SELECT	U.u_user_name, BS.BasketName, BS.BasketSummaryID, O.u_Name, 'ESP', U.u_user_id, O.u_org_id
	FROM	Orders.dbo.BasketSummary AS BS
	JOIN	NextGen_Profiles.dbo.UserObject AS U
	ON		BS.BasketOwnerID = U.u_user_id
	JOIN	NextGen_Profiles.dbo.OrganizationObject AS O
	ON		U.u_org_id = O.u_org_id
	WHERE	BS.UpdatedDateTime <= DATEADD(MINUTE, -30, GETDATE())
	AND		BS.ESPDistStateTypeId in (1, 2, 3)

	--generate email if baskets came up
	IF EXISTS (SELECT TOP (1) UserName FROM @Baskets)
	BEGIN
		
		DECLARE @recipients NVARCHAR(MAX) 
				, @BodyHTML	NVARCHAR(MAX)
				, @Environment VARCHAR(20)
				, @Subject VARCHAR(100)

		SELECT	@Environment = REPLACE(ServerEnvironment, ' ', '')
		FROM	BTAdmin.dbo.ServerURL

		IF @Environment LIKE 'DEV%'
			SET @recipients = 'kelly.gulutz@baker-taylor.com;karine.liu@baker-taylor.com;cerisa.meunier@baker-taylor.com'

		IF @Environment = 'Production'
			SET @recipients = 'DL-TS360-Tier-3-Support@baker-taylor.com;DL-360Tier2Support@baker-taylor.com'

		SELECT @BodyHTML = N'<H2>Baskets in a Processing State</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>UserName</th>' +
				N'<th>BasketName</th>' +
				N'<th>BasketID</th>' +
				N'<th>Organization</th>' +
				N'<th>Reason</th>' +
				N'<th>UserID</th>' +
				N'<th>OrgID</th>' +
				N'</tr>' +
		CAST (( 
		SELECT	td = UserName, SPACE(0),
				td = BasketName, SPACE(0),
				td = BasketID, SPACE(0),
				td = Organization, SPACE(0),
				td = Reason, SPACE(0),
				td = UserID, SPACE(0),
				td = OrgID, SPACE(0)
		FROM	@Baskets
		FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' ;

		SELECT @Subject = 'TS360 ' + @Environment + ': Baskets in Processing State'

		EXEC msdb.dbo.sp_send_dbmail
			 @recipients = @recipients
			, @reply_to = 'NoReply@baker-taylor.com'
			, @subject = @Subject
			, @body = @BodyHTML
			, @body_format	= 'HTML'
	END
END
GO
