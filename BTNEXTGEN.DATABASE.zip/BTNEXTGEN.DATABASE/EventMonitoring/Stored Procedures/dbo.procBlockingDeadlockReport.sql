SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2016-11-14
Description:	Emails a list of deadlocks and blocking 
Modifications:
2016-11-18	Changed to a running total for the day
2016-01-23	Changed to half hour totals
=============================================
*/
CREATE PROCEDURE [dbo].[procBlockingDeadlockReport]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Recipients VARCHAR(MAX) = 'btsupport@intsof.com;kelly.gulutz@baker-taylor.com;dan.johnson@baker-taylor.com;ivor.addo@baker-taylor.com;cerisa.meunier@baker-taylor.com;ralph.McKewen@baker-taylor.com;tdo24@csc.com;DL-360Tier2Support@baker-taylor.com'
			, @BlockingHTML NVARCHAR(MAX)
			, @DeadlocksHTML NVARCHAR(MAX)
			, @BodyHTML NVARCHAR(MAX)
			, @BlockingCount INT = 0
			, @DeadlockCount INT = 0
			, @CurrentDate DATE = GETDATE()
	--BLOCKING REPORT  **********************************************************************************
	CREATE	TABLE	#Blocking(
			EventHour	varchar(50),
			WaitTime	integer)
		
	INSERT	#Blocking(
			EventHour,
			WaitTime)
	SELECT	CAST(
			CAST(DATEPART(yy, [EventDate]) as varchar(4)) + '-' +
			CAST(DATEPART(mm, [EventDate]) as varchar(2))  + '-' +
			CAST(DATEPART(dd, [EventDate]) as varchar(2))  + ' ' +
			CAST(DATEPART(hh, [EventDate]) as varchar(2)) + --':00:00'
			CASE WHEN DATEPART(MINUTE, EventDate) < 30 THEN ':00' ELSE ':30' END
			as datetime ) as EventHour,
			[WaitTime]/1000
	FROM	[EventMonitoring].[dbo].[BlockedProcessesInfo]
	WHERE	DB_NAME([DatabaseID]) NOT IN ('BTAdmin', 'CSCDBA', 'MSDB')
	AND		[EventDate] >= @CurrentDate
	AND		EventDate > '2016-11-11 09:40'  --Threshold changed from 10 seconds to 1 second

	SELECT @BlockingHTML = 
		N'<H2>Blocking breakdown</H2>' +
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Event Hour</th>' +
		N'<th>Count</th>' +
		N'<th>Total Wait</th>' +
		N'</tr>' +
	CAST(
	(SELECT		td = EventHour
				, SPACE(0)
				, td = COUNT(1)
				, SPACE(0)
				, td = SUM(WaitTime)
	FROM		#Blocking
	GROUP BY	EventHour
	ORDER BY	CAST(EventHour AS DATETIME) DESC
	FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
	+ N'</table>' 

	SELECT @BlockingCount = COUNT(*) FROM #Blocking

	DROP TABLE #Blocking

	--DEADLOCK REPORT  ****************************************************************************
	SELECT @DeadlocksHTML = 
		N'<H2>Deadlock breakdown </H2>' +
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Event Hour</th>' +
		N'<th>Count</th>' +
		N'</tr>' +
	CAST(
	(SELECT		
				td = CAST(DATEPART(yy, [create_date]) as varchar(4)) + '-' +
					CAST(DATEPART(mm, [create_date]) as varchar(2))  + '-' +
					CAST(DATEPART(dd, [create_date]) as varchar(2))  + ' ' +
					CAST(DATEPART(hh, [create_date]) as varchar(2)) + --':00',
					CASE WHEN DATEPART(MINUTE, create_date) < 30 THEN ':00' ELSE ':30' END, 
					SPACE(0), 
				td = COUNT(1)
	FROM		[EventMonitoring].[dbo].[DeadlocksReports] PA WITH (NOLOCK) 
	WHERE		create_date >= @CurrentDate
	GROUP BY	
				CAST(DATEPART(yy, [create_date]) as varchar(4)) + '-' +
				CAST(DATEPART(mm, [create_date]) as varchar(2))  + '-' +
				CAST(DATEPART(dd, [create_date]) as varchar(2))  + ' ' +
				CAST(DATEPART(hh, [create_date]) as varchar(2)) + --':00'
				CASE WHEN DATEPART(MINUTE, create_date) < 30 THEN ':00' ELSE ':30' END
	ORDER BY	CAST(
				CAST(DATEPART(yy, [create_date]) as varchar(4)) + '-' +
				CAST(DATEPART(mm, [create_date]) as varchar(2))  + '-' +
				CAST(DATEPART(dd, [create_date]) as varchar(2))  + ' ' +
				CAST(DATEPART(hh, [create_date]) as varchar(2)) + --':00' 
				CASE WHEN DATEPART(MINUTE, create_date) < 30 THEN ':00' ELSE ':30' END AS DATETIME) DESC
	FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
	+ N'</table>' 

	SELECT	@DeadlockCount = COUNT(*) 
	FROM	[EventMonitoring].[dbo].[DeadlocksReports] PA WITH (NOLOCK) 
	WHERE	create_date >= @CurrentDate

	SELECT @BlockingHTML = '<p><H1>Blocking count for today: ' + CAST(@BlockingCount AS VARCHAR(10)) + '</H1></p>' + ISNULL(@BlockingHTML, '') 
	SELECT @DeadlocksHTML = '<p><H1>Deadlock count for today: ' + CAST(@DeadlockCount AS VARCHAR(10)) + '</H1></p>' + ISNULL(@DeadlocksHTML, '') 
		
	SELECT @BodyHTML = '<p>' + @BlockingHTML + '</p><p>' + @DeadlocksHTML + '</p>'

	--Send email
	EXEC msdb.dbo.sp_send_dbmail
			@recipients = @recipients
		, @reply_to = 'ProductionNoReply@baker-taylor.com'
		, @subject = 'TS360 Production: Blocks & Deadlocks'
		, @body = @BodyHTML 
		, @importance = 'High'
		, @body_format = 'HTML'
	
END
GO
