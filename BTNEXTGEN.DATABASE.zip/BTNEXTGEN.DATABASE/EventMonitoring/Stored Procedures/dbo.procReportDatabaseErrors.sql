SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-05-11
Description:	Designed to run every 5 minutes
				Pulls data from other server for log reports for IO errors, reports if new errors have been found
				Also checks for new Blocking or Deadlock errors since the last check, reports if new ones have been found
=============================================
*/
CREATE PROCEDURE [dbo].[procReportDatabaseErrors]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CheckFromDate		DATETIME
			, @NewIO			BIT = 0
			, @CheckToDate		DATETIME
			, @BlockingHTML		NVARCHAR(MAX)
			, @BlockingCount	INT = 0
			, @DeadlocksHTML	NVARCHAR(MAX)
			, @DeadlockCount	INT = 0
			
	--IO ERRORS*****************************
	DECLARE @IOErrorTable TABLE (Instance VARCHAR(50), EventDate VARCHAR(20), IOEvents INT)
	DECLARE @LastIOEvent TABLE(Server VARCHAR(25), LastIOEvent DATETIME)

	--Biztalk
	SELECT	@CheckFromDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'BizTalk'

	IF @CheckFromDate IS NULL
		SET @CheckFromDate = '4/11/2017'
		
	INSERT INTO  dbo.LogData (Server, LogDate, LogText)
	EXEC [10.100.100.19\BIZTALK].master.dbo.usp_readerrorlog @CheckFromDate

	IF @@ROWCOUNT > 0
		SET @NewIO = 1

	SET @CheckFromDate = NULL

	--Sharepoint
	SELECT	@CheckFromDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'Sharepoint'

	IF @CheckFromDate IS NULL
		SET @CheckFromDate = '4/11/2017'

	INSERT INTO dbo.LogData (Server, LogDate, LogText)
	EXEC [10.100.100.20\SPNextGen].master.dbo.usp_readerrorlog @CheckFromDate

	IF @@ROWCOUNT > 0
		SET @NewIO = 1

	SET @CheckFromDate = NULL

	--Axis360
	SELECT	@CheckFromDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'Axis360'

	IF @CheckFromDate IS NULL
		SET @CheckFromDate = '4/11/2017'

	INSERT INTO dbo.LogData (Server, LogDate, LogText)
	EXEC [10.100.100.21\SPBTDML].master.dbo.usp_readerrorlog @CheckFromDate

	IF @@ROWCOUNT > 0
		SET @NewIO = 1

	SET @CheckFromDate = NULL

	--TS360Repository
	SELECT	@CheckFromDate = MAX(LogDate)
	FROM	dbo.LogData
	WHERE	Server = 'TS360Repository'

	IF @CheckFromDate IS NULL
		SET @CheckFromDate = '4/11/2017'

	DECLARE @LogID      INT,
			@searchStr   VARCHAR(256),
			@startDate   DATETIME;

	DECLARE @errorLogs   TABLE (
		LogID    INT,
		LogDate  DATETIME,
		LogSize  BIGINT   );

	DECLARE @logData      TABLE (
		LogDate     DATETIME,
		ProcInfo    VARCHAR(64),
		LogText     VARCHAR(MAX)   );

	SELECT  @searchStr = 'I/O'

	INSERT INTO @errorLogs
	EXEC sys.sp_enumerrorlogs;

	SELECT TOP 1 @LogID = LogID
	FROM @errorLogs
	ORDER BY [LogDate];

	WHILE @LogID >= 0
	BEGIN
		INSERT INTO @logData
		EXEC sys.sp_readerrorlog @LogID, 1, @searchStr;
		
		IF @LogID = 0
			BREAK;

		SELECT TOP 1 @LogID = LogID
		FROM	@errorLogs
		WHERE	LogID < @LogID
		ORDER BY [LogDate];
	END

	INSERT INTO dbo.LogData (Server, LogDate, LogText)
	SELECT	'TS360Repository' as Server, [LogDate], [LogText]
	FROM	@logData
	WHERE	LogDate > @CheckFromDate;

	IF @@ROWCOUNT > 0
		SET @NewIO = 1
	--IO ERRORS END**************************

	--Blocking*******************************
	SELECT	@CheckFromDate = CheckDate
			, @CheckToDate = GETDATE()
	FROM	dbo.LastErrorCheckDate
	WHERE	CheckType = 'Blocking'

	CREATE	TABLE	#Blocking(
			EventHour	varchar(50),
			WaitTime	integer)
		
	INSERT	#Blocking(
			EventHour,
			WaitTime)
	SELECT	CAST(
			CAST(DATEPART(yy, EventDate) as varchar(4)) + '-' +
			CAST(DATEPART(mm, EventDate) as varchar(2))  + '-' +
			CAST(DATEPART(dd, EventDate) as varchar(2))  + ' ' +
			CAST(DATEPART(hh, EventDate) as varchar(2)) + --':00:00'
			CASE WHEN DATEPART(MINUTE, EventDate) < 30 THEN ':00' ELSE ':30' END
			as datetime ) as EventHour,
			WaitTime/1000
	FROM	dbo.BlockedProcessesInfo
	WHERE	DB_NAME(DatabaseID) NOT IN ('BTAdmin', 'CSCDBA', 'MSDB')
	AND		EventDate >= @CheckFromDate
	AND		EventDate < @CheckToDate

	SELECT @BlockingHTML = 
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Event Hour</th>' +
		N'<th>Count</th>' +
		N'<th>Total Wait</th>' +
		N'</tr>' +
	CAST(
	(SELECT		td = EventHour
				, SPACE(0)
				, td = COUNT(1)
				, SPACE(0)
				, td = SUM(WaitTime)
	FROM		#Blocking
	GROUP BY	EventHour
	ORDER BY	CAST(EventHour AS DATETIME) DESC
	FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
	+ N'</table>' 

	SELECT @BlockingCount = COUNT(*) FROM #Blocking

	DROP TABLE #Blocking

	UPDATE 	dbo.LastErrorCheckDate
	SET		CheckDate = @CheckToDate
	WHERE	CheckType = 'Blocking'
	--End of Blocking********************

	--Deadlocks**************************
	SELECT	@CheckFromDate = NULL
			, @CheckToDate = NULL

	SELECT	@CheckFromDate = CheckDate
			, @CheckToDate = GETDATE()
	FROM	dbo.LastErrorCheckDate
	WHERE	CheckType = 'Deadlocks'

	SELECT @DeadlocksHTML = 
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Event Hour</th>' +
		N'<th>Count</th>' +
		N'</tr>' +
	CAST(
	(SELECT		
				td = CAST(DATEPART(yy, [create_date]) as varchar(4)) + '-' +
					CAST(DATEPART(mm, [create_date]) as varchar(2))  + '-' +
					CAST(DATEPART(dd, [create_date]) as varchar(2))  + ' ' +
					CAST(DATEPART(hh, [create_date]) as varchar(2)) + --':00',
					CASE WHEN DATEPART(MINUTE, create_date) < 30 THEN ':00' ELSE ':30' END, 
					SPACE(0), 
				td = COUNT(1)
	FROM		[EventMonitoring].[dbo].[DeadlocksReports] PA WITH (NOLOCK) 
	WHERE		create_date >= @CheckFromDate
	AND			create_date < @CheckToDate
	GROUP BY	
				CAST(DATEPART(yy, [create_date]) as varchar(4)) + '-' +
				CAST(DATEPART(mm, [create_date]) as varchar(2))  + '-' +
				CAST(DATEPART(dd, [create_date]) as varchar(2))  + ' ' +
				CAST(DATEPART(hh, [create_date]) as varchar(2)) + --':00'
				CASE WHEN DATEPART(MINUTE, create_date) < 30 THEN ':00' ELSE ':30' END
	ORDER BY	CAST(
				CAST(DATEPART(yy, [create_date]) as varchar(4)) + '-' +
				CAST(DATEPART(mm, [create_date]) as varchar(2))  + '-' +
				CAST(DATEPART(dd, [create_date]) as varchar(2))  + ' ' +
				CAST(DATEPART(hh, [create_date]) as varchar(2)) + --':00' 
				CASE WHEN DATEPART(MINUTE, create_date) < 30 THEN ':00' ELSE ':30' END AS DATETIME) DESC
	FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
	+ N'</table>' 

	SELECT	@DeadlockCount = COUNT(*) 
	FROM	dbo.DeadlocksReports PA WITH (NOLOCK) 
	WHERE	create_date >= @CheckFromDate
	AND		create_date < @CheckToDate

	UPDATE 	dbo.LastErrorCheckDate
	SET		CheckDate = @CheckToDate
	WHERE	CheckType = 'Deadlocks'

	IF @NewIO = 1 OR @DeadlockCount > 0 OR @BlockingCount > 0
	BEGIN
		DECLARE @Recipients VARCHAR(MAX) = 'btsupport@intsof.com;kelly.gulutz@baker-taylor.com;dan.johnson@baker-taylor.com;ivor.addo@baker-taylor.com;cerisa.meunier@baker-taylor.com;Ralph.McKewen@baker-taylor.com;tdo24@csc.com;DL-360Tier2Support@baker-taylor.com'
				, @BodyHTML NVARCHAR(MAX) = ''
		
		IF @NewIO = 1
		BEGIN
			DECLARE @ReportingDate DATETIME = 
				CAST(CAST(CAST(DATEADD(DAY, -1, GETDATE()) as DATE) AS VARCHAR(10)) + SPACE(1) + CAST(DATEPART(HOUR, DATEADD(HOUR,-24, GETDATE())) AS VARCHAR(2)) + ':00' as DATETIME)

			INSERT INTO @IOErrorTable
			SELECT	Server, CONVERT(VARCHAR(10), CAST(LogDate as DATE), 120) + SPACE(1) + RIGHT('0' + CAST(DATEPART(Hour, LogDate) as VARCHAR(2)), 2) + ':00' as EventDate, COUNT(*) as CountOfEvents
			FROM	dbo.LogData
			WHERE	LogDate >= @ReportingDate
			GROUP BY CAST(LogDate as DATE), DATEPART(Hour, LogDate), Server
			ORDER BY EventDate DESC

			INSERT INTO @LastIOEvent
			SELECT	Server, MAX(LogDate) as LastIOEvent
			FROM	dbo.LogData
			GROUP BY Server
			ORDER BY LastIOEvent DESC

			DECLARE @Axis360HTML		VARCHAR(MAX)
					, @TS360HTML		VARCHAR(MAX)
					, @SharepointHTML	VARCHAR(MAX)
					, @BiztalkHTML		VARCHAR(MAX)
					, @LastEventHTML	VARCHAR(MAX)
					, @Subject			VARCHAR(50)

			SELECT @Axis360HTML = 
				N'<H2>Axis360 IO Events (Last 24 hours)</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>Event Date</th>' +
				N'<th>IOEvents</th>' +
				N'</tr>' +
			CAST(
			(SELECT		td = EventDate
						, SPACE(0)
						, td = IOEvents
			FROM		@IOErrorTable
			WHERE		Instance = 'Axis360'
			ORDER BY	EventDate DESC
			FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
			+ N'</table>' 

			SELECT @TS360HTML = 
				N'<H2>TS360 Repository IO Events (Last 24 hours)</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>Event Date</th>' +
				N'<th>IOEvents</th>' +
				N'</tr>' +
			CAST(
			(SELECT		td = EventDate
						, SPACE(0)
						, td = IOEvents
			FROM		@IOErrorTable
			WHERE		Instance = 'TS360Repository'
			ORDER BY	EventDate DESC
			FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
			+ N'</table>' 

			SELECT @BiztalkHTML = 
				N'<H2>BizTalk IO Events (Last 24 hours)</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>Event Date</th>' +
				N'<th>IOEvents</th>' +
				N'</tr>' +
			CAST(
			(SELECT		td = EventDate
						, SPACE(0)
						, td = IOEvents
			FROM		@IOErrorTable
			WHERE		Instance = 'BizTalk'
			ORDER BY	EventDate DESC
			FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
			+ N'</table>' 

			SELECT @SharepointHTML = 
				N'<H2>Sharepoint IO Events (Last 24 hours)</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>Event Date</th>' +
				N'<th>IOEvents</th>' +
				N'</tr>' +
			CAST(
			(SELECT		td = EventDate
						, SPACE(0)
						, td = IOEvents
			FROM		@IOErrorTable
			WHERE		Instance = 'Sharepoint'
			ORDER BY	EventDate DESC
			FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
			+ N'</table>' 

			SELECT @LastEventHTML = 
				N'<H2>Last IO Event</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>Server</th>' +
				N'<th>LastIOEvent</th>' +
				N'</tr>' +
			CAST(
			(SELECT		td = Server
						, SPACE(0)
						, td = LastIOEvent
			FROM		@LastIOEvent
			ORDER BY	LastIOEvent DESC
			FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
			+ N'</table>' 

			SELECT @BodyHTML = '<p>' + ISNULL(@LastEventHTML, '') + 
				'</p><p>' + ISNULL(@TS360HTML, '') + 
				'</p><p>' + ISNULL(@Axis360HTML, '') + 
				'</p><p>' + ISNULL(@BiztalkHTML, '') + 
				'</p><p>' + ISNULL(@SharepointHTML, '') + '</p>'
		END

		IF @DeadlockCount > 0
		BEGIN
			SELECT @DeadlocksHTML = '<p><H2>Deadlock count: ' + CAST(@DeadlockCount AS VARCHAR(10)) + '</H2></p>' + ISNULL(@DeadlocksHTML, '') 
			SELECT @BodyHTML = ISNULL(@BodyHTML, '') + '<p>' + @DeadlocksHTML + '</p>'
		END

		IF @BlockingCount > 0
		BEGIN
			SELECT @BlockingHTML = '<p><H2>Blocking count: ' + CAST(@BlockingCount AS VARCHAR(10)) + '</H2></p>' + ISNULL(@BlockingHTML, '')
			SELECT @BodyHTML = ISNULL(@BodyHTML, '') + '<p>' + @BlockingHTML + '</p>' 
		END

		--Send email
		EXEC msdb.dbo.sp_send_dbmail
				@recipients = @recipients
			, @reply_to = 'ProductionNoReply@baker-taylor.com'
			, @subject = 'TS360 Production: New Database Errors'
			, @body = @BodyHTML 
			, @importance = 'High'
			, @body_format = 'HTML'
	END
END
GO
