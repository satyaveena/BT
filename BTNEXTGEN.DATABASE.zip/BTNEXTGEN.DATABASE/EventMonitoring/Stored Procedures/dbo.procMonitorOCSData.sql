SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[procMonitorOCSData]
AS
BEGIN
	--exec EventMonitoring.dbo.procMonitorOCSData

	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	TRUNCATE TABLE dbo.OCSResults

	INSERT INTO dbo.OCSResults
	SELECT		--o.u_name, 
				os.Account8ID, os.OrderNumber
				, CAST(os.orderdate as date) as OrderDate
				, 'OCSModifiedDateTime' as Reason
				, OS.OCSModifiedDateTime
	FROM		orders.dbo.OrderDetailStatus ods WITH (NOLOCK)              
	RIGHT JOIN  orders.dbo.OrderSummary os WITH (NOLOCK)
				ON			os.Account8ID = ods.Account8ID
				AND			os.OrderNumber = ods.OrderNumber
				AND			os.CompanyCode = ods.CompanyCode
				AND			ISNULL(os.IMSSegmentID, '')  = ISNULL(ods.IMSSegmentID, '')	
	--JOIN		nextgen_profiles.dbo.BTAccounts a ON a.u_account8_id = os.Account8id
	--JOIN		nextgen_profiles.dbo.[OrganizationObject] o ON o.u_org_id = a.u_org_id
	WHERE		os.OrderNumber NOT IN ('CANCELLED', 'BACKORDER')
	AND			os.CompanyCode IN ('BT')
	AND			os.Account8ID <> '00491016'
	AND			os.OrderDate > '2015-01-01'
	AND			os.Account8ID IN (SELECT u_account8_id FROM nextgen_profiles.dbo.BTAccounts WHERE u_org_id IS NOT NULL AND u_account8_id IS NOT NULL)
	GROUP BY	os.Account8ID, os.OrderNumber
				, os.orderdate, os.UpdateStatus, OS.OCSModifiedDateTime
	HAVING		max(os.[OCSModifiedDateTime]) < MAX(ods.[OCSModifiedDateTime])

	UNION

	SELECT		--o.u_name, 
				os.Account8ID, os.OrderNumber
				, CAST(os.orderdate as date) as OrderDate
				, 'CancelledQty'
				, OS.OCSModifiedDateTime
	FROM		(SELECT		Account8ID, OrderNumber, CompanyCode, IMSSegmentID, SUM(QUantity) as Quantity
				FROM		orders.dbo.OrderDetailStatus
				WHERE		Status IN ('C') 
				AND			ISNULL(CancelReasonCode, '') <> 'CL'          -- 2018-04-03 Bruce Baum TFS 28342
				GROUP BY	Account8ID, OrderNumber, CompanyCode, IMSSegmentID 
				HAVING		SUM(Quantity) > 0) as ods
	RIGHT JOIN  orders.dbo.OrderSummary os WITH (NOLOCK)
				ON			os.Account8ID = ods.Account8ID
				AND			os.OrderNumber = ods.OrderNumber
				AND			os.CompanyCode = ods.CompanyCode
				AND			ISNULL(os.IMSSegmentID, '')  = ISNULL(ods.IMSSegmentID, '')	
	--JOIN		nextgen_profiles.dbo.BTAccounts a ON a.u_account8_id = os.Account8id
	--JOIN		nextgen_profiles.dbo.[OrganizationObject] o ON o.u_org_id = a.u_org_id
	WHERE		os.OrderNumber NOT IN ('CANCELLED', 'BACKORDER')
	AND			os.Account8ID <> '00491016'
	AND			os.OrderDate > '2015-01-01'
	--AND			os.[OCSModifiedDateTime] < '2015-04-13 3:00'
	AND			os.Account8ID IN (SELECT u_account8_id FROM nextgen_profiles.dbo.BTAccounts WHERE u_org_id IS NOT NULL AND u_account8_id IS NOT NULL)
	GROUP BY	os.Account8ID, os.OrderNumber
				, os.orderdate, os.UpdateStatus, OS.OCSModifiedDateTime
	HAVING		max(ISNULL(os.CancelledQuantity, 0)) <> SUM(ISNULL(ods.quantity, 0))

	--InProcess
	UNION

	SELECT		--o.u_name, 
				os.Account8ID, os.OrderNumber
				, CAST(os.orderdate as date) as OrderDate
				, 'InProcess Qty'
				, OS.OCSModifiedDateTime
	FROM		(SELECT Account8ID, OrderNumber, CompanyCode, IMSSegmentID, SUM(QUantity) as Quantity
				FROM orders.dbo.OrderDetailStatus 
				WHERE Status IN ('P', 'D') --Bruce\Dave 2018-04-06
				GROUP BY Account8ID, OrderNumber, CompanyCode, IMSSegmentID 
				HAVING SUM(Quantity) > 0
				) as ods 
	RIGHT JOIN  orders.dbo.OrderSummary os WITH (NOLOCK)
				ON			os.Account8ID = ods.Account8ID
				AND			os.OrderNumber = ods.OrderNumber
				AND			os.CompanyCode = ods.CompanyCode
				AND			ISNULL(os.IMSSegmentID, '')  = ISNULL(ods.IMSSegmentID, '')	
	--JOIN		nextgen_profiles.dbo.BTAccounts a ON a.u_account8_id = os.Account8id
	--JOIN		nextgen_profiles.dbo.[OrganizationObject] o ON o.u_org_id = a.u_org_id
	WHERE		os.OrderNumber NOT IN ('CANCELLED', 'BACKORDER')
	AND			os.Account8ID <> '00491016'
	AND			os.OrderDate > '2015-01-01'
	AND			os.Account8ID IN (SELECT u_account8_id FROM nextgen_profiles.dbo.BTAccounts WHERE u_org_id IS NOT NULL AND u_account8_id IS NOT NULL)
	GROUP BY	os.Account8ID, os.OrderNumber
				, os.orderdate, os.UpdateStatus, OS.OCSModifiedDateTime
	HAVING		max(ISNULL(os.InProcessQuantity, 0)) <> SUM(ISNULL(ods.quantity, 0))
	--BAKCORDERED QUANTITY

	UNION

	SELECT		--o.u_name, 
				os.Account8ID, os.OrderNumber
				, CAST(os.orderdate as date) as OrderDate
				, 'BOQty'
				, OS.OCSModifiedDateTime
	FROM		(SELECT Account8ID, OrderNumber, CompanyCode, IMSSegmentID, SUM(QUantity) as Quantity 
				FROM orders.dbo.OrderDetailStatus 
				WHERE Status IN ('B', 'U', '5', '4', '3')
				GROUP BY Account8ID, OrderNumber, CompanyCode, IMSSegmentID 
				HAVING SUM(Quantity) > 0) AS ods 
	RIGHT JOIN	orders.dbo.OrderSummary os WITH (NOLOCK)
				ON			os.Account8ID = ods.Account8ID
				AND			os.OrderNumber = ods.OrderNumber
				AND			os.CompanyCode = ods.CompanyCode
				AND			ISNULL(os.IMSSegmentID, '')  = ISNULL(ods.IMSSegmentID, '')	
	--JOIN		nextgen_profiles.dbo.BTAccounts a ON a.u_account8_id = os.Account8id
	--JOIN		nextgen_profiles.dbo.[OrganizationObject] o ON o.u_org_id = a.u_org_id
	WHERE		os.OrderNumber NOT IN ('CANCELLED', 'BACKORDER')
	AND			os.Account8ID <> '00491016'
	AND			os.OrderDate > '2015-01-01'
	AND			os.Account8ID IN (SELECT u_account8_id FROM nextgen_profiles.dbo.BTAccounts WHERE u_org_id IS NOT NULL AND u_account8_id IS NOT NULL)
	GROUP BY	os.Account8ID, os.OrderNumber
				, os.orderdate, os.UpdateStatus, OS.OCSModifiedDateTime
	HAVING		max(ISNULL(os.BackOrderQuantity, 0)) <> SUM(ISNULL(ods.quantity, 0))
	ORDER BY Account8ID, OrderNumber

	IF @@ROWCOUNT > 0
	BEGIN
		--1st email account number & order number as .rpt attachment for john to fix
		--2nd email body of email will contain full list so we can see what the errors are
		DECLARE @ProfileName		NVARCHAR(255)
				, @Recipients		VARCHAR(MAX)
				, @ReplyTo			VARCHAR(MAX)
				, @Subject			NVARCHAR(510)
				, @ServerName		VARCHAR(255)
				, @importanceStatus CHAR(4) = 'HIGH'						
				, @ccrecipients		VARCHAR(MAX)
				, @attachmentname	CHAR(12) = CONVERT(CHAR(8), GETDATE(), 112) + '.rpt'
	
		SELECT	@ServerName = @@SERVERNAME 
	
		SET @ReplyTo = 'PRODNoReply@baker-taylor.com'
		SET @Subject = 'TS360 Production: OCS Data Discrepancies'
		SET @recipients = 'kelly.gulutz@baker-taylor.com;jmcgrat4@csc.com;Larry.D''Agostino@baker-taylor.com; Bruce.Baum@Baker-Taylor.com'
		--DHB 2018-04-03  SET @recipients = 'kelly.gulutz@baker-taylor.com;cerisa.meunier@baker-taylor.com;jmcgrat4@csc.com;Larry.D''Agostino@baker-taylor.com'
		--DHB 2018-04-03  SET @ccrecipients = 'Dan.Johnson@baker-taylor.com;Ivor.Addo@baker-taylor.com;'

		--Send second email, with results and addtional information in body
		SET @Subject = 'TS360 Production: OCS Data Discrepancy Full List'
		EXEC msdb.dbo.sp_send_dbmail
			--@profile_name = 'CSC SQL Mail'
			@recipients = @recipients
			, @copy_recipients = @ccrecipients
			, @reply_to = @ReplyTo
			, @subject = @Subject
			, @importance = @importanceStatus
			--, @query_attachment_filename = 'OCSDiscrepancies.txt'
			--, @query = 'SELECT * FROM Orders.dbo.OCSResults ORDER BY Account8ID, OrderNumber '
			--, @attach_query_result_as_file = 1
	END
END


GO
