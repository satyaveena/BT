SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[procMonitorQueueCounts]
AS
/**************************************************************
CREATED BY:		David Browne (Baker & Taylor)
CREATEION Date:	2014-06-05

exec procMonitorQueueCounts
2015-07-28  GENERAL DAN SHAKEUP
2016-02-25	KG	Added ODS queue stats to consolidate emails
2016-10-18	KG	Excluded onebox bofs from the submitted order status
2017-01-23	KG	Support for 3.1.12 Hotfix 2
				Added FAST POC Queue
2017-08-03	KG	Modified the order check dates to be 8/1
2017-09-16	KG	Removed POC Queue
2018-03-06	KG	Changed to use updated date time on the BOF instead of created date time
2018-03-29	DHB	Deployed to EventMonitoring DB
2018-07-11	KG	Changed the order count to one date at the top of the stored proc
2019-02-14	KG	TFS 33874	Add III background process to queue length email
2019-02-07	KG	TFS 32257 Add ESP and Processing counts to queue lengths
2020-01-13  CM TFS ESP Auto Ranking - Queue Monitoring
2020-02-06	KF	Added OCS last load dates
2020-03-10	KG	37137 Added sp_executesql to handle connection issues with ODS
2020-05-22	RM	37980 Added CSD to queue lengths
2021-06-10	KG	Created dynamic recipients and subjects based on environment
**************************************************************/
BEGIN

	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	SET NOCOUNT ON;
		
	DECLARE @OrderCheckDate	DATE = '1/29/2019'
			, @ODSErrorNumber INT = 0
			, @ODSErrorMessage NVARCHAR(4000)
			, @ODSQuery NVARCHAR(MAX)
			, @ODSPendingHTML		NVARCHAR(MAX)
			, @ODSProcessedHTML	NVARCHAR(MAX)
			, @ODSParameters	NVARCHAR(MAX)
			, @ODSErrorHTML NVARCHAR(MAX) = ''
			, @Environment VARCHAR(20)
			, @recipients		varchar(500) 

	SELECT	@Environment = REPLACE(ServerEnvironment, ' ', '')
	FROM	BTAdmin.dbo.ServerURL

	If @Environment LIKE 'DEV%'
		SET @recipients = 'kelly.gulutz@baker-taylor.com'

	IF @Environment = 'Production'
		SET @recipients = 'kelly.Gulutz@baker-taylor.com;ivor.addo@baker-taylor.com;tdo24@csc.com;dan.johnson@baker-taylor.com;Jamie.Self@baker-taylor.com;cerisa.meunier@baker-taylor.com;btsupport@intsof.com;Nicole.Tate@baker-taylor.com'

	--ODS Breakdown
	CREATE TABLE #QueueLength
	(
		RecordCount		INT
		, SendPriority	INT
		, SendPriorityOutput VARCHAR(25)
	)

	CREATE TABLE #ProcessedRecords
	(
		RecordCount		INT
		, ProcessDate	DATE
		, ProcessHour	INT
		, ProcessDateOutput	VARCHAR(25)
	)

	--CheckODS connection status
	BEGIN TRY

		--test query
		SELECT @ODSQuery = 'SELECT TOP (1) prd_id FROM ODS.db_transaction.dbo.tbl_ts360_product_queue'
		EXEC sp_executesql @ODSQuery

	END TRY

	BEGIN CATCH

		SELECT @ODSErrorNumber = ERROR_NUMBER()
				, @ODSErrorMessage = ERROR_MESSAGE()

	END CATCH

	--ODS  ************************************************
	--Changed to use check above before performing the query, must use sp_executesql because this sp won't compile if we can't connect
	IF @ODSErrorNumber = 0
	BEGIN
		DECLARE	@ODSPendingCount		integer = 0
				, @ODSMongoPendingCount	integer = 0
				, @ODSOutputs			NVARCHAR(MAX)

		--TS360 Product queue
		SELECT @ODSQuery = 'SELECT @ODSPendingCount = COUNT(1) FROM ODS.db_transaction.dbo.tbl_ts360_product_queue WHERE status_cd = ''P'''
			, @ODSOutputs = '@ODSPendingCount INT OUTPUT'

		EXEC sp_executesql @ODSQUery, @ODSOutputs, @ODSPendingCount = @ODSPendingCount OUTPUT

		--Mongo product queue
		SELECT	@ODSQuery = 'SELECT @ODSMongoPendingCount = COUNT(1) FROM ODS.[db_transaction].[dbo].[tbl_ts360_Mongo_product_queue] WHERE StatusCode = ''p'''
			, @ODSOutputs = '@ODSMongoPendingCount INT OUTPUT'

		EXEC sp_executesql @ODSQUery, @ODSOutputs, @ODSMongoPendingCount = @ODSMongoPendingCount OUTPUT

		DECLARE @CheckDate DATETIME2
		--creates a date for this hour yesterday, 12:06 pm on 12/7/2015 should return 12/6/2015 12:00
		SET @CheckDate = CAST(CAST(CAST(GETDATE()-1 as DATE) AS VARCHAR(10)) + SPACE(1) + RIGHT('0' + CAST(DATEPART(HOUR, GETDATE()) as VARCHAR(2)), 2) + ':00' as datetime2)

		--Priority breakdown
		SELECT @ODSQuery = '
		SELECT COUNT(*) as RecordCount, send_priority, send_priority 
		FROM		ODS.db_transaction.dbo.tbl_ts360_product_queue AS ODS
		WHERE		status_cd = ''P'' 
		GROUP BY	send_priority
		WITH ROLLUP'

		INSERT INTO #QueueLength (RecordCount, SendPriority, SendPriorityOutput)
		EXEC sp_executesql @ODSQuery

		--Records processed in the last 24 hours
		SELECT @ODSQuery = 
			'SELECT		COUNT(*) as completed, CAST(completion_date as Date) as Date, DATEPART(hour, completion_date) as Hour, CAST(completion_date as Date)
			FROM		ODS.db_transaction.dbo.tbl_ts360_product_queue AS ODS
			WHERE		status_cd = ''c''
			and			completion_date >= @CheckDate
			GROUP BY	CAST(completion_date as Date), DATEPART(hour, completion_date), CAST(completion_date as Date)'
			, @ODSParameters = N'@CheckDate DATETIME2'

		INSERT INTO #ProcessedRecords (RecordCount, ProcessDate, ProcessHour, ProcessDateOutput)
		EXEC sp_executesql @ODSQuery, @ODSParameters, @CheckDate = @CheckDate

		INSERT INTO #ProcessedRecords (RecordCount)
		SELECT	SUM(RecordCount)
		FROM	#ProcessedRecords

		--Build HTML
		SET @ODSPendingHTML = N'<H2>ODS Pending Product Breakdown</H2>' +
					N'<table border="1">' +
					N'<tr>' + 
					N'<th>RecordCount</th>' +
					N'<th>SendPriority</th>' +
					N'</tr>' +
		CAST ((
				SELECT	td = RecordCount, SPACE(1),
						td = CASE WHEN SendPriorityOutput IS NULL THEN 'Pending' ELSE SendPriorityOutput END, SPACE(1)
				FROM	#QueueLength 
				ORDER BY CASE WHEN SendPriority IS NULL THEN 1 ELSE 0 END, SendPriority
		FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' ;

		SELECT @ODSProcessedHTML = N'<H2>ODS Processed Records</H2>' +
					N'<table border="1">' +
					N'<tr>' + 
					N'<th>RecordCount</th>' +
					N'<th>ProcessDate</th>' +
					N'<th>ProcessHour</th>' +
					N'</tr>' +
		CAST ((
			SELECT	td = RecordCount, SPACE(1),
					td = CASE WHEN ProcessDateOutput IS NULL THEN 'Processed' ELSE ProcessDateOutput END , SPACE(1),
					td = ProcessHour, SPACE(1)
			FROM	#ProcessedRecords 
			ORDER BY CASE WHEN ProcessDate IS NULL THEN 1 ELSE 0 END, ProcessDate, ProcessHour
		FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' ;
	END
	ELSE --unable to connect to ODS
	BEGIN
		SELECT @ODSErrorHTML = '<font color="red"><p>Unable to connect to ODS<br>' +
							'ErrorNumber: ' + CAST(@ODSErrorNumber AS VARCHAR(10)) + '<br>' +
							'ErrorMessage: ' + @ODSErrorMessage + '</font>'
	END

	--PRICING ENGINE  ************************************
	DECLARE	@PendingRepricingCount int = 0

	SELECT	@PendingRepricingCount = COUNT(1)
	FROM	Orders.dbo.BasketLineItems WITH (NOLOCK)
	WHERE	RePricingRequiredFlag = 1

	--FAST  ***********************************************
	DECLARE	@FastPendingCount		integer = 0,
			@FASTBackLog			integer = 0,
			@FastDRPendingCount		integer = 0--,
			--@FastPOCPendingCount	integer = 0

	SELECT	@FastPendingCount = COUNT(1) 
	FROM	BTAdmin.dbo.ProductFastBatchItems
	WHERE	ProductFastBatchID = 0

	SELECT	@FASTBackLog = COUNT(1) 
	FROM	BTAdmin.dbo.ProductFastBatchItems
	WHERE	ProductFastBatchID = -1 

	SELECT	@FastDRPendingCount = COUNT(1) 
	FROM	BTAdmin.dbo.ProductFastDRBatchItems
	WHERE	ProductFastDRBatchID = 0

	--OCS  ***********************************************
	DECLARE	@ErrorInvoiceDetail int,
			@ErrorInvoiceSummary int,
			@ErrorOrderDetail int,
			@ErrorOrderDetailStatus int,
			@ErrorOrderHeader int,
			@ErrorOrderSummary int,
			@ErrorPackage int,
			@ErrorVASSundry int

	SELECT	@ErrorInvoiceDetail = COUNT(1) 
	FROM	orders.[dbo].[ErrorInvoiceDetail]

	SELECT	@ErrorInvoiceSummary = COUNT(1) 
	FROM	orders.[dbo].[ErrorInvoiceSummary]

	SELECT	@ErrorOrderDetail = COUNT(1) 
	FROM	orders.[dbo].[ErrorOrderDetail]

	SELECT	@ErrorOrderDetailStatus = COUNT(1) 
	FROM	orders.[dbo].[ErrorOrderDetailStatus]

	SELECT	@ErrorOrderHeader = COUNT(1) 
	FROM	orders.[dbo].[ErrorOrderHeader]

	SELECT	@ErrorOrderSummary = COUNT(1) 
	FROM	orders.[dbo].[ErrorOrderSummary]

	SELECT	@ErrorPackage = COUNT(1) 
	FROM	orders.[dbo].[ErrorPackage]

	SELECT	@ErrorVASSundry = COUNT(1) 
	FROM	orders.[dbo].[ErrorVASSundry]

	--COMMERCE SERVER  ***********************************
	DECLARE	@CSPendingCount			integer = 0

	SELECT	@CSPendingCount = COUNT(1) 
	FROM	BTAdmin.dbo.ProductCommerceServerBatchItems
	WHERE	ProductCommerceServerBatchID = 0


	--ORDER STATUS  **************************************
	DECLARE	@NewOrderCount int,
			@InProcessOrderCount int,
			@SubmittedCount INT,
			@ESPSubmittedCount INT,
			@ILSPendingOrderCount int,
			@ILSError nvarchar(max),
			@ProcessingStateCount INT

	--ESP AUTO RANK STATUS *********************************
	DECLARE @NewESPAutoRankCount INT,
			@InProcessESPAutoRankCount INT,
			@SubmittedESPAutoRankCount INT

	DECLARE @CSDBasketOrderFormCount INT,
			@CSDInvoiceDetailCount INT,
			@CSDOrderDetailStatusCount INT,
			@CSDBOFPulledCount INT,
			@CSDInvoicePulledCount INT,
			@CSDOrderDetailPulledCount INT

	DECLARE @ILSPending table (ILSPendingOrderCount INT)
	
	SELECT	@NewOrderCount = COUNT(1) 
	FROM	Orders.[dbo].[BasketOrderForm]
	WHERE	BasketOrderFormStateID = 1 -- new order
	AND		DATEDIFF(MINUTE, UpdatedDateTime, GETDATE()) > 6
	AND		UpdatedDateTime > @OrderCheckDate
	AND		BasketAccountTypeID <> 9

	SELECT	@InProcessOrderCount = COUNT(1) 
	FROM	Orders.[dbo].[BasketOrderForm] 
	WHERE	BasketOrderFormStateID = 2 -- In Process
	AND		DATEDIFF(MINUTE, UpdatedDateTime, GETDATE()) > 6
	AND		UpdatedDateTime > @OrderCheckDate
	AND		BasketAccountTypeID <> 9

	SELECT	@SubmittedCount = COUNT(1) 
	FROM	Orders.[dbo].[BasketOrderForm] 
	WHERE	BasketOrderFormStateID = 3 -- Submitted
	AND		DATEDIFF(MINUTE, UpdatedDateTime, GETDATE()) > 6
	AND		UpdatedDateTime > @OrderCheckDate
	AND		BasketAccountTypeID <> 9

	INSERT INTO @ILSPending
	EXEC	Orders.dbo.procTS360GetILSPendingOrderCount @ILSError OUTPUT

	select	@ILSPendingOrderCount = ILSPendingOrderCount
	from	@ILSPending

	--ESP
	SELECT	@ESPSubmittedCount = COUNT(*)
	FROM 	Orders.dbo.BasketSummary
	WHERE	ESPDistStateTypeId in (1, 2, 3)
	AND		UpdatedDateTime <= DATEADD(MINUTE, -30, GETDATE())

	--ProcessingState
	SELECT	@ProcessingStateCount = COUNT(*)
	FROM	Orders.dbo.BasketSummary
	WHERE	BasketStateID = 10 --InProcess
	AND		UpdatedDateTime <= DATEADD(MINUTE, -30, GETDATE())

	--ESP AUTO RANK NEW
	SELECT	@NewESPAutoRankCount = COUNT(1)
	FROM	Orders.dbo.ESPAutoRankQueue
	WHERE	ESPAutoRankQueueStatus = 1

	--ESP AUTO RANK IN PROCESS
	SELECT	@InProcessESPAutoRankCount = COUNT(1)
	FROM	Orders.dbo.ESPAutoRankQueue
	WHERE	ESPAutoRankQueueStatus = 2

	--ESP AUTO RANK SUBMITTED
	SELECT	@SubmittedESPAutoRankCount = COUNT(1)
	FROM	Orders.dbo.ESPAutoRankQueue
	WHERE	ESPAutoRankQueueStatus = 3

	--CSD
	SELECT	@CSDBasketOrderFormCount = COUNT(1)
	FROM	Orders.dbo.BasketOrderForm
	WHERE	CustomerSupportLoadFlag = 1

	SELECT	@CSDInvoiceDetailCount = COUNT(1)
	FROM	Orders.dbo.InvoiceDetail
	WHERE	CustomerSupportLoadFlag = 1

	SELECT	@CSDOrderDetailStatusCount = COUNT(1)
	FROM	Orders.dbo.OrderDetailStatus
	WHERE	CustomerSupportLoadFlag = 1

	SELECT	@CSDBOFPulledCount  = COUNT(BasketOrderFormId)
	FROM	Orders.dbo.BasketOrderForm
	WHERE	CustomerSupportLoadFlag = 2

	SELECT	@CSDInvoicePulledCount = COUNT(InvoiceDetailID)
	FROM	Orders.dbo.InvoiceDetail
	WHERE	CustomerSupportLoadFlag = 2

	SELECT	@CSDOrderDetailPulledCount = COUNT(OrderDetailStatusID)
	FROM	orders.dbo.OrderDetailStatus
	WHERE	CustomerSupportLoadFlag = 2



	--GENERATE TEXT FOR EMAIL  ***************************		
	DECLARE	@QueueCounts TABLE (
		QueueName		nvarchar(100),
		QueueCount	integer)
	
	INSERT	@QueueCounts(
			QueueName,
			QueueCount)
	VALUES	('Commerce Server', @CSPendingCount),
			('ODS (Product)', ISNULL(@ODSPendingCount, 0)),
			('ODS (Mongo)', ISNULL(@ODSMongoPendingCount, 0)),
			('Pricing Engine', @PendingRepricingCount),
			('Fast', @FastPendingCount),
			('Fast (Low Priority)', @FASTBackLog),
			('Fast DR', @FastDRPendingCount),
			--('Fast POC', @FastPOCPendingCount), 
			--('Invoice Summary Pending Deletion', @InvoiceSummaryCount),
			--('Invoice Detail Pending Deletion', @InvoiceDetailCount),
			('Order Summary errors', @ErrorOrderSummary),
			('Order Header errors', @ErrorOrderHeader),
			('Order Detail errors', @ErrorOrderDetail),
			('Order Detail Status errors', @ErrorOrderDetailStatus),
			('Invoice Summary errors', @ErrorInvoiceSummary),
			('Invoice Detail errors', @ErrorInvoiceDetail),
			('Package errors', @ErrorPackage),
			('VAS errors', @ErrorVASSundry),
			('New Order Count', @NewOrderCount),
			('In Process Order Count', @InProcessOrderCount),
			('Submitted Order Count', @SubmittedCount),
			('ILS Pending Order Count', @ILSPendingOrderCount),
			('ESP Submitted State Count', @ESPSubmittedCount),
			('Processing State Count', @ProcessingStateCount),
			('New ESP AutoRank Count', @NewESPAutoRankCount),
			('In Process ESP AutoRank Count', @InProcessESPAutoRankCount),
			('Submitted ESP AutoRank Count', @SubmittedESPAutoRankCount),
			('CSD Basket Order Form Pending Count', @CSDBasketOrderFormCount),
			('CSD Basket Order Form Pulled Count', @CSDBOFPulledCount),
			('CSD Invoice Detail Pending Count', @CSDInvoiceDetailCount),
			('CSD Invoice Detail Pulled Count', @CSDInvoicePulledCount),
			('CSD Order Detail Status Pending Count', @CSDOrderDetailStatusCount),
			('CSD Order Detail Status Pulled Count', @CSDOrderDetailPulledCount)

	DECLARE @QueueHTML  NVARCHAR(max) ;

	SET @QueueHTML =
		N'<H1>TS360 ' +  @Environment + ' Queue Lengths</H1>' + --		N'<H1>TS360 PROD Queue Lengths</H1>' +
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Queue</th>' +
		N'<th>Length</th>' +
		N'</tr>' +
	CAST ( ( 
	SELECT		td = QueueName,       '',
				td = QueueCount,       ''
	FROM	@QueueCounts
	FOR XML PATH('tr'), TYPE 
	) AS NVARCHAR(MAX) ) +
	N'</table>' ;

	--OCS
	DECLARE	@OCSOrdersLastRunDate	datetime,
			@OCSInvoicesLastRunDate	DATETIME,
			@OCSHTML NVARCHAR(MAX),
			@InvoiceHours INT, 
			@OrdersHours INT

	SELECT	TOP (1) @OCSOrdersLastRunDate = [OCSTimestamp]

	FROM	orders.dbo.OCSExtract
	WHERE	[OCSStoredProcedure] = 'NXT.NGEXOS'

	SELECT	TOP (1) @OCSInvoicesLastRunDate = [OCSTimestamp]
	FROM	orders.dbo.OCSExtract
	WHERE	[OCSStoredProcedure] = 'NXT.NGEXVS'

	SELECT	@InvoiceHours = DATEDIFF(hh, @OCSInvoicesLastRunDate, GETDATE())
			, @OrdersHours = DATEDIFF(hh, @OCSOrdersLastRunDate, GETDATE())

	SET @OCSHTML = 	
		'<H2>OCS Load Status</H2>' +
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Load</th>' +
		N'<th>Last Run</th>' +
		N'</tr>' +
		N'<tr>' + 
		N'<td>' + 
		CASE WHEN @OrdersHours > 48 THEN '<font color="red">' ELSE '' END + 
		N'Orders Load' + 
		CASE WHEN @OrdersHours > 48 THEN '</font>' ELSE '' END + 
		N'</td>' +
		N'<td>' + 
		CASE WHEN @OrdersHours > 48 THEN '<font color="red">' ELSE '' END + 
		CAST(@OCSOrdersLastRunDate as nvarchar(50)) + 
		CASE WHEN @OrdersHours > 48 THEN '</font>' ELSE '' END + 
		N'</td>' +
		N'</tr>' +
		N'<tr>' + 
		N'<td>' +
		CASE WHEN @InvoiceHours > 48 THEN '<font color="red">' ELSE '' END +
		N'Invoice Load' +
		CASE WHEN @InvoiceHours > 48 THEN '</font>' ELSE '' END +
		N'</td>' +
		N'<td>' + 
		CASE WHEN @InvoiceHours > 48 THEN '<font color="red">' ELSE '' END +
		CAST(@OCSInvoicesLastRunDate as nvarchar(50)) + 
		CASE WHEN @InvoiceHours > 48 THEN '</font>' ELSE '' END +
		N'</td>' +
		CASE WHEN @InvoiceHours > 48 THEN '</font>' ELSE '' END +
		N'</tr>' +
		N'</table>' ;

	--eMAIL  *************************************************************************************************************
	DECLARE	@BodyHTML nvarchar(max)
			, @ReplyTo VARCHAR(100)
			, @Subject VARCHAR(100)

	SELECT 	@BodyHTML = ISNULL(@ODSErrorHTML, N'') +
						ISNULL(@QueueHTML, N'') +
						ISNULL(@OCSHTML, N'') +
						ISNULL(@ODSPendingHTML, N'') +
						ISNULL(@ODSProcessedHTML, N'')

	SELECT @ReplyTo = @Environment + 'NoReply@baker-taylor.com'
			, @Subject = 'TS360 ' + @Environment + ':  Queue Lengths.' --, @subject = 'TS360 Production:  Queue Lengths.'

	EXEC msdb.dbo.sp_send_dbmail
		 @recipients = @recipients
		, @reply_to = @ReplyTo
		, @subject = @Subject
		, @body = @BodyHTML
		, @body_format	= 'HTML'

	DROP TABLE #QueueLength
	DROP TABLE #ProcessedRecords


END



GO
