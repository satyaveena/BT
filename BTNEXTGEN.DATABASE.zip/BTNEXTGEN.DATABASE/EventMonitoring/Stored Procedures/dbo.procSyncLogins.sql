SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-08-29
Description:	Reports on differences between logins/roles/permissions on two nodes of an AG group
2018-04-04		DHB Moved to EventMonitoring	

Modified:		
2018-12-05	Bruce Baum - TFS 32353:Create TS360DBA email distribution list

=============================================
*/
CREATE PROCEDURE [dbo].[procSyncLogins]
	@Node2 SYSNAME --other server in linked group
	, @GenerateResults BIT = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @Node1			SYSNAME = @@SERVERNAME
			, @sql			NVARCHAR(max)
			, @LoginsHTML	NVARCHAR(MAX)
			, @RolesHTML	NVARCHAR(MAX)
			, @PermissionsHTML	NVARCHAR(MAX)
			, @ResultsFound	BIT = 0
			, @RecordCount	INT
			, @BodyHTML		NVARCHAR(MAX);

	DECLARE @Recipients NVARCHAR(MAX) = N'TS360DBAs@baker-taylor.com';

	DECLARE @primaryLogins TABLE (
		[name]					sysname NOT NULL
		, [sid]					varbinary(85) NOT NULL
		, servername			sysname NOT NULL
		, [type]				char(1) NOT NULL
		, is_disabled			bit NULL
		, default_database_name	sysname NULL
		, default_language_name	sysname NULL
		, is_policy_checked		bit NULL
		, is_expiration_checked	bit NULL
		, password_hash			varbinary(256) NULL
		, error					varchar(max)
	);

	--query for local server
	INSERT INTO @primaryLogins ([name], [sid], servername, [type], is_disabled, default_database_name, default_language_name, is_policy_checked, is_expiration_checked, password_hash)
	SELECT	sp.[name], sp.[sid], @@SERVERNAME, sp.[type], sp.is_disabled, sp.default_database_name
			, sp.default_language_name, l.is_policy_checked, l.is_expiration_checked, l.password_hash
	FROM	master.sys.server_principals AS sp
	LEFT JOIN master.sys.sql_logins AS l ON sp.[sid]=l.[sid]
	WHERE	sp.[type] IN ('U', 'G', 'S') 
	AND		sp.[name] NOT LIKE 'NT Service\%' 
	AND		sp.[name] NOT IN ('NT AUTHORITY\SYSTEM')

	--go after secondary server
	SET @sql=N'
	SELECT	sp.[name], sp.[sid], ''' + @Node2 + ''', sp.[type], sp.is_disabled, sp.default_database_name
			, sp.default_language_name, l.is_policy_checked, l.is_expiration_checked, l.password_hash
	FROM	[' + @Node2 + '].master.sys.server_principals AS sp
	LEFT JOIN [' + @Node2 + '].master.sys.sql_logins AS l ON sp.[sid]=l.[sid]
	WHERE	sp.[type] IN (''U'', ''G'', ''S'') 
	AND		sp.[name] NOT LIKE ''NT Service\%'' 
	AND		sp.[name] NOT IN (''NT AUTHORITY\SYSTEM'')';

	INSERT INTO @primaryLogins ([name], [sid], servername, [type], is_disabled, default_database_name, default_language_name, is_policy_checked, is_expiration_checked, password_hash)
	EXECUTE master.sys.sp_executesql @sql;

	--- These are the server roles on the primary replica.
	DECLARE @primaryRoles TABLE (
		[sid]			varbinary(85) NOT NULL
		, [name]		sysname NOT NULL
		, servername	sysname NOT NULL
		, error			varchar(max)
	);

	--local node
	INSERT INTO @primaryRoles ([sid], [name], servername)
	SELECT	sr.[sid], sr.[name], @@SERVERNAME
	FROM	master.sys.server_principals AS sr
	WHERE	sr.[type]='R';

	--other node
	SET @sql=N'
	SELECT	sr.[sid], sr.[name], ''' + @Node2 + '''
	FROM	['+@Node2+'].master.sys.server_principals AS sr
	WHERE	sr.[type]=''R''';

	INSERT INTO @primaryRoles ([sid], [name], servername)
	EXECUTE master.sys.sp_executesql @sql;

	--- These are the role members of the server roles on
	--- the primary replica.
	DECLARE @primaryMembers TABLE (
		role_sid			varbinary(85) NOT NULL
		, member_sid		varbinary(85) NOT NULL
		, servername		sysname
		, error				varchar(max)
	);

	--local node
	INSERT INTO @primaryMembers (role_sid, member_sid, servername)
	SELECT	r.[sid], m.[sid], @@SERVERNAME
	FROM	master.sys.server_principals AS r
	JOIN	master.sys.server_role_members AS rm 
	ON		r.principal_id=rm.role_principal_id
	JOIN	master.sys.server_principals AS m 
	ON		rm.member_principal_id=m.principal_id;

	SET @sql=N'
	SELECT	r.[sid], m.[sid], ''' + @Node2 + '''
	FROM	['+@Node2+N'].master.sys.server_principals AS r
	JOIN	['+@Node2+N'].master.sys.server_role_members AS rm 
	ON		r.principal_id=rm.role_principal_id
	JOIN	['+@Node2+N'].master.sys.server_principals AS m 
	ON		rm.member_principal_id=m.principal_id';

	INSERT INTO @primaryMembers (role_sid, member_sid, servername)
	EXECUTE master.sys.sp_executesql @sql;

	--- These are the server-level permissions on the
	--- primary replica.
	DECLARE @primaryPermissions TABLE (
		state_desc			nvarchar(120) NOT NULL,
		[permission_name]	nvarchar(256) NOT NULL,
		principal_name		sysname NOT NULL
		, servername		sysname
		, error				VARCHAR(MAX)
		, principal_sid		VARBINARY(85)
	);

	--local
	INSERT INTO @primaryPermissions (state_desc, [permission_name], principal_name, servername, principal_sid)
	SELECT	p.state_desc, p.[permission_name], sp.[name], @@SERVERNAME, sp.sid
	FROM	master.sys.server_permissions AS p
	JOIN	master.sys.server_principals AS sp 
	ON		p.grantee_principal_id=sp.principal_id
	WHERE	p.class=100;

	SET @sql=N'
	SELECT	p.state_desc, p.[permission_name], sp.[name], ''' + @Node2 + ''', sp.sid
	FROM	['+@Node2+'].master.sys.server_permissions AS p
	JOIN	['+@Node2+'].master.sys.server_principals AS sp 
	ON		p.grantee_principal_id=sp.principal_id
	WHERE	p.class=100';

	INSERT INTO @primaryPermissions (state_desc, [permission_name], principal_name, servername, principal_sid)
	EXECUTE master.sys.sp_executesql @sql;

	--Logins
	WITH Node1 AS
	(
		SELECT	* 
		FROM	@primaryLogins 
		WHERE	servername = @Node1 
		AND		name NOT IN ('##MS_PolicyEventProcessingLogin##')
	), 
	Node2 AS
	(
		SELECT	* 
		FROM	@primaryLogins 
		WHERE	servername = @Node2 
		AND		name NOT IN ('##MS_PolicyEventProcessingLogin##')
	)

	SELECT	CASE WHEN Node1.sid IS NULL THEN 'Login not on Node1' ELSE CASE WHEN Node2.sid IS NULL THEN 'Login not on Node2' ELSE NULL END END as Error
			, COALESCE(Node1.name, node2.name) as Name
			, COALESCE(Node1.sid, node2.sid) as Sid
			, COALESCE(Node1.servername, node2.servername) as servername
			, COALESCE(Node1.type, node2.type) as type
			, COALESCE(Node1.is_disabled, node2.is_disabled) as IsDisabled
			, COALESCE(Node1.default_database_name, node2.default_database_name) as DefaultDB
			, COALESCE(Node1.default_language_name, node2.default_language_name) as DefaultLanguage
			, COALESCE(Node1.is_policy_checked, node2.is_policy_checked) as IsPolicyChecked
			, COALESCE(Node1.is_expiration_checked, node2.is_expiration_checked) as IsExpirationChecked
			, COALESCE(Node1.password_hash, node2.password_hash) as PasswordHash
	INTO	#Logins
	FROM	Node1
	FULL OUTER JOIN Node2
	ON		Node1.sid = Node2.sid
	WHERE	(Node1.sid IS NULL OR Node2.sid IS NULL);

	SELECT @RecordCount = @@ROWCOUNT;
	--set the flag so we know we found something
	IF	@RecordCount > 0
		SET @ResultsFound = 1;

	--Roles
	WITH Node1 as
	(
		SELECT	M.*, L.name as LoginName, R.name as RoleName
		FROM	@primaryMembers AS M
		JOIN	@primaryLogins AS L
		ON		M.member_sid = L.sid
		AND		M.servername = L.servername
		JOIN	@primaryRoles AS R
		ON		M.role_sid = R.sid
		AND		M.servername = R.servername
		WHERE	M.servername = @Node1
	)
	, Node2 AS
	(
		SELECT	M.*, L.name as LoginName, R.name as RoleName
		FROM	@primaryMembers AS M
		JOIN	@primaryLogins AS L
		ON		M.member_sid = L.sid
		AND		M.servername = L.servername
		JOIN	@primaryRoles AS R
		ON		M.role_sid = R.sid
		AND		M.servername = R.servername
		WHERE	M.servername = @Node2
	)

	SELECT	CASE WHEN Node1.role_sid IS NULL THEN 'Login not assigned to server role on Node1' ELSE 
			CASE WHEN Node2.role_sid IS NULL THEN 'Login not assigned to server role on Node2' ELSE NULL END END as Error
			, COALESCE(Node1.role_sid, Node2.role_sid) as RoleSID
			, COALESCE(Node1.member_sid, Node2.member_sid) as MemberSID
			, COALESCE(Node1.servername, Node2.servername) as ServerName
			, COALESCE(Node1.LoginName, Node2.loginName) as LoginName
			, COALESCE(Node1.RoleName, Node2.RoleName) as RoleName
	INTO	#Roles
	FROM	Node1
	FULL OUTER JOIN Node2
	ON		Node1.role_sid = Node2.role_sid
	AND		Node1.member_sid = Node2.member_sid
	WHERE	(Node1.role_sid IS NULL OR Node2.role_sid IS NULL);

	SELECT @RecordCount = @@ROWCOUNT;
	--set the flag so we know we found something
	IF	@RecordCount > 0
		SET @ResultsFound = 1;

	--permissions
	WITH Node1 AS
	(
		SELECT	state_desc, permission_name, principal_name, servername, principal_sid
		FROM	@primaryPermissions
		WHERE	servername = @Node1
		AND		principal_name NOT LIKE '##%'
	)
	, Node2 AS
	(
		SELECT	state_desc, permission_name, principal_name, servername, principal_sid
		FROM	@primaryPermissions
		WHERE	servername = @Node2
		AND		principal_name NOT LIKE '##%'
	)

	SELECT	CASE WHEN Node1.principal_sid IS NULL THEN 'Permission not assigned to server role on Node1' ELSE 
			CASE WHEN Node2.principal_sid IS NULL THEN 'Permission not assigned to server role on Node2' ELSE NULL END END as Error
			, COALESCE(Node1.state_desc, Node2.state_desc) as StateDesc
			, COALESCE(Node1.permission_name, Node2.permission_name) as PermissionState
			, COALESCE(Node1.principal_name, Node2.principal_name) as PrincipalName
			, COALESCE(Node1.servername, Node2.servername) as ServerName
	INTO	#Permissions
	FROM	Node1
	FULL OUTER JOIN Node2
	ON		Node1.state_desc = Node2.state_desc
	AND		Node1.permission_name = Node2.permission_name
	AND		Node1.principal_sid = Node2.principal_sid
	WHERE	Node1.principal_sid IS NULL
	OR		Node2.principal_sid IS NULL
	ORDER BY node1.principal_name, node2.principal_name;

	SELECT @RecordCount = @@ROWCOUNT
	--set the flag so we know we found something
	IF	@RecordCount > 0
		SET @ResultsFound = 1

	IF @GenerateResults = 1 AND @ResultsFound = 0
		SELECT 'No discrepancies found';

	ELSE IF @GenerateResults = 1 AND @ResultsFound = 1
	BEGIN
		SELECT * FROM #Logins ORDER BY Name, servername
		SELECT * FROM #Roles ORDER BY RoleName, LoginName, ServerName
		SELECT * FROM #Permissions ORDER BY PrincipalName, ServerName
	END
	ELSE IF @GenerateResults = 0 AND @ResultsFound = 1
	BEGIN
		SET @LoginsHTML = 
			N'<H1>TS360 Login Comparison Report</H1>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Login Name</th>' +
			N'<th>Error</th>' + 
			N'<th>Sid</th>' +
			N'<th>ServerName</th>' +
			N'<th>Type</th>' +
			N'</tr>' +
			CAST ((
				SELECT	td = Name, ''
						, td = Error, ''
						, td = Sid, ''
						, td = servername, ''
						, td = type, ''
				FROM	#Logins
				ORDER BY Name, servername
				FOR XML PATH('tr'), TYPE) AS NVARCHAR(MAX)) +
			N'</table>';

		SET @RolesHTML = 
			N'<H1>TS360 Roles Comparison Report</H1>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Error</th>' +
			N'<th>Role Name</th>' + 
			N'<th>LoginName</th>' +
			N'<th>ServerName</th>' +
			N'</tr>' +
			CAST ((
				SELECT	td = Error, ''
						, td = RoleName, ''
						, td = LoginName, ''
						, td = ServerName, ''
				FROM	#Roles
				ORDER BY RoleName, LoginName, ServerName
				FOR XML PATH('tr'), TYPE) AS NVARCHAR(MAX)) +
			N'</table>';

		SET @PermissionsHTML = 
			N'<H1>TS360 Permissions Comparison Report</H1>' +
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Error</th>' +
			N'<th>StateDesc</th>' + 
			N'<th>PermissionState</th>' +
			N'<th>PrincipalName</th>' +
			N'<th>ServerName</th>' +
			N'</tr>' +
			CAST ((
				SELECT	td = Error, ''
						, td = StateDesc, ''
						, td = PermissionState, ''
						, td = PrincipalName, ''
						, td = ServerName, ''
				FROM	#Permissions
				ORDER BY StateDesc, PermissionState, PrincipalName, ServerName
				FOR XML PATH('tr'), TYPE) AS NVARCHAR(MAX)) +
			N'</table>';

		SET @BodyHTML = ISNULL(@LoginsHTML, '') + ISNULL(@RolesHTML, '') + ISNULL(@PermissionsHTML, '')

		--Send email 
		EXEC msdb.dbo.sp_send_dbmail
			 @recipients = @recipients
			, @reply_to = 'NoReply@baker-taylor.com'
			, @subject = 'TS360 Login Mismatches'
			, @body = @BodyHTML
			, @body_format = 'HTML'
			, @importance = 'high';
	END

	DROP TABLE #Logins
	DROP TABLE #Roles
	DROP TABLE #Permissions
END
GO
