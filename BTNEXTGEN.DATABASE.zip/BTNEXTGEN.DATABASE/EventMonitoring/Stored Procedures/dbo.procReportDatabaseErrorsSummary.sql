SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-05-11
Description:	Hourly summary of deadlocks, blocking, and IO errors

Modified:		
2018-04-12 DHB  Upgraded procedure to support 2016 Event Monitoring
2020-04-14	KG	Modified to grab information from logged tables
				This only gets called when the logging job runs at the top of the hour
				Changed also to report a rolling 24 hour window
				Also added QA/Prod check for serverurl
=============================================
*/
CREATE PROCEDURE [dbo].[procReportDatabaseErrorsSummary]
AS
BEGIN
	SET NOCOUNT ON;

	--Variables
	DECLARE @Recipients VARCHAR(MAX) 
			, @ServerEnvironment VARCHAR(255)

	SELECT	@ServerEnvironment = ServerEnvironment
	FROM	BTAdmin.dbo.ServerURL

	IF @ServerEnvironment LIKE 'DEV%'
		SET @Recipients = 'kelly.gulutz@baker-taylor.com'

	IF @ServerEnvironment = 'QA'
		SET @Recipients = 'kelly.gulutz@baker-taylor.com;dan.johnson@baker-taylor.com;ivor.addo@baker-taylor.com;cerisa.meunier@baker-taylor.com;Ralph.McKewen@baker-taylor.com;tdo24@csc.com;DL-360Tier2Support@baker-taylor.com'

	IF @ServerEnvironment = 'Production'
		SET @Recipients = 'DL-TS360-Tier-3-Support@baker-taylor.com;dan.johnson@baker-taylor.com;ivor.addo@baker-taylor.com;DL-360Tier2Support@baker-taylor.com'

	DECLARE @BlockingHTML NVARCHAR(MAX)
			, @DeadlocksHTML NVARCHAR(MAX)
			, @BodyHTML NVARCHAR(MAX)
			, @BlockingCount INT = 0
			, @DeadlockCount INT = 0
			, @CurrentDate DATETIME = GETDATE()

	--DECLARE @IOErrorTable TABLE (Instance VARCHAR(50), EventDate VARCHAR(20), IOEvents INT)
	--DECLARE @LastIOEvent TABLE(Server VARCHAR(25), LastIOEvent DATETIME)
		
	--BLOCKING REPORT  **********************************************************************************
	DECLARE	@ReportDateTime Datetime 
	SELECT	@ReportDateTime = DATEADD(hh, -1, GETDATE()) 

	DECLARE	@Event TABLE(
			EventTime			DateTime,
			[Blocked Query]		varchar(500),
			[Blocking Query]	varchar(500),
			[Database Name]		varchar(50),
			[Duration (ms)]		bigint,
			EventHour			DateTime)

	INSERT	@Event(EventTime, [Blocked Query], [Blocking Query], [Database Name], [Duration (ms)])
	SELECT	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), EventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) as [EventTime],
			EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocked-process/process/inputbuf)[1]','SYSNAME') AS [Blocked Query],
			EventXML.Data.value('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocking-process/process/inputbuf)[1]','SYSNAME') AS [Blocking Query],
			EventXML.Data.value('(/event/data[@name=''database_name'']/value)[1]','SYSNAME') AS [Database Name],
			EventXML.Data.value('(/event/data[@name=''duration'']/value)[1]','BIGINT')/1000 AS [Duration (ms)]
		FROM	(
				SELECT  CONVERT(XML, event_data) Data
				FROM	sys.fn_xe_file_target_read_file(N'BlockingMonitor*.xel', NULL, NULL, NULL) 
				WHERE   OBJECT_NAME = 'blocked_process_report') EventXML
		WHERE	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), EventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) >= @CurrentDate

	DECLARE	@EventRollup TABLE(
		EventTime			DateTime,
		[Duration (ms)]		bigint,
		EventHour			DateTime)

		INSERT		@EventRollup(EventTime, [Duration (ms)])
		SELECT		EventTime,
					MAX([Duration (ms)])	as [Duration (ms)]

		FROM		@Event
		WHERE		[Database Name] NOT IN ('BTAdmin', 'CSCDBA', 'MSDB')
		GROUP BY	EventTime,
					[Blocked Query],
					[Blocking Query]

		UPDATE	@EventRollup
		SET		EventHour = CAST(
				CAST(DATEPART(yy, EventTime) as varchar(4)) + '-' +
				CAST(DATEPART(mm, EventTime) as varchar(2))  + '-' +
				CAST(DATEPART(dd, EventTime) as varchar(2))  + ' ' +
				CAST(DATEPART(hh, EventTime) as varchar(2)) + --':00:00'
				CASE WHEN DATEPART(MINUTE, EventTime) < 30 THEN ':00' ELSE ':30' END
				as datetime )


	CREATE	TABLE	#Blocking(
			EventHour	varchar(50),
			WaitTime	BIGINT)
		
	INSERT	#Blocking(
			EventHour,
			WaitTime)

	SELECT	EventHour,
			[Duration (ms)]
	FROM	@EventRollup
	SELECT @BlockingHTML = 
		N'<H2>Blocking breakdown</H2>' +
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Event Hour</th>' +
		N'<th>Count</th>' +
		N'<th>Total Wait</th>' +
		N'</tr>' +
	CAST(
	(SELECT		td = EventHour
				, SPACE(0)
				, td = COUNT(1)
				, SPACE(0)
				, td = SUM(WaitTime)
	FROM		#Blocking
	GROUP BY	EventHour
	ORDER BY	CAST(EventHour AS DATETIME) DESC
	FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
	+ N'</table>' 

	SELECT @BlockingCount = COUNT(*) FROM #Blocking

	DROP TABLE #Blocking

	--DEADLOCK REPORT  ****************************************************************************
	DECLARE	@DeadlockDateTimes TABLE(
		RawDate	datetime,
		ProcessedDate	Datetime)

	INSERT	@DeadlockDateTimes(RawDate)

	SELECT	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2'))  as CreateDate
	FROM	(
			SELECT  CONVERT(XML, event_data) Data
			FROM	sys.fn_xe_file_target_read_file(N'DeadlockMonitor*.xel', NULL, NULL, NULL) 
			WHERE   OBJECT_NAME = 'xml_deadlock_report') DeadlockEventXML
	WHERE	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) >= @CurrentDate

	UPDATE	@DeadlockDateTimes 
	SET		ProcessedDate = CAST(
			CAST(DATEPART(yy, RawDate) as varchar(4)) + '-' +
			CAST(DATEPART(mm, RawDate) as varchar(2))  + '-' +
			CAST(DATEPART(dd, RawDate) as varchar(2))  + ' ' +
			CAST(DATEPART(hh, RawDate) as varchar(2)) +  
			CASE WHEN DATEPART(MINUTE, RawDate) < 30 THEN ':00' ELSE ':30' END AS DATETIME)


	SELECT @DeadlocksHTML = 
		N'<H2>Deadlock breakdown </H2>' +
		N'<table border="1">' +
		N'<tr>' + 
		N'<th>Event Hour</th>' +
		N'<th>Count</th>' +
		N'</tr>' +
	CAST(
	(SELECT		td = ProcessedDate, 
				SPACE(0), 
				td = COUNT(1)
	FROM		@DeadlockDateTimes
	GROUP BY	ProcessedDate
	ORDER BY	ProcessedDate DESC
	FOR XML PATH('tr'), TYPE) as NVARCHAR(MAX))
	+ N'</table>' 


	SELECT	@DeadlockCount = COUNT(*) 
	FROM	@DeadlockDateTimes 


	SELECT @BlockingHTML = '<p><H1>Blocking count for today: ' + CAST(@BlockingCount AS VARCHAR(10)) + '</H1></p>' + ISNULL(@BlockingHTML, '') 
	SELECT @DeadlocksHTML = '<p><H1>Deadlock count for today: ' + CAST(@DeadlockCount AS VARCHAR(10)) + '</H1></p>' + ISNULL(@DeadlocksHTML, '') 
		
	SELECT @BodyHTML = '<p>' + @BlockingHTML + '</p><p>' + @DeadlocksHTML + '</p>'

	--Send email
	DECLARE @ReplyTo VARCHAR(100)
			, @Subject VARCHAR(100)

	SELECT @ReplyTo = REPLACE(@ServerEnvironment, ' ', '') + 'NoReply@baker-taylor.com'
			, @Subject = 'TS360 ' + @ServerEnvironment + ': Database Error Summary'

	EXEC msdb.dbo.sp_send_dbmail
			@recipients = @recipients
		, @reply_to = @ReplyTo
		, @subject = @Subject
		, @body = @BodyHTML 
		, @body_format = 'HTML'
END
GO
