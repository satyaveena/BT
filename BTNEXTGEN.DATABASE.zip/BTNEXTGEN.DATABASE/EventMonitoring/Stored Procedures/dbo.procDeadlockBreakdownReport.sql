SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-01-24
Description:	Emails a report of the deadlock breakdown from the previous day

Modification:	2018-04-12 DHB  Altered procedure to support 2016 extended events

exec [dbo].[procDeadlockBreakdownReport]
=============================================
*/
CREATE PROCEDURE [dbo].[procDeadlockBreakdownReport]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CheckDate DATE = DATEADD(DAY, -1, GETDATE())
			, @Today DATE = GETDATE()
			, @Recipients VARCHAR(MAX) = 'dan.johnson@baker-taylor.com;ivor.addo@baker-taylor.com;kelly.gulutz@baker-taylor.com;cerisa.meunier@baker-taylor.com'
			, @BodyHTML NVARCHAR(MAX)
			, @DeadlockCount INT = 0

	DECLARE @Deadlocks TABLE
	(
		EventDate	datetime
		, KilledSP	VARCHAR(MAX)
		, KillingSP	VARCHAR(MAX)
		, KilledServer VARCHAR(50)
		, KillingServer VARCHAR(50)
	)
	INSERT INTO @Deadlocks
	SELECT	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'varchar(50)')) AS [create_date],
			DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/executionStack/frame/@procname)[1]', 'nvarchar(max)') AS KilledSP,
			DeadlockEventXML.Data.value('(//process[2]/executionStack/frame/@procname)[1]', 'nvarchar(max)') AS KillingSP,
			DeadlockEventXML.Data.value('(//process[@id[//victim-list/victimProcess[1]/@id]]/@hostname)[1]', 'nvarchar(max)') AS KilledServer,
			DeadlockEventXML.Data.value('(//process[2]/@hostname)[1]', 'nvarchar(max)') AS KillingServer
	FROM	(
			SELECT  CONVERT(XML, event_data) Data
			FROM	sys.fn_xe_file_target_read_file(N'DeadlockMonitor*.xel', NULL, NULL, NULL) 
			WHERE   OBJECT_NAME = 'xml_deadlock_report') DeadlockEventXML
	WHERE	DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) >= @CheckDate
	AND		DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), DeadlockEventXML.Data.value('(event/@timestamp)[1]', 'datetime2')) < @Today
	ORDER BY 1 DESC

	SELECT @DeadlockCount = @@ROWCOUNT

	IF @DeadlockCount  >  0
	BEGIN
		SELECT @BodyHTML = 
			N'<H2>Deadlock breakdown</H2>' + 
			N'<table border="1">' +
			N'<tr>' + 
			N'<th>Deadlock DateTime</th>' +
			N'<th>Killed SP</th>' +
			N'<th>Killing SP</th>' +
			N'<th>Killed Server</th>' +
			N'<th>Killing Server</th>' +
			N'</tr>' +
		CAST(
		(SELECT
			td = CAST(DATEPART(yyyy, EventDate) as char(4)) 
		+ '-' + CAST(DATEPART(MONTH, EventDate) as varchar(2))
		+ '-' + CAST(DATEPART(dd, EventDate) as varchar(2))
		+ ' ' + CAST(DATEPART(HH, EventDate) as varchar(2))
		+ ':' + CAST(DATEPART(MINUTE, EventDate) as varchar(2))
			, SPACE(1)
			, td = ISNULL(KilledSP, SPACE(1))
			, SPACE(1)
			, td = ISNULL(KillingSP, SPACE(1))
			, SPACE(1)
			, td = ISNULL(KilledServer, SPACE(1))
			, SPACE(1)
			, TD = ISNULL(KillingServer, SPACE(1))
		FROM @Deadlocks
		ORDER BY EventDate
		FOR XML PATH ('tr'), TYPE) AS NVARCHAR(MAX))
		+ '</table>'
	END
	ELSE
	BEGIN
		SELECT @BodyHTML = '<H2>No deadlocks for the previous day</H2>'
	END

	EXEC msdb.dbo.sp_send_dbmail
		@Body = @BodyHTML
		, @Recipients  = @Recipients
		, @reply_to = 'ProductionNoReply@baker-taylor.com'
		, @subject = 'TS360 Production: Deadlock Breakdown Report'
		, @body_format = 'HTML'

END
GO
