SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[procSQLAgentJobQuery]
/*****************************************************************************************
DEVELOPER:		Bruce Baum
DEV DATE:		2018-09
CALLED FROM:	UI
OVERVIEW:		TFS 31224 - Return Statistics about SQL Agent Jobs

MODIFICATION HISTORY:		

****************************************************************************************/
AS

BEGIN

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY

Declare @Job_Result_Set Table ( JobID					uniqueidentifier NOT NULL
							  , JobName					Sysname
							  ,	JobDescription			nvarchar(512)
							  , JobEnabled				varchar(3)
							  , JobFrequency			varchar(30)
							  , JobStartDate			Date
							  , JobStartTime			varchar(8)
							  , MaxElapsedSec			int
							  , MaxDuration				varchar(8)
							  , AvgElapsedSec			int
							  , AvgDuration				varchar(8)
							  , LastElapsedSec			int
							  , ThresholdElapsedSec		int
							  , LastDuration			varchar(8)
							  , Subday_Freq				varchar(16)
							  , JobStatus				varchar(16)
							  , JobOutcome_Msg			nvarchar(4000)
							  , JobStatusSortBy			int
							  , ResponsiblePartyName	nvarchar(200)
							  , ResponsiblePartyPhone	nvarchar(40)
							  , ResponsiblePartyEMail	nvarchar(100)
							  )

Insert into @Job_Result_Set (JobID, JobName, JobDescription, JobEnabled, JobFrequency, JobStartDate, JobStartTime,
							 MaxElapsedSec, MaxDuration, AvgElapsedSec, AvgDuration, LastElapsedSec, LastDuration,
							 Subday_Freq, JobStatus, JobOutcome_Msg, JobStatusSortBy)
SELECT msdb.dbo.sysjobs.job_id AS 'JobID', 
	   msdb.dbo.sysjobs.Name AS 'Job Name', Description,
   'Job Enabled' = CASE msdb.dbo.sysjobs.Enabled
      WHEN 1 THEN 'Yes'
      WHEN 0 THEN 'No'
   END,
   'Frequency' = CASE msdb.dbo.sysschedules.freq_type
      WHEN 1 THEN 'Once'
      WHEN 4 THEN 'Daily'
      WHEN 8 THEN 'Weekly'
      WHEN 16 THEN 'Monthly'
      WHEN 32 THEN 'Monthly relative'
      WHEN 64 THEN 'When SQLServer Agent starts'
   END, 
    'Start Date' = CASE run_date
      WHEN 0 THEN null
      ELSE
      substring(convert(varchar(15),run_date),1,4) + '/' + 
      substring(convert(varchar(15),run_date),5,2) + '/' + 
      substring(convert(varchar(15),run_date),7,2)
   END,
   'Start Time' = CASE len(run_time)
      WHEN 1 THEN cast('00:00:0' + right(run_time,2) as char(8))
      WHEN 2 THEN cast('00:00:' + right(run_time,2) as char(8))
      WHEN 3 THEN cast('00:0' 
            + Left(right(run_time,3),1)  
            +':' + right(run_time,2) as char (8))
      WHEN 4 THEN cast('00:' 
            + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
      WHEN 5 THEN cast('0' 
            + Left(right(run_time,5),1) 
            +':' + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
      WHEN 6 THEN cast(Left(right(run_time,6),2) 
            +':' + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
   END,

	Max_Total_Seconds AS 'Max Elapsed Seconds', 
	RIGHT('0' + CAST(Max_Total_Seconds / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((Max_Total_Seconds / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(Max_Total_Seconds % 60 AS VARCHAR),2) AS Max_Duration, 

    Avg_Total_Seconds AS 'Avg Elapsed Seconds', 
	RIGHT('0' + CAST(Avg_Total_Seconds / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((Avg_Total_Seconds / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(Avg_Total_Seconds % 60 AS VARCHAR),2) AS Avg_Duration, 
	
	Last_Total_Seconds AS 'Last Elapsed Seconds',
	RIGHT('0' + CAST(Last_Total_Seconds / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((Last_Total_Seconds / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(Last_Total_Seconds % 60 AS VARCHAR),2) AS Last_Duration,
  
    CASE(msdb.dbo.sysschedules.freq_subday_interval)
      WHEN 0 THEN 'Once'
      ELSE cast('Every ' 
            + right(msdb.dbo.sysschedules.freq_subday_interval,2) 
            + ' '
            +     CASE(msdb.dbo.sysschedules.freq_subday_type)
                     WHEN 1 THEN 'Once'
                     WHEN 4 THEN 'Minutes'
                     WHEN 8 THEN 'Hours'
                  END as char(16))
    END as 'Subday Frequency',
	case last_run_outcome
	when 0 then 'Failed'  
	when 1 then 'Successful'  
	when 2 then 'Retry' 
	when 3 then 'Cancelled'  
	when 4 then 'In Progress'
	else 'UnKnown'
	end as Job_Execution_Status,
	last_outcome_message, 
	case last_run_outcome
	when 0 then 1  
	when 1 then 6  
	when 2 then 4 
	when 3 then 2  
	when 4 then 3
	else 5
	end as JobStatusSortBy
FROM msdb.dbo.sysjobs with (NoLock)
LEFT OUTER JOIN msdb.dbo.sysjobschedules with (NoLock)
ON msdb.dbo.sysjobs.job_id = msdb.dbo.sysjobschedules.job_id
INNER JOIN msdb.dbo.sysschedules with (NoLock) ON msdb.dbo.sysjobschedules.schedule_id = msdb.dbo.sysschedules.schedule_id 
join msdb.dbo.sysjobservers s with (NoLock) on msdb.dbo.sysjobs.job_id = s.job_id

LEFT OUTER JOIN (SELECT job_id, max (((run_duration/10000 * 3600) +				-- hrs as seconds
									  (run_duration/100%100 * 60) +				-- min as seconds
									   run_duration%100)) as Max_Total_Seconds  -- seconds
				FROM msdb.dbo.sysjobhistory with (NoLock)
				where step_id=0 
				GROUP BY job_id) Q1
ON msdb.dbo.sysjobs.job_id = Q1.job_id

LEFT OUTER JOIN (SELECT job_id, avg (((run_duration/10000 * 3600) +				-- hrs as seconds
									  (run_duration/100%100 * 60) +				-- min as seconds
									   run_duration%100)) as Avg_Total_Seconds  -- seconds
      FROM msdb.dbo.sysjobhistory with (NoLock)
	  where step_id=0 
      GROUP BY job_id) Q2
ON msdb.dbo.sysjobs.job_id = Q2.job_id

LEFT OUTER JOIN (SELECT run_date, run_time, job_id,  
									(((run_duration/10000 * 3600) +					-- hrs as seconds
									  (run_duration/100%100 * 60) +					-- min as seconds
									   run_duration%100))  as Last_Total_Seconds  	-- seconds 
      FROM msdb.dbo.sysjobhistory with (NoLock)
	  where step_id=0 and instance_id in (select max(instance_id) from msdb..sysjobhistory with (NoLock) GROUP BY job_id)
      ) Q3
ON msdb.dbo.sysjobs.job_id = Q3.job_id

WHERE Next_run_time = 0

UNION

SELECT msdb.dbo.sysjobs.job_id AS 'JobID', 
	   msdb.dbo.sysjobs.Name AS 'Job Name', Description,
   'Job Enabled' = CASE msdb.dbo.sysjobs.Enabled
      WHEN 1 THEN 'Yes'
      WHEN 0 THEN 'No'
   END,
   'Frequency' = CASE msdb.dbo.sysschedules.freq_type
      WHEN 1 THEN 'Once'
      WHEN 4 THEN 'Daily'
      WHEN 8 THEN 'Weekly'
      WHEN 16 THEN 'Monthly'
      WHEN 32 THEN 'Monthly relative'
      WHEN 64 THEN 'When SQLServer Agent starts'
   END, 
   'Start Date' = CASE run_date
      WHEN 0 THEN null
      ELSE
      substring(convert(varchar(15),run_date),1,4) + '/' + 
      substring(convert(varchar(15),run_date),5,2) + '/' + 
      substring(convert(varchar(15),run_date),7,2)
   END,
   'Start Time' = CASE len(run_time)
      WHEN 1 THEN cast('00:00:0' + right(run_time,2) as char(8))
      WHEN 2 THEN cast('00:00:' + right(run_time,2) as char(8))
      WHEN 3 THEN cast('00:0' 
            + Left(right(run_time,3),1)  
            +':' + right(run_time,2) as char (8))
      WHEN 4 THEN cast('00:' 
            + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
      WHEN 5 THEN cast('0' 
            + Left(right(run_time,5),1) 
            +':' + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
      WHEN 6 THEN cast(Left(right(run_time,6),2) 
            +':' + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
   END,

	Max_Total_Seconds AS 'Max Elapsed Seconds', 
	RIGHT('0' + CAST(Max_Total_Seconds / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((Max_Total_Seconds / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(Max_Total_Seconds % 60 AS VARCHAR),2) AS Max_Duration, 

    Avg_Total_Seconds AS 'Avg Elapsed Seconds', 
	RIGHT('0' + CAST(Avg_Total_Seconds / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((Avg_Total_Seconds / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(Avg_Total_Seconds % 60 AS VARCHAR),2) AS Avg_Duration, 
	
	Last_Total_Seconds AS 'Last Elapsed Seconds',
	RIGHT('0' + CAST(Last_Total_Seconds / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((Last_Total_Seconds / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(Last_Total_Seconds % 60 AS VARCHAR),2) AS Last_Duration,
  
    CASE(msdb.dbo.sysschedules.freq_subday_interval)
      WHEN 0 THEN 'Once'
      ELSE cast('Every ' 
            + right(msdb.dbo.sysschedules.freq_subday_interval,2) 
            + ' '
            +     CASE(msdb.dbo.sysschedules.freq_subday_type)
                     WHEN 1 THEN 'Once'
                     WHEN 4 THEN 'Minutes'
                     WHEN 8 THEN 'Hours'
                  END as char(16))
    END as 'Subday Frequency',
	case last_run_outcome
	when 0 then 'Failed'  
	when 1 then 'Successful'  
	when 2 then 'Retry' 
	when 3 then 'Cancelled'  
	when 4 then 'In Progress'
	else 'UnKnown'
	end as Job_Execution_Status,
	last_outcome_message, 
	case last_run_outcome
	when 0 then 1  
	when 1 then 6  
	when 2 then 4 
	when 3 then 2  
	when 4 then 3
	else 5
	end as JobStatusSortBy
FROM msdb.dbo.sysjobs with (NoLock)
LEFT OUTER JOIN msdb.dbo.sysjobschedules with (NoLock) ON msdb.dbo.sysjobs.job_id = msdb.dbo.sysjobschedules.job_id
INNER JOIN msdb.dbo.sysschedules with (NoLock) ON msdb.dbo.sysjobschedules.schedule_id = msdb.dbo.sysschedules.schedule_id 
join msdb.dbo.sysjobservers s with (NoLock) on msdb.dbo.sysjobs.job_id = s.job_id

LEFT OUTER JOIN (SELECT job_id, max (((run_duration/10000 * 3600) +				-- hrs as seconds
									  (run_duration/100%100 * 60) +				-- min as seconds
									   run_duration%100)) as Max_Total_Seconds  -- seconds
				FROM msdb.dbo.sysjobhistory with (NoLock)
				where step_id=0 
				GROUP BY job_id) Q1
ON msdb.dbo.sysjobs.job_id = Q1.job_id

LEFT OUTER JOIN (SELECT job_id, avg (((run_duration/10000 * 3600) +				-- hrs as seconds
									  (run_duration/100%100 * 60) +				-- min as seconds
									   run_duration%100)) as Avg_Total_Seconds  -- seconds
      FROM msdb.dbo.sysjobhistory with (NoLock)
	  where step_id=0 
      GROUP BY job_id) Q2
ON msdb.dbo.sysjobs.job_id = Q2.job_id

LEFT OUTER JOIN (SELECT run_date, run_time, job_id,  
									(((run_duration/10000 * 3600) +					-- hrs as seconds
									  (run_duration/100%100 * 60) +					-- min as seconds
									   run_duration%100))  as Last_Total_Seconds  	-- seconds 
      FROM msdb.dbo.sysjobhistory with (NoLock)
	  where step_id=0 and instance_id in (select max(instance_id) from msdb..sysjobhistory with (NoLock) GROUP BY job_id)
      ) Q3
ON msdb.dbo.sysjobs.job_id = Q3.job_id

WHERE Next_run_time <> 0

Update	rs
		Set ThresholdElapsedSec		= t.ThresholdDuration,
			ResponsiblePartyName	= t.ResponsiblePartyName,
			ResponsiblePartyPhone	= t.ResponsiblePartyPhone,
			ResponsiblePartyEMail	= t.ResponsiblePartyEMail
From	@Job_Result_Set rs
Join	[EventMonitoring].[dbo].[ThresholdDuration] t on t.JobID = rs.JobID

Select	JobName as 'JobName', JobDescription as 'Description', JobEnabled as 'JobEnabled', JobFrequency as 'Frequency', 
		JobStartDate as 'StartDate', JobStartTime as 'StartTime',
		MaxElapsedSec as 'MaxElapsedSeconds', MaxDuration as 'MaxDuration', AvgElapsedSec as 'AvgElapsedSeconds', AvgDuration as 'AvgDuration', 
		LastElapsedSec as 'LastElapsedSeconds', LastDuration as 'LastDuration', ThresholdElapsedSec as ThresholdDuration,
		Subday_Freq as 'Frequency', JobStatus as 'Status', JobOutcome_Msg as 'OutcomeMessage', 
		ResponsiblePartyName, ResponsiblePartyPhone, ResponsiblePartyEMail, JobStatusSortBy
From @Job_Result_Set
ORDER BY JobEnabled Desc, JobStatusSortBy, JobStartDate desc, JobStartTime desc, JobName

Select	JobName, ThresholdDuration, ResponsiblePartyName, ResponsiblePartyPhone, ResponsiblePartyEMail
From	[EventMonitoring].[dbo].[ThresholdDuration]

RETURN 0

END TRY
	
BEGIN CATCH
Declare @ErrorMessage varchar(256)
		SET	@ErrorMessage = ERROR_MESSAGE() 
		SELECT 'An Error Occured', @ErrorMessage 
		RETURN -1
END CATCH

END
GO
