SET QUOTED_IDENTIFIER OFF
GO

/****** Object:  Default [DefaultSystemUser]    Script Date: 10/26/2018 11:07:17 AM ******/
CREATE DEFAULT [dbo].[DefaultSystemUser] 
AS
SYSTEM_USER
GO
