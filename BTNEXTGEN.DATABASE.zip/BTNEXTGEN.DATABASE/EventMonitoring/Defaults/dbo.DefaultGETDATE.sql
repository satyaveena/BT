SET QUOTED_IDENTIFIER OFF
GO

/****** Object:  Default [DefaultGETDATE]    Script Date: 10/26/2018 10:58:29 AM ******/
CREATE DEFAULT [dbo].[DefaultGETDATE] 
AS
GETDATE()
GO
