CREATE SERVICE [DeadlockNotificationService]
AUTHORIZATION [dbo]
ON QUEUE [dbo].[DeadlockNotificationQueue]
(
[http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]
)
GO
