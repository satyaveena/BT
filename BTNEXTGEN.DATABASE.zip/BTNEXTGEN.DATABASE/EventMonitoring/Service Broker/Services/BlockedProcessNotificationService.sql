CREATE SERVICE [BlockedProcessNotificationService]
AUTHORIZATION [dbo]
ON QUEUE [dbo].[BlockedProcessNotificationQueue]
(
[http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]
)
GO
