CREATE TYPE [dbo].[udtCreatedBy] FROM nvarchar (255) NOT NULL
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[udtCreatedBy]'
GO
