CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__125]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__125] ADD CONSTRAINT [PK__Catalog___1AF84101609ED11C] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
