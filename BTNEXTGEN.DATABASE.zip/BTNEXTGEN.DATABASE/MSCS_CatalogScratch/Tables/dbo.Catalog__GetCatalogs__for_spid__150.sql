CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__150]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__150] ADD CONSTRAINT [PK__Catalog___1AF84101033E01E3] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
