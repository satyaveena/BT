CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__144]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__144] ADD CONSTRAINT [PK__Catalog___1AF8410134D49220] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
