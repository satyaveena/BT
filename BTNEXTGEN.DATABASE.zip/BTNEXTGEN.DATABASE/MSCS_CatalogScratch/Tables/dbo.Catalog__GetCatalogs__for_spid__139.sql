CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__139]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__139] ADD CONSTRAINT [PK__Catalog___1AF8410137C60D64] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
