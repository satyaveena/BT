CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__64]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__64] ADD CONSTRAINT [PK__Catalog___1AF841011D7C2B7C] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
