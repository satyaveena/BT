CREATE TABLE [dbo].[Catalog__VC__CatalogPriceRules__for_spid__137]
(
[RowId] [int] NOT NULL IDENTITY(1, 1),
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CategoryName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProductID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Produ__50DBD3F1] DEFAULT (''),
[VariantID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Varia__51CFF82A] DEFAULT (''),
[AdjustmentType] [smallint] NOT NULL,
[Amount] [money] NULL,
[DisplayName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
