CREATE TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__92]
(
[RowId] [int] NOT NULL IDENTITY(1, 1),
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [smallint] NOT NULL,
[CategoryName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Categ__096BDC85] DEFAULT (''),
[ProductID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Produ__0A6000BE] DEFAULT (''),
[VariantID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Varia__0B5424F7] DEFAULT (''),
[DisplayName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__92] ADD CONSTRAINT [PK__Catalog___FFEE743107839413] PRIMARY KEY CLUSTERED  ([RowId]) ON [PRIMARY]
GO
