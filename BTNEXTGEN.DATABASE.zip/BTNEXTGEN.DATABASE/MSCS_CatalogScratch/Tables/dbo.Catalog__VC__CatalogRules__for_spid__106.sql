CREATE TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__106]
(
[RowId] [int] NOT NULL IDENTITY(1, 1),
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [smallint] NOT NULL,
[CategoryName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Categ__1CF21B97] DEFAULT (''),
[ProductID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Produ__1DE63FD0] DEFAULT (''),
[VariantID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Varia__1EDA6409] DEFAULT (''),
[DisplayName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__106] ADD CONSTRAINT [PK__Catalog___FFEE74311B09D325] PRIMARY KEY CLUSTERED  ([RowId]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
