CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__330]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__330] ADD CONSTRAINT [PK__Catalog___1AF8410148923D61] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
