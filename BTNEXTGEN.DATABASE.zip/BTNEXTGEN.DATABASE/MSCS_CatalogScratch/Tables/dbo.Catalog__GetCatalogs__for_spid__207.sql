CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__207]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__207] ADD CONSTRAINT [PK__Catalog___1AF8410154ED274E] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
