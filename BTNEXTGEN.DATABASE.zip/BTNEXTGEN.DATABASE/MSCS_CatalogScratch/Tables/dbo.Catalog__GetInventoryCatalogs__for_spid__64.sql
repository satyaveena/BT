CREATE TABLE [dbo].[Catalog__GetInventoryCatalogs__for_spid__64]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[#InventoryCatalogName#] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetInventoryCatalogs__for_spid__64] ADD CONSTRAINT [PK__Catalog___1AF8410173D00A73] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
