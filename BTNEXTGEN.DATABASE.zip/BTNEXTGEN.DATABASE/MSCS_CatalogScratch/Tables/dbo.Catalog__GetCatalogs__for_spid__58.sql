CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__58]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__58] ADD CONSTRAINT [PK__Catalog___1AF841015B3966D3] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
