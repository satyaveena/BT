CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__72]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__72] ADD CONSTRAINT [PK__Catalog___1AF841014343785F] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
