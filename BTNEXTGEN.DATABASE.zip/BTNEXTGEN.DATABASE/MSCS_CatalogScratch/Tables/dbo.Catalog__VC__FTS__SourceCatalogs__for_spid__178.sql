CREATE TABLE [dbo].[Catalog__VC__FTS__SourceCatalogs__for_spid__178]
(
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__FTS__SourceCatalogs__for_spid__178] ADD CONSTRAINT [PK__Catalog___19D9FA460A950AE8] PRIMARY KEY CLUSTERED  ([CatalogName]) ON [PRIMARY]
GO
