CREATE TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__150]
(
[RowId] [int] NOT NULL IDENTITY(1, 1),
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [smallint] NOT NULL,
[CategoryName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Categ__7B9CE01B] DEFAULT (''),
[ProductID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Produ__7C910454] DEFAULT (''),
[VariantID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Varia__7D85288D] DEFAULT (''),
[DisplayName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__150] ADD CONSTRAINT [PK__Catalog___FFEE743179B497A9] PRIMARY KEY CLUSTERED  ([RowId]) ON [PRIMARY]
GO
