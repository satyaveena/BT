CREATE TABLE [dbo].[Catalog__VC__FTS__SourceCatalogs__for_spid__194]
(
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__FTS__SourceCatalogs__for_spid__194] ADD CONSTRAINT [PK__Catalog___19D9FA464BC21919] PRIMARY KEY CLUSTERED  ([CatalogName]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
