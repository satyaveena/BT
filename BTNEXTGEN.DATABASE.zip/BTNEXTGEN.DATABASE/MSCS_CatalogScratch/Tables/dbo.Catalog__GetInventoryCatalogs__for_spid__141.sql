CREATE TABLE [dbo].[Catalog__GetInventoryCatalogs__for_spid__141]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[#InventoryCatalogName#] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetInventoryCatalogs__for_spid__141] ADD CONSTRAINT [PK__Catalog___1AF84101141CDE74] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
