CREATE TABLE [dbo].[Catalog__VC__FTS__RelatedCatalogs__for_spid__121]
(
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsVirtualCatalog] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__FTS__RelatedCatalogs__for_spid__121] ADD CONSTRAINT [PK__Catalog___19D9FA462B6BEECE] PRIMARY KEY CLUSTERED  ([CatalogName]) ON [PRIMARY]
GO
