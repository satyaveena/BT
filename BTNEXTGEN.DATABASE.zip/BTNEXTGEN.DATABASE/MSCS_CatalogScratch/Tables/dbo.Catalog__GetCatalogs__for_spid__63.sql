CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__63]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__63] ADD CONSTRAINT [PK__Catalog___1AF841014EA972BC] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
