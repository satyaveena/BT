CREATE TABLE [dbo].[Catalog__VC__FTS__SourceCatalogs__for_spid__149]
(
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__FTS__SourceCatalogs__for_spid__149] ADD CONSTRAINT [PK__Catalog___19D9FA46098A4168] PRIMARY KEY CLUSTERED  ([CatalogName]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
