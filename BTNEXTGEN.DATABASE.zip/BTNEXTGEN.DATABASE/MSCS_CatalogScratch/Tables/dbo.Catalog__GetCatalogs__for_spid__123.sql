CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__123]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__123] ADD CONSTRAINT [PK__Catalog___1AF8410106648751] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
