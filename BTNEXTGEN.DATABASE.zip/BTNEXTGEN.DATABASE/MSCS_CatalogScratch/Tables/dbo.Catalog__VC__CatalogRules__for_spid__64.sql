CREATE TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__64]
(
[RowId] [int] NOT NULL IDENTITY(1, 1),
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [smallint] NOT NULL,
[CategoryName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Categ__68736660] DEFAULT (''),
[ProductID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Produ__69678A99] DEFAULT (''),
[VariantID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Varia__6A5BAED2] DEFAULT (''),
[DisplayName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__64] ADD CONSTRAINT [PK__Catalog___FFEE7431668B1DEE] PRIMARY KEY CLUSTERED  ([RowId]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
