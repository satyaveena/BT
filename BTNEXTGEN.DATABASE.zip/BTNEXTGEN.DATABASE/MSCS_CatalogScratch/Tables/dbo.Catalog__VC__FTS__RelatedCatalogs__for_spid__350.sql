CREATE TABLE [dbo].[Catalog__VC__FTS__RelatedCatalogs__for_spid__350]
(
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsVirtualCatalog] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__FTS__RelatedCatalogs__for_spid__350] ADD CONSTRAINT [PK__Catalog___19D9FA460B9350C2] PRIMARY KEY CLUSTERED  ([CatalogName]) ON [PRIMARY]
GO
