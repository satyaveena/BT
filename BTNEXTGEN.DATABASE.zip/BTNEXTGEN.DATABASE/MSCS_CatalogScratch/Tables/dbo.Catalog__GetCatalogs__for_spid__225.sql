CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__225]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__225] ADD CONSTRAINT [PK__Catalog___1AF841010A8A1DF0] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
