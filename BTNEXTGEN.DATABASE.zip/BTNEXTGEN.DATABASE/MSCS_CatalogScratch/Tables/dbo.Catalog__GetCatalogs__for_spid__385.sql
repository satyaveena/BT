CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__385]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__385] ADD CONSTRAINT [PK__Catalog___1AF8410155573BA2] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
