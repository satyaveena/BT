CREATE TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__75]
(
[RowId] [int] NOT NULL IDENTITY(1, 1),
[CatalogName] [nvarchar] (85) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [smallint] NOT NULL,
[CategoryName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Categ__4E697B9A] DEFAULT (''),
[ProductID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Produ__4F5D9FD3] DEFAULT (''),
[VariantID] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Catalog____Varia__5051C40C] DEFAULT (''),
[DisplayName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__VC__CatalogRules__for_spid__75] ADD CONSTRAINT [PK__Catalog___FFEE74314C813328] PRIMARY KEY CLUSTERED  ([RowId]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
