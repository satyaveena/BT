CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__68]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__68] ADD CONSTRAINT [PK__Catalog___1AF8410154ADFB83] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
