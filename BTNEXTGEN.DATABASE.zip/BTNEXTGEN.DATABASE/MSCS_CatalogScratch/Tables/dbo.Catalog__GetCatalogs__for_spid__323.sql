CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__323]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__323] ADD CONSTRAINT [PK__Catalog___1AF8410132D8066C] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
