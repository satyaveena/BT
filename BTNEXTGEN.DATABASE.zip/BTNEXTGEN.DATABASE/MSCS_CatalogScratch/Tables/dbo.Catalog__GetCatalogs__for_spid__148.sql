CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__148]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__148] ADD CONSTRAINT [PK__Catalog___1AF841012512604C] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
