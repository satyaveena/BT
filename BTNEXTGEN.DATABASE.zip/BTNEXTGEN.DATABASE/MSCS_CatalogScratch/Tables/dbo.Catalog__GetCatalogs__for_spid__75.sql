CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__75]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__75] ADD CONSTRAINT [PK__Catalog___1AF841012C146396] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
