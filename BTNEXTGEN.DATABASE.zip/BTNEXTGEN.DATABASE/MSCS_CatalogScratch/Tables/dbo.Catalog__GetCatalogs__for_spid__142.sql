CREATE TABLE [dbo].[Catalog__GetCatalogs__for_spid__142]
(
[#TmpCatalogRowNum#] [int] NOT NULL IDENTITY(1, 1),
[CatalogID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Catalog__GetCatalogs__for_spid__142] ADD CONSTRAINT [PK__Catalog___1AF841013592E0D8] PRIMARY KEY CLUSTERED  ([#TmpCatalogRowNum#]) ON [PRIMARY]
GO
