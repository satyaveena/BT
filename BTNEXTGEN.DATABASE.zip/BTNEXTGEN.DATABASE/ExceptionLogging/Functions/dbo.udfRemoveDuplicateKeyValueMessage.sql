SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	9/2/2015
Description:	Removes the duplicate message string the elmah message
=============================================
*/
CREATE FUNCTION [dbo].[udfRemoveDuplicateKeyValueMessage]
(
	@Message NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Return NVARCHAR(MAX) = @Message

	--Variables
	DECLARE @DupKeyStart INT = 0
	DECLARE @DupKeyEnd INT = 0
	DECLARE @Length INT
	DECLARE @ReplacementString NVARCHAR(MAX)

	--SET values
	SET @DupKeyStart = PATINDEX('%the duplicate key value is%', @Message)
	--if dupkey start is 0, just return
	IF @DupKeyStart = 0
		RETURN @Return

	SET @DupKeyEnd = CHARINDEX(')', @Message, @DupKeyStart)
	--IF @DupKeyEnd is 0, just trim to the end of the string
	IF @DupKeyEnd = 0
		SET @DupKeyEnd = LEN(@Message) - 1 --For when we add the 2 when setting the length

	SET @Length	= @DupKeyEnd - @DupKeyStart + 2 --Accomodates the ). at the end
	SET @ReplacementString = SUBSTRING (@Message, @DupKeyStart, @Length)

	SELECT @Return = REPLACE(@Message, @ReplacementString, '')

	RETURN @Return 

END
GO
