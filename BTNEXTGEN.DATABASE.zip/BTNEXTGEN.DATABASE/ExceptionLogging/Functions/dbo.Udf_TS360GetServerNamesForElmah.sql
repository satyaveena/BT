SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		Hai Do
-- Create date: 2014-12-16
-- Description:	Get all servernames which have the error
-- =============================================
CREATE FUNCTION [dbo].[Udf_TS360GetServerNamesForElmah] 
(
	-- Add the parameters for the function here
	@Type [nvarchar](255) ,
	@Source [nvarchar](255),
	@Message nvarchar(4000),
	@StartDate datetime,
	@Days int
)
RETURNS nvarchar(100)
AS
BEGIN
	DECLARE @ServerNames varchar(500)
	DECLARE @Date DATE
	SET @Date = CONVERT(date,@StartDate,101)

	SELECT @ServerNames = COALESCE(@ServerNames + ', ','') + [Host]
	FROM ExceptionLog E with (nolock)
	WHERE E.TimeUtc>= @Date AND E.TimeUtc < DATEADD(day,@Days,@Date)
		AND E.[Type] = @Type
		AND E.[Source] = @Source
		AND (@Message = '' OR E.[Message] = @Message)
		AND E.[Host] is not NULL
	GROUP BY [Host]
	IF @ServerNames is NULL
		SET @ServerNames = ''
		
	RETURN @ServerNames
END

GO
