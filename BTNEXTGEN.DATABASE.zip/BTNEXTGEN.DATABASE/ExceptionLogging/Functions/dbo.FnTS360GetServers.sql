SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[FnTS360GetServers] 
(
	-- Add the parameters for the function here
	@Type [nvarchar](100) ,
	@Source [nvarchar](60),
	@Date datetime
)
RETURNS nvarchar(100)
AS
BEGIN
	declare @result nvarchar(100)
	
select @result = COALESCE(@result + ',', '') + [Host]
  FROM [ExceptionLogging].[dbo].[ExceptionLog]   el with(nolock)
  where el.Type=@Type and el.Source = @Source
  and DAY([TimeUtc]) =  DAY(@Date) 
  AND MONTH([TimeUtc]) =  MONTH(@Date) 
  AND YEAR([TimeUtc]) =  YEAR(@Date)
  group by [Host]
  
  return @result

END
GO
