SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	4/8/2015
Description:	Removes junk information from the AllXML value in the ELMAHLog
=============================================
*/
CREATE FUNCTION [dbo].[udfRemoveELMAHJunk]
(
	@AllXMLString NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Return NVARCHAR(MAX)

	SET @Return = @AllXMLString

	SET @Return = REPLACE(@Return, CHAR(13), SPACE(0))
	SET @Return = REPLACE(@Return, CHAR(10), SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.SqlException: Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.   at System.Data.SqlClient.SqlConnection.', SPACE(0))
	SET @Return = REPLACE(@Return, 'OnError(SqlException exception, Boolean breakConnection)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'at ', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.TdsParser.', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.SqlCommand.', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.SqlDataReader.', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.Common.', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.TdsParserStateObject.', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.SqlInternalConnection.', SPACE(0))
	SET @Return = REPLACE(@Return, 'ThrowExceptionAndWarning(TdsParserStateObject stateObj)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'Run(RunBehavior runBehavior, SqlCommand cmdHandler, SqlDataReader dataStream, BulkCopySimpleResultSet bulkCopyHandler, TdsParserStateObject stateObj)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'FinishExecuteReader(SqlDataReader ds, RunBehavior runBehavior, String resetOptionsString)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'RunExecuteReaderTds(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, Boolean async)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'RunExecuteReader(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, String method, DbAsyncResult result)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'InternalExecuteNonQuery(DbAsyncResult result, String methodName, Boolean sendToPipe)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ExecuteNonQuery()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.SqlException: Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ConsumeMetaData()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'get_MetaData()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'RunExecuteReader(CommandBehavior cmdBehavior, RunBehavior runBehavior, Boolean returnStream, String method)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ExecuteReader(CommandBehavior behavior, String method)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ExecuteDbDataReader(CommandBehavior behavior)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'DbCommand.System.Data.IDbCommand.ExecuteReader(CommandBehavior behavior)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'DbDataAdapter.FillInternal(DataSet dataset, DataTable[] datatables, Int32 startRecord, Int32 maxRecords, String srcTable, IDbCommand command, CommandBehavior behavior)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'DbDataAdapter.Fill(DataSet dataSet, Int32 startRecord, Int32 maxRecords, String srcTable, IDbCommand command, CommandBehavior behavior)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'DbDataAdapter.Fill(DataSet dataSet)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'System.Data.SqlClient.SqlInternalConnection.System.Data.SqlClient.TdsParserStateObject.ReadSniError(TdsParserStateObject stateObj, UInt32 error)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ReadSni(DbAsyncResult asyncResult, TdsParserStateObject stateObj)   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ReadNetworkPacket()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ReadBuffer()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ReadByte()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ReadSniError(TdsParserStateObject stateObj, UInt32 error)  ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ExecuteReader()   ', SPACE(0))
	SET @Return = REPLACE(@Return, 'ExecuteScalar()   ', SPACE(0))
	
	--SET @Return = REPLACE(@Return, '', SPACE(0))
	-- Return the result of the function
	RETURN @Return

END
GO
