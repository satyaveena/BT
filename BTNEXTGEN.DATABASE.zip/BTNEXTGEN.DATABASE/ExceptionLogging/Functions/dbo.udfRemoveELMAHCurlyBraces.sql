SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	4/9/2015
Description:	Removes the data between curly braces
=============================================
*/
CREATE FUNCTION [dbo].[udfRemoveELMAHCurlyBraces]
(
	@Data NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	--Variables
	DECLARE @Return NVARCHAR(MAX)
	DECLARE @GuidPattern VARCHAR(MAX) = '%{[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]}%'

	--Start position of the guid
	DECLARE @StartPosition INT = PATINDEX(@GuidPattern, @Data)

	--Actual GUID value
	DECLARE @Guid NCHAR(38) = SUBSTRING (@Data, @StartPosition, 38)

	--Replace the GUID
	SELECT	@Return = REPLACE(@Data, @Guid, '')

	-- Return the result of the function
	RETURN @Return

END
GO
