SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2/18/2016
Description:	Returns Missing Indexes for the BTDBAReport
=============================================
*/
CREATE PROCEDURE [dbo].[procBTDBAReportLongRunningQueries]
	@ReportDate		DATE
	, @Database		VARCHAR(25)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	SPName
			, TotalWorkerTime
			, AvgWorkerTime
			, ExecutionCount
			, CallsPerSecond
			, TotalElapsedTime
			, AvgElapsedTime
			, CachedTime
	FROM	dbo.LongRunningQueries
	WHERE	CreatedDate = @ReportDate
	AND		DB = @Database
	ORDER BY TotalWorkerTime DESC
END
GO
