SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2/18/2016
Description:	Returns Missing Indexes for the BTDBAReport
=============================================
*/
CREATE PROCEDURE [dbo].[procBTDBAReportMissingIndexes]
	@ReportDate		DATE
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	improvement_measure
			, TableName
			, [Columns]
			, IncludeStatement
			, user_seeks
			, last_user_seek
			, user_scans
			, last_user_scan
	FROM	dbo.MissingIndexes
	WHERE	CreatedDate = @ReportDate
	AND		ExcludeFromReport = 0
	ORDER BY improvement_measure DESC
END
GO
