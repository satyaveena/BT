SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-07-18
Description:	Returns error information based on the ExceptionID

fid, FolderID for folder GUIDs
2017-11-03	KG	Changed Nextgen_profiles.dbo.CsUsers to NextGen_profiles.dbo.UserObject
2018-04-28	kG	Added TFSNumber and ExceptionLogTFSID to the result
=============================================
*/
CREATE PROCEDURE [dbo].[procReportingELMAHDetail]
	@ErrorID		UNIQUEIDENTIFIER
	, @StartDate	DATETIME = NULL
	, @EndDate		DATETIME = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	--For entity framework
	IF(0=1) 
		SET FMTONLY OFF

	DECLARE @NonTimeOutCount	INT = 0
			, @Message			NVARCHAR(MAX)
			, @HoursOffSet		INT
			, @ErrorCount		INT

	CREATE TABLE #Return
	(
		UserName			NVARCHAR(MAX)
		, BasketSummaryID	NVARCHAR(MAX)
		, BasketName		NVARCHAR(80)
		, PathInfo			NVARCHAR(MAX)
		, QueryString		NVARCHAR(MAX)
		, HttpReferer		NVARCHAR(MAX)
		, AllXML			XML
		, Message			NVARCHAR(MAX)
		, EmailAddress		NVARCHAR(100)
		, FolderName		NVARCHAR(255)
		, BTKey				VARCHAR(10)
		, TimeEST			DATETIME
		, Source			NVARCHAR(60)
		, Type				NVARCHAR(100)
		, TFSNumber			INT
		, ExceptionLogTFSID	BIGINT
	)

	--Timeouts
	CREATE TABLE #Timeouts
	(
		Host			NVARCHAR(50)
		, Type			NVARCHAR(100)
		, Source		NVARCHAR(60)
		, Message		NVARCHAR(MAX)
	)

	CREATE TABLE #TempTimeouts
	(
		Host			NVARCHAR(50)
		, Type			NVARCHAR(100)
		, Source		NVARCHAR(60)
		, AllXML		XML
	)

	SELECT @HoursOffSet = DATEDIFF(HOUR, GETUTCDATE(), GETDATE())

	--Set the end date to now in EST if no end date was specified
	IF @EndDate IS NULL
		SET @EndDate = GETDATE()
	ELSE
		--set EndDate to tomorrow so that we actually include today
		SET @EndDate = DATEADD(DAY, 1, @EndDate)

	IF @StartDate IS NULL
		SET @StartDate = '1/1/1900'

	--Convert to UTC time
	SELECT @StartDate = DATEADD(HOUR, @HoursOffSet * -1, @StartDate)
			, @EndDate = DATEADD(HOUR, @HoursOffSet * -1, @EndDate)
	
	--grab the data from the log table
	INSERT INTO #Return (AllXML, Message, TimeEST, Source, Type)
	SELECT	AllXml, Message, DATEADD(HOUR, @HoursOffSet, TimeUtc), Source, Type
	FROM	dbo.ExceptionLogReportingNonTimeoutErrors WITH (NOLOCK)
	WHERE	ErrorID = @ErrorID

	--check if we need to check timeouts
	SELECT @NonTimeOutCount = @@ROWCOUNT
	
	IF @NonTimeOutCount = 0
	BEGIN
		--grab the XML
		INSERT INTO #Return (AllXML, Message, TimeEST, Source, Type)
		SELECT	AllXML, 'Timeout: ' + dbo.udfRemoveELMAHJunk(R.P.value('data(./@detail)[1]', 'NVARCHAR(MAX)')) as Message
				, DATEADD(HOUR, @HoursOffSet, TimeUtc), Source, Type
		FROM	dbo.ExceptionLogReportingTimeoutErrors
		CROSS APPLY AllXml.nodes('error') AS R(p)
		WHERE	ErrorID = @ErrorID

		UPDATE	#Return
		SET		Message = REPLACE(Message, SUBSTRING(Message, CHARINDEX('PK__#', Message)-2, 33), '')
		WHERE	Message like 'Violation of PRIMARY KEY constraint%'
		AND		Message like '%Cannot insert duplicate key in object%'
		AND		(Message like '%@BasketSummaryIDs%' OR Message like '%@BTKeyCatalogs%' OR Message like '%@BasketOrderForms%' OR Message like '%@DeletedBasketIDs%')
		AND		Message like '%PK__#%'
	END

	--parse out the stuff for the report
	UPDATE	R
	SET UserName = E.I.value('(/error/serverVariables/item[@name="AUTH_USER"]/value/@string)[1]', 'VARCHAR(MAX)') 
		, PathInfo = E.I.value('(/error/serverVariables/item[@name="PATH_INFO"]/value/@string)[1]', 'VARCHAR(MAX)')
		, BasketSummaryID = E.I.value('(/error/queryString/item[@name="cartId"]/value/@string)[1]', 'VARCHAR(MAX)')
		, QueryString = E.I.value('(/error/serverVariables/item[@name="QUERY_STRING"]/value/@string)[1]', 'VARCHAR(MAX)')
		, HttpReferer = E.I.value('(/error/serverVariables/item[@name="HTTP_REFERER"]/value/@string)[1]', 'VARCHAR(MAX)')
	FROM	#Return AS R
	CROSS APPLY AllXml.nodes('error') AS E(I)

	--If AuthUser isn't populated, go after HTTP_REQUEST_USERID
	UPDATE	R
	SET		UserName = E.I.value('(/error/serverVariables/item[@name="HTTP_REQUEST_USERID"]/value/@string)[1]', 'VARCHAR(MAX)') 
	FROM	#Return AS R
	CROSS APPLY AllXml.nodes('error') AS E(I)
	WHERE	UserName = ''

	--update the cart name
	UPDATE	R
	SET		BasketName = BS.BasketName
	FROM	Orders.dbo.BasketSummary AS BS
	JOIN	#Return AS R
	ON		BS.BasketSummaryID = R.BasketSummaryID

	--strip out email and conver to username
	UPDATE	#Return
	SET		UserName = REPLACE(UserName, '0#.f|upmprovider_', '')
	WHERE	CHARINDEX('{', UserName) <> 0

	UPDATE	#Return
	SET		UserName = RIGHT(UserName, LEN(UserName) - CHARINDEX('|', UserName))
	WHERE	CHARINDEX('{', UserName) <> 0

	UPDATE	R
	SET		UserName = U.u_user_name
	FROM	#Return AS R
	JOIN	NextGen_Profiles.dbo.UserObject AS U
	ON		R.UserName = U.u_email_address

	UPDATE	R
	SET		UserName = u.u_user_name
	FROM	#Return AS R
	JOIN	NextGen_Profiles.dbo.UserObject AS U
	ON		R.UserName = u.u_user_id
	WHERE	CHARINDEX('{', UserName) <> 0

	--pull out folder id from the query string
	UPDATE	#Return
	SET		FolderName = SUBSTRING(QueryString, CHARINDEX('_fid', QueryString) + 5, 38)
	WHERE	CHARINDEX('_fid', QueryString) <> 0

	UPDATE	#Return
	SET		FolderName = SUBSTRING(QueryString, CHARINDEX('FolderID', QueryString) + 5, 38)
	WHERE	CHARINDEX('FolderID', QueryString) <> 0

	--convert to folder name
	UPDATE	R
	SET		FolderName = UF.Literal
	FROM	#Return AS R
	JOIN	Orders.dbo.UserFolders as UF
	ON		R.FolderName = UF.UserFolderID

	--btkey
	UPDATE	#Return
	SET		BTKey = SUBSTRING(QueryString, CHARINDEX('ngbtkey', QueryString) + 8, 10)
	WHERE	CHARINDEX('ngbtkey', QueryString) <> 0

	--Get error count
	--Type is something that doesn't change, and we know if we have to go timeout or not
	IF @NonTimeOutCount = 0
	BEGIN
		--grab the XML
		INSERT INTO #TempTimeouts (Host, Type, Source, AllXML)
		SELECT	Host, Type, Source, AllXml
		FROM	dbo.ExceptionLogReportingTimeoutErrors
		WHERE	TimeUtc >= @StartDate
		AND		TimeUtc < @EndDate

		INSERT INTO #Timeouts (Host, [Type], [Source], [Message])
		SELECT	Host, Type, Source, 'Timeout: ' + dbo.udfRemoveELMAHJunk(R.P.value('data(./@detail)[1]', 'NVARCHAR(MAX)')) as Message
		FROM	#TempTimeouts
		CROSS APPLY AllXml.nodes('error') AS R(p)

		UPDATE	#Timeouts
		SET		Message = REPLACE(Message, SUBSTRING(Message, CHARINDEX('PK__#', Message)-2, 33), '')
		WHERE	Message like 'Violation of PRIMARY KEY constraint%'
		AND		Message like '%Cannot insert duplicate key in object%'
		AND		(Message like '%@BasketSummaryIDs%' OR Message like '%@BTKeyCatalogs%' OR Message like '%@BasketOrderForms%' OR Message like '%@DeletedBasketIDs%')
		AND		Message like '%PK__#%'

		SELECT	@ErrorCount = COUNT(*)
		FROM	#Timeouts AS T
		JOIN	#Return AS R
		ON		T.Type = R.Type
		AND		T.Source = R.Source
		AND		T.Message = R.Message
	END
	ELSE
	BEGIN
		--nontimeout errors
		SELECT	@ErrorCount = COUNT(*)
		FROM	dbo.ExceptionLogReportingNonTimeoutErrors AS E
		JOIN	#Return AS R
		ON		E.Type = R.Type
		AND		E.Source = R.Source
		AND		E.Message = R.Message
		WHERE	TimeUtc >= @StartDate
		AND		TimeUtc < @EndDate
	END

	SELECT	UserName, PathInfo, BasketName, QueryString, HttpReferer, AllXML, Message, FolderName, BTKey, TimeEST, Source, Type, @ErrorCount as ErrorCount
			, TFSNumber, ExceptionLogTFSID
	FROM	#Return

	DROP TABLE #Return
	DROP TABLE #TempTimeouts
END
GO
