SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Ivor D. Addo
-- Create Date: 03/17/2013
-- Description:	Log API Requests
-- =============================================
CREATE PROCEDURE [dbo].[procTS360APILogRequests] 
	@webMethod nvarchar(255),
	@requestMessage nvarchar(max),
	@responseMessage nvarchar(max),
	@vendorAPIKey nvarchar(255),
	@createdOn datetime2(7),
	@createdBy nvarchar(50),
	@exceptionMessage nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO TS360APILog(LogRequestId, WebMethod, RequestMessage, ResponseMessage, VendorAPIKey, CreatedOn, CreatedBy, ExceptionMessage)
    VALUES (NEWID(), @webMethod,@requestMessage, @responseMessage, @vendorAPIKey,@createdOn, @createdBy, @exceptionMessage)

END
GO
