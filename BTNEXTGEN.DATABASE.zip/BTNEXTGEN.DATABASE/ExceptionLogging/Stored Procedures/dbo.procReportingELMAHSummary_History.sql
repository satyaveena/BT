SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
=============================================
Author:			Kelly Gulutz
Create date:	2018-01-09
Description:	Copied from procReportingELMAHSummary, Returns reports for QA/Dev ELMAH log viewing from the history table

Notes: 
Date coming in is EST
=============================================
*/
CREATE PROCEDURE [dbo].[procReportingELMAHSummary_History]
	@BeginDate		DATETIME = NULL
	, @EndDate		DATETIME = NULL
	, @PageIndex	INT = 1
	, @PageSize		INT = 25
	, @TotalCount	INT OUTPUT
	, @SortBy		VARCHAR(50) = 'Time' --Time, Host, Type, Source, Message
	, @SortDirection BIT = 1 --1 desc, 0 asc
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	--Temp Return table
	DECLARE @TempReturn TABLE
	(
		Host			NVARCHAR(50)
		, Type			NVARCHAR(100)
		, Source		NVARCHAR(60)
		, Message		NVARCHAR(MAX)
		, TimeUTC		DATETIME
		, Application	NVARCHAR(60)
		, ErrorID		UNIQUEIDENTIFIER
		, AllXML		NVARCHAR(MAX)
	)

	--Final Return
	DECLARE @FinalReturn TABLE
	(
		Host			NVARCHAR(50)
		, Type			NVARCHAR(100)
		, Source		NVARCHAR(60)
		, Message		NVARCHAR(MAX)
		, TimeUTC		DATETIME
		, Application	NVARCHAR(60)
		, ErrorID		UNIQUEIDENTIFIER
		, AllXML		NVARCHAR(MAX)
		, RowNumber		INT IDENTITY (1, 1)
	)

	DECLARE	@fromItem	INT
			, @toItem	INT

	--Set the end date to now in EST if no end date was specified
	IF @EndDate IS NULL
		SET @EndDate = GETDATE()
	ELSE
		--set EndDate to tomorrow so that we actually include today
		SET @EndDate = DATEADD(DAY, 1, @EndDate)

	IF @BeginDate IS NULL
		SET @BeginDate = '1/1/1900'

	--Get UTC vs EST timezone diff
	DECLARE @HoursOffSet INT = DATEDIFF(HOUR, GETDATE(), GETUTCDATE())

	--Convert to UTC time
	SELECT @BeginDate = DATEADD(HOUR, @HoursOffSet, @BeginDate)
			, @EndDate = DATEADD(HOUR, @HoursOffSet, @EndDate)

	--Non timeout messages
	INSERT INTO @TempReturn (Host, Type, Source, Message, TimeUtc, ErrorId, AllXml)
	SELECT	Host, [Type], [Source], Message, TimeUtc, ErrorID, AllXML
	FROM	dbo.ExceptionLogReportingNonTimeoutErrors_History
	WHERE	TimeUtc >= @BeginDate
	AND		TimeUtc < @EndDate
	
	--Timeouts
	DECLARE @Timeouts TABLE 
	(
		Host			NVARCHAR(50)
		, Type			NVARCHAR(100)
		, Source		NVARCHAR(60)
		, AllXML		XML
		, TimeUTC		DateTime
		, ErrorID		UNIQUEIDENTIFIER
	)

	INSERT INTO @Timeouts
	SELECT	Host, Type, Source, AllXml, TimeUtc, ErrorId
	FROM	dbo.ExceptionLogReportingTimeoutErrors_History
	WHERE	TimeUtc >= @BeginDate
	AND		TimeUtc < @EndDate

	INSERT INTO @TempReturn (Host, [Type], [Source], [Message], TimeUtc, ErrorID, AllXML)
	SELECT	Host, Type, Source, 'Timeout: ' + dbo.udfRemoveELMAHJunk(R.P.value('data(./@detail)[1]', 'NVARCHAR(MAX)')) as Message
			, TimeUtc, ErrorID, CAST(AllXML AS NVARCHAR(MAX)) as AllXML
	FROM	@Timeouts
	CROSS APPLY AllXml.nodes('error') AS R(p)
	
	--Dedup primary key temp table violoation messages
	UPDATE	@TempReturn
	SET		Message = REPLACE(Message, SUBSTRING(Message, CHARINDEX('PK__#', Message)-2, 33), '')
	WHERE	Message like 'Violation of PRIMARY KEY constraint%'
	AND		Message like '%Cannot insert duplicate key in object%'
	AND		(Message like '%@BasketSummaryIDs%' OR Message like '%@BTKeyCatalogs%' OR Message like '%@BasketOrderForms%' OR Message like '%@DeletedBasketIDs%')
	AND		Message like '%PK__#%'

	SELECT	@TotalCount = COUNT(*)
	FROM	@TempReturn

	--set from and to range for the result 
	SET @fromItem = (@PageIndex - 1) * @PageSize + 1
	SET @toItem = @fromItem + @PageSize - 1

	IF @SortDirection = 1
	BEGIN
		IF @SortBy = 'Host'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Host DESC, TimeUtc DESC
		
		ELSE IF @SortBy = 'Type'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Type DESC, TimeUtc DESC
		
		ELSE IF @SortBy = 'Source'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Source DESC, TimeUtc DESC
		
		ELSE IF @SortBy = 'Message'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Message DESC, TimeUtc DESC

		ELSE
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY TimeUtc DESC
	END
	ELSE --IF @SortDirection = 0
	BEGIN
		IF @SortBy = 'Host'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Host, TimeUtc DESC
		
		ELSE IF @SortBy = 'Type'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Type, TimeUtc DESC
		
		ELSE IF @SortBy = 'Source'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Source, TimeUtc DESC
		
		ELSE IF @SortBy = 'Message'
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY Message, TimeUtc DESC

		ELSE
			--Insert temp results, default sort by Timesorted
			INSERT INTO @FinalReturn (Host, Type, Source, Message, TimeUtc, ErrorId)
			SELECT	Host, Type, Source, Message, TimeUtc, ErrorId
			FROM	@TempReturn
			ORDER BY TimeUtc
	END

	--return page, but convert TimeUtc to EST
	SELECT	@HoursOffSet *= -1

	SELECT	Host, Type, Source, Message, DATEADD(HOUR, @HoursOffSet, TimeUTC) as TimeEst, ErrorId
	FROM	@FinalReturn
	WHERE	RowNumber BETWEEN @fromItem AND @toItem
	ORDER BY RowNumber
END
GO
