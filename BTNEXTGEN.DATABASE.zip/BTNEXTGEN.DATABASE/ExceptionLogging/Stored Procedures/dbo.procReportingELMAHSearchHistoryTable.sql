SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2018-01-24
Description:	Allows for searching of the ExceptionLogHistory table via TFS or Type/Source/Message
				Message will always search as trailing like
				Performance was too slow without dynamic SQL
=============================================
*/
CREATE PROCEDURE [dbo].[procReportingELMAHSearchHistoryTable]
	@TFSNumber		INT = NULL
	, @Type			NVARCHAR(100) = NULL
	, @Source		NVARCHAR(60) = NULL
	, @Message		NVARCHAR(MAX) = NULL
	, @MaxReturnCount INT = 25
AS
BEGIN
	SET NOCOUNT ON;
	SET TRAN ISOLATION LEVEL READ UNCOMMITTED;

	--Variables
	DECLARE @TimeZoneAdjustment INT = DATEDIFF(HOUR, GETUTCDATE(), GETDATE())
			, @SearchNumber TINYINT

	--Set message to work with the
	--User input check, must supply data
	IF @TFSNumber IS NULL and @Type IS NULL AND @Source IS NULL and @Message IS NULL
	BEGIN
		SELECT	'You must supply at least one argument to search by.' as ErrorMessage
		RETURN -1
	END

	--Cannot search by TFSNumber and Type/Source/Message
	DECLARE @NonTFSSearch BIT = 0
	IF @Type IS NOT NULL
		SET @NonTFSSearch = 1
	ELSE IF @Source IS NOT NULL
		SET @NonTFSSearch = 1
	ELSE IF @Message IS NOT NULL
		SET @NonTFSSearch = 1

	IF @TFSNumber IS NOT NULL AND @NonTFSSearch = 1
	BEGIN
		SELECT	'You cannot search by TFSNumber and Type/Source/Message.'
		RETURN -1
	END

	--Return if @MaxReturnCount = 0
	IF @MaxReturnCount = 0
	BEGIN
		SELECT	'You must specify a return count greater than 0.'
		RETURN -1
	END

	--Search, TFSNumber
	IF @TFSNumber IS NOT NULL
	BEGIN
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST
				, ErrorID, AllXML
		FROM	dbo.ExceptionLogTFS AS TFS
		LEFT JOIN dbo.ExceptionLogHistory AS H
		ON		TFS.Type = H.Type
		AND		TFS.Source = H.Source
		AND		TFS.Message = H.Message
		WHERE	TFSTicketNumber = @TFSNumber
		ORDER BY TimeUtc DESC

		RETURN 0
	END

	/*
	Determine parameters passed in so that we can build the right statement
	Dynamic SQL did not work with the permissions applied to the login, so 7 select statements had be determined
	1. All 3 parameters were passed
	2. Just type
	3. Just source
	4. Just message
	5. Type + Source
	6. Type + Message
	7. Source + Message
	This just seemed like an easier way to see what query we were going to build
	*/
	IF @Type IS NOT NULL AND @Source IS NOT NULL AND @Message IS NOT NULL
		SET @SearchNumber = 1
	ELSE IF @Type IS NOT NULL AND @Source IS NULL AND @Message IS NULL
		SET @SearchNumber = 2
	ELSE IF @Type IS NULL AND @Source IS NOT NULL and @Message IS NULL
		SET @SearchNumber = 3
	ELSE IF @Type IS NULL AND @Source IS NULL and @Message IS NOT NULL
		SET @SearchNumber = 4
	ELSE IF @Type IS NOT NULL AND @Source IS NOT NULL AND @Message IS NULL
		SET @SearchNumber = 5
	ELSE IF @Type IS NOT NULL AND @Source IS NULL AND @Message IS NOT NULL
		SET @SearchNumber = 6
	ELSE IF @Type IS NULL AND @Source IS NOT NULL AND @Message IS NOT NULL
		SET @SearchNumber = 7
	ELSE
		BEGIN
			SELECT 'Invalid search'
			RETURN -1
		END
	
	PRINT 'Search Number ' + CAST(@SearchNumber AS CHAR(1))

	IF @SearchNumber = 1
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.Type = @Type
		AND		H.Source = @Source
		AND		H.MessageFormatted LIKE @Message + '%'
		ORDER BY TimeUtc DESC

	ELSE IF @SearchNumber = 2
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.Type = @Type
		ORDER BY TimeUtc DESC

	ELSE IF @SearchNumber = 3
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.Source = @Source
		ORDER BY TimeUtc DESC

	ELSE IF @SearchNumber = 4
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.MessageFormatted LIKE @Message + '%'
		ORDER BY TimeUtc DESC

	ELSE IF @SearchNumber = 5
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.Type = @Type
		AND		H.Source = @Source
		ORDER BY TimeUtc DESC

	ELSE IF @SearchNumber = 6
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.Type = @Type
		AND		H.MessageFormatted LIKE @Message + '%'
		ORDER BY TimeUtc DESC

	ELSE IF @SearchNumber = 7
		SELECT TOP (@MaxReturnCount) TFS.TFSTicketNumber, H.Type, H.Source, H.MessageFormatted as Message
				, DATEADD(HOUR, @TimeZoneAdjustment, TimeUtc) as TimeEST, ErrorID, AllXML
		FROM	dbo.ExceptionLogHistory AS H 
		LEFT JOIN dbo.ExceptionLogTFS AS TFS 
		ON		H.Type = TFS.Type 
		AND		H.Source = TFS.Source  
		AND		H.Message = TFS.Message  
		WHERE	H.Source = @Source
		AND		H.MessageFormatted LIKE @Message + '%'
		ORDER BY TimeUtc DESC
END
GO
