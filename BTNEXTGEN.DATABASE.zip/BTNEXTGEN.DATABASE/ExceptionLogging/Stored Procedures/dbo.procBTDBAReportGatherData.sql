SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2/10/2016
Description:	Archives data for the BTDBA Reports
=============================================
*/
CREATE PROCEDURE [dbo].[procBTDBAReportGatherData]
AS
BEGIN
	SET NOCOUNT ON;

	--grab the last date we did missing indexes
	DECLARE @MaxMissingIndexDate DATE
	SELECT	@MaxMissingIndexDate = MAX(CreatedDate)
	FROM	dbo.MissingIndexes

	--Missing Indexes
	INSERT INTO dbo.MissingIndexes
	SELECT		migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS improvement_measure
				, mid.statement as TableName
				, ISNULL (mid.equality_columns,'')
					+ CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN ',' ELSE '' END
					+ ISNULL (mid.inequality_columns, '') as [Columns]
				, mid.included_columns AS IncludeStatement
				, migs.user_seeks
				, migs.last_user_seek
				, migs.user_scans
				, migs.last_user_scan
				, GETDATE() as CreatedDate
				, 0 as ExcludeFromReport
	FROM sys.dm_db_missing_index_groups mig
	INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
	INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
	WHERE migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) > 10
	AND	  migs.user_seeks > 25
	AND	  migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) > 1000
	ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC
	
	--Update the exclude from report flag
	--If the flag to exclude a missing index from the report was set from last week's file, carry that to today
	; WITH ExcludedFromLastRun AS
	(SELECT	TableName
			, [Columns]
			, ISNULL(IncludeStatement, '') as IncludeStatement
			, CreatedDate
	FROM	dbo.MissingIndexes
	WHERE	CreatedDate = @MaxMissingIndexDate
	AND		ExcludeFromReport = 1)

	UPDATE	MI
	SET		ExcludeFromReport = 1
	FROM	dbo.MissingIndexes AS MI
	JOIN	ExcludedFromLastRun AS E
	ON		MI.TableName = E.TableName
	AND		MI.[Columns] = E.[Columns]
	AND		ISNULL(MI.IncludeStatement, '') = E.IncludeStatement
	WHERE	MI.CreatedDate = CAST(GETDATE() AS DATE)

	--Long running stored procedures, ProductCatalog
	INSERT INTO dbo.LongRunningQueries
	SELECT TOP(25) p.name AS SPName
		, qs.total_worker_time/1000  AS TotalWorkerTime
		, (qs.total_worker_time/qs.execution_count)/1000  AS [AvgWorkerTime], qs.execution_count
		, ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second]
		, (qs.total_elapsed_time/1000 ) as total_elapsed_time
		, (qs.total_elapsed_time/qs.execution_count)/1000 AS [avg_elapsed_time]
		, qs.cached_time
		, db.name as DB
		, GETDATE() as CreatedDateTime
	FROM	ProductCatalog.sys.procedures AS p
	INNER JOIN sys.dm_exec_procedure_stats AS qs
	ON		p.[object_id] = qs.[object_id]
	JOIN	sys.databases AS DB
	ON		qs.database_id = db.database_id
	WHERE	db.name = 'ProductCatalog'
	ORDER BY qs.total_worker_time DESC;

	--Long running stored procedures, Orders
	INSERT INTO dbo.LongRunningQueries
	SELECT TOP(25) p.name AS SPName
		, qs.total_worker_time/1000  AS TotalWorkerTime
		, (qs.total_worker_time/qs.execution_count)/1000  AS [AvgWorkerTime], qs.execution_count
		, ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second]
		, (qs.total_elapsed_time/1000 ) as total_elapsed_time
		, (qs.total_elapsed_time/qs.execution_count)/1000 AS [avg_elapsed_time]
		, qs.cached_time
		, db.name as DB
		, GETDATE() as CreatedDateTime
	FROM	Orders.sys.procedures AS p
	INNER JOIN sys.dm_exec_procedure_stats AS qs
	ON		p.[object_id] = qs.[object_id]
	JOIN	sys.databases AS DB
	ON		qs.database_id = db.database_id
	WHERE	db.name = 'Orders'
	ORDER BY qs.total_worker_time DESC;

END
GO
