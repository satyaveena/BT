SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kell Gulutz
Create date:	2017-06-07
Description:	Counts for Storm Runner tests

Modifications: 
2017-06-20	Modified to do users 1 to 100
2017-08-25	Bruce Baum - TFS 26573:SQL 2016 Upgrade: @@ServerName
						 Changed to Access the [BTAdmin].[dbo].[ServerURL] Table to determine which Server the Procedure is running on
							
=============================================
*/
CREATE PROCEDURE [dbo].[procPerformanceTestingValidateResults]
	@BeginDate DATETIME = NULL
	, @EndDate DATETIME = NULL
	, @BeginID	INT
	, @EndID INT
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	IF @BeginDate IS NULL
	BEGIN
		--Default being & end to 6am to 7am if no dates are passed
		SELECT @BeginDate = CAST(CAST(CAST(GETDATE() AS DATE) as VARCHAR(10)) + ' 6:00' as DATETIME)
				, @EndDate = CAST(CAST(CAST(GETDATE() AS DATE) as VARCHAR(10)) + ' 7:00' as DATETIME)
    END

	DECLARE @ServerName VARCHAR(255) = @@SERVERNAME
	
	DECLARE @TestUsers TABLE 
	(
		UserName			NVARCHAR(50)
		, UserID			NVARCHAR(50)
		, LastActivityDate	DATETIME
	)

	DECLARE @Baskets TABLE
	(
		BasketSummaryID			NVARCHAR(50)
		, BasketOwnerID			NVARCHAR(50)
		, BasketLineItemID		NVARCHAR(50)
		, BasketLineItemGridID	NVARCHAR(50)
		, BTKey					CHAR(10)
		, BLIQty				INT
		, BasketName			NVARCHAR(80)
	)

	--UserName table
	DECLARE @UsersSeed TABLE (u_user_name NVARCHAR(50))
	DECLARE @UserNamePrefix VARCHAR(25) 

	--Perf1_% in QA, PT010 to PT013 in PE

	
	SELECT TOP 1 @ServerName = ServerEnvironment		--2017-08-25	Bruce Baum - TFS 26573
	 FROM [BTAdmin].[dbo].[ServerURL]

	--IF @ServerName = 'BT-STG-DB-1\REPOSITORY'
	IF Left(@ServerName,2) = 'QA'						--2017-08-25	Bruce Baum - TFS 26573
	OR Left(@ServerName,3) = 'DEV'
	BEGIN
		SELECT @UserNamePrefix = 'Perf1_'

		WHILE @BeginID <= @EndID
		BEGIN
			IF @BeginID < 100
				INSERT INTO @UsersSeed VALUES (@UserNamePrefix + RIGHT ('0' + CAST(@BeginID AS VARCHAR(2)), 2))
			ELSE
				INSERT INTO @UsersSeed VALUES (@UserNamePrefix + RIGHT ('0' + CAST(@BeginID AS VARCHAR(3)), 3))

			SET @BeginID += 1
		END

		INSERT INTO @TestUsers (UserName, UserID, LastActivityDate)
		SELECT	cs.u_user_name, cs.u_user_id, cs.dt_last_activity_date
		FROM	Orders.dbo.CSUsers AS CS
		JOIN	@UsersSeed AS U
		ON		CS.u_user_name = U.u_user_name
	END

	--IF @ServerName = 'BTDEVSQLCLS\REPOSITORY'
	IF Left(@ServerName,2) = 'PE'					--2017-08-25	Bruce Baum - TFS 26573
	BEGIN
		SELECT @UserNamePrefix = 'PT'

		WHILE @BeginID <= @EndID
		BEGIN
			INSERT INTO @UsersSeed VALUES (@UserNamePrefix + RIGHT ('00' + CAST(@BeginID AS VARCHAR(3)), 3))

			SET @BeginID += 1
		END

		INSERT INTO @TestUsers (UserName, UserID, LastActivityDate)
		SELECT	cs.u_user_name, cs.u_user_id, cs.dt_last_activity_date
		FROM	Orders.dbo.CSUsers AS CS
		JOIN	@UsersSeed AS U
		ON		CS.u_user_name = U.u_user_name
	END

	--get baskets from the window
	INSERT INTO @Baskets (BasketSummaryID, BasketOwnerID, BasketLineItemID, BasketLineItemGridID, BTKey, BLIQty, BasketName)
	SELECT	BS.BasketSummaryID, BS.BasketOwnerID, BLI.BasketLineItemID, BLIG.BasketLineItemGridID, BLI.BTKey, BLI.Quantity, BS.BasketName
	FROM	Orders.dbo.BasketSummary AS BS
	JOIN	@TestUsers AS TU
	ON		BS.BasketOwnerID = TU.UserID
	JOIN	Orders.dbo.BasketLineItems AS BLI
	ON		BS.BasketSummaryID = BLI.BasketSummaryIDRedundant 
	LEFT JOIN Orders.dbo.BasketLineItemGrids AS BLIG
	ON		BLI.BasketLineItemID = BLIG.BasketLineItemID
	WHERE	BS.UpdatedDateTime >= @BeginDate
	AND		BS.UpdatedDateTime <= @EndDate

	SELECT	'BasketStats' as ResultDescription
			, U.UserName, U.LastActivityDate, B.BasketName
			, COUNT(DISTINCT B.BTKey) as CountOfLines
	FROM	@Baskets AS B
	JOIN	@TestUsers AS U
	ON		B.BasketOwnerID = U.UserID
	GROUP BY U.UserName, U.LastActivityDate, B.BasketName

	SELECT	DISTINCT 'LineItemDetails' as ResultDescription
			, U.UserName, B.BasketName, B.BTKey, B.BLIQty
	FROM	@Baskets AS B
	JOIN	@TestUsers AS U
	ON		B.BasketOwnerID = U.UserID
	ORDER BY UserName, BasketName, BTKey

	SELECT	DISTINCT 'GridDetails' as ResultDescription
			, U.UserName, B.BasketName, B.BTKey, COUNT(B.BasketLineItemGridID) as GridLineCount
	FROM	@Baskets AS B
	JOIN	@TestUsers AS U
	ON		B.BasketOwnerID = U.UserID
	GROUP BY UserName, BasketName, BTKey

	SELECT	DISTINCT 'GridTemplates' as ResultDescription, GT.Name, GTL.AgencyCodeID, GTL.ItemTypeID, CollectionID, CallNumberText, UserCode1ID, UserCode2ID, UserCode3ID, UserCode4ID, UserCode5ID, UserCode6ID, Quantity, GTL.Sequence
	FROM	Orders.dbo.GridTemplates AS GT
	JOIN	Orders.dbo.UserGridTemplates AS UGT
	ON		GT.GridTemplateID = UGT.GridTemplateID
	JOIN	@TestUsers AS U
	ON		UGT.u_user_id = U.UserID
	JOIN	Orders.dbo.GridTemplateLines AS GTL
	ON		GT.GridTemplateID = GTL.GridTemplateID
	ORDER BY GT.Name, GTL.Sequence

	DECLARE @HoursOffSet INT = DATEDIFF(HOUR, GETDATE(), GETUTCDATE()) * -1
	DECLARE @BeginTimeOffSet DATETIME = DATEADD(hh, @HoursOffSet, @BeginDate)
			, @EndTimeOffSet DATETIME = DATEADD(hh, @HoursOffSet, @EndDate)

	SELECT	ErrorId
			, Application
			, Host
			, Type
			, Source
			, Message
			, [User]
			, StatusCode
			, TimeUtc
			, Sequence
			, CAST(AllXml as XML) as AllXml
	FROM	dbo.ExceptionLog
	WHERE	TimeUTC >= @BeginTimeOffSet
	AND		TimeUTC <= @EndTimeOffSet
	
END
GO
