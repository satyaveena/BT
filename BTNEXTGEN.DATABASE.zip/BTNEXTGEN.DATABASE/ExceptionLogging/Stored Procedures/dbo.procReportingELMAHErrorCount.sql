SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2020-09-10
Description:	Returns for the current date, an hourly count of ELMAH errors
=============================================
*/
CREATE PROCEDURE [dbo].[procReportingELMAHErrorCount]
AS
BEGIN

	SET NOCOUNT ON;

	CREATE TABLE #TempHours (HourOfDay TINYINT)
	CREATE TABLE #tmpTable
	( 
		Host			NVARCHAR(50)
		, Type			NVARCHAR(100)
		, [Source]		NVARCHAR(60)
		, Message		NVARCHAR(MAX)
		, TimeEST		DATETIME
		, Application	NVARCHAR(60)
		, ErrorID		UNIQUEIDENTIFIER
	)

	CREATE TABLE #HourlySummary
	(
		ELMAHErrorCount INT
		, Hour			TINYINT

	)

	DECLARE @StartDateTime	DATETIME2
			, @EndDatetime	DATETIME2
			, @SummaryHTML	VARCHAR(MAX)
			, @recipients	VARCHAR(500) = 'DL-360Tier2Support@baker-taylor.com'

	--hours table
	;WITH HoursTable AS 
	(
	SELECT	0 AS HourNumber
	UNION ALL
	SELECT	HourNumber + 1
	FROM	HoursTable 
	WHERE	HourNumber < DATEPART(HOUR, GETDATE())
	)
	INSERT INTO #TempHours
	SELECT	HoursTable.HourNumber 
	FROM	HoursTable

	SELECT	@StartDateTime = CAST(GETDATE() AS DATE)
			, @EndDateTime = CAST(DATEADD(DAY, 1, GETDATE()) AS DATE)

	--PLEASE DO NOT MAKE ANY CHANGES TO SCRIPT LISTED IN LINE. Call to procReportingELMAHSummary to get data
	INSERT INTO #tmpTable 
	EXEC	dbo.procReportingELMAHSummary @StartDateTime, @EndDateTime, 1, 5000, Null, Time, 1

	INSERT INTO #HourlySummary (ELMAHErrorCount, [Hour])
	SELECT	COUNT(*) AS ELMAHErrorCount, (DATEPART(HOUR, TimeEST)) AS [Hour] 
	FROM	#tmpTable 
	GROUP BY (DATEPART(HOUR, TimeEST))

	SELECT	ISNULL(ELMAHErrorCount, 0) AS ELMAHErrorCount, @StartDateTime AS TodaysDate, TH.HourOfDay AS [Hour]
	FROM	#TempHours AS TH
	LEFT JOIN #HourlySummary AS HS
	ON		TH.HourOfDay = HS.[Hour]
	ORDER BY TH.HourOfDay

	SELECT @SummaryHTML = N'<H2>Hourly ELMAH Counts</H2>' +
				N'<table border="1">' +
				N'<tr>' + 
				N'<th>ELMAHErrorCount</th>' +
				N'<th>TodaysDate</th>' +
				N'<th>Hour</th>' +
				N'</tr>' +
	CAST ((
		SELECT	td = ISNULL(ELMAHErrorCount, 0), SPACE(1),
				td = @StartDateTime, SPACE(1),
				td = TH.HourOfDay, SPACE(1)
			FROM	#TempHours AS TH
			LEFT JOIN #HourlySummary AS HS
			ON		TH.HourOfDay = HS.[Hour]
			ORDER BY TH.HourOfDay
	FOR XML PATH('tr'), TYPE 
	) AS NVARCHAR(MAX) ) +
	N'</table>' ;
		
	EXEC msdb.dbo.sp_send_dbmail
		 @recipients = @recipients
		, @reply_to = 'ProductionNoReply@baker-taylor.com'
		, @subject = 'TS360 ELMAH Hourly Summary'
		, @body = @SummaryHTML
		, @body_format	= 'HTML'

	DROP TABLE #HourlySummary
	DROP TABLE #tmpTable
	DROP TABLE #TempHours

END
GO
