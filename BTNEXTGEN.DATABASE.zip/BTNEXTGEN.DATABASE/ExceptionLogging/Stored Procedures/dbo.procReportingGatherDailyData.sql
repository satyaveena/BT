SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	3/17/2015
Description:	Runs daily and pulls data out of the exception logging table for 

Modifications:
2017-07-18	KG	Modified to pull from view since the logic is going to be shared in a separate report of QA/Dev ELMAH viewing
2017-11-03	KG	Added XML and ErrorID to the history table
=============================================
*/
CREATE PROC [dbo].[procReportingGatherDailyData]
AS
BEGIN
	DECLARE @Yesterday DATETIME = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE)
			, @Today DATETIME = CAST(GETDATE() AS DATE) 

	--Insert yesterday, non timeout messages
	INSERT INTO dbo.ExceptionLogHistory (Host, [Type], [Source], [Message], TimeUtc, ErrorID, AllXml)
	SELECT	Host, [Type], [Source], Message, TimeUtc, ErrorID, AllXml
	FROM	dbo.ExceptionLogReportingNonTimeoutErrors
	WHERE	TimeUtc >= @Yesterday
	AND		TimeUtc < @Today

	--Insert yesteday timeouts
	DECLARE @Temp TABLE (Host NVARCHAR(50), Type NVARCHAR(100), SOurce NVARCHAR(60), AllXML XML, TimeUTC DateTime, ErrorID UNIQUEIDENTIFIER)

	INSERT INTO @Temp
	SELECT	Host, Type, Source, AllXml, TimeUtc, ErrorId
	FROM	dbo.ExceptionLogReportingTimeoutErrors
	WHERE	TimeUtc >= @Yesterday
	AND		TimeUtc < @Today

	INSERT INTO dbo.ExceptionLogHistory (Host, [Type], [Source], [Message], TimeUtc, ErrorID, AllXml)
	SELECT Host, Type, Source, 'Timeout: ' + dbo.udfRemoveELMAHJunk(R.P.value('data(./@detail)[1]', 'NVARCHAR(MAX)')) as Message, TimeUTC, ErrorID, CAST(AllXml AS NVARCHAR(MAX))
	FROM @Temp
	CROSS APPLY AllXml.nodes('error') AS R(p)

	--Dedup primary key temp table violoation messages
	UPDATE	dbo.ExceptionLogHistory
	SET		Message = REPLACE(Message, SUBSTRING(Message, CHARINDEX('PK__#', Message)-2, 33), '')
	WHERE	Message like 'Violation of PRIMARY KEY constraint%'
	AND		Message like '%Cannot insert duplicate key in object%'
	AND		(Message like '%@BasketSummaryIDs%' OR Message like '%@BTKeyCatalogs%' OR Message like '%@BasketOrderForms%' OR Message like '%@DeletedBasketIDs%')
	AND		Message like '%PK__#%'

	--Set the formatted column data 
	UPDATE	dbo.ExceptionLogHistory
	SET		MessageFormatted = REPLACE(REPLACE(Message, CHAR(13), SPACE(0)), CHAR(10), SPACE(0))
	WHERE	MessageFormatted IS NULL

	--Add new items to the TFS table
	INSERT INTO dbo.ExceptionLogTFS ([Type], [Source], [Message], FirstErrorDate)
	SELECT		H.[Type], H.[Source], H.[Message], MIN(TimeUTC)
	FROM		dbo.ExceptionLogHistory as H
	LEFT JOIN	dbo.ExceptionLogTFS AS TFS
	ON			H.[Type] = TFS.[Type]
	AND			H.[Source] = TFS.[Source]
	AND			H.[Message] = TFS.[Message]
	WHERE		TFS.[Type] IS NULL
	AND			H.TimeUtc >= @Yesterday
	AND			H.TimeUtc < @Today
	GROUP BY	H.[Type], H.[Source], H.[Message]
	
END


GO
