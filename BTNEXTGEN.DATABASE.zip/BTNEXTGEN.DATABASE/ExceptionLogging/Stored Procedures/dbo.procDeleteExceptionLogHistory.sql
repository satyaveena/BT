SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[procDeleteExceptionLogHistory]
AS
/*
Modifications:
2013-09-05	KG	Changed to 14 day purge
*/
BEGIN
	DECLARE	@PurgeDate datetime

	SELECT	@PurgeDate = DATEADD(hh, -336, GETDATE())
	    
	DELETE	[ExceptionLogging].[dbo].[ExceptionLog]
	WHERE	TimeUtc < @PurgeDate
  
END

GO
