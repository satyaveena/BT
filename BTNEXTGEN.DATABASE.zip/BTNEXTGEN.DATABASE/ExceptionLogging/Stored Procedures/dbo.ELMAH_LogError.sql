SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ELMAH_LogError]
(
    @ErrorId UNIQUEIDENTIFIER,
    @Application NVARCHAR(60),
    @Host NVARCHAR(30),
    @Type NVARCHAR(100),
    @Source NVARCHAR(60),
    @Message NVARCHAR(500),
    @User NVARCHAR(50),
    @StatusCode INT,
    @TimeUtc DATETIME,
    @Sequence INT = 0, -- 2016-09-05 Dan Cao	PBI #22071
	@AllXml NTEXT
)
AS
/*****************************************************************************************
DEVELOPER:		Elmah
DEV DATE:		
CALLED FROM:	TS360 UI
OVERVIEW:		
MODIFICATION HISTORY:
	2016-09-05 Dan Cao	PBI #22071: Move WCF services to an isolated Web API instances
		- Add new default value for @Sequence
		- Write Log when Farm Cache down

****************************************************************************************/
    SET NOCOUNT ON

    INSERT
    INTO
        [ExceptionLog]
        (
            [ErrorId],
            [Application],
            [Host],
            [Type],
            [Source],
            [Message],
            [User],
            [AllXml],
            [StatusCode],
            [TimeUtc],
            [Sequence]
        )
    VALUES
        (
            @ErrorId,
            @Application,
            @Host,
            @Type,
            @Source,
            @Message,
            @User,
            @AllXml,
            @StatusCode,
            @TimeUtc,
            @Sequence 
        )
       
    -- BEGIN: 2016-09-05 Dan Cao	PBI #22071  
	IF @Message like '%Farm Cache is not available%'
	BEGIN
		DECLARE @HostLog varchar(200)
		Set @HostLog = 'TS360: Farm Cache is not available. HOST: ' + @Host
		
		EXEC msdb.dbo.sp_send_dbmail		
			 @recipients ='bt_app_support_group@csc.com'
			, @reply_to = 'bt_app_support_group@csc.com'		
			, @subject = @HostLog
			, @body = @Message
			, @importance = 'High'
	END
	-- END: 2016-09-05 Dan Cao	PBI #22071  
GO
