SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2018-04-26	
Description:	Updates the ExceptionLogTFS table with the TFS ticket number based on ExceptionLogTFSID
=============================================
*/
CREATE PROCEDURE [dbo].[procReportingSetELMAHTFSNumber]
	@ExceptionLogTFSID	BIGINT
	, @TFSNumber		INT
AS
BEGIN
	SET NOCOUNT ON;

    UPDATE	dbo.ExceptionLogTFS
	SET		TFSTicketNumber = @TFSNumber
	WHERE	ExceptionLogTFSID = @ExceptionLogTFSID

END
GO
