SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



/*
=============================================
Author:			Kelly Gulutz
Create date:	2015-03-20
Description:	SP For ELMAH Reporting

Modifications
2019-02-21	KG	TFS 33739 Change colors Green - Didn't ocurr last week
								 Yellow - First occurrance ever
=============================================
*/
CREATE PROCEDURE [dbo].[procReportingELMAHWeeklyReport_DailyBreakdown]
(
	@StartDate			DATETIME = NULL
	, @EndDate			DATETIME = NULL
	, @UserExperience	BIT = 0
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @MinDate as DATE
			, @MaxDate as DATE
			, @LastWeekStartDate DATETIME
			, @HoursOffSet INT = DATEDIFF(HOUR, GETDATE(), GETUTCDATE())

	IF @StartDate IS NULL
	BEGIN
		SET @StartDate = DATEADD(DAY, -7, CAST(GETDATE() as DATE))
		SET @EndDate = CAST(GETDATE() as DATE)
	END
	ELSE

	--Reset date to midnight
	BEGIN
		SET @StartDate = CAST(@STartDate AS DATE)
		SET @EndDate = CAST(@EndDate AS DATE)
	END

	--Convert the start and end to EST
	SET @StartDate = DATEADD(hh, @HoursOffSet, @StartDate)
	SET @EndDate = DATEADD(hh, @HoursOffSet, @EndDate) --We want to use today so we can use < properly

	--Get the startdate for last week 
	SELECT	@LastWeekStartDate = DATEADD(DAY, -7, @StartDate)

	CREATE TABLE #TempResults 
	(	
		Host NVARCHAR(50)
		, Type NVARCHAR(100)
		, Source NVARCHAR(60)
		, ErrorDate DATE
		, Message NVARCHAR(MAX)
	)

	CREATE TABLE #Counts
	(
		Type NVARCHAR(100)
		, Source NVARCHAR(60)
		, ErrorCount INT
		, ErrorDate DATE
		, Message NVARCHAR(MAX)
	)

	CREATE TABLE #ServerErrors 
	(
		Type				nvarchar(100)
		, Source			nvarchar(60)
		, Servers			varchar(MAX)
		, ErrorDate			date
		, Message			nvarchar(MAX)
		, NewError			bit DEFAULT 0
		, FirstTimeError	bit default 0
	)

	IF @UserExperience = 0
	BEGIN
		INSERT INTO #TempResults
		SELECT	Host, Type, Source, CAST(DATEADD(hh, @HoursOffSet * -1, TimeUTC) AS DATE) as ErrorDate, MessageFormatted
		FROM	dbo.ExceptionLogHistory
		WHERE	TimeUtc >= @StartDate and TimeUtc < @EndDate;
	END
	ELSE
	BEGIN
		INSERT INTO #TempResults
		SELECT	Host, Type, Source, CAST(DATEADD(hh, @HoursOffSet * -1, TimeUTC) AS DATE) as ErrorDate, MessageFormatted
		FROM	dbo.ExceptionLogHistory
		WHERE	TimeUtc >= @StartDate and TimeUtc < @EndDate --GETDATE() converted to UTC so that we're extracting the right times
		AND		DATEPART(hh,  DATEADD(hh, @HoursOffSet, TimeUTC)) BETWEEN 7 and 22 --Converts UTC to EST so that we can do 7am to 10pm
	END

	--Set output dates
	SELECT	@MinDate = MIN(ErrorDate)
			, @MaxDate = MAX(ErrorDate)
	FROM	#TempResults

	INSERT INTO #Counts
	SELECT Type, Source, COUNT(*) as ErrorCount, ErrorDate, Message
	FROM	#TempResults
	GROUP BY Type, Source, ErrorDate, Message;

	WITH HostErrors AS
	(
		SELECT DISTINCT Host, Type, Source, ErrorDate, Message
		FROM #TempResults
	)
	INSERT INTO #ServerErrors (Type, Source, Servers, ErrorDate, Message)
	SELECT A.Type, A.Source, Severs = 
		STUFF((SELECT ', ' + Host
				FROM	HostErrors b 
				WHERE	b.Type = a.Type 
				AND		b.Source = a.Source
				AND		b.ErrorDate = a.ErrorDate
				FOR XML PATH('')), 1, 2, '')
		, A.ErrorDate
		, A.Message
	FROM HostErrors AS A
	GROUP BY A.Type, A.Source, A.ErrorDate, A.Message

	--Update if the error is new since last week
	; WITH LastWeeksErrors AS
	(
		SELECT Host, Type, Source, MessageFormatted as Message
		FROM	dbo.ExceptionLogHistory
		WHERE	TimeUtc >= @LastWeekStartDate and TimeUtc < @StartDate --Use this week's start date as the end date check
	)
	UPDATE	SE
	SET		NewError = 1
	FROM	#ServerErrors AS SE
	LEFT JOIN LastWeeksErrors AS LW
	ON		SE.Type = LW.Type
	AND		SE.Source = LW.Source
	AND		SE.Message = LW.Message
	WHERE	LW.Source IS NULL

	--Update if this is the first time ever for the error.
	; with FirstTimeError as
    (
		select	host, type, source, MessageFormatted as Message
		from	dbo.ExceptionLogHistory
		where	TimeUtc < @LastWeekStartDate
	)
	update	se
	set		SE.FirstTimeError = 1
	from	#ServerErrors as SE
	left join FirstTimeError as FT
	on		SE.Type = FT.Type
	and		SE.Source = FT.Source
	and		SE.Message = FT.Message
	where	FT.Source is null

	SELECT	SE.Type 
			, SE.Source 
			, SE.Servers
			, SE.ErrorDate
			, SE.Message 
			, C.ErrorCount
			, @MinDate as MinDate
			, @MaxDate as MaxDate
			, SE.NewError
			, SE.FirstTimeError
	FROM	#ServerErrors AS SE
	JOIN	#Counts AS C
	ON		SE.Type = C.Type
	AND		SE.Source = C.Source
	AND		SE.ErrorDate = C.ErrorDate
	AND		SE.Message = C.Message

	DROP TABLE #Counts
	DROP TABLE #ServerErrors
	DROP TABLE #TempResults
END

GO
