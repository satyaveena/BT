SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


/*
=============================================
Author:			Kelly Gulutz
Create date:	2015-03-20
Description:	SP For ELMAH Reporting

Modifications:
2017-11-07	KG	1. Added ErrorID to result set
				2. Combined regular and UserExperience into 1 report with a UE flag
				3. Changed to temp tables from table variables for performance
2019-02-21	KG	TFS 33739
				1. Add TFS state
				2. Add TFSID
				3. Change colors Green - Didn't ocurr last week
								 Yellow - First occurrance ever
=============================================
*/
CREATE procedure [dbo].[procReportingELMAHWeeklyReport]
(
	@StartDate			datetime = null
	, @EndDate			datetime = null
	, @UserExperience	bit = 0
)
as
begin
	SET NOCOUNT ON;

	DECLARE @LastWeekStartDate DATETIME
			, @HoursOffSet INT = DATEDIFF(HOUR, GETDATE(), GETUTCDATE())

	IF @StartDate IS NULL
	BEGIN
		SET @StartDate = DATEADD(DAY, -7, CAST(GETDATE() as DATE))
		set @EndDate = cast(getdate() as date)
	end
	else
	--Reset date to midnight
	begin
		SET @StartDate = CAST(@STartDate AS DATE)
		set @EndDate = cast(@EndDate as date)
	end

	--Convert the start and end to EST
	SET @StartDate = DATEADD(hh, @HoursOffSet, @StartDate)
	SET @EndDate = DATEADD(hh, @HoursOffSet, @EndDate) --We want to use today so we can use < properly

	--Get the startdate for last week 
	SELECT	@LastWeekStartDate = DATEADD(DAY, -7, @StartDate)

	CREATE TABLE #TempResults 
	(	
		Host		NVARCHAR(50)
		, Type		NVARCHAR(100)
		, Source	NVARCHAR(60)
		, Message	NVARCHAR(MAX)
		, ErrorID	UNIQUEIDENTIFIER
	)

	CREATE TABLE #Counts 
	(		
		Type		NVARCHAR(100)
		, Source	NVARCHAR(60)
		, Message	NVARCHAR(MAX)
		, ErrorCount INT
	)
	
	CREATE TABLE #ServerErrors
	(
		Type				NVARCHAR(100)
		, Source			NVARCHAR(60)
		, Message			NVARCHAR(MAX)
		, Servers			VARCHAR(500)
		, NewError			BIT DEFAULT 0
		, ErrorID			uniqueidentifier
        , FirstTimeError	bit default 0
	)

	IF @UserExperience = 0
	BEGIN
		INSERT INTO #TempResults (HOst, Type, Source, Message, ErrorID)
		SELECT Host, Type, Source, MessageFormatted, ErrorID
		FROM dbo.ExceptionLogHistory
		WHERE TimeUtc >= @StartDate and TimeUtc < @EndDate;
	END
	else
	begin
		insert into #TempResults
		select	Host, Type, Source, MessageFormatted, ErrorID
		from	dbo.ExceptionLogHistory
		where	TimeUtc >= @StartDate and TimeUtc < @EndDate
		and		datepart(hh,  dateadd(hh, @HoursOffSet, TimeUTC)) between 7 and 22; --Converts UTC to EST so that we can do 7am to 10pm
	end
	--Get counts
	INSERT INTO #Counts
	SELECT Type, Source, Message, COUNT(*) as ErrorCount
	FROM #TempResults
	GROUP BY Type, Source, Message;

	;WITH HostErrors AS
	(
		SELECT DISTINCT Host, Type, Source, Message
		FROM #TempResults
	)
	INSERT INTO #ServerErrors (Type, Source, Message, Servers)
	SELECT A.Type, A.Source, A.Message, Severs = 
		STUFF((SELECT ', ' + Host
				FROM	HostErrors b 
				WHERE	b.Type = a.Type 
				AND		b.Source = a.Source
				AND		b.Message = a.Message
				FOR XML PATH('')), 1, 2, '')
	FROM HostErrors AS A
	GROUP BY A.Type, A.Source, A.Message
	
	--Update if the error is new since last week
	; with LastWeeksErrors as
	(
		select	Host, Type, Source, MessageFormatted as Message
		from	dbo.ExceptionLogHistory
		where	TimeUtc >= @LastWeekStartDate 
		and		TimeUtc < @StartDate --Use this week's start date as the end date check
	)
	update	SE
	set		NewError = 1
	from	#ServerErrors as SE
	left join LastWeeksErrors as LW
	on		SE.Type = LW.Type
	and		SE.Source = LW.Source
	and		SE.Message = LW.Message
	where	LW.Source is null

	--Update if this is the first time ever for the error.
	; with FirstTimeError as
    (
		select	host, type, source, MessageFormatted as Message
		from	dbo.ExceptionLogHistory
		where	TimeUtc < @LastWeekStartDate
	)
	update	se
	set		SE.FirstTimeError = 1
	from	#ServerErrors as SE
	left join FirstTimeError as FT
	on		SE.Type = FT.Type
	and		SE.Source = FT.Source
	and		SE.Message = FT.Message
	where	FT.Source is null

	--MaxError ID
	; with MaxErrorID as
	(
		select	Type, Source, Message, max(cast(ErrorID as varchar(50))) as MaxErrorID
		from	#TempResults
		group by Type, Source, Message
	)
	update	SE
	set		ErrorID = MaxErrorID
	from	#ServerErrors as SE
	join	MaxErrorID as M
	on		SE.Type = M.Type
	and		SE.Source = M.Source
	and		SE.Message = M.Message

	--Return data
	select	SE.Type, SE.Source, SE.Message, SE.Servers, SE.NewError, SE.ErrorID, SE.FirstTimeError	
			, C.ErrorCount, TFS.TFSTicketNumber, TFS.Comments, TFS.Priority, TFS.DeploymentStatus, TFS.ReleasePath, TFS.State, TFS.ExceptionLogTFSID
	from	#ServerErrors as SE
	join	#Counts as C
	on		SE.Type = C.Type
	and		SE.Source = C.Source
	and		SE.Message = C.Message
	left join dbo.ExceptionLogTFS as TFS
	on		SE.Type = TFS.Type
	and		SE.Source = TFS.Source
	and		SE.Message = TFS.Message

	drop table #TempResults
	drop table #Counts
	drop table #ServerErrors
end

GO
