SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-07-18
Description:	View to be used for non timeout errors
				procReportingGatherDailyData
				procReportingELMAHSummary
				procReportingELMAHDetail

**********IF YOU MAKE ANY CHANGES HERE COPY THEM TO ExceptionLogReportingTimeoutErrors_History
=============================================
*/
CREATE VIEW [dbo].[ExceptionLogReportingTimeoutErrors]
AS
	SELECT	Host, Type, Source, CAST(AllXml AS XML) as AllXML, TimeUtc, Application, ErrorId
	FROM	dbo.ExceptionLog WITH (NOLOCK)
	WHERE	Message like '%timeout%'
	AND		Type IN ('System.Data.SqlClient.SqlException', 'BTNextGen.Grid.Exception.CartGridLoadFailedException')
	AND		Source IN ('.Net SqlClient Data Provider', 'Catalog: BTNextGen.Grid')
GO
