SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



/*
=============================================
Author:			Kelly Gulutz
Create date:	2018-01-09
Description:	Copied from ExceptionLogReportingTimeoutErrors, removed application id
				View to be used for non timeout errors
				procReportingELMAHSummary_History
				procReportingELMAHDetail_History
=============================================
*/
CREATE VIEW [dbo].[ExceptionLogReportingTimeoutErrors_History]
AS
	SELECT	Host, Type, Source, CAST(AllXml AS XML) as AllXML, TimeUtc, ErrorId
	FROM	dbo.ExceptionLogHistory WITH (NOLOCK)
	WHERE	Message like '%timeout%'
	AND		Type IN ('System.Data.SqlClient.SqlException', 'BTNextGen.Grid.Exception.CartGridLoadFailedException')
	AND		Source IN ('.Net SqlClient Data Provider', 'Catalog: BTNextGen.Grid')
GO
