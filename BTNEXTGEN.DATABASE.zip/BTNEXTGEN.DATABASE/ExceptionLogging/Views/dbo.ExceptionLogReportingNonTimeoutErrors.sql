SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


/*
=============================================
Author:			Kelly Gulutz
Create date:	2017-07-18
Description:	View to be used for non timeout errors
				procReportingGatherDailyData
				procReportingELMAHSummary
				procReportingELMAHDetail
*****IF YOU MAKE ANY CHANGES HERE COPY THEM TO ExceptionLogReportingNonTimeoutErrors_History
=============================================
*/
CREATE    VIEW [dbo].[ExceptionLogReportingNonTimeoutErrors]  
WITH SCHEMABINDING
AS  
SELECT 
	base.[Host]
	,base.[Type]
	,base.[Source]
	,base.[Message]
	,base.[TimeUtc]
	,base.[Application]
	,base.[ErrorId]
	,el.[Allxml]
FROM dbo.[ExceptionLogReportingNonTimeoutErrors_Base] base inner join dbo.ExceptionLog  el on base.ErrorID = el.ErrorId
 

GO
