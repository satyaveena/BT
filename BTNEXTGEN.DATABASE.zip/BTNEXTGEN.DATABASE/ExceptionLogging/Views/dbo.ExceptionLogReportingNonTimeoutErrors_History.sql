SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



/*
=============================================
Author:			Kelly Gulutz
Create date:	2018-01-09
Description:	Copied from ExceptionLogReportingNonTimeoutErrors for use with history stored procedures
				View to be used for non timeout errors
				procReportingELMAHSummary_History
				procReportingELMAHDetail_History
=============================================
*/
CREATE VIEW [dbo].[ExceptionLogReportingNonTimeoutErrors_History]
AS
	SELECT	Host, [Type]
			, [Source]
			, dbo.udfRemoveDuplicateKeyValueMessage(REPLACE(REPLACE(CASE WHEN CHARINDEX('(Process ID', [Message]) <> 0 THEN  REPLACE([Message], SUBSTRING ([Message],
						 CHARINDEX('(Process ID', [Message]), --First parenthesis
						 CHARINDEX(')', [Message], CHARINDEX('(Process ID', [Message])) - CHARINDEX('(Process ID', [Message]) + 1
						 ), '') ELSE [Message] END, CHAR(13), ''), CHAR(10), '')) as Message
			, TimeUtc
			, ErrorId
			, AllXml
	FROM	dbo.ExceptionLogHistory
	WHERE	NOT ([Message] like '%timeout%' AND [Type] = 'System.Data.SqlClient.SqlException' AND [Source] = '.Net SqlClient Data Provider')
	AND		NOT ([Message] like '%timeout%' AND [Type] = 'BTNextGen.Grid.Exception.CartGridLoadFailedException' AND [Source] = 'Catalog: BTNextGen.Grid')
	AND		NOT ([Source] LIKE '%Debug%')
	AND		NOT ([Message] LIKE '%BTKEY%' AND [Message] LIKE '%is not in cache%')
GO
