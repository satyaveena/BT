USE [ExceptionLogging]
GO

/****** Object:  View [dbo].[ExceptionLogReportingNonTimeoutErrors_Base]    Script Date: 12/20/2022 11:24:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[ExceptionLogReportingNonTimeoutErrors_Base]
WITH SCHEMABINDING
AS  
 SELECT Host, [Type]  
   , CASE WHEN Type = 'Stored procedure catch error' THEN Application ELSE [Source] END as [Source]  
   , dbo.[udfRemoveDuplicateKeyValueMessage](REPLACE(REPLACE(CASE WHEN CHARINDEX('(Process ID', [Message]) <> 0 THEN  REPLACE([Message], SUBSTRING ([Message],  
       CHARINDEX('(Process ID', [Message]), --First parenthesis  
       CHARINDEX(')', [Message], CHARINDEX('(Process ID', [Message])) - CHARINDEX('(Process ID', [Message]) + 1  
       ), '') ELSE [Message] END, CHAR(13), ''), CHAR(10), '')) as Message  
   , TimeUtc  
   , Application  
	, ErrorId     
 FROM dbo.ExceptionLog  
 WHERE NOT ([Message] like '%timeout%' AND [Type] = 'System.Data.SqlClient.SqlException' AND [Source] = '.Net SqlClient Data Provider')  
 AND  NOT ([Message] like '%timeout%' AND [Type] = 'BTNextGen.Grid.Exception.CartGridLoadFailedException' AND [Source] = 'Catalog: BTNextGen.Grid')  
 AND  NOT ([Source] LIKE '%Debug%')  
 AND  NOT ([Message] LIKE '%BTKEY%' AND [Message] LIKE '%is not in cache%')  
 

GO



/****** Object:  Index [PK_ExceptionLogReportingNonTimeoutErrors_ErrorId]    Script Date: 12/20/2022 11:33:30 AM ******/
CREATE UNIQUE CLUSTERED INDEX [PK_ExceptionLogReportingNonTimeoutErrors_ErrorId] ON [dbo].[ExceptionLogReportingNonTimeoutErrors_Base]
(
	[ErrorId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [Data1]
GO


/****** Object:  Index [NCI_ExceptionLogReportingNonTimeoutErrors_TimeUtc]    Script Date: 12/20/2022 11:33:23 AM ******/
CREATE NONCLUSTERED INDEX [NCI_ExceptionLogReportingNonTimeoutErrors_TimeUtc] ON [dbo].[ExceptionLogReportingNonTimeoutErrors_Base]
(
	[TimeUtc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [Data1]
GO


