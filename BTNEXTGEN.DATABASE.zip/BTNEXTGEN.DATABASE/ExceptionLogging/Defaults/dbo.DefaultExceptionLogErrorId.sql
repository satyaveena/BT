SET QUOTED_IDENTIFIER OFF
GO
CREATE DEFAULT [dbo].[DefaultExceptionLogErrorId]
	AS newid()
GO
