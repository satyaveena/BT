CREATE TABLE [dbo].[ExceptionLog]
(
[ErrorId] [uniqueidentifier] NOT NULL,
[Application] [nvarchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Host] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Source] [nvarchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[User] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[StatusCode] [int] NOT NULL,
[TimeUtc] [datetime] NOT NULL,
[Sequence] [int] NOT NULL,
[AllXml] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [Data1]
GO
ALTER TABLE [dbo].[ExceptionLog] ADD CONSTRAINT [PK_ExceptionLog] PRIMARY KEY NONCLUSTERED  ([ErrorId]) ON [Data1]
GO
CREATE NONCLUSTERED INDEX [ix1] ON [dbo].[ExceptionLog] ([TimeUtc]) ON [Data1]
GO
EXEC sp_bindefault N'[dbo].[DefaultExceptionLogErrorId]', N'[dbo].[ExceptionLog].[ErrorId]'
GO
