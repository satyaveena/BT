CREATE TABLE [dbo].[MissingIndexes]
(
[improvement_measure] [float] NULL,
[TableName] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Columns] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IncludeStatement] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[user_seeks] [bigint] NULL,
[last_user_seek] [datetime] NULL,
[user_scans] [bigint] NULL,
[last_user_scan] [datetime] NULL,
[CreatedDate] [date] NULL,
[ExcludeFromReport] [bit] NULL CONSTRAINT [DF__MissingIndexes_ExcludeFromReport] DEFAULT ((0))
) ON [Data1] TEXTIMAGE_ON [Data1]
GO
