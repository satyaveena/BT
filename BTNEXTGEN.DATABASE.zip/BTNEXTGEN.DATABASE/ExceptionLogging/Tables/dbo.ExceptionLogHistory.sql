CREATE TABLE [dbo].[ExceptionLogHistory]
(
[ExceptionLogHistoryID] [bigint] NOT NULL IDENTITY(1, 1),
[Host] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Type] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Source] [nvarchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TimeUtc] [datetime] NOT NULL,
[Hours] [int] NULL,
[ErrorID] [uniqueidentifier] NULL,
[AllXml] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MessageFormatted] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [Data1] TEXTIMAGE_ON [Data1]
GO
ALTER TABLE [dbo].[ExceptionLogHistory] ADD CONSTRAINT [PK_ExceptionLogHistory] PRIMARY KEY NONCLUSTERED  ([ExceptionLogHistoryID]) ON [Data1]
GO
CREATE NONCLUSTERED INDEX [IX_ExceptionLoggingHistory_TimeUTC] ON [dbo].[ExceptionLogHistory] ([TimeUtc]) ON [Data1]
GO
CREATE NONCLUSTERED INDEX [IX_ExceptionLoggingHistory_TimeUTC_IncludeTypeSourceMsg] ON [dbo].[ExceptionLogHistory] ([TimeUtc]) INCLUDE ([Message], [Source], [Type]) ON [Data1]
GO
CREATE NONCLUSTERED INDEX [IX_ExceptionLoggingHistory_TypeSourceTime_IncludeMsg] ON [dbo].[ExceptionLogHistory] ([Type], [Source], [TimeUtc]) INCLUDE ([Message]) ON [Data1]
GO
