CREATE TABLE [dbo].[ExceptionLogTFS]
(
[ExceptionLogTFSID] [bigint] NOT NULL IDENTITY(1, 1),
[Type] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Source] [nvarchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TFSTicketNumber] [int] NULL,
[Comments] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FirstErrorDate] [datetime] NULL,
[Priority] [smallint] NULL,
[DeploymentStatus] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReleasePath] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AssignedTo] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [Data1]
GO
ALTER TABLE [dbo].[ExceptionLogTFS] ADD CONSTRAINT [PK_ExceptionLogTFS] PRIMARY KEY CLUSTERED  ([ExceptionLogTFSID]) ON [Data1]
GO
