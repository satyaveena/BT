CREATE TABLE [dbo].[LongRunningQueries]
(
[SPName] [sys].[sysname] NULL,
[TotalWorkerTime] [bigint] NULL,
[AvgWorkerTime] [bigint] NULL,
[ExecutionCount] [bigint] NULL,
[CallsPerSecond] [bigint] NULL,
[TotalElapsedTime] [bigint] NULL,
[AvgElapsedTime] [bigint] NULL,
[CachedTime] [datetime] NULL,
[DB] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedDate] [date] NULL
) ON [Data1]
GO
