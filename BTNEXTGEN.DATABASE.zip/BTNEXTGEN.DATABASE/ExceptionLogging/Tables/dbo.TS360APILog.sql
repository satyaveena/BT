CREATE TABLE [dbo].[TS360APILog]
(
[LogRequestId] [uniqueidentifier] NOT NULL,
[WebMethod] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RequestMessage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ResponseMessage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[VendorAPIKey] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedOn] [datetime2] NULL,
[CreatedBy] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExceptionMessage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [Data1]
GO
ALTER TABLE [dbo].[TS360APILog] ADD CONSTRAINT [PK_APILog] PRIMARY KEY CLUSTERED  ([LogRequestId]) ON [Data1]
GO
