CREATE TABLE [dbo].[SystemProps]
(
[i_ApplicationID] [int] NULL,
[s_Name] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_ClassName] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[s_ResourceType] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[s_Description] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[f_ResourceFlags] [int] NULL,
[f_PupFlags] [int] NOT NULL,
[s_RefResource] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_MachineName] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[i_Status] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_ProgidSnapin] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_ProgidPUP] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_PUPParam1] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_PUPParam2] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_PUPParam3] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SystemProps] ADD CONSTRAINT [PK_SystemProps] PRIMARY KEY CLUSTERED  ([s_ResourceType]) ON [PRIMARY]
GO
GRANT SELECT ON  [dbo].[SystemProps] TO [admin_commerceAdministrator_role]
GO
