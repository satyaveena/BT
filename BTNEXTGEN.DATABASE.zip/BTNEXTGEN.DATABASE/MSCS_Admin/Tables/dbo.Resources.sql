CREATE TABLE [dbo].[Resources]
(
[i_ResourceID] [int] NOT NULL IDENTITY(1, 1),
[s_DisplayName] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[s_Description] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Des__03317E3D] DEFAULT (''),
[s_Type] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[f_IsGlobal] [bit] NULL CONSTRAINT [DF__Resources__f_IsG__0425A276] DEFAULT ((0)),
[f_ResourceFlags] [int] NULL CONSTRAINT [DF__Resources__f_Res__0519C6AF] DEFAULT ((0)),
[s_ProgIDSnapIn] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Pro__060DEAE8] DEFAULT (''),
[s_Computer] [nvarchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Com__07020F21] DEFAULT (''),
[i_Status] [int] NULL CONSTRAINT [DF__Resources__i_Sta__07F6335A] DEFAULT ((0)),
[f_PupFlags] [int] NULL CONSTRAINT [DF__Resources__f_Pup__08EA5793] DEFAULT ((0)),
[s_ProgIDPUP] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Pro__09DE7BCC] DEFAULT (''),
[s_PupParam1] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Pup__0AD2A005] DEFAULT (''),
[s_PupParam2] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Pup__0BC6C43E] DEFAULT (''),
[s_PupParam3] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Resources__s_Pup__0CBAE877] DEFAULT ('')
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Resources] ADD CONSTRAINT [PK_Resources] PRIMARY KEY NONCLUSTERED  ([i_ResourceID]) ON [PRIMARY]
GO
GRANT DELETE ON  [dbo].[Resources] TO [admin_commerceAdministrator_role]
GO
GRANT INSERT ON  [dbo].[Resources] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[Resources] TO [admin_commerceAdministrator_role]
GO
GRANT UPDATE ON  [dbo].[Resources] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[Resources] TO [admin_reader_role]
GO
