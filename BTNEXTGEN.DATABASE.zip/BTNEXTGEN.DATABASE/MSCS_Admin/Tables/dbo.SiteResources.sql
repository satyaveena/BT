CREATE TABLE [dbo].[SiteResources]
(
[i_SiteID] [int] NOT NULL,
[i_ResourceID] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SiteResources] ADD CONSTRAINT [PK_SiteResources] PRIMARY KEY NONCLUSTERED  ([i_SiteID], [i_ResourceID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SiteResources] WITH NOCHECK ADD CONSTRAINT [FK_SiteResources_Resources] FOREIGN KEY ([i_ResourceID]) REFERENCES [dbo].[Resources] ([i_ResourceID])
GO
ALTER TABLE [dbo].[SiteResources] WITH NOCHECK ADD CONSTRAINT [FK_SiteResources_Sites] FOREIGN KEY ([i_SiteID]) REFERENCES [dbo].[Sites] ([i_SiteID])
GO
GRANT DELETE ON  [dbo].[SiteResources] TO [admin_commerceAdministrator_role]
GO
GRANT INSERT ON  [dbo].[SiteResources] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[SiteResources] TO [admin_commerceAdministrator_role]
GO
GRANT UPDATE ON  [dbo].[SiteResources] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[SiteResources] TO [admin_reader_role]
GO
