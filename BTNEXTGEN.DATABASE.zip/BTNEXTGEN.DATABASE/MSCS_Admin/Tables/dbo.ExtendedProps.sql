CREATE TABLE [dbo].[ExtendedProps]
(
[s_ResourceType] [nvarchar] (194) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[s_PropertyName] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[f_IsConnStr] [bit] NOT NULL,
[f_IsHidden] [bit] NOT NULL,
[f_IsSimpleList] [bit] NOT NULL,
[s_Description] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[i_Vartype] [int] NULL,
[s_Value] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_DisplayName] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ExtendedProps] ADD CONSTRAINT [PK_ExtendedProps] PRIMARY KEY CLUSTERED  ([s_ResourceType], [s_PropertyName]) ON [PRIMARY]
GO
GRANT SELECT ON  [dbo].[ExtendedProps] TO [admin_commerceAdministrator_role]
GO
