CREATE TABLE [dbo].[Sites]
(
[i_SiteID] [int] NOT NULL IDENTITY(1, 1),
[s_Name] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[s_Description] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF__Sites__s_Descrip__7E6CC920] DEFAULT (''),
[i_Status] [int] NOT NULL,
[d_DateCreated] [datetime] NULL CONSTRAINT [DF__Sites__d_DateCre__7F60ED59] DEFAULT (getdate()),
[d_DateModified] [datetime] NULL CONSTRAINT [DF__Sites__d_DateMod__00551192] DEFAULT (getdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Sites] ADD CONSTRAINT [PK_Sites] PRIMARY KEY NONCLUSTERED  ([i_SiteID]) ON [PRIMARY]
GO
GRANT DELETE ON  [dbo].[Sites] TO [admin_commerceAdministrator_role]
GO
GRANT INSERT ON  [dbo].[Sites] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[Sites] TO [admin_commerceAdministrator_role]
GO
GRANT UPDATE ON  [dbo].[Sites] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[Sites] TO [admin_reader_role]
GO
