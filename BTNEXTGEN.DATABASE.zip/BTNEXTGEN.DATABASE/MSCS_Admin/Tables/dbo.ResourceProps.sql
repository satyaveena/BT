CREATE TABLE [dbo].[ResourceProps]
(
[i_ResourceID] [int] NOT NULL,
[s_PropertyName] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[f_IsConnStr] [bit] NULL CONSTRAINT [DF__ResourceP__f_IsC__0EA330E9] DEFAULT ((0)),
[f_IsHidden] [bit] NULL CONSTRAINT [DF__ResourceP__f_IsH__0F975522] DEFAULT ((0)),
[f_IsSimpleList] [bit] NULL CONSTRAINT [DF__ResourceP__f_IsS__108B795B] DEFAULT ((0)),
[s_Description] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[i_Vartype] [int] NOT NULL,
[s_Value] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[s_DisplayName] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ResourceProps] ADD CONSTRAINT [PK_ResourceProps] PRIMARY KEY NONCLUSTERED  ([i_ResourceID], [s_PropertyName]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ResourceProps] WITH NOCHECK ADD CONSTRAINT [FK_ResourceProps_Resources] FOREIGN KEY ([i_ResourceID]) REFERENCES [dbo].[Resources] ([i_ResourceID])
GO
GRANT DELETE ON  [dbo].[ResourceProps] TO [admin_commerceAdministrator_role]
GO
GRANT INSERT ON  [dbo].[ResourceProps] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[ResourceProps] TO [admin_commerceAdministrator_role]
GO
GRANT UPDATE ON  [dbo].[ResourceProps] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[ResourceProps] TO [admin_reader_role]
GO
