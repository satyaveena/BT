CREATE TABLE [dbo].[pupdbscripts]
(
[i_SiteID] [int] NOT NULL,
[i_ResourceID] [int] NOT NULL,
[u_scriptname] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[txt_script] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[pupdbscripts] ADD CONSTRAINT [PK__pupdbscr__7ED35F041DE57479] PRIMARY KEY NONCLUSTERED  ([i_SiteID], [i_ResourceID], [u_scriptname]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[pupdbscripts] ADD CONSTRAINT [FK__pupdbscri__i_Res__20C1E124] FOREIGN KEY ([i_ResourceID]) REFERENCES [dbo].[Resources] ([i_ResourceID])
GO
ALTER TABLE [dbo].[pupdbscripts] ADD CONSTRAINT [FK__pupdbscri__i_Sit__1FCDBCEB] FOREIGN KEY ([i_SiteID]) REFERENCES [dbo].[Sites] ([i_SiteID])
GO
GRANT DELETE ON  [dbo].[pupdbscripts] TO [admin_commerceAdministrator_role]
GO
GRANT INSERT ON  [dbo].[pupdbscripts] TO [admin_commerceAdministrator_role]
GO
GRANT SELECT ON  [dbo].[pupdbscripts] TO [admin_commerceAdministrator_role]
GO
GRANT UPDATE ON  [dbo].[pupdbscripts] TO [admin_commerceAdministrator_role]
GO
