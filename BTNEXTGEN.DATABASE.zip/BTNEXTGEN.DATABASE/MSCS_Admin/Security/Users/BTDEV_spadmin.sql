IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'BTDEV\spadmin')
CREATE LOGIN [BTDEV\spadmin] FROM WINDOWS
GO
CREATE USER [BTDEV\spadmin] FOR LOGIN [BTDEV\spadmin]
GO
