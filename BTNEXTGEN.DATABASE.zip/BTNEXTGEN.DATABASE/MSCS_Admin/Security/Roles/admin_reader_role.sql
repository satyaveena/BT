CREATE ROLE [admin_reader_role]
AUTHORIZATION [dbo]
GO
EXEC sp_addrolemember N'admin_reader_role', N'BTDEV\spadmin'
GO
