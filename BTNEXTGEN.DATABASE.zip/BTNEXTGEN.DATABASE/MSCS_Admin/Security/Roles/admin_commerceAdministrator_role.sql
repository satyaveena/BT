CREATE ROLE [admin_commerceAdministrator_role]
AUTHORIZATION [dbo]
GO
