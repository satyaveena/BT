SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[proc_insert_pupdbscript]
  (@site nvarchar(256),
  @resource nvarchar(256),
  @scriptname nvarchar(256),
  @script ntext)
  
AS 
  declare @localized_string_errstr1 NVARCHAR(128)
  set @localized_string_errstr1  = N'Site %s does not exist'

  declare @localized_string_errstr2 NVARCHAR(128)
  set @localized_string_errstr2  = N'Resource %s does not exist in site %s.'

  DECLARE @site_id int,
    @res_id int

  SET NOCOUNT ON

  SELECT @site_id = (SELECT i_SiteID FROM Sites WHERE s_Name = @site)
  IF @site_id IS NULL
  BEGIN
    RAISERROR (@localized_string_errstr1,  16, 1, @site)
    GOTO done
  END
    
  SELECT @res_id = (SELECT R.i_ResourceID FROM Resources AS R
        INNER JOIN SiteResources SR ON R.i_ResourceID = SR.i_ResourceID
        WHERE R.s_DisplayName = @resource AND SR.i_SiteID = @site_id)
  IF @res_id IS NULL
  BEGIN
    RAISERROR (@localized_string_errstr2,  16, 1, @resource, @site)
    GOTO done
  END

  DELETE FROM pupdbscripts WHERE i_SiteID=@site_id AND i_ResourceID=@res_id AND u_scriptname=@scriptname

  INSERT INTO pupdbscripts (i_SiteID, i_ResourceID, u_scriptname, txt_script) VALUES (@site_id, @res_id, @scriptname, @script)

  done: 
GO
GRANT EXECUTE ON  [dbo].[proc_insert_pupdbscript] TO [admin_commerceAdministrator_role]
GO
