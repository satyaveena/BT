SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[proc_delete_pupdbscript]
  (@site nvarchar(256),
  @resource nvarchar(256),
  @scriptname nvarchar(256))
  
AS 

  declare @localized_string_errstr5 NVARCHAR(128)
  set @localized_string_errstr5  = N'Site %s does not exist'

  declare @localized_string_errstr6 NVARCHAR(128)
  set @localized_string_errstr6  = N'Resource %s does not exist in site %s.'

  DECLARE @site_id int,
    @res_id int

  SET NOCOUNT ON

  SELECT @site_id = (SELECT i_SiteID FROM Sites WHERE s_Name = @site)
  IF @site_id IS NULL
  BEGIN
    RAISERROR (@localized_string_errstr5,  16, 1, @site)
    GOTO done
  END
    
  SELECT @res_id = (SELECT R.i_ResourceID FROM Resources AS R
        INNER JOIN SiteResources SR ON R.i_ResourceID = SR.i_ResourceID
        WHERE R.s_DisplayName = @resource AND SR.i_SiteID = @site_id)
  IF @res_id IS NULL
  BEGIN
    RAISERROR (@localized_string_errstr6,  16, 1, @resource, @site)
    GOTO done
  END
  
  SET NOCOUNT OFF
  DELETE FROM pupdbscripts WHERE i_SiteID=@site_id AND i_ResourceID=@res_id AND u_scriptname=@scriptname

  done: 
GO
GRANT EXECUTE ON  [dbo].[proc_delete_pupdbscript] TO [admin_commerceAdministrator_role]
GO
