SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- procedure to create the resource property definitions by inserting a row in ExtendedProps 
-- only inserts the property if it isnt already defined
-- raises error if the resource is not defined in systemprops
CREATE PROCEDURE [dbo].[proc_insert_extended_property]
  (
    @resourceType       nvarchar(194),
    @propertyName       nvarchar(256),
    @isConnectionString bit,
    @isHidden           bit,
    @isSimpleList       bit,
    @description        nvarchar(512) = NULL,
    @varType            int = NULL,
    @value              ntext = NULL,
    @displayName        nvarchar(64) = NULL
  )
AS
  declare @localized_string_Proc_Insert_Extended_Property_Error_Message NVARCHAR(512)
  set @localized_string_Proc_Insert_Extended_Property_Error_Message = N'Microsoft Commerce Server: Resource Type %s is not defined. Property %s could not be created'

  if not exists (select '*' from SystemProps where (SystemProps.s_ResourceType = @resourceType))
    RAISERROR (@localized_string_Proc_Insert_Extended_Property_Error_Message, 16, 1, @resourceType, @propertyName)
  if exists (select '*' from ExtendedProps where (ExtendedProps.s_ResourceType = @resourceType) AND (ExtendedProps.s_PropertyName = @propertyName))
    return 0
  else
    insert into 
      ExtendedProps (s_ResourceType, s_PropertyName, f_IsConnStr,         f_IsHidden, f_IsSimpleList, i_Vartype, s_Value, s_Description,  s_DisplayName) 
      VALUES        (@resourceType,  @propertyName,  @isConnectionString, @isHidden,  @isSimpleList,  @varType,  @value,  @description,   @displayName)
        
  return 0
GO
