SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[proc_check_admin_version]
AS
  -- must set nocount otherwise ado reads the rowcounts into the recordset and things go awry
  SET NOCOUNT ON

  DECLARE @obsoleteResources TABLE (type nvarchar(20))
  DECLARE @migratableResources TABLE (type nvarchar(20), version nvarchar(10))
  
  DECLARE @version AS nvarchar(10)
  DECLARE @admin_versions_table TABLE ( [s_Category] nvarchar(32), [s_ResourceType] nvarchar(256), [s_Value] ntext)
  
  INSERT INTO @obsoleteResources SELECT 'BDSecurity'
  INSERT INTO @obsoleteResources SELECT 'Campaigns'
  INSERT INTO @obsoleteResources SELECT 'Predictor'
  INSERT INTO @obsoleteResources SELECT 'Predictor_Site'
  
  INSERT INTO @migratableResources SELECT 'Catalog', '7.4.0'
  INSERT INTO @migratableResources SELECT 'Inventory', '7.3.0'
  INSERT INTO @migratableResources SELECT 'Marketing', '7.1.0'
  INSERT INTO @migratableResources SELECT 'Transactions', '7.1.0'
  INSERT INTO @migratableResources SELECT 'TransactionConfig', '7.1.0'
  INSERT INTO @migratableResources SELECT 'DataWarehouse_Group', '6.1.0'
   
  -- check that admin schema is valid 
  IF NOT EXISTS(SELECT '*' FROM Sites WHERE i_SiteID = 0)
    INSERT INTO @admin_versions_table
      SELECT 'Invalid Schema', 'Default Group', 'The Global Resources Container' 

  -- check admin schema version
  SELECT @version = CAST(s_Description AS nvarchar(10)) FROM SystemProps 
    WHERE (s_Name LIKE '' AND s_ResourceType LIKE 'Version' AND s_ClassName LIKE 'MSCS_Version')
  IF (@version NOT LIKE '7.0.0')
    INSERT INTO @admin_versions_table values ('Obsolete Schema', 'MSCS_Version', @version)

  -- check resource versions
  INSERT INTO @admin_versions_table
    SELECT 'Downlevel Definition', ExtendedProps.s_ResourceType, ExtendedProps.s_Value FROM ExtendedProps 
      INNER JOIN @migratableResources AS m ON (ExtendedProps.s_ResourceType LIKE m.type)
      WHERE (ExtendedProps.s_PropertyName LIKE 's_ResourceVersion' 
        AND CAST(ExtendedProps.s_Value AS nvarchar(10)) NOT LIKE m.version)

  -- check for any resources that we no longer support
  INSERT INTO @admin_versions_table
    SELECT 'Obsolete Instance', Resources.s_DisplayName, Resources.s_Type FROM Resources 
      WHERE Resources.s_Type IN (SELECT type FROM @obsoleteResources)

  -- check for any resources that we support but need to be migrated to latest version
  INSERT INTO @admin_versions_table
    SELECT 'Downlevel Instance', Resources.s_DisplayName, ResourceProps.s_Value FROM Resources 
      INNER JOIN ResourceProps ON (Resources.i_ResourceID = ResourceProps.i_ResourceID)
      INNER JOIN @migratableResources AS m ON(Resources.s_Type LIKE m.type)
      WHERE (ResourceProps.s_PropertyName LIKE 's_ResourceVersion'
        AND CAST(ResourceProps.s_Value AS nvarchar(10)) NOT LIKE m.version)

  SELECT * FROM @admin_versions_table
GO
GRANT EXECUTE ON  [dbo].[proc_check_admin_version] TO [admin_commerceAdministrator_role]
GO
GRANT EXECUTE ON  [dbo].[proc_check_admin_version] TO [admin_reader_role]
GO
