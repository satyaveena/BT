SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- procedure to create resource definition by insertings a row in SystemProps
-- only inserts the resource if it isnt already defined

CREATE PROCEDURE [dbo].[proc_insert_system_property]
  (
    @applicationID      int = NULL ,
    @name               nvarchar(64) = NULL ,
    @className          nvarchar(64),
    @resourceType       nvarchar(32),
    @description        nvarchar(64) = NULL ,
    @resourceFlags      int = NULL ,
    @pupFlags           int,
    @refResource        nvarchar(64) = NULL ,
    @machineName        nvarchar(256) = NULL ,
    @status             nvarchar(256) = NULL ,
    @progidSnapin       nvarchar(128) = NULL ,
    @progidPUP          nvarchar(128) = NULL ,
    @PUPParam1          ntext = NULL ,
    @PUPParam2          ntext = NULL ,
    @PUPParam3          ntext = NULL 
  )
AS
  if exists (select '*' from SystemProps where (SystemProps.s_ResourceType = @resourceType))
    return 0
  else
    insert into 
      SystemProps (i_ApplicationID, s_Name, s_ClassName, s_ResourceType, s_Description, f_ResourceFlags, f_PupFlags, s_RefResource, s_MachineName, i_Status, s_ProgidSnapin, s_ProgidPUP, s_PUPParam1, s_PUPParam2, s_PUPParam3) 
      VALUES      (@applicationID,  @name,  @className,  @resourceType,  @description,  @resourceFlags,  @pupFlags,  @refResource,  @machineName,  @status,  @progidSnapin,  @progidPUP,  @PUPParam1,  @PUPParam2,  @PUPParam3)

  return 0
GO
