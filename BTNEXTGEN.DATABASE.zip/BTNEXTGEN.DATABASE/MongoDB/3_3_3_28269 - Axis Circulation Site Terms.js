use Profiles
var results = db.SiteTerms.find({"Category" : "EBookPurchaseOptions"}).count()
if(results < 1)
{
  
var siteTerms = [{ Key: "Multiple Users - One Year Limit", Value: "Multi-User 1 YR"},
{ Key: "Multiple Users - Perpetual", Value: "Multi-User"},
{ Key: "Multiple Users - Thirty Day Limit", Value: "Multi-User 30 Days"},
{ Key: "Single User - 26 Circulation Limit", Value: "Single-User 26 Circ"},
{ Key: "Single User - 30 Circulation Limit", Value: "Single-User 30 Circ"},
{ Key: "Single User - 35 Circulation Limit", Value: "Single-User 35 Circ"},
{ Key: "Single User - 180 Day Limit", Value: "Single-User 180 Days"},
{ Key: "Single User - One Year Limit", Value: "Single-User 1 Year"},
{ Key: "Single End User - 60 Day Limit", Value: "Single-User 60 Days"},
{ Key: "Single User - Two Year Limit", Value: "Single-User 2 Years"},
{ Key: "Single User - 2 Years or 52 Circulation Limit", Value: "Single-User 2 Yr/52"},
{ Key: "Single User - 90 Day Limit", Value: "Single-User 90 Days"},
{ Key: "Single User - Perpetual", Value: "Single-User"},
{ Key: "Single User - 2 Years or 25 Circulation Limit", Value: "Single-User 2 Yr/25"},
{ Key: "Single User - 2 Years or 24 Circulation Limit", Value: "Single-User 2 Yr/24"},
{ Key: "Single User - Three Year Limit", Value: "Single-User 3 Years"},
{ Key: "Single User - 5 Year Limit", Value: "Single-User 5 Years"},
{ Key: "SUPO", Value: "Single-User"},
{ Key: "MUPO", Value: "Multi-User"},
{ Key: "Multiple Users - Two Year Limit", Value: "Multi-User 2 YR"}]

var siteTermArray = new Array();
for (var i = 0; i < siteTerms.length; i++) {
    siteTermArray.push({
                "Value" : siteTerms[i].Key, 
            	"Name" : siteTerms[i].Value, 
            	"FootprintInformation" : {
                "CreatedBy" : "rm", 
                "CreatedDate" : new Date(), 
                "UpdatedBy" : "rm", 
                "UpdatedDate" : new Date()
            }, 
            "Sequence" : NumberInt(i+1)
            });
}

var siteTerm ={ 
    "Category" : "EBookPurchaseOptions", 
    "SiteTermType" : [
            ], 
    "FootprintInformation" : {
        "CreatedBy" : "rmDataLoad", 
        "CreatedDate" : ISODate("2016-05-27T11:29:11.730-0400"), 
        "UpdatedBy" : "rmDataLoad", 
        "UpdatedDate" : ISODate("2016-05-27T11:29:11.730-0400")
    }, 
    "SiteTermAttributes" : siteTermArray
}


db.SiteTerms.insert(siteTerm)
}
else
{
  print("Site Term Exists!")
}

