var before = new Date();
print ("34768 - Start Profiles Queue Creation");
var common = db.getSiblingDB('Common');
var standingOrders = db.getSiblingDB('StandingOrders');
var itemArray = new Array();
var collectionName = "Profiles";
var collection = standingOrders.getCollection(collectionName);
var changeType = "Upsert";
var isRealTime = false;
var batchSize = 0;
var batchLimit = 10000;
var totalBatches = 0;
var documents = collection.find({});
documents.forEach(	function(document){
itemArray.push({"FootprintInformation" : {
"UpdatedBy" : "AzureService", 
"UpdatedDate" : new Date(), 
"CreatedBy" : "cdm", 
"CreatedDate" : new Date()
}, 
"ObjectId" : document._id, 
"CollectionName" : collectionName, 
"ChangeType" : changeType, 
"Priority" : NumberInt(0), 
"InProcessState" : NumberInt(0), 
"IsRealTime" : isRealTime});
batchSize++;
if(batchSize > batchLimit){
common.AzureSearchQueue.insert(itemArray);
batchSize = 0;
itemArray = new Array();
//print("Inserted Batch " + totalBatches++);
}

});
common.AzureSearchQueue.insert(itemArray);
//print ("34768 - Total documents added to queue" + totalBatches++);

var after = new Date();
var execution_mills = after - before;
print("Total execution time ms: " + execution_mills);