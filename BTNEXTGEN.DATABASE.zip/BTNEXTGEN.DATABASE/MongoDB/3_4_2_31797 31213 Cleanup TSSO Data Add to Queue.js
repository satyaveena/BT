var before = new Date();
//TFS 31797 TSSO - ebooks showing when selecting Print when searching by Areas of Interest
//Build Azure Queue for Series that will be updated
print("31797 - Start Series Queue Creation");
var common = db.getSiblingDB('Common');
var standingOrders = db.getSiblingDB('StandingOrders');
var itemArray = new Array();
var collectionName = "Series"; 
var collection = standingOrders.getCollection(collectionName);
var changeType = "Upsert";
var isRealTime = false;
var batchSize = 0;
var batchLimit = 10000;
var totalBatches = 0;
var documents = collection.find({"AreasOfInterest": "Print", "Format": "eBook" });
documents.forEach(	function(document){
itemArray.push({"FootprintInformation" : {
"UpdatedBy" : "AzureService", 
"UpdatedDate" : new Date(), 
"CreatedBy" : "cdm", 
"CreatedDate" : new Date()
}, 
"ObjectId" : document._id, 
"CollectionName" : collectionName, 
"ChangeType" : changeType, 
"Priority" : NumberInt(0), 
"InProcessState" : NumberInt(0), 
"IsRealTime" : isRealTime});
batchSize++;
if(batchSize > batchLimit){
common.AzureSearchQueue.insert(itemArray);
batchSize = 0;
itemArray = new Array();
//print("Inserted Batch " + totalBatches++);
}

});
common.AzureSearchQueue.insert(itemArray);
print("31797 - End Series Queue Creation");
//print("31797 - Total documents added to queue " + totalBatches++);

//Fix Series.AreasOfInterest Print/eBook

print("31797 - Start Data Cleanup");
collection.update(
{ "AreasOfInterest": "Print", "Format": "eBook" },
{ $pull: { "AreasOfInterest":"Print" } },
{ multi: true}
);
print("31797 - End Data Cleanup");

//Start processing for ticket 31213 
//Delete ProfiledSeries.SeriesRedundantInformation
print("31213 - Start delete SeriesRedundantInformation");
db.ProfiledSeries.update({},{"$unset" : {"RedundantSeriesInformation" : 1}},{multi:true});
print("31213 - End delete SeriesRedundantInformation");

//Load SeriesRedundantInformation
print("31213 - Start Load SeriesRedundantInformation");
var standingOrders = db.getSiblingDB('StandingOrders');

var documents = standingOrders.Series.find({});
documents.forEach(	function(series){

seriesObj = new Object();
if (series.Name){seriesObj.Name =series.Name;}
if (series.Author){seriesObj.Author = series.Author;}
if (series.Format){seriesObj.Format = series.Format;}
if (series.Audience){seriesObj.Audience = series.Audience;}
if (series.Publisher){seriesObj.Publisher = series.Publisher;}
if (series.Distributor){seriesObj.Distributor = series.Distributor;}
if (series.Frequency){seriesObj.Frequency = series.Frequency;}
if (series.Programs){seriesObj.Programs = series.Programs;}
if (series.AreasOfInterest){seriesObj.AreasOfInterest = series.AreasOfInterest;}
if (series.Status){seriesObj.Status = series.Status;}
if (series.LatestIssueInformation){seriesObj.LatestIssueInformation = series.LatestIssueInformation;}
if (series.FootprintInformation){seriesObj.FootprintInformation = series.FootprintInformation;}
if (series.HasRelatedSeries){seriesObj.HasRelatedSeries = series.HasRelatedSeries;}
if (series.HasBindingPreferences){seriesObj.HasBindingPreferences = series.HasBindingPreferences;}
if (series.RelatedSeriesIDs){seriesObj.RelatedSeriesIDs = series.RelatedSeriesIDs;}
if (series.BindingPreferences){seriesObj.BindingPreferences = series.BindingPreferences;}
if (series.RequestStatus){seriesObj.RequestStatus = series.RequestStatus;}
standingOrders.ProfiledSeries.update(
{"SeriesID": series.SeriesID},
{  $set: {"RedundantSeriesInformation" : seriesObj   
}},
{multi:true});

});

print("31213 - End Load SeriesRedundantInformation");

//Build Queue for ProfiledSeries
print("31213 - Start ProfiledSeries Queue Creation");
var common = db.getSiblingDB('Common');
var standingOrders = db.getSiblingDB('StandingOrders');
var itemArray = new Array();
var collectionName = "ProfiledSeries";
var collection = standingOrders.getCollection(collectionName);
var changeType = "Upsert";
var isRealTime = false;
var batchSize = 0;
var batchLimit = 10000;
var totalBatches = 0;
var documents = collection.find({});
documents.forEach(	function(document){
itemArray.push({"FootprintInformation" : {
"UpdatedBy" : "AzureService", 
"UpdatedDate" : new Date(), 
"CreatedBy" : "cdm", 
"CreatedDate" : new Date()
}, 
"ObjectId" : document._id, 
"CollectionName" : collectionName, 
"ChangeType" : changeType, 
"Priority" : NumberInt(0), 
"InProcessState" : NumberInt(0), 
"IsRealTime" : isRealTime});
batchSize++;
if(batchSize > batchLimit){
common.AzureSearchQueue.insert(itemArray);
batchSize = 0;
itemArray = new Array();
//print("Inserted Batch " + totalBatches++);
}

});
common.AzureSearchQueue.insert(itemArray);
//print("31213 - Total documents added to queue " + totalBatches++);



var after = new Date();
var execution_mills = after - before;
print("Total execution time ms: " + execution_mills);