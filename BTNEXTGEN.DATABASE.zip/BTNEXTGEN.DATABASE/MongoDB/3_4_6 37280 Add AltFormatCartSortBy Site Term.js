use Profiles
db.SiteTerms.remove({"Category" : "AltFormatCartSortBy"});


var siteTerms = [ { "Value" : "ngpubdate", "Name" : "Pub Date" }, 
{ "Value" : "ngformatliteral", "Name" : "Format" }]

var siteTermArray = new Array();
for (var i = 0; i < siteTerms.length; i++) {
    siteTermArray.push({
                "Value" : siteTerms[i].Value, 
            	"Name" : siteTerms[i].Name, 
            	"FootprintInformation" : {
                "CreatedBy" : "cm", 
                "CreatedDate" : new Date(), 
                "UpdatedBy" : "cm", 
                "UpdatedDate" : new Date()
            }, 
            "Sequence" : NumberInt(i+1)
            });
}

var siteTerm ={ 
    "Category" : "AltFormatCartSortBy", 
    "SiteTermType" : [
            ], 
    "FootprintInformation" : {
        "CreatedBy" : "cmDataLoad", 
        "CreatedDate" : new Date(), 
        "UpdatedBy" : "cmDataLoad", 
        "UpdatedDate" : new Date()
    }, 
    "SiteTermAttributes" : siteTermArray
}


db.SiteTerms.insert(siteTerm)


