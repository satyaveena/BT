print("31469 - Start");
db = db.getSiblingDB('Profiles');
var results = db.SiteTerms.find({ "Category": "AdvSearchBookFilterLexileScale", "SiteTermAttributes.Value": "HL" }).count()
if(results < 1)
{
db.SiteTerms.update(
    { "Category": "AdvSearchBookFilterLexileScale" },
    { "$push": 
        {"SiteTermAttributes": {
			"$each":[
            {
            "Value" : "HL", 
            "Name" : "High-Low (HL)", 
            "FootprintInformation" : {
                "CreatedBy" : "rmDataLoad", 
                "CreatedDate" : new Date(), 
                "UpdatedBy" : "rmDataLoad", 
                "UpdatedDate" : new Date()
            }, 
            "Sequence" : NumberInt(7)
            }

            
	    ]
        }
	}
	}
)
print("31469 - Complete");
}

else
{
  print("31469 - Skipped: Site Term Exists!");
}
