CREATE TYPE [dbo].[udtCreatedBy] FROM nvarchar (255) NOT NULL
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[udtCreatedBy]'
GO
