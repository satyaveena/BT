CREATE TYPE [dbo].[udtLoadError] FROM varchar (max) NULL
GO
