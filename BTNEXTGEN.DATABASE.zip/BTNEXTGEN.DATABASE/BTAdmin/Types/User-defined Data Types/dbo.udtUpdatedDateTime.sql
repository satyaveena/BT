CREATE TYPE [dbo].[udtUpdatedDateTime] FROM datetime2 NOT NULL
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[udtUpdatedDateTime]'
GO
