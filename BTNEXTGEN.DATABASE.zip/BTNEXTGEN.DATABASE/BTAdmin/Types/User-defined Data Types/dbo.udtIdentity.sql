CREATE TYPE [dbo].[udtIdentity] FROM bigint NOT NULL
GO
