CREATE TYPE [dbo].[utblBasketPricingTOLASPricingUpdates] AS TABLE
(
[BTEKey] [varchar] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShipToAccount] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProductCode] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[VendorNumber] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccumulatorType] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemGroupPriceKey] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
GO
GRANT EXECUTE ON TYPE:: [dbo].[utblBasketPricingTOLASPricingUpdates] TO [db_execute]
GO
