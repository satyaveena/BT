CREATE TYPE [dbo].[udtLoadStatus] FROM varchar (25) NULL
GO
