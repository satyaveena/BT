CREATE TYPE [dbo].[udtCreatedDateTime] FROM datetime2 NOT NULL
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[udtCreatedDateTime]'
GO
