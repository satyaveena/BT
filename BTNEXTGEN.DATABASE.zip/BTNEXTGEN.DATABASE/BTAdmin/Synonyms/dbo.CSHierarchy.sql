CREATE SYNONYM [dbo].[CSHierarchy] FOR [Nextgen_productcatalog].[dbo].[hierarchy]
GO
