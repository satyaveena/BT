CREATE SYNONYM [dbo].[CSProducts] FOR [Nextgen_productcatalog].[dbo].[Products]
GO
