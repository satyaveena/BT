CREATE SYNONYM [dbo].[CSMktgOrderDisc] FOR [Nextgen_marketing].[dbo].[mktg_order_discount]
GO
