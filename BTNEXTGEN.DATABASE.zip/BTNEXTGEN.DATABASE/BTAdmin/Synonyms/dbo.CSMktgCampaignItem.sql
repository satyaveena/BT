CREATE SYNONYM [dbo].[CSMktgCampaignItem] FOR [Nextgen_marketing].[dbo].[mktg_campaign_item]
GO
