CREATE SYNONYM [dbo].[CSMktgExpression] FOR [Nextgen_marketing].[dbo].[mktg_expression]
GO
