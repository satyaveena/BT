SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Mark Howell
Create date:	8/2/2012
Description:	Promotions update for pricing indicators
=============================================
*/
CREATE FUNCTION [dbo].[udfBasketPricingDeMunge] 
( 
	@fld	VARCHAR(512)
) 
RETURNS VARCHAR(512)
AS
BEGIN

	DECLARE @cat varchar(512)
	SELECT	@cat = substring(@fld,CHARINDEX('(',@fld,1),charindex(')',@fld,charindex('(',@fld,1)))

	DECLARE @result varchar(512)
	SELECT	@result = REPLACE(@fld,@cat,'')

	RETURN	@result
END
GO
