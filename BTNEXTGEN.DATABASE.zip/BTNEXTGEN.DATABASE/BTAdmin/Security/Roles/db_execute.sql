CREATE ROLE [db_execute]
AUTHORIZATION [dbo]
GO
EXEC sp_addrolemember N'db_execute', N'DevUI'
GO
EXEC sp_addrolemember N'db_execute', N'Karine'
GO
EXEC sp_addrolemember N'db_execute', N'Ralph'
GO
EXEC sp_addrolemember N'db_execute', N'SSISBatchEntry'
GO
EXEC sp_addrolemember N'db_execute', N'Tiffany'
GO
