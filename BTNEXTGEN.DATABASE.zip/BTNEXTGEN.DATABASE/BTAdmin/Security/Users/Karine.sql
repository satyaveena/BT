CREATE USER [Karine] FOR LOGIN [Karine]
GO
