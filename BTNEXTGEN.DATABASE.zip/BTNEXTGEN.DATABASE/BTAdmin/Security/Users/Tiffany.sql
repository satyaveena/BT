CREATE USER [Tiffany] FOR LOGIN [Tiffany]
GO
