SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2014-10-10
Description:	Updates the file read flag when a file has been imported
=============================================
*/
CREATE PROCEDURE [dbo].[procBatchEntryMarkFileAsRead]
	(@BatchEntryQueueID		NVARCHAR(50))
AS
BEGIN
	SET NOCOUNT ON;

	--Convert parameter to big int
	DECLARE @QueueID BIGINT = @BatchEntryQueueID

    UPDATE	dbo.BatchEntryQueue
	SET		FileRead = 1
	WHERE	BatchEntryQueueID = @QueueID
END
GO
