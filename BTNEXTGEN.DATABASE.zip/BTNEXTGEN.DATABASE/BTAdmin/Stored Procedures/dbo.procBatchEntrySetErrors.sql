SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2014-10-20
Description:	Updated queue table with errors from the SSIS package

Modifications:
2015-10-12	KG	TFS 19323 Improved error handling
=============================================
*/
CREATE PROCEDURE [dbo].[procBatchEntrySetErrors]
(
	@BatchEntryQueueID		BIGINT
	, @ErrorMessage			NVARCHAR(MAX)
)
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @AlertMessageTemplateID			BIGINT
			, @BasketName					NVARCHAR(80)
			, @UserID						NVARCHAR(50)
			, @DestinationBasketSummaryID	NVARCHAR(50)
			, @Template						NVARCHAR(500)
			, @ConfigReferenceValue			NVARCHAR(500)
			, @ReturnCode					INT

	--Fail the cart
    UPDATE	dbo.BatchEntryQueue
	SET		LoadStatus = 'Failed'
			, LoadError = @ErrorMessage
	WHERE	BatchEntryQueueID = @BatchEntryQueueID

	--Get basket name
	SELECT	@BasketName = BasketName
			, @UserID = Q.UserID
			, @DestinationBasketSummaryID = Q.DestinationBasketSummaryID
	FROM	Orders.dbo.BasketSummary AS BS
	INNER JOIN dbo.BatchEntryQueue AS Q
	ON		BS.BasketSummaryID = Q.DestinationBasketSummaryID
	WHERE	Q.BatchEntryQueueID = @BatchEntryQueueID

	--Get alert message details
	SET @AlertMessageTemplateID = 20

	EXEC Profiles.dbo.procGetAlertMessageTemplate
		@AlertMessageTemplateID = @AlertMessageTemplateID
		, @AlertMessageTemplate = @Template OUTPUT
		, @ConfigReferenceValue = @ConfigReferenceValue OUTPUT
		, @Return				= @ReturnCode
		, @Message				= @ErrorMessage

	SET @Template = REPLACE(@Template, '@cartname', @BasketName)

	--set the alert
	EXEC Profiles.dbo.procInsertAlertUserMessage
		@AlertMessage			= @Template
		, @UserID				= @UserID
		, @MessageTemplateID	= @AlertMessageTemplateID
		, @SourceSystem			= 'Batch Entry'
		, @Return				= @ReturnCode
		, @Message				= @ErrorMessage
	SELECT @Template as template, @UserID as Userid, @AlertMessageTemplateID as messagetemplate

	--release the cart
	UPDATE	Orders.dbo.BasketSummary
	SET		BasketStateID = 1
			, BasketProcessingCategoryID = NULL
	WHERE	BasketSummaryID = @DestinationBasketSummaryID

	RETURN 0

END
GO
