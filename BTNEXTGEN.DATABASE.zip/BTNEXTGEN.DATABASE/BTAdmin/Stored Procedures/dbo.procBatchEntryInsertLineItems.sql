SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz	
Create date:	2014-10-09
Description:	Inserts items into BatchEntryLineItems table
=============================================
*/
CREATE PROCEDURE [dbo].[procBatchEntryInsertLineItems]
	@BatchEntryQueueID	NVARCHAR(50) -- SSIS cannot handle a bigint
	, @Item				VARCHAR(14)
	, @ItemQuantity		VARCHAR(5) --in case the user supplies something else

AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO dbo.BatchEntryLineItems (BatchEntryQueueID, Item, ItemQuantity)
	VALUES (@BatchEntryQueueID
		, REPLACE(REPLACE(REPLACE(@Item, CHAR(10), ''), CHAR(13), ''), CHAR(9), '') --Replacing carriage returns, line feeds, and tabs
		, REPLACE(REPLACE(REPLACE(@ItemQuantity, CHAR(10), ''), CHAR(13), ''), CHAR(9), '') 
		)
END
GO
