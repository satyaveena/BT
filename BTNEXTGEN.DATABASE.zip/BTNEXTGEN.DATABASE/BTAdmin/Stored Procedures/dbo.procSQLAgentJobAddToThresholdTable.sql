SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[procSQLAgentJobAddToThresholdTable] (
		@Message	 varchar(100) = ''  OUTPUT
)

/*****************************************************************************************
DEVELOPER:		Bruce Baum
DEV DATE:		2018-10
CALLED FROM:	UI
OVERVIEW:		TFS 31224 - Return Statistics about SQL Agent Jobs

MODIFICATION HISTORY:		

****************************************************************************************/
AS

BEGIN

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY

Declare @InsertCount int = 0
		

Insert into  [BTAdmin].[dbo].[ThresholdDuration] (JobID, JobName)
SELECT Job.Job_ID as JobID, Name AS 'JobName'
From			msdb.dbo.sysjobs Job with (NoLock)
Left Outer Join	[BTAdmin].[dbo].[ThresholdDuration] t with (NoLock) on Job.Job_ID = t.JobID
Where t.JobID IS NULL

Set @InsertCount = @@ROWCOUNT

IF @InsertCount > 0
Begin
	IF @InsertCount > 1
		Set @Message = Cast (@InsertCount as varchar(5)) + ' New Jobs Added to Threshold Table'
	Else
		Set @Message = Cast (@InsertCount as varchar(5)) + ' New Job Added to Threshold Table'

	SELECT TOP (10) JobID, [JobName]
		  ,[ThresholdDuration]
		  ,[ResponsiblePartyName]
		  ,[ResponsiblePartyPhone]
		  ,[ResponsiblePartyEMail]
		  ,[CreatedBy]
		  ,[CreatedDateTime]
		  ,[UpdatedBy]
		  ,[UpdatedDateTime]
	  FROM [BTAdmin].[dbo].[ThresholdDuration]
	  Where Cast(CreatedDateTime as Date) = Cast(GetDate() as Date)
End
  Else Set @Message = 'No New Jobs Found'

--Select @Message

RETURN 0

END TRY
	
BEGIN CATCH
Declare @ErrorMessage varchar(256)
		SET	@ErrorMessage = ERROR_MESSAGE() 
		SELECT 'An Error Occured', @ErrorMessage 
		RETURN -1
END CATCH

END
GO
