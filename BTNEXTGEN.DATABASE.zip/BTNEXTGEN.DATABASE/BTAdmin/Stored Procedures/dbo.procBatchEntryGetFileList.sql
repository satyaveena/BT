SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2014-10-03
Description:	Called from BatchEntry SSIS package. Returns a list of files that are ready to be read
=============================================
*/
CREATE PROCEDURE [dbo].[procBatchEntryGetFileList]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT		CAST(BatchEntryQueueID as VARCHAR(MAX)) as BatchEntryQueueID
				, FilePath
				, DestinationBasketSummaryID
				, ISNULL(eSuppliers, '') as eSuppliers
				, ISNULL(IsValidateBTKey, '') as IsValidateBTKey
				, ISNULL(OrganizationID, '') as OrganizationID 
				, REVERSE(LEFT(REVERSE(FilePath), CHARINDEX('/',REVERSE(FilePath))-1)) as FileName
	FROM		dbo.BatchEntryQueue
	WHERE		FileRead = 0
	AND			LoadStatus IS NULL
	ORDER BY	CreatedDateTime
END
GO
