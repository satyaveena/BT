SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Mark Howell
Create date:	8/2/2012
Description:	Promotions update for pricing indicators

2014-03-19 CDM TFS 8098:  Migration of all Commerce Server DBs to the Repository SQL Instance
									Use Synonyms instead of Commerce Server.Nextgen_profiles.
2014-12-01	KG	TFS 14255	Added step to merge promo data into ProductCalculations
=============================================
*/
CREATE PROCEDURE [dbo].[procBasketPricingInsertPromotions]
AS
BEGIN
	
	--need to grab all the active promotions along with their product and category settings
	SELECT	i.u_campitem_name 
			, i.dt_campitem_start 
			, i.dt_campitem_end
			, i.b_campitem_active 
			, i.dt_campitem_modified 
			, i.b_campitem_deleted 
			, i.dt_campitem_archived 
			, i.i_campitem_exposure_limit 
			, e.u_expr_prodpicker_catalog_name 
			, CASE dbo.udfBasketPricingTS360DeMungeCat(e.u_expr_prodpicker_category_id )
				WHEN '' THEN dbo.udfBasketPricingDeMunge(e.u_expr_prodpicker_catalog_name )
				ELSE dbo.udfBasketPricingTS360DeMungeCat(e.u_expr_prodpicker_category_id )
				END CatalogName
			, dbo.udfBasketPricingDeMunge(e.u_expr_prodpicker_category_id ) CategoryName 
			, dbo.udfBasketPricingDeMunge(e.u_expr_prodpicker_product_id  ) productid  
	INTO	#tmp
	FROM	dbo.CSMktgCampaignItem i 
	INNER JOIN dbo.CSMktgOrderDisc d 
	ON		i.i_campitem_id = d.i_campitem_id 
	INNER JOIN dbo.CSMktgExpression e 
	ON		d.i_disc_award_expr = e.i_expr_id
	WHERE	i.b_campitem_active = 1
	AND		i.dt_campitem_start < = GETDATE()
	AND		i.dt_campitem_end > GETDATE();
		
	-- combine products with promotions for comparison work
	-- get all the books related to categories directly referenced from promotions from each catalog (catalog name, productid) recursively	
	-- Get any categories and sub categories referenced by promos
	select
			tt.u_campitem_name
			, tt.dt_campitem_start
			, tt.dt_campitem_end
			, tt.b_campitem_active
			, tt.dt_campitem_modified
			, b_campitem_deleted 
			, dt_campitem_archived 
			, i_campitem_exposure_limit
			, tt.CatalogName
			, tt.CategoryName 
			, p.oid
			, p.btkey into #cats1 
	from #tmp tt
		INNER JOIN dbo.CSProducts p 
			ON		tt.CatalogName = p.CatalogName 
					AND		tt.categoryname = p.Categoryname  
	where p.btkey = ''
	
	while @@ROWCOUNT > 0
		insert into #cats1
		select p.u_campitem_name
			, p.dt_campitem_start
			, p.dt_campitem_end
			, p.b_campitem_active
			, p.dt_campitem_modified
			, b_campitem_deleted 
			, dt_campitem_archived 
			, i_campitem_exposure_limit
			, p2.CatalogName
			, p2.CategoryName 
			, p2.oid
			, p2.btkey from #cats1 p
		INNER JOIN dbo.CSHierarchy h 
			ON		p.CatalogName = h.CatalogName 
					AND		p.oid= h.oid 
		INNER JOIN dbo.CSProducts p2 
			ON		h.child_Catalogname = p2.CatalogName 
					and h.child_oid = p2.oid 
		where	p2.btkey = '' 
				and p2.categoryname not in (select CategoryName from #cats1);
			
	-- Get all the products referenced by any of the collected categories		
	WITH ff AS 
	(
		SELECT tt.u_campitem_name
				, tt.dt_campitem_start
				, tt.dt_campitem_end
				, tt.b_campitem_active
				, tt.dt_campitem_modified
				, b_campitem_deleted 
				, dt_campitem_archived 
				, i_campitem_exposure_limit
				, tt.CatalogName
				, tt.CategoryName 
				, p2.btkey  
		FROM	#cats1  as tt 
		INNER JOIN dbo.CSProducts p 
		ON		tt.CatalogName = p.CatalogName 
		AND		tt.categoryname = p.Categoryname  
		INNER JOIN dbo.CSHierarchy h 
		ON		p.CatalogName = h.CatalogName 
		AND		p.oid= h.oid 
		INNER JOIN dbo.CSProducts p2 
		ON		h.child_Catalogname = p2.CatalogName and h.child_oid = p2.oid 
	)
	
	SELECT	* 
	INTO	#results 
	FROM	ff 
	WHERE	isnull(btkey,'') <> ''
	
	drop table #cats1
		
	-- get all the books directly referenced from promotions from each catalog (catalog name, productid)
	INSERT INTO #results
	SELECT	t.u_campitem_name
			, t.dt_campitem_start
			, dt_campitem_end
			, b_campitem_active
			, dt_campitem_modified
			, b_campitem_deleted 
			, dt_campitem_archived 
			, i_campitem_exposure_limit
			, t.CatalogName
			, t.CategoryName 
			, p.btkey  
	FROM #tmp t 
	INNER JOIN dbo.CSProducts p 
	ON		t.u_expr_prodpicker_catalog_name = p.CatalogName
	AND		t.productid  = p.productid 
	WHERE	t.productid <> ''
	
	-- clean out any records for just categories since we alreay have our products that categories reference
	DELETE FROM #results 
	WHERE ISNULL(btkey,'') = ''
		
	--Merge results into ProductCalculations
	MERGE	ProductCatalog.dbo.ProductCalculations AS PC
	USING	(SELECT DISTINCT P.ProductID FROM #results AS R JOIN ProductCatalog.dbo.Products AS P ON R.btkey = P.BTKey) AS Promos
	ON		PC.ProductID = Promos.ProductID
	WHEN MATCHED AND (PC.HasPromo IS NULL OR PC.HasPromo = 0) THEN
			UPDATE
			SET		HasPromo = 1
	WHEN NOT MATCHED BY TARGET THEN 
			INSERT (ProductID, HasPromo)
			VALUES (Promos.ProductID, 1)
	WHEN NOT MATCHED BY SOURCE AND (PC.HasPromo = 1)THEN
			UPDATE
			SET		HasPromo = 0;

	-- compare what was saved out above with previously persisted results from previous run
	IF OBJECT_ID('ProductCatalog.dbo.TMP_PromoItems') IS NULL
	BEGIN
		-- create the table
		SELECT	* 
		INTO	ProductCatalog.dbo.TMP_PromoItems 
		FROM	#results 
		WHERE 0 = 1
	END

	--	look for additions
	INSERT INTO dbo.BasketPricingPromotionChanges (BTKey) 
	SELECT DISTINCT r.BTKey 
	FROM	#results r
	LEFT OUTER JOIN ProductCatalog.dbo.TMP_PromoItems t 
	ON		r.u_campitem_name = t.u_campitem_name 
	AND		r.btkey = t.BTKey  
	WHERE	t.btkey is null
		
	--  look for any deletions
	INSERT INTO dbo.BasketPricingPromotionChanges (BTKey) 
	SELECT DISTINCT t.BTKey 
	FROM	#results r
	RIGHT OUTER JOIN ProductCatalog.dbo.TMP_PromoItems t 
	ON		r.u_campitem_name = t.u_campitem_name 
	AND		r.btkey = t.BTKey  
	WHERE	r.btkey is null
	
	--  look for any with different campitem setting changes
	INSERT INTO dbo.BasketPricingPromotionChanges (BTKey) 
	SELECT DISTINCT t.BTKey 
	FROM	#results r
	INNER JOIN ProductCatalog.dbo.TMP_PromoItems t 
	ON		r.u_campitem_name = t.u_campitem_name 
	AND		r.btkey = t.BTKey
	WHERE	r.b_campitem_active <> t.b_campitem_active 
	OR		r.dt_campitem_end <> t.dt_campitem_end 
	OR		r.dt_campitem_modified <> t.dt_campitem_modified 
	OR		r.dt_campitem_start <> t.dt_campitem_start 
	OR		r.b_campitem_deleted <> t.b_campitem_deleted 
	OR		r.dt_campitem_archived <> t.dt_campitem_archived 
	OR		r.i_campitem_exposure_limit <> t.i_campitem_exposure_limit 
			  
	--  update persisted results for use in next run.
	INSERT INTO ProductCatalog.dbo.TMP_PromoItems 
	SELECT	r.*
	FROM	#results r
	LEFT OUTER JOIN ProductCatalog.dbo.TMP_PromoItems t 
	ON		r.u_campitem_name = t.u_campitem_name 
	AND		r.BTKey = r.BTKey 
	WHERE	t.BTKey IS NULL
		
	DELETE FROM ProductCatalog.dbo.TMP_PromoItems 
	WHERE	u_campitem_name + ' -- ' + BTKey 
	IN 
	(
		SELECT DISTINCT t.u_campitem_name + ' -- ' + t.BTKey 
		FROM	#results r
		RIGHT OUTER JOIN ProductCatalog.dbo.TMP_PromoItems t 
		ON		r.u_campitem_name = t.u_campitem_name 
		AND		r.btkey = t.BTKey  
		WHERE	r.btkey IS NULL
	)
	
	UPDATE ProductCatalog.dbo.TMP_PromoItems 
	SET		b_campitem_active = t.b_campitem_active
			, dt_campitem_end = t.dt_campitem_end 
			, dt_campitem_modified = t.dt_campitem_modified 
			, dt_campitem_start = t.dt_campitem_start
			, b_campitem_deleted = t.b_campitem_deleted
			, dt_campitem_archived = t.dt_campitem_archived 
			, i_campitem_exposure_limit = t.i_campitem_exposure_limit 
	FROM	ProductCatalog.dbo.TMP_PromoItems t 
	INNER JOIN #results r 
	ON		t.u_campitem_name = r.u_campitem_name 
	AND		t.BTKey = r.BTKey 
	WHERE	r.b_campitem_active <> t.b_campitem_active 
	OR		r.dt_campitem_end <> t.dt_campitem_end 
	OR		r.dt_campitem_modified <> t.dt_campitem_modified 
	OR		r.dt_campitem_start <> t.dt_campitem_start 
	OR		r.b_campitem_deleted <> t.b_campitem_deleted 
	OR		r.dt_campitem_archived <> t.dt_campitem_archived 
	OR		r.i_campitem_exposure_limit <> t.i_campitem_exposure_limit 
	
	DROP TABLE #results 	
	DROP TABLE #tmp	
		
END
GO
GRANT EXECUTE ON  [dbo].[procBasketPricingInsertPromotions] TO [db_execute]
GO
