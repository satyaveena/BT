SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2014-10-10
Description:	Exports the BatchEntryErrorReport
=============================================
*/
CREATE PROCEDURE [dbo].[procBatchEntryExportErrorFile]
(
	@BatchEntryQueueID	BIGINT

)
AS
BEGIN
	SET NOCOUNT ON;

    SELECT	Item
	FROM	dbo.BatchEntryLineItems
	WHERE	BatchEntryQueueID = @BatchEntryQueueID
	AND		LoadStatus = 'Failed'
END
GO
