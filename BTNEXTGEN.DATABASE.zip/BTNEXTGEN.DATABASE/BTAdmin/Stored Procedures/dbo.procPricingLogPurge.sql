SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2015-07-21
Description:	Cleans up the pricing logs in BTAdmin
=============================================
*/
CREATE PROCEDURE [dbo].[procPricingLogPurge]
	@Days INT
	, @BatchSize INT
AS
BEGIN
	SET NOCOUNT ON;

	--Delete in small batches to minimize the effect
	DECLARE @RowCount INT  = 0
			, @CheckDate DATETIME2 = DATEADD(DAY, @Days * -1, GETDATE())

	--Proc Pricing Get
	SELECT	TOP 1 @RowCount = 1
	FROM	dbo.procPricingGetLog
	WHERE	LogDateTime <= @CheckDate

	WHILE @RowCount > 0
	BEGIN
		DELETE TOP (@BatchSize)
		FROM	dbo.procPricingGetLog
		WHERE	LogDateTime <= @CheckDate

		SELECT @RowCount = @@ROWCOUNT
	END
	 
	--Proc Pricing Set
	SELECT	TOP 1 @RowCount = 1
	FROM	dbo.procPricingSetLog
	WHERE	LogDateTime <= @CheckDate

	WHILE @RowCount > 0
	BEGIN
		DELETE TOP (@BatchSize)
		FROM	dbo.procPricingSetLog
		WHERE	LogDateTime <= @CheckDate

		SELECT @RowCount = @@ROWCOUNT
	END

END
GO
