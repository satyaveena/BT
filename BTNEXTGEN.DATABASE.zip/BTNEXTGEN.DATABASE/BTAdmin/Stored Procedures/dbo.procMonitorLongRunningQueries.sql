SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
=============================================
Author:			Kelly Gulutz
Create date:	1/6/2014
Description:	Reports if there are any queries running longer than 12 hours
				If it's SSISOrders_Prod, we'll kill it

Modifications
2015-10-13	KG	Turned monitor job back on and disabled kill step
=============================================
*/
CREATE PROCEDURE [dbo].[procMonitorLongRunningQueries]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Processes TABLE
	(
		SPID			SMALLINT
		, LastBatch		DATETIME
		, ProgramName	NVARCHAR(128)
		, HostName		NVARCHAR(128)
		, LoginName		NVARCHAR(128)
	)

	INSERT INTO @Processes
	SELECT	p.spid
			, P.last_batch
			, P.program_name
			, P.hostname
			, P.loginame
	FROM	master.dbo.sysprocesses P
	WHERE	P.spid > 50
	AND		P.status not in ('background', 'sleeping')
	AND		P.cmd not in ('AWAITING COMMAND'
						,'MIRROR HANDLER'
						,'LAZY WRITER'
						,'CHECKPOINT SLEEP'
						,'RA MANAGER')
	AND		DATEDIFF(hh, P.last_batch, GETDATE()) >= 12
	AND		p.program_name NOT IN ('SQLAgent - TSQL JobStep (Job 0x466C3F93D5D3D64A9538E9F5A4C6A0F2 : Step 1)'  --cscdba:  BlockingHistory
			, 'Microsoft® Windows® Operating System') --sp_server_diagnostic

	IF EXISTS (SELECT TOP 1 SPID FROM @Processes)
	BEGIN
		----check if the OCS process is the long running thread. If it is, kill it, but email that we've killed it
		--IF EXISTS (SELECT TOP 1 SPID FROM @Processes WHERE LoginName = 'SSISOrders_Prod')
		--BEGIN
		--	EXEC msdb.dbo.sp_send_dbmail
		--		@recipients = 'kelly.gulutz@baker-taylor.com;david.browne@baker-taylor.com'
		--		, @reply_to = 'NoReplyPROD@baker-taylor.com'
		--		, @subject = 'Long Running Prod Threads - OCS Orders'
		--		, @body = 'OCS Orders has been running for more than 12 hours and has been killed.'			

		--	DECLARE @SPID SMALLINT
		--			, @SQL NVARCHAR(100)

		--	SELECT	@SPID = SPID
		--	FROM	@Processes
		--	WHERE LoginName = 'SSISOrders_Prod'

		--	--have to use dynamic SQL because KILL will not accept a variable
		--	SET @SQL = 'KILL ' + CAST(@SPID AS VARCHAR(4))
		--	EXEC (@SQL)

		--	--Remove it from the table
		--	DELETE FROM @Processes WHERE SPID = @SPID
		--END
		
		--go and check to see if we still have long running queries. They may still exist
		IF EXISTS (SELECT TOP 1 SPID FROM @Processes)
		BEGIN
			EXEC msdb.dbo.sp_send_dbmail
				@recipients = 'kelly.gulutz@baker-taylor.com;cerisa.meunier@baker-taylor.com;karine.liu@baker-taylor.com;ivor.addo@baker-taylor.com'
				, @reply_to = 'NoReplyPROD@baker-taylor.com'
				, @subject = 'Long Running Prod Threads'
				, @body = 'These threads have been running for longer than 12 hours.'
				, @query = 'SELECT	p.spid 
									, P.last_batch
									, LEFT(P.program_name, 250) as program_name
									, LEFT(P.hostname, 250) as hostname
									, LEFT(P.loginame, 250) as loginname
							FROM	master.dbo.sysprocesses P
							WHERE	P.spid > 50
							AND		P.status not in (''background'', ''sleeping'')
							AND		P.cmd not in (''AWAITING COMMAND''
												,''MIRROR HANDLER''
												,''LAZY WRITER''
												,''CHECKPOINT SLEEP''
												,''RA MANAGER'')
							AND		DATEDIFF(hh, P.last_batch, GETDATE()) >= 12'
		END
		END
	END

GO
