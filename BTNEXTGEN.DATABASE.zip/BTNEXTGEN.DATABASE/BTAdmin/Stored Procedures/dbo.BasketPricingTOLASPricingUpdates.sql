SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	6/29/2012
Description:	For TOLAS Pricing Updates, called for the MQ feed for real time pricing updates

MODIFICATION HISTORY:
2016-05-30  CDM TFS 21256: Pricing Feed changes - TOLAS  
									0Library// flag all LT SHIP TO accounts
=============================================
*/
CREATE PROCEDURE [dbo].[BasketPricingTOLASPricingUpdates]
	@TVP AS dbo.utblBasketPricingTOLASPricingUpdates READONLY
	, @ErrorMessage AS VARCHAR(MAX) OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--Move MQ records to a work table so we can update **** values to NULL
	DECLARE @MQRecords as dbo.utblBasketPricingTOLASPricingUpdates
	INSERT INTO @MQRecords
	SELECT * FROM @TVP
	
	--Null out the **** Fields
	UPDATE	@MQRecords
	SET		ProductCode = NULL
	WHERE	LEFT(ProductCode, 1) = '*'
	
	UPDATE	@MQRecords
	SET		VendorNumber = NULL
	WHERE	LEFT(VendorNumber, 1) = '*'
	
	UPDATE	@MQRecords
	SET		AccumulatorType = NULL
	WHERE	LEFT(AccumulatorType, 1) = '*'
	
	UPDATE	@MQRecords
	SET		ItemGroupPriceKey = NULL
	WHERE	ItemGroupPriceKey = '*'
	
	UPDATE	@MQRecords
	SET		ShipToAccount = NULL
	WHERE	ShipToAccount = REPLICATE('*', 8)
		
	--INSERT INTO dbo.BasketPricingTOLASAccountChanges, which is account changes only, so filter out any records that have a BTEKey
	INSERT INTO dbo.BasketPricingTOLASAccountChanges (ShipToAccountID, ProductCode, VendorNumber, AccumulatorType, ItemGroup)
	SELECT		ShipToAccount, ProductCode, VendorNumber, AccumulatorType, ItemGroupPriceKey
	FROM		@MQRecords M
	WHERE		M.BTEKey IS NULL


	--TFS 21256  CDM 2016-05-30
	DECLARE @TOLASPricingItemPrice TABLE (
				BTEKey char(19),
				AccountNumber varchar(8)
			)

	INSERT INTO @TOLASPricingItemPrice
	SELECT		BTEKey, ShipToAccount
	FROM		@MQRecords
	WHERE		ShipToAccount <> '0Library'

	INSERT INTO @TOLASPricingItemPrice
	SELECT		tpip.BTEKey, t.AccountNumber
	FROM		Profiles.dbo.TOLASAccount t
	JOIN		NextGen_Profiles.dbo.BTAccounts b on t.AccountNumber = b.u_erp_account_number AND t.ShipToAccountflag  = b.b_is_shipping_account
	CROSS JOIN	@MQRecords tpip
	WHERE		t.CustomerType = 'LT'
	AND			b.b_is_TOLAS = 1
	AND			b.b_is_shipping_account = 1
	AND			u_org_id IS NOT NULL
	AND			tpip.ShipToAccount = '0Library'
	-- END TFS 21256
	
	--INSERT INTO BasketPricingTOLASBTEKeyChanges, BTEKey records
	INSERT INTO dbo.BasketPricingTOLASBTEKeyChanges (AccountID, BTEKey)
	SELECT		AccountNumber, BTEKey
	FROM		@TOLASPricingItemPrice M
	WHERE		M.BTEKey IS NOT NULL
	
END
GO
GRANT EXECUTE ON  [dbo].[BasketPricingTOLASPricingUpdates] TO [db_execute]
GO
