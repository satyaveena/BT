SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

create PROCEDURE [dbo].[procSQLAgentJobDuration]  (
		@JobName	SYSNAME
)
/*****************************************************************************************
DEVELOPER:		Bruce Baum
DEV DATE:		2018-09
CALLED FROM:	UI
OVERVIEW:		TFS 31224 - Return Statistics about SQL Agent Jobs

MODIFICATION HISTORY:		

****************************************************************************************/
AS

BEGIN

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY

SELECT msdb.dbo.sysjobs.Name AS 'Job Name', Description,
   'Run Date' = CASE run_date
      WHEN 0 THEN null
      ELSE
      substring(convert(varchar(15),run_date),1,4) + '/' + 
      substring(convert(varchar(15),run_date),5,2) + '/' + 
      substring(convert(varchar(15),run_date),7,2)
   END,
   'Run Time' = CASE len(run_time)
      WHEN 1 THEN cast('00:00:0' + right(run_time,2) as char(8))
      WHEN 2 THEN cast('00:00:' + right(run_time,2) as char(8))
      WHEN 3 THEN cast('00:0' 
            + Left(right(run_time,3),1)  
            +':' + right(run_time,2) as char (8))
      WHEN 4 THEN cast('00:' 
            + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
      WHEN 5 THEN cast('0' 
            + Left(right(run_time,5),1) 
            +':' + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
      WHEN 6 THEN cast(Left(right(run_time,6),2) 
            +':' + Left(right(run_time,4),2)  
            +':' + right(run_time,2) as char (8))
   END,
	run_duration AS 'Elapsed Seconds',
	RIGHT('0' + CAST(run_duration / 3600 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST((run_duration / 60) % 60 AS VARCHAR),2) + ':' +
	RIGHT('0' + CAST(run_duration % 60 AS VARCHAR),2) AS Last_Duration,

	case last_run_outcome
	when 0 then 'Failed'  
	when 1 then 'Successful'  
	when 2 then 'Retry' 
	when 3 then 'Cancelled'  
	when 4 then 'In Progress'
	else 'UnKnown'
	end as Job_Execution_Status,

	Substring(last_outcome_message,1,75) as last_outcome_message
FROM msdb.dbo.sysjobs 
LEFT OUTER JOIN msdb.dbo.sysjobschedules 
ON msdb.dbo.sysjobs.job_id = msdb.dbo.sysjobschedules.job_id
INNER JOIN msdb.dbo.sysschedules ON msdb.dbo.sysjobschedules.schedule_id = msdb.dbo.sysschedules.schedule_id 
join msdb.dbo.sysjobservers s with (NoLock) on msdb.dbo.sysjobs.job_id = s.job_id
--LEFT OUTER JOIN (SELECT job_id, max(run_duration) AS run_duration, avg(run_duration) AS avg_duration
--      FROM msdb.dbo.sysjobhistory
--      GROUP BY job_id) Q1
--ON msdb.dbo.sysjobs.job_id = Q1.job_id
Join msdb.dbo.sysjobhistory h with (NoLock) on msdb.dbo.sysjobs.job_id = h.job_id
where step_id=0
AND		msdb.dbo.sysjobs.Name = @JobName
order by run_date desc, run_time desc

RETURN 0

END TRY
	
BEGIN CATCH
Declare @ErrorMessage varchar(256)
		SET	@ErrorMessage = ERROR_MESSAGE() 
		RETURN -1
END CATCH

END
GO
