SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2014-10-10
Description:	Generates alerts
	19 - Batch Entry Completed
	20 - Batch Entry Failed
	21 - Batch Entry Completed(with errors)
	All error files will be exported as BatchEntry + BatchEntryQueueID + .txt
	Generates the alerts and marks the files as open
=============================================
*/
CREATE PROCEDURE [dbo].[procBatchEntryGenerateAlerts]
(
	@BatchEntryQueueID	BIGINT
	, @ExportErrorFile	BIT OUTPUT
	, @ErrorPath		VARCHAR(MAX) OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @AlertMessageTemplateID			BIGINT
			, @BasketName					NVARCHAR(80)
			, @Template						NVARCHAR(500)
			, @ConfigReferenceValue			NVARCHAR(500)
			, @ReturnCode					INT
			, @ErrorMessage					NVARCHAR(500)
			, @UserID						NVARCHAR(50)
			, @DestinationBasketSummaryID	NVARCHAR(50)

	--Get basket name
	SELECT	@BasketName = BasketName
			, @UserID = Q.UserID
			, @DestinationBasketSummaryID = Q.DestinationBasketSummaryID
	FROM	Orders.dbo.BasketSummary AS BS
	INNER JOIN dbo.BatchEntryQueue AS Q
	ON		BS.BasketSummaryID = Q.DestinationBasketSummaryID
	WHERE	Q.BatchEntryQueueID = @BatchEntryQueueID

	--Get path for file export
	SELECT	@ErrorPath = BatchEntryErrorFilePath
	FROM	dbo.BatchEntryErrorFilePath

	--If the batch is marked failed in the batchentryqueue table, the whole cart failed (or there were no valid items) 
	IF EXISTS 
	(SELECT	BatchEntryQueueID 
		FROM	dbo.BatchEntryQueue 
		WHERE	BatchEntryQueueID = @BatchEntryQueueID
		AND		LoadStatus = 'Failed')
	BEGIN
		SET @AlertMessageTemplateID = 20

		EXEC Profiles.dbo.procGetAlertMessageTemplate
			@AlertMessageTemplateID = @AlertMessageTemplateID
			, @AlertMessageTemplate = @Template OUTPUT
			, @ConfigReferenceValue = @ConfigReferenceValue OUTPUT
			, @Return				= @ReturnCode
			, @Message				= @ErrorMessage

		SET @Template = REPLACE(@Template, '@cartname', @BasketName)
		SET @ExportErrorFile = 0
	END

	IF EXISTS (SELECT TOP (1) 1 FROM dbo.BatchEntryLineItems WHERE BatchEntryQueueID = @BatchEntryQueueID AND LoadStatus = 'Failed')
	AND	NOT EXISTS (SELECT TOP (1) 1 FROM dbo.BatchEntryQueue WHERE BatchEntryQueueID = @BatchEntryQueueID AND LoadStatus = 'Failed')
	--If the one or all of the batch items failed to load, but we processed it, mark the batch as completed but with errors
	BEGIN
		SET @AlertMessageTemplateID = 21

		EXEC Profiles.dbo.procGetAlertMessageTemplate
			@AlertMessageTemplateID = @AlertMessageTemplateID
			, @AlertMessageTemplate = @Template OUTPUT
			, @ConfigReferenceValue = @ConfigReferenceValue OUTPUT
			, @Return				= @ReturnCode
			, @Message				= @ErrorMessage

		SET @Template = REPLACE(@Template, '@cartname', @BasketName)
		SET @Template = REPLACE(@Template, '@URL', @ConfigReferenceValue + @DestinationBasketSummaryID)
		SET @Template = REPLACE(@Template, '@SPURL', @ErrorPath + '/BatchEntry' + CAST(@BatchEntryQueueID AS VARCHAR(25)) + '.tab')
		SET @ExportErrorFile = 1
	END

	IF NOT EXISTS (SELECT TOP (1) 1 FROM dbo.BatchEntryLineItems WHERE BatchEntryQueueID = @BatchEntryQueueID AND LoadStatus = 'Failed')
	AND NOT EXISTS (SELECT TOP (1) 1 FROM dbo.BatchEntryQueue WHERE BatchEntryQueueID = @BatchEntryQueueID AND LoadStatus = 'Failed')
	--We should only have successes at this point, but we'll make sure anyway
	BEGIN
		SET @AlertMessageTemplateID = 19

		EXEC Profiles.dbo.procGetAlertMessageTemplate
			@AlertMessageTemplateID = @AlertMessageTemplateID
			, @AlertMessageTemplate = @Template OUTPUT
			, @ConfigReferenceValue = @ConfigReferenceValue OUTPUT
			, @Return				= @ReturnCode
			, @Message				= @ErrorMessage

		SET @Template = REPLACE(@Template, '@cartname', @BasketName)
		SET @Template = REPLACE(@Template, '@URL', @ConfigReferenceValue + @DestinationBasketSummaryID)
		SET @ExportErrorFile = 0
	END

	--set the alert
	EXEC Profiles.dbo.procInsertAlertUserMessage
		@AlertMessage			= @Template
		, @UserID				= @UserID
		, @MessageTemplateID	= @AlertMessageTemplateID
		, @SourceSystem			= 'Batch Entry'
		, @Return				= @ReturnCode
		, @Message				= @ErrorMessage

	--release the cart
	UPDATE	Orders.dbo.BasketSummary
	SET		BasketStateID = 1
			, BasketProcessingCategoryID = NULL
	WHERE	BasketSummaryID = @DestinationBasketSummaryID

	RETURN 0
END
GO
