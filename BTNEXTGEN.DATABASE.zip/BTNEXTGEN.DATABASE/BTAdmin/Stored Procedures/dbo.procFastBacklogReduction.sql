SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*
=============================================
Author:			Kelly Gulutz
Create date:	2016-02-09
Description:	Reduces the fast backlog
=============================================
*/
CREATE PROCEDURE [dbo].[procFastBacklogReduction]
AS
BEGIN

	DECLARE	@FastCount integer

	SELECT	@FastCount = COUNT(1) 
	FROM	BTAdmin.dbo.ProductFastBatchItems
	WHERE	ProductFastBatchID = 0 


	IF @FastCount < 10000
	BEGIN
		UPDATE	BTAdmin.dbo.ProductFastBatchItems
		SET		ProductFastBatchID = 0
		WHERE	ProductFastBatchID = -1
		AND		ProductID IN (SELECT TOP (30000) ProductID
							FROM		BTAdmin.dbo.ProductFastBatchItems
							WHERE		ProductFastBatchID = -1
							ORDER BY 	[Priority])
	END

	DECLARE @FastPOCCount INT
	
	SELECT	@FastPOCCount = COUNT(1)
	FROM	dbo.ProductFastPOCBatchItems
	WHERE	ProductFastPOCBatchID = 0
	
	IF @FastPOCCount < 10000
	BEGIN
		UPDATE	TOP (30000) BTAdmin.dbo.ProductFastPOCBatchItems
		SET		ProductFastPOCBatchID = 0
		WHERE	ProductFastPOCBatchID = -1
		AND		ProductID IN (SELECT TOP (30000) ProductID
							FROM		BTAdmin.dbo.ProductFastPOCBatchItems
							WHERE		ProductFastPOCBatchID = -1
							ORDER BY	[Priority])	
	END
END
GO
