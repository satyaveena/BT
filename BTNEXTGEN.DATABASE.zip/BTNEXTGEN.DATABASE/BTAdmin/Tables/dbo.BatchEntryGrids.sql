CREATE TABLE [dbo].[BatchEntryGrids]
(
[BatchEntryGridID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BatchEntryQueueID] [dbo].[udtIdentity] NOT NULL,
[AgencyCodeID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemTypeID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CollectionID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode2ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode3ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode4ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode5ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode6ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserCode1ID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Quantity] [int] NULL,
[Sequence] [int] NOT NULL,
[BTkey] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[CallNumberText] [varchar] (26) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TRIGGER [dbo].[tuSetFootprintBatchEntryGrids] ON [dbo].[BatchEntryGrids] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	t
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	dbo.BatchEntryGrids t 
	ON			t.BatchEntryGridID = i.BatchEntryGridID
END


GO
ALTER TABLE [dbo].[BatchEntryGrids] ADD CONSTRAINT [PK__BatchEntryGridID] PRIMARY KEY CLUSTERED  ([BatchEntryGridID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BatchEntryGrids] ADD CONSTRAINT [FK_BatchEntryGrids_BatchEntryQueue] FOREIGN KEY ([BatchEntryQueueID]) REFERENCES [dbo].[BatchEntryQueue] ([BatchEntryQueueID])
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BatchEntryGrids].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryGrids].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BatchEntryGrids].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryGrids].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BatchEntryGrids].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryGrids].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BatchEntryGrids].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryGrids].[UpdatedDateTime]'
GO
