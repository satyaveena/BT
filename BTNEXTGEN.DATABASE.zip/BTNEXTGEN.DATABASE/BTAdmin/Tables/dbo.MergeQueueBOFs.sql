CREATE TABLE [dbo].[MergeQueueBOFs]
(
[MergeQueueBOFID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[MergeQueueID] [bigint] NULL,
[AccountID] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BasketAccountTypeID] [bigint] NULL,
[PONumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoadStatus] [dbo].[udtLoadStatus] NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MergeQueueBOFs] ADD CONSTRAINT [PK_MergeQueueBOFID] PRIMARY KEY CLUSTERED  ([MergeQueueBOFID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [ix_MergeQueueBOFs_MergeQueueID] ON [dbo].[MergeQueueBOFs] ([MergeQueueID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueueBOFs].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueueBOFs].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueueBOFs].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueueBOFs].[UpdatedDateTime]'
GO
