CREATE TABLE [dbo].[ProductQueryTermsFastBatchItems]
(
[ProductQueryTermsFastBatchItemID] [bigint] NOT NULL IDENTITY(1, 1),
[ProductQueryTermsFastBatchID] [bigint] NOT NULL,
[ProductQueryTermID] [bigint] NOT NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[ExtractReason] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReloadIndicator] [bit] NOT NULL CONSTRAINT [DF__ProductQu__Reloa__03317E3D] DEFAULT ((0)),
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TRIGGER [dbo].[tuSetFootprintProductQueryTermsFastBatchItems] ON [dbo].[ProductQueryTermsFastBatchItems] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductQueryTermsFastBatchItems
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductQueryTermsFastBatchItems t ON t.[ProductQueryTermsFastBatchItemID] = i.[ProductQueryTermsFastBatchItemID]
END
GO
ALTER TABLE [dbo].[ProductQueryTermsFastBatchItems] ADD CONSTRAINT [PK_ProductQueryTermsFastBatchItems] PRIMARY KEY CLUSTERED  ([ProductQueryTermsFastBatchItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE1_ProductQueryTermsFastBatchItems_ProductQueryTermID] ON [dbo].[ProductQueryTermsFastBatchItems] ([ProductQueryTermID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE2_ProductQueryTermsFastBatchItems_ProductQueryTermsFastBatchID] ON [dbo].[ProductQueryTermsFastBatchItems] ([ProductQueryTermsFastBatchID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE3_ProductQueryTermsFastBatchItems_ProductQueryTermsFastBatchID] ON [dbo].[ProductQueryTermsFastBatchItems] ([ProductQueryTermsFastBatchID]) INCLUDE ([ProductQueryTermID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE5_ProductQueryTermsFastBatchItems_ProductQueryTermsFastBatchID_ProductQueryTermID] ON [dbo].[ProductQueryTermsFastBatchItems] ([ProductQueryTermsFastBatchID], [ProductQueryTermID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastBatchItems].[UpdatedDateTime]'
GO
