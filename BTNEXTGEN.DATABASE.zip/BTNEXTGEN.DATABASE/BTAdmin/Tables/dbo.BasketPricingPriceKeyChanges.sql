CREATE TABLE [dbo].[BasketPricingPriceKeyChanges]
(
[BasketPricingPriceKeyChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BTKey] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingPriceKeyChanges] ADD CONSTRAINT [XPKBasketPricingPriceKeyChanges] PRIMARY KEY CLUSTERED  ([BasketPricingPriceKeyChangeID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingPriceKeyChanges] ADD CONSTRAINT [AK1_BasketPricingPriceKeyChanges_BTKey] UNIQUE NONCLUSTERED  ([BTKey]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingPriceKeyChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingPriceKeyChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingPriceKeyChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingPriceKeyChanges].[UpdatedDateTime]'
GO
