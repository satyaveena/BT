CREATE TABLE [dbo].[BasketPricingTOLASAccountChanges]
(
[BasketPricingTOLASAccountChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[ShipToAccountID] [nvarchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProductCode] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[VendorNumber] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccumulatorType] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemGroup] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingTOLASAccountChanges] ADD CONSTRAINT [XPKBasketPricingTOLASAccountChanges] PRIMARY KEY CLUSTERED  ([BasketPricingTOLASAccountChangeID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingTOLASAccountChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingTOLASAccountChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingTOLASAccountChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingTOLASAccountChanges].[UpdatedDateTime]'
GO
