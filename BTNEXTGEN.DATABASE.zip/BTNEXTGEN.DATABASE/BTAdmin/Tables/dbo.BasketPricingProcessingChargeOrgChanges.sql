CREATE TABLE [dbo].[BasketPricingProcessingChargeOrgChanges]
(
[BasketPricingProcessingChargeOrgChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[OrgID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingProcessingChargeOrgChanges] ADD CONSTRAINT [XPKBasketPricingProcessingChargeOrgChanges] PRIMARY KEY CLUSTERED  ([BasketPricingProcessingChargeOrgChangeID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingProcessingChargeOrgChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingProcessingChargeOrgChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingProcessingChargeOrgChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingProcessingChargeOrgChanges].[UpdatedDateTime]'
GO
