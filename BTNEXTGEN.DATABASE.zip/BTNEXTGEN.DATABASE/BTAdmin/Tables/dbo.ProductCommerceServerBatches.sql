CREATE TABLE [dbo].[ProductCommerceServerBatches]
(
[ProductCommerceServerBatchID] [bigint] NOT NULL IDENTITY(1, 1),
[LoadStatus] [dbo].[udtLoadStatus] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[CatalogName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE TRIGGER [dbo].[tuSetFootprintProductCommerceServerBatches] ON [dbo].[ProductCommerceServerBatches] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductCommerceServerBatches
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductCommerceServerBatches t 
	ON			t.ProductCommerceServerBatchID = i.ProductCommerceServerBatchID
END

GO
ALTER TABLE [dbo].[ProductCommerceServerBatches] ADD CONSTRAINT [PK_ProductCommerceServerBatchID] PRIMARY KEY CLUSTERED  ([ProductCommerceServerBatchID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE1_ProductCommerceServerBatches_CatalogName] ON [dbo].[ProductCommerceServerBatches] ([CatalogName]) INCLUDE ([ProductCommerceServerBatchID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatches].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatches].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatches].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatches].[UpdatedDateTime]'
GO
