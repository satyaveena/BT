CREATE TABLE [dbo].[BackGroundJobSplitBasket]
(
[BackGroundJobSplitBasketID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[u_user_id] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SendNoRequisitionToGridCart] [bit] NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BackGroundJobSplitBasket] ADD CONSTRAINT [PK_BackGroundJobSplitBasket] PRIMARY KEY CLUSTERED  ([BackGroundJobSplitBasketID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BackGroundJobSplitBasket].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BackGroundJobSplitBasket].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BackGroundJobSplitBasket].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BackGroundJobSplitBasket].[UpdatedDateTime]'
GO
