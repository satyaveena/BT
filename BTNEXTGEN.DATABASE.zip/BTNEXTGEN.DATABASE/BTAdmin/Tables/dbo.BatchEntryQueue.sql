CREATE TABLE [dbo].[BatchEntryQueue]
(
[BatchEntryQueueID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[FilePath] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DestinationBasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[UserID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FileRead] [bit] NOT NULL CONSTRAINT [DF__BatchEntry_FileRead] DEFAULT ((0)),
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[eSuppliers] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsValidateBTKey] [bit] NULL,
[OrganizationID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemsValidated] [bit] NOT NULL CONSTRAINT [DF__BatchEntry_ItemsValidated] DEFAULT ((0)),
[LoadStatus] [dbo].[udtLoadStatus] NULL,
[LoadError] [dbo].[udtLoadError] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintBatchEntryQueue] ON [dbo].[BatchEntryQueue] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	t
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	dbo.BatchEntryQueue t 
	ON			t.BatchEntryQueueID = i.BatchEntryQueueID
END

GO
ALTER TABLE [dbo].[BatchEntryQueue] ADD CONSTRAINT [PK_BatchEntryQueue] PRIMARY KEY CLUSTERED  ([BatchEntryQueueID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryQueue].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryQueue].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryQueue].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryQueue].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryQueue].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryQueue].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryQueue].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryQueue].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryQueue].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryQueue].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryQueue].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryQueue].[UpdatedDateTime]'
GO
