CREATE TABLE [dbo].[JobLastRunDates]
(
[BLIRollupCheck] [datetime] NOT NULL
) ON [PRIMARY]
GO
