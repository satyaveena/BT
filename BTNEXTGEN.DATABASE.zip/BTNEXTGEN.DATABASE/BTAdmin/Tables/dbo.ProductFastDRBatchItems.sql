CREATE TABLE [dbo].[ProductFastDRBatchItems]
(
[ProductFastDRBatchItemID] [bigint] NOT NULL IDENTITY(1, 1),
[ProductFastDRBatchID] [bigint] NOT NULL,
[ProductID] [bigint] NOT NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[ExtractReason] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReloadIndicator] [bit] NOT NULL CONSTRAINT [DF__ProductFa__Reloa__76969D2E] DEFAULT ((0)),
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[Priority] [tinyint] NOT NULL CONSTRAINT [DF__ProductFa__Prior__4D5F7D71] DEFAULT ((0)),
[PullDateTime] [datetime2] NOT NULL CONSTRAINT [DF__ProductFa__PullD__4E53A1AA] DEFAULT (getdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ProductFastDRBatchItems] ADD CONSTRAINT [PK_ProductFastDRBatchItems] PRIMARY KEY CLUSTERED  ([ProductFastDRBatchItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE4_ProductFastDRBatchItems_ProductFastBatchID] ON [dbo].[ProductFastDRBatchItems] ([ProductFastDRBatchID]) INCLUDE ([CreatedBy], [CreatedDateTime], [ExtractReason], [ProductFastDRBatchItemID], [ProductID], [ReloadIndicator], [UpdatedBy], [UpdatedDateTime]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE3_ProductFastDRBatchItems_ProductFastBatchID_IncludeProductID] ON [dbo].[ProductFastDRBatchItems] ([ProductFastDRBatchID]) INCLUDE ([ProductID]) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET ARITHABORT ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET NUMERIC_ROUNDABORT OFF
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE NONCLUSTERED INDEX [IE3_ProductFastDRBatchItems_ProductFastDRBatchID_CreatedDateTime_IncludeProductID] ON [dbo].[ProductFastDRBatchItems] ([ProductFastDRBatchID], [Priority], [PullDateTime], [CreatedDateTime]) INCLUDE ([ProductID]) WHERE ([ProductFastDRBatchID]=(0)) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE2_ProductFastDRBatchItems_ProductID] ON [dbo].[ProductFastDRBatchItems] ([ProductID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastDRBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastDRBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastDRBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastDRBatchItems].[UpdatedDateTime]'
GO
