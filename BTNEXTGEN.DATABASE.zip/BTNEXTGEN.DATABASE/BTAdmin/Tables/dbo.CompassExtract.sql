CREATE TABLE [dbo].[CompassExtract]
(
[StandingOrderProfilesLastExtractDate] [datetime] NOT NULL,
[StandingOrderProfileAccountExractDate] [datetime] NOT NULL
) ON [PRIMARY]
GO
