CREATE TABLE [dbo].[TMP_PromoItems]
(
[u_campitem_name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[dt_campitem_start] [datetime] NULL,
[dt_campitem_end] [datetime] NULL,
[b_campitem_active] [bit] NULL,
[dt_campitem_modified] [datetime] NULL,
[b_campitem_deleted] [bit] NULL,
[dt_campitem_archived] [datetime] NULL,
[i_campitem_exposure_limit] [int] NULL,
[CatalogName] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CategoryName] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BTKey] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
