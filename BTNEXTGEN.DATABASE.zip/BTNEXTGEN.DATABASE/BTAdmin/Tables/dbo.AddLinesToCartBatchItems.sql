CREATE TABLE [dbo].[AddLinesToCartBatchItems]
(
[AddLinesToCartBatchItemID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[AddLinesToCartBatchID] [bigint] NOT NULL,
[BTKey] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[quantity] [int] NULL,
[POLineItemNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BibNumber] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PrimaryResponsiblePartyRedundant] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShortTitleRedundant] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoadStatus] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoadError] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AddLinesToCartBatchItems] ADD CONSTRAINT [PK_AddLinesToCartBatchItems] PRIMARY KEY CLUSTERED  ([AddLinesToCartBatchItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx1_AddLinesToCartBatchItems] ON [dbo].[AddLinesToCartBatchItems] ([AddLinesToCartBatchID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AddLinesToCartBatchItems] ADD CONSTRAINT [fk_AddLinesToCartBatchItems_AddLinesToCartBatchID] FOREIGN KEY ([AddLinesToCartBatchID]) REFERENCES [dbo].[AddLinesToCartBatch] ([AddLinesToCartBatchID])
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[AddLinesToCartBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[AddLinesToCartBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[AddLinesToCartBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[AddLinesToCartBatchItems].[UpdatedDateTime]'
GO
