CREATE TABLE [dbo].[ProductFastBatchItems]
(
[ProductFastBatchItemID] [bigint] NOT NULL IDENTITY(1, 1),
[ProductFastBatchID] [bigint] NOT NULL,
[ProductID] [bigint] NOT NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[ExtractReason] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReloadIndicator] [bit] NOT NULL CONSTRAINT [DF_Product_ReloadIndicator] DEFAULT ((0)),
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[Priority] [tinyint] NOT NULL CONSTRAINT [DF__ProductFa__Prior__4B7734FF] DEFAULT ((0)),
[PullDateTime] [datetime2] NOT NULL CONSTRAINT [DF__ProductFa__PullD__4C6B5938] DEFAULT (getdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ProductFastBatchItems] ADD CONSTRAINT [PK_ProductFastBatchItems] PRIMARY KEY CLUSTERED  ([ProductFastBatchItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE1_ProductFastBatchItems_ProductFastBatchID] ON [dbo].[ProductFastBatchItems] ([ProductFastBatchID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE4_ProductFastBatchItems_ProductFastBatchID_MostColumns] ON [dbo].[ProductFastBatchItems] ([ProductFastBatchID]) INCLUDE ([CreatedBy], [CreatedDateTime], [ExtractReason], [ProductFastBatchItemID], [ProductID], [ReloadIndicator], [UpdatedBy], [UpdatedDateTime]) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET ARITHABORT ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET NUMERIC_ROUNDABORT OFF
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE NONCLUSTERED INDEX [IE3_ProductFastBatchItems_ProductFastBatchIDPriorityPullDateCreatedDate_IncludeProductID] ON [dbo].[ProductFastBatchItems] ([ProductFastBatchID], [Priority], [PullDateTime], [CreatedDateTime]) INCLUDE ([ProductID]) WHERE ([ProductFastBatchID]=(0)) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE2_ProductFastBatchItems_ProductID] ON [dbo].[ProductFastBatchItems] ([ProductID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastBatchItems].[UpdatedDateTime]'
GO
