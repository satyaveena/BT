CREATE TABLE [dbo].[ServerURL]
(
[ServerID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[ServerEnvironment] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ServerURL] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ServerURL] ADD CONSTRAINT [PK_ServerURL] PRIMARY KEY CLUSTERED  ([ServerID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ServerURL].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ServerURL].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ServerURL].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ServerURL].[UpdatedDateTime]'
GO
