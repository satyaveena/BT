CREATE TABLE [dbo].[MassUpdates]
(
[MassUpdateID] [bigint] NOT NULL IDENTITY(1, 1),
[UserID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Quantity] [int] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[CreatedDatetime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedDatetime] [dbo].[udtUpdatedDateTime] NOT NULL,
[BasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintMassUpdates] ON [dbo].[MassUpdates] FOR UPDATE
AS

BEGIN
  	UPDATE   	StandingOrderProfiles
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	MassUpdates t ON i.MassUpdateID = t.MassUpdateID
END
GO
ALTER TABLE [dbo].[MassUpdates] ADD CONSTRAINT [PK_MassUpdates] PRIMARY KEY CLUSTERED  ([MassUpdateID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MassUpdates].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MassUpdates].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MassUpdates].[CreatedDatetime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MassUpdates].[UpdatedDatetime]'
GO
