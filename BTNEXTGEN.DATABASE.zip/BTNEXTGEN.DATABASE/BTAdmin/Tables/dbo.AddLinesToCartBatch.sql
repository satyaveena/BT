CREATE TABLE [dbo].[AddLinesToCartBatch]
(
[AddLinesToCartBatchID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[u_user_id] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OriginalBasketStateID] [bigint] NOT NULL,
[LoadStatus] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoadError] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintAddLinesToCartBatch] ON [dbo].[AddLinesToCartBatch]
   WITH 
 EXECUTE AS CALLER  AFTER UPDATE 
  
  AS

BEGIN
       UPDATE       AddLinesToCartBatch
       SET          UpdatedDateTime = GetDate(),
                    UpdatedBy = SYSTEM_USER
       FROM         inserted i
       INNER JOIN   AddLinesToCartBatch t ON i.AddLinesToCartBatchID = t.AddLinesToCartBatchID
END



GO
ALTER TABLE [dbo].[AddLinesToCartBatch] ADD CONSTRAINT [PK_ AddLinesToCartBatch] PRIMARY KEY CLUSTERED  ([AddLinesToCartBatchID]) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET ARITHABORT ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET NUMERIC_ROUNDABORT OFF
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE NONCLUSTERED INDEX [idx1_AddLinesToCartBatch] ON [dbo].[AddLinesToCartBatch] ([LoadStatus]) WHERE ([LoadStatus]='P') ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[AddLinesToCartBatch].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[AddLinesToCartBatch].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[AddLinesToCartBatch].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[AddLinesToCartBatch].[UpdatedDateTime]'
GO
