CREATE TABLE [dbo].[QuotationExpiration]
(
[DaysToExpiration] [int] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[CreatedDatetime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedDatetime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[QuotationExpiration].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[QuotationExpiration].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[QuotationExpiration].[CreatedDatetime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[QuotationExpiration].[UpdatedDatetime]'
GO
