CREATE TABLE [dbo].[BatchEntryErrorFilePath]
(
[BatchEntryErrorFilePathID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BatchEntryErrorFilePath] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE TRIGGER [dbo].[tuSetFootprintBatchEntryErrorFilePath] ON [dbo].[BatchEntryErrorFilePath] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	t
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	dbo.BatchEntryErrorFilePath t 
	ON			t.BatchEntryErrorFilePathID = i.BatchEntryErrorFilePathID
END



GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BatchEntryErrorFilePath].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryErrorFilePath].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BatchEntryErrorFilePath].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryErrorFilePath].[UpdatedDateTime]'
GO
