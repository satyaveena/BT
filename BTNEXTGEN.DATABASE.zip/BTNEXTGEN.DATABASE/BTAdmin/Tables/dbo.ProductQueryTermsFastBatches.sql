CREATE TABLE [dbo].[ProductQueryTermsFastBatches]
(
[ProductQueryTermsFastBatchID] [bigint] NOT NULL IDENTITY(1, 1),
[LoadStatus] [dbo].[udtLoadStatus] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TRIGGER [dbo].[tuSetFootprintProductQueryTermsFastBatches] ON [dbo].[ProductQueryTermsFastBatches] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductQueryTermsFastBatches
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductQueryTermsFastBatches t ON t.[ProductQueryTermsFastBatchID] = i.[ProductQueryTermsFastBatchID]
END
GO
ALTER TABLE [dbo].[ProductQueryTermsFastBatches] ADD CONSTRAINT [PK_ProductQueryTerms] PRIMARY KEY CLUSTERED  ([ProductQueryTermsFastBatchID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastBatches].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastBatches].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastBatches].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastBatches].[UpdatedDateTime]'
GO
