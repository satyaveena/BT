CREATE TABLE [dbo].[ODSExtracts]
(
[ODSExtractID] [bigint] NOT NULL IDENTITY(1, 1),
[ODSExtract] [dbo].[udtLoadStatus] NOT NULL,
[ExtractDate] [datetime2] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TRIGGER [dbo].[tuSetFootprintODSExtracts] ON [dbo].[ODSExtracts] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ODSExtracts
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ODSExtracts t ON t.[ODSExtractID] = i.[ODSExtractID]
END
GO
ALTER TABLE [dbo].[ODSExtracts] ADD CONSTRAINT [PK_ODSExtracts] PRIMARY KEY CLUSTERED  ([ODSExtractID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ODSExtracts].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ODSExtracts].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ODSExtracts].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ODSExtracts].[UpdatedDateTime]'
GO
