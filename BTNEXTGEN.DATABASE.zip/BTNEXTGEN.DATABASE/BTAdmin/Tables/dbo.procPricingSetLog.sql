CREATE TABLE [dbo].[procPricingSetLog]
(
[BasketLineItemID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ListPrice] [money] NULL,
[PromotionPrice] [money] NULL,
[ContractPrice] [money] NULL,
[PromotionCode] [nvarchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ContractDiscountPercent] [numeric] (4, 2) NULL,
[ProcessingCharges] [money] NULL,
[BuildingCount] [int] NULL,
[LogDateTime] [datetime2] NULL CONSTRAINT [DF__procPrici__LogDa__308E3499] DEFAULT (getdate())
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_procPricingSetLog_LogDateTime] ON [dbo].[procPricingSetLog] ([LogDateTime]) ON [PRIMARY]
GO
