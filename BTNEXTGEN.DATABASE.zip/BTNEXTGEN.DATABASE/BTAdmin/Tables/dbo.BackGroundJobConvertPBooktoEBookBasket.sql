CREATE TABLE [dbo].[BackGroundJobConvertPBooktoEBookBasket]
(
[BackGroundJobConvertPBooktoEBookBasketID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[SourceBasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BasketName] [nvarchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BasketFolderID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[eSupplierPreference] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DigitalFormatPreference] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BasketOwnerID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OriginalBasketStateID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BackGroundJobConvertPBooktoEBookBasket] ADD CONSTRAINT [PK_BackGroundJobConvertPBooktoEBookBasket] PRIMARY KEY CLUSTERED  ([BackGroundJobConvertPBooktoEBookBasketID]) ON [PRIMARY]
GO
