CREATE TABLE [dbo].[MergeQueueSourceBaskets]
(
[MergeQueueSourceBasketID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[MergeQueueID] [bigint] NULL,
[SourceBasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DeleteBasketIndicator] [bit] NULL CONSTRAINT [DF__MergeQueu__Delet__2704CA5F] DEFAULT ((0)),
[OriginalBasketStateID] [int] NULL,
[LoadStatus] [dbo].[udtLoadStatus] NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MergeQueueSourceBaskets] ADD CONSTRAINT [PK_MergeQueueSourceBasketID] PRIMARY KEY CLUSTERED  ([MergeQueueSourceBasketID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [ix_MergeQueueSourceBaskets_MergeQueueID] ON [dbo].[MergeQueueSourceBaskets] ([MergeQueueID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueueSourceBaskets].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueueSourceBaskets].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueueSourceBaskets].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueueSourceBaskets].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueueSourceBaskets].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueueSourceBaskets].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueueSourceBaskets].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueueSourceBaskets].[UpdatedDateTime]'
GO
