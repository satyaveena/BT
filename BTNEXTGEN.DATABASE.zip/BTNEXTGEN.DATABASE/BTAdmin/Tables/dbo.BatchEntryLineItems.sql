CREATE TABLE [dbo].[BatchEntryLineItems]
(
[BatchEntryLineItemID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BatchEntryQueueID] [dbo].[udtIdentity] NOT NULL,
[BTKey] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ISBN] [char] (13) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ISBN10] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[Item] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemQuantity] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoadStatus] [dbo].[udtLoadStatus] NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[Quantity] [int] NULL,
[PrimaryResponsiblePartyRedundant] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShortTitleRedundant] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE TRIGGER [dbo].[tuSetFootprintBatchEntryLineItems] ON [dbo].[BatchEntryLineItems] FOR UPDATE
AS

BEGIN
  	UPDATE   	t
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	dbo.BatchEntryLineItems t 
	ON			t.BatchEntryLineItemID = i.BatchEntryLineItemID
END


GO
ALTER TABLE [dbo].[BatchEntryLineItems] ADD CONSTRAINT [PK_BatchEntryLineItems] PRIMARY KEY CLUSTERED  ([BatchEntryLineItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE2_BatchEntryLineItems_BatchEntryQueueID_w_Include] ON [dbo].[BatchEntryLineItems] ([BatchEntryQueueID]) INCLUDE ([BatchEntryLineItemID], [Item], [ItemQuantity], [LoadStatus]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE1_BatchEntryLineItems_BatchEntryQueueID_w_Include] ON [dbo].[BatchEntryLineItems] ([BatchEntryQueueID], [LoadStatus]) INCLUDE ([BatchEntryLineItemID], [Item]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BatchEntryLineItems] ADD CONSTRAINT [FK_BatchEntryLineItems_BatchEntryQueue] FOREIGN KEY ([BatchEntryQueueID]) REFERENCES [dbo].[BatchEntryQueue] ([BatchEntryQueueID])
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryLineItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryLineItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryLineItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryLineItems].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryLineItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryLineItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryLineItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryLineItems].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryLineItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryLineItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultSystemUser]', N'[dbo].[BatchEntryLineItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BatchEntryLineItems].[UpdatedDateTime]'
GO
