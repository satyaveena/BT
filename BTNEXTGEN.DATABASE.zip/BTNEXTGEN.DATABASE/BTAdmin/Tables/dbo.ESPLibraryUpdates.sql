CREATE TABLE [dbo].[ESPLibraryUpdates]
(
[ESPLastLibraryFetchDate] [datetime] NOT NULL
) ON [PRIMARY]
GO
