CREATE TABLE [dbo].[MassUpdateBasketUserLineItems]
(
[MassUpdateBasketUserLineItemID] [bigint] NOT NULL IDENTITY(1, 1),
[MassUpdateID] [bigint] NOT NULL,
[BasketUserLineItemID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[CreatedDatetime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedDatetime] [dbo].[udtUpdatedDateTime] NOT NULL,
[BasketLineItemID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BasketUserID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintMassUpdateBasketUserLineItems] ON [dbo].[MassUpdateBasketUserLineItems] FOR UPDATE
AS

BEGIN
  	UPDATE   	MassUpdateBasketUserLineItems
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	MassUpdateBasketUserLineItems t ON i.MassUpdateBasketUserLineItemID = t.MassUpdateBasketUserLineItemID
END
GO
ALTER TABLE [dbo].[MassUpdateBasketUserLineItems] ADD CONSTRAINT [PK_MassUpdateBasketUserLineItems] PRIMARY KEY CLUSTERED  ([MassUpdateBasketUserLineItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_MassUpdateBasketUserLineItems_MassUpdateID_BasketUserLineItemID] ON [dbo].[MassUpdateBasketUserLineItems] ([MassUpdateID], [BasketUserLineItemID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MassUpdateBasketUserLineItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MassUpdateBasketUserLineItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MassUpdateBasketUserLineItems].[CreatedDatetime]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MassUpdateBasketUserLineItems].[UpdatedDatetime]'
GO
