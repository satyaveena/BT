CREATE TABLE [dbo].[ProductFastDRBatches]
(
[ProductFastDRBatchID] [bigint] NOT NULL IDENTITY(1, 1),
[LoadStatus] [dbo].[udtLoadStatus] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE TRIGGER [dbo].[tuSetFootprintProductFastDRBatches] ON [dbo].[ProductFastDRBatches] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductFastDRBatches
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductFastDRBatches t 
	ON			t.ProductFastDRBatchID = i.ProductFastDRBatchID
END

GO
ALTER TABLE [dbo].[ProductFastDRBatches] ADD CONSTRAINT [PK_ProductFastDRBatch] PRIMARY KEY CLUSTERED  ([ProductFastDRBatchID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastDRBatches].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastDRBatches].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastDRBatches].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastDRBatches].[UpdatedDateTime]'
GO
