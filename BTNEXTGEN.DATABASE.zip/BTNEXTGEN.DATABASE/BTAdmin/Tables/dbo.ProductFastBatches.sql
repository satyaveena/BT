CREATE TABLE [dbo].[ProductFastBatches]
(
[ProductFastBatchID] [bigint] NOT NULL IDENTITY(1, 1),
[LoadStatus] [dbo].[udtLoadStatus] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintProductFastBatches] ON [dbo].[ProductFastBatches] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductFastBatches
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductFastBatches t 
	ON			t.ProductFastBatchID = i.ProductFastBatchID
END
GO
ALTER TABLE [dbo].[ProductFastBatches] ADD CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED  ([ProductFastBatchID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastBatches].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastBatches].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastBatches].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastBatches].[UpdatedDateTime]'
GO
