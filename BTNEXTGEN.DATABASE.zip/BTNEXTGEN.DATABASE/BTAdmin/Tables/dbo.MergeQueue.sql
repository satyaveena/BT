CREATE TABLE [dbo].[MergeQueue]
(
[MergeQueueID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[DestinationBasketSummaryID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[UserID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LoadStatus] [dbo].[udtLoadStatus] NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MergeQueue] ADD CONSTRAINT [PK_MergeQueue] PRIMARY KEY CLUSTERED  ([MergeQueueID]) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET ARITHABORT ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET NUMERIC_ROUNDABORT OFF
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE NONCLUSTERED INDEX [ix_MergeQueue_MergeQueueID] ON [dbo].[MergeQueue] ([MergeQueueID]) WHERE ([LoadStatus]='P') ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueue].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueue].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[MergeQueue].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[MergeQueue].[UpdatedDateTime]'
GO
