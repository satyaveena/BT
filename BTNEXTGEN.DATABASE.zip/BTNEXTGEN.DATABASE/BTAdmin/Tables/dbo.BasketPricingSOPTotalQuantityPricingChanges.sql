CREATE TABLE [dbo].[BasketPricingSOPTotalQuantityPricingChanges]
(
[BasketPricingPromotionChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[AccountID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[PriceKey] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingSOPTotalQuantityPricingChanges] ADD CONSTRAINT [XPKBasketPricingSOPTotalQuantityPricingChanges] PRIMARY KEY CLUSTERED  ([BasketPricingPromotionChangeID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingSOPTotalQuantityPricingChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingSOPTotalQuantityPricingChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingSOPTotalQuantityPricingChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingSOPTotalQuantityPricingChanges].[UpdatedDateTime]'
GO
