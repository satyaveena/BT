CREATE TABLE [dbo].[BasketPricingTOLASBTEKeyChanges]
(
[BasketPricingTOLASBTEKeyChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[AccountID] [nvarchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BTEKey] [char] (19) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingTOLASBTEKeyChanges] ADD CONSTRAINT [XPKBasketPricingTOLASBTEKeyChanges] PRIMARY KEY CLUSTERED  ([BasketPricingTOLASBTEKeyChangeID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingTOLASBTEKeyChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingTOLASBTEKeyChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingTOLASBTEKeyChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingTOLASBTEKeyChanges].[UpdatedDateTime]'
GO
