CREATE TABLE [dbo].[BasketPricingListPriceChanges]
(
[BasketPricingListPriceChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BTKey] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingListPriceChanges] ADD CONSTRAINT [XPKBasketPricingListPriceChanges] PRIMARY KEY CLUSTERED  ([BasketPricingListPriceChangeID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingListPriceChanges] ADD CONSTRAINT [AK1_BasketPricingListPriceChanges_BTKey] UNIQUE NONCLUSTERED  ([BTKey]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingListPriceChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingListPriceChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingListPriceChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingListPriceChanges].[UpdatedDateTime]'
GO
