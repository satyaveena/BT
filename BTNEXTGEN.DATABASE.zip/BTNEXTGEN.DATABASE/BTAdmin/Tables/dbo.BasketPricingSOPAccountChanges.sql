CREATE TABLE [dbo].[BasketPricingSOPAccountChanges]
(
[BasketPricingSOPAccountChangeID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[AccountID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BasketPricingSOPAccountChanges] ADD CONSTRAINT [XPKBasketPricingSOPAccountChanges] PRIMARY KEY CLUSTERED  ([BasketPricingSOPAccountChangeID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingSOPAccountChanges].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingSOPAccountChanges].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BasketPricingSOPAccountChanges].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BasketPricingSOPAccountChanges].[UpdatedDateTime]'
GO
