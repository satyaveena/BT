CREATE TABLE [dbo].[ProductQueryTermsFastDRBatches]
(
[ProductQueryTermsFastDRBatchID] [bigint] NOT NULL IDENTITY(1, 1),
[LoadStatus] [dbo].[udtLoadStatus] NOT NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintProductQueryTermsFastDRBatches] ON [dbo].[ProductQueryTermsFastDRBatches] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductQueryTermsFastDRBatches
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductQueryTermsFastDRBatches t ON t.[ProductQueryTermsFastDRBatchID] = i.[ProductQueryTermsFastDRBatchID]
END
GO
ALTER TABLE [dbo].[ProductQueryTermsFastDRBatches] ADD CONSTRAINT [PK_ProductQueryTermsFastDRBatches] PRIMARY KEY CLUSTERED  ([ProductQueryTermsFastDRBatchID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastDRBatches].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastDRBatches].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastDRBatches].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastDRBatches].[UpdatedDateTime]'
GO
