CREATE TABLE [dbo].[ProductCommerceServerBatchItems]
(
[ProductCommerceServerBatchItemID] [bigint] NOT NULL IDENTITY(1, 1),
[ProductCommerceServerBatchID] [bigint] NOT NULL,
[ProductID] [bigint] NOT NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[ExtractReason] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReloadIndicator] [bit] NOT NULL CONSTRAINT [DF_ProductCommerceServerBatchItems_ReloadIndicator] DEFAULT ((0)),
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE TRIGGER [dbo].[tuSetFootprintProductCommerceServerBatchItems] ON [dbo].[ProductCommerceServerBatchItems] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductCommerceServerBatchItems
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductCommerceServerBatchItems t 
	ON			t.ProductCommerceServerBatchItemID = i.ProductCommerceServerBatchItemID
END


GO
ALTER TABLE [dbo].[ProductCommerceServerBatchItems] ADD CONSTRAINT [PK_ProductCommerceServerBatchItems] PRIMARY KEY CLUSTERED  ([ProductCommerceServerBatchItemID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE1_ProductCommerceServerBatchItems_ProductFastBatchID] ON [dbo].[ProductCommerceServerBatchItems] ([ProductCommerceServerBatchID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE4_ProductCommerceServerBatchItems_ProductCommerceServerBatchID_CreatedDateTime] ON [dbo].[ProductCommerceServerBatchItems] ([ProductCommerceServerBatchID], [CreatedDateTime]) INCLUDE ([ProductID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE3_ProductCommerceServerBatchItems_ProductCommerceServerBatchID_ProductID] ON [dbo].[ProductCommerceServerBatchItems] ([ProductCommerceServerBatchID], [ProductID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE5_ProductCommerceServerBatchItems_ProductCommerceServerBatchID_UpdatedDateTime] ON [dbo].[ProductCommerceServerBatchItems] ([ProductCommerceServerBatchID], [UpdatedDateTime]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE2_ProductCommerceServerBatchItems_ProductID] ON [dbo].[ProductCommerceServerBatchItems] ([ProductID]) WITH (FILLFACTOR=80) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatchItems].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatchItems].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductCommerceServerBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductCommerceServerBatchItems].[UpdatedDateTime]'
GO
