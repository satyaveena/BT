CREATE TABLE [dbo].[BackGroundJobApplyDuplicates]
(
[BackGroundJobApplyDuplicatesID] [dbo].[udtIdentity] NOT NULL IDENTITY(1, 1),
[BasketIDs] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL,
[AccountList] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Account8List] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CartCheckType] [nvarchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OrderCheckType] [nvarchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OrgId] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[downloadCheckType] [nvarchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MoveToNewCart] [bit] NULL CONSTRAINT [DF__BackGroun__MoveT__1C873BEC] DEFAULT ((0)),
[IsRequiredDuplicateCarts] [bit] NULL,
[IsRequiredDuplicateOrder] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BackGroundJobApplyDuplicates] ADD CONSTRAINT [PK_BackGroundJobApplyDuplicates] PRIMARY KEY CLUSTERED  ([BackGroundJobApplyDuplicatesID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BackGroundJobApplyDuplicates].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BackGroundJobApplyDuplicates].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BackGroundJobApplyDuplicates].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BackGroundJobApplyDuplicates].[UpdatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BackGroundJobApplyDuplicates].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BackGroundJobApplyDuplicates].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[BackGroundJobApplyDuplicates].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[BackGroundJobApplyDuplicates].[UpdatedDateTime]'
GO
