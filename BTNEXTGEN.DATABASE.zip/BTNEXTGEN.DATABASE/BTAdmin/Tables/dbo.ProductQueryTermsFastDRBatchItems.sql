CREATE TABLE [dbo].[ProductQueryTermsFastDRBatchItems]
(
[ProductQueryTermsFastDRBatchItemID] [bigint] NOT NULL IDENTITY(1, 1),
[ProductQueryTermsFastDRBatchID] [bigint] NOT NULL,
[ProductQueryTermID] [bigint] NOT NULL,
[LoadError] [dbo].[udtLoadError] NULL,
[ExtractReason] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReloadIndicator] [bit] NOT NULL CONSTRAINT [DF__ProductQu__Reloa__71D1E811] DEFAULT ((0)),
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintProductQueryTermsFastDRBatchItems] ON [dbo].[ProductQueryTermsFastDRBatchItems] FOR UPDATE
AS
--Maintained in ERwin Model

BEGIN
  	UPDATE   	ProductQueryTermsFastDRBatchItems
	SET			UpdatedDateTime = GetDate(),
				UpdatedBy = SYSTEM_USER
	FROM		inserted i
	INNER JOIN	ProductQueryTermsFastDRBatchItems t ON t.[ProductQueryTermsFastDRBatchItemID] = i.[ProductQueryTermsFastDRBatchItemID]
END

GO
ALTER TABLE [dbo].[ProductQueryTermsFastDRBatchItems] ADD CONSTRAINT [PK_ProductQueryTermsFastDRBatchItems] PRIMARY KEY CLUSTERED  ([ProductQueryTermsFastDRBatchItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE1_ProductQueryTermsFastDRBatchItems_ProductQueryTermID] ON [dbo].[ProductQueryTermsFastDRBatchItems] ([ProductQueryTermID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IE3_ProductQueryTermsFastDRBatchItems_ProductQueryTermsFastDRBatchID] ON [dbo].[ProductQueryTermsFastDRBatchItems] ([ProductQueryTermsFastDRBatchID]) INCLUDE ([ProductQueryTermID]) ON [PRIMARY]
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastDRBatchItems].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastDRBatchItems].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductQueryTermsFastDRBatchItems].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductQueryTermsFastDRBatchItems].[UpdatedDateTime]'
GO
