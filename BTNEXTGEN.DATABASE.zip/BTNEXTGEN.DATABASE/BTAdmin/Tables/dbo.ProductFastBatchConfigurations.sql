CREATE TABLE [dbo].[ProductFastBatchConfigurations]
(
[ProductFastBatchConfigurationID] [tinyint] NOT NULL IDENTITY(1, 1),
[Source] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Priority] [tinyint] NULL,
[Delay] [tinyint] NULL,
[CreatedBy] [dbo].[udtCreatedBy] NOT NULL,
[CreatedDateTime] [dbo].[udtCreatedDateTime] NOT NULL,
[UpdatedBy] [dbo].[udtUpdatedBy] NOT NULL,
[UpdatedDateTime] [dbo].[udtUpdatedDateTime] NOT NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tuSetFootprintProductFastBatchConfigurations] ON [dbo].[ProductFastBatchConfigurations] 
WITH EXECUTE AS CALLER AFTER UPDATE 
AS
BEGIN
	UPDATE	T
	SET		UpdatedBy = SYSTEM_USER
			, UpdatedDateTime = GETDATE()
	FROM	dbo.ProductFastBatchConfigurations as T
	JOIN	inserted i
	ON		T.ProductFastBatchConfigurationID = i.ProductFastBatchConfigurationID

		
END
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastBatchConfigurations].[CreatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastBatchConfigurations].[CreatedDateTime]'
GO
EXEC sp_bindefault N'[dbo].[DefautSystemUser]', N'[dbo].[ProductFastBatchConfigurations].[UpdatedBy]'
GO
EXEC sp_bindefault N'[dbo].[DefaultGETDATE]', N'[dbo].[ProductFastBatchConfigurations].[UpdatedDateTime]'
GO
