using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BTNextGen.Commerce.Portal.Common.Constants;

namespace BTNextGen.Pricing
{
    public class PricingController : IPricingController
    {
        internal class ThreadPamameter
        {
            public string BasketSummaryID { get; set; }
            //public int BatchSize { get; set; }
            public int BatchWaitingTime { get; set; }
        }
        private const string LogCategory = "PricingController";
        #region public method

        /// <summary>
        /// Calculate Price for whole basket
        /// </summary>
        /// <param name="basketSummaryId"></param>
        /// <param name="batchWaitingTime"></param>
        /// <param name="isAsync"></param>
        public void CalculatePrice(string basketSummaryId, int batchWaitingTime, bool isAsync = true)
        {
            var param = new ThreadPamameter()
            {
                BasketSummaryID = basketSummaryId,
                //BatchSize = batchSize,
                BatchWaitingTime = batchWaitingTime
            };

            if (isAsync)
            {
                var pc = new PricingController();
                //var newThread = new Thread(pc.DoCalculateCartPrice);
                //newThread.Start(param);
                ThreadPool.QueueUserWorkItem(pc.DoCalculateCartPrice, param);
            }
            else
            {
                DoCalculateCartPrice(param);
            }
        }

        /// <summary>
        /// Calculate Price for search/item details
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public List<ItemPricing> CalculatePrice(List<BasketLineItemUpdated> items, int? overriedQtyForDiscount, bool hideNetPrice = false)
        {
            if (items == null || items.Count == 0) return null;
            List<ItemPricing> retItemPricing = null;
            try
            {
                PricingLogger.LogInfo(LogCategory, "CalculatePrice - Realtime <== BEGIN");
                foreach (var item in items)
                {
                    PricingLogger.LogDebug(LogCategory, item.ToString());
                }
                //
                //re-price
                ProcessRePrice(items, overriedQtyForDiscount, hideNetPrice);
                //
                retItemPricing = ReMapItemPricing(items);

                if (retItemPricing != null && retItemPricing.Count > 0)
                {
                    var retItemPricingLogMessage = string.Empty;
                    foreach (var itemPricing in retItemPricing)
                    {
                        retItemPricingLogMessage += Environment.NewLine + itemPricing;
                    }
                    PricingLogger.LogDebug(LogCategory, "Items Pricing Return:" + retItemPricingLogMessage);
                }
            }
            catch (Exception exception)
            {
                var errorLogBuilder = new System.Text.StringBuilder();
                errorLogBuilder.AppendLine("Error Items: ");
                foreach (var item in items)
                {
                    errorLogBuilder.AppendLine(item.ToString());
                }

                // log all lines info
                PricingLogger.LogInfo(LogCategory, errorLogBuilder.ToString());

                PricingLogger.LogException(exception);
            }
            finally
            {
                PricingLogger.LogInfo(LogCategory, "CalculatePrice - Realtime ==> END");
            }

            return retItemPricing;
        }
        #endregion

        #region Thread Worker Methods

        public void DoBackgroundPrice(int batchWaitingTime, string basketPostfixCharacterSet)
        {
            var pricingControllerDao = new PricingControllerDAO();
            var hasException = false;
            List<BasketLineItemUpdated> items = null;

            try
            {
                PricingLogger.LogInfo(LogCategory, string.Format("BACKGROUND PRICE [BasketPostfixCharacterSet: {0}] => BEGIN", basketPostfixCharacterSet));
                while (true)
                {
                    // Get BasketLineItemUpdated to re-price
                    PricingLogger.LogInfo(LogCategory, "====== NEW BATCH ======");
                    var ds = pricingControllerDao.GetBasketLineItemUpdatedToRePrice(null, basketPostfixCharacterSet);
                    items = PricingDAOManager.ConvertToBasketLineItemUpdated(ds);

                    if (items != null)
                    {
                        PricingLogger.LogInfo(LogCategory, "GetBasketLineItemUpdatedToRePrice ==> DONE. ItemCount: " + items.Count);
                        foreach (var item in items)
                        {
                            PricingLogger.LogDebug(LogCategory, item.ToString());
                        }

                        // re-price
                        PricingLogger.LogInfo(LogCategory, "ProcessRePrice <== BEGIN");
                        ProcessRePrice(items);
                        PricingLogger.LogInfo(LogCategory, "ProcessRePrice ==> END");

                        // Update after re-price.
                        pricingControllerDao.UpdateBasketLineItemUpdated(items);
                        PricingLogger.LogInfo(LogCategory, "UpdateBasketLineItemUpdated ==> DONE");

                        // sleep after a batch is complete
                        Thread.Sleep(batchWaitingTime);
                    }
                    else
                    {
                        PricingLogger.LogInfo(LogCategory, "GetBasketLineItemUpdatedToRePrice ==> DONE. ItemCount: 0");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                PricingLogger.LogException(ex);
                hasException = true;
            }
            finally
            {
                //just in case exception occurs before the SET sp is called, call this to reset the RepricingIndicator to 0.
                if (hasException && items != null && items.Any())
                {
                    var errorLogBuilder = new System.Text.StringBuilder();
                    errorLogBuilder.AppendLine("Error Items: ");
                    foreach (var item in items)
                    {
                        errorLogBuilder.AppendLine(item.ToString());
                    }
                    
                    // log all lines info
                    PricingLogger.LogInfo(LogCategory, errorLogBuilder.ToString());

                    PricingLogger.LogInfo(LogCategory, "ResetBasketRepricingIndicator <== BEGIN");
                    pricingControllerDao.ResetBasketRepricingIndicator(items[0].BasketSummaryId);
                    PricingLogger.LogInfo(LogCategory, "ResetBasketRepricingIndicator ==> END");
                }

                PricingLogger.LogInfo(LogCategory, "BackgroundReprice <= END");
            }
        }

        /// <summary>
        /// Calculate Price for whole basket
        /// </summary>
        /// <param name="basketSummaryId"></param>
        /// <param name="batchSize"></param>
        /// <param name="batchWaitingTime"></param>
        private void DoCalculateCartPrice(object data)
        {
            var threadParam = (ThreadPamameter)data;
            var basketSummaryId = threadParam.BasketSummaryID;
            if (string.IsNullOrEmpty(basketSummaryId)) return;

            PricingLogger.LogInfo(LogCategory, string.Format("CalculatePrice - BasketSummary:{0} <== BEGIN", basketSummaryId));
            var pricingControllerDao = new PricingControllerDAO();
            List<BasketLineItemUpdated> items = null;
            var hasException = false;
            try
            {
                // Get BasketLineItemUpdated to re-price
                PricingLogger.LogInfo(LogCategory, "GetBasketLineItemUpdatedToRePrice <== BEGIN");
                var ds = pricingControllerDao.GetBasketLineItemUpdatedToRePrice(basketSummaryId);
                items = PricingDAOManager.ConvertToBasketLineItemUpdated(ds);
                PricingLogger.LogInfo(LogCategory, "GetBasketLineItemUpdatedToRePrice ==> END");

                if (items == null) return;
                foreach (var item in items)
                {
                    PricingLogger.LogDebug(LogCategory, item.ToString());
                }

                PricingLogger.LogInfo(LogCategory, "ProcessRePrice <== BEGIN");
                //re-price
                ProcessRePrice(items);
                PricingLogger.LogInfo(LogCategory, "ProcessRePrice ==> END");
                foreach (var item in items)
                {
                    PricingLogger.LogDebug(LogCategory, item.ToString());
                }

                PricingLogger.LogInfo(LogCategory, "UpdateBasketLineItemUpdated <== BEGIN");
                pricingControllerDao.UpdateBasketLineItemUpdated(items);
                PricingLogger.LogInfo(LogCategory, "UpdateBasketLineItemUpdated ==> END");
            }
            catch (Exception exception)
            {
                PricingLogger.LogException(exception);
                hasException = true;
            }
            finally
            {
                //just in case exception occurs before the SET sp is called, call this to reset the RepricingIndicator to 0.
                if (hasException)
                {
                    if (items != null && items.Any())
                    {
                        var errorLogBuilder = new System.Text.StringBuilder();
                        errorLogBuilder.AppendLine("Error Items: ");
                        foreach (var item in items)
                        {
                            errorLogBuilder.AppendLine(item.ToString());
                        }

                        // log all lines info
                        PricingLogger.LogInfo(LogCategory, errorLogBuilder.ToString());
                    }

                    PricingLogger.LogInfo(LogCategory, "ResetBasketRepricingIndicator <== BEGIN");
                    pricingControllerDao.ResetBasketRepricingIndicator(basketSummaryId);
                    PricingLogger.LogInfo(LogCategory, "ResetBasketRepricingIndicator ==> END");
                }
                PricingLogger.LogInfo(LogCategory, "CalculatePrice <= END");
            }
        }
        #endregion

        #region private methods
        /// <summary>
        /// Remap basket lineitem to item pricing
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        private List<ItemPricing> ReMapItemPricing(IEnumerable<BasketLineItemUpdated> items)
        {
            return items.Select(item => new ItemPricing
                                            {
                                                BTKey = item.BTKey,
                                                BasketSummaryId = item.BasketSummaryId,
                                                ListPrice = item.ListPrice,
                                                ContractPrice = item.ContractPrice,
                                                PromotionPrice = item.PromotionPrice,
                                                SalePrice = item.SalePrice,
                                                ExtendedPrice = item.ExtendedPrice,
                                                ESupplier = item.ESupplier,
                                                DiscountPercent = item.DiscountPercent
                                            }).ToList();
        }

        /// <summary>
        /// Calculate Prices in memory
        /// </summary>
        /// <param name="items"></param>
        private void ProcessRePrice(List<BasketLineItemUpdated> items)
        {
            ProcessRePrice(items, null);
        }
        private void ProcessRePrice(List<BasketLineItemUpdated> items, int? overriedQtyForDiscount, bool hideNetPrice = false)
        {
            //List price will be reset all at one.

            CalculateListPrice(items);
            if (!hideNetPrice)
            {
                CalculateContractPrice(items, overriedQtyForDiscount);
                //
                CalculatePromotionPrice(items);
            }
            //Re total items
            ReTotal(items);
        }

        /// <summary>
        /// Re update price of line item
        /// </summary>
        /// <param name="items"></param>
        private void ReTotal(IEnumerable<BasketLineItemUpdated> items)
        {
            PricingLogger.LogInfo(LogCategory, "Retotal after pricing");
            foreach (var item in items)
            {
                PricingLogger.LogDebug(LogCategory, "Item before retotal:" + item);
                if (!item.ContractPrice.HasValue || item.ContractPrice == 0)
                {
                    item.ContractPrice = item.ListPrice;
                }
                if (item.PromotionActiveIndicator && item.PromotionChangedIndicator)
                {
                    item.SalePrice = Lowest(item.PromotionPrice, item.ContractPrice);

                    item.DiscountPercent = (item.SalePrice == item.PromotionPrice &&
                                            item.PromotionDiscountPercent > 0)
                                               ? item.PromotionDiscountPercent
                                               : item.ContractDiscountPercent;

                    item.PromotionChangedIndicator = false;
                }
                else
                {
                    item.SalePrice = item.ContractPrice;
                    item.DiscountPercent = item.ContractDiscountPercent;
                }
                item.ExtendedPrice = item.TotalLineQuantity * item.SalePrice;

                ApplyMupoAndProcessingChargesToItem(item);

                PricingLogger.LogDebug(LogCategory, "Item after retotal:" + item);
            }
        }

        private void ApplyMupoAndProcessingChargesToItem(BasketLineItemUpdated item)
        {
            if (string.Compare(item.PurchaseOption, MupoContants.MupoOption, StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(item.PurchaseOption, MupoContants.MupoOptionMultiUser, StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(item.PurchaseOption, MupoContants.MupoOptionMultiUser1Year, StringComparison.OrdinalIgnoreCase) == 0)
            {
                if (item.NumberOfBuildings < 1) item.NumberOfBuildings = 1;

                if (item.ListPrice <= item.ContractPrice)
                {
                    item.ExtendedPrice = item.ContractPrice * item.NumberOfBuildings;
                    item.SalePrice = item.ContractPrice * item.NumberOfBuildings;
                }
                else
                {
                    item.ExtendedPrice = item.ListPrice * item.NumberOfBuildings;
                    item.SalePrice = item.ContractPrice * item.NumberOfBuildings;
                }
            }

            item.SalePrice += item.ProcessingCharges;
            if (item.SalesTax > 0)
            {
                item.SalePrice += item.SalePrice * (decimal)item.SalesTax / 100;
            }
        }

        /// <summary>
        /// get the low price b/w two
        /// </summary>
        /// <param name="firstPrice"></param>
        /// <param name="secondPrice"></param>
        /// <returns></returns>
        private decimal? Lowest(decimal? firstPrice, decimal? secondPrice)
        {
            if (firstPrice == 0 && secondPrice > 0) return secondPrice;
            if (firstPrice > 0 && secondPrice == 0) return firstPrice;
            if (firstPrice <= secondPrice) return firstPrice;
            if (secondPrice <= firstPrice) return secondPrice;
            return 0;
        }

        /// <summary>
        /// Calculate Commerce Server promotion price.
        /// </summary>
        /// <param name="items"></param>
        private static void CalculatePromotionPrice(List<BasketLineItemUpdated> items)
        {
            PricingLogger.LogInfo(LogCategory, "CalculatePromotionPrice => BEGIN");
            //Collect all item need to be reset promotion price.
            var itemsToResetPromotionPrice =
                items.Where(item => item.PromotionChangedIndicator && item.PromotionActiveIndicator).ToList();
            var itemPricings = PricingCalculator.Instance.CalculatePromotionPrice(itemsToResetPromotionPrice);
            if (itemPricings != null && itemPricings.Count > 0)
            {
                ReUpdateItemPromotionPrice(items, itemPricings);
            }
            PricingLogger.LogInfo(LogCategory, "CalculatePromotionPrice <= END");
        }

        /// <summary>
        /// Calculate Contract Price (SOP, TOLAS)
        /// </summary>
        /// <param name="items"></param>
        private static void CalculateContractPrice(List<BasketLineItemUpdated> items, int? overriedQtyForDiscount)
        {
            PricingLogger.LogInfo(LogCategory, "CalculateContractPrice => BEGIN");
            //Collect all item need to be reset contract price.
            var itemsToResetContractPrice = items.Where(item => item.ContractChangedIndicator).ToList();
            var itemPricings = PricingCalculator.Instance.CalculateContractPrice(itemsToResetContractPrice, overriedQtyForDiscount);
            if (itemPricings != null && itemPricings.Count > 0)
            {
                ReUpdateItemContractPrice(items, itemPricings);
            }
            PricingLogger.LogInfo(LogCategory, "CalculateContractPrice <= END");
        }

        /// <summary>
        /// Calculate List Price
        /// </summary>
        /// <param name="items"></param>
        private static void CalculateListPrice(IEnumerable<BasketLineItemUpdated> items)
        {
            PricingLogger.LogInfo(LogCategory, "CalculateListPrice => BEGIN");
            //Collect all item need to be reset list price.
            if (items == null) return;
            var itemsToResetListPrice = items.Where(item => item.ProductPriceChangedIndicator).ToList();
            var itemPricings = PricingCalculator.Instance.CalculateListPrice(itemsToResetListPrice);
            if (itemPricings != null && itemPricings.Count > 0)
            {
                PricingLogger.LogDebug(LogCategory, "======ItemPricing after get list price:======");
                foreach (var pricing in itemPricings)
                {
                    PricingLogger.LogDebug(LogCategory, pricing.ToString());
                }
                ReUpdateItemListPrice(items, itemPricings);
            }
            PricingLogger.LogInfo(LogCategory, "CalculateListPrice <= END");
        }

        /// <summary>
        /// Re update list price back to line item and reset PriceChangedIndicator
        /// </summary>
        /// <param name="items"></param>
        /// <param name="itemPricings"></param>
        private static void ReUpdateItemListPrice(IEnumerable<BasketLineItemUpdated> items,
            List<ItemPricing> itemPricings)
        {
            if (itemPricings == null || itemPricings.Count == 0) return;
            PricingLogger.LogDebug(LogCategory, "ReUpdateItemListPrice");
            foreach (var item in items)
            {
                var pricingItem = itemPricings.Where(x => x.BTKey == item.BTKey).FirstOrDefault();

                if (pricingItem != null)
                {
                    PricingLogger.LogDebug(LogCategory, pricingItem.ToString());
                    item.ListPrice = pricingItem.ListPrice;
                }
                item.QuantityChanged = true;
                item.ProductPriceChangedIndicator = false;
                PricingLogger.LogDebug(LogCategory, item.ToString());
            }
        }

        /// <summary>
        /// Re update contract price back to line item and reset ContractChangedIndicator
        /// </summary>
        /// <param name="items"></param>
        /// <param name="itemPricings"></param>
        private static void ReUpdateItemContractPrice(IEnumerable<BasketLineItemUpdated> items,
            List<ItemPricing> itemPricings)
        {
            if (itemPricings == null || itemPricings.Count == 0) return;
            PricingLogger.LogDebug(LogCategory, "ReUpdateItemContractPrice");
            foreach (var item in items)
            {
                var pricingItem = itemPricings.Where(x => x.BTKey == item.BTKey).FirstOrDefault();

                if (pricingItem != null)
                {
                    PricingLogger.LogDebug(LogCategory, pricingItem.ToString());
                    item.ContractPrice = pricingItem.ContractPrice;
                    item.ContractDiscountPercent = pricingItem.ContractDiscountPercent.HasValue
                                                       ? pricingItem.ContractDiscountPercent.Value
                                                       : 0;

                }
                item.QuantityChanged = true;
                item.ContractChangedIndicator = false;
                PricingLogger.LogDebug(LogCategory, item.ToString());
            }
        }

        /// <summary>
        /// Re update contract price back to line item and reset PromotionChangedIndicator
        /// </summary>
        /// <param name="items"></param>
        /// <param name="itemPricings"></param>
        private static void ReUpdateItemPromotionPrice(IEnumerable<BasketLineItemUpdated> items,
            List<ItemPricing> itemPricings)
        {
            if (itemPricings == null || itemPricings.Count == 0) return;
            PricingLogger.LogDebug(LogCategory, "ReUpdateItemPromotionPrice");
            foreach (var item in items)
            {
                var pricingItem = itemPricings.Where(x => x.BTKey == item.BTKey).FirstOrDefault();

                if (pricingItem != null)
                {
                    PricingLogger.LogDebug(LogCategory, pricingItem.ToString());
                    item.PromotionPrice = pricingItem.PromotionPrice;
                    item.PromotionDiscountPercent = pricingItem.PromotionDiscountPercent.HasValue
                                                        ? pricingItem.PromotionDiscountPercent.Value
                                                        : 0;
                    item.PromotionCode = pricingItem.PromotionCode;
                }
                item.QuantityChanged = true;
                //item.PromotionChangedIndicator = false;
            }
        }
        #endregion
    }
}
