using System.Collections.Generic;

namespace BTNextGen.Pricing
{
    public interface IPricingController
    {
        /// <summary>
        /// Calculate Price for search/item details
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        List<ItemPricing> CalculatePrice(List<BasketLineItemUpdated> items, int? overriedQtyForDiscount, bool hideNetPrice = false);

        /// <summary>
        /// Background Pricing.
        /// </summary>
        /// <param name="batchWaitingTime"></param>
        /// <param name="basketPostfixCharacterSet"></param>
        void DoBackgroundPrice(int batchWaitingTime, string basketPostfixCharacterSet);

        /// <summary>
        /// Calculate Price for whole basket
        /// </summary>
        /// <param name="basketSummaryId"></param>
        /// <param name="batchWaitingTime"></param>
        /// <param name="isAsync"></param>
        void CalculatePrice(string basketSummaryId, int batchWaitingTime, bool isAsync = true);
    }
}
