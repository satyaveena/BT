using System.Collections.Generic;

namespace BTNextGen.Pricing
{
    public interface IPricingCalculator
    {
        /// <summary>
        /// Calculate list price of BasketLineItemUpdateds
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        List<ItemPricing> CalculateListPrice(List<BasketLineItemUpdated> items);

        /// <summary>
        /// Calculate contract price of BasketLineItemUpdateds
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        List<ItemPricing> CalculateContractPrice(List<BasketLineItemUpdated> items, int? overriedQtyForDiscount);

        /// <summary>
        /// Calculate promotion price of BasketLineItemUpdateds
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        List<ItemPricing> CalculatePromotionPrice(List<BasketLineItemUpdated> items);
    }
}