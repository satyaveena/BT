namespace BTNextGen.Pricing
{
    public class PromotionPricingArgument
    {
        public string BTKey { get; set; }

        public string ProductCatalog { get; set; }

        public string UserId { get; set; }

        public int TotalLineQuantity { get; set; }

        public int TotalOrderQuantity { get; set; }

        public string MarketType { get; set; }

        public string ProductType { get; set; }

        public string AudienceType { get; set; }
    }
}
