﻿using System;
using BT.TS360Constants;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Elmah;
using Microsoft.SharePoint;
using log4net;

namespace BTNextGen.Pricing
{
    internal class PricingLogger
    {
        internal const string ConnectStringProvider = "provider";
        internal const char Semicolon = ';';

        private static readonly ILog Log= LogManager.GetLogger(typeof(PricingLogger));

        public static void LogDebug(string category, string message)
        {
            if (SPContext.Current != null)
            {
                Logger.Write(category, message, false);
            }
            else
            {
                LogDebugToLog4Net(message);
            }
        }

        public static void LogInfo(string category, string message)
        {
            if (SPContext.Current != null)
            {
                Logger.Write(category, message, false);
            }
            else
            {
                LogInfoToLog4Net(message);
            }
        }

        public static void LogException(Exception exception)
        {
            if (SPContext.Current != null)
            {
                //Logger.LogException(exception);
                Logger.RaiseException(exception, ExceptionCategory.Pricing);
            }
            else
            {
                //LogToLog4Net(exception.ToString(), exception);
                //Logger.RaiseExceptionToElmah(exception, ExceptionCategory.Pricing);

                LogToElmah(exception);
            }
        }

        /// <summary>
        /// DB Connection String
        /// </summary>
        private static string ConnectionString
        {
            get
            {
                var connectString = PricingConfiguration.Instance.ExceptionLoggingDbConnString;
                // Cut out Provider
                if (connectString.ToLower().Contains(ConnectStringProvider))
                {
                    int firstDelimeter = connectString.IndexOf(Semicolon);
                    connectString = connectString.Substring(firstDelimeter + 1);
                }

                return connectString;
            }
        }

        private static void LogDebugToLog4Net(string message, Exception exception = null)
        {
            Log.Debug(message, exception);
        }

        private static void LogInfoToLog4Net(string message, Exception exception = null)
        {
            Log.Info(message, exception);
        }

        private static void LogToElmah(Exception exception)
        {
            var errorLog = new SqlErrorLog(ConnectionString);
            errorLog.ApplicationName = "TS360 - Pricing Engine";

            var error = new Error(exception);
            error.ApplicationName = errorLog.ApplicationName;
            error.Source = "Pricing";
            error.Type = "System.Exception";

            errorLog.Log(error);
        }
    }
}
