using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using BT.TS360Constants;
using BTNextGen.Pricing.PromotionServiceReference;

namespace BTNextGen.Pricing
{
    public class PricingCalculator : IPricingCalculator, IDisposable
    {
        private static PricingCalculator _instance;

        private static PromotionServiceClient _promotionServiceClient;

        /// <summary>
        /// Singleton instance of PricingCalculator
        /// </summary>
        public static PricingCalculator Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new PricingCalculator();
                //
                return _instance;
            }
        }

        private PricingCalculator()
        {

        }

        private int PromotionServiceBatchSize
        {
            get
            {
                var batchSize = PricingConfiguration.Instance.PromotionServiceBatchSize;
                int iValue;
                if (string.IsNullOrEmpty(batchSize) || !Int32.TryParse(batchSize, out iValue))
                {
                    iValue = 160; //default
                }
                return iValue;
            }
        }

        /// <summary>
        /// Calculate list price of BasketLineItemUpdateds
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public List<ItemPricing> CalculateListPrice(List<BasketLineItemUpdated> items)
        {
            if (items == null || items.Count == 0) return null;

            var galeLiteral = PricingConfiguration.Instance.GaleLiteral;
            var listPricingArguments = new List<ListPricingArgument>();
            HashSet<string> uniqueBTKey = new HashSet<string>();
            foreach (BasketLineItemUpdated item in items)
            {
                //If the item is GALE and there is not account
                if (string.IsNullOrEmpty(item.AccountERPNumber) &&
                    !string.IsNullOrEmpty(galeLiteral) &&
                    string.Compare(item.ESupplier, galeLiteral, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    PricingLogger.LogDebug("PricingCalculator",
                                           string.Format(
                                               "CalculateListPrice: Gale product ({0}, {1}) without Account Number => Set list price to null",
                                               item.BTKey, item.ESupplier));
                    item.ListPrice = null;
                }
                else if (!string.IsNullOrEmpty(item.BTKey))
                {
                    if (uniqueBTKey.Add(item.BTKey))
                        listPricingArguments.Add(new ListPricingArgument()
                                                     {
                                                         BTKey = item.BTKey,
                                                         eMarket = item.EMarket,
                                                         eTier = item.ETier
                                                     });
                }
            }

            return PricingCalculatorDAO.Instance.GetListPrice(listPricingArguments);
        }

        /// <summary>
        /// Calculate contract price of BasketLineItemUpdateds
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public List<ItemPricing> CalculateContractPrice(List<BasketLineItemUpdated> items, int? overriedQtyForDiscount)
        {
            var itemPricings = new List<ItemPricing>();
            List<SOPPricingArgument> sopPricingArguments;
            List<TOLASPricingArgument> tolasPricingArguments;
            //create the SOP Arguments and TOLAS Arguments
            GetSOPAndTOLASArgument(items, out sopPricingArguments, out tolasPricingArguments);

            if (sopPricingArguments == null || sopPricingArguments.Count == 0)
            {
                PricingLogger.LogInfo("PricingCalculator", " CalculateContractPrice => There is no item for SOP pricing.");
            }
            else
            {
                var sopItemPricings = PricingCalculatorDAO.Instance.CalculateContractPrice(sopPricingArguments, overriedQtyForDiscount);
                if (sopItemPricings != null && sopItemPricings.Count > 0)
                {
                    itemPricings.AddRange(sopItemPricings);
                }
            }

            if (tolasPricingArguments == null || tolasPricingArguments.Count == 0)
            {
                PricingLogger.LogInfo("PricingCalculator", " CalculateContractPrice => There is no item for TOLAS pricing.");
            }
            else
            {
                var tolasItemPricings = PricingCalculatorDAO.Instance.CalculateContractPrice(tolasPricingArguments);
                if (tolasItemPricings != null && tolasItemPricings.Count > 0)
                {
                    itemPricings.AddRange(tolasItemPricings);
                }
            }

            return itemPricings;
        }

        /// <summary>
        /// Calculate promotion price of BasketLineItemUpdateds
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public List<ItemPricing> CalculatePromotionPrice(List<BasketLineItemUpdated> items)
        {
            var repriceLines = new List<LineRepricedInfo>();
            foreach (var lineItem in items)
            {
                if (!string.IsNullOrEmpty(lineItem.BTKey) && !string.IsNullOrEmpty(lineItem.ProductCatalog) &&
                    !string.IsNullOrEmpty(lineItem.SoldToId) && !string.IsNullOrEmpty(lineItem.MarketType) && lineItem.TotalLineQuantity != 0)
                {
                    repriceLines.Add(new LineRepricedInfo()
                                                         {
                                                             AudienceType = lineItem.AudienceType,
                                                             BTKey = lineItem.BTKey,
                                                             MarketType = lineItem.MarketType,
                                                             UserId = lineItem.SoldToId,
                                                             ProductCatalog = lineItem.ProductCatalog,
                                                             ProductType = lineItem.ProductType,
                                                             TotalLineQuantity = lineItem.TotalLineQuantity,
                                                             TotalOrderQuantity = lineItem.TotalOrderQuantity.HasValue ? lineItem.TotalOrderQuantity.Value : 0,
                                                             Pig = lineItem.Pig,
                                                             SiteBranding = lineItem.SiteBranding,
                                                             OrgId = lineItem.OrgId,
                                                             OrgName = lineItem.OrgName
                                                         });
                }
            }
            var retList = new List<ItemPricing>();
            if (repriceLines.Count == 0) return retList;

            //call to CS Promotion Service
            var returnPromoPrices = RunPipeline(repriceLines);
            //validate
            if (returnPromoPrices == null) return retList;
            PricingLogger.LogDebug("PricingCalculator", "==================ItemPricing after get promotion price:==================");
            //calculate after getting promotion prices
            foreach (var lineItem in items)
            {
                if (returnPromoPrices.ContainsKey(lineItem.BTKey))
                {
                    var promotionPrice = returnPromoPrices[lineItem.BTKey];

                    var singlePromoPrice = promotionPrice.Price / lineItem.TotalLineQuantity;
                    var pricingItem = new ItemPricing
                                          {
                                              BTKey = lineItem.BTKey,
                                              BasketSummaryId = lineItem.BasketSummaryId,
                                              ContractPrice = lineItem.ContractPrice,
                                              ExtendedPrice = lineItem.ExtendedPrice,
                                              ListPrice = lineItem.ListPrice,
                                              PromotionPrice = singlePromoPrice,
                                              PromotionDiscountPercent =
                                                  (lineItem.ListPrice.HasValue && lineItem.ListPrice.Value != 0 &&
                                                   singlePromoPrice != 0)
                                                      ? (lineItem.ListPrice - singlePromoPrice) * 100 / lineItem.ListPrice
                                                      : 0,
                                              PromotionCode = promotionPrice.PromotionCode
                                          };
                    PricingLogger.LogDebug("PricingCalculator", pricingItem.ToString());
                    retList.Add(pricingItem);
                }
            }

            return retList;
        }

        private Dictionary<string, PromotionPrice> RunPipeline(List<LineRepricedInfo> items)
        {
            var startTime = DateTime.Now;
            PricingLogger.LogDebug("PricingCalculator",
                                   string.Format(
                                       "#############Start running CS promotion service for {0} items.#############",
                                       items.Count));

            var endPointAddress = new EndpointAddress(PricingConfiguration.Instance.PromotionServiceUrl);

            var binding = new BasicHttpBinding();

            binding.OpenTimeout = binding.CloseTimeout = binding.SendTimeout = binding.ReceiveTimeout = new TimeSpan(0, 0, 30);
            binding.ReceiveTimeout = new TimeSpan(0, 2, 0);

            binding.MaxReceivedMessageSize = Int32.MaxValue;
            binding.MaxBufferPoolSize = Int32.MaxValue;
            binding.MaxBufferSize = Int32.MaxValue;

            binding.ReaderQuotas.MaxDepth = Int32.MaxValue;
            binding.ReaderQuotas.MaxStringContentLength = Int32.MaxValue;
            binding.ReaderQuotas.MaxArrayLength = Int32.MaxValue;
            binding.ReaderQuotas.MaxBytesPerRead = Int32.MaxValue;
            binding.ReaderQuotas.MaxNameTableCharCount = Int32.MaxValue;

            var ps = new PromotionServiceClient(binding, endPointAddress);
            try
            {
                var promoPrices = new List<PromotionPrice>();
                ps.Open();
                var i = 0;
                int batchSize = PromotionServiceBatchSize;
                var count = batchSize;
                while (count == batchSize)
                {
                    var batchItems = items.Skip(i).Take(batchSize);
                    count = items.Count();
                    if (count == 0) break;
                    i += count;
                    var returnedPromoPrices = ps.CalculatePromotionPrices(batchItems.ToList());
                    //var returnedPromoPrices = CommonHelper.CalculatePromotionPrices(batchItems.ToList());
                    if (returnedPromoPrices != null && returnedPromoPrices.Any())
                        promoPrices.AddRange(returnedPromoPrices);
                }

                PricingLogger.LogDebug("PricingCalculator",
                    string.Format(
                        "#############End running CS promotion service - Duration:{0} ms. #############",
                        DateTime.Now.Subtract(startTime).TotalMilliseconds));

                var promoPricesDict = new Dictionary<string, PromotionPrice>();

                foreach (var returnedPromoPrice in promoPrices)
                {
                    if (!promoPricesDict.ContainsKey(returnedPromoPrice.BtKey))
                    {
                        promoPricesDict.Add(returnedPromoPrice.BtKey, returnedPromoPrice);
                    }
                    else
                    {
                        promoPricesDict[returnedPromoPrice.BtKey] = returnedPromoPrice;
                    }
                }
                return promoPricesDict;
            }
            catch (FaultException exception)
            {
                //ps.Abort();
                PricingLogger.LogException(exception);
                return null;
            }
            catch (EndpointNotFoundException exception)
            {
                //ps.Abort();
                PricingLogger.LogException(exception);
                return null;
            }
            catch (CommunicationException exception)
            {
                //ps.Abort();
                PricingLogger.LogException(exception);
                return null;
            }
            catch (TimeoutException exception)
            {
                //ps.Abort();
                PricingLogger.LogException(exception);
                return null;
            }
            catch (Exception exception)
            {
                //ps.Abort();
                PricingLogger.LogException(exception);
                return null;
            }
            finally
            {
                //if (ps.State != CommunicationState.Closing && ps.State != CommunicationState.Closed)
                //{
                //    ps.Close();
                //}
            }
        }


        /// <summary>
        /// Build SOP/TOLAS Pricing Arguments.
        /// </summary>
        /// <param name="lineItemUpdateds"></param>
        /// <param name="sopPricingArguments"></param>
        /// <param name="tolasPricingArguments"></param>
        private void GetSOPAndTOLASArgument(IEnumerable<BasketLineItemUpdated> lineItemUpdateds,
            out List<SOPPricingArgument> sopPricingArguments,
            out List<TOLASPricingArgument> tolasPricingArguments)
        {
            sopPricingArguments = new List<SOPPricingArgument>();
            tolasPricingArguments = new List<TOLASPricingArgument>();
            HashSet<string> uniqueBTKeySOP = new HashSet<string>();
            HashSet<string> uniqueBTKeyTOLAS = new HashSet<string>();
            foreach (var lineItem in lineItemUpdateds)
            {
                //If there's no account for pricing, the contrace will be null and displayed on UI as list price
                if (string.IsNullOrEmpty(lineItem.AccountId) && string.IsNullOrEmpty(lineItem.AccountERPNumber))
                {
                    lineItem.ContractPrice = null;
                }
                else
                {
                    string itemId;
                    if (CheckItemForTolas(lineItem, out itemId))
                    {
                        if (!string.IsNullOrEmpty(itemId) && !string.IsNullOrEmpty(lineItem.AccountERPNumber)
                            && !string.IsNullOrEmpty(lineItem.PrimaryWarehouse))
                        {
                            if (uniqueBTKeyTOLAS.Add(lineItem.BTKey))
                                tolasPricingArguments.Add(new TOLASPricingArgument()
                                                              {
                                                                  BasketSummaryID = lineItem.BasketSummaryId,
                                                                  BTKey = lineItem.BTKey,
                                                                  ItemId = itemId,
                                                                  PriceKey = lineItem.PriceKey,
                                                                  AcceptableDiscount = lineItem.AcceptableDiscount,
                                                                  AccountERPNumber = lineItem.AccountERPNumber,
                                                                  ListPrice = lineItem.ListPrice,
                                                                  PrimaryWarehouse = lineItem.PrimaryWarehouse,
                                                                  ProductLine = lineItem.ProductLine,
                                                                  ReturnFlag = lineItem.ReturnFlag,
                                                                  TotalLineQuanity = lineItem.TotalLineQuantity
                                                              }
                                    );
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(lineItem.BTKey) && !string.IsNullOrEmpty(lineItem.AccountPricePlan)
                            && !string.IsNullOrEmpty(lineItem.PriceKey) && lineItem.TotalOrderQuantity.HasValue)
                        {
                            if (uniqueBTKeySOP.Add(lineItem.BTKey))
                                sopPricingArguments.Add(new SOPPricingArgument()
                                                            {
                                                                BTKey = lineItem.BTKey,
                                                                PlanID = lineItem.AccountPricePlan,
                                                                PriceKey = lineItem.PriceKey,
                                                                TotalQuanity = lineItem.TotalOrderQuantity,
                                                                OrderLineQuanity = lineItem.TotalLineQuantity,
                                                                ListPrice = lineItem.ListPrice
                                                            });
                        }
                    }
                }
            }
        }

        private bool CheckItemForTolas(BasketLineItemUpdated lineItem, out string itemId)
        {
            itemId = string.Empty;
            if (string.Compare(lineItem.ProductType, ProductTypeConstants.Entertainment, StringComparison.CurrentCultureIgnoreCase) == 0
                    || string.Compare(lineItem.ProductType, ProductTypeConstants.Movie, StringComparison.CurrentCultureIgnoreCase) == 0
                    || string.Compare(lineItem.ProductType, ProductTypeConstants.Music, StringComparison.CurrentCultureIgnoreCase) == 0)
            {
                if (!string.IsNullOrEmpty(lineItem.Upc))
                    itemId = lineItem.Upc;
                else
                    itemId = lineItem.ISBN;

                return true;
            }

            if (lineItem.IsHomeDelivery || lineItem.IsVIPAccount || lineItem.IsOneBoxAccount)
            {
                itemId = lineItem.BTKey;
                return true;
            }

            return false;
        }

        public void Dispose()
        {
            if (_promotionServiceClient != null &&
                (_promotionServiceClient.State == CommunicationState.Opened ||
                _promotionServiceClient.State == CommunicationState.Created ||
                _promotionServiceClient.State == CommunicationState.Faulted))
            {
                _promotionServiceClient.Close();
                _promotionServiceClient = null;
            }
        }
    }
}
