﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserGridCode : EditableObject<GridDataAccessManager>
    {        
        public string UserGridCodeId
        {
            get { return Id; }            
        }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                SetChanged();
                _userId = value;
            }
        }

        //For example: btadmin
        public string UserLoginName { get; internal set; }

        //Fist name, Last name
        public string UserDisplayName { get; internal set; }

        private string _gridCodeId;
        public string GridCodeId
        {
            get { return _gridCodeId; }
            set
            {
                SetChanged();
                _gridCodeId = value;
            }
        }

        private string _gridFieldId;
        public string GridFieldId
        {
            get { return _gridFieldId; }
            set
            {
                SetChanged();
                _gridFieldId = value;
            }
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateUserGridCode(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateUserGridCode(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteUserGridCode(this);
        }
    }
}
