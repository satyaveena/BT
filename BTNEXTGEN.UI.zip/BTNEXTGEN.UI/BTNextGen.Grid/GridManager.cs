﻿using System;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.Exception;
using BTNextGen.VelocityCaching;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Controllers;
namespace BTNextgen.Grid
{
    public class GridManager
    {       
        private GridDataAccessManager _currentDataAccessManager;        

        internal GridDataAccessManager CurrentDataAccessManager
        {
            get { return _currentDataAccessManager; }
            set { _currentDataAccessManager = value; }
        }

        internal GridManager()
        {
                   
        }        

        /// <summary>
        /// Get GridFields for the current organization context.
        /// </summary>
        /// <returns></returns>
        //public GridFieldList GetGridFields(bool isGetInUseInfo = true)
        //{
        //    return _currentDataAccessManager.GetGridFields(isGetInUseInfo);
        //}

        //public GridFieldList GetGridFieldsForSlipReport()
        //{
        //    return _currentDataAccessManager.GetGridFields(false);
        //}

        //public GridFieldList GetGridFieldsActive(bool isGetInUseInfo = true)
        //{
        //    var results = new GridFieldList();
        //    var gridFields = _currentDataAccessManager.GetAllGridFields(isGetInUseInfo);
        //    foreach (var gridField in gridFields.Where(gridField => gridField.ActiveIndicator))
        //    {
        //        results.Add(gridField);
        //    }
        //    return results;
        //}

        /// <summary>
        /// Get GridFields with Authorized user in an organization context and grid fields and grid codes being actived
        /// </summary>
        /// <param name="authorizedUserId"></param>
        /// <returns></returns>
        //public GridFieldList GetGridFieldsByAuthorizedUser(string authorizedUserId)
        //{
        //    var gridFieldList = _currentDataAccessManager.GetGridFields();
        //    var result = new GridFieldList();
        //    result.AddRange(
        //        gridFieldList.Where(item => item.UserGridFields.Count(i => i.UserId == authorizedUserId) != 0));
        //    return result;
        //}

        public GridFieldList GetAllGridFieldWithAuthorizedCodeForUser(string sessionCacheKey = "")
        {
            if (!string.IsNullOrEmpty(sessionCacheKey))
            {
                var gridFieldListSession = VelocityCacheManager.Read(sessionCacheKey) as GridFieldList;
                if (gridFieldListSession != null)
                    return gridFieldListSession;
            }

            var gridFieldList = VelocityCacheManager.Read("GetAllGridFieldWithAuthorizedCodeForUser") as GridFieldList;
            if(gridFieldList != null)
            {
                return gridFieldList;
            }
            gridFieldList = _currentDataAccessManager.GetAllGridFieldWithAuthorizedCodeForUser();
            VelocityCacheManager.Write("GetAllGridFieldWithAuthorizedCodeForUser", gridFieldList, 
                GridCacheConstants.CommonGridCacheLevel);

            if (!string.IsNullOrEmpty(sessionCacheKey))
            {
                VelocityCacheManager.Write(sessionCacheKey, gridFieldList, VelocityCacheLevel.Session);
            }
            return gridFieldList;
        }

        /// <summary>
        /// Return a list of GridTemplates in the current organization context.
        /// </summary>      
        /// <returns></returns>
        public GridTemplateList GetGridTemplates()
        {
            return _currentDataAccessManager.GetGridTemplates();
        }

        /// <summary>
        /// Return a GridTemplate by gridTemplateId
        /// </summary>
        /// <param name="gridTemplateId"></param>
        /// <returns></returns>
        public GridTemplate GetGridTemplateById(string gridTemplateId)
        {
            return _currentDataAccessManager.GetGridTemplate(gridTemplateId);
        }
                     
        /// <summary>
        /// Return a list of GridTemplates in the organization
        /// </summary>
        /// <param name="authorizedUserId"></param>      
        /// <returns></returns>
        public GridTemplateList GetGridTemplatesByAuthorizedUser(string authorizedUserId, bool isGetAll = false)
        {
            var list = _currentDataAccessManager.GetGridTemplatesByAuthorizedUser(authorizedUserId, isGetAll);

            if (list == null) return null;

            var result = new GridTemplateList();
            result.AddRange(list.Where(x => !x.IsGridDistribution).ToList());
            return result;
        }

        /// <summary>
        /// Return a list of GridTemplates having been assigned to a user.
        /// </summary>        
        /// <param name="userId"> </param>
        /// <returns></returns>
        public IEnumerable<GridTemplate> GetGridTemplatesByAssignedUser(string userId)
        {
            try
            {
                var list = GetGridTemplatesByAuthorizedUser(userId);
                return list.Where(i => i.OwnerUserId != CurrentDataAccessManager.UserId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        /// <summary>
        /// Get All available SOPGridField Type;
        /// </summary>
        /// <returns></returns>
        public List<SOPGridField> GetAvailableSOPGridFieldList()
        {
            return _currentDataAccessManager.GetSOPGridFieldList();
        }     

        /// <summary>
        /// Get all template owner in an organization.
        /// </summary>
        /// <returns></returns>
        public List<GridTemplateOwner> GetGridTemplateOwners()
        {
            return _currentDataAccessManager.GetGridTemplateOwners();
        }

        public UserPreference GetUserPreference()
        {
            var userPreference = (UserPreference)VelocityCacheManager.Read(CacheKeyConstant.GRID_USER_PREFERENCE_CACHEKEY);
            if(userPreference==null)
            {
                userPreference = _currentDataAccessManager.GetUserPreference();
                if (userPreference != null)
                {
                    VelocityCacheManager.Write(CacheKeyConstant.GRID_USER_PREFERENCE_CACHEKEY, userPreference, VelocityCacheLevel.Session);
                }
                else
                {
                    Logger.Write("GridManager", "User Preference not found", false);
                }
                
            }            
            return userPreference;
        }

        public void ClearCacheGridTemplateOfAuthorizedUser(string authorizedUserId)
        {
            _currentDataAccessManager.ClearCacheGridTemplateAuthorizedUser(authorizedUserId);
        }

        public void UpdateUserGridTemplates(List<UserGridTemplate> userGridTemplates )
        {
            _currentDataAccessManager.UpdateUserGridTemplates(userGridTemplates);
        }

        #region Standing Orders
        public List<StandingOrder> GetStandingOrdersByGridTemplateID(string gridTemplateId, string orgId, int pageNumber, int linePerPage, string sortField, string sortOrder, out int totalLine)
        {
            var profileController = ProfileController.Current;
            var result = profileController.GetStandingOrdersByGridTemplateID(gridTemplateId, orgId, pageNumber, linePerPage, sortField, sortOrder, out totalLine);
            return result;
        }
        public List<StandingOrder> GetStandingOrders(string keyword, string searchField, string orgId, int pageNumber, int linePerPage, string sortField, string sortOrder, out int totalLine)
        {
            var profileController = ProfileController.Current;
            var result = profileController.GetStandingOrders(keyword, searchField, orgId, pageNumber, linePerPage, sortField, sortOrder, out totalLine);
            return result;
        }
        public int UpdateStandingOrders(string gridTemplateId, string[] standingOrderIds, string orgId)
        {
            var profileController = ProfileController.Current;
            var result = profileController.UpdateStandingOrders(gridTemplateId, standingOrderIds, orgId);
            return result;
        }
        //public bool GetOrgStandingOrderStatus(string orgId)
        //{
        //    var profileController = ProfileController.Current;
        //    var result = profileController.GetOrgStandingOrderStatus(orgId);
        //    return result;
        //}
        #endregion

        public void CopyGridTemplates(List<string> gridTemplateIds, string userId)
        {
            try
            {
                _currentDataAccessManager.CopyGridTemplates(gridTemplateIds, userId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        public void UpdateUserGridFieldSlipReportSequence(List<CommonBaseGridUserControl.UIGridField> gridFields)
        {
            try
            {
                _currentDataAccessManager.UpdateUserGridFieldSlipReportSequence(gridFields);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }
		#region NEW GRID

        //public List<CommonBaseGridUserControl.UIUserGridField> GetUserGridFieldsCodes(string userId, string orgId,
        //    out int defaultQuantity)
        //{
        //    try
        //    {
        //        return _currentDataAccessManager.GetUserGridFieldsCodes(userId, orgId, out defaultQuantity);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogException(ex);
        //        throw new CartGridLoadFailedException(ex.Message);
        //    }
        //}

        //public List<CommonBaseGridUserControl.UIUserGridField> GetUserGridFieldsCodes(string userId, string orgId)
        //{
        //    try
        //    {
        //        int defaultQuantity;
        //        return _currentDataAccessManager.GetUserGridFieldsCodes(userId, orgId, out defaultQuantity);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogException(ex);
        //        throw new CartGridLoadFailedException(ex.Message);
        //    }
        //}


        #endregion

        public void SaveGridFieldsGridCodes(List<string> deletedGridCodes, List<CommonBaseGridUserControl.UIGridField> changedGridFields,
            List<CommonBaseGridUserControl.UIGridCode> changedGridCodes, string espFundCodeFieldID, string espBranchCodeFieldID, string ilsFundCodeFieldID, string ilsLocationCodeFieldID,
            string ilsMemberCodeRemainderFieldId, int ilsMemberCodeLength, bool ilsPassEntireLocationAsRemainder, string ilsPassPOAsLineNoteFieldId, string ilsCollectionCodeFieldId)
        {
            try
            {
                _currentDataAccessManager.SaveGridFieldsGridCodes(deletedGridCodes, changedGridFields, changedGridCodes, espFundCodeFieldID, espBranchCodeFieldID,
                    ilsFundCodeFieldID, ilsLocationCodeFieldID, ilsMemberCodeRemainderFieldId, ilsMemberCodeLength, ilsPassEntireLocationAsRemainder, ilsPassPOAsLineNoteFieldId, ilsCollectionCodeFieldId);
            }
            catch
            {
                throw;
            }
        }
    }
}
