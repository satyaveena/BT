﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserGridCodeList : EditableObjectCollection<UserGridCode, GridDataAccessManager>
    {
        private bool _isGetInUseInfo = true;
        public bool IsGetInUseInfo 
        {
            get { return _isGetInUseInfo; }
            set { _isGetInUseInfo = value; }
        }
        protected override IEnumerable<UserGridCode> InternalLoadItems(Dictionary<string, object> parameters)
        {
            return CurrentDataAccessManager.GetAllUserGridCodes(parameters["GridFieldId"].ToString(), parameters["GridCodeId"].ToString(), isGetInUseInfo: _isGetInUseInfo, nocache: parameters["IsNoCache"].ToString());
        }
    }
}
