﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class GridCode : EditableObject<GridDataAccessManager>
    {
        public string GridCodeId
        {
            get { return Id; }
        }

        private string _gridFieldId;
        public string GridFieldId
        {
            get { return _gridFieldId; }
            set
            {
                SetChanged();
                _gridFieldId = value;
            }
        }

        private string _code;
        public string Code
        {
            get { return _code; }
            set
            {
                SetChanged();
                _code = value;
            }
        }

        private string _literal;
        public string Literal
        {
            get { return _literal; }
            set
            {
                SetChanged();
                _literal = value;
            }
        }

        private DateTime? _effectiveDate;
        public DateTime? EffectiveDate
        {
            get { return _effectiveDate; }
            set
            {
                SetChanged();
                _effectiveDate = value;
            }
        }

        private DateTime? _expirationDate;
        public DateTime? ExpirationDate
        {
            get { return _expirationDate; }
            set
            {
                SetChanged();
                _expirationDate = value;
            }
        }

        private bool _activeIndicator;
        public bool ActiveIndicator
        {
            get { return _activeIndicator; }
            set
            {
                SetChanged();
                _activeIndicator = value;
            }
        }


        private bool _deleteIndicator;
        public bool DeleteIndicator
        {
            get { return _deleteIndicator; }
            set
            {
                SetChanged();
                _deleteIndicator = value;
            }
        }

        private bool _isExpired;
        public bool IsExpired
        {
            get { return _isExpired; }
            set
            {
                SetChanged();
                _isExpired = value;
            }
        }

        private int _sequence;
        public int Sequence
        {
            get { return _sequence; }
            set 
            { 
                SetChanged();
                _sequence = value;
            }
        }

        public bool IsUsing { get; internal set; }

        public bool IsAuthorized { get; internal set; }

        public bool IsNoCache { get; set; }

        private bool _isGetInUseInfo = true;
        public bool IsGetInUseInfo 
        {
            get { return _isGetInUseInfo; }
            set { _isGetInUseInfo = value; }
        }
        //
        private UserGridCodeList _userGridCodes;
        public UserGridCodeList UserGridCodes
        {
            get
            {
                if (_userGridCodes == null)
                {
                    _userGridCodes = new UserGridCodeList() { IsGetInUseInfo = IsGetInUseInfo };
                    if (!string.IsNullOrEmpty(GridCodeId))
                        _userGridCodes.LoadItems((new Dictionary<string, object>
                                                 {
                                                     {"GridFieldId", GridFieldId},
                                                     {"GridCodeId", GridCodeId},
                                                     {"IsNoCache", IsNoCache}
                                                 }));
                }
                return _userGridCodes;
            }
            internal set
            {
                SetChanged();
                _userGridCodes = value;
            }
        }
        
        public string UserIDs { get; set; }

        public int AssignedUsersCount { get; set; }

        protected override void SaveSubObjects()
        {
            UpdateGridCodeIdToUserGridCodes();
            //
            if(_userGridCodes != null)
                _userGridCodes.Save();
        }

        private void UpdateGridCodeIdToUserGridCodes()
        {
            if (_userGridCodes != null)
            {
                foreach (var userGridCode in UserGridCodes)
                {
                    if (userGridCode.IsDataChanged())
                        userGridCode.GridCodeId = GridCodeId;
                }
            }
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateGridCode(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateGridCode(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteGridCode(this);
        }
    }
}
