﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.DataAccess;
using BTNextGen.Grid.Exception;

namespace BTNextgen.Grid
{
    public abstract class EditableObjectCollection<T, TD> : IEnumerable<T> where  TD: DataAccessManager where T : EditableObject<TD>        
    {               
        protected readonly List<T> Items;

        protected readonly List<T> ItemsToBeRemoved;

        protected TD CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<TD>(); }
        }

        public int Count { get { return Items.Count; } }

        private bool _enableTrackingChange;

        protected EditableObjectCollection()
        {
            Items = new List<T>();
            ItemsToBeRemoved = new List<T>();
            _enableTrackingChange = true;
        }

        public void EnableTrackingChanged()
        {
            _enableTrackingChange = true;
        }

        public void DisableTrackingChanged()
        {
            _enableTrackingChange = false;
        }

        public virtual void Add(T item)
        {            
            Items.Add(item);
        }

        public virtual void AddAt(int index, T item)
        {
            Items.Insert(index, item);
        }

        public virtual void AddRange(IEnumerable<T> items)
        {
            Items.AddRange(items);
        }

        public virtual void Remove(T item)
        {
            if (item!=null)
            {
                Items.Remove(item);
                if (_enableTrackingChange)
                    if (!string.IsNullOrEmpty(item.Id))
                    {
                        item.MarkRemove();
                        ItemsToBeRemoved.Add(item);
                    }
            }            
        }

        public virtual void RemoveById(string id)
        {
            var item = GetObjectById(id);
            Remove(item);            
        }

        public virtual void RemoveById(IEnumerable<string> idList)
        {
            foreach (var id in idList)
            {
                RemoveById(id);
            }            
        }

        public void Clear()
        {
            foreach (T item in Items)
            {
                item.MarkRemove();
                ItemsToBeRemoved.Add(item);
            }
            Items.Clear();
        }

        internal void LoadItems(Dictionary<string, object> parameters)
        {
            try
            {
                var items = InternalLoadItems(parameters);
                if (items != null)
                    Items.AddRange(items);
            }
            catch (CartGridLoadFailedException ex)
            {
                Logger.LogException(ex);
                throw;
            }
        }
        public void LoadItemsFromOutside(IEnumerable<T> items)
        {
            try
            {
                //var items = InternalLoadItems(parameters);
                if (items != null)
                    Items.AddRange(items);
            }
            catch (CartGridLoadFailedException ex)
            {
                Logger.LogException(ex);
                throw;
            }


        }
        internal List<T> GetRemovedItems()
        {
            return ItemsToBeRemoved;
        }

        protected virtual IEnumerable<T> InternalLoadItems(Dictionary<string, object> parameters)
        {
            return null;
        }

        public virtual void Validate()
        {
            
        }

        public virtual void Save()
        {
            Validate();
            bool isTransactionOwner = false;
            try
            {                
                //if there are no transaction has been started
                if (!CurrentDataAccessManager.TransactionStarted)
                {
                    //This object is an transaction owner.
                    isTransactionOwner = true;
                    CurrentDataAccessManager.BeginTransaction();
                }

                foreach (var itemToUpdate in Items)
                {
                    //Only really update for items changed.
                    if (itemToUpdate.IsDataChanged())
                        itemToUpdate.Save();
                }

                //Save items to be removed.
                foreach (var itemToRemove in ItemsToBeRemoved)
                {
                    itemToRemove.Save();
                }
                
                //
                ItemsToBeRemoved.Clear();
                //
                //If TransactionOwner--> commited
                if (isTransactionOwner)
                    CurrentDataAccessManager.CommitTransaction();
            }
            catch (Exception exception)
            {
                //If TransactionOwner--> rollback
                if (isTransactionOwner)
                    CurrentDataAccessManager.RollBackTransaction();
                //
                if (exception is CartGridSaveFailedException)
                {
                    //--TFS 6979: reduce ELMAH log
                    //Logger.LogException(exception);
                    throw new CartGridSaveFailedException(exception.Message);
                }
                throw;
            }            
        }


        protected virtual void PersistAllAsUpdate()
        {
            PersistAllAsUpdate();
        }

        public virtual void SaveAll()
        {
            Validate();
            bool isTransactionOwner = false;
            try
            {
                //if there are no transaction has been started
                if (!CurrentDataAccessManager.TransactionStarted)
                {
                    //This object is an transaction owner.
                    isTransactionOwner = true;
                    CurrentDataAccessManager.BeginTransaction();
                }

                PersistAllAsUpdate();
              
                //Save items to be removed.
                foreach (var itemToRemove in ItemsToBeRemoved)
                {
                    itemToRemove.Save();
                }

                //
                ItemsToBeRemoved.Clear();
                //
                //If TransactionOwner--> commited
                if (isTransactionOwner)
                    CurrentDataAccessManager.CommitTransaction();
            }
            catch (Exception exception)
            {
                //If TransactionOwner--> rollback
                if (isTransactionOwner)
                    CurrentDataAccessManager.RollBackTransaction();
                //
                if (exception is CartGridSaveFailedException)
                {
                    Logger.LogException(exception);
                    throw new CartGridSaveFailedException(exception.Message);
                }
                throw;
            }
        }

        public T GetObjectById(string id)
        {
            //LINQ object query
            return Items.SingleOrDefault(item => item.Id == id);
        }

        public IEnumerator<T> GetEnumerator()
        {
            return Items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return Items.GetEnumerator();
        }

        /// <summary>
        /// Sort Items assending by columnName
        /// </summary>
        /// <param name="columnName"></param>
        public virtual void SortAscending(string columnName)
        {

        }

        /// <summary>
        /// Sort Items assending by a list of columnNames.        
        /// </summary>
        /// <param name="columnNames"></param>
        public virtual void SortAscending(List<string> columnNames)
        {
            
        }

        /// <summary>
        /// Sort Items desending by a columnName.
        /// </summary>
        /// <param name="columnName"></param>
        public virtual void SortDescending(string columnName)
        {

        }

        /// <summary>
        /// Sort Items desending by a list of columnNames.
        /// </summary>
        /// <param name="columnNames"></param>
        public virtual void SortDescending(List<string> columnNames)
        {

        }        
    }
}
