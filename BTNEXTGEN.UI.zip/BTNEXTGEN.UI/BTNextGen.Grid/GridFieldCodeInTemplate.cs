﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Grid;

namespace BTNextgen.Grid
{
    public class GridFieldCodeInTemplate : EditableObject<GridDataAccessManager>
    {
        private string _gridTemplateLineId;
        public string GridTemplateLineId
        {
            get { return _gridTemplateLineId; }
            internal set
            {
                SetChanged();
                _gridTemplateLineId = value;
            }
        }

        private string _gridFieldId;
        public string GridFieldId
        {
            get { return _gridFieldId; }
            set
            {
                SetChanged();
                _gridFieldId = value;
            }
        }

        private string _gridCodeId;
        public string GridCodeId
        {
            get { return _gridCodeId; }
            set
            {
                SetChanged();
                _gridCodeId = value;
            }
        }

        private string _gridCode;
        public string GridCode
        {
            get { return _gridCode; }
            internal set
            {
                SetChanged();
                _gridCode = value;
            }
        }

        private string _gridText;
        public string GridText
        {
            get { return _gridText; }
            set
            {
                SetChanged();
                _gridText = value;
            }
        }
        //Position of the grid field in the de-normalized table.
        internal int GridFieldPosition { get; set; }

        public bool IsFreeText { get; set; }

        public bool IsAuthorized { get; set; }

        public FieldCodeStatus Status { get; set; }
    }
}
