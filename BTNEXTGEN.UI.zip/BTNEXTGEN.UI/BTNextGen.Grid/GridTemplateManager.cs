﻿using System;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextgen.Grid;
using BTNextGen.Grid.Helpers;

namespace BTNextGen.Grid
{
    public class GridTemplateManager
    {
        private string _userId;
        private string _orgId;
        public GridTemplateManager(string userId, string orgId)
        {
            _userId = userId;
            _orgId = orgId;
        }
        protected GridDataAccessManager CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<GridDataAccessManager>(); }
        }

        public CommonGridTemplate GetGridTemplate(string gridTemplateId)
        {
            return DistributedCacheHelper.GetGridTemplate(gridTemplateId, _orgId);
        }

        public CommonGridTemplate GetGridTemplateFromUser(string gridTemplateId)
        {
            var gridTemplates = GetGridTemplatesForUser();
            if (gridTemplates != null && gridTemplates.Any())
            {
                return gridTemplates.FirstOrDefault(x => x.GridTemplateId == gridTemplateId);
            }
            return null;
        }

        public CommonGridTemplate GetGridTemplateFromOrg(string gridTemplateId)
        {
            return DistributedCacheHelper.GetGridTemplate(gridTemplateId, _orgId);
        }

        public List<CommonGridTemplate> GetGridTemplatesForUser()
        {
            var gridTemplates = CurrentDataAccessManager.GetGridTemplatesByUser(_userId);
            if (gridTemplates == null) return null;

            var results = new List<CommonGridTemplate>();
            foreach (var gridTpl in gridTemplates)
            {
                if (IsValidTemplate(gridTpl))
                {
                    results.Add(gridTpl);
                }
            }
            return results.OrderBy(r => r.Name).ToList();
        }

        public List<CommonGridTemplateLine> LoadGridTemplateLines(string gridTemplateId)
        {
            var gridTemplateLines = CurrentDataAccessManager.GetGridTemplateLinesNew(gridTemplateId);

            CompileGridTemplateLineData(gridTemplateLines);
            gridTemplateLines = gridTemplateLines.OrderBy(x => x.Sequence).ToList();
            return gridTemplateLines;
        }

        public List<CommonGridTemplateLine> LoadDefaultGridTemplateLines(string cartId)
        {
            var gridTemplateLines = CurrentDataAccessManager.GetDefaultBasketGridTemplate(_userId, cartId);
            CompileGridTemplateLineData(gridTemplateLines);
            gridTemplateLines = gridTemplateLines.OrderBy(x => x.Sequence).ToList();
            return gridTemplateLines;
        }

        /// <summary>
        /// Check user permission on a grid template
        /// TRUE: All Grid Lines
        /// FALSE: Get Authorized Grid Lines Only
        /// </summary>
        /// <param name="gridTemplateId"></param>
        /// <returns></returns>
        public bool CheckUserRightOnGridTemplateLine(string gridTemplateId)
        {
            if (!CommonHelper.IsAuthorizeToUseAllGridCodes(_orgId))
            {
                if (string.IsNullOrEmpty(gridTemplateId)) return true;

                var userGridTemplate = CurrentDataAccessManager.GetUserGridTemplates(gridTemplateId);

                var userRight = string.Empty;
                if (userGridTemplate != null)
                {
                    var userTemplate = userGridTemplate.SingleOrDefault(x => x.UserId == _userId);
                    if (userTemplate != null)
                    {
                        userRight = userTemplate.RowExpensionRight.ToUpper();
                    }
                }
                return userRight == "ALL";
            }
            return true;
        }

        private bool AddFieldCodeInTemplate(List<GridTemplateFieldCode> gridCodeList, string gridCodeId, string gridFieldId, GridFieldType gridFieldType,
            List<CommonBaseGridUserControl.UIGridCode> orgGridCodes,
            List<CommonBaseGridUserControl.UIGridCode> userGridCodes, bool isShowCode = true)
        {
            var fc = GridDataHelper.LookUpGridFieldCode(userGridCodes, gridCodeId, isShowCode);
            if (fc != null)
            {
                fc.IsAuthorized = true;
            }
            else
            {
                fc = GridDataHelper.LookUpGridFieldCode(orgGridCodes, gridCodeId, isShowCode);
                if (fc != null)
                {
                    fc.IsAuthorized = false;
                }
            }
            if (fc != null && fc.GridFieldId == gridFieldId)
            {
                gridCodeList.Add(new GridTemplateFieldCode()
                                 {
                                     GridCodeId = fc.GridCodeId,
                                     GridFieldId = fc.GridFieldId,
                                     GridCode = fc.GridCodeValue,
                                     GridText = fc.GridTextValue,
                                     IsExpired = fc.IsExpired,
                                     IsFutureDate = fc.IsFutureDate,
                                     IsDisabled = fc.IsDisabled,
                                     IsAuthorized = fc.IsAuthorized,
                                     IsExpiredOrFutureDate = fc.IsExpiredOrFutureDate,
                                     GridFieldType = gridFieldType
                                 });
                return true;
            }
            return false;
        }

        private void CompileGridTemplateLineData(IEnumerable<CommonGridTemplateLine> gridTemplateLines)
        {
            var activeGridFields = DistributedCacheHelper.GetActiveGridFieldsForOrg(_orgId, true);
            var userGridFieldsCodes = UserGridFieldsCodesManager.Instance.GetUserGridFieldsCodes(_userId, _orgId);
            if (gridTemplateLines != null)
            {
                foreach (var gridLine in gridTemplateLines)
                {
                    var gridCodeList = new List<GridTemplateFieldCode>();
                    foreach (var gf in activeGridFields)
                    {
                        var isAdded = false;
                        var newFc = new GridTemplateFieldCode();
                        newFc.IsFreeText = gf.IsFreeText;
                        newFc.GridFieldId = gf.ID;
                        newFc.IsAuthorized = true;
                        newFc.GridFieldType = (GridFieldType)Enum.Parse(typeof(GridFieldType), gf.GridFieldType);
                        if (!gf.IsFreeText)
                        {
                            var isShowCode = true;
                            if (userGridFieldsCodes != null && userGridFieldsCodes.UserGridFields != null)
                            {
                                var userGridField = userGridFieldsCodes.UserGridFields.FirstOrDefault(x => x.GridFieldID == gf.ID);
                                if (userGridField != null)
                                    isShowCode = string.IsNullOrEmpty(userGridField.DisplayType) ||
                                                         userGridField.DisplayType.ToUpper() != "LITERAL";
                            }
                            if (userGridFieldsCodes != null)
                            {
                                isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.AgencyCodeID, gf.ID, GridFieldType.AgencyCode,
                                    gf.UIGridCodes, userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.ItemTypeID, gf.ID, GridFieldType.ItemType, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.CollectionID, gf.ID, GridFieldType.Collection, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.UserCode1ID, gf.ID, GridFieldType.UserCode1, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.UserCode2ID, gf.ID, GridFieldType.UserCode2, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.UserCode3ID, gf.ID, GridFieldType.UserCode3, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.UserCode4ID, gf.ID, GridFieldType.UserCode4, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.UserCode5ID, gf.ID, GridFieldType.UserCode5, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                                if (!isAdded)
                                    isAdded = AddFieldCodeInTemplate(gridCodeList, gridLine.UserCode6ID, gf.ID, GridFieldType.UserCode6, gf.UIGridCodes,
                                        userGridFieldsCodes.UserGridCodes, isShowCode);
                            }
                        }
                        else
                        {
                            var orgFieldCode = GridDataHelper.LookUpCallNumberGridFieldCodeInOrg(activeGridFields);
                            if (orgFieldCode != null && orgFieldCode.GridFieldId == gf.ID)
                            {
                                var callNumberFieldCode = new GridTemplateFieldCode
                                {
                                    GridFieldId = orgFieldCode.GridFieldId,
                                    GridText = gridLine.CallNumberText,
                                    IsAuthorized = true,
                                    IsExpired = false,
                                    IsFreeText = true,
                                    GridFieldType = GridFieldType.CallNumber
                                };
                                gridCodeList.Add(callNumberFieldCode);
                                isAdded = true;
                            }
                        }
                        if (!isAdded)
                            gridCodeList.Add(newFc);
                    }
                    gridLine.GridFieldCodeList = gridCodeList;
                }
            }
        }

        public string SaveGridTemplate(string organizationID, string gridTemplateID, string owerID, string templateName,
            string templateDescriptions, bool enableIndicator, List<CommonGridTemplateLine> gridTemplateLines,
            List<string> deletedLineIDs, string cartID, bool isDefault)
        {
            if (string.IsNullOrEmpty(gridTemplateID))
            {
                gridTemplateID = Guid.NewGuid().ToString("B");
            }

            CurrentDataAccessManager.SaveGridTemplate(organizationID, gridTemplateID, owerID, templateName,
                templateDescriptions, enableIndicator, gridTemplateLines,
                deletedLineIDs, cartID, isDefault);

            HttpHelper.ForceRefreshDistributedCacheForGridTemplates(organizationID);
            return gridTemplateID;
        }

        public void SaveUserGridTemplates(List<CommonGridTemplate> gridTemplatesForUpdate, List<string> gridTemplateIDsForDelete)
        {
            CurrentDataAccessManager.SaveUserGridTemplates(_userId, gridTemplatesForUpdate, gridTemplateIDsForDelete);

            DistributedCacheHelper.SetExpiredGridTemplates(_orgId);
        }

        public void SaveGridLinesAsTemplate(List<CommonGridTemplateLine> gridTemplateLines, string templateName,
            bool needToSaveQuantity, out string newTemplateNameIfDuplicated, out string newGridTemplateId)
        {
            CurrentDataAccessManager.SaveGridLinesAsAGridTemplate(_userId, gridTemplateLines, templateName, needToSaveQuantity, false, string.Empty,
                out newTemplateNameIfDuplicated, out newGridTemplateId, false);

            HttpHelper.ForceRefreshDistributedCacheForGridTemplates();
        }

        public void SaveGridLinesAsDefaultTemplate(List<CommonGridTemplateLine> gridTemplateLines, string defaultBasketId,
            out string newTemplateNameIfDuplicated, out string newGridTemplateId, bool overwriteGridDistributionOption, string templateName = "")
        {
            CurrentDataAccessManager.SaveGridLinesAsAGridTemplate(_userId, gridTemplateLines, templateName, true, true, defaultBasketId,
                out newTemplateNameIfDuplicated,
                out newGridTemplateId, overwriteGridDistributionOption);

            HttpHelper.ForceRefreshDistributedCacheForGridTemplates();
        }

        public List<GridTemplateOwner> GetGridTemplateOwners()
        {
            var owners = new List<GridTemplateOwner>();
            var orgGridTemplates = DistributedCacheHelper.GetGridTemplatesForOrg(_orgId);

            if (orgGridTemplates != null && orgGridTemplates.Any())
            {
                owners.AddRange(
                    orgGridTemplates
                    .Where(x => string.IsNullOrEmpty(x.DefaultBasketSummaryID))
                    .Select(
                        gt => new GridTemplateOwner { OwnerUserId = gt.OwnerUserID, Name = gt.OwnerUserName }));
                return owners.GroupBy(x => x.OwnerUserId).Select(x => x.First()).ToList();
            }
            return owners;
        }

        public List<CommonGridTemplate> GetGridTemplatesByOrg()
        {
            var templates = DistributedCacheHelper.GetGridTemplatesForOrg(_orgId);
            if (templates != null)
            {
                var results = new List<CommonGridTemplate>();
                foreach (var gridTpl in templates)
                {
                    if (IsValidTemplate(gridTpl) )
                    {
                        results.Add(gridTpl);
                    }
                }
                return results;
                //return templates.Where(x => !x.IsGridDistribution && !string.IsNullOrEmpty(x.Name) &&
                //    (string.IsNullOrEmpty(x.DefaultBasketSummaryID) ||
                //        (!string.IsNullOrEmpty(x.DefaultBasketSummaryID) &&
                //           (!x.GridDistributionOption.HasValue || x.GridDistributionOption == (int)GridDistributionOption.UseGridtemplate)))).ToList();
            }
            return null;
        }

        private bool IsValidTemplate(CommonGridTemplate gridTpl)
        {
            if (gridTpl == null) return false;

            var isAutoName = !string.IsNullOrEmpty(gridTpl.Name) && gridTpl.Name[0] == '(' && gridTpl.Name[gridTpl.Name.Length - 1] == ')';

            if (gridTpl.IsGridDistribution || string.IsNullOrEmpty(gridTpl.Name) || (string.IsNullOrEmpty(gridTpl.Description) && isAutoName)) return false;

            return true;
        }

        public List<CommonGridTemplate> GetGridTemplatesByOwner(string ownerId)
        {
            return DistributedCacheHelper.GetGridTemplatesByOwner(ownerId, _orgId);
        }

        public List<CommonGridTemplate> GetGridTemplatesByOwner(string ownerId, string orgId, bool hasDefault = false)
        {
            return DistributedCacheHelper.GetGridTemplatesByOwner(ownerId, orgId, hasDefault);
        }

        public void CopyGridTemplates(List<string> gridTemplateIds)
        {
            CurrentDataAccessManager.CopyGridTemplates(gridTemplateIds, _userId);

            DistributedCacheHelper.SetExpiredGridTemplates(_orgId);
        }

        public List<CommonGridTemplateLine> LoadCartGridDistribution(string userId, string cartId, string orgId, out int cartGridOption, out string templateId)
        {
            var gridTemplateLines = CurrentDataAccessManager.LoadCartGridDistribution(userId, cartId, orgId, out cartGridOption, out templateId);
            if (gridTemplateLines != null)
            {
                CompileGridTemplateLineData(gridTemplateLines);
                gridTemplateLines = gridTemplateLines.OrderBy(x => x.Sequence).ToList();
                return gridTemplateLines;
            }
            return null;
        }

        public bool SaveCartGridDistribution(string userId, string cartId, string orgId, int cartGridOption, string templateId, List<CommonGridTemplateLine> GridTemplateLine)
        {
            return CurrentDataAccessManager.SaveCartGridDistribution(userId, cartId, cartGridOption, templateId, GridTemplateLine);
        }

        public string GetDefaultGridTemplateId(string userId, string cartId)
        {
            return CurrentDataAccessManager.GetDefaultGridTemplateId(userId, cartId);
        }
    }
}
