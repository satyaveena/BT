﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class GridFieldList : EditableObjectCollection<GridField, GridDataAccessManager>
    {
        //public IEnumerable<GridField> GetActiveGridFields()
        //{
        //    var actives = from n in Items
        //                  where n.ActiveIndicator == true
        //                  select n;
        //    return actives;
        //}

        /// <summary>
        /// Get All available unused SOPGridField Type for current grid field list;
        ///  </summary>
        /// <returns></returns>
        //public List<SOPGridField> GetAvailableSOPGridFieldList()
        //{
        //    var sopGridFieldList = CartGridContext.Current.GridManager.GetAvailableSOPGridFieldList();
        //    foreach (var gridField in this)
        //    {
        //        var anyItem = sopGridFieldList.First(i => i.SOPGridFieldId == gridField.SOPGridFieldId);
                
        //        if (anyItem != null)
        //            sopGridFieldList.Remove(anyItem);
        //    }
        //    return sopGridFieldList;
        //}    

        //public bool CheckDuplicateName()
        //{
        //    var fieldNameNum = Items.Select(item => item.Name).Distinct(StringComparer.CurrentCultureIgnoreCase).Count();
        //    if (fieldNameNum < Items.Count)
        //        return true;
        //    return false;
        //}
    }
}
