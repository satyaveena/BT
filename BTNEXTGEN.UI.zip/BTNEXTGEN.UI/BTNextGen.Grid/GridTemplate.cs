﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Grid;

namespace BTNextgen.Grid
{
    public class GridTemplate : EditableObject<GridDataAccessManager>
    {        
        public string GridTemplateId
        {
            get { return Id; }            
        }

        private string _ownerUserId;
        public string OwnerUserId
        {
            get { return _ownerUserId; }
            set
            {
                SetChanged();
                _ownerUserId = value;
            }
        }

        /// <summary>
        /// Note: This is not going to persisted to DB. It facilitate the UI.
        /// </summary>
        public string OwnerUserName { get; set; }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                SetChanged();
                _name = value;
            }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set
            {
                SetChanged();
                _description = value;
            }
        }

        private bool _enableIndicator;
        public bool EnableIndicator
        {
            get { return _enableIndicator; }
            set
            {
                SetChanged();
                _enableIndicator = value;
            }
        }

        private string _createdBy;
        public string CreatedBy
        {
            get { return _createdBy; }
            set
            {
                SetChanged();
                _createdBy = value;
            }
        }

        private DateTime _lastModidied;
        public DateTime LastModidied
        {
            get { return _lastModidied; }
            set
            {
                SetChanged();
                _lastModidied = value;
            }
        }

        private int _gridTemplateLineCount;
        public int GridTemplateLineCount
        {
            get { return _gridTemplateLineCount; }
            set
            {
                SetChanged();
                _gridTemplateLineCount = value;
            }
        }
        private int _userGridTemplatesCount;
        public int UserGridTemplatesCount
        {
            get { return _userGridTemplatesCount; }
            set
            {
                SetChanged();
                _userGridTemplatesCount = value;
            }
        }

        //list of <fieldID column name, fieldID value>
        public Dictionary<string, string> GridFieldPositions { get; internal set; }

        private GridTemplateLineList _gridTemplateLines;
        public GridTemplateLineList GridTemplateLines 
        { 
            get
            {
                if (_gridTemplateLines == null)
                {
                    _gridTemplateLines = new GridTemplateLineList();
                    //
                    if (!string.IsNullOrEmpty(GridTemplateId))
                        _gridTemplateLines.LoadItems((new Dictionary<string, object>
                                                     {
                                                         {"GridTemplateId", GridTemplateId},
                                                         {"PageIndex", PageIndex},
                                                         {"PageSize", PageSize}
                                                     }));
                }
                return _gridTemplateLines;
            }
            internal set { _gridTemplateLines = value; }
        }

        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }

        private UserGridTemplateList _userGridTemplates;
        public UserGridTemplateList UserGridTemplates
        {
            get
            {
                if (_userGridTemplates == null)
                {
                    _userGridTemplates = new UserGridTemplateList();
                    //
                    if (!string.IsNullOrEmpty(GridTemplateId))
                        _userGridTemplates.LoadItems((new Dictionary<string, object>
                                                     {
                                                         {"GridTemplateId", GridTemplateId}
                                                     }));
                }
                return _userGridTemplates;
            }
            internal set { _userGridTemplates = value; }
        }

        public bool IsGridDistribution { get; set; }
        public int? GridDistributionOption { get; set; }
        public string DefaultBasketSummaryId { get; set; }
        public bool IsUserDefaultGridTemplate { get; set; }

        public List<GridTemplateLine> Find(string gridId, string gridCode)
        {            
            return
                _gridTemplateLines.Where(
                    i => i.GridFieldCodeInTemplates.Any(ii => ii.GridFieldId == gridId && ii.GridCode == gridCode)).ToList();
        }

        public void ReplaceAll(string gridId, string gridCodeToReplace, string newGridCode)
        {           
            SetChanged();
            foreach (GridTemplateLine line in _gridTemplateLines)
            {
                var gridFieldCodeInTemplates = line.GridFieldCodeInTemplates.Where(i => i.GridCode == gridCodeToReplace && i.GridFieldId == gridId);
                if (gridFieldCodeInTemplates.Any())
                {
                    foreach (GridFieldCodeInTemplate gridFieldCodeInTemplate in gridFieldCodeInTemplates)
                    {
                        gridFieldCodeInTemplate.GridCode = newGridCode;
                    }
                }
            }            
        }

        public override void Save()
        {
            base.Save();
            UpdateGridTemplateIdToGridTemplateLines();
            if(_gridTemplateLines != null)
                _gridTemplateLines.Save();
            //
            UpdateGridTemplateIdToUserGridTemplates();
            if(_userGridTemplates != null)
                _userGridTemplates.Save();
        }
        protected override void SaveSubObjects()
        {            
           
        }

        private void UpdateGridTemplateIdToUserGridTemplates()
        {
            if (_userGridTemplates != null)
            {
                foreach (var userGridTemplate in _userGridTemplates)
                {
                    userGridTemplate.GridTemplateId = GridTemplateId;
                }
            }
        }

        private void UpdateGridTemplateIdToGridTemplateLines()
        {
            if (_gridTemplateLines != null)
            {
                foreach (var gridTemplateLine in _gridTemplateLines)
                {
                    gridTemplateLine.GridTemplateId = GridTemplateId;
                }
            }
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateGridTemplate(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateGridTemplate(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteGridTemplate(this);
        }

        public void ApplyTemplate(GridTemplate gridTemplate)
        {
            SetChanged();
            _gridTemplateLines.AddRange(gridTemplate.GridTemplateLines);
        }

        /// <summary>
        /// Sort grid field column by the setup from organization
        /// </summary>
        public void SortByGridFieldSequence()
        {
            //var gridFields = CartGridContext.Current.GridManager.GetGridFields();
            //GridTemplateLines.SortByGridFieldsOrder(gridFields);
        }

        public List<UserGridTemplate> GetUserGridTemplates(string orgId, int pageIndex, int pageSize, out int total)
        {
            return CurrentDataAccessManager.GetUserGridTemplates(this.GridTemplateId, orgId, pageIndex, pageSize, out total);
        }
    }
}
