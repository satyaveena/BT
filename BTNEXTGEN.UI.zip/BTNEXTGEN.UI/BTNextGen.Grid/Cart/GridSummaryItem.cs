﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class GridSummaryItem
    {
        public int TotalTitles { get; set; }

        public int TotalQuantity { get; set; }

        public decimal TotalListPrice { get; set; }

        public decimal TotalEstDiscPrice { get; set; }

        public string GridField1Type { get; set; }

        public string GridField2Type { get; set; }

        public string GridField3Type { get; set; }

        public string GridField1Value { get; set; }

        public string GridField2Value { get; set; }

        public string GridField3Value { get; set; }

        public string DisplayValue1 { get; set; }

        public string DisplayValue2 { get; set; }

        public string DisplayValue3 { get; set; }

        public GridSummaryItemDetailList GetGridSummaryItemDetails(string cartId, int pageNum, int pageSize, string orderBy, bool? direction, bool viewMineOnly)
        {
            GridSummaryItemDetailList titles = new GridSummaryItemDetailList();
            var parameters = new Dictionary<string, object>
                                         {
                                             {"CartID", cartId},
                                             {"GridSummaryItem", this},
                                             {"PageNumber", pageNum},
                                             {"PageSize", pageSize},
                                             {"OrderBy", orderBy},
                                             {"Direction", direction},
                                             {"ViewMineOnly", viewMineOnly}
                                         };
            titles.LoadItems(parameters);
            return titles;
        }

        public bool HasZeroQuantity { get; set; }
    }
}
