﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class GridSummaryItemDetail:EditableObject<CartGridDataAccessManager>
    {
        public string LineItemID { get; set; }

        public string BTKey { get; set; }

        public string Title { get; set; }

        public string ISBN_UPC { get; set; }

        public int Quantity { get; set; }

        public string UpdatedByName { get; set; }
    }
}
