﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class DefaultCartGridTemplateLine : EditableObject<CartGridDataAccessManager>
    {
        public string DefaultCartGridTemplateLineId { get; set; }

        public DefaultCartGridFieldCodeList DefaultCartGridFieldCodes { get; set; }

    }
}
