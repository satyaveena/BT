﻿using System;
using System.Collections.Generic;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.Cart;
using BTNextGen.VelocityCaching;
using BTNextgen.Grid.Cart.Shared;
using BTNextGen.Commerce.Portal.Common.Search;
using CacheKeyConstant = BT.TS360Constants.CacheKeyConstant;
using CartMixMode = BT.TS360Constants.CartMixMode;

namespace BTNextgen.Grid.Cart
{
    public class CartGridManager
    {        
        internal CartGridDataAccessManager CurrentDataAccessManager { get; set; }

        internal CartGridManager()
        {
            
        }

        #region General Methods       

        /// <summary>
        /// Check if a cart is grid enabled cart
        /// </summary>
        /// <param name="cartId">Basket Summary Id</param>
        /// <returns></returns>
        public bool HasGrid(string cartId)
        {
            return CurrentDataAccessManager.HasGrid(cartId);
        }

        //public int TitleWithoutGridCount(string cartId)
        //{
        //    return CurrentDataAccessManager.TitleWithoutGridCount(cartId);            
        //}

        //public void SaveGridLinesAsAGridTemplate(List<CartGridLine> cartGridLines, string templateName, bool needToSaveQuantity, out string newTemplateNameIfDuplicated)
        //{
        //    //Need to check the duplicated template name of the current user to throw an exception here, then changed the name accordingly.
        //    //Add a sequence number suffix to the template name to prevent duplicated name, then let user know about that.
        //    //Refer to the FS_Item_Details_w_processing_charges function specification at Items Action/Save as Template
        //    CurrentDataAccessManager.SaveGridLinesAsAGridTemplate(cartGridLines, templateName, needToSaveQuantity, out newTemplateNameIfDuplicated);
        //}

        //public string SaveGridLinesAsDefaultGridTemplate(List<CommonCartGridLine> cartGridLines, string cartId)
        //{
        //    //Refer to the FS_Item_Details_w_processing_charges function specification at Items Action/Save as Default
        //    CurrentDataAccessManager.SaveGridLinesAsDefaultGridTemplate(cartId, cartGridLines);
        //    var defaultTemplate = GetDefaultCartGridTemplate(cartId);
        //    return defaultTemplate != null ? defaultTemplate.GridTemplateId : string.Empty;
        //}

        public List<GridNoteCount> GetCountForLineItem(string cartId, List<string> lineItems)
        {
            return CurrentDataAccessManager.GetCountForLineItemIds(cartId, lineItems);
        }

        #endregion

        #region CartLineExtension

        //public List<CartLineExtension> GetCartLineExtentions(List<string> lineItemIdList)
        //{
        //    return CurrentDataAccessManager.GetCartGridExtention(lineItemIdList);            
        //}
        /// <summary>
        /// Key:LineItemId; Value:BTKey
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="btkeys"></param>
        /// <returns></returns>
        public List<KeyValuePair<string, string>> GetNotesByBTKeys(string cartId, List<string> btkeys)
        {
            return CurrentDataAccessManager.GetNotesByBTKeys(cartId, btkeys);
        }
        public List<NoteClientObject> GetNotesByBTKeys(string cartId, string userId, List<string> btkeys, List<string> lineItemIds = null)
        {
            return CurrentDataAccessManager.GetNotesByBTKeys(cartId, userId, btkeys, lineItemIds);

        }
        public Dictionary<string, List<CartLineItemNoteQuantity>> GetNotesByLineItemId(List<string> lineItemIds)
        {
            return CurrentDataAccessManager.GetCartLineItemNoteQuantities(lineItemIds);
        }

        public void UpdateLineItemNoteQuantity(CartLineItemNoteQuantity cartLineItemNoteQuantity)
        {
            CurrentDataAccessManager.UpdateCartLineItemNoteQuantity(cartLineItemNoteQuantity);
        }
        /// <summary>
        /// Get GetCartGridExtension list with validation and error code filter.
        /// </summary>
        /// <param name="lineItemIdList"></param>
        /// <param name="shouldValidate"></param>
        /// <param name="errorCodeFilter">
        /// if errorCodeFilter = null/empty---> no filter.
        /// errorCodeFilter value are a list of errorCodes separated by a comma.
        /// </param>
        /// <returns></returns>
        public List<string> GetCartLineExtentions(List<string> lineItemIdList, bool shouldValidate, string errorCodeFilter)
        {
            return CurrentDataAccessManager.GetCartGridExtention(lineItemIdList, shouldValidate, errorCodeFilter);            
        }

        public List<string> GetErrorLineItems(string cartId, string errorCodeFilter, int pageSize, int pageNumber, string orderBy,
            string direction, out int totalPage)
        {
            Dictionary<string, bool> lineHasGrid;
            return GetErrorLineItems(cartId, errorCodeFilter, pageSize, pageNumber, orderBy, direction, out totalPage,
                                     out lineHasGrid);
        }

        /// <summary>
        /// Get all line item id that have errors in its grid.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="errorCodeFilter">
        /// if errorCodeFilter = null/empty---> no filter.
        /// errorCodeFilter value are a list of errorCodes separated by a comma.
        /// </param>
        /// <param name="pageSize"></param>
        /// <param name="pageNumber"></param>
        /// <param name="orderBy"></param>
        /// <param name="direction"></param>
        /// <param name="totalPage"></param>
        /// <param name="lineHasGrid">indicate that the line item has Grid Lines or not</param>
        /// <returns>List of line items.</returns>
        public List<string> GetErrorLineItems(string cartId, string errorCodeFilter, int pageSize, int pageNumber,string orderBy, 
            string direction, out int totalPage, out Dictionary<string, bool> lineHasGrid)
        {
            try
            {
                lineHasGrid = new Dictionary<string, bool>();

                var cacheKey = string.Format("GetErrorLineItems_{0}_{1}{2}{3}{4}{5}", cartId, errorCodeFilter.Replace(";", "_"), pageSize, 
                    pageNumber, orderBy, direction);
                var cacheKeyTotalPage = string.Format("GetErrorLineItems_{0}_{1}{2}{3}{4}{5}_TotalPage", cartId, errorCodeFilter.Replace(";", "_"), pageSize,
                    pageNumber, orderBy, direction);
                var errorIds = VelocityCacheManager.Read(cacheKey) as List<string>;
                var cacheTotalPage = VelocityCacheManager.Read(cacheKeyTotalPage);

                if (errorIds == null || cacheTotalPage == null)
                {
                    errorIds = CurrentDataAccessManager.GetErrorLineItems(cartId, errorCodeFilter, pageSize, pageNumber, orderBy,
                    direction, out totalPage, out lineHasGrid);

                    VelocityCacheManager.Write(cacheKey, errorIds, GridCacheConstants.CommonGridCacheLevel);
                    VelocityCacheManager.Write(cacheKeyTotalPage, totalPage, GridCacheConstants.CommonGridCacheLevel);

                    cacheTotalPage = totalPage;
                }
                totalPage = (int)cacheTotalPage;
                return errorIds;
            }
            catch (Exception exception)
            {
                Logger.Write("GetErrorLineItems", exception.Message);
                throw;
            }
        }

        

        #endregion
        
        #region LineItem Action      

        /// <summary>
        /// Remove grid from a line item id.
        /// </summary>
        /// <param name="lineItemId"></param>
        /// <param name="keepQuantity">True: Keep total quanity at line item, False: Set total quantity to Zero</param>
        public void RemoveGridFromLineItem(string lineItemId, bool keepQuantity)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Line Item Action/Remove Grid.
            CurrentDataAccessManager.RemoveGridFromLineItem(lineItemId, keepQuantity);
        }

        /// <summary>
        /// Remove grid from a list of line item id.
        /// </summary>
        /// <param name="lineItemIdList"></param>
        /// <param name="keepQuantity">True: Keep total quanity at line item, False: Set total quantity to Zero</param>
        public void RemoveGridFromLineItem(List<string> lineItemIdList, bool keepQuantity)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Line Item Action/Remove Grid.
            CurrentDataAccessManager.RemoveGridFromLineItems(lineItemIdList, keepQuantity);
        }      

        #endregion

        #region Cart Action

        #region General Cart Actions        

        /// <summary>
        /// Will update R2.0 Framework.
        /// </summary>
        //public void SearchWithinCartByTitle(string cartId, string facetPath, string keywork, string searchBy, int pageNumber, int pageSize, string sortBy, out int totalLines)
        //{
        //    //The current application need to switch to this method
        //    //Refer to the FS_Item_Details_w_processing_charges function specification at Search Within Cart.
        //    CurrentDataAccessManager.SearchWithinCartByTitle(cartId, facetPath, keywork, pageNumber, pageSize, sortBy, out totalLines);            
        //}

        
        /// <summary>
        /// Remove grid from a cart id.
        /// </summary>
        /// <param name="cartId">BasketSummaryId</param>
        /// <param name="keepQuantity">True: Keep total quanity at line item, False: Set total quantity to Zero</param>       
        public void RemoveGridFromCart(string cartId, bool keepQuantity)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Remove Grid.
            CurrentDataAccessManager.RemoveGridFromCart(cartId, keepQuantity);            
        }

        public void DeleteZeroQuantityTitlesAndGridLines(string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Delete Zero Quantity Titles|Grid Lines
            CurrentDataAccessManager.DeleteZeroQuantityTitlesAndGridLines(cartId);            
        }

        /// <summary>
        /// Create a copy of Cart
        /// </summary>
        /// <param name="cartId">CartId to copy</param>
        /// <param name="newCartName">New Cart name</param>
        /// <param name="destinationFolderId">Destination folderId the cart will be copied to, this parameter may be null or empty</param>
        /// <param name="newFolderName">New folder name if any, this param is required when detinationFolderId is null or empty</param>
        /// <param name="cartCopyType"></param>
        /// <remarks>Will have methods for shared cart</remarks>
        public void CreateACopyOfCart(string cartId, string newCartName, string destinationFolderId, string newFolderName, CartCopyType cartCopyType, bool copyESP)
        {
            //Update the R2.0 cart framework.
            //If destinationFolderId = null or empty, create a new folder with newFolderName.
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Create Copy of Cart.
            CurrentDataAccessManager.CreateACopyOfCart(cartId, newCartName, destinationFolderId, newFolderName, cartCopyType, copyESP);            
        }

        public void ReplaceAllGridFieldCodeInCart(string cartId, GridFieldType gridFieldType, string gridCodeId, string gridText, string newGridCodeId,
            string newFreeTextId, out int totalCount)
        {
            CurrentDataAccessManager.ReplaceAllGridFieldCodeInCart(cartId, gridFieldType, gridCodeId, gridText, newGridCodeId, newFreeTextId, 
                out totalCount);
        }

        public void ReplaceAllGridLineQuantityInCart(string cartId, int currentQty, int newQty, out int totalCount)
        {
            CurrentDataAccessManager.ReplaceAllGridLineQuantityInCart(cartId, currentQty, newQty, out totalCount);
        }

        /// <summary>
        /// Transfer a cart to a list of users
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="userIdList">A List of UserId the cart will be transfer to</param>
        /// <param name="keepACopy">To indicate that if the transfer user want to keep a copy before transfer the cart to others user</param>
        public void TransferCartToUsers(string cartId, List<string> userIdList, bool keepACopy)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Transfer Cart.
            //Refer to the FS_Carts List Page function specification at Cart Panel/Selected Cart Actions/Transfer Cart
            CurrentDataAccessManager.TransferCartToUsers(cartId, userIdList, keepACopy);
        }
        
        public string CheckEbookAccountInfoForOrg(string cartId, string orgIDs)
        {
            return CurrentDataAccessManager.CheckEbookAccountInfoForOrg(cartId, orgIDs);
        }

        /// <summary>
        /// Append, Replace or Delete notes to all titles in a cart.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="note"></param>
        /// <param name="requestType">Append, Replace or Delete</param>
        public void ModifyNoteToAllTitles(string cartId, string note, string requestType)
        {
            CurrentDataAccessManager.ModifyNoteToAllTitles(cartId, note, requestType);
        }

        public int GetLengthOfLongestNote(string cartId)
        {

            return CurrentDataAccessManager.GetLengthOfLongestNote(cartId);
        }

        /// <summary>
        /// Get GridSummary for a cart.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="field1">Field 1</param>
        /// <param name="field2">Field 2</param>
        /// <param name="field3Type">Field 3</param>
        /// <param name="viewMyGridLineOnly"></param>
        /// <param name="sortBy"></param>
        /// <param name="direction"></param>
        /// <returns></returns>
        public GridSummary GetGridSummary(string cartId, string field1Type, string field2Type, string field3Type, bool viewMyGridLineOnly, string sortBy, bool? direction)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Summary/Grid Summary.
            return CurrentDataAccessManager.GetGridSummary(cartId, field1Type, field2Type, field3Type, viewMyGridLineOnly, sortBy, direction);            
        }
      
        public void SetBlankGridLineToCart(string cartId)
        {
            //TFS #5605 - Apply a blank grid line to all non-grid titles to a Grid Cart.
            CurrentDataAccessManager.SetBlankGridLineToCart(cartId);
        }

        public List<string> SplitCartToGridAndNonGrid(string cartId)
        {
            //TFS #5605 - Split a cart to grid cart and nongrid cart
            return CurrentDataAccessManager.SplitCartToGridAndNonGrid(cartId);
        }

        public CartMixMode CheckCartContainsBothGridAndNonGridTitles(string cartId)
        {
            //TFS #5605 - Check if a cart has a mix of grid and non-grid titles
            return CurrentDataAccessManager.CheckCartContainsBothGridAndNonGridTitles(cartId);
        }

        //public CartSplitResult SplitCart(string cartId, SplitCartMode splitCartOption, string userId, out Dictionary<string, string> separatedCarts)
        //{
        //    //TFS #5605 - Split a cart to grid cart and nongrid cart
        //    return CurrentDataAccessManager.SplitCart(cartId, splitCartOption, userId, out separatedCarts);
        //}

        public void ConvertPBookToEBook(string sourceBasketSummaryID, string newCartName, string folderId, string userID, string eSupplierPreference, string digitalFormatPerference)
        {
            CurrentDataAccessManager.ConvertPBookToEBook(sourceBasketSummaryID, newCartName, folderId, userID, eSupplierPreference, digitalFormatPerference);
        }

        #endregion        

        #region Apply Template to Cart       

        /// <summary>
        /// Check duplicate gridTemplate to be applied to CartId
        /// This will be used with ApplyTemplateToCartAppendToAllTitles method.
        /// </summary>
        /// <param name="gridTemplateId"></param>
        /// <param name="cartId">Basket Summary Id</param>
        /// <returns></returns>
        public bool CheckDuplicatedCartGridLineTemplate(string gridTemplateId, string cartId)
        {
            return CurrentDataAccessManager.CheckDuplicatedCartGridLineTemplate(gridTemplateId, cartId);
        }

        public void ApplyTemplateToCartAppendToAllTitles(string gridTemplateId, string cartId, bool duplicatedAllow)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply template.
            //Will apply all template items to lineItem of the flag Authorize to All user  = true in the grid template. Otherwise, just apply authorized template lines
            //Do not apply disable, or expired template line, or furure date.            
            CurrentDataAccessManager.ApplyTemplateToCartAllTitles(gridTemplateId, cartId, duplicatedAllow);            
        }

        public void ApplyTemplateToNonGridTitles(string gridTemplateId, string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply template.
            //Will apply all template items to lineItem of the flag Authorize to All user  = true in the grid template. Otherwise, just apply authorized template lines
            //Do not apply disable, or expired template line, or furure date.
            //Only apply to title has not been applied a grid.
            CurrentDataAccessManager.ApplyTemplateToNonGridTitles(gridTemplateId, cartId);            
        }

        public void ApplyTemplateToTitleAsReplace(string gridTemplateId, string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply template.
            //Remove all old Grid, then apply a new one.
            //Will apply all template items to lineItem of the flag Authorize to All user  = true in the grid template. Otherwise, just apply authorized template lines
            //Do not apply disable, or expired template line, or furure date.
            CurrentDataAccessManager.ApplyTemplateToTitleAsReplace(gridTemplateId, cartId);            
        }

        #endregion

        #region Aplly Default Template to Cart.        

        public GridTemplate GetDefaultCartGridTemplate(string cartId)
        {
            return CurrentDataAccessManager.GetDefaultCartGridTemplate(cartId);            
        }

        /// <summary>
        /// Check if a cart has a default grid template or not.
        /// </summary>
        /// <param name="cartId"></param>
        public bool HasDefaultCartGridTemplate(string cartId)
        {
            return CurrentDataAccessManager.HasDefaultCartGridTemplate(cartId);            
        }

        /// <summary>
        /// Check if there are any grid line in a cart that is duplicated with its the default template.
        /// This method will be used with ApplyDefaultGridTemplateToCartAllTitle method.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        public bool CheckDuplicateDefaultTemplateForCart(string cartId)
        {
            return CurrentDataAccessManager.CheckDuplicateDefaultTemplateForCart(cartId);            
        }
        
        /// <summary>
        ///Apply default grid template of a cart for all titles in cart. The default template is at user/cart level
        ///The default grid template is a template has been saved by calling SaveAsDefaultCartGridTemplate method
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="duplicatedAllow"></param>
        /// <param name="mergeQuantityBySum"></param>
        public void ApplyDefaultGridTemplateToCartAllTitle(string cartId, bool duplicatedAllow, bool mergeQuantityBySum)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply Default/All Title.            
            CurrentDataAccessManager.ApplyDefaultGridTemplateToCartAllTitle(cartId, duplicatedAllow, mergeQuantityBySum);            
        }        

        /// <summary>
        ///Apply default grid template of a cart for Non-Grid line item only. The default template is at user/cart level
        ///The default grid template is a template has been saved by calling SaveAsDefaultCartGridTemplate method
        /// </summary>
        /// <param name="cartId"></param>
        public void ApplyDefaultGridTemplateToCartNonGridTitles(string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply Default/Non-Grid
            CurrentDataAccessManager.ApplyDefaultGridTemplateToCartNonGridTitles(cartId);
        }

        /// <summary>
        ///Apply default grid template of a cart as a replacement. The default template is at user/cart level
        ///The default grid template is a template has been saved by calling SaveAsDefaultCartGridTemplate method
        /// </summary>
        /// <param name="cartId"></param>
        public void ApplyDefaultGridTemplateToCartAsAReplace(string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply Default/Replace Grid for all title
            CurrentDataAccessManager.ApplyDefaultGridTemplateToCartAsAReplace(cartId);            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="DeleteDefaultGridTemplate"></param>
        /// <returns></returns>
        public bool DeleteDefaultGridTemplate(string cartId, bool isDeleteGridTemplate)
        {
            return CurrentDataAccessManager.DeleteDefaultGridTemplate(cartId, isDeleteGridTemplate);
        }

        #endregion

        #region Paste GridLine from Clipboard 360 to Cart

        /// <summary>
        /// Check duplicate grid line of a cart before pasting Grid from Clipboard360
        /// </summary>
        /// <param name="cartGridLines"></param>
        /// <param name="cartId"></param>
        /// <returns></returns>
        //public bool CheckDuplicateGridLineCart(List<CartGridLine> cartGridLines, string cartId)
        //{
        //    //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Paste Grid Lines
        //    return CurrentDataAccessManager.CheckDuplicateGridLineCart(cartGridLines, cartId);            
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cartGridLines"></param>
        /// <param name="toCartId"></param>
        /// <param name="duplicatedAllow"></param>        
        public void PasteGridLineFromClipboard360ToCart(List<CommonGridTemplateLine> cartGridLines, string toCartId, bool duplicatedAllow)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Paste Grid Lines
            CurrentDataAccessManager.PasteGridLineFromClipboard360ToCart(cartGridLines, toCartId, duplicatedAllow, true);            
        }

        #endregion

        #endregion

        #region Add Product To Cart
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="products">Dictionary[btKey, quantity]</param>
        /// <param name="cartGridLines"></param>
        /// <param name="note"></param>
        /// <param name="toCartId"></param>
        /// <param name="toCartName"></param>
        /// <param name="toFolderId"></param>
        public void AddProductToCart(List<ProductLineItem> products, Dictionary<string, List<CommonCartGridLine>> cartGridLines, string toCartId,
            out string PermissionViolationMessage, out int totalAddingQuantity)
        {
            //Refer to FS_Master_Add_NG32_Original_Entry
            CurrentDataAccessManager.AddProductsToCart(products, cartGridLines, toCartId, out PermissionViolationMessage, out totalAddingQuantity);
        }

        public void AddProductToCartBatchEntry(List<ProductLineItem> products, Dictionary<string, List<CommonCartGridLine>> cartGridLines, string toCartId,
            out string PermissionViolationMessage, out int totalAddingQuantity)
        {
            if (products == null || products.Count == 0)
            {
                PermissionViolationMessage = "";
                totalAddingQuantity = 0;
                return;
            }

            CurrentDataAccessManager.AddProductToCartBatchEntry(products, cartGridLines, toCartId, out PermissionViolationMessage, out totalAddingQuantity);
        }

        public void AddBatchToBackgroundProcessing(string fileName, Dictionary<string, List<CommonCartGridLine>> cartGridLines, string toCartId, string userID,
                                                    string eSuppliers, Boolean IsValidateBTKey, string organizationID)
        {
            CurrentDataAccessManager.AddBatchToBackgroundProcessing(fileName, cartGridLines, toCartId, userID, eSuppliers, IsValidateBTKey, organizationID);

        }

        public bool ValidateGridInCartForLibrarySystemAccount(string cartId, string accountId)
        {
            return CurrentDataAccessManager.ValidateGridInCartForLibrarySystemAccount(cartId, accountId);
        }
        #endregion

        #region Shared Cart

        /// <summary>
        /// Check if a cart is a shared cart, or a private cart.
        /// </summary>
        /// <param name="cartId">Basket Summary Id</param>
        /// <returns>True: Shared Cart, False: Private Cart</returns>
        public bool IsSharedCart(string cartId)
        {
            return CurrentDataAccessManager.IsSharedCart(cartId);
        }

        /// <summary>
        /// Check if a cart has a shared cart profile associated
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        public bool HasSharedCartProfile(string cartId, out string ownerId)
        {
            return CurrentDataAccessManager.HasSharedCartProfile(cartId, out ownerId);
        }

        /// <summary>
        /// Used to check if a cart is a premium shared cart.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns>True: Premium Shared Cart, False: Non-Premium Shared Cart</returns>
        public bool IsPremiumSharedCart(string cartId)
        {
            return CurrentDataAccessManager.IsPremiumSharedCart(cartId);
        }

        /// <summary>
        /// Get Shared Cart profile of a cart id.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns>SharedCartProfile</returns>
        public SharedCartProfile GetSharedCartProfile(string cartId, bool? hasProfile = null, string ownerId = null)
        {
            //string ownerId = string.Empty;
            var profile = (SharedCartProfile)VelocityCacheManager.Read(CacheKeyConstant.SHARE_CART_PROFILE_CACHE_KEY_PREFIX + cartId);
            if (profile == null)
            {
                if ((hasProfile.HasValue && !string.IsNullOrEmpty(ownerId))
                    || HasSharedCartProfile(cartId, out ownerId))
                {
                    profile = new SharedCartProfile() { CartId = cartId, CartOwnerId = ownerId };
                }
                else
                {
                    //
                    profile = CreateSharedCartProfile(cartId);
                }
                VelocityCacheManager.Write(CacheKeyConstant.SHARE_CART_PROFILE_CACHE_KEY_PREFIX + cartId, profile, GridCacheConstants.CommonGridCacheLevel);
                return profile;
            }
            return profile;
        }

        /// <summary>
        /// Create a SharedCartProfile object in memory for a cart id.
        /// This SharedCartProfile has not persisted to the database.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns>SharedCartProfile</returns>
        private SharedCartProfile CreateSharedCartProfile(string cartId)
        {            
            var sharedCartProfile = new SharedCartProfile() {CartId = cartId, CartOwnerId = CurrentDataAccessManager.UserId};
            sharedCartProfile.InitialDefaultValue();
            return sharedCartProfile;
        }

        /// <summary>
        /// Checks if user is cart member.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool IsSharedCartMember(string cartId, string userId)
        {
            return CurrentDataAccessManager.IsSharedCartMember(cartId, userId);
        }

        ///<summary>
        /// Get all SharedCart Members Workflow Stages 
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="sharedCartMemberIds">List of memberIDs to get workflows</param>
        /// <returns>List of Shared cart member workflow stages </returns>
        public IEnumerable<SharedCartMemberWorkflowStage>  GetAllSharedCartMemberWorkflowStages(string cartId, List<string> sharedCartMemberIds)
        {
            return CurrentDataAccessManager.GetSharedCartMemberWorkflowStages(cartId, sharedCartMemberIds);
        }
        /// <summary>
        /// Get CartUserGroupList of current login user/context.
        /// </summary>
        /// <returns></returns>
        public CartUserGroupList GetCartUserGroups()
        {
            var result = new CartUserGroupList();
            result.AddRange(CurrentDataAccessManager.GetCartUserGroups());
            return result;         
        }

        public CartUserGroup GetCartUserGroup(string cartUserGroupId)
        {
            var result = new CartUserGroup {Id = cartUserGroupId};            
            return result;
        }

        /// <summary>
        /// Get Shared Cart Summary
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="viewMineOnly">True: View only the summary for current login user, false: All users</param>
        /// <param name="sortBy">"User Name", "Total Titles", "Total Quantity", "Total List Price", "Est Disc Price"</param>
        /// <returns></returns>
        public SharedCartSummary GetSharedCartSummary(string cartId, bool viewMineOnly, string sortBy, bool? direction)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Summary/Share Summary.
            return CurrentDataAccessManager.GetSharedCartSummary(cartId, viewMineOnly, sortBy, direction);
        }

        /// <summary>
        /// Get Shared Cart Summary
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="userId"></param>
        /// <param name="sortBy">"Title", "ISBN", "Quantity"</param>
        /// <returns></returns>
        public SharedCartSummaryItemDetailList GetSharedCartSummaryItemDetail(string cartId, string userId, string sortBy, bool? direction)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Summary/Share Summary.
            return CurrentDataAccessManager.GetSharedCartSummaryDetail(cartId, userId, sortBy, direction);
        }  
        /// <summary>
        /// Get All workflow stage for an current organization.
        /// </summary>
        /// <returns></returns>
        public OrganizationWorkflowStageList GetOrganizationWorkflowStageList(string cartId)
        {
            var result = new OrganizationWorkflowStageList();
            result.AddRange(CurrentDataAccessManager.GetOrganizationWorkflowStages(cartId));
            return result;
        }

        public IEnumerable<SharedCartWorkflowStage> GetSharedCartWorkflowStages(string cartId)
        {
            return CurrentDataAccessManager.GetSharedCartWorkflowStages(cartId);
        }

        public SharedCartMemberWorkflowStageList GetSharedCartMemberWorkflowStages(string cartId, string sharedCartMemberId)
        {
            var result = new SharedCartMemberWorkflowStageList();
            result.AddRange(CurrentDataAccessManager.GetSharedCartMemberWorkflowStages(cartId, sharedCartMemberId));
            return result;
        }

        public bool HasPermission(string cartId)
        {
            if(IsSharedCart(cartId))
            {
                if(IsPremiumSharedCart(cartId))
                {
                    var sharedCartMember = GetSharedCartProfile(cartId).GetCurrentSharedCartMember();
                    return sharedCartMember == null || sharedCartMember.IsValidTimeToUpdate();
                }
                return true;
            }

            return true;
        }

        public bool HasPermissionToAddProductToCart(string cartId)
        {
            if (IsSharedCart(cartId))
            {
                if (IsPremiumSharedCart(cartId))
                {
                    var sharedCartMember = GetSharedCartProfile(cartId).GetCurrentSharedCartMember();
                    return sharedCartMember == null || sharedCartMember.IsValidTimeToAddProductToCart();
                }
                return true;
            }

            return true;
        }

        public bool HasPermissionOnGroup(string cartId)
        {
            if (IsSharedCart(cartId))
            {
                if (IsPremiumSharedCart(cartId))
                {
                    var sharedCartMember = GetSharedCartProfile(cartId).GetCurrentSharedCartMember();
                    return sharedCartMember == null || sharedCartMember.IsValidTimeToUpdateGroup();
                }
                return true;
            }

            return true;
        }

        public bool HasPermissionForSelectedCartBatchEntry(string cartId)
        {
            if (IsSharedCart(cartId))
            {
                if (IsPremiumSharedCart(cartId))
                {
                    var sharedCartMember = GetSharedCartProfile(cartId).GetCurrentSharedCartMember();
                    return sharedCartMember == null || sharedCartMember.IsValidTimeForBatchEntry();
                }
                return true;
            }

            return true;
        }

        #endregion
    }
}
