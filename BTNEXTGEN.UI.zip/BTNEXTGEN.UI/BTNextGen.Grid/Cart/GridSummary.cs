﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class GridSummary
    {
        public int TotalTitles { get; set; }

        public int TotalQuantity { get; set; }

        public decimal TotalListPrice { get; set; }

        public decimal TotalEstDiscPrice { get; set; }

        public List<GridSummaryItem> Items { get; set; }
    }
}
