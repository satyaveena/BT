﻿using System;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.Helpers;

namespace BTNextgen.Grid.Cart
{
    public class CartLineItemGridManager
    {
        private List<string> _lineItemIds = new List<string>();

        private Dictionary<string, List<CommonCartGridLine>> _dicCartGridLineList =
            new Dictionary<string, List<CommonCartGridLine>>();
        private List<string> _deletedGridLineIDs = new List<string>();
        protected CartGridDataAccessManager CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<CartGridDataAccessManager>(); }
        }

        public void AddLineItemId(string id)
        {
            if (!_lineItemIds.Contains(id))
                _lineItemIds.Add(id);

            if (!_dicCartGridLineList.ContainsKey(id))
                _dicCartGridLineList.Add(id, new List<CommonCartGridLine>());
        }

        public void SetAddedCartGridLines(string lineItemId, List<CommonCartGridLine> addedCartGridLines)
        {
            List<CommonCartGridLine> gridLines;
            if (_dicCartGridLineList.ContainsKey(lineItemId))
            {
                gridLines = _dicCartGridLineList[lineItemId];
            }
            else
            {
                gridLines = new List<CommonCartGridLine>();
                _dicCartGridLineList[lineItemId] = gridLines;
            }
            gridLines.AddRange(addedCartGridLines);
        }

        public void SetUpdatedCartGridLines(string lineItemId, List<CommonCartGridLine> addedCartGridLines)
        {
            List<CommonCartGridLine> gridLines;
            if (_dicCartGridLineList.ContainsKey(lineItemId))
            {
                gridLines = _dicCartGridLineList[lineItemId];
            }
            else
            {
                gridLines = new List<CommonCartGridLine>();
                _dicCartGridLineList[lineItemId] = gridLines;
            }
            gridLines.AddRange(addedCartGridLines);
        }

        public void SetDeletedCartGridLines(List<string> deletedGridLineIDs)
        { 
            _deletedGridLineIDs.AddRange(deletedGridLineIDs);
        }
        
        public void SaveGridLines()
        {
            if (_dicCartGridLineList == null || _dicCartGridLineList.Count == 0)
                return;

            CurrentDataAccessManager.UpdateAllCartGridLines(_lineItemIds, _dicCartGridLineList, _deletedGridLineIDs);
        }

        public Dictionary<string, List<CommonCartGridLine>> LoadCartLineItemGridLines(string userId, string orgId, List<string> lineItemIds)
        {
            var activeGridFields = DistributedCacheHelper.GetActiveGridFieldsForOrg(orgId, true);
            var userGridFieldsCodes = UserGridFieldsCodesManager.Instance.GetUserGridFieldsCodes(userId, orgId);

            var dict = CurrentDataAccessManager.GetCartGridLinesNewGrid(lineItemIds);

            foreach (var lineItemId in lineItemIds)
            {
                if (dict.ContainsKey(lineItemId))
                {
                    var cartGridLines = dict[lineItemId];
                    cartGridLines = cartGridLines.OrderBy(x => x.Sequence).ToList();
                    foreach (var gridLine in cartGridLines)
                    {
                        RefineCartGridLineFieldCodes(gridLine, activeGridFields, userGridFieldsCodes);
                    }
                    dict[lineItemId] = cartGridLines;
                }
                else
                {
                    dict.Add(lineItemId, new List<CommonCartGridLine>());
                }
            }
            return dict;
        }

        private void RefineCartGridLineFieldCodes(CommonCartGridLine gridLine, 
                                                    List<CommonBaseGridUserControl.UIGridField> activeGridFields,
                                                    UserGridFieldsCodes userGridFieldsCodes )
        {
            var refinedGridFieldCodes = new List<CartGridLineFieldCode>();
            
            foreach (var gf in activeGridFields)
            {
                var newFc = new CartGridLineFieldCode();
                newFc.IsFreeText = gf.IsFreeText;
                newFc.GridFieldId = gf.ID;
                
                var isShowCode = true;
                if (userGridFieldsCodes != null && userGridFieldsCodes.UserGridFields != null)
                {
                    var userGridField = userGridFieldsCodes.UserGridFields.FirstOrDefault(x => x.GridFieldID == gf.ID);
                    if (userGridField != null)
                        isShowCode = string.IsNullOrEmpty(userGridField.DisplayType) ||
                                               userGridField.DisplayType.ToUpper() != "LITERAL";
                }
                foreach (var gfc in gridLine.GridFieldCodeList)
                {                    
                    if (!gfc.IsFreeText)
                    {                        
                        if (userGridFieldsCodes != null)
                        {
                            var fc = GridDataHelper.LookUpGridFieldCode(userGridFieldsCodes.UserGridCodes, gfc.GridCodeId, isShowCode);
                            if (fc != null && fc.GridFieldId == gf.ID)
                            {
                                fc.IsAuthorized = true;
                                newFc = fc;
                                break;
                            }
                        }

                        var fullFc = GridDataHelper.LookUpGridFieldCode(gf.UIGridCodes, gfc.GridCodeId, isShowCode);
                        if (fullFc != null && fullFc.GridFieldId == gf.ID)
                        {
                            newFc = fullFc;
                            newFc.IsAuthorized = false;
                            break;
                        }
                        //if (!string.IsNullOrEmpty(gfc.GridCodeId))
                        //{
                        //    hasUnAuthorizedGridCode = true;
                        //}
                    }
                    else
                    {
                        var freeTextFc = GridDataHelper.LookUpCallNumberGridFieldCodeInOrg(activeGridFields);
                        if (!string.IsNullOrEmpty(freeTextFc.GridFieldId) && freeTextFc.GridFieldId == gf.ID)
                        {
                            newFc = freeTextFc;
                            freeTextFc.GridTextValue = gfc.GridTextValue;
                            freeTextFc.IsAuthorized = true;                            
                            break;
                        }
                    }
                }
                
                newFc.GridFieldType = CommonHelper.ConvertToGridFieldType(gf.GridFieldType);
                refinedGridFieldCodes.Add(newFc);
            }
            gridLine.GridFieldCodeList = refinedGridFieldCodes;
            gridLine.IsAuthorized = !refinedGridFieldCodes.Exists(x=>x.IsAuthorized == false && !string.IsNullOrEmpty(x.GridCodeId));
        }
    }
}
