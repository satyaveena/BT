﻿namespace BTNextgen.Grid.Cart.Shared
{
    /// <summary>
    /// List of Users are shared for a cart.
    /// </summary>
    public class SharedCartMemberList : EditableObjectCollection<SharedCartMember, CartGridDataAccessManager>
    {
        /// <summary>
        /// Add a CartUserGroup to SharedCartMemberList
        /// </summary>
        /// <param name="cartUserGroup"></param>
        public void AddUserGroup(CartUserGroup cartUserGroup)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Summary Information/Shared Profile/Shared Cart with Additional Users
            //Need to merge duplicate user with highest permission.
        }

        protected override System.Collections.Generic.IEnumerable<SharedCartMember> InternalLoadItems(System.Collections.Generic.Dictionary<string, object> parameters)
        {
            return CurrentDataAccessManager.GetSharedCartMembers(parameters["CartID"].ToString());            
        }
    }
}
