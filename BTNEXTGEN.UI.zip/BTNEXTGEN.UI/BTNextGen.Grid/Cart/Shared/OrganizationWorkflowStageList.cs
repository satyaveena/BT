﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart.Shared
{
    public class OrganizationWorkflowStageList : EditableObjectCollection<OrganizationWorkflowStage, CartGridDataAccessManager>
    {

    }
}
