﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart.Shared
{
    /// <summary>
    /// Organization Workflow Stage information to contain a custom Stage Alias name
    /// </summary>
    public class OrganizationWorkflowStage : EditableObject<CartGridDataAccessManager>
    {
        public string OrganizationWorkflowStageId { get { return Id; } }
        
        public string OrganizationId { get; set; }

        public WorkflowStage Stage { get; set; }

        /// <summary>
        /// StageAlias of current organization
        /// </summary>
        public string StageAlias { get; set; }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateOrganizationWorkflowStage(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateOrganizationWorkflowStage(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteOrganizationWorkflowStage(Id);
        }
    }
}
