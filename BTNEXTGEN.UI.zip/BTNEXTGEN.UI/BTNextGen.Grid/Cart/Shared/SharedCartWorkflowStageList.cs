﻿using System;

namespace BTNextgen.Grid.Cart.Shared
{
    public class SharedCartWorkflowStageList : EditableObjectCollection<SharedCartWorkflowStage, CartGridDataAccessManager>
    {
        internal bool IsNewStageAdded { get; set; }
        protected override System.Collections.Generic.IEnumerable<SharedCartWorkflowStage> InternalLoadItems(System.Collections.Generic.Dictionary<string, object> parameters)
        {
            return CurrentDataAccessManager.GetSharedCartWorkflowStages(parameters["SharedCartWorkFlowId"].ToString());            
        }
        public void Sort()
        {
            Items.Sort((stage, workflowStage) => stage.Stage.CompareTo(workflowStage.Stage));            
        }

        public SharedCartWorkflowStage NextStage(SharedCartWorkflowStage currentStage)
        {
            var nextStages = Items.FindAll(item => item.Stage > currentStage.Stage);
            if (nextStages.Count == 0)
                return null;
            nextStages.Sort((x,y) => x.Stage.CompareTo(y.Stage));
            return nextStages[0];
        }

        public SharedCartWorkflowStage PreviousStage(SharedCartWorkflowStage currentStage)
        {
            var previousStages = Items.FindAll(item => item.Stage < currentStage.Stage);
            if (previousStages.Count == 0)
                return null;
            previousStages.Sort((x, y) => x.Stage.CompareTo(y.Stage));
            return previousStages[previousStages.Count-1];
        }
        public override void Add(SharedCartWorkflowStage item)
        {
            IsNewStageAdded = true;
            base.Add(item);
        }

        public override void AddRange(System.Collections.Generic.IEnumerable<SharedCartWorkflowStage> items)
        {
            IsNewStageAdded = true;
            base.AddRange(items);
        }

    }
}
