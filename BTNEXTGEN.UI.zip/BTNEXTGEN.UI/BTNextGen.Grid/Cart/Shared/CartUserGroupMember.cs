﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart.Shared
{
    public class CartUserGroupMember : EditableObject<CartGridDataAccessManager>
    {
        public String CartUserGroupMemberId
        {
            get { return Id; }
            internal set { Id = value; }
        }

        public string CartUserGroupId { get; set; }
        public string UserName { get; set; }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                SetChanged();
                _userId = value;
            }
        }

        private bool _hasContribution;
        public bool HasContribution
        {
            get { return _hasContribution; }
            set
            {
                SetChanged();
                _hasContribution = value;
            }
        }

        private bool _hasRequisition;
        public bool HasRequisition
        {
            get { return _hasRequisition; }
            set
            {
                SetChanged();
                _hasRequisition = value;
            }
        }

        private bool _hasReview;
        public bool HasReview
        {
            get { return _hasReview; }
            set
            {
                SetChanged();
                _hasReview = value;
            }
        }

        private bool _hasAcquisition;
        public bool HasAcquisition
        {
            get { return _hasAcquisition; }
            set
            {
                SetChanged();
                _hasAcquisition = value;
            }
        }

        private bool _isOwner;
        public bool IsOwner
        {
            get { return _isOwner; }
            set
            {
                SetChanged();
                _isOwner = value;
            }
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateCartUserGroupMember(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateCartUserGroupMember(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteCartUserGroupMember(Id);
        }
    }
}
