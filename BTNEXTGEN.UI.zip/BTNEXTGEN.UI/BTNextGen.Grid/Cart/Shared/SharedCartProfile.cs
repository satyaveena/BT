﻿using System;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.Grid.Exception;

namespace BTNextgen.Grid.Cart.Shared
{
    public class SharedCartProfile : EditableObject<CartGridDataAccessManager>
    {        
        public string CartId { get; internal set; }

        public string CartOwnerId { get; internal set; }

        private SharedCartWorkflow _workflow;
        public SharedCartWorkflow Workflow
        {
            get 
            {
                if (_workflow == null && !string.IsNullOrEmpty(CartId))
                {
                    _workflow = CurrentDataAccessManager.GetSharedCartWorkflow(CartId);
                }
                return _workflow;
            }
            set
            {
                SetChanged();
                _workflow = value;
            }
        }

        /// <summary>
        /// Need to set SharedCartProfile to the SharedCartMember object after loading.
        /// </summary>
        private SharedCartMemberList _sharedCartMembers;
        public SharedCartMemberList SharedCartMembers
        {
            get
            {
                if (_sharedCartMembers == null)
                {
                    _sharedCartMembers = new SharedCartMemberList();
                    if(!string.IsNullOrEmpty(CartId))
                        _sharedCartMembers.LoadItems(new Dictionary<string, object>{{"CartID", CartId}});
                    UpdateShareCartProfileToMembers();
                }
                
                return _sharedCartMembers;
            }
            internal set { _sharedCartMembers = value; }
        }                

        internal SharedCartProfile()
        {
            
        }
       
        public void InitialDefaultValue()
        {
            SharedCartMembers = new SharedCartMemberList();
            SharedCartMembers.AddRange(CurrentDataAccessManager.GetSharedCartMembers(CartId));
            if (SharedCartMembers.Count == 0)
            {
                var sharedCartMember = new SharedCartMember
                                           {
                                               SharedCartProfile = this,
                                               CartId = CartId,
                                               HasOwner = true,
                                               UserId = CurrentDataAccessManager.UserId
                                           };
                SharedCartMembers.Add(sharedCartMember);
            }
        }

        protected override void SaveSubObjects()
        {
            if (_workflow != null)
            {
                _workflow.SharedCartWorkflowId = CartId;
                _workflow.Save();
            }
            //
            if (_sharedCartMembers != null)
            {
                UpdateCartIDToMembers();
                _sharedCartMembers.Save();
            }
        }

        public override void Save()
        {
            var isWorkflowChange = _workflow.WorkflowStages.IsNewStageAdded;
            //check if new workflow stages added update to all members which HasOwner = true
            if (isWorkflowChange)
            {
                foreach (SharedCartMember member in SharedCartMembers)
                {
                    if (member.HasOwner)
                    {
                        foreach (SharedCartWorkflowStage stage in _workflow.WorkflowStages)
                        {
                            if (member.SharedCartMemberWorkflowStages.Count(i => i.Stage == stage.Stage) == 0)
                            {
                                member.SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage
                                                                              {Stage = stage.Stage});
                            }
                        }
                    }
                }
            }
            
            base.Save();

            //Reload _workflow if workflow stages are removed/added to get newest CurrentWorkflowStage
            if (isWorkflowChange)
            {
                _workflow = CurrentDataAccessManager.GetSharedCartWorkflow(CartId);
            }
        }

        public void Share(string requisitionType)
        {
            CurrentDataAccessManager.ShareCart(CartId, requisitionType);
        }

        public SharedCartWorkflowStage GetCurrentWorkflowStageObject()
        {
            if (Workflow != null)
            {
                if (Workflow.CompletionDate != null)
                    return null;
                //
                return GetWorkflowStageObject(Workflow.CurrentWorkflowStage);
            }
            return null;
        }

        public SharedCartWorkflowStage GetWorkflowStageObject(WorkflowStage stage)
        {
            if(Workflow != null)
                return Workflow.WorkflowStages.FirstOrDefault(i => i.Stage == stage);
            return null;
        }

        public WorkflowStatus GetWorkflowStatus(WorkflowStage stage)
        {
            
            SharedCartWorkflowStage workflowStage = Workflow.WorkflowStages.FirstOrDefault(i => i.Stage == stage);
            if (workflowStage != null)
                return workflowStage.Status;
            throw new CartGridException("The workflow stage is not available");
        }

        /// <summary>
        /// Get Shared Cart member information for current login user
        /// </summary>
        /// <returns></returns>
        public SharedCartMember GetCurrentSharedCartMember()
        {
            if (SharedCartMembers != null)
                return SharedCartMembers.FirstOrDefault(i => i.UserId == CurrentDataAccessManager.UserId);
            return new SharedCartMember();
        }

        private void UpdateShareCartProfileToMembers()
        {
            if (_sharedCartMembers != null)
            {
                foreach (SharedCartMember sharedCartMember in _sharedCartMembers)
                {
                    sharedCartMember.SharedCartProfile = this;
                }
            }
        }
        private void UpdateCartIDToMembers()
        {
            if (_sharedCartMembers != null)
            {
                foreach (SharedCartMember sharedCartMember in _sharedCartMembers)
                {
                    sharedCartMember.CartId = CartId;
                }
            }
        }
    }
}
