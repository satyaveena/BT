﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart.Shared
{
    public class CartUserGroupList : EditableObjectCollection<CartUserGroup, CartGridDataAccessManager>
    {
        public override void Add(CartUserGroup item)
        {
            //Need to check duplicate name here. The shared cart group name must be unique.
            //Throw exception if duplicated.
            base.Add(item);
        }        
    }
}
