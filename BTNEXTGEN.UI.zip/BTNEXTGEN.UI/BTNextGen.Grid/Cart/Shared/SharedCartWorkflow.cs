﻿using System;
using System.Linq;
using System.Collections.Generic;
using BTNextGen.Grid.Exception;

namespace BTNextgen.Grid.Cart.Shared
{
    public class SharedCartWorkflow : EditableObject<CartGridDataAccessManager>
    {
        public string SharedCartWorkflowId
        {
            get { return Id; }
            set
            {
                //SetChanged();
                Id = value;
            }
        }

        private string _timezone;
        public string TimeZone
        {
            get { return _timezone; }
            set
            {
                SetChanged();
                _timezone = value;
            }
        }

        private DateTime? _completionDate;
        public DateTime? CompletionDate
        {
            get { return _completionDate; }
            set
            {
                SetChanged();
                _completionDate = value;
            }

        }

        private SharedCartWorkflowStageList _workflowStages;
        public SharedCartWorkflowStageList WorkflowStages
        {
            get
            {
                if (_workflowStages == null)
                {
                    _workflowStages = new SharedCartWorkflowStageList();
                    if (!string.IsNullOrEmpty(SharedCartWorkflowId))
                    {
                        _workflowStages.LoadItems(new Dictionary<string, object> { { "SharedCartWorkFlowId", SharedCartWorkflowId } });
                    }
                }
                if (_workflowStages.Count > 0)
                {
                    _workflowStages.Sort();
                }

                return _workflowStages;
            }
            internal set { _workflowStages = value; }
        }

        protected override void Validate()
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Summary Information/Shared Profile/Specify End Date for Contribution, Requisition, Review                                     
            if (_workflowStages != null)
            {
                _workflowStages.Sort();
                foreach (SharedCartWorkflowStage stage in _workflowStages)
                {
                    if (stage.EndDateTime != null)
                    {
                        var previous = _workflowStages.PreviousStage(stage);
                        switch (stage.Stage)
                        {
                            case WorkflowStage.Acquisition:
                            case WorkflowStage.Contribution:
                                break;
                            case WorkflowStage.Requisition:

                                if (previous != null && previous.EndDateTime != null && stage.EndDateTime != null &&
                                    stage.EndDateTime < previous.EndDateTime)
                                    throw new CartGridException("Invalid End Date Time between Workflow Stages");
                                break;
                            case WorkflowStage.Review:

                                if (previous != null && previous.EndDateTime != null && stage.EndDateTime != null &&
                                    stage.EndDateTime <= previous.EndDateTime)
                                    throw new CartGridException("Invalid End Date Time between Workflow Stages");
                                if (previous != null && previous.EndDateTime == null)
                                {
                                    previous = _workflowStages.PreviousStage(previous);
                                    if (previous != null && previous.EndDateTime != null && stage.EndDateTime != null &&
                                    stage.EndDateTime <= previous.EndDateTime)
                                        throw new CartGridException("Invalid End Date Time between Workflow Stages");
                                }
                                break;
                        }
                    }
                }

            }
            base.Validate();
        }

        /// <summary>
        /// Current workflow stage.
        /// </summary>
        public WorkflowStage CurrentWorkflowStage { get; set; }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateSharedCartWorkflow(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateSharedCartWorkflow(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteSharedCartWorkflow(Id);
        }

        protected override void SaveSubObjects()
        {
            if (_workflowStages != null)
            {
                UpdateSharedCartWorkflowIdToChildren();
                Validate();
                _workflowStages.Save();
            }
        }

        private void UpdateSharedCartWorkflowIdToChildren()
        {
            foreach (SharedCartWorkflowStage workflowStage in _workflowStages)
            {
                workflowStage.CartId = Id;
            }
        }

        public static bool HasRightForCurrentWorkflowReviewAcquisition(string cartId, string userId)
        {
            if (string.IsNullOrEmpty(cartId) || string.IsNullOrEmpty(userId))
                return false;

            var cartGridManager = new CartGridDataAccessManager();
            cartGridManager.UserId = userId;
            cartGridManager.Initialize();
            // get current cart workflow stage
            var workflow = cartGridManager.GetSharedCartWorkflow(cartId);
            if (workflow.CurrentWorkflowStage != WorkflowStage.Closed)
            {
                // get user rights
                var workflowStages = cartGridManager.GetSharedCartWorkflowStages(cartId);
                var hasIncompleteStage = workflowStages.Any(stage => !stage.IsCompleted());
                if (!hasIncompleteStage) // all stages completed
                    return false;
                var sharedCartMembers = cartGridManager.GetSharedCartMembers(cartId);
                if (sharedCartMembers != null && sharedCartMembers.Any())
                {
                    var sharedCartMember = sharedCartMembers.FirstOrDefault(
                        r => r.UserId.Equals(userId, StringComparison.CurrentCultureIgnoreCase));
                    if (sharedCartMember != null)
                    {
                        if (workflow.CurrentWorkflowStage == WorkflowStage.Review && sharedCartMember.HasReview)
                            return true;
                        else if (workflow.CurrentWorkflowStage == WorkflowStage.Acquisition &&
                                 sharedCartMember.HasAcquisition)
                            return true;
                        else if (workflow.CurrentWorkflowStage == WorkflowStage.Contribution &&
                                 sharedCartMember.HasContribution)
                            return true;
                        else if (workflow.CurrentWorkflowStage == WorkflowStage.Requisition &&
                                 sharedCartMember.HasRequisition)
                            return true;
                    }
                }
            }

            return false;
        }
    }
}
