﻿
namespace BTNextgen.Grid.Cart.Shared
{
    public enum WorkflowStage
    {
        Contribution = 1,
        Requisition = 2,
        Review = 3,
        Acquisition = 4,
        Closed = 5
    }
}
