﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart;

namespace BTNextGen.Grid.Cart.Shared
{
    public class SharedCartSummaryItemDetail:EditableObject<CartGridDataAccessManager>
    {
        public string Title { get; internal set; }

        public string ISBN { get; internal set; }

        public int Quantity { get; internal set; }
        
        public string BTKey { get; internal set; }

        public string LineItemID { get; internal set; }
    }
}
