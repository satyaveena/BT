﻿using System;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common.Helpers;

namespace BTNextgen.Grid.Cart.Shared
{
    public class SharedCartWorkflowStage : EditableObject<CartGridDataAccessManager>
    {
        public string CartId { get; internal set; }

        private WorkflowStage _stage;
        public WorkflowStage Stage
        {
            get { return _stage; }
            set
            {
                SetChanged();
                _stage = value;
            }
        }

        private DateTime? _completionDate;
        public DateTime? CompletionDate
        {
            get { return _completionDate; }
            set
            {
                SetChanged();
                _completionDate = value;
            }
        }

        private DateTime? _endDateTime;
        public DateTime? EndDateTime
        {
            get { return _endDateTime; }
            set
            {
                SetChanged();
                _endDateTime = value;
            }
        }

        private WorkflowStatus _status;
        public WorkflowStatus Status
        {
            get { return _status; }
            set
            {
                SetChanged();
                _status = value;
            }
        }

        /// <summary>
        /// StageAlias of current organization
        /// </summary>
        private string _stageAlias;
        public string StageAlias
        {
            get { return _stageAlias; }
            set
            {
                SetChanged();
                _stageAlias = value;
            }
        }

        public SharedCartWorkflowStage()
        {
            Status = WorkflowStatus.NotStarted;
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateSharedCartWorkflowStage(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateSharedCartWorkflowStage(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteSharedCartWorkflowStage(Id);
        }

        public bool IsValidTimeToUpdate()
        {
            return (Status == WorkflowStatus.InProgress);
        }

        public bool IsCompleted()
        {
            var currentDateTime = CommonHelper.GetCurrentDateTimeByTimeZone();
            return (Status == WorkflowStatus.Completed) || ((EndDateTime < currentDateTime) && (CompletionDate != null));
        }
    }
}
