﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart.Shared
{
    public class CartUserGroup : EditableObject<CartGridDataAccessManager>
    {
        public String CartUserGroupId { get { return Id; } set { Id = value; } }

        private string _name;
        public string Name
        { 
            get { return _name; } 
            set
            {
                SetChanged();
                _name = value;
            }
        }

        private bool _workflowEnabled;
        public bool WorkflowEnabled
        {
            get { return _workflowEnabled; }
            set
            {
                SetChanged();
                _workflowEnabled = value;
            }
        }

        /// <summary>
        /// Must apply lazy loading.
        /// </summary>
        private CartUserGroupMemberList _members;
        public CartUserGroupMemberList Members
        {
            get
            {
                if (_members == null)
                {
                    _members = new CartUserGroupMemberList();
                    if (!string.IsNullOrEmpty(CartUserGroupId))
                    {
                        _members.LoadItems(new Dictionary<string, object> {{"CartUserGroupId", CartUserGroupId}});
                    }
                }
                return _members;
            }
            internal set
            {
                SetChanged();
                _members = value;
            }
        }

        protected override void SaveSubObjects()
        {
            if (_members != null)
            {
                UpdateUserGroupIdToMembers();
                _members.Save();
            }
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateCartUserGroup(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateCartUserGroup(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteCartUserGroup(Id);
        }

        private void UpdateUserGroupIdToMembers()
        {
            if (_members == null)
                return;
            //
            foreach (var member in _members)
            {
                if (member.IsDataChanged())
                    member.CartUserGroupId = CartUserGroupId;
            }
        }
    }
}
