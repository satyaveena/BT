﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Grid.Cart.Shared;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart;

namespace BTNextGen.Grid
{
    public class SharedCartSummaryItemDetailList : EditableObjectCollection<SharedCartSummaryItemDetail, CartGridDataAccessManager>
    {
        protected override IEnumerable<SharedCartSummaryItemDetail> InternalLoadItems(Dictionary<string, object> parameters)
        {
            var cartId = parameters["CartId"] as string;
            var userId = parameters["UserId"] as string;
            var sortBy = parameters["SortBy"] as string;
            var direction = Convert.ToBoolean(parameters["Direction"] as string);
            var items = CurrentDataAccessManager.GetSharedCartSummaryDetail(cartId, userId, sortBy, direction);
            
            return items;
        }
    }
}
