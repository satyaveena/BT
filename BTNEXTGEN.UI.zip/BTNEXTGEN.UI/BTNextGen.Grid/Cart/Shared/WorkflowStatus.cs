﻿namespace BTNextgen.Grid.Cart.Shared
{
    public enum WorkflowStatus
    {
        InProgress = 2,
        Completed = 3,
        NotStarted = 1,
        Missing = 0
    }
}
