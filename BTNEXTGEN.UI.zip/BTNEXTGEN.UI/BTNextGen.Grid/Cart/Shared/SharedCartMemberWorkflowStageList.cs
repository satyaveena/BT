﻿using BTNextGen.Grid.Exception;

namespace BTNextgen.Grid.Cart.Shared
{
    public class SharedCartMemberWorkflowStageList : EditableObjectCollection<SharedCartMemberWorkflowStage, CartGridDataAccessManager>
    {
        protected override System.Collections.Generic.IEnumerable<SharedCartMemberWorkflowStage> InternalLoadItems(System.Collections.Generic.Dictionary<string, object> parameters)
        {
            return base.InternalLoadItems(parameters);
        }

        public void Remove(WorkflowStage stage)
        {
            Items.Remove(Items.Find(i => i.Stage == stage));
        }

        public bool Contains(WorkflowStage stage)
        {
            return Items.Find(item => item.Stage == stage) != null;
        }

        public override void Save()
        {
            if(Items.Count > 4)
                throw new CartGridException("Have too many workflow stage");
            base.Save();
        }
        public void Sort()
        {
            Items.Sort((stage, workflowStage) => stage.Stage.CompareTo(workflowStage.Stage));            
        }
        
    }
}
