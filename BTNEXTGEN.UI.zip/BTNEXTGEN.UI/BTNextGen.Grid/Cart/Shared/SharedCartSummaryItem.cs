﻿using System.Collections.Generic;
using BTNextGen.Grid;
using BTNextGen.Grid.Cart.Shared;

namespace BTNextgen.Grid.Cart.Shared
{
    public class SharedCartSummaryItem
    {
        public string UserId { get; internal set; }

        public string LoginId { get; internal set; }

        public string UserName { get; internal set; }

        public int TotalTitles { get; internal set; }

        public int TotalTitlesWithoutGrid { get; internal set; }

        public int TotalQuantity { get; internal set; }

        public decimal TotalListPrice { get; internal set; }

        public decimal TotalNetPrice { get; internal set; }

        public decimal TotalEstimateDiscountPrice { get; internal set; }
        
        public SharedCartSummaryItemDetailList GetSharedCartSummaryItemDetails(string cartId, string userId, string sortBy, bool? direction)
        {
            SharedCartSummaryItemDetailList titles = new SharedCartSummaryItemDetailList();
            var parameters = new Dictionary<string, object>
                                         {
                                             {"CartID", cartId},
                                             {"GridSummaryItem", userId},
                                             {"SortBy", sortBy},
                                             {"Direction", direction}
                                         };
            titles.LoadItems(parameters);
            return titles;
        }
    }
}
