﻿using System;
using BTNextGen.Commerce.Portal.Common.Helpers;

namespace BTNextgen.Grid.Cart.Shared
{
    /// <summary>
    /// Note: This object must be re-loaded after every stage updated to reset the CompletedByAllUser.
    /// </summary>
    public class SharedCartMemberWorkflowStage : EditableObject<CartGridDataAccessManager>
    {
        public string SharedCartMemberId { get; set; }

        private WorkflowStage _stage;
        public WorkflowStage Stage 
        { 
            get { return _stage; }
            set
            {
                SetChanged();
                _stage = value;
            } 
        }        
       
        public DateTime? CompletionDateTime { get; set; }

        private bool _isCompleted;

        private bool _stageFinished;
        public bool StageFinished
        {
            get { return _stageFinished; }
            set
            {
                SetChanged();
                _stageFinished = value;
            }
        }

        public bool IsCompleted
        {
            get { return _isCompleted; }
            set
            {
                SetChanged();
                if(value)
                    CompletionDateTime = CommonHelper.GetCurrentDateTimeByTimeZone();
                else
                {
                    CompletionDateTime = null;
                }
                _isCompleted = value;
            }
        }

        internal void InternalSetIsCompleted(bool isCompleted)
        {
            _isCompleted = isCompleted;
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateSharedCartMemberWorkflowStage(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateSharedCartMemberWorkflowStage(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteSharedCartMemberWorkflowStage(Id);
        }
    }
}
