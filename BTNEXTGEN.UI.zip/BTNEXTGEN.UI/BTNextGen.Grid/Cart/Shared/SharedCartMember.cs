﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BTNextgen.Grid.Cart.Shared
{
    /// <summary>
    /// 
    /// </summary>
    public class SharedCartMember : EditableObject<CartGridDataAccessManager>
    {
        public string SharedCartMemberId { get { return Id; } }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                SetChanged();
                _userId = value;
            }
        }

        public string UserFullName { get; set; } // Full name of shared member

        private string _cartId;
        public string CartId
        {
            get { return _cartId; }
            set
            {
                SetChanged();
                _cartId = value;
            }
        } //Basket Summary Id

        private bool _hasContribution;
        public bool HasContribution
        {
            get { return _hasContribution; }
            set
            {
                if (value)
                {
                    if (!SharedCartMemberWorkflowStages.Contains(WorkflowStage.Contribution) && IsShareCartProfileContainsStage(WorkflowStage.Contribution))
                    {
                        SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage
                                                               {
                                                                   SharedCartMemberId = SharedCartMemberId,
                                                                   Stage = WorkflowStage.Contribution,
                                                               });
                    }
                    _hasContribution = true;
                }
                else
                {
                    SharedCartMemberWorkflowStages.Remove(WorkflowStage.Contribution);
                    _hasContribution = false;
                }

            }
        }

        private bool IsShareCartProfileContainsStage(WorkflowStage workflowStage)
        {
            if (SharedCartProfile == null || SharedCartProfile.Workflow == null ||
                SharedCartProfile.Workflow.WorkflowStages == null)
            {
                return false;
            }

            return SharedCartProfile.Workflow.WorkflowStages.Any(stage => stage.Stage == workflowStage);
        }

        private bool _hasRequisition;
        public bool HasRequisition
        {
            get { return _hasRequisition; }
            set
            {
                if (value)
                {
                    if (!SharedCartMemberWorkflowStages.Contains(WorkflowStage.Requisition) && IsShareCartProfileContainsStage(WorkflowStage.Requisition))
                    {
                        SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage
                                                               {
                                                                   SharedCartMemberId = SharedCartMemberId,
                                                                   Stage = WorkflowStage.Requisition,
                                                               });
                    }
                    _hasRequisition = true;
                }
                else
                {
                    SharedCartMemberWorkflowStages.Remove(WorkflowStage.Requisition);
                    _hasRequisition = false;
                }
            }
        }

        private bool _hasReview;
        public bool HasReview
        {
            get { return _hasReview; }
            set
            {
                if (value)
                {
                    if (!SharedCartMemberWorkflowStages.Contains(WorkflowStage.Review) && IsShareCartProfileContainsStage(WorkflowStage.Review))
                    {
                        SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage
                                                               {
                                                                   SharedCartMemberId = SharedCartMemberId,
                                                                   Stage = WorkflowStage.Review,
                                                               });
                    }
                    _hasReview = true;
                }
                else
                {
                    SharedCartMemberWorkflowStages.Remove(WorkflowStage.Review);
                    _hasReview = false;
                }
            }
        }

        private bool _hasAcquisition;
        public bool HasAcquisition
        {
            get { return _hasAcquisition; }
            set
            {
                if (value)
                {
                    if (!SharedCartMemberWorkflowStages.Contains(WorkflowStage.Acquisition) && IsShareCartProfileContainsStage(WorkflowStage.Acquisition))
                    {
                        SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage
                                                               {
                                                                   SharedCartMemberId = SharedCartMemberId,
                                                                   Stage = WorkflowStage.Acquisition,
                                                               });
                    }
                    _hasAcquisition = true;
                }
                else
                {
                    SharedCartMemberWorkflowStages.Remove(WorkflowStage.Acquisition);
                    _hasAcquisition = false;
                }
            }
        }

        private bool _hasOwner;
        public bool HasOwner
        {
            get { return _hasOwner; }
            set
            {
                _hasOwner = value;
                if (value)
                {
                    HasContribution = true;
                    HasRequisition = true;
                    HasAcquisition = true;
                    HasReview = true;
                }
                SetChanged();
            }
        }

        /// <summary>
        /// Reference back to SharedCartProfile
        /// </summary>
        public SharedCartProfile SharedCartProfile { get; set; }

        /// <summary>
        /// List of Workflow Stages that the users have to completed.
        /// </summary>
        private SharedCartMemberWorkflowStageList _sharedCartMemberWorkflowStageList;
        public SharedCartMemberWorkflowStageList SharedCartMemberWorkflowStages
        {
            get
            {
                if (_sharedCartMemberWorkflowStageList == null)
                {
                    _sharedCartMemberWorkflowStageList = new SharedCartMemberWorkflowStageList();
                }
                if (_sharedCartMemberWorkflowStageList.Count > 0)
                {
                    _sharedCartMemberWorkflowStageList.Sort();
                }
                return _sharedCartMemberWorkflowStageList;
            }
            internal set
            {
                _sharedCartMemberWorkflowStageList = value;
            }
        }

        public bool IsCartOwner { get; set; }

        protected override void SaveSubObjects()
        {
            base.SaveSubObjects();
            //
        }

        protected override void PersistAsNew()
        {
            UpdateShareCartMemberIdToStages();
            CurrentDataAccessManager.CreateSharedCartMember(this);
        }

        protected override void PersistAsUpdate()
        {
            UpdateShareCartMemberIdToStages();
            CurrentDataAccessManager.UpdateSharedCartMember(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteSharedCartMember(Id);
        }

        /// <summary>
        /// Used check if the current member has right to update the shared cart.
        /// </summary>
        /// <returns></returns>
        public bool IsValidTimeToUpdate()
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Item Action/Apply Default
            bool result;
            if (HasOwner || !CurrentDataAccessManager.IsPremiumSharedCart(CartId))
                return true;
            //
            if (HasContribution)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Contribution);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasAcquisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasReview)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasRequisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Requisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            return false;
        }

        public bool IsValidTimeToAddProductToCart()
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Item Action/Apply Default
            bool result;
            if (HasOwner || !CurrentDataAccessManager.IsPremiumSharedCart(CartId))
                return true;
            //
            if (HasContribution)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Contribution);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasAcquisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasReview)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            return false;
        }

        public bool IsValidTimeToUpdateGroup()
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Item Action/Apply Default
            bool result;
            if (HasOwner || !CurrentDataAccessManager.IsPremiumSharedCart(CartId))
                return true;

            if (HasReview)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasAcquisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Used check if the current member has right to delete/move/restore the shared cart.
        /// </summary>
        /// <returns></returns>
        public bool IsValidTimeToDeleteMoveOrRestore()
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Remove Grid
            bool result;
            if (HasOwner || !CurrentDataAccessManager.IsPremiumSharedCart(CartId))
                return true;
            //            
            if (HasAcquisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasReview)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            return false;
        }

        public bool IsValidTimeToDesignateAsPrimaryCart()
        {
            bool result;
            if (HasOwner || !CurrentDataAccessManager.IsPremiumSharedCart(CartId))
                return true;

            if (HasContribution)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Contribution);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }

            if (HasReview)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }

            //            
            if (HasAcquisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }

            return false;
        }

        public void UpdateShareCartMemberIdToStages()
        {
            foreach (SharedCartMemberWorkflowStage sharedCartMemberWorkflowStage in SharedCartMemberWorkflowStages)
            {
                BeginDataLoading();
                sharedCartMemberWorkflowStage.SharedCartMemberId = SharedCartMemberId;
                EndDataLoading();
            }
        }

        public bool IsCompleteWorkflowStage(WorkflowStage checkedStage)
        {
            bool result;

            if (SharedCartProfile == null) return false;

            SharedCartWorkflowStage stage;

            switch (checkedStage)
            {
                case WorkflowStage.Contribution:
                    stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Contribution);
                    if (stage != null)
                    {
                        result = stage.IsCompleted();
                        if (result)
                            return true;
                    }
                    break;
                case WorkflowStage.Requisition:
                    stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Requisition);
                    if (stage != null)
                    {
                        result = stage.IsCompleted();
                        if (result)
                            return true;
                    }
                    break;
                case WorkflowStage.Review:
                    stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                    if (stage != null)
                    {
                        result = stage.IsCompleted();
                        if (result)
                            return true;
                    }
                    break;
                case WorkflowStage.Acquisition:
                    stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                    if (stage != null)
                    {
                        result = stage.IsCompleted();
                        if (result)
                            return true;
                    }
                    break;

            }

            return false;
        }

        public bool IsValidTimeForBatchEntry()
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Item Action/Apply Default
            bool result;
            if (HasOwner || !CurrentDataAccessManager.IsPremiumSharedCart(CartId))
                return true;
            //
            if (HasContribution)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Contribution);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasAcquisition)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            if (HasReview)
            {
                var stage = SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                result = stage.IsValidTimeToUpdate();
                if (result)
                    return true;
            }
            return false;
        }
    }
}
