﻿using System.Collections.Generic;

namespace BTNextgen.Grid.Cart
{
    public class CartLineItemNoteQuantityInListItems
    {
        protected CartGridDataAccessManager CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<CartGridDataAccessManager>(); }
        }


        public Dictionary<string, List<CartLineItemNoteQuantity>> LoadItems(List<string> lineItemIds)
        {
            var items = CurrentDataAccessManager.GetCartLineItemNoteQuantities(lineItemIds);
            return items;
        }

       
    }
}
