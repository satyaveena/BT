﻿namespace BTNextgen.Grid.Cart
{
    public class DefaultCartGridTemplate : EditableObject<CartGridDataAccessManager>
    {
        public string DefaultCartGridTemplateId { get { return Id; } }

        public string CartId { get; set; }

        public DefaultCartGridTemplateLineList DefaultCartGridTemplateLines { get; internal set; }

        public DefaultCartGridTemplate()
        {
            DefaultCartGridTemplateLines = new DefaultCartGridTemplateLineList();
        }        
    }
}
