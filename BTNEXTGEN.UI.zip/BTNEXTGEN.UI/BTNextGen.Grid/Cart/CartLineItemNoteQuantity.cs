﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class CartLineItemNoteQuantity : EditableObject<CartGridDataAccessManager>
    {
        public string CartLineItemNoteQuantityId { get { return Id; } }

        internal string CartLineItemQuantityId { get; set; }
        private string _lineItemId;
        public string LineItemId
        {
            get { return _lineItemId; }
            set
            {
                SetChanged();
                _lineItemId = value;
            }
        }

        public string UserId { get; set; }//User Id from User Profile.

        public string UserName { get; internal set; }

        private string _note;
        public string Note
        {
            get { return _note; }
            set
            {
                SetChanged();
                _note = value;
            }
        }

        private int? _quantity;
        public int? Quantity
        {
            get { return _quantity; }
            set
            {
                SetChanged();
                _quantity = value;
            }
        }

        public DateTime LastUpdated { get; set; }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateCartLineItemNoteQuantity(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateCartLineItemNoteQuantity(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteCartLineItemNoteQuantity(LineItemId);
        }
        public void Add()
        {
            CurrentDataAccessManager.CreateCartLineItemNoteQuantity(this);
        }

        public void Update()
        {
            CurrentDataAccessManager.UpdateCartLineItemNoteQuantity(this);
        }

        public void Delete()
        {
            CurrentDataAccessManager.DeleteCartLineItemNoteQuantity(LineItemId);
        }
    }
}
