﻿using System;
using System.Collections.Generic;

namespace BTNextgen.Grid.Cart
{
    public class GridSummaryItemDetailList : EditableObjectCollection<GridSummaryItemDetail, CartGridDataAccessManager>
    {
        public int TotalItemsCount { get; set; }
        protected override IEnumerable<GridSummaryItemDetail> InternalLoadItems(Dictionary<string, object> parameters)
        {
            var gridSummaryItem = parameters["GridSummaryItem"] as GridSummaryItem;
            var pageNum = Convert.ToInt32(parameters["PageNumber"]);
            var pageSize = Convert.ToInt32(parameters["PageSize"]);
            var orderBy = parameters["OrderBy"] as string;
            var direction = (bool)parameters["Direction"];
            var cartId = parameters["CartID"] as string;
            var viewMineOnly = (bool)parameters["ViewMineOnly"];
            int totals = 0;
            var items = CurrentDataAccessManager.GetGridSummaryItemDetail(cartId, gridSummaryItem, pageNum, pageSize, orderBy, direction, viewMineOnly, out totals);
            TotalItemsCount = totals;
            return items;
        }
    }
}
