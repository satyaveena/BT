﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class GridSummaryItemList : List<GridSummaryItem>
    {

    }
}
