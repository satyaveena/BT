﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public class DefaultCartGridFieldCode : EditableObject<CartGridDataAccessManager>
    {
        public string GridFieldId { get; set; }

        public string GridCodeId { get; set; }

        public string GridTextId { get; set; }

        public string DefaultCartGridTemplateLineId { get; set; }

        /// <summary>
        /// Position of the grid field in the de-normalized table.
        /// </summary>
        internal int GridFieldPosition { get; set; }
    }
}
