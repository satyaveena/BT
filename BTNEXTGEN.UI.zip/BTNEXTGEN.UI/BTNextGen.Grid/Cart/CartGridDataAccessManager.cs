﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.Cart;
using BTNextGen.Grid.Exception;
using BTNextGen.VelocityCaching;
using BTNextgen.Grid.Cart.Shared;
using BTNextGen.Grid.Helpers;
using BTNextGen.Grid.DataAccess;
using Microsoft.SqlServer.Server;
using BTNextGen.Commerce.Portal.Common.Search;
using CartMixMode = BT.TS360Constants.CartMixMode;

namespace BTNextgen.Grid.Cart
{
    public class CartGridDataAccessManager : DataAccessManager
    {
        private CartGridDAOManager _cartGridDaoManager;

        protected override DAOManager GetDAOManager()
        {
            _cartGridDaoManager = new CartGridDAOManager();
            return _cartGridDaoManager;
        }

        //public override void LoadById<T>(T editableObject)
        //{
        //    if (editableObject is CartLineExtension)
        //    {
        //        FillCartLineExtensionById(editableObject as CartLineExtension);
        //        return;
        //    }
        //}

        //public void FillCartLineExtensionById(CartLineExtension cartLineExtension)
        //{

        //}

        #region General

        public bool HasGrid(string cartId)
        {
            try
            {
                int nonRankedCount = 0;
                DataSet ds = _cartGridDaoManager.GetCartSummary(out nonRankedCount, cartId, this.UserId);
                return GetHasGridIndicatorFromDataSet(ds);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
        }        

        public List<GridNoteCount> GetCountForLineItemIds(string cartId, List<string> lineItemIds)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetCountForLineItems(cartId, lineItemIds);
                return GetGridNoteCountLineItemsFromDataSet(ds);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        #endregion

        #region LineItem Action

        public void RemoveGridFromLineItem(string lineItemId, bool keepQuantity)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Line Item Action/Remove Grid.
            List<string> lineItemIDs = new List<string>();
            lineItemIDs.Add(lineItemId);
            try
            {
                _cartGridDaoManager.RemoveGridFromLineItems(lineItemIDs, keepQuantity);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void RemoveGridFromLineItems(List<string> lineItemIdList, bool keepQuantity)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Line Item Action/Remove Grid.
            try
            {
                _cartGridDaoManager.RemoveGridFromLineItems(lineItemIdList, keepQuantity);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }


        #endregion

        #region Cart Action

        //public void SearchWithinCartByTitle(string cartId, string facetPath, string keywork, int pageNumber, int pageSize, string sortBy, out int totalLines)
        //{
        //    //Refer to the FS_Item_Details_w_processing_charges function specification at Search Within Cart.
        //    throw new NotImplementedException();
        //}

        public void SearchWithinCartByNote(string cartId, string facetPath, string keywork, int pageNumber, int pageSize, string sortBy, out int totalLines)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Search Within Cart.
            try
            {
                _cartGridDaoManager.SearchWithinCartByNote(cartId, facetPath, keywork, pageNumber, pageSize, sortBy,
                                                           out totalLines);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void RemoveGridFromCart(string cartId, bool keepQuantity)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Remove Grid.
            try
            {
                _cartGridDaoManager.RemoveGridFromCart(cartId, keepQuantity);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void DeleteZeroQuantityTitlesAndGridLines(string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Delete Zero Quantity Titles|Grid Lines
            try
            {
                _cartGridDaoManager.DeleteZeroQuantityTitlesAndGridLines(cartId);
            }
            catch (SqlException ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }

            //throw new NotImplementedException();
        }

        public void CreateACopyOfCart(string cartId, string newCartName, string destinationFolderId, string newFolderName, CartCopyType cartCopyType, bool copyESP)
        {
            //Update the R2.0 cart framework.
            //If destinationFolderId = null or empty, create a new folder with newFolderName.
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Create Copy of Cart.

            List<SqlDataRecord> cartList = DataConverter.ConverUserIDsToDataSet(new List<string> { cartId });
            _cartGridDaoManager.CreateCopyOfCart(cartList, newCartName, destinationFolderId, (int)cartCopyType, copyESP);
        }

        public void ReplaceAllGridFieldCodeInCart(string cartId, GridFieldType gridFieldType, string gridCodeId, string gridText, string newGridCodeId,
            string newFreeTextId, out int totalCount)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Find and Replace.
            try
            {
                _cartGridDaoManager.ReplaceAllGridFieldCodeInCart(cartId, gridFieldType, gridCodeId, gridText, newGridCodeId,
                                                                  newFreeTextId, out totalCount);

            }
            catch (SqlException ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void ReplaceAllGridLineQuantityInCart(string cartId, int currentQty, int newQty, out int totalCount)
        {
            _cartGridDaoManager.ReplaceAllGridLineQuantityInCart(cartId, currentQty, newQty, out totalCount);
        }

        public void TransferCartToUsers(string cartId, List<string> userIdList, bool keepACopy)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Transfer Cart.
            try
            {
                List<SqlDataRecord> userIds = DataConverter.ConverUserIDsToDataSet(userIdList);
                _cartGridDaoManager.TransferCartToUser(cartId, userIds, keepACopy);
            }
            catch (SqlException ex)
            {
                ex.Source = "procTS360TransferBasketToUsers:" + ex.Source;
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }

            //throw new NotImplementedException();
        }

        public string CheckEbookAccountInfoForOrg(string cartId, string orgIDs)
        {
            try
            {
                string errAccList = string.Empty;
                var orgArr = orgIDs.Split(';');
                foreach (var org in orgArr)
                {
                    if (!string.IsNullOrEmpty(org))
                    {
                        DataSet ds = _cartGridDaoManager.CheckEBookAccountForOrg(cartId, org);
                        foreach (DataRow row in ds.Tables[0].Rows)
                        {
                            if (!Parser.ToBool(row["Access"]) &&
                                !errAccList.Contains(DataAccessHelper.ConvertToString(row["Literal"])))
                                errAccList += DataAccessHelper.ConvertToString(row["Literal"]) + "; ";
                        }
                    }
                }

                return errAccList;
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        /// <summary>
        /// Append, Replace or Delete notes to all titles in a cart.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="note"></param>
        /// <param name="requestType">Append, Replace or Delete</param>
        public void ModifyNoteToAllTitles(string cartId, string note, string requestType)
        {
            try
            {
                _cartGridDaoManager.ModifyNoteToAllTitles(cartId, note, requestType);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public int GetLengthOfLongestNote(string cartId)
        {

            try
            {
                DataSet ds = _cartGridDaoManager.GetLengthOfLongestNote(cartId);
                return GetLengthOfLongestNoteDataSet(ds);

            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }

        }

        public GridSummary GetGridSummary(string cartId, string field1Type, string field2Type, string field3Type, bool viewMyGridLineOnly, string sortBy, bool? direction)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Summary/Grid Summary.
            try
            {
                field1Type = BuildValidGridFieldType(field1Type);
                field2Type = BuildValidGridFieldType(field2Type);
                field3Type = BuildValidGridFieldType(field3Type);

                DataSet ds = _cartGridDaoManager.GetGridSummary(cartId, field1Type, field2Type, field3Type, viewMyGridLineOnly, sortBy, direction);
                return GetGridSummaryFromDataSet(ds, field1Type, field2Type, field3Type);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }

            throw new NotImplementedException();
        }

        public IEnumerable<GridSummaryItemDetail> GetGridSummaryItemDetail(string cartId, GridSummaryItem gridSummaryItem, int pageNum, int pageSize, string orderBy, bool? direction, bool viewMineOnly, out int totalItems)
        {
            try
            {
                var field1Type = BuildValidGridFieldType(gridSummaryItem.GridField1Type);
                var field2Type = BuildValidGridFieldType(gridSummaryItem.GridField2Type);
                var field3Type = BuildValidGridFieldType(gridSummaryItem.GridField3Type);

                DataSet ds = _cartGridDaoManager.GetGridSummaryDetails(cartId, field1Type,
                                                                       field2Type,
                                                                       field3Type,
                                                                       gridSummaryItem.GridField1Value,
                                                                       gridSummaryItem.GridField2Value,
                                                                       gridSummaryItem.GridField3Value, pageNum,
                                                                       pageSize, orderBy, direction, viewMineOnly, out totalItems);
                return GetGridSummaryItemDetailFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }

        }

        private string BuildValidGridFieldType(string fieldType)
        {            
            if (!string.IsNullOrEmpty(fieldType))
            {
                if (fieldType.ToLower().Equals("null")) return string.Empty;

                if (!fieldType.Equals("CallNumberText", StringComparison.OrdinalIgnoreCase) &&
                    !fieldType.EndsWith("ID", StringComparison.OrdinalIgnoreCase))
                {
                    if (fieldType.Equals("CallNumber", StringComparison.OrdinalIgnoreCase))
                        fieldType += "Text";
                    else
                        fieldType += "ID";
                }
            }

            return fieldType;
        }

        public GridTemplate GetDefaultCartGridTemplate(string cartId)
        {
            GridTemplate template = null;
            try
            {
                var commonGridTmpl = DistributedCacheHelper.GetDefaultGridTemplate(UserId, OrganizationId, cartId);
                if (commonGridTmpl != null) 
                    template = new GridTemplate(){Id = commonGridTmpl.GridTemplateId};
                
            }
            catch (CartGridDatabaseException cartGridDatabaseException)
            {
                Logger.LogException(cartGridDatabaseException);
                throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
            }
            return template;
            //throw new NotImplementedException();
        }

        //public void SaveGridLinesAsDefaultGridTemplate(string cartId, List<CommonCartGridLine> cartGridLines)
        //{
        //    try
        //    {
        //        Dictionary<string, object> fieldList = null;
        //        List<SqlDataRecord> gridLines = DataConverter.ConvertGridTemplateLinesToDataSetNew(cartGridLines);
        //        //List<SqlDataRecord> gridLines = DataConverter.ConvertCartGridLinesToDataSet(cartGridLines, out fieldList);
        //        _cartGridDaoManager.SaveGridLinesAsDefaultGridTemplate(gridLines, fieldList, cartId);

        //        var cacheKey = string.Format("CartGridDataAccessManager.GetDefaultCartGridTemplate_{0}", cartId);
        //        VelocityCacheManager.SetExpired(cacheKey);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogException(ex);
        //        throw new CartGridSaveFailedException(ex.Message);
        //    }

        //    //throw new NotImplementedException();
        //}

        public bool HasDefaultCartGridTemplate(string cartId)
        {
            try
            {
                return _cartGridDaoManager.HasDefaultCartGridTemplate(cartId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }

            //throw new NotImplementedException();
        }

        public bool CheckDuplicateDefaultTemplateForCart(string cartId)
        {
            try
            {
                return _cartGridDaoManager.CheckDuplicateDefaultTemplateForCart(cartId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }

            //throw new NotImplementedException();
        }

        public bool CheckDuplicatedCartGridLineTemplate(string gridTemplateId, string cartId)
        {
            try
            {
                return _cartGridDaoManager.CheckDuplicatedCartGridLineTemplate(gridTemplateId, cartId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        public void ApplyDefaultGridTemplateToCartAllTitle(string cartId, bool duplicatedAllow, bool mergeQuantityBySum)
        {
            _cartGridDaoManager.ApplyTemplateToCartTitles("", cartId, false, false, duplicatedAllow);
        }

        public void ApplyDefaultGridTemplateToCartNonGridTitles(string cartId)
        {
            _cartGridDaoManager.ApplyTemplateToCartTitles("", cartId, true, false, false);
        }

        public void ApplyDefaultGridTemplateToCartAsAReplace(string cartId)
        {
            _cartGridDaoManager.ApplyTemplateToCartTitles("", cartId, false, true, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="isDeleteGridTemplate"></param>
        /// <returns></returns>
        public bool DeleteDefaultGridTemplate(string cartId, bool isDeleteGridTemplate)
        {
            try
            {
                return _cartGridDaoManager.DeleteDefaultGridTemplate(cartId, isDeleteGridTemplate);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);

                return false;
            }

        }

        public void ApplyTemplateToCartAllTitles(string gridTemplateId, string cartId, bool duplicatedAllow)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply template.
            //Will apply all template items to lineItem of the flag Authorize to All user  = true in the grid template. Otherwise, just apply authorized template lines
            //Do not apply disable, or expired template line, or furure date.  
            var manager = new GridTemplateManager(UserId, OrganizationId);
            var isAuthorizedToUseAll = manager.CheckUserRightOnGridTemplateLine(gridTemplateId);
            _cartGridDaoManager.ApplyTemplateToCartTitles(gridTemplateId, cartId, false, false, duplicatedAllow, isAuthorizedToUseAll);
        }

        public void ApplyTemplateToNonGridTitles(string gridTemplateId, string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply template.
            //Will apply all template items to lineItem of the flag Authorize to All user  = true in the grid template. Otherwise, just apply authorized template lines
            //Do not apply disable, or expired template line, or furure date.
            //Only apply to title has not been applied a grid.
            
            var manager = new GridTemplateManager(UserId, OrganizationId);
            var isAuthorizedToUseAll = manager.CheckUserRightOnGridTemplateLine(gridTemplateId);
            _cartGridDaoManager.ApplyTemplateToCartTitles(gridTemplateId, cartId, true, false, false, isAuthorizedToUseAll);
        }

        public void ApplyTemplateToTitleAsReplace(string gridTemplateId, string cartId)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Apply template.
            //Remove all old Grid, then apply a new one.
            //Will apply all template items to lineItem of the flag Authorize to All user  = true in the grid template. Otherwise, just apply authorized template lines
            //Do not apply disable, or expired template line, or furure date.
            var manager = new GridTemplateManager(UserId, OrganizationId);
            var isAuthorizedToUseAll = manager.CheckUserRightOnGridTemplateLine(gridTemplateId);
            _cartGridDaoManager.ApplyTemplateToCartTitles(gridTemplateId, cartId, false, true, false, isAuthorizedToUseAll);
        }

        public void PasteGridLineFromClipboard360ToCart(List<CommonGridTemplateLine> cartGridLines, string toCartId, bool duplicatedAllow, bool mergeQuantityBySum)
        {
            //Refer to the FS_Item_Details_w_processing_charges function specification at Cart Action/Paste Grid Lines
            try
            {
                cartGridLines = cartGridLines.OrderBy(item => item.Sequence).ToList();
                List<SqlDataRecord> gridLines = DataConverter.ConvertGridLinesToDataSetNew(cartGridLines);
                _cartGridDaoManager.PasteGridLineFromClipboard360ToCart(gridLines, toCartId, duplicatedAllow, mergeQuantityBySum);

            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void AddProductsToCart(List<ProductLineItem> products, Dictionary<string, List<CommonCartGridLine>> cartGridLines, string toCartId,
            out string PermissionViolationMessage, out int totalAddingQuantity)
        {
            //Refer to FS_Master_Add_NG32_Original_Entry
            try
            {
                List<SqlDataRecord> productsDS = DataConverter.ConvertProductsToMergeCartLineItem(products);
                List<SqlDataRecord> gridLines = DataConverter.ConvertCartGridLinesToDataSet(cartGridLines);
                _cartGridDaoManager.AddProductTocart(productsDS, toCartId, gridLines, out PermissionViolationMessage, out totalAddingQuantity);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void AddProductToCartBatchEntry(List<ProductLineItem> products, Dictionary<string, List<CommonCartGridLine>> cartGridLines, string toCartId,
            out string PermissionViolationMessage, out int totalAddingQuantity)
        {
            try
            {
                List<SqlDataRecord> productDs = DataConverter.ConvertProductsToMergeCartLineItem(products);
                List<SqlDataRecord> gridLines = DataConverter.ConvertCartGridLinesToDataSet(cartGridLines);
                _cartGridDaoManager.AddProductTocart(productDs, toCartId, gridLines, out PermissionViolationMessage, out totalAddingQuantity);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void AddBatchToBackgroundProcessing(string fileName, Dictionary<string, List<CommonCartGridLine>> cartGridLines, string toCartId, string userID,
            string eSuppliers, Boolean IsValidateBTKey, string organizationID)
        {
            try
            {
                if (cartGridLines == null || cartGridLines.Count == 0)
                    _cartGridDaoManager.AddBatchEntryToBackground(fileName, toCartId, userID, null, eSuppliers, IsValidateBTKey, organizationID);
                else
                {
                    List<SqlDataRecord> gridLines = DataConverter.ConvertCartGridLinesToDataSet(cartGridLines);
                    _cartGridDaoManager.AddBatchEntryToBackground(fileName, toCartId, userID, gridLines, eSuppliers, IsValidateBTKey, organizationID);
                }
                
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
            //throw new NotImplementedException();
        }

        public void SetBlankGridLineToCart(string cartId)
        {
            //TFS #5605 - Apply a blank grid line to all non-grid titles to a Grid Cart.
            try
            {
                _cartGridDaoManager.SetBlankGridLineToCart(cartId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public List<string> SplitCartToGridAndNonGrid(string cartId)
        {
            //TFS #5605 - Split a cart to grid cart and nongrid cart
            try
            {
                var ds = _cartGridDaoManager.SplitCartToGridAndNonGrid(cartId);
                return GetCartNamesFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        //public CartSplitResult SplitCart(string cartId, SplitCartMode splitCartOption, string userId, out Dictionary<string, string> separatedCarts)
        //{
        //    //TFS #5605 - Split a cart to grid cart and nongrid cart
        //    try
        //    {
        //        var ds = _cartGridDaoManager.SplitCartToGridAndNonGrid(cartId);
        //        separatedCarts = GetCartNamesFromDataSet(ds);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogException(ex);
        //        throw new CartGridSaveFailedException(ex.Message);
        //    }
        //}

        public CartMixMode CheckCartContainsBothGridAndNonGridTitles(string cartId)
        {
            //TFS #5605 - Check if a cart has a mix of grid and non-grid titles
            try
            {
                return _cartGridDaoManager.CheckCartContainsBothGridAndNonGridTitles(cartId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        #endregion

        //public CartLineExtension GetCartGridExtension(string lineItemId)
        //{
        //    //If CartLineExtension does not exist, create a new one.
        //    CartLineExtension cartLineExtension = null;
        //    try
        //    {
        //        DataSet ds = _cartGridDaoManager.GetCartGridExtension(lineItemId, false, String.Empty);
        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //            cartLineExtension = GetCartLineExtensionFromDataRow(ds.Tables[0].Rows[0]);                
        //    }
        //    catch (Exception cartGridDatabaseException)
        //    {
        //        Logger.LogException(cartGridDatabaseException);
        //        throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
        //    }

        //    return cartLineExtension;            
        //}

        //public List<CartLineExtension> GetCartGridExtention(List<string> lineItemIdList)
        //{
        //    if (lineItemIdList == null || lineItemIdList.Count == 0) return null;
        //    List<CartLineExtension> cartLineExtList = null;
        //    try
        //    {
        //        DataSet ds = _cartGridDaoManager.GetCartGridExtension(lineItemIdList, false, String.Empty);
        //        cartLineExtList = GetCartLineExtensionFromDataSet(ds);

        //    }
        //    catch (Exception cartGridDatabaseException)
        //    {
        //        Logger.LogException(cartGridDatabaseException);
        //        throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
        //    }

        //    return cartLineExtList;
        //}

        /// <summary>
        /// Get GetCartGridExtension list with validation and error code filter.
        /// </summary>
        /// <param name="lineItemIdList"></param>
        /// <param name="shouldValidate"></param>
        /// <param name="errorCodeFilter">
        /// if errorCodeFilter = null/empty---> no filter.
        /// errorCodeFilter value are a list of errorCodes separated by a comma.
        /// </param>
        /// <returns></returns>
        public List<string> GetCartGridExtention(List<string> lineItemIdList, bool shouldValidate, string errorCodeFilter)
        {
            List<string> list = null;
            try
            {
                DataSet ds = _cartGridDaoManager.GetCartGridExtension(lineItemIdList, shouldValidate, errorCodeFilter);
                list = GetCartLineExtensionFromDataSet(ds);
            }
            catch (Exception cartGridDatabaseException)
            {
                Logger.LogException(cartGridDatabaseException);
                throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
            }
            return list;
        }

        /// <summary>
        /// Get GetCartGridExtension with validation and error code filter.
        /// </summary>
        /// <param name="lineItemId"></param>
        /// <param name="shouldValidate"></param>
        /// <param name="errorCodeFilter">
        /// if errorCodeFilter = null/empty---> no filter.
        /// errorCodeFilter value are a list of errorCodes separated by a comma.
        /// </param>
        /// <returns></returns>
        //public CartLineExtension GetCartGridExtension(string lineItemId, bool shouldValidate, string errorCodeFilter)
        //{
        //    CartLineExtension cartLineExtension = null;
        //    try
        //    {
        //        DataSet ds = _cartGridDaoManager.GetCartGridExtension(new List<string>() { lineItemId }, shouldValidate, errorCodeFilter);
        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //            cartLineExtension = GetCartLineExtensionFromDataRow(ds.Tables[0].Rows[0]);
        //    }
        //    catch (Exception cartGridDatabaseException)
        //    {
        //        Logger.LogException(cartGridDatabaseException);
        //        throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
        //    }
        //    return cartLineExtension;
        //}

        public List<KeyValuePair<string, string>> GetNotesByBTKeys(string cartId, List<string> btkeys)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetNotesByBTKeys(cartId, btkeys);
                return GetBTKeysFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }
        public List<NoteClientObject> GetNotesByBTKeys(string cartId, string userId, List<string> btkeys, List<string> lineItemIds = null)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetNotesByBTKeys(cartId, userId, btkeys, lineItemIds);
                return GetNotesByBTKeysFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }
        /// <summary>
        /// Get all line item id that have errors in its grid.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="errorCodeFilter">
        /// if errorCodeFilter = null/empty---> no filter.
        /// errorCodeFilter value are a list of errorCodes separated by a comma.
        /// </param>
        /// <param name="pageSize"></param>
        /// <param name="pageNumber"></param>
        /// <param name="orderBy"></param>
        /// <param name="direction"></param>
        /// <param name="totalPage"></param>
        /// <returns>List of line item id</returns>
        public List<string> GetErrorLineItems(string cartId, string errorCodeFilter, int pageSize, int pageNumber, string orderBy,
            string direction, out int totalPage)
        {
            Dictionary<string, bool> lineHasGrid;
            return GetErrorLineItems(cartId, errorCodeFilter, pageSize, pageNumber,
                                                                   orderBy, direction, out totalPage, out lineHasGrid);
        }

        public List<string> GetErrorLineItems(string cartId, string errorCodeFilter, int pageSize, int pageNumber, string orderBy,
            string direction, out int totalPage, out Dictionary<string, bool> lineHasGrid)
        {
            List<string> list = null;
            try
            {
                DataSet ds = _cartGridDaoManager.GetErrorLineItems(cartId, errorCodeFilter, pageSize, pageNumber,
                                                                   orderBy, out totalPage, direction);
                list = GetErrorLineItemFromDataSet(ds, out lineHasGrid);
            }
            catch (Exception cartGridDatabaseException)
            {
                Logger.LogException(cartGridDatabaseException);
                throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
            }
            return list;
        }

        //public Dictionary<string, List<CartGridLine>> GetCartGridLines(List<string> lineItemIds, bool shouldValidate, string errorFilter)//int pageSize, int pageNumber, string orderBy, out int totalPage, out bool hasError, out string errorCode)
        //{
        //    Dictionary<string, List<CartGridLine>> lines = null;
        //    try
        //    {
        //        bool hasError = false;
        //        string errorCode = String.Empty;
        //        DataSet ds = _cartGridDaoManager.GetCartGridLines(lineItemIds, shouldValidate, errorFilter, out hasError, out errorCode);
        //        lines = GetCartGridLinesFromDataSet(ds);
        //    }
        //    catch (Exception cartGridDatabaseException)
        //    {
        //        throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
        //    }
        //    return lines;
        //}

        //public void CreateCartGridLine(CartGridLine cartGridLine)
        //{
        //    try
        //    {
        //        DataSet ds = _cartGridDaoManager.GetGridFieldCodePositionInBasket(cartGridLine.LineItemId);
        //        if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
        //        {
        //            throw new CartGridLoadFailedException("Can not get Field Code Position in Basket");
        //        }
        //        Dictionary<string, int> map = ds.Tables[0].AsEnumerable().ToDictionary(dr => DataAccessHelper.ConvertToString(dr["GridFieldID"]),
        //                                                  dr => DataAccessHelper.ConvertToInt(dr["Position"]));
        //        Dictionary<string, object> dict = DataConverter.ConvertCartGridLineToDictionary(cartGridLine, map);
        //        _cartGridDaoManager.UpdateCartGridLine(cartGridLine.CartGridLineId,
        //                                                                cartGridLine.LineItemId, cartGridLine.Quantity,
        //                                                                cartGridLine.Sequence, dict);
        //    }
        //    catch (Exception ex)
        //    {
        //        //Logger.LogException(ex);
        //        throw new CartGridSaveFailedException(ex.Message);
        //    }
        //}

        public void UpdateCartGridHeader(List<string> lineItemIDs)
        {
            // fix #11760
            if (lineItemIDs == null || lineItemIDs.Count == 0)
                return;

            try
            {
                _cartGridDaoManager.UpdateCartGridHeader(lineItemIDs);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
        }
        //public void UpdateCartGridLine(CartGridLine cartGridLine)
        //{
        //    try
        //    {
        //        DataSet ds = _cartGridDaoManager.GetGridFieldCodePositionInBasket(cartGridLine.LineItemId);
        //        if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
        //        {
        //            throw new CartGridLoadFailedException("Can not get Field Code Position in Basket");
        //        }
        //        Dictionary<string, int> map = ds.Tables[0].AsEnumerable().ToDictionary(dr => DataAccessHelper.ConvertToString(dr["GridFieldID"]),
        //                                                  dr => DataAccessHelper.ConvertToInt(dr["Position"]));

        //        Dictionary<string, object> dict = DataConverter.ConvertCartGridLineToDictionary(cartGridLine, map);
        //        _cartGridDaoManager.UpdateCartGridLine(cartGridLine.CartGridLineId,
        //                                                                cartGridLine.LineItemId, cartGridLine.Quantity,
        //                                                                cartGridLine.Sequence, dict);
        //    }
        //    catch (Exception ex)
        //    {
        //        //Logger.LogException(ex);
        //        throw new CartGridSaveFailedException(ex.Message); ;
        //    }
        //}

        //public void UpdateAllCartGridLines(string basketLineItemID, List<CartGridLine> cartGridLineList)
        //{
        //    //UserId;
        //    var dataRecords = new List<SqlDataRecord>();
        //    var sqlMetaDatas = new SqlMetaData[33];

        //    try
        //    {
        //        foreach (CartGridLine cartGridLine in cartGridLineList)
        //        {
        //            if (!cartGridLine.IsDataChanged())
        //                continue;

        //            DataSet ds = _cartGridDaoManager.GetGridFieldCodePositionInBasket(cartGridLine.LineItemId);
        //            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
        //            {
        //                throw new CartGridLoadFailedException("Can not get Field Code Position in Basket");
        //            }

        //            Dictionary<string, int> map = ds.Tables[0].AsEnumerable().ToDictionary(dr => DataAccessHelper.ConvertToString(dr["GridFieldID"]),
        //                                                      dr => DataAccessHelper.ConvertToInt(dr["Position"]));

        //            Dictionary<string, object> dict = DataConverter.ConvertCartGridLineToDictionary(cartGridLine, map);

        //            // initialize the sqlMetaDatas......
        //            sqlMetaDatas[0] = new SqlMetaData("BasketLineItemID", SqlDbType.VarChar, 50);
        //            sqlMetaDatas[1] = new SqlMetaData("BasketGridLineID", SqlDbType.VarChar, 50);
        //            sqlMetaDatas[2] = new SqlMetaData("Quantity", SqlDbType.Int);

        //            int k = 3;
        //            foreach (var item in dict)
        //            {
        //                sqlMetaDatas[k] = new SqlMetaData(item.Key, SqlDbType.VarChar, 50);
        //                k++;
        //            }

        //            var dataRecord = new SqlDataRecord(sqlMetaDatas);

        //            if (string.IsNullOrEmpty(cartGridLine.CartGridLineId))
        //                cartGridLine.CartGridLineId = Guid.NewGuid().ToString("B");//Create Primary Key

        //            dataRecord.SetString(0, basketLineItemID);
        //            dataRecord.SetString(1, cartGridLine.CartGridLineId);
        //            dataRecord.SetInt32(2, cartGridLine.Quantity);

        //            int v = 3;
        //            foreach (var item in dict)
        //            {
        //                if (string.IsNullOrEmpty(item.Value.ToString()))
        //                    dataRecord.SetDBNull(v);
        //                else
        //                    dataRecord.SetString(v, item.Value.ToString());

        //                v++;
        //            }

        //            dataRecords.Add(dataRecord);
        //        }

        //        if (dataRecords.Count > 0)
        //            _cartGridDaoManager.UpdateAllCartGridLines(UserId, dataRecords);

        //    }
        //    catch (Exception ex)
        //    {
        //        //Logger.LogException(ex);
        //        throw new CartGridSaveFailedException(ex.Message); ;
        //    }


        //}
        //public void UpdateAllCartGridLines(List<string> basketLineItemIDs, Dictionary<string, CartGridLineList> dicCartGridLineList)
        //{
        //    if (basketLineItemIDs == null || basketLineItemIDs.Count == 0
        //        || dicCartGridLineList == null || dicCartGridLineList.Count == 0)
        //        return;

        //    //UserId;
        //    var dataRecords = new List<SqlDataRecord>();
        //    var sqlMetaDatas = new SqlMetaData[33];

        //    try
        //    {
        //        DataSet ds = _cartGridDaoManager.GetGridFieldCodePositionInBasketForLineItems(basketLineItemIDs);
        //        if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
        //        {
        //            throw new CartGridLoadFailedException("Can not get Field Code Position in Basket");
        //        }
        //        Dictionary<string, Dictionary<string, int>> mapPosition = new Dictionary<string, Dictionary<string, int>>();
        //        foreach (DataRow row in ds.Tables[0].Rows)
        //        {
        //            var lineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemId"]);
        //            var fieldId = DataAccessHelper.ConvertToString(row["GridFieldID"]);
        //            var position = DataAccessHelper.ConvertToInt(row["Position"]);
        //            if (!mapPosition.ContainsKey(lineItemId))
        //                mapPosition.Add(lineItemId, new Dictionary<string, int>());
        //            if (!mapPosition[lineItemId].ContainsKey(fieldId))
        //                mapPosition[lineItemId].Add(fieldId, position);

        //        }
        //        foreach (var list in dicCartGridLineList)
        //        {
        //            var basketLineItemID = list.Key;
        //            var cartGridLineList = list.Value;
        //            foreach (CartGridLine cartGridLine in cartGridLineList)
        //            {
        //                if (!cartGridLine.IsDataChanged())
        //                    continue;

        //                Dictionary<string, int> map = mapPosition[basketLineItemID];
        //                Dictionary<string, object> dict = DataConverter.ConvertCartGridLineToDictionary(cartGridLine, map);

        //                // initialize the sqlMetaDatas......
        //                sqlMetaDatas[0] = new SqlMetaData("BasketLineItemID", SqlDbType.VarChar, 50);
        //                sqlMetaDatas[1] = new SqlMetaData("BasketGridLineID", SqlDbType.VarChar, 50);
        //                sqlMetaDatas[2] = new SqlMetaData("Quantity", SqlDbType.Int);

        //                int k = 3;
        //                foreach (var item in dict)
        //                {
        //                    sqlMetaDatas[k] = new SqlMetaData(item.Key, SqlDbType.VarChar, 50);
        //                    k++;
        //                }

        //                var dataRecord = new SqlDataRecord(sqlMetaDatas);

        //                if (string.IsNullOrEmpty(cartGridLine.CartGridLineId))
        //                    cartGridLine.CartGridLineId = Guid.NewGuid().ToString("B");//Create Primary Key

        //                dataRecord.SetString(0, basketLineItemID);
        //                dataRecord.SetString(1, cartGridLine.CartGridLineId);
        //                dataRecord.SetInt32(2, cartGridLine.Quantity);

        //                int v = 3;
        //                foreach (var item in dict)
        //                {
        //                    if (string.IsNullOrEmpty(item.Value.ToString()))
        //                        dataRecord.SetDBNull(v);
        //                    else
        //                        dataRecord.SetString(v, item.Value.ToString());

        //                    v++;
        //                }

        //                dataRecords.Add(dataRecord);
        //            }
        //        }

        //        if (dataRecords.Count > 0)
        //            _cartGridDaoManager.UpdateAllCartGridLines(UserId, dataRecords);

        //    }
        //    catch (Exception ex)
        //    {
        //        //Logger.LogException(ex);
        //        throw new CartGridSaveFailedException(ex.Message); ;
        //    }


        //}

        public void UpdateAllCartGridLines(List<string> basketLineItemIDs, 
            Dictionary<string, List<CommonCartGridLine>> dicCartGridLineList, 
            List<string> deletedGridLines)
        {
            if (basketLineItemIDs == null || basketLineItemIDs.Count == 0
                || dicCartGridLineList == null || dicCartGridLineList.Count == 0)
                return;

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[14];

            try
            {
                foreach (var list in dicCartGridLineList)
                {
                    var basketLineItemId = list.Key;
                    var cartGridLineList = list.Value;
                    foreach (var cartGridLine in cartGridLineList)
                    {
                        var gridCodeList = cartGridLine.GridFieldCodeList;
                        // initialize the sqlMetaDatas......
                        sqlMetaDatas[0] = new SqlMetaData("BasketLineItemGridID", SqlDbType.VarChar, 50);
                        sqlMetaDatas[1] = new SqlMetaData("BasketLineItemID", SqlDbType.VarChar, 50);
                        
                        sqlMetaDatas[2] = new SqlMetaData("AgencyCodeID", SqlDbType.VarChar, 50);
                        sqlMetaDatas[3] = new SqlMetaData("ItemTypeID", SqlDbType.VarChar, 50);
                        sqlMetaDatas[4] = new SqlMetaData("CollectionID", SqlDbType.VarChar, 50);

                        int k = 5;
                        for(var i = 1; i <= 6; i++)
                        {
                            //UserCode[i]ID
                            string codeIdParam = string.Format("UserCode{0}ID", i);

                            sqlMetaDatas[k] = new SqlMetaData(codeIdParam, SqlDbType.VarChar, 50);
                            k++;
                        }
                        sqlMetaDatas[k] = new SqlMetaData("CallNumberText", SqlDbType.VarChar, 26);
                        sqlMetaDatas[++k] = new SqlMetaData("Quantity", SqlDbType.Int);
                        sqlMetaDatas[++k] = new SqlMetaData("Sequence", SqlDbType.Int);
                        //Set up data records list......

                        var dataRecord = new SqlDataRecord(sqlMetaDatas);
                        //    cartGridLine.CartGridLineId = Guid.NewGuid().ToString("B");//Create Primary Key
                        if (string.IsNullOrEmpty(cartGridLine.CartGridLineId))
                            dataRecord.SetDBNull(0);
                        else
                            dataRecord.SetString(0, cartGridLine.CartGridLineId);

                        dataRecord.SetString(1, basketLineItemId);

                        
                        for (var i = 0; i < gridCodeList.Count; i++)
                        {
                            var position = 0;
                            var gridFc = gridCodeList[i];
                            switch (gridFc.GridFieldType)
                            {
                                case GridFieldType.AgencyCode:
                                    position = 2;
                                    break;
                                case GridFieldType.ItemType:
                                    position = 3;
                                    break;
                                case GridFieldType.Collection:
                                    position = 4;
                                    break;
                                case GridFieldType.UserCode1:
                                    position = 5;
                                    break;
                                case GridFieldType.UserCode2:
                                    position = 6;
                                    break;
                                case GridFieldType.UserCode3:
                                    position = 7;
                                    break;
                                case GridFieldType.UserCode4:
                                    position = 8;
                                    break;
                                case GridFieldType.UserCode5:
                                    position = 9;
                                    break;
                                case GridFieldType.UserCode6:
                                    position = 10;
                                    break;
                                case GridFieldType.CallNumber:
                                    position = 11;
                                    break;
                            }
                            if (gridFc.GridFieldType != GridFieldType.CallNumber)
                            {
                                if (!string.IsNullOrEmpty(gridFc.GridCodeId))
                                    dataRecord.SetString(position, gridFc.GridCodeId);
                                else
                                    dataRecord.SetDBNull(position);
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(gridFc.GridTextValue))
                                    dataRecord.SetString(position, gridFc.GridTextValue);
                                else
                                    dataRecord.SetDBNull(position);
                            }

                        }
                        
                        dataRecord.SetInt32(12, cartGridLine.Quantity);
                        dataRecord.SetInt32(13, cartGridLine.Sequence);

                        dataRecords.Add(dataRecord);
                    }
                }

                if (dataRecords.Count > 0 || (deletedGridLines != null && deletedGridLines.Any()))
                    _cartGridDaoManager.UpdateAllCartGridLines(UserId ?? SiteContext.Current.UserId, dataRecords, deletedGridLines);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message); ;
            }
        }

        public void DeleteCartGridLine(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteCartGridLine(id);
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public Dictionary<string, List<CartLineItemNoteQuantity>> GetCartLineItemNoteQuantities(List<string> lineItemIds)
        {
            Dictionary<string, List<CartLineItemNoteQuantity>> list = null;
            try
            {
                DataSet ds = _cartGridDaoManager.GetCartLineItemNoteQuantities(lineItemIds);
                list = GetCartLineItemNoteQuantitiesFromDataSet(ds);
            }
            catch (CartGridDatabaseException cartGridDatabaseException)
            {
                throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
            }
            return list;
        }


        public void CreateCartLineItemNoteQuantity(CartLineItemNoteQuantity cartLineItemNoteQuantity)
        {

            try
            {
                _cartGridDaoManager.UpdateCartLineItemNoteQuantity(cartLineItemNoteQuantity.LineItemId, cartLineItemNoteQuantity.CartLineItemNoteQuantityId, cartLineItemNoteQuantity.CartLineItemQuantityId ?? "0", cartLineItemNoteQuantity.Quantity, cartLineItemNoteQuantity.Note);
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void UpdateCartLineItemNoteQuantity(CartLineItemNoteQuantity cartLineItemNoteQuantity)
        {
            try
            {
                _cartGridDaoManager.UpdateCartLineItemNoteQuantity(cartLineItemNoteQuantity.LineItemId,
                    cartLineItemNoteQuantity.CartLineItemNoteQuantityId,
                    cartLineItemNoteQuantity.CartLineItemQuantityId ?? "0", cartLineItemNoteQuantity.Quantity,
                    cartLineItemNoteQuantity.Note);
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteCartLineItemNoteQuantity(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteCartLineItemNoteQuantity(id);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        //public IEnumerable<GridLineFieldCode> GetGridLineFieldCodes(string cartGridLineId, bool shouldValidate, string errorCodeFilter)
        //{
        //    throw new NotImplementedException();
        //}

        public bool ValidateGridInCartForLibrarySystemAccount(string cartId, string accountId)
        {
            try
            {
                return _cartGridDaoManager.ValidateGridInCartForLibrarySystemAccount(cartId, accountId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        public void ConvertPBookToEBook(string sourceBasketSummaryID, string newCartName, string folderId, string userID, string eSupplierPreference, string digitalFormatPerference)
        {
            try
            {
                _cartGridDaoManager.ConvertPBookToEBook(sourceBasketSummaryID, newCartName, folderId, userID, eSupplierPreference, digitalFormatPerference);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        #region Shared Cart

        /// <summary>
        /// Get Cart Summary by Id with cached per request
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        private DataSet GetCartSummary(string cartId)
        {
            var cacheKey = string.Format("CartGridDataAccessManager_{0}_{1}", cartId, this.UserId);
            var dsCache = VelocityCacheManager.Read(cacheKey);
            if (dsCache != null)
            {
                return dsCache as DataSet;
            }

            int nonRankedCount = 0;
            DataSet dsFromDatabase = _cartGridDaoManager.GetCartSummary(out nonRankedCount, cartId, this.UserId);
            VelocityCacheManager.Write(cacheKey, dsFromDatabase, GridCacheConstants.CommonGridCacheLevel);
            return dsFromDatabase;
        }

        public bool IsSharedCart(string cartId)
        {
            try
            {
                //DataSet ds = _cartGridDaoManager.GetCartSummary(cartId, this.UserId);
                var ds = this.GetCartSummary(cartId);
                return GetSharedCartIndicatorFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        public bool IsPremiumSharedCart(string cartId)
        {
            try
            {
                //DataSet ds = _cartGridDaoManager.GetCartSummary(cartId, this.UserId);
                var ds = this.GetCartSummary(cartId);
                return GetPremiumIndicatorFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        public void CreateCartUserGroup(CartUserGroup cartUserGroup)
        {
            List<SqlDataRecord> groupMembers = null;
            try
            {
                _cartGridDaoManager.UpdateCartUserGroup(groupMembers, cartUserGroup.CartUserGroupId, cartUserGroup.Name, SiteContext.Current.UserId, cartUserGroup.WorkflowEnabled);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void UpdateCartUserGroup(CartUserGroup cartUserGroup)
        {
            List<SqlDataRecord> groupMembers = null;
            try
            {
                _cartGridDaoManager.UpdateCartUserGroup(groupMembers, cartUserGroup.CartUserGroupId, cartUserGroup.Name, SiteContext.Current.UserId, cartUserGroup.WorkflowEnabled);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteCartUserGroup(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteCartUserGroup(id);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void CreateCartUserGroupMember(CartUserGroupMember cartUserGroupMember)
        {
            try
            {
                List<SqlDataRecord> stages = DataConverter.GetUtblSharedCartUserGroupWorkflowStage(cartUserGroupMember);
                _cartGridDaoManager.UpdateCartUserGroupMember(cartUserGroupMember.CartUserGroupMemberId,
                                                              cartUserGroupMember.CartUserGroupId,
                                                              cartUserGroupMember.UserId,
                                                              stages,
                                                              cartUserGroupMember.IsOwner);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }

        }

        public void UpdateCartUserGroupMember(CartUserGroupMember cartUserGroupMember)
        {
            try
            {
                List<SqlDataRecord> stages = DataConverter.GetUtblSharedCartUserGroupWorkflowStage(cartUserGroupMember);
                _cartGridDaoManager.UpdateCartUserGroupMember(cartUserGroupMember.CartUserGroupMemberId,
                                                              cartUserGroupMember.CartUserGroupId,
                                                              cartUserGroupMember.UserId,
                                                              stages,
                                                              cartUserGroupMember.IsOwner);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }

        }

        public void DeleteCartUserGroupMember(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteCartUserGroupMember(id);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }

        }

        public string CreateOrganizationWorkflowStage(OrganizationWorkflowStage organizationWorkflowStage)
        {
            try
            {
                return _cartGridDaoManager.CreateOrganizationWorkflowStage(organizationWorkflowStage);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void UpdateOrganizationWorkflowStage(OrganizationWorkflowStage organizationWorkflowStage)
        {
            try
            {
                _cartGridDaoManager.UpdateOrganizationWorkflowStage(organizationWorkflowStage);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void DeleteOrganizationWorkflowStage(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteOrganizationWorkflowStage(id);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void CreateSharedCartMember(SharedCartMember sharedCartMember)
        {
            try
            {
                List<SqlDataRecord> workflowStages =
                DataConverter.GetUtblSharedCartMemberWorkflowStage(sharedCartMember.SharedCartMemberWorkflowStages);
                _cartGridDaoManager.UpdateSharedCartMember(sharedCartMember.SharedCartMemberId, sharedCartMember.UserId,
                                                           sharedCartMember.CartId, sharedCartMember.HasOwner,
                                                           workflowStages);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }

        }

        public void UpdateSharedCartMember(SharedCartMember sharedCartMember)
        {
            try
            {
                List<SqlDataRecord> workflowStages =
                DataConverter.GetUtblSharedCartMemberWorkflowStage(sharedCartMember.SharedCartMemberWorkflowStages);
                _cartGridDaoManager.UpdateSharedCartMember(sharedCartMember.SharedCartMemberId, sharedCartMember.UserId,
                                                           sharedCartMember.CartId, sharedCartMember.HasOwner,
                                                           workflowStages);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }

        }

        public void DeleteSharedCartMember(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteSharedCartMember(id);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void CreateSharedCartMemberWorkflowStage(SharedCartMemberWorkflowStage sharedCartMemberWorkflowStage)
        {
            try
            {
                _cartGridDaoManager.UpdateSharedCartMemberWorkflowStage(sharedCartMemberWorkflowStage.Id, sharedCartMemberWorkflowStage.SharedCartMemberId, (int)sharedCartMemberWorkflowStage.Stage, sharedCartMemberWorkflowStage.CompletionDateTime);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void UpdateSharedCartMemberWorkflowStage(SharedCartMemberWorkflowStage sharedCartMemberWorkflowStage)
        {
            try
            {
                _cartGridDaoManager.UpdateSharedCartMemberWorkflowStage(sharedCartMemberWorkflowStage.Id, sharedCartMemberWorkflowStage.SharedCartMemberId, (int)sharedCartMemberWorkflowStage.Stage, sharedCartMemberWorkflowStage.CompletionDateTime);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void DeleteSharedCartMemberWorkflowStage(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteSharedCartMemberWorkflowStage(id);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void CreateSharedCartWorkflow(SharedCartWorkflow sharedCartWorkflow)
        {
            try
            {
                _cartGridDaoManager.UpdateSharedCartWorkflow(sharedCartWorkflow.SharedCartWorkflowId, sharedCartWorkflow.TimeZone);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void UpdateSharedCartWorkflow(SharedCartWorkflow sharedCartWorkflow)
        {
            try
            {
                _cartGridDaoManager.UpdateSharedCartWorkflow(sharedCartWorkflow.SharedCartWorkflowId, sharedCartWorkflow.TimeZone);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void DeleteSharedCartWorkflow(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteSharedCartWorkflow(id);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void CreateSharedCartWorkflowStage(SharedCartWorkflowStage sharedCartWorkflowStage)
        {
            try
            {
                _cartGridDaoManager.UpdateSharedCartWorkflowStage(sharedCartWorkflowStage.Id,
                                                                  sharedCartWorkflowStage.CartId,
                                                                  (int)sharedCartWorkflowStage.Stage,
                                                                  sharedCartWorkflowStage.CompletionDate,
                                                                  sharedCartWorkflowStage.EndDateTime,
                                                                  (int)sharedCartWorkflowStage.Status);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void UpdateSharedCartWorkflowStage(SharedCartWorkflowStage sharedCartWorkflowStage)
        {
            try
            {
                _cartGridDaoManager.UpdateSharedCartWorkflowStage(sharedCartWorkflowStage.Id,
                                                             sharedCartWorkflowStage.CartId,
                                                             (int)sharedCartWorkflowStage.Stage,
                                                             sharedCartWorkflowStage.CompletionDate,
                                                             sharedCartWorkflowStage.EndDateTime,
                                                             (int)sharedCartWorkflowStage.Status);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }

        }

        public void DeleteSharedCartWorkflowStage(string id)
        {
            try
            {
                _cartGridDaoManager.DeleteSharedCartWorkflowStage(id);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void ShareCart(string cartId, string requisitionType)
        {
            try
            {
                _cartGridDaoManager.ShareCart(cartId, requisitionType);

            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        /// <summary>
        /// Check if a cart has a Shared Cart Profile associated
        /// A cart may have shared cart profile, but it's not been shared.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        public bool HasSharedCartProfile(string cartId, out string ownerId)
        {
            try
            {
                var cacheKey = string.Format("CartGridDataAccessManager.HasSharedCartProfile_{0}", cartId);
                var cacheCacheKeyOwnerId = string.Format("CartGridDataAccessManager.HasSharedCartProfile_OwnerId_{0}", cartId);

                var hasSharedCartInCache = VelocityCacheManager.Read(cacheKey);
                if (hasSharedCartInCache != null)
                {
                    var ownerIdInCache = VelocityCacheManager.Read(cacheCacheKeyOwnerId);
                    if (ownerIdInCache != null)
                    {
                        ownerId = ownerIdInCache.ToString();
                        return (bool)hasSharedCartInCache;
                    }
                }

                var hasSharedCart = _cartGridDaoManager.HasSharedCartProfile(cartId, out ownerId);
                VelocityCacheManager.Write(cacheKey, hasSharedCart, GridCacheConstants.CommonGridCacheLevel);
                VelocityCacheManager.Write(cacheCacheKeyOwnerId, ownerId, GridCacheConstants.CommonGridCacheLevel);
                return hasSharedCart;
            }
            catch (SqlException sqlException)
            {
                Logger.LogException(sqlException);
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public SharedCartSummary GetSharedCartSummary(string cartId, bool viewMineOnly, string sortBy, bool? direction)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetSharedCartSummary(cartId, viewMineOnly, sortBy, direction);
                return Converter.ConvertToSharedCartSummary(ds);
            }
            catch (Exception sqlException)
            {
                Logger.LogException(sqlException);
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public SharedCartSummaryItemDetailList GetSharedCartSummaryDetail(string cartId, string userId, string sortBy, bool? direction)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetSharedCartSummaryDetail(cartId, userId, sortBy, direction);
                return Converter.ConvertToSharedCartSummaryDetail(ds);
            }
            catch (Exception sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public IEnumerable<CartUserGroup> GetCartUserGroups()
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetCartUserGroups();
                return Converter.ConvertToListCartUserGroup(ds);
            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public IEnumerable<CartUserGroupMember> GetCartUserGroupMembers(string cartUserGroupId)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetCartUserGroupMembers(cartUserGroupId);
                return Converter.ConvertToListCartUserGroupMember(ds);

            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public IEnumerable<OrganizationWorkflowStage> GetOrganizationWorkflowStages(string cartId)
        {
            return _cartGridDaoManager.GetOrganizationWorkflowStages(cartId, this.OrganizationId);
        }

        public IEnumerable<SharedCartMember> GetSharedCartMembers(string cartId)
        {
            try
            {
                var cacheKey = string.Format("CartGridDataAccessManager.GetSharedCartMembers_{0}", cartId);
                var membersInCache = VelocityCacheManager.Read(cacheKey);
                if (membersInCache != null)
                {
                    return membersInCache as IEnumerable<SharedCartMember>;
                }
                DataSet ds = _cartGridDaoManager.GetSharedCartMembers(cartId);
                var retMembers = ConvertToListSharedCartMember(ds, cartId);
                VelocityCacheManager.Write(cacheKey, retMembers, GridCacheConstants.CommonGridCacheLevel);
                return retMembers;
            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        /// <summary>
        /// Checks if user is cart member.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool IsSharedCartMember(string cartId, string userId)
        {
            DataSet ds = _cartGridDaoManager.GetSharedCartMembers(cartId);
            if (ds != null && ds.Tables.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    var memberId = DataAccessHelper.ConvertTo<string>(row, "u_user_id");

                    if (string.Equals(userId, memberId, StringComparison.InvariantCultureIgnoreCase))
                        return true;
                }
            }

            return false;
        }

        public IEnumerable<SharedCartMemberWorkflowStage> GetSharedCartMemberWorkflowStages(string cartId, string sharedCartMemberId)
        {
            try
            {
                var sharedCartMemberIds = new List<string> { sharedCartMemberId };
                DataSet ds = _cartGridDaoManager.GetSharedCartMemberWorkflowStages(cartId, sharedCartMemberIds);

                return Converter.ConvertToListSharedCartMemberWorkflowStage(ds, sharedCartMemberId);
            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public IEnumerable<SharedCartMemberWorkflowStage> GetSharedCartMemberWorkflowStages(string cartId, List<string> sharedCartMemberIds)
        {
            try
            {
                DataSet ds = _cartGridDaoManager.GetSharedCartMemberWorkflowStages(cartId, sharedCartMemberIds);
                return Converter.ConvertToListSharedCartMemberWorkflowStage(ds);
            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }


        public SharedCartWorkflow GetSharedCartWorkflow(string cartId)
        {
            try
            {
                var cacheKey = string.Format("__GetSharedCartWorkflow_{0}", cartId);
                var ds = VelocityCacheManager.Read(cacheKey) as DataSet;
                if (ds == null)
                {
                    ds = _cartGridDaoManager.GetSharedCartWorkflow(cartId);
                    VelocityCacheManager.Write(cacheKey, ds, GridCacheConstants.CommonGridCacheLevel);
                }
                return Converter.ConvertToSharedCartWorkflow(ds);
            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        public IEnumerable<SharedCartWorkflowStage> GetSharedCartWorkflowStages(string cartId)
        {
            try
            {
                var cacheKey = string.Format("__GetSharedCartWorkflowStages_{0}", cartId);
                var ds = VelocityCacheManager.Read(cacheKey) as DataSet;
                if (ds == null)
                {
                    ds = _cartGridDaoManager.GetSharedCartWorkflowStages(cartId);
                    VelocityCacheManager.Write(cacheKey, ds, GridCacheConstants.CommonGridCacheLevel);
                }

                return Converter.ConvertToListSharedCartWorkflowStage(ds);
            }
            catch (SqlException sqlException)
            {
                throw new CartGridLoadFailedException(sqlException.Message);
            }
        }

        #endregion

        //public int TitleWithoutGridCount(string cartId)
        //{
        //    throw new NotImplementedException();
        //}

        #region Local Utilities
        private List<string> GetCartLineExtensionFromDataSet(DataSet ds)
        {
            if (ds == null | ds.Tables.Count <= 0 || ds.Tables[0].Rows == null || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }

            var list = new List<string>();
            //var list = new List<CartLineExtension>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                list.Add(DataAccessHelper.ConvertToString(row["BasketLineItemID"])); 
                //CartLineExtension cartLineExtension = GetCartLineExtensionFromDataRow(row);
                //list.Add(cartLineExtension);
            }

            return list;
        }
        //private CartLineExtension GetCartLineExtensionFromDataRow(DataRow row)
        //{
        //    var cartLineExtension = new CartLineExtension();
        //    cartLineExtension.BeginDataLoading();
        //    cartLineExtension.LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
        //    cartLineExtension.HasError = DataAccessHelper.ConvertToBool(row["HasError"]);
        //    cartLineExtension.CartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
        //    cartLineExtension.ErrorCodeFilter = DataAccessHelper.ConvertToString(row["ErrorCodes"]);
        //    //cartLineExtension.GridLineCount = DataAccessHelper.ConvertToInt(row["CountGridLines"]);
        //    //cartLineExtension.NoteCount = DataAccessHelper.ConvertToInt(row["CountUserNotes"]);
        //    cartLineExtension.EndDataLoading();
        //    return cartLineExtension;
        //}
        //private List<CartLineExtension> GetBriefCartLineExtensionFromDataSet(DataSet ds)
        //{
        //    if (ds == null | ds.Tables.Count <= 0 || ds.Tables[0].Rows == null || ds.Tables[0].Rows.Count == 0)
        //    {
        //        return null;
        //    }

        //    var list = new List<CartLineExtension>();
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        CartLineExtension cartLineExtension = GetBriefCartLineExtensionFromDataRow(row);
        //        list.Add(cartLineExtension);
        //    }

        //    return list;
        //}
        //private CartLineExtension GetBriefCartLineExtensionFromDataRow(DataRow row)
        //{
        //    var cartLineExtension = new CartLineExtension();
        //    cartLineExtension.BeginDataLoading();
        //    cartLineExtension.LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
        //    //cartLineExtension.GridLineCount = DataAccessHelper.ConvertToInt(row["CountGridLines"]);
        //    //cartLineExtension.NoteCount = DataAccessHelper.ConvertToInt(row["CountUserNotes"]);
        //    cartLineExtension.EndDataLoading();
        //    return cartLineExtension;
        //}
        //private List<string> GetErrorLineItemFromDataSet(DataSet ds)
        //{
        //    Dictionary<string, bool> lineHasGrid;
        //    return GetErrorLineItemFromDataSet(ds, out lineHasGrid);
        //}
        private List<string> GetErrorLineItemFromDataSet(DataSet ds, out Dictionary<string, bool> lineHasGrid)
        {
            lineHasGrid = new Dictionary<string, bool>();
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            var list = new List<string>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var lineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                list.Add(lineItemId);
                var hasGridLines = DataAccessHelper.ConvertToInt(row["CountGridLines"]);
                lineHasGrid.Add(lineItemId, hasGridLines > 0);
            }
            return list;
        }

        private Dictionary<string, List<CartLineItemNoteQuantity>> GetCartLineItemNoteQuantitiesFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var dict = new Dictionary<string, List<CartLineItemNoteQuantity>>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var item = new CartLineItemNoteQuantity();
                item.BeginDataLoading();
                string lineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                item.LineItemId = lineItemId;
                item.Id = DataAccessHelper.ConvertToString(row["BasketUserLineItemNoteID"]);
                item.CartLineItemQuantityId = DataAccessHelper.ConvertToString(row["BasketUserLineItemID"]);
                item.UserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
                item.UserName = DataAccessHelper.ConvertToString(row["UserAlias"]);
                if (row["Quantity"] != DBNull.Value)
                    item.Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]);
                item.Note = DataAccessHelper.ConvertToString(row["Note"]);
                item.LastUpdated = DataAccessHelper.ConvertToDateTime(row["NoteUpdatedDateTime"]) ?? DateTime.Today;
                item.EndDataLoading();
                if (!dict.ContainsKey(lineItemId))
                    dict.Add(lineItemId, new List<CartLineItemNoteQuantity>());

                dict[lineItemId].Add(item);
            }
            return dict;
        }
        //private Dictionary<string, List<CartGridLine>> GetCartGridLinesFromDataSet(DataSet ds)
        //{
        //    if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
        //    {
        //        return null;
        //    }
        //    var dict = new Dictionary<string, List<CartGridLine>>();
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        var line = new CartGridLine();
        //        line.BeginDataLoading();
        //        string lineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
        //        line.LineItemId = lineItemId;
        //        line.Id = DataAccessHelper.ConvertToString(row["BasketGridLineID"]);
        //        line.HasError = DataAccessHelper.ConvertToBool(row["HasError"]);
        //        line.ErrorCode = DataAccessHelper.ConvertToString(row["ErrorCodes"]);
        //        line.Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]);
        //        line.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
        //        line.LastModifiedByUserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
        //        line.LastModifiedByUserName = DataAccessHelper.ConvertToString(row["display_name"]);
        //        line.FieldCodeList = new GridLineFieldCodeList();
        //        line.IsAuthorized = true;

        //        for (int i = 1; i <= 10; i++)
        //        {
        //            string gridField = "GridField" + i.ToString() + "ID";
        //            string gridCode = "GridCode" + i.ToString() + "ID";
        //            string gridText = "GridText" + i.ToString();
        //            string gridCodeValue = "GridCodeValue" + i.ToString();
        //            string gridCodeAuthorized = "IsAuthorized" + i.ToString();
        //            string gridFieldFreeText = "FreeTextIndicator" + i.ToString();
        //            if (!String.IsNullOrEmpty(DataAccessHelper.ConvertToString(row[gridField])))
        //            {
        //                bool hasError = false;
        //                string errorCode = string.Empty;

        //                var fieldCode = new GridLineFieldCode
        //                {
        //                    CartGridLineId = line.Id,
        //                    GridFieldId =
        //                        DataAccessHelper.ConvertToString(
        //                            row[gridField]),
        //                    GridCodeId =
        //                        DataAccessHelper.ConvertToString(
        //                            row[gridCode]),
        //                    GridTextId =
        //                        DataAccessHelper.ConvertToString(
        //                            row[gridText]),
        //                    GridCodeValue =
        //                        DataAccessHelper.ConvertToString(row[gridCodeValue]),
        //                    IsFreeText = Parser.ToBool(row[gridFieldFreeText]),
        //                    IsAuthorized = Parser.ToBool(row[gridCodeAuthorized])
        //                };

        //                if (line.HasError && line.ErrorCode.Contains(CartValidationErrorCodes.FreeTextFieldBlank)
        //                    && fieldCode.IsFreeText && string.IsNullOrEmpty(fieldCode.GridTextId))
        //                {
        //                    hasError = true;
        //                    errorCode = CartValidationErrorCodes.FreeTextFieldBlank;
        //                }
        //                else if (line.HasError && line.ErrorCode.Contains(CartValidationErrorCodes.GridCodeBlank)
        //                    && !fieldCode.IsFreeText && string.IsNullOrEmpty(fieldCode.GridCodeId))
        //                {
        //                    hasError = true;
        //                    errorCode = CartValidationErrorCodes.GridCodeBlank;
        //                }
        //                else if (line.HasError && line.ErrorCode.Contains(CartValidationErrorCodes.DuplicateLine))
        //                {
        //                    hasError = true;
        //                    errorCode = CartValidationErrorCodes.DuplicateLine;
        //                }

        //                fieldCode.HasError = hasError;
        //                fieldCode.ErrorCode = errorCode;
        //                line.FieldCodeList.Add(fieldCode);
        //                if (!Parser.ToBool(row[gridCodeAuthorized]))
        //                {
        //                    line.IsAuthorized = false;
        //                }
        //            }
        //        }
        //        line.EndDataLoading();
        //        if (!dict.ContainsKey(lineItemId))
        //            dict.Add(lineItemId, new List<CartGridLine>());

        //        dict[lineItemId].Add(line);
        //    }
        //    return dict;
        //}
        private bool GetHasGridIndicatorFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count <= 0)
            {
                return false;
            }
            return DataAccessHelper.ConvertToBool(ds.Tables[0].Rows[0]["HasGrids"]);
        }
        private bool GetSharedCartIndicatorFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count <= 0)
            {
                return false;
            }
            return DataAccessHelper.ConvertToBool(ds.Tables[0].Rows[0]["IsShared"]);
        }

        private bool GetPremiumIndicatorFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count <= 0)
            {
                return false;
            }
            return DataAccessHelper.ConvertToBool(ds.Tables[0].Rows[0]["IsPremiumBasket"]);
        }

        private GridSummary GetGridSummaryFromDataSet(DataSet ds, string field1, string field2, string field3)
        {
            if (ds == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count <= 0)
            {
                return null;
            }
            int totalTitles = 0;
            int totalQuantity = 0;
            decimal totalListPrice = 0;
            decimal totalEscDisc = 0;
            var gridSummary = new GridSummary();
            gridSummary.Items = new List<GridSummaryItem>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var item = new GridSummaryItem();
                item.GridField1Type = field1;
                item.GridField2Type = field2;
                item.GridField3Type = field3;
                item.GridField1Value = DataAccessHelper.ConvertToString(row["GridField1ID"]);
                item.GridField2Value = DataAccessHelper.ConvertToString(row["GridField2ID"]);
                item.GridField3Value = DataAccessHelper.ConvertToString(row["GridField3ID"]);
                item.DisplayValue1 = DataAccessHelper.ConvertToString(row["GridCodeValue1"]);
                item.DisplayValue2 = DataAccessHelper.ConvertToString(row["GridCodeValue2"]);
                item.DisplayValue3 = DataAccessHelper.ConvertToString(row["GridCodeValue3"]);
                item.TotalEstDiscPrice = DataAccessHelper.ConvertToGetDecimal(row["EstDisc"]);
                item.TotalListPrice = DataAccessHelper.ConvertToGetDecimal(row["ListPrice"]);
                item.TotalQuantity = DataAccessHelper.ConvertToInt(row["Quantity"]);
                item.TotalTitles = DataAccessHelper.ConvertToInt(row["Titles"]);
                item.HasZeroQuantity = DataAccessHelper.ConvertToBool(row["HasZeroQuantity"]);
                gridSummary.Items.Add(item);
                totalEscDisc += item.TotalEstDiscPrice;
                totalListPrice += item.TotalListPrice;
                totalQuantity += item.TotalQuantity;
                totalTitles += item.TotalTitles;
            }
            gridSummary.TotalEstDiscPrice = totalEscDisc;
            gridSummary.TotalListPrice = totalListPrice;
            gridSummary.TotalQuantity = totalQuantity;
            gridSummary.TotalTitles = totalTitles;
            return gridSummary;
        }
        private GridSummaryItemDetailList GetGridSummaryItemDetailFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
                return null;
            var list = new GridSummaryItemDetailList();
            var rowList = ds.Tables[0].Rows;
            foreach (DataRow row in rowList)
            {
                var itemDetail = new GridSummaryItemDetail
                {
                    LineItemID = DataAccessHelper.ConvertToString(row["BasketLineItemID"]),
                    Title = DataAccessHelper.ConvertToString(row["Title"]),
                    Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]),
                    ISBN_UPC = DataAccessHelper.ConvertToString(row["ISBNUPC"]),
                    UpdatedByName = DataAccessHelper.ConvertToString(row["UpdatedByName"]),
                    BTKey = DataAccessHelper.ConvertToString(row["BTKey"])
                };
                list.Add(itemDetail);
            }
            return list;
        }

        private IEnumerable<SharedCartMember> ConvertToListSharedCartMember(DataSet dsSharedCartMembers, string cartId)
        {
            if (dsSharedCartMembers == null || dsSharedCartMembers.Tables.Count == 0) return null;

            var sharedCartMembers = new List<SharedCartMember>();

            var basketUserIds = GetBasketUserIds(dsSharedCartMembers.Tables[0]);
            var sharedCartMembersWfStages = GetSharedCartMemberWorkflowStages(cartId, basketUserIds);

            var dictShareCartMemberWfStages = SetDictForShareCartMember(sharedCartMembersWfStages);

            foreach (DataRow row in dsSharedCartMembers.Tables[0].Rows)
            {
                var sharedCartMember = new SharedCartMember();
                sharedCartMember.BeginDataLoading();
                sharedCartMember.Id = DataAccessHelper.ConvertTo<string>(row, "BasketUserId");
                sharedCartMember.UserId = DataAccessHelper.ConvertTo<string>(row, "u_user_id");
                sharedCartMember.UserFullName = DataAccessHelper.ConvertTo<string>(row, "display_name");
                sharedCartMember.CartId = cartId;

                if (dictShareCartMemberWfStages != null && dictShareCartMemberWfStages.Count > 0)
                {
                    if (dictShareCartMemberWfStages.ContainsKey(sharedCartMember.Id))
                    {
                        sharedCartMember.SharedCartMemberWorkflowStages.AddRange(dictShareCartMemberWfStages[sharedCartMember.Id]);
                    }
                }
                //else
                //{
                //    sharedCartMember.SharedCartMemberWorkflowStages.AddRange(GetSharedCartMemberWorkflowStages(cartId,
                //                                                                                           sharedCartMember
                //                                                                                               .Id));
                //}

                sharedCartMember.HasContribution = Parser.ToBool(row["HasContribution"]);
                sharedCartMember.HasRequisition = Parser.ToBool(row["HasRequisition"]);
                sharedCartMember.HasReview = Parser.ToBool(row["HasReview"]);
                sharedCartMember.HasAcquisition = Parser.ToBool(row["HasAcquisition"]);
                sharedCartMember.HasOwner = Parser.ToBool(row["HasOwner"]);
                sharedCartMember.EndDataLoading();
                sharedCartMembers.Add(sharedCartMember);
            }
            return sharedCartMembers;
        }

        private Dictionary<string, List<SharedCartMemberWorkflowStage>> SetDictForShareCartMember(IEnumerable<SharedCartMemberWorkflowStage> sharedCartMembersWfStages)
        {
            var results = new Dictionary<string, List<SharedCartMemberWorkflowStage>>();
            if (sharedCartMembersWfStages != null)
            {
                foreach (var sharedCartMemberWorkflowStage in sharedCartMembersWfStages)
                {
                    if (results.ContainsKey(sharedCartMemberWorkflowStage.SharedCartMemberId))
                    {
                        results[sharedCartMemberWorkflowStage.SharedCartMemberId].Add(sharedCartMemberWorkflowStage);
                    }
                    else
                    {
                        results[sharedCartMemberWorkflowStage.SharedCartMemberId] =
                            new List<SharedCartMemberWorkflowStage> {sharedCartMemberWorkflowStage};
                    }
                }
            }
            return results;
        }

        private List<string> GetBasketUserIds(DataTable dataTable)
        {
            var results = new List<string>();

            if (dataTable == null || dataTable.Rows.Count == 0) return results;

            results.AddRange(from DataRow row in dataTable.Rows select DataAccessHelper.ConvertTo<string>(row, "BasketUserId"));
            return results;
        }

        private List<KeyValuePair<string, string>> GetBTKeysFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0) return null;
            var results = new List<KeyValuePair<string, string>>();
            //var cartLineExts = new List<CartLineExtension>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                results.Add(new KeyValuePair<string, string>(DataAccessHelper.ConvertToString(row["BasketLineItemID"]),
                                                            DataAccessHelper.ConvertToString(row["BTkey"])));
                //var cartLine = new CartLineExtension();
                //cartLine.BeginDataLoading();
                //cartLine.LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                //cartLine.BTKeys = DataAccessHelper.ConvertToString(row["BTkey"]);
                //cartLine.CartId = cartId;
                //cartLine.EndDataLoading();
                //cartLineExts.Add(cartLine);
            }
            //return cartLineExts;
            return results;
        }
        private List<NoteClientObject> GetNotesByBTKeysFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0) return null;
            var notes = new List<NoteClientObject>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var note = new NoteClientObject();
                var btkey = DataAccessHelper.ConvertToString(row["BTkey"]);
                if (string.IsNullOrEmpty(btkey))
                {
                    btkey = DataAccessHelper.ConvertToString(row["BasketOriginalEntryID"]);
                    //if (!string.IsNullOrEmpty(btkey))
                    //{
                    //    btkey = btkey.Replace("{", "").Replace("}", "");
                    //}
                }
                note.BTKey = btkey;
                note.LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                note.NotesCount = DataAccessHelper.ConvertToString(row["NotesCount"]);
                note.Note = DataAccessHelper.ConvertToString(row["Note"]);
                note.MyQty = DataAccessHelper.ConvertToString(row["Quantity"]);
                if(string.IsNullOrEmpty(note.MyQty))
                    note.MyQty = DataAccessHelper.ConvertToString(row["NoteQuantity"]);

                notes.Add(note);
            }
            return notes;
        }
        //private List<GridNoteCount> GetGridNoteCountBTKeysFromDataSet(DataSet ds)
        //{
        //    if (ds == null || ds.Tables.Count == 0) return null;
        //    var gridNoteCounts = new List<GridNoteCount>();
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        var gridNote = new GridNoteCount();
        //        gridNote.BTKey = DataAccessHelper.ConvertToString(row["BTKey"]);
        //        //gridNote.NoteCount = DataAccessHelper.ConvertToInt(row["CountUsersNotes"]);
        //        gridNote.QuantityCount = DataAccessHelper.ConvertToInt(row["CountUsersQuantity"]);
        //        gridNoteCounts.Add(gridNote);
        //    }
        //    return gridNoteCounts;
        //}

        private List<GridNoteCount> GetGridNoteCountLineItemsFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0) return null;
            var gridNoteCounts = new List<GridNoteCount>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var gridNote = new GridNoteCount();
                gridNote.LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemId"]);
                //gridNote.NoteCount = DataAccessHelper.ConvertToInt(row["CountUsersNotes"]);
                gridNote.QuantityCount = DataAccessHelper.ConvertToInt(row["CountUsersQuantity"]);
                gridNote.GridLineCount = DataAccessHelper.ConvertToInt(row["CountGridLines"]);
                gridNote.LineItemTotalQuantity = DataAccessHelper.ConvertToInt(row["LineItemTotalQuantity"]);
                gridNoteCounts.Add(gridNote);
            }
            return gridNoteCounts;
        }

        private List<string> GetCartNamesFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count != 2) return null;

            return new List<string>
                       {
                           string.Format("{0};{1}", ds.Tables[0].Rows[0][0], ds.Tables[0].Rows[0][1]),
                           string.Format("{0};{1}", ds.Tables[0].Rows[1][0], ds.Tables[0].Rows[1][1])
                       };
        }

        #endregion
        private int GetLengthOfLongestNoteDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count <= 0)
            {
                return 0;
            }
            return DataAccessHelper.ConvertToInt(ds.Tables[0].Rows[0]["LengthOfLongestNote"]);
        }

        #region NEW GRID
        public Dictionary<string, List<CommonCartGridLine>> GetCartGridLinesNewGrid(List<string> lineItemIds)
        {
            Dictionary<string, List<CommonCartGridLine>> lines = null;
            try
            {
                DataSet ds = _cartGridDaoManager.GetCartGridLines(lineItemIds);
                lines = GetCartGridLinesFromDataSetNewGrid(ds);
            }
            catch (Exception cartGridDatabaseException)
            {
                throw new CartGridLoadFailedException(cartGridDatabaseException.Message);
            }
            return lines;
        }
        private Dictionary<string, List<CommonCartGridLine>> GetCartGridLinesFromDataSetNewGrid(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }

            var dict = new Dictionary<string, List<CommonCartGridLine>>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var line = new CommonCartGridLine();
                string lineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                line.LineItemId = lineItemId;
                line.CartGridLineId = DataAccessHelper.ConvertToString(row["BasketLineItemGridID"]);
                line.Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]);
                line.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
                line.LastModifiedByUserName = DataAccessHelper.ConvertToString(row["UpdatedBy"]);
                line.GridFieldCodeList = new List<CartGridLineFieldCode>();
                line.IsAuthorized = true;

                line.GridFieldCodeList.Add(new CartGridLineFieldCode
                {
                    CartGridLineId = line.CartGridLineId,
                    GridCodeId = DataAccessHelper.ConvertToString(row["AgencyCodeID"]),
                    IsFreeText = false,
                    GridFieldType = GridFieldType.AgencyCode
                });

                line.GridFieldCodeList.Add(new CartGridLineFieldCode
                {
                    CartGridLineId = line.CartGridLineId,
                    GridCodeId = DataAccessHelper.ConvertToString(row["ItemTypeID"]),
                    IsFreeText = false,
                    GridFieldType = GridFieldType.ItemType
                });

                line.GridFieldCodeList.Add(new CartGridLineFieldCode
                {
                    CartGridLineId = line.CartGridLineId,
                    GridCodeId = DataAccessHelper.ConvertToString(row["CollectionID"]),
                    IsFreeText = false,
                    GridFieldType = GridFieldType.Collection
                }); 

                for (int i = 1; i <= 6; i++)
                {
                    string gridCode = "UserCode" + i;
                    
                    var fieldCode = new CartGridLineFieldCode
                    {
                        CartGridLineId = line.CartGridLineId,
                        GridCodeId = DataAccessHelper.ConvertToString(row[gridCode + "ID"]),
                        IsFreeText = false,
                        GridFieldType = CommonHelper.ConvertToGridFieldType(gridCode)
                    };

                    line.GridFieldCodeList.Add(fieldCode);                    
                }
                line.CallNumberText = DataAccessHelper.ConvertToString(row["CallNumberText"]);
                line.GridFieldCodeList.Add(new CartGridLineFieldCode
                {
                    CartGridLineId = line.CartGridLineId,
                    GridTextValue = line.CallNumberText,
                    IsFreeText = true,
                    GridFieldType = GridFieldType.CallNumber
                }); 

                if (!dict.ContainsKey(lineItemId))
                    dict.Add(lineItemId, new List<CommonCartGridLine>());

                dict[lineItemId].Add(line);
            }
            return dict;
        }
        #endregion

    }
}
