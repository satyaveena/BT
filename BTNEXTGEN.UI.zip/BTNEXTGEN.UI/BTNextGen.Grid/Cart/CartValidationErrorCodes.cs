﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid.Cart
{
    public static class CartValidationErrorCodes
    {
        public const string DuplicateLine = "1";
        public const string TitleNoGrid = "2";
        public const string TitleZeroQuantity = "3";
        public const string GridLineZeroQuantity = "4";        
        public const string GridCodeBlank = "5";
        public const string FreeTextFieldBlank = "6";
    }
}
