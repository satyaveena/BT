﻿namespace BTNextgen.Grid.Cart
{
    public enum CartCopyType
    {
        AllTitle = 1,
        MyTitle = 2,
        TitleOnly = 3,
        NoChoose = 4
    }
}
