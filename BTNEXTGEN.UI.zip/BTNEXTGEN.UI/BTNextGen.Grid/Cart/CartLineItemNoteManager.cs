﻿using System;
using System.Collections.Generic;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;

namespace BTNextgen.Grid.Cart
{
    public class CartLineItemNoteManager
    {
        private List<string> _lineItemIds = new List<string>();
        protected CartGridDataAccessManager CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<CartGridDataAccessManager>(); }
        }

        public void AddLineItemId(string id)
        {
            if (!_lineItemIds.Contains(id))
                _lineItemIds.Add(id);
        }

        public Dictionary<string, List<CartLineItemNoteQuantity>> LoadCartLineItemGridLines(List<string> lineItemIds)
        {

            try
            {
                return CurrentDataAccessManager.GetCartLineItemNoteQuantities(lineItemIds);
            }
            catch
            {
                throw;
            }
            finally
            {
            }
        }
        public List<CartLineItemNoteQuantity> LoadCartLineItemGridLines(string lineItemId)
        {
            try
            {
                var dict = CurrentDataAccessManager.GetCartLineItemNoteQuantities(new List<string> { lineItemId });
                if (dict != null && dict.ContainsKey(lineItemId))
                    return dict[lineItemId];
                return null;
            }
            catch
            {
                throw;
            }
            finally
            {
            }
        }

        public void UpdateNote(CartLineItemNoteQuantity note)
        {
            try
            {
                note.Update();
            }
            catch
            {
                throw;
            }
            finally
            {
            }
        }
        public void AddNote(CartLineItemNoteQuantity note)
        {
            try
            {
                note.Add();
            }
            catch
            {
                throw;
            }
            finally
            {
            }
        }
        public void DeleteNote(CartLineItemNoteQuantity note)
        {
            try
            {
                note.Delete();
            }
            catch
            {
                throw;
            }
            finally
            {
            }
        }
    }
}
