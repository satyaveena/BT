﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class GridField : EditableObject<GridDataAccessManager>
    {        
        public string GridFieldId
        {
            get { return Id; }            
        }

        private int _sopGridFieldId;
        public int SOPGridFieldId
        {
            get { return _sopGridFieldId; }
            set
            {
                SetChanged();
                _sopGridFieldId = value;
            }
        }

        private string _organizationId;
        public string OrganizationId
        {
            get { return _organizationId; }
            set
            {
                SetChanged();
                _organizationId = value;
            }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                SetChanged();
                _name = value;
            }
        }

        private bool _freeTextIndicator;
        public bool FreeTextIndicator
        {
            get { return _freeTextIndicator; }
            set
            {
                SetChanged();
                _freeTextIndicator = value;
            }
        }

        private int _freeTextCharacterLimit;
        public int FreeTextCharacterLimit
        {
            get { return _freeTextCharacterLimit; }
            set
            {
                SetChanged();
                _freeTextCharacterLimit = value;
            }
        }

        private int _sequence;
        public int Sequence
        {
            get { return _sequence; }
            set
            {
                SetChanged();
                _sequence = value;
            }
        }

        private bool _lockedIndicator;
        public bool LockedIndicator
        {
            get { return _lockedIndicator; }
            set
            {
                SetChanged();
                _lockedIndicator = value;
            }
        }

        private bool _activeIndicator;
        public bool ActiveIndicator
        {
            get { return _activeIndicator; }
            set
            {
                SetChanged();
                _activeIndicator = value;
            }
        }

        private bool _deleteIndicator;
        public bool DeleteIndicator
        {
            get { return _deleteIndicator; }
            set
            {
                SetChanged();
                _deleteIndicator = value;
            }
        }

        private bool _userViewAllGridCodesIndicator;
        public bool UserViewAllGridCodesIndicator
        {
            get { return _userViewAllGridCodesIndicator; }
            set
            {
                SetChanged();
                _userViewAllGridCodesIndicator = value;
            }
        }

        private bool _validateIndicator;
        public bool ValidateIndicator
        {
            get { return _validateIndicator; }
            set
            {
                SetChanged();
                _validateIndicator = value;
            }
        }

        private int _slipReportSequence;
        public int SlipReportSequence
        {
            get { return _slipReportSequence; }
            set
            {
                SetChanged();
                _slipReportSequence = value;
            }
        }

        public bool IsUsing { get; internal set; }

        private GridCodeList _gridCodes;

        public bool IsGetInUseInfo { get; set; }
        /// <summary>
        /// All Grid Codes for the GridField
        /// </summary>
        public GridCodeList GridCodes
        {
            get
            {
                if (_gridCodes == null)
                {
                    _gridCodes = new GridCodeList(IsGetInUseInfo);
                    //
                    if (!string.IsNullOrEmpty(GridFieldId))
                        _gridCodes.LoadItems((new Dictionary<string, object>
                                                     {
                                                         {"GridFieldId", GridFieldId},
                                                         {"GetAll", "false"},                                                         
                                                         {"IsNoCache", IsNoCache}
                                                     }));
                }
                return _gridCodes;
            }       
            internal set { _gridCodes = value; }
        }

        public bool IsNoCache { get; set; }

        private GridCodeList _allGridCode;
        public GridCodeList AllGridCodes
        {
            get
            {
                if (_allGridCode == null)
                {
                    _allGridCode = new GridCodeList(IsGetInUseInfo);
                    //
                    if (!string.IsNullOrEmpty(GridFieldId))
                        _allGridCode.LoadItems((new Dictionary<string, object>
                                                     {
                                                         {"GridFieldId", GridFieldId},
                                                         {"GetAll", "true"},
                                                         {"IsNoCache", IsNoCache}
                                                     }));
                }
                return _allGridCode;
            }
            internal set { _allGridCode = value; }
        }

        private UserGridFieldList _userGridFields;

        /// <summary>
        /// All users having authorized this grid field.
        /// </summary>
        public UserGridFieldList UserGridFields
        {
            get
            {
                if (_userGridFields == null)
                {
                    _userGridFields = new UserGridFieldList() { IsGetInUseInfo = IsGetInUseInfo };
                    if (!string.IsNullOrEmpty(GridFieldId))
                        _userGridFields.LoadItems((new Dictionary<string, object>
                                                 {
                                                     {"GridFieldId", GridFieldId}
                                                 }));
                }
                return _userGridFields;
            }
            internal set { _userGridFields = value; }
        }
        
        protected void SetGridFieldProperties(GridCodeList gridCodeList, UserGridField currentUserGridField)
        {
            _gridCodes = gridCodeList;
            _userGridFields = new UserGridFieldList {currentUserGridField};
        }

        public override void Save()
        {
            OrganizationId = CurrentDataAccessManager.OrganizationId;
            base.Save();
        }

        protected override void SaveSubObjects()
        {
            if (_gridCodes != null)
            {
                UpdateGridFieldIdToGridCode();
                _gridCodes.Save();
            }
            if (_allGridCode != null)
            {
                UpdateGridFieldIdToAllGridCode();
                _allGridCode.Save();
            }
            if (_userGridFields != null)
            {
                UpdateGridFieldIdToUserGridFields();
                UserGridFields.Save();
            }                            
        }

        private void UpdateGridFieldIdToUserGridFields()
        {            
            foreach (var userGridFields in _userGridFields)
            {
                if (userGridFields.IsDataChanged())
                    userGridFields.GridFieldId = GridFieldId;
            }
        }

        private void UpdateGridFieldIdToGridCode()
        {
            if (_gridCodes == null)
                return;
            //
            foreach (var gridCode in _gridCodes)
            {
                if (gridCode.IsDataChanged())
                    gridCode.GridFieldId = GridFieldId;
            }
        }

        private void UpdateGridFieldIdToAllGridCode()
        {
            if (_allGridCode == null)
                return;
            //
            foreach (var gridCode in _allGridCode)
            {
                if (gridCode.IsDataChanged())
                    gridCode.GridFieldId = GridFieldId;
            }
        }

        /// <summary>
        /// Get Authorized Grid Codes for current user context.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<GridCode> GetAuthorizedGridCodes()
        {
            var fullGridCodeList = this.GridCodes;
            return fullGridCodeList.Where(gridCode => gridCode.UserGridCodes.Any(uc => uc.UserId == CurrentDataAccessManager.UserId)).ToList();
        }

        //public IEnumerable<GridCode> GetAuthorizedGridCodesActive()
        //{
        //    var results = new List<GridCode>();
        //    var fullGridCodeList = this.GridCodes;
        //    var fullGridCodeListOrderBySequence = (  from gridcode in fullGridCodeList
        //                                             where gridcode.ActiveIndicator == true
        //                                             orderby gridcode.Sequence ascending
        //                                             select gridcode).ToList();

        //    if (this.UserViewAllGridCodesIndicator)
        //    {
        //        foreach (var gridCode in fullGridCodeListOrderBySequence)
        //        {
        //            if (((gridCode.EffectiveDate.HasValue && gridCode.EffectiveDate.Value <= DateTime.Now)
        //                    && (gridCode.ExpirationDate.HasValue && gridCode.ExpirationDate.Value > DateTime.Now)) ||
        //                ((gridCode.EffectiveDate.HasValue && gridCode.EffectiveDate.Value <= DateTime.Now) && !gridCode.ExpirationDate.HasValue))
        //            {
        //                results.Add(gridCode);
        //            }
        //        }
        //    }
        //    else
        //    {
        //        foreach (var gridCode in fullGridCodeListOrderBySequence)
        //        {
        //            foreach (var userGridCode in gridCode.UserGridCodes)
        //            {
        //                if (userGridCode.UserId == CurrentDataAccessManager.UserId
        //                    && ( ((gridCode.EffectiveDate.HasValue && gridCode.EffectiveDate.Value <= DateTime.Now)
        //                    && (gridCode.ExpirationDate.HasValue && gridCode.ExpirationDate.Value > DateTime.Now)) ||
        //                    ((gridCode.EffectiveDate.HasValue && gridCode.EffectiveDate.Value <= DateTime.Now) && !gridCode.ExpirationDate.HasValue)))
        //                {
        //                    results.Add(gridCode);
        //                }
        //            }
        //        }
        //    }

        //    return results;
        //    //return fullGridCodeList.Where(gridCode => gridCode.UserGridCodes.Any(uc => uc.UserId == CurrentDataAccessManager.UserId)
        //    //    && (gridCode.EffectiveDate.HasValue && gridCode.EffectiveDate <= DateTime.Now)).ToList();
        //}

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateGridField(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateGridField(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteGridField(Id);
        }
    }
}
