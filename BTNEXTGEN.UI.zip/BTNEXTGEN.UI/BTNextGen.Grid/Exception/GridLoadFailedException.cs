﻿namespace BTNextGen.Grid.Exception
{
    public class GridLoadFailedException : GridException
    {
        public GridLoadFailedException(string message) : base(message)
        {
        }

        public GridLoadFailedException(int exceptionCode, string message) : base(exceptionCode, message)
        {
        }
    }
}
