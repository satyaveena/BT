﻿namespace BTNextGen.Grid.Exception
{
    public class CartGridLoadFailedException : CartGridException
    {
        public CartGridLoadFailedException()
        {
            
        }

        public CartGridLoadFailedException(string message)
            : base(message)
        {
            
        }
    }
}
