﻿namespace BTNextGen.Grid.Exception
{
    public class CartGridException : System.Exception
    {
        public int ExceptionCode { get; private set; }

        public CartGridException()
        {
            
        }

        public CartGridException(string message):base(message)
        {
            
        }

        public CartGridException(int exceptionCode, string message)
            : base(message)
        {
            ExceptionCode = exceptionCode;
        }
    }
}
