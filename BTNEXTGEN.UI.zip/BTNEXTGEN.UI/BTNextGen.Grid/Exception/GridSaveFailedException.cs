﻿namespace BTNextGen.Grid.Exception
{
    public class GridSaveFailedException : GridException
    {
        public GridSaveFailedException(string message) : base(message)
        {
        }

        public GridSaveFailedException(int exceptionCode, string message) : base(exceptionCode, message)
        {
        }
    }
}
