﻿namespace BTNextGen.Grid.Exception
{
    public class CartGridSaveFailedException : CartGridException
    {
        public CartGridSaveFailedException()
        {
            
        }

        public CartGridSaveFailedException(string message)
            : base(message)
        {
            
        }
    }
}
