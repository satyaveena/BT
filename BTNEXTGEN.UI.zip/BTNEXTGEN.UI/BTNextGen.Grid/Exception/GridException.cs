﻿namespace BTNextGen.Grid.Exception
{
    public class GridException : System.Exception
    {
        public int ExceptionCode { get; private set; }

        public GridException(string message)
            : base(message)
        {
            
        }

        public GridException(int exceptionCode, string message) : base(message)
        {
            ExceptionCode = exceptionCode;
        }
    }
}
