﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserGridFieldList : EditableObjectCollection<UserGridField, GridDataAccessManager>
    {
        private bool _isGetInUseInfo = true;
        public bool IsGetInUseInfo
        {
            get { return _isGetInUseInfo; }
            set { _isGetInUseInfo = value; }
        }
        protected override IEnumerable<UserGridField> InternalLoadItems(Dictionary<string, object> parameters)
        {
            return CurrentDataAccessManager.GetAllUserGridFields(parameters["GridFieldId"].ToString(), _isGetInUseInfo /*8248*/);            
        }
    }
}
