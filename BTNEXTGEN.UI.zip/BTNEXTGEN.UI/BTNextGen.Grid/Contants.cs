﻿
namespace BTNextGen.Grid
{
    internal static class StoredProcedureName
    {
        #region Grid Related Stored Procedures

        internal static string PROC_GET_GRID_CODES = "procTS360GetGridCodes";
        internal static string PROC_SET_GRID_CODE = "procTS360SetGridCode";
        internal static string PROC_DELETE_GRID_CODE = "procTS360DeleteGridCode";

        internal static string PROC_GET_USER_GRID_CODES = "procTS360GetUserGridCodes";
        internal static string PROC_SET_USER_GRID_CODE = "procTS360SetUserGridCode";
        internal static string PROC_DELETE_USER_GRID_CODE = "procTS360DeleteUserGridCode";

        //internal static string PROC_GET_GRID_FIELDS = "procTS360GetGridFields";
        internal static string PROC_SET_GRID_FIELD = "procTS360SetGridField";
        internal static string PROC_DELETE_GRID_FIELD = "procTS360DeleteGridField";
        internal static string PROC_GET_ALL_GRID_FIELD_WITH_CODE = "procTS360GetGridFieldsWithAuthorizedGridCodeForUser";

        internal static string PROC_GET_USER_GRID_FIELDS = "procTS360GetUserGridFields";
        internal static string PROC_SET_USER_GRID_FIELD = "procTS360SetUserGridField";
        internal static string PROC_DELETE_USER_GRID_FIELD = "procTS360DeleteUserGridField";

        internal static string PROC_GET_GRID_TEMPLATES = "procTS360GetGridTemplates";
        internal static string PROC_GET_SINGLE_GRID_TEMPLATE = "procTS360GetGridTemplate";
        internal static string PROC_SET_GRID_TEMPLATE = "procTS360SetGridTemplate";
        internal static string PROC_DELETE_GRID_TEMPLATE = "procTS360DeleteGridTemplate";
        internal static string PROC_GET_GRID_TEMPLATE_OWNERS = "procTS360GetGridTemplateOwners";
        internal static string PROC_GET_SOP_GRID_FIELD_LIST = "procTS360GetSOPGridFieldList";

        internal static string PROC_GET_USER_GRID_TEMPLATES = "procTS360GetUserGridTemplates";
        internal static string PROC_GET_GRID_TEMPLATES_BY_USER = "procTS360GetGridTemplatesByUser";
        internal static string PROC_SET_USER_GRID_TEMPLATE = "procTS360SetUserGridTemplate";
        internal static string PROC_DELETE_USER_GRID_TEMPLATE = "procTS360DeleteUserGridTemplate";
        internal static string PROC_SET_USER_GRID_TEMPLATES = "procTS360SetUserGridTemplates";

        internal static string PROC_GET_USER_DEFAULT_GRID_TEMPLATE = "procTS360GetUserObject";
        internal static string PROC_SET_USER_DEFAULT_GRID_TEMPLATE = "procTS360SetUserObject";

        internal static string PROC_GET_GRID_TEMPLATE_LINES = "procTS360GetGridTemplateLines";
        internal static string PROC_GET_GRID_TEMPLATE_LINES_WITH_PAGING = "procTS360GetGridTemplateLinesWithPaging";
        internal static string PROC_SET_GRID_TEMPLATE_LINE = "procTS360SetGridTemplateLine";
        internal static string PROC_DELETE_GRID_TEMPLATE_LINE = "procTS360DeleteGridTemplateLine";

        internal static string PROC_GET_GRID_FIELD_POSITION = "procTS360GetGridFieldPositionInGridTemplate";

        internal static string PROC_COPY_GRID_TEMPLATE = "procTS360CopyGridTemplate";

        // PE
        internal static string PROC_GET_ALL_USER_GRID_CODES = "procTS360GetAllUserGridCodes";
        internal static string PROC_GET_ALL_USER_GRID_FIELDS = "procTS360GetAllUserGridFields";

        internal static string PROC_GET_USER_GRID_TEMPLATES_PAGING = "procTS360GetUserGridTemplatesWithPaging";
        internal static string PROC_UPDATE_USER_GRID_TEMPLATES = "procTS360UpdateUserGridTemplates";
        internal static string ProcTs360SaveSlipReportForGridField = "procTS360SaveSlipReportForGridField";
        
        internal static string ProcTs360SaveGridTemplate = "procTS360SaveGridTemplate";
        internal static string ProcTs360SaveUserGridFieldsCodes = "procTS360SetUserGridFields";
        internal static string ProcTS360UpdateUserGridCodes = "procTS360UpdateUserGridCodes";

        internal static string ProcTs360ClearDefaultSettingOfGridTemplate = "procTS360ClearDefaultSettingOfGridTemplate";
        internal static string ProcTS360GetGridDistribution = "procTS360GetGridDistributionOption";
        internal static string ProcTS360SaveGridDistribution = "procTS360SaveGridDistribution";

        #endregion

        #region Cart Grid Related Stored Procedures name

        internal static string PROC_GET_CART_GRID_HEADERS = "procTS360GetBasketGridHeaders";
        internal static string PROC_CREATE_BASKET_GRID_HEADER = "procTS360CreateBasketGridHeader";

        internal static string PROC_GET_ERROR_LINE_ITEMS = "procTS360GetErrorLineItems";
        internal static string PROC_SET_CART_GRID_LINE = "procTS360SetBasketGridLine";
        internal static string PROC_SET_ALL_CART_GRID_LINE = "procTS360SetAllBasketGridLine";
        internal static string PROC_DELETE_CART_GRID_LINE = "procTS360DeleteBasketGridLine";

        internal static string PROC_GET_CART_LINE_ITEM_NOTE_QUANTITES = "procTS360GetBasketLineItemNoteQuantities";
        internal static string PROC_SET_CART_LINE_ITEM_NOTE_QUANTITY = "procTS360SetBasketLineItemNoteQuantity";
        internal static string PROC_DELETE_CART_LINE_ITEM_QUANTITY = "procTS360DeleteBasketLineItemNoteQuantity";
        internal static string PROC_MODIFY_NOTE_TO_ALL_TITLES = "procTS360UpdateAndRemoveNoteToAllTitle";
        internal static string PROC_SEARCH_WITHITN_BASKET_NOTE = "procTS360SearchWithinBasketByNote";
        internal static string PROC_GET_NOTES_BY_BTKEYS = "procTS360GetNotesByBtkeys";
        internal static string PROC_GET_USER_NOTES_BY_BTKEYS = "procTS360GetUserNoteByBTkey";

        internal static string PROC_HAS_DEFAULT_CART_GRID_TEMPLATE = "procTS360HasDefaultBasketGridTemplate";
        internal static string PROC_SAVE_GRID_LINES_AS_GRID_TEMPLATE = "procTS360SaveGridLinesAsAGridTemplate";
        internal static string PROC_CART_CHECK_DUPLICATE_DEFAULT_TEMPLATE = "procTS360CheckDuplicateDefaultTemplateForBasket";
        internal static string PROC_PASTE_GRID_LINE_FROM_CLIPBOARD = "procTS360PasteGridLineFromClipboard360ToBasket";
        internal static string PROC_COPY_CANCELLED_LINE_ITEMS = "procTS360CopyCancelledBasketLineItems";

        internal static string PROC_COPY_BASKETS = "procTS360CopyBaskets";
        internal static string PROC_CHECK_DUPLICATE_GRID_LINE_TEMPLATE_CART = "procTS360CheckDuplicateTemplateForBasket";

        internal static string PROC_CREATE_EBOOK_BASKETS = "procTS360CreateeBookBasket";
        
        internal static string PROC_APPLY_TEMPLATE_TO_TITLES = "procTS360ApplyTemplateToTitles";

        internal static string PROC_REMOVE_GRID_FROM_LINE_ITEMS = "procTS360RemoveGridFromLineItems";

        internal static string PROC_ADD_PRODUCT_TO_CART = "procTS360AddMoveCopyLineItems";
        internal static string PROC_GET_GRID_FIELD_POSITION_IN_CART = "procTS360GetGridFieldPositionInBasket";
        internal static string PROC_GET_GRID_FIELD_POSITION_IN_CART_LineItems = "procTS360GetGridFieldPositionInBasketForLineItems";

        internal static string PROC_GET_GRID_SUMMARY = "procTS360GetGridSummary";
        internal static string PROC_GET_GRID_SUMMARY_DETAIL = "procTS360GetGridSummaryDetail";
        internal static string PROC_REMOVE_GRID_FROM_CART = "procTS360RemoveGridFromBasket";

        internal static string PROC_TRANSFER_CART_TO_USERS = "procTS360TransferBasketToUsers";
        internal static string PROC_CHECK_EBOOK_ACCOUNT_INFO = "procTS360GetAccountInfoForESupplier";

        internal static string PROC_DELETE_ZERO_QUANTITY = "procTS360DeleteBasketLineitemsWithZeroQuantity";

        internal static string PROC_REPLACE_ALL_GRID_FIELD_CODE_IN_BASKET = "procTS360ReplaceAllGridFieldCodeInBasket";

        internal static string PROC_VALIDATE_GRID_IN_CART_FOR_LIBRARY_SYSTEM_ACCOUNT = "procTS360ValidateGridInCartForLibrarySystemAccount";

        internal static string PROC_UPDATE_GRID_FIELD_POSITION_IN_TEMPLATE_HEADER = "procTS360UpdateHeaderOrTemplate";

        internal static string PROC_GET_GRID_NOTE_COUNT_FOR_LINEITEM = "procTS360GetCountNotesAndGridLineByBLIs";

        internal static string PROC_DELETE_DEFAULT_GRID_TEMPLATE = "procTS360DeleteDefaultTemplate";
        internal static string PROC_SET_BLANK_GL_TO_CART = "procTS360ConvertSharedLineToGridLine";
        internal static string PROC_SPLIT_CART_TO_GRID_AND_NONGRID = "procTS360SplitBasketToGridAndNG";
        internal static string PROC_BASKET_MANAGEMENT_CHECK_CONTAIN_MIX = "procTS360CheckBasketContainsAMixOfGridNNonGrid";
        internal static string PROC_GET_LENGTH_LONGEST_NOTE = "procTS360GetLengthOfLongestNote";

        internal static string PROC_ADD_BATCH_TO_BACKGROUND_PROCESSING = "procTS360RequestBatchEntry";

        #endregion

        #region Shared Cart
        internal static string ProcIsSharedCart = "procTS360IsSharedCart";
        internal static string ProcIsPremiumSharedCart = "procTS360IsPremiumSharedCart";

        internal static string ProcTs360SetBasketUserGroup = "procTS360SetBasketUserGroup";
        internal static string ProcTs360DeleteBasketUserGroup = "procTS360DeleteBasketUserGroup";
        internal static string ProcTs360GetBasketUserGroups = "procTS360GetBasketUserGroups";

        internal static string ProcSetUserGroupMember = "procTS360SetBasketUserGroupMembers";
        internal static string ProcDeleteUserGroupMember = "procTS360DeleteBasketUserGroupMember";
        internal static string ProcTs360GetBasketUserGroupMembers = "procTS360GetBasketUserGroupMembers";

        internal static string ProcSetOrgWorkflowStage = "procTS360SetOrgWorkflowStage";
        internal static string ProcDeleteOrgWorkflowStage = "procTS360DeleteOrgWorkflowStage";
        internal static string ProcGetOrganizationWorkflowStages = "procTS360GetOrganizationWorkflowStages";

        internal static string ProcSetSharedCartMember = "procTS360SetBasketUser";
        internal static string ProcDeleteSharedCartMember = "procTS360DeleteBasketUser";
        internal static string ProcTs360GetSharedCartMembers = "procTS360GetBasketUsers";

        internal static string ProcSetMemberWorkflowStage = "procTS360SetBasketUserWorkflowStage";
        internal static string ProcDeleteMemberWorkflowStage = "procTS360DeleteBasketUserWorkflowStage";
        internal static string ProcTs360GetSharedCartMemberWorkflowStages = "procTS360GetBasketUserWorkflowStages";

        internal static string ProcSetSharedCartWorkflow = "procTS360SetBasketWorkflows";
        internal static string ProcDeleteSharedCartWorkflow = "procTS360DeleteBasketWorkflow";
        internal static string ProcTs360GetSharedCartWorkflows = "procTS360GetBasketWorkflows";

        internal static string ProcSetWorkflowStage = "procTS360SetBasketWorkflowStage";
        internal static string ProcDeleteWorkflowStage = "procTS360DeleteBasketWorkflowStage";
        internal static string ProcTs360GetCartWorkflowStages = "procTS360GetBasketWorkflowStages";

        internal static string ProcShareCart = "procTS360SharedBasket";
        internal static string ProcHasSharedCartProfile = "procTS360HasSharedBasketProfile";
        internal static string ProcGetSharedCartSummary = "procTS360GetBasketSummary";
        internal static string ProcGetSharedCartSummaryDetail = "procTS360GetBasketSummaryDetail";

        #endregion

        #region NEW GRID STORED PROCEDURES
        internal static string PROC_GET_GRID_FIELD_GRID_CODE_BY_USER = "procTS360GetGridFieldsAndCodesByUser";
        internal static string PROC_GET_GRID_FIELD_BY_USER = "procTS360GetGridFieldsByUser";
        internal static string PROC_GET_BASKET_LINE_ITEM_GRIDS = "procTS360GetBasketLineItemGrids";
        internal static string PROC_GET_DEFAULT_BASKET_GRID_TEMPLATE = "procTS360GetDefaultBasketGridTemplate";        
        #endregion

    }

    public class GridCacheConstants
    {
        public static VelocityCaching.VelocityCacheLevel CommonGridCacheLevel
        {
            get { return VelocityCaching.VelocityCacheLevel.Request; }
        }

        public static VelocityCaching.VelocityCacheLevel CartActionCacheLevel
        {
            get { return VelocityCaching.VelocityCacheLevel.Session; }
        }
    }
}
