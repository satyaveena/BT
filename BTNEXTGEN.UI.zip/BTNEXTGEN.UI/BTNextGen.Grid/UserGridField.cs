﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserGridField : EditableObject<GridDataAccessManager>
    {        
        public string UserGridFieldId
        {
            get { return Id; }            
        }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                SetChanged();
                _userId = value;
            }
        }

        //For example: btadmin
        public string UserLoginName { get; internal set; }

        //Fist name, Last name
        public string UserDisplayName { get; internal set; }

        private string _gridFieldId;
        public string GridFieldId
        {
            get { return _gridFieldId; }
            set
            {
                SetChanged();
                _gridFieldId = value;
            }
        }

        private string _displayType;
        public string DisplayType
        {
            get { return _displayType; }
            set
            {
                SetChanged();
                _displayType = value;
            }
        }

        private string _defaultGridCodeId;
        public string DefaultGridCodeId
        {
            get { return _defaultGridCodeId; }
            set
            {
                SetChanged();
                _defaultGridCodeId = value;
            }
        }

        private string _defaultGridText;
        public string DefaultGridText
        {
            get { return _defaultGridText; }
            set
            {
                SetChanged();
                _defaultGridText = value;
            }
        }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateUserGridField(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateUserGridField(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteUserGridField(this);
        }
    }
}
