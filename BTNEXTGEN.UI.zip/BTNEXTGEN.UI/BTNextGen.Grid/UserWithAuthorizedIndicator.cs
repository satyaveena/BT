﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserWithAuthorizedIndicator
    {
        public string UserId { get; set; }

        public string UserName { get; set; }

        public bool IsAuthorized { get; set; }
    }
}
