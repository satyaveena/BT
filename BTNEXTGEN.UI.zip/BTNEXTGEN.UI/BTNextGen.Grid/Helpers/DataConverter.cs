﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.DataItems;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Grid.Cart;
using BTNextGen.Grid.Cart.Shared;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart;
using BTNextgen.Grid.Cart.Shared;
using Microsoft.SqlServer.Server;

namespace BTNextGen.Grid.Helpers
{
    public class DataConverter
    {
        public static List<SqlDataRecord> ConvertCartLineExtensionToBasketLineItemIDs(List<string> lineItemIds)
        {
            const string LINEITEMID = "BasketLineItemID";
            SqlMetaData column = new SqlMetaData(LINEITEMID, SqlDbType.NVarChar, 255);
            List<SqlDataRecord> list = new List<SqlDataRecord>();

            foreach (string lineItemId in lineItemIds)
            {
                SqlDataRecord record = new SqlDataRecord(column);
                record.SetString(0, lineItemId);
                list.Add(record);
            }

            return list;
        }
        public static DataSet ConvertGridCodeToDataSet(GridCode gridCode)
        {
            const string GRID_CODE_ID = "GridCodeID";
            const string GRID_FIELD_ID = "GridFieldID";
            const string CODE = "Code";
            const string LITERAL = "Literal";
            const string EFFECTIVE_DATE = "EffectiveDate";
            const string EXPIRATION_DATE = "ExpirationDate";
            const string ACTIVE_INDICATOR = "ActiveIndicator";

            DataSet ds = new DataSet();
            DataTable t = new DataTable();
            ds.Tables.Add(t);
            t.Columns.Add(GRID_CODE_ID, typeof(string));
            t.Columns.Add(GRID_FIELD_ID, typeof(string));
            t.Columns.Add(CODE, typeof(string));
            t.Columns.Add(LITERAL, typeof(string));
            t.Columns.Add(EFFECTIVE_DATE, typeof(DateTime));
            t.Columns.Add(EXPIRATION_DATE, typeof(DateTime));
            t.Columns.Add(ACTIVE_INDICATOR, typeof(bool));
            DataRow row = t.NewRow();
            row[GRID_CODE_ID] = gridCode.GridCodeId;
            row[GRID_FIELD_ID] = gridCode.GridFieldId;
            row[CODE] = gridCode.Code;
            row[LITERAL] = gridCode.Literal;
            row[EFFECTIVE_DATE] = gridCode.ExpirationDate;
            row[EXPIRATION_DATE] = gridCode.ExpirationDate;
            row[ACTIVE_INDICATOR] = gridCode.ActiveIndicator;

            t.Rows.Add(row);
            return ds;
        }
        public static DataSet ConvertUserGridCodeToDataSet(UserGridCode code)
        {
            const string USER_GRID_CODE_ID = "UserGridCodeID";
            const string GRID_CODE_ID = "GridCodeID";
            const string USER_ID = "u_user_id";
            DataSet ds = new DataSet();
            DataTable t = new DataTable();
            ds.Tables.Add(t);
            t.Columns.Add(USER_GRID_CODE_ID, typeof(string));
            t.Columns.Add(GRID_CODE_ID, typeof(string));
            t.Columns.Add(USER_ID, typeof(string));
            DataRow row = t.NewRow();
            row[USER_GRID_CODE_ID] = code.UserGridCodeId;
            row[GRID_CODE_ID] = code.GridCodeId;
            row[USER_ID] = code.UserId;
            t.Rows.Add(row);
            return ds;
        }
        public static DataSet ConvertGridFieldToDataSet(GridField gridField)
        {
            const string GRID_FIELD_ID = "GridFieldID";
            const string SOP_GRID_FIELD_ID = "SOPGridFieldID";
            const string ORG_ID = "u_org_id";
            const string FREE_TEXT_INDI = "FreeTextIndicator";
            const string NAME = "Name";
            const string FREE_TEXT_CHARACTER = "FreeTextCharacterLimit";
            const string SEQUENCE = "Sequence";
            const string LOCKED_INDICATOR = "LockedIndicator";
            const string ACTIVE_INDICATOR = "ActiveIndicator";
            const string ALL_GRID_CODES_INDICATOR = "UserViewAllGridCodesIndicator";
            const string VALIDATE_INDICATOR = "ValidateIndicator";
            const string SLIP_REPORT_SEQUENCE = "SlipReportSequence";

            DataSet ds = new DataSet();
            DataTable t = new DataTable();
            ds.Tables.Add(t);
            t.Columns.Add(GRID_FIELD_ID, typeof(string));
            t.Columns.Add(SOP_GRID_FIELD_ID, typeof(string));
            t.Columns.Add(ORG_ID, typeof(string));
            t.Columns.Add(NAME, typeof(string));
            t.Columns.Add(FREE_TEXT_INDI, typeof(bool));
            t.Columns.Add(FREE_TEXT_CHARACTER, typeof(int));
            t.Columns.Add(SEQUENCE, typeof(byte));
            t.Columns.Add(LOCKED_INDICATOR, typeof(bool));
            t.Columns.Add(ACTIVE_INDICATOR, typeof(bool));
            t.Columns.Add(ALL_GRID_CODES_INDICATOR, typeof(bool));
            t.Columns.Add(VALIDATE_INDICATOR, typeof(bool));
            t.Columns.Add(SLIP_REPORT_SEQUENCE, typeof(bool));
            DataRow row = t.NewRow();
            row[GRID_FIELD_ID] = gridField.GridFieldId;
            row[SOP_GRID_FIELD_ID] = gridField.SOPGridFieldId;
            row[ORG_ID] = gridField.OrganizationId;
            row[NAME] = gridField.Name;
            row[FREE_TEXT_INDI] = gridField.FreeTextIndicator;
            row[FREE_TEXT_CHARACTER] = gridField.FreeTextCharacterLimit;
            row[SEQUENCE] = gridField.Sequence;
            row[LOCKED_INDICATOR] = gridField.LockedIndicator;
            row[ACTIVE_INDICATOR] = gridField.ActiveIndicator;
            row[ALL_GRID_CODES_INDICATOR] = gridField.UserViewAllGridCodesIndicator;
            row[VALIDATE_INDICATOR] = gridField.ValidateIndicator;
            row[SLIP_REPORT_SEQUENCE] = gridField.SlipReportSequence;

            t.Rows.Add(row);
            return ds;
        }
        public static DataSet ConvertUserGridFieldToDataSet(UserGridField userGridField)
        {
            const string USER_GRID_FIELD_ID = "UserGridFieldID";
            const string GRID_FIELD_ID = "GridFieldID";
            const string USER_ID = "u_user_id";
            const string DISPLAY_TYPE = "DisplayType";
            const string DEFAULT_GRID_CODE_ID = "DefaultGridCodeID";

            DataSet ds = new DataSet();
            DataTable t = new DataTable();
            ds.Tables.Add(t);
            t.Columns.Add(USER_GRID_FIELD_ID, typeof(string));
            t.Columns.Add(GRID_FIELD_ID, typeof(string));
            t.Columns.Add(USER_ID, typeof(string));
            t.Columns.Add(DISPLAY_TYPE, typeof(string));
            t.Columns.Add(DEFAULT_GRID_CODE_ID, typeof(string));
            DataRow row = t.NewRow();
            row[USER_GRID_FIELD_ID] = userGridField.UserGridFieldId;
            row[GRID_FIELD_ID] = userGridField.GridFieldId;
            row[USER_ID] = userGridField.UserId;
            row[DISPLAY_TYPE] = userGridField.DisplayType;
            row[DEFAULT_GRID_CODE_ID] = userGridField.DefaultGridCodeId;
            t.Rows.Add(row);
            return ds;
        }
        public static List<SqlDataRecord> ConvertProductsToMergeCartLineItem(string btkey, int quantity, string note)
        {
            var columns = new SqlMetaData[8];
            columns[0] = new SqlMetaData("BasketLineItemID", SqlDbType.NVarChar, 50);
            columns[1] = new SqlMetaData("BTKey", SqlDbType.Char, 10);
            columns[2] = new SqlMetaData("quantity", SqlDbType.Int);
            columns[3] = new SqlMetaData("POLineItemNumber", SqlDbType.NVarChar, 50);
            columns[4] = new SqlMetaData("Note", SqlDbType.Text);
            columns[5] = new SqlMetaData("BibNumber", SqlDbType.NVarChar, 25);
            columns[6] = new SqlMetaData("PrimaryResponsiblePartyRedundant", SqlDbType.NVarChar, 255);
            columns[7] = new SqlMetaData("ShortTitleRedundant", SqlDbType.NVarChar, 256);
            List<SqlDataRecord> dataRecords = new List<SqlDataRecord>();

            SqlDataRecord record = new SqlDataRecord(columns);
            record.SetString(1, btkey);
            record.SetInt32(2, quantity);
            record.SetString(4, note);
            dataRecords.Add(record);

            return dataRecords;
        }
        public static List<SqlDataRecord> ConvertProductsToMergeCartLineItem(List<ProductLineItem> products)
        {
            var columns = new SqlMetaData[8];
            columns[0] = new SqlMetaData("BasketLineItemID", SqlDbType.NVarChar, 50);
            columns[1] = new SqlMetaData("BTKey", SqlDbType.Char, 10);
            columns[2] = new SqlMetaData("quantity", SqlDbType.Int);
            columns[3] = new SqlMetaData("POLineItemNumber", SqlDbType.NVarChar, 50);
            columns[4] = new SqlMetaData("Note", SqlDbType.Text);
            columns[5] = new SqlMetaData("BibNumber", SqlDbType.NVarChar, 25);
            columns[6] = new SqlMetaData("PrimaryResponsiblePartyRedundant", SqlDbType.NVarChar, 255);
            columns[7] = new SqlMetaData("ShortTitleRedundant", SqlDbType.NVarChar, 256);
            List<SqlDataRecord> dataRecords = new List<SqlDataRecord>();
            foreach (var item in products)
            {
                SqlDataRecord record = new SqlDataRecord(columns);
                if (!string.IsNullOrEmpty(item.LineItemId))
                    record.SetString(0, item.LineItemId);
                record.SetString(1, item.BTKey);
                if (item.Quantity >= 0)
                    record.SetInt32(2, item.Quantity);
                else
                {
                    record.SetDBNull(2);
                }
                if (!string.IsNullOrEmpty(item.PONumber))
                {
                    record.SetString(3, item.PONumber);
                }
                if (!string.IsNullOrEmpty(item.Note))
                {
                    record.SetString(4, item.Note);
                }
                if (!string.IsNullOrEmpty(item.BibNumber))
                {
                    record.SetString(5, item.BibNumber);
                }
                if (!string.IsNullOrEmpty(item.Author))
                {
                    record.SetString(6, item.Author);
                }
                else
                {
                    record.SetValue(6, DBNull.Value);
                }

                if (!string.IsNullOrEmpty(item.Title))
                {
                    record.SetString(7, item.Title);
                }
                else
                {
                    record.SetValue(7, DBNull.Value);
                }
                dataRecords.Add(record);
            }
            return dataRecords;
        }
        public static List<SqlDataRecord> ConvertUPCProductsToMergeCartLineItem(Dictionary<string, int> upcQuantity, string note)
        {
            var columns = new SqlMetaData[8];
            columns[0] = new SqlMetaData("BasketLineItemID", SqlDbType.NVarChar, 50);
            columns[1] = new SqlMetaData("ISBNUPC", SqlDbType.Char, 14);
            columns[2] = new SqlMetaData("quantity", SqlDbType.Int);
            columns[3] = new SqlMetaData("POLineItemNumber", SqlDbType.NVarChar, 50);
            columns[4] = new SqlMetaData("Note", SqlDbType.Text);
            columns[5] = new SqlMetaData("BibNumber", SqlDbType.NVarChar, 25);
            columns[6] = new SqlMetaData("PrimaryResponsiblePartyRedundant", SqlDbType.NVarChar, 255);
            columns[7] = new SqlMetaData("ShortTitleRedundant", SqlDbType.NVarChar, 256);
            List<SqlDataRecord> dataRecords = new List<SqlDataRecord>();
            foreach (var item in upcQuantity)
            {
                SqlDataRecord record = new SqlDataRecord(columns);
                record.SetString(1, item.Key);
                record.SetInt32(2, item.Value);
                record.SetString(4, note);
                dataRecords.Add(record);
            }
            return dataRecords;
        }
        public static List<SqlDataRecord> ConvertLineItemIDsToMergeCartLineItem(List<string> lineItemIDs)
        {
            var columns = new SqlMetaData[8];
            columns[0] = new SqlMetaData("BasketLineItemID", SqlDbType.NVarChar, 50);
            columns[1] = new SqlMetaData("BTKey", SqlDbType.Char, 10);
            columns[2] = new SqlMetaData("quantity", SqlDbType.Int);
            columns[3] = new SqlMetaData("POLineItemNumber", SqlDbType.NVarChar, 50);
            columns[4] = new SqlMetaData("Note", SqlDbType.Text);
            columns[5] = new SqlMetaData("BibNumber", SqlDbType.NVarChar, 25);
            columns[6] = new SqlMetaData("PrimaryResponsiblePartyRedundant", SqlDbType.NVarChar, 255);
            columns[7] = new SqlMetaData("ShortTitleRedundant", SqlDbType.NVarChar, 256);
            List<SqlDataRecord> dataRecords = new List<SqlDataRecord>();
            foreach (var lineItemId in lineItemIDs)
            {
                SqlDataRecord record = new SqlDataRecord(columns);
                record.SetString(0, lineItemId);
                dataRecords.Add(record);
            }
            return dataRecords;
        }
        public static DataSet ConverUserGridTemplateToDataSet(UserGridTemplate userGridTemplate)
        {
            const string USER_GRID_TEMPLATE_ID = "UserGridTemplateID";
            const string GRID_TEMPLATE_ID = "GridTemplateID";
            const string USER_ID = "u_user_id";
            const string SEQUENCE = "Sequence";

            DataSet ds = new DataSet();
            DataTable t = new DataTable();
            ds.Tables.Add(t);
            t.Columns.Add(USER_GRID_TEMPLATE_ID, typeof(string));
            t.Columns.Add(GRID_TEMPLATE_ID, typeof(string));
            t.Columns.Add(USER_ID, typeof(string));
            t.Columns.Add(SEQUENCE, typeof(int));

            DataRow row = t.NewRow();
            row[USER_GRID_TEMPLATE_ID] = userGridTemplate.UserGridTemplateId;
            row[GRID_TEMPLATE_ID] = userGridTemplate.GridTemplateId;
            row[USER_ID] = userGridTemplate.UserId;
            row[SEQUENCE] = userGridTemplate.Sequence;

            t.Rows.Add(row);
            return ds;
        }
        //public static Dictionary<string, object> ConvertCartGridLineToDictionary(CartGridLine cartGridLine, Dictionary<string, int> map)
        //{
        //    Dictionary<string, object> dict = new Dictionary<string, object>();
        //    GridLineFieldCodeList list = cartGridLine.FieldCodeList;
        //    for (int i = 0; i < 10; i++)
        //    {
        //        string fieldIdParam = "@GridField" + (i + 1).ToString() + "ID";
        //        string codeIDParam = "@GridCode" + (i + 1).ToString() + "ID";
        //        string textParam = "@GridText" + (i + 1).ToString();

        //        if (i < list.Count)
        //        {
        //            int position = map[list.ElementAt(i).GridFieldId];
        //            if (position < 0)
        //            {
        //                dict.Add(fieldIdParam, DBNull.Value);
        //                dict.Add(codeIDParam, DBNull.Value);
        //                dict.Add(textParam, DBNull.Value);
        //                continue;
        //            }

        //            GridLineFieldCode line = list.FirstOrDefault(j => j.GridFieldId == list.ElementAt(i).GridFieldId);
        //            if (line != null)
        //            {
        //                dict.Add(fieldIdParam, line.GridFieldId);
        //                if (string.IsNullOrEmpty(line.GridCodeId))
        //                    dict.Add(codeIDParam, DBNull.Value);
        //                else
        //                    dict.Add(codeIDParam, line.GridCodeId);

        //                if (string.IsNullOrEmpty(line.GridTextId))
        //                    dict.Add(textParam, DBNull.Value);
        //                else
        //                    dict.Add(textParam, line.GridTextId);
        //            }
        //        }
        //        else
        //        {
        //            dict.Add(fieldIdParam, DBNull.Value);
        //            dict.Add(codeIDParam, DBNull.Value);
        //            dict.Add(textParam, DBNull.Value);
        //        }
        //    }
        //    return dict;
        //}
        public static DataSet ConvertCartGridLineItemNoteQuantityToDataSet(CartLineItemNoteQuantity cartLineItemNoteQuantity)
        {
            const string CART_LINE_ID = "BasketLineItemID";
            const string NOTE = "Note";
            const string USER_ID = "u_user_id";
            const string QUANTITY = "Quantity";

            DataSet ds = new DataSet();
            DataTable t = new DataTable();
            ds.Tables.Add(t);
            t.Columns.Add(CART_LINE_ID, typeof(string));
            t.Columns.Add(USER_ID, typeof(string));
            t.Columns.Add(QUANTITY, typeof(string));
            t.Columns.Add(NOTE, typeof(int));

            DataRow row = t.NewRow();
            row[CART_LINE_ID] = cartLineItemNoteQuantity.LineItemId;
            row[USER_ID] = cartLineItemNoteQuantity.UserId;
            row[QUANTITY] = cartLineItemNoteQuantity.Quantity;
            row[NOTE] = cartLineItemNoteQuantity.Note;

            t.Rows.Add(row);
            return ds;
        }
        public static Dictionary<string, string> ConverGridTemplateFieldToDictionary(GridTemplate template)
        {
            Dictionary<string, string> fieldList = new Dictionary<string, string>();
            GridTemplateLine item = template.GridTemplateLines.FirstOrDefault();
            int i = 1;
            if (item != null)
            {
                foreach (GridFieldCodeInTemplate line in item.GridFieldCodeInTemplates)
                {
                    fieldList.Add("GridField" + i.ToString() + "ID", line.GridFieldId);
                    i++;
                }
            }
            return fieldList;
        }
        public static Dictionary<string, string> ConverGridCodeInTemplateToDictionary(GridTemplateLine templateLine, DataSet map)
        {
            Dictionary<string, string> codeList = new Dictionary<string, string>();
            Dictionary<string, int> fieldMap =
                map.Tables[0].AsEnumerable().Where(
                    row =>
                    !string.IsNullOrEmpty(DataAccessHelper.ConvertToString(row["GridFieldID"]))).ToDictionary(
                        dr => DataAccessHelper.ConvertToString(dr["GridFieldID"]),
                        dr => DataAccessHelper.ConvertToInt(dr["Position"]));
            GridFieldCodeInTemplateList list = templateLine.GridFieldCodeInTemplates;
            if (list != null)
            {
                foreach (GridFieldCodeInTemplate line in list)
                {

                    var position = fieldMap[line.GridFieldId];
                    if (position > 0)
                    {
                        if (!string.IsNullOrEmpty(line.GridFieldId))
                            codeList.Add("GridField" + position + "ID", line.GridFieldId);
                        if (!string.IsNullOrEmpty(line.GridCodeId))
                            codeList.Add("GridCode" + position + "ID", line.GridCodeId);
                        if (!string.IsNullOrEmpty(line.GridText))
                            codeList.Add("GridText" + position, line.GridText);
                    }
                }
            }
            return codeList;
        }

        //public static List<SqlDataRecord> ConvertCartGridLinesToDataSet(List<CartGridLine> cartGridLines)
        //{
        //    var dataRecords = new List<SqlDataRecord>();
        //    var sqlMetaDatas = new SqlMetaData[32];

        //    int colNum = 0;

        //    for (int i = 1; i <= 10; i++)
        //    {
        //        string codeIDFieldName = "GridCode" + i.ToString() + "ID";
        //        string textFieldName = "GridText" + i.ToString();
        //        string fieldIDFieldName = "GridField" + i.ToString() + "ID";
        //        sqlMetaDatas[colNum] = new SqlMetaData(fieldIDFieldName, SqlDbType.VarChar, 50);
        //        sqlMetaDatas[colNum + 10] = new SqlMetaData(codeIDFieldName, SqlDbType.VarChar, 50);
        //        sqlMetaDatas[colNum + 20] = new SqlMetaData(textFieldName, SqlDbType.VarChar, 26);
        //        colNum++;

        //    }
        //    colNum += 20;
        //    sqlMetaDatas[colNum++] = new SqlMetaData("Quantity", SqlDbType.Int);
        //    sqlMetaDatas[colNum++] = new SqlMetaData("BTKey", SqlDbType.NVarChar, 10);
        //    foreach (CartGridLine cartGridLine in cartGridLines)
        //    {
        //        var dataRecord = new SqlDataRecord(sqlMetaDatas);
        //        dataRecord.SetInt32(30, cartGridLine.Quantity);
        //        int i = 0;
        //        foreach (GridLineFieldCode fieldCode in cartGridLine.FieldCodeList)
        //        {
        //            dataRecord.SetString(i, fieldCode.GridFieldId);
        //            if (!string.IsNullOrEmpty(fieldCode.GridCodeId))
        //                dataRecord.SetString(i + 10, fieldCode.GridCodeId);
        //            if (!string.IsNullOrEmpty(fieldCode.GridTextId))
        //                dataRecord.SetString(i + 20, fieldCode.GridTextId);
        //            i++;
        //        }
        //        dataRecords.Add(dataRecord);
        //    }
        //    return dataRecords;
        //}
        public static List<SqlDataRecord> ConvertCartGridLinesToDataSet(Dictionary<string, List<CommonCartGridLine>> cartGridLines)
        {
            if (cartGridLines == null || cartGridLines.Count == 0) return null;

            

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[13];

            int colNum = 0;
            sqlMetaDatas[colNum++] = new SqlMetaData("AgencyCodeID", SqlDbType.VarChar, 50);
            sqlMetaDatas[colNum++] = new SqlMetaData("ItemTypeID", SqlDbType.VarChar, 50);
            sqlMetaDatas[colNum++] = new SqlMetaData("CollectionID", SqlDbType.VarChar, 50);

            for (int i = 1; i < 7; i++)
            {
                string userCodeID = "UserCode" + i + "ID";
                sqlMetaDatas[colNum] = new SqlMetaData(userCodeID, SqlDbType.VarChar, 50);
                colNum++;
            }
            sqlMetaDatas[colNum++] = new SqlMetaData("CallNumberText", SqlDbType.VarChar, 26);
            sqlMetaDatas[colNum++] = new SqlMetaData("Quantity", SqlDbType.Int);//colNum= 10
            sqlMetaDatas[colNum++] = new SqlMetaData("Sequence", SqlDbType.Int);//colNum= 11
            sqlMetaDatas[colNum++] = new SqlMetaData("BTKey", SqlDbType.NVarChar, 10);//colNum= 12
            foreach (KeyValuePair<string, List<CommonCartGridLine>> keyValuePair in cartGridLines)
            {
                var gridLineList = keyValuePair.Value;
                if (gridLineList == null || gridLineList.Count == 0) continue;
                gridLineList = gridLineList.OrderBy(item => item.Sequence).ToList();
                //var sequence = 1;
                foreach (CommonCartGridLine cartGridLine in gridLineList)
                {
                    var dataRecord = new SqlDataRecord(sqlMetaDatas);
                    var gridCodeList = cartGridLine.GridFieldCodeList;
                    for (var i = 0; i < gridCodeList.Count; i++)
                    {
                        var position = 0;
                        var gridFc = gridCodeList[i];
                        switch (gridFc.GridFieldType)
                        {
                            case GridFieldType.AgencyCode:
                                position = 0;
                                break;
                            case GridFieldType.ItemType:
                                position = 1;
                                break;
                            case GridFieldType.Collection:
                                position = 2;
                                break;
                            case GridFieldType.UserCode1:
                                position = 3;
                                break;
                            case GridFieldType.UserCode2:
                                position = 4;
                                break;
                            case GridFieldType.UserCode3:
                                position = 5;
                                break;
                            case GridFieldType.UserCode4:
                                position = 6;
                                break;
                            case GridFieldType.UserCode5:
                                position = 7;
                                break;
                            case GridFieldType.UserCode6:
                                position = 8;
                                break;
                            case GridFieldType.CallNumber:
                                position = 9;
                                break;
                        }
                        if (gridFc.GridFieldType != GridFieldType.CallNumber)
                        {
                            if (!string.IsNullOrEmpty(gridFc.GridCodeId))
                                dataRecord.SetString(position, gridFc.GridCodeId);
                            else
                                dataRecord.SetDBNull(position);
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(gridFc.GridTextValue))
                                dataRecord.SetString(position, gridFc.GridTextValue);
                            else
                                dataRecord.SetDBNull(position);
                        }

                    }
                    //TFS 10170: Add Sequence
                    //if (!string.IsNullOrEmpty(cartGridLine.AgencyCodeID))
                    //    dataRecord.SetString(0, cartGridLine.AgencyCodeID);
                    //else
                    //    dataRecord.SetDBNull(0);
                    //if (!string.IsNullOrEmpty(cartGridLine.ItemTypeID))
                    //    dataRecord.SetString(1, cartGridLine.ItemTypeID);
                    //else
                    //    dataRecord.SetDBNull(1);
                    //if (!string.IsNullOrEmpty(cartGridLine.CollectionID))
                    //    dataRecord.SetString(2, cartGridLine.CollectionID);
                    //else
                    //    dataRecord.SetDBNull(2); 
                    //if (!string.IsNullOrEmpty(cartGridLine.UserCode1ID))
                    //    dataRecord.SetString(3, cartGridLine.UserCode1ID);
                    //else
                    //    dataRecord.SetDBNull(3); 
                    //if (!string.IsNullOrEmpty(cartGridLine.UserCode2ID))
                    //    dataRecord.SetString(4, cartGridLine.UserCode2ID);
                    //else
                    //    dataRecord.SetDBNull(4); 
                    //if (!string.IsNullOrEmpty(cartGridLine.UserCode3ID))
                    //    dataRecord.SetString(5, cartGridLine.UserCode3ID);
                    //else
                    //    dataRecord.SetDBNull(5); 
                    //if (!string.IsNullOrEmpty(cartGridLine.UserCode4ID))
                    //    dataRecord.SetString(6, cartGridLine.UserCode4ID);
                    //else
                    //    dataRecord.SetDBNull(6); 
                    //if (!string.IsNullOrEmpty(cartGridLine.UserCode5ID))
                    //    dataRecord.SetString(7, cartGridLine.UserCode5ID);
                    //else
                    //    dataRecord.SetDBNull(7); 
                    //if (!string.IsNullOrEmpty(cartGridLine.UserCode6ID))
                    //    dataRecord.SetString(8, cartGridLine.UserCode6ID);
                    //else
                    //    dataRecord.SetDBNull(8); 
                    //if (!string.IsNullOrEmpty(cartGridLine.CallNumberText))
                    //    dataRecord.SetString(9, cartGridLine.CallNumberText);
                    //else
                    //    dataRecord.SetDBNull(9); 
                    if (cartGridLine.Quantity > 0)
                        dataRecord.SetInt32(10, cartGridLine.Quantity);
                    else
                        dataRecord.SetDBNull(10);
                    dataRecord.SetInt32(11, cartGridLine.Sequence);
                    dataRecord.SetString(12, keyValuePair.Key);
                    //int i = 0;
                    //foreach (GridTemplateFieldCode fieldCode in cartGridLine.GridFieldCodeList)
                    //{
                    //    dataRecord.SetString(i, fieldCode.GridFieldId);
                    //    if (!string.IsNullOrEmpty(fieldCode.GridCodeId))
                    //        dataRecord.SetString(i + 10, fieldCode.GridCodeId);
                    //    if (!string.IsNullOrEmpty(fieldCode.GridTextId))
                    //        dataRecord.SetString(i + 20, fieldCode.GridTextId);
                    //    i++;
                    //}
                    dataRecords.Add(dataRecord);
                }
            }

            return dataRecords;
        }

        //public static List<SqlDataRecord> ConvertCartGridLinesToDataSet(List<CartGridLine> cartGridLines, out Dictionary<string, object> fieldList)
        //{
        //    var dataRecords = new List<SqlDataRecord>();
        //    var sqlMetaDatas = new SqlMetaData[23];

        //    var line = cartGridLines.FirstOrDefault();
        //    int colNum = 0;
        //    fieldList = new Dictionary<string, object>();
        //    for (int i = 1; i <= 10; i++)
        //    {
        //        string codeIDFieldName = "GridCode" + i.ToString() + "ID";
        //        string textFieldName = "GridText" + i.ToString();
        //        sqlMetaDatas[colNum] = new SqlMetaData(codeIDFieldName, SqlDbType.VarChar, 50);
        //        sqlMetaDatas[colNum + 10] = new SqlMetaData(textFieldName, SqlDbType.VarChar, 26);
        //        colNum++;
        //        if (line != null &&
        //            line.FieldCodeList != null &&
        //            line.FieldCodeList.Count > 0 &&
        //            i <= line.FieldCodeList.Count)
        //        {
        //            var field = line.FieldCodeList.ElementAt(i - 1);
        //            fieldList.Add("GridField" + i.ToString() + "ID", field.GridFieldId);
        //        }
        //        else
        //        {
        //            fieldList.Add("GridField" + i.ToString() + "ID", DBNull.Value);
        //        }
        //    }
        //    colNum += 10;
        //    sqlMetaDatas[colNum++] = new SqlMetaData("Quantity", SqlDbType.Int);
        //    sqlMetaDatas[colNum++] = new SqlMetaData("Sequence", SqlDbType.Int);
        //    sqlMetaDatas[colNum++] = new SqlMetaData("EnabledIndicator", SqlDbType.Bit);
        //    var sequence = cartGridLines.Count;
        //    foreach (CartGridLine cartGridLine in cartGridLines)
        //    {
        //        var dataRecord = new SqlDataRecord(sqlMetaDatas);
        //        dataRecord.SetInt32(20, cartGridLine.Quantity);
        //        dataRecord.SetInt32(21, sequence);
        //        dataRecord.SetBoolean(22, true);
        //        int i = 0;
        //        foreach (GridLineFieldCode fieldCode in cartGridLine.FieldCodeList)
        //        {
        //            if (string.IsNullOrEmpty(fieldCode.GridCodeId))
        //                dataRecord.SetDBNull(i);
        //            else
        //                dataRecord.SetString(i, fieldCode.GridCodeId);
        //            if (string.IsNullOrEmpty(fieldCode.GridTextId))
        //                dataRecord.SetDBNull(i + 10);
        //            else
        //                dataRecord.SetString(i + 10, fieldCode.GridTextId);
        //            i++;
        //        }
        //        dataRecords.Add(dataRecord);
        //        sequence--;
        //    }
        //    return dataRecords;
        //}

        public static List<SqlDataRecord> ConvertGridTemplateLinesToDataSetNew(List<CommonGridTemplateLine> gridTemplateLines)
        {
            if (gridTemplateLines == null || gridTemplateLines.Count == 0) return null;

            gridTemplateLines = gridTemplateLines.OrderBy(item => item.Sequence).ToList();

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[16];
            sqlMetaDatas[0] = new SqlMetaData("GridTemplateLineID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("GridTemplateID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData(GridFieldType.AgencyCode + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[3] = new SqlMetaData(GridFieldType.ItemType + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[4] = new SqlMetaData(GridFieldType.Collection + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[5] = new SqlMetaData(GridFieldType.CallNumber + "Text", SqlDbType.VarChar, 26);
            sqlMetaDatas[6] = new SqlMetaData(GridFieldType.UserCode1 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[7] = new SqlMetaData(GridFieldType.UserCode2 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[8] = new SqlMetaData(GridFieldType.UserCode3 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[9] = new SqlMetaData(GridFieldType.UserCode4 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[10] = new SqlMetaData(GridFieldType.UserCode5 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[11] = new SqlMetaData(GridFieldType.UserCode6 + "ID", SqlDbType.NVarChar, 50);

            sqlMetaDatas[12] = new SqlMetaData("Quantity", SqlDbType.Int);
            sqlMetaDatas[13] = new SqlMetaData("EnabledIndicator", SqlDbType.Bit);
            sqlMetaDatas[14] = new SqlMetaData("Sequence", SqlDbType.Int);
            sqlMetaDatas[15] = new SqlMetaData("TempDisabledIndicator", SqlDbType.Bit);

            //var sequence = gridTemplateLines.Count;
            foreach (var gridLine in gridTemplateLines)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);
                dataRecord.SetString(0, gridLine.ID);
                dataRecord.SetDBNull(1);

                if (!string.IsNullOrEmpty(gridLine.AgencyCodeID))
                    dataRecord.SetString(2, gridLine.AgencyCodeID);
                else
                {
                    dataRecord.SetDBNull(2);
                }

                if (!string.IsNullOrEmpty(gridLine.ItemTypeID))
                    dataRecord.SetString(3, gridLine.ItemTypeID);
                else
                {
                    dataRecord.SetDBNull(3);
                }

                if (!string.IsNullOrEmpty(gridLine.CollectionID))
                    dataRecord.SetString(4, gridLine.CollectionID);
                else
                {
                    dataRecord.SetDBNull(4);
                }
                
                if (!string.IsNullOrEmpty(gridLine.CallNumberText))
                    dataRecord.SetString(5, gridLine.CallNumberText);
                else
                {
                    dataRecord.SetDBNull(5);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode1ID))
                    dataRecord.SetString(6, gridLine.UserCode1ID);
                else
                {
                    dataRecord.SetDBNull(6);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode2ID))
                    dataRecord.SetString(7, gridLine.UserCode2ID);
                else
                {
                    dataRecord.SetDBNull(7);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode3ID))
                    dataRecord.SetString(8, gridLine.UserCode3ID);
                else
                {
                    dataRecord.SetDBNull(8);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode4ID))
                    dataRecord.SetString(9, gridLine.UserCode4ID);
                else
                {
                    dataRecord.SetDBNull(9);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode5ID))
                    dataRecord.SetString(10, gridLine.UserCode5ID);
                else
                {
                    dataRecord.SetDBNull(10);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode6ID))
                    dataRecord.SetString(11, gridLine.UserCode6ID);
                else
                {
                    dataRecord.SetDBNull(11);
                }

                dataRecord.SetInt32(12, gridLine.Qty);
                dataRecord.SetBoolean(13, true);
                dataRecord.SetInt32(14, gridLine.Sequence);
                dataRecord.SetBoolean(15, gridLine.IsTempDisabled);
                dataRecords.Add(dataRecord);
                //sequence--;
            }
            return dataRecords;
        }

        public static List<SqlDataRecord> ConvertGridLinesToDataSetNew(List<CommonGridTemplateLine> gridLines)
        {
            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[14];
            sqlMetaDatas[0] = new SqlMetaData(GridFieldType.AgencyCode + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData(GridFieldType.ItemType + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData(GridFieldType.Collection + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[3] = new SqlMetaData(GridFieldType.UserCode1 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[4] = new SqlMetaData(GridFieldType.UserCode2 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[5] = new SqlMetaData(GridFieldType.UserCode3 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[6] = new SqlMetaData(GridFieldType.UserCode4 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[7] = new SqlMetaData(GridFieldType.UserCode5 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[8] = new SqlMetaData(GridFieldType.UserCode6 + "ID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[9] = new SqlMetaData(GridFieldType.CallNumber + "Text", SqlDbType.VarChar, 26);
            sqlMetaDatas[10] = new SqlMetaData("Quantity", SqlDbType.Int);
            sqlMetaDatas[11] = new SqlMetaData("Sequence", SqlDbType.Int);
            sqlMetaDatas[12] = new SqlMetaData("EnabledIndicator", SqlDbType.Bit);
            sqlMetaDatas[13] = new SqlMetaData("CreatedBy", SqlDbType.VarChar, 50);

            foreach (var gridLine in gridLines)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);
                if (!string.IsNullOrEmpty(gridLine.AgencyCodeID))
                    dataRecord.SetString(0, gridLine.AgencyCodeID);
                else
                {
                    dataRecord.SetDBNull(0);
                }

                if (!string.IsNullOrEmpty(gridLine.ItemTypeID))
                    dataRecord.SetString(1, gridLine.ItemTypeID);
                else
                {
                    dataRecord.SetDBNull(1);
                }

                if (!string.IsNullOrEmpty(gridLine.CollectionID))
                    dataRecord.SetString(2, gridLine.CollectionID);
                else
                {
                    dataRecord.SetDBNull(2);
                }
                
                if (!string.IsNullOrEmpty(gridLine.UserCode1ID))
                    dataRecord.SetString(3, gridLine.UserCode1ID);
                else
                {
                    dataRecord.SetDBNull(3);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode2ID))
                    dataRecord.SetString(4, gridLine.UserCode2ID);
                else
                {
                    dataRecord.SetDBNull(4);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode3ID))
                    dataRecord.SetString(5, gridLine.UserCode3ID);
                else
                {
                    dataRecord.SetDBNull(5);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode4ID))
                    dataRecord.SetString(6, gridLine.UserCode4ID);
                else
                {
                    dataRecord.SetDBNull(6);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode5ID))
                    dataRecord.SetString(7, gridLine.UserCode5ID);
                else
                {
                    dataRecord.SetDBNull(7);
                }

                if (!string.IsNullOrEmpty(gridLine.UserCode6ID))
                    dataRecord.SetString(8, gridLine.UserCode6ID);
                else
                {
                    dataRecord.SetDBNull(8);
                }

                if (!string.IsNullOrEmpty(gridLine.CallNumberText))
                    dataRecord.SetString(9, gridLine.CallNumberText);
                else
                {
                    dataRecord.SetDBNull(9);
                }

                dataRecord.SetInt32(10, gridLine.Qty);
                dataRecord.SetInt32(11, gridLine.Sequence);
                dataRecord.SetBoolean(12, true);
                dataRecord.SetString(13, SiteContext.Current.UserId);

                dataRecords.Add(dataRecord);
            }
            return dataRecords;
        }

        public static List<SqlDataRecord> ConverUserIDsToDataSet(List<string> userIds)
        {
            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData("GUID", SqlDbType.NVarChar, 50);
            foreach (string userId in userIds)
            {
                if (!string.IsNullOrEmpty(userId))
                {
                    var record = new SqlDataRecord(sqlMetaDatas);
                    record.SetString(0, userId);
                    dataRecords.Add(record);
                }
            }
            return dataRecords;
        }

        public static List<SqlDataRecord> ConvertGuidsToDataSet(List<string> guids)
        {
            if (guids == null || guids.Count == 0)
                return null;

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData("GUID", SqlDbType.NVarChar, 50);
            foreach (string guid in guids)
            {
                if (!string.IsNullOrEmpty(guid))
                {
                    var record = new SqlDataRecord(sqlMetaDatas);
                    record.SetString(0, guid);
                    dataRecords.Add(record);
                }
            }
            return dataRecords;
        }

        public static List<SqlDataRecord> GetUtblCartUserGroupMemberDataRecords(CartUserGroupMemberList listMember)
        {
            if (listMember == null || listMember.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[7];

            //Generating collumns metadata
            sqlMetaDatas[0] = new SqlMetaData("BasketUserGroupMemberId", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("UserId", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData("HasContribution", SqlDbType.Bit);
            sqlMetaDatas[3] = new SqlMetaData("HasRequisition", SqlDbType.Bit);
            sqlMetaDatas[4] = new SqlMetaData("HasReview", SqlDbType.Bit);
            sqlMetaDatas[5] = new SqlMetaData("HasAcquisition", SqlDbType.Bit);
            sqlMetaDatas[6] = new SqlMetaData("IsOwner", SqlDbType.Bit);

            //Binding rows
            foreach (var member in listMember)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);
                if (!string.IsNullOrEmpty(member.CartUserGroupMemberId))
                {
                    dataRecord.SetString(0, member.CartUserGroupMemberId);
                }
                else
                {
                    dataRecord.SetDBNull(0);
                }

                if (!string.IsNullOrEmpty(member.UserId))
                {
                    dataRecord.SetString(1, member.UserId);
                }
                else
                {
                    dataRecord.SetDBNull(1);
                }

                dataRecord.SetBoolean(2, member.HasContribution);
                dataRecord.SetBoolean(3, member.HasRequisition);
                dataRecord.SetBoolean(4, member.HasReview);
                dataRecord.SetBoolean(5, member.HasAcquisition);
                dataRecord.SetBoolean(6, member.IsOwner);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        public static List<SqlDataRecord> GetUtblSharedCartMemberWorkflowStage(SharedCartMemberWorkflowStageList listWorkflowStage)
        {
            if (listWorkflowStage == null || listWorkflowStage.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[3];

            //Generating collumns metadata
            sqlMetaDatas[0] = new SqlMetaData("BasketUserID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("WorkflowStageID", SqlDbType.Int);
            sqlMetaDatas[2] = new SqlMetaData("CompletionDateTime", SqlDbType.DateTime);

            //Binding rows
            foreach (var member in listWorkflowStage)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);
                if (!string.IsNullOrEmpty(member.SharedCartMemberId))
                {
                    dataRecord.SetString(0, member.SharedCartMemberId);
                }
                else
                {
                    dataRecord.SetDBNull(0);
                }

                dataRecord.SetInt32(1, (int)member.Stage);

                if (member.CompletionDateTime.HasValue)
                {
                    dataRecord.SetDateTime(2, member.CompletionDateTime.Value);
                }
                else
                {
                    dataRecord.SetDBNull(2);
                }
                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        public static List<SqlDataRecord> GetUtblSharedCartWorkflowStage(SharedCartWorkflowStageList listWorkflowStage)
        {
            if (listWorkflowStage == null || listWorkflowStage.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[5];

            //Generating collumns metadata
            sqlMetaDatas[0] = new SqlMetaData("Stage", SqlDbType.Int);
            sqlMetaDatas[1] = new SqlMetaData("CompletionDate", SqlDbType.DateTime);
            sqlMetaDatas[2] = new SqlMetaData("EndDateTime", SqlDbType.DateTime);
            sqlMetaDatas[3] = new SqlMetaData("Status", SqlDbType.Int);
            sqlMetaDatas[4] = new SqlMetaData("StageAlias", SqlDbType.NVarChar, 50);

            //Binding rows
            foreach (var workflowStage in listWorkflowStage)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetInt32(0, (int)workflowStage.Stage);

                if (workflowStage.CompletionDate.HasValue)
                {
                    dataRecord.SetDateTime(1, workflowStage.CompletionDate.Value);
                }
                else
                {
                    dataRecord.SetDBNull(1);
                }

                if (workflowStage.EndDateTime.HasValue)
                {
                    dataRecord.SetDateTime(2, workflowStage.EndDateTime.Value);
                }
                else
                {
                    dataRecord.SetDBNull(2);
                }

                dataRecord.SetInt32(3, (int)workflowStage.Status);

                if (!string.IsNullOrEmpty(workflowStage.StageAlias))
                {
                    dataRecord.SetString(4, workflowStage.StageAlias);
                }
                else
                {
                    dataRecord.SetDBNull(4);
                }

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        public static List<SqlDataRecord> GetUtblSharedCartUserGroupWorkflowStage(CartUserGroupMember cartUserGroupMember)
        {
            //If the user has owner priveledge, he will have all other priveledge as default
            if (cartUserGroupMember.IsOwner)
            {
                cartUserGroupMember.HasAcquisition = true;
                cartUserGroupMember.HasContribution = true;
                cartUserGroupMember.HasRequisition = true;
                cartUserGroupMember.HasReview = true;
            }
            var sqlMetadata = new SqlMetaData("WorkflowStageID", SqlDbType.Int);
            var sqlDataRecords = new List<SqlDataRecord>();
            if (cartUserGroupMember.HasContribution)
            {
                var sqlDataRecord = new SqlDataRecord(sqlMetadata);
                sqlDataRecord.SetInt32(0, (int)WorkflowStage.Contribution);
                sqlDataRecords.Add(sqlDataRecord);
            }
            if (cartUserGroupMember.HasAcquisition)
            {
                var sqlDataRecord = new SqlDataRecord(sqlMetadata);
                sqlDataRecord.SetInt32(0, (int)WorkflowStage.Acquisition);
                sqlDataRecords.Add(sqlDataRecord);
            }
            if (cartUserGroupMember.HasRequisition)
            {
                var sqlDataRecord = new SqlDataRecord(sqlMetadata);
                sqlDataRecord.SetInt32(0, (int)WorkflowStage.Requisition);
                sqlDataRecords.Add(sqlDataRecord);
            }
            if (cartUserGroupMember.HasReview)
            {
                var sqlDataRecord = new SqlDataRecord(sqlMetadata);
                sqlDataRecord.SetInt32(0, (int)WorkflowStage.Review);
                sqlDataRecords.Add(sqlDataRecord);
            }
            return sqlDataRecords;
        }

        public static List<SqlDataRecord> GetUtblUserGridTemplates(List<UserGridTemplate> userGridTemplates)
        {
            if (userGridTemplates == null || userGridTemplates.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[6];

            //Generating collumns metadata
            sqlMetaDatas[0] = new SqlMetaData("GridTemplateID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("UserGridTemplateID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData("u_user_id", SqlDbType.NVarChar, 50);
            sqlMetaDatas[3] = new SqlMetaData("IsAssigned", SqlDbType.Bit);
            sqlMetaDatas[4] = new SqlMetaData("Sequence", SqlDbType.Int);
            sqlMetaDatas[5] = new SqlMetaData("RowExpansionRight", SqlDbType.NVarChar, 10);

            //Binding rows
            foreach (var member in userGridTemplates)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetString(0, member.GridTemplateId);


                dataRecord.SetString(1, member.Id);


                dataRecord.SetString(2, member.UserId);


                dataRecord.SetBoolean(3, member.IsAssigned);

                dataRecord.SetInt32(4, member.Sequence);

                dataRecord.SetString(5, member.RowExpensionRight);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        public static List<SqlDataRecord> GetUtblUiGridFields(List<CommonBaseGridUserControl.UIGridField> gridField)
        {
            if (gridField == null || gridField.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = DefineGridFieldTable();

            //Binding rows
            foreach (var field in gridField)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetString(0, field.ID);
                dataRecord.SetString(1, field.Name);
                dataRecord.SetBoolean(2, field.ActiveIndicator);
                dataRecord.SetInt32(3, field.SlipReportSequence);
                dataRecord.SetString(4, field.GridFieldType);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        private static SqlMetaData[] DefineGridFieldTable()
        {
            var sqlMetaDatas = new SqlMetaData[5];
            sqlMetaDatas[0] = new SqlMetaData("GridFieldID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("Name", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData("ActiveIndicator", SqlDbType.Bit);
            sqlMetaDatas[3] = new SqlMetaData("SlipReportSequence", SqlDbType.Int);
            sqlMetaDatas[4] = new SqlMetaData("GridFieldType", SqlDbType.VarChar, 20);
            return sqlMetaDatas;
        }

        public static List<SqlDataRecord> GetUtblGridCodes(List<CommonBaseGridUserControl.UIGridCode> gridCode)
        {
            if (gridCode == null || gridCode.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = DefineGridCodeTableStructure();

            //Binding rows
            foreach (var code in gridCode)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetString(0, code.GridFieldID);
                dataRecord.SetString(1, code.ID);
                dataRecord.SetString(2, code.Code);
                dataRecord.SetString(3, string.IsNullOrEmpty(code.Literal) ? "" : code.Literal);

                if (code.EffectiveDate.HasValue)
                {
                    dataRecord.SetDateTime(4, code.EffectiveDate.Value);
                }
                else
                {
                    dataRecord.SetDBNull(4);
                }

                if (code.ExpirationDate.HasValue)
                {
                    dataRecord.SetDateTime(5, code.ExpirationDate.Value);
                }
                else
                {
                    dataRecord.SetDBNull(5);
                }
                dataRecord.SetBoolean(6, !code.Disable);
                dataRecord.SetInt32(7, code.Sequence);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        public static List<SqlDataRecord> GetUtblGridCodesUserIdsForSaving(List<CommonBaseGridUserControl.UIGridCode> gridCode)
        {
            if (gridCode == null || gridCode.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = DefineGridCodeTableStructure();

            //Binding rows
            foreach (var code in gridCode)
            {
                var userIds = code.UserIDs;
                if (string.IsNullOrEmpty(userIds))
                {
                    var deleteRecord = new SqlDataRecord(sqlMetaDatas);
                    deleteRecord.SetString(0, "NOUSER");
                    deleteRecord.SetString(1, code.ID);

                    deleteRecord.SetDBNull(2);
                    deleteRecord.SetDBNull(3);
                    deleteRecord.SetDBNull(4);
                    deleteRecord.SetDBNull(5);
                    deleteRecord.SetDBNull(6);
                    deleteRecord.SetDBNull(7);

                    dataRecords.Add(deleteRecord);
                    continue;
                }

                var arrUsers = userIds.Split(';');
                if (arrUsers.Length <= 0) continue;

                foreach (var userId in arrUsers)
                {
                    if(string.IsNullOrEmpty(userId))
                        continue;
                    var dataRecord = new SqlDataRecord(sqlMetaDatas);

                    dataRecord.SetString(0, userId.Trim());
                    dataRecord.SetString(1, code.ID);

                    dataRecord.SetDBNull(2);
                    dataRecord.SetDBNull(3);
                    dataRecord.SetDBNull(4);
                    dataRecord.SetDBNull(5);
                    dataRecord.SetDBNull(6);
                    dataRecord.SetDBNull(7);

                    dataRecords.Add(dataRecord);
                }
            }

            return dataRecords.Count == 0 ? null : dataRecords;
        }

        private static SqlMetaData[] DefineGridCodeTableStructure()
        {
            var sqlMetaDatas = new SqlMetaData[8];
            sqlMetaDatas[0] = new SqlMetaData("GridFieldID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("GridCodeID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData("Code", SqlDbType.NVarChar, 50);
            sqlMetaDatas[3] = new SqlMetaData("Literal", SqlDbType.VarChar, 255);
            sqlMetaDatas[4] = new SqlMetaData("EffectiveDate", SqlDbType.DateTime);
            sqlMetaDatas[5] = new SqlMetaData("ExpirationDate", SqlDbType.DateTime);
            sqlMetaDatas[6] = new SqlMetaData("ActiveIndicator", SqlDbType.Bit);
            sqlMetaDatas[7] = new SqlMetaData("Sequence", SqlDbType.Int);
            return sqlMetaDatas;
        }

        #region Private

        #endregion

        public static List<SqlDataRecord> ConvertUIUserGridFieldToDataSet(List<CommonBaseGridUserControl.UIUserGridField> userGridFieldObjects)
        {
            if (userGridFieldObjects == null || userGridFieldObjects.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[5];

            //Generating collumns metadata
            sqlMetaDatas[0] = new SqlMetaData("UserGridFieldID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("GridFieldID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[2] = new SqlMetaData("DisplayType", SqlDbType.VarChar, 7);
            sqlMetaDatas[3] = new SqlMetaData("DefaultGridCodeID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[4] = new SqlMetaData("DefaultGridText", SqlDbType.NVarChar, 26);

            //Binding rows
            foreach (var uiUserGridField in userGridFieldObjects)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetString(0, uiUserGridField.UserGridFieldID);
                dataRecord.SetString(1, uiUserGridField.GridFieldID);
                dataRecord.SetString(2, uiUserGridField.DisplayType);

                dataRecord.SetValue(3, 
                    !string.IsNullOrEmpty(uiUserGridField.DefaultGridCodeID)
                        ? uiUserGridField.DefaultGridCodeID
                        : (object) DBNull.Value);
                
                dataRecord.SetString(4, uiUserGridField.DefaultGridText);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }

        public static List<SqlDataRecord> ConvertGridTemplatesToDatatSet(List<CommonGridTemplate> gridTemplates)
        {
            if (gridTemplates == null || gridTemplates.Count == 0)
            {
                return null;
            }

            var dataRecords = new List<SqlDataRecord>();
            var sqlMetaDatas = new SqlMetaData[3];

            //Generating collumns metadata
            sqlMetaDatas[0] = new SqlMetaData("GridTemplateID", SqlDbType.NVarChar, 50);
            sqlMetaDatas[1] = new SqlMetaData("EnabledIndicator", SqlDbType.Bit);
            sqlMetaDatas[2] = new SqlMetaData("IsDefault", SqlDbType.Bit);

            //Binding rows
            foreach (var gridTemplate in gridTemplates)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetString(0, gridTemplate.GridTemplateId);
                dataRecord.SetBoolean(1, gridTemplate.EnabledIndicator);
                dataRecord.SetBoolean(2, gridTemplate.IsDefaultTemplate);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;
        }
    }

    public class Converter
    {
        public static SharedCartSummary ConvertToSharedCartSummary(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0) return null;

            var sharedCartSummary = new SharedCartSummary { Items = new SharedCartSummaryItemList() };

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var sharedCartSummaryItem = new SharedCartSummaryItem();
                sharedCartSummaryItem.UserId = DataAccessHelper.ConvertTo<string>(row, "UserId");
                sharedCartSummaryItem.LoginId = DataAccessHelper.ConvertTo<string>(row, "LoginUser");
                sharedCartSummaryItem.UserName = DataAccessHelper.ConvertTo<string>(row, "UserName");
                sharedCartSummaryItem.TotalTitles = DataAccessHelper.ConvertTo<int>(row, "TotalTitle");
                sharedCartSummaryItem.TotalTitlesWithoutGrid = DataAccessHelper.ConvertTo<int>(row, "TotalTitleWithoutGrid");
                sharedCartSummaryItem.TotalQuantity = DataAccessHelper.ConvertTo<int>(row, "TotalQuantity");
                sharedCartSummaryItem.TotalListPrice = DataAccessHelper.ConvertTo<decimal>(row, "TotalListPrice");
                sharedCartSummaryItem.TotalNetPrice = DataAccessHelper.ConvertTo<decimal>(row, "TotalNetPrice");
                sharedCartSummary.Items.Add(sharedCartSummaryItem);
            }
            return sharedCartSummary;
        }

        public static SharedCartSummaryItemDetailList ConvertToSharedCartSummaryDetail(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0) return null;

            var sharedCartSummaryDetails = new SharedCartSummaryItemDetailList();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var sharedCartSummaryItemDetail = new SharedCartSummaryItemDetail();
                sharedCartSummaryItemDetail.BTKey = DataAccessHelper.ConvertTo<string>(row, "BTKey");
                sharedCartSummaryItemDetail.LineItemID = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                sharedCartSummaryItemDetail.ISBN = DataAccessHelper.ConvertTo<string>(row, "ISBN");
                sharedCartSummaryItemDetail.Quantity = DataAccessHelper.ConvertTo<int>(row, "Quantity");
                sharedCartSummaryItemDetail.Title = DataAccessHelper.ConvertTo<string>(row, "Title");
                sharedCartSummaryDetails.Add(sharedCartSummaryItemDetail);
            }
            return sharedCartSummaryDetails;
        }

        public static IEnumerable<CartUserGroup> ConvertToListCartUserGroup(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0) return null;

            var cartUserGroups = new List<CartUserGroup>();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var cartUserGroup = new CartUserGroup();
                cartUserGroup.BeginDataLoading();
                cartUserGroup.Id = DataAccessHelper.ConvertTo<string>(row, "BasketUserGroupID");
                cartUserGroup.Name = DataAccessHelper.ConvertTo<string>(row, "BasketUserGroupName");
                cartUserGroup.EndDataLoading();
                cartUserGroups.Add(cartUserGroup);
            }
            return cartUserGroups;
        }

        public static IEnumerable<CartUserGroupMember> ConvertToListCartUserGroupMember(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count < 2) return null;

            var cartUserGroupMembers = new List<CartUserGroupMember>();

            foreach (DataRow row in dataSet.Tables[1].Rows)
            {
                var cartUserGroupMember = new CartUserGroupMember();
                cartUserGroupMember.BeginDataLoading();
                cartUserGroupMember.Id = DataAccessHelper.ConvertTo<string>(row, "BasketUserGroupMemberID");
                cartUserGroupMember.UserId = DataAccessHelper.ConvertTo<string>(row, "u_user_id");
                cartUserGroupMember.UserName = DataAccessHelper.ConvertTo<string>(row, "u_user_name");
                cartUserGroupMember.IsOwner = DataAccessHelper.ConvertTo<bool>(row, "OwnerRightIndicator");
                //if (!cartUserGroupMember.IsOwner)
                {
                    cartUserGroupMember.HasContribution = Parser.ToBool(row["Contribution"]);
                    cartUserGroupMember.HasRequisition = Parser.ToBool(row["Requisition"]);
                    cartUserGroupMember.HasReview = Parser.ToBool(row["Review"]);
                    cartUserGroupMember.HasAcquisition = Parser.ToBool(row["Acquisition"]);
                }
                cartUserGroupMembers.Add(cartUserGroupMember);
                cartUserGroupMember.EndDataLoading();
            }
            return cartUserGroupMembers;
        }

        public static IEnumerable<OrganizationWorkflowStage> ConvertToListOrganizationWorkflowStage(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0) return null;

            var organizationWorkflowStages = new List<OrganizationWorkflowStage>();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var organizationWorkflowStage = new OrganizationWorkflowStage();
                organizationWorkflowStage.Id = DataAccessHelper.ConvertTo<string>(row, "OrganizationWorkflowStageId");
                organizationWorkflowStage.Stage = Parser.ToWorkflowStageEnum(DataAccessHelper.ConvertTo<int>(row, "Stage"));
                organizationWorkflowStage.StageAlias = DataAccessHelper.ConvertTo<string>(row, "StageAlias");

                organizationWorkflowStages.Add(organizationWorkflowStage);
            }
            return organizationWorkflowStages;
        }

        public static IEnumerable<SharedCartMemberWorkflowStage> ConvertToListSharedCartMemberWorkflowStage(DataSet dataSet, string sharedCartMemberId = null)
        {
            if (dataSet == null || dataSet.Tables.Count == 0) return null;

            var sharedCartMemberWorkflowStages = new List<SharedCartMemberWorkflowStage>();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var sharedCartMemberWorkflowStage = new SharedCartMemberWorkflowStage();
                sharedCartMemberWorkflowStage.BeginDataLoading();
                sharedCartMemberWorkflowStage.Id = DataAccessHelper.ConvertTo<string>(row, "BasketUserWorkflowStageId");
                sharedCartMemberWorkflowStage.Stage =
                    Parser.ToWorkflowStageEnum(DataAccessHelper.ConvertToInt(row["Stages"]));
                sharedCartMemberWorkflowStage.StageFinished = DataAccessHelper.ConvertTo<bool>(row, "StageFinished");
                sharedCartMemberWorkflowStage.InternalSetIsCompleted(DataAccessHelper.ConvertTo<int>(row, "IsCompleted") == 1);
                if (row["CompletionDate"] == null || row["CompletionDate"] == DBNull.Value)
                {
                    sharedCartMemberWorkflowStage.CompletionDateTime = null;
                }
                else
                {
                    sharedCartMemberWorkflowStage.CompletionDateTime = DataAccessHelper.ConvertTo<DateTime>(row,
                                                                                                            "CompletionDate");
                }
                if (!string.IsNullOrEmpty(sharedCartMemberId))
                    sharedCartMemberWorkflowStage.SharedCartMemberId = sharedCartMemberId;
                else
                {
                    sharedCartMemberWorkflowStage.SharedCartMemberId = DataAccessHelper.ConvertTo<string>(row, "BasketUserId");
                }
                sharedCartMemberWorkflowStage.EndDataLoading();
                sharedCartMemberWorkflowStages.Add(sharedCartMemberWorkflowStage);
            }
            return sharedCartMemberWorkflowStages;
        }

        public static SharedCartWorkflow ConvertToSharedCartWorkflow(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0 || dataSet.Tables[0].Rows.Count != 1) return null;

            var sharedCartWorkflow = new SharedCartWorkflow();
            sharedCartWorkflow.BeginDataLoading();
            sharedCartWorkflow.Id = DataAccessHelper.ConvertTo<string>(dataSet.Tables[0].Rows[0], "BasketSummaryID");
            sharedCartWorkflow.TimeZone = DataAccessHelper.ConvertTo<string>(dataSet.Tables[0].Rows[0], "TimeZone");
            if (dataSet.Tables[0].Rows[0]["CompletionDateTime"] == DBNull.Value)
            {
                sharedCartWorkflow.CompletionDate = null;
            }
            else
            {
                sharedCartWorkflow.CompletionDate = DataAccessHelper.ConvertTo<DateTime>(dataSet.Tables[0].Rows[0], "CompletionDateTime");
            }
            sharedCartWorkflow.CurrentWorkflowStage =
                Parser.ToWorkflowStageEnum(DataAccessHelper.ConvertToInt(dataSet.Tables[0].Rows[0]["CurrentBasketWorkflowStage"]));
            sharedCartWorkflow.EndDataLoading();
            return sharedCartWorkflow;
        }

        public static IEnumerable<SharedCartWorkflowStage> ConvertToListSharedCartWorkflowStage(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0) return null;

            var sharedCartWorkflowStages = new List<SharedCartWorkflowStage>();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var sharedCartWorkflowStage = new SharedCartWorkflowStage();
                sharedCartWorkflowStage.BeginDataLoading();
                sharedCartWorkflowStage.Id = DataAccessHelper.ConvertTo<string>(row, "BasketWorkflowStageID");
                sharedCartWorkflowStage.Stage =
                    Parser.ToWorkflowStageEnum(DataAccessHelper.ConvertToInt(row["Stages"]));
                if (row["CompletionDateTime"] == DBNull.Value)
                {
                    sharedCartWorkflowStage.CompletionDate = null;
                }
                else
                {
                    sharedCartWorkflowStage.CompletionDate = DataAccessHelper.ConvertTo<DateTime>(row, "CompletionDateTime");
                }
                if (row["EndDateTime"] == DBNull.Value)
                {
                    sharedCartWorkflowStage.EndDateTime = null;
                }
                else
                {
                    sharedCartWorkflowStage.EndDateTime = DataAccessHelper.ConvertTo<DateTime>(row, "EndDateTime");
                }

                sharedCartWorkflowStage.Status =
                    Parser.ToWorkflowStatusEnum(DataAccessHelper.ConvertToInt(row["Status"]));
                sharedCartWorkflowStage.EndDataLoading();
                sharedCartWorkflowStages.Add(sharedCartWorkflowStage);
            }
            return sharedCartWorkflowStages;
        }

        public static string ConverToStringWorkflowStage(WorkflowStage stage)
        {
            switch (stage)
            {
                case WorkflowStage.Contribution:
                    return "Contribution";

                case WorkflowStage.Requisition:
                    return "Requisition";

                case WorkflowStage.Acquisition:
                    return "Acquisition";

                case WorkflowStage.Review:
                    return "Review";
            }
            return string.Empty;
        }

        public static string ConverToStringWorkflowStatus(WorkflowStatus status)
        {
            switch (status)
            {
                case WorkflowStatus.InProgress:
                    return "InProgress";
                case WorkflowStatus.Completed:
                    return "Completed";
                case WorkflowStatus.NotStarted:
                    return "Not Started";
            }
            return null;
        }
    }
}
