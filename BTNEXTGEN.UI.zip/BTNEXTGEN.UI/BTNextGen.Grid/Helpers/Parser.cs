﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextgen.Grid.Cart.Shared;

namespace BTNextGen.Grid.Helpers
{
    public static class Parser
    {
        public static bool ToBool(object value)
        {
            var resultString = value.ToString();
            switch (resultString)
            {
                case "1":
                    resultString = "True";
                    break;
                case "0":
                    resultString = "False";
                    break;
            }

            bool result;
            return bool.TryParse(resultString, out result) && result;
        }

        public static WorkflowStage ToWorkflowStageEnum(int value)
        {
            switch (value)
            {
                case (int)WorkflowStage.Contribution:
                    return WorkflowStage.Contribution;
                case (int)WorkflowStage.Requisition:
                    return WorkflowStage.Requisition;
                case (int)WorkflowStage.Review:
                    return WorkflowStage.Review;
                default:
                    return WorkflowStage.Acquisition;
            }
        }

        public static WorkflowStatus ToWorkflowStatusEnum(int value)
        {
            switch (value)
            {
                case (int)WorkflowStatus.InProgress:
                    return WorkflowStatus.InProgress;
                case (int)WorkflowStatus.NotStarted:
                    return WorkflowStatus.NotStarted;
                case (int)WorkflowStatus.Completed:
                    return WorkflowStatus.Completed;
                default:
                    return WorkflowStatus.Missing;
            }
        }
         public static FieldCodeStatus ToFieldCodeStatus(int value)
         {
             switch (value)
             {
                 case 0:return FieldCodeStatus.Usable;
                 case 1:return FieldCodeStatus.Disabled;
                 case 2:return FieldCodeStatus.Expired;
                 case 3:return FieldCodeStatus.FutureDate;
                 default:return FieldCodeStatus.Usable;
             }
         }
    }
}
