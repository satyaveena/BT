﻿using System.Linq;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart.Shared;

namespace BTNextgen.Grid.Helpers
{
    public static class WorkflowHelper
    {
        public static bool HasPermissionInStage(WorkflowStage sharedCartMemberWorkflowStage, SharedCartMember currentSharedCartMember)
        {
            if (currentSharedCartMember != null && currentSharedCartMember.HasOwner)
            {
                return true;
            }

            if (currentSharedCartMember != null && currentSharedCartMember.SharedCartProfile != null)
            {
                switch (sharedCartMemberWorkflowStage)
                {
                    case WorkflowStage.Contribution:
                        if (currentSharedCartMember.HasContribution)
                        {
                            var stage = currentSharedCartMember.SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Contribution);
                            if (stage != null)
                            {
                                return stage.IsValidTimeToUpdate();
                            }
                        }
                        break;
                    case WorkflowStage.Requisition:
                        if (currentSharedCartMember.HasRequisition)
                        {
                            var stage = currentSharedCartMember.SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Requisition);
                            if (stage != null)
                            {
                                return stage.IsValidTimeToUpdate();
                            }
                        }
                        break;
                    case WorkflowStage.Review:
                        if (currentSharedCartMember.HasReview)
                        {
                            var stage = currentSharedCartMember.SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Review);
                            if (stage != null)
                            {
                                return stage.IsValidTimeToUpdate();
                            }
                        }
                        break;
                    case WorkflowStage.Acquisition:
                        if (currentSharedCartMember.HasAcquisition)
                        {
                            var stage = currentSharedCartMember.SharedCartProfile.GetWorkflowStageObject(WorkflowStage.Acquisition);
                            if (stage != null)
                            {
                                return stage.IsValidTimeToUpdate();
                            }
                        }
                        break;
                }
            }

            return false;
        }

        public static bool HasOwner(string cartId, string orgId, string userId)
        {
            var cartGridManager = CartGridContext.Current.CartGridManager;
            try
            {
                CartGridContext.Current.Impersonate(orgId, userId);

                var shareCartProfile = cartGridManager.GetSharedCartProfile(cartId);
                if (shareCartProfile != null)
                {
                    var shareCartMember = shareCartProfile.GetCurrentSharedCartMember();
                    if (shareCartMember != null)
                    {
                        return shareCartMember.HasOwner;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
            }
            finally
            {
                CartGridContext.Current.UndoImpersonate();
            }
        }
    }
}
