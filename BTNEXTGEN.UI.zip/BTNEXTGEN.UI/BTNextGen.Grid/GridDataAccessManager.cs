﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.Exception;
using BTNextGen.Grid.Helpers;
using BTNextGen.Grid.DataAccess;
using BTNextGen.VelocityCaching;
using Microsoft.SqlServer.Server;

namespace BTNextgen.Grid
{
    public class GridDataAccessManager : DataAccessManager
    {
        private GridDAOManager _gridDaoManager;
        private static readonly VelocityCacheLevel CacheLevel = GridCacheConstants.CommonGridCacheLevel;

        protected override DAOManager GetDAOManager()
        {
            _gridDaoManager = new GridDAOManager();
            return _gridDaoManager;
        }

        # region PE methods

        //public GridFieldList GetAllGridFields(bool isGetInUseInfo = true)
        //{
        //    GridFieldList list = null;
        //    try
        //    {
        //        //read from cache
        //        var cacheKey = string.Format("GridDataAccessManager.GetAllUserGridFields()_{0}", _gridDaoManager.OrganizationId);
        //        var dsFromCache = VelocityCacheManager.Read(cacheKey);
        //        if (dsFromCache != null) return GetGridFieldsFromDataSet(dsFromCache as DataSet, isGetInUseInfo);

        //        //not exist in cache
        //        DataSet ds = _gridDaoManager.GetAllGridFields(isGetInUseInfo);
        //        list = GetGridFieldsFromDataSet(ds, isGetInUseInfo);

        //        //store data set to cache, expiration per request
        //        VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogException(ex);
        //        throw new CartGridLoadFailedException(ex.Message);
        //    }
        //    return list;
        //}

        public UserGridFieldList GetAllUserGridFields(string gridFieldId, bool isGetInUseInfo = true)
        {
            UserGridFieldList list = null;
            try
            {
                //read from cache
                var cacheKey = string.Format("GridDataAccessManager.GetAllUserGridFields()_{0}", _gridDaoManager.OrganizationId);
                var dsFromCache = VelocityCacheManager.Read(cacheKey);
                if (dsFromCache != null) return FilterUserGridFieldsFromDataSet(dsFromCache as DataSet, gridFieldId);

                //not exist in cache
                DataSet ds = _gridDaoManager.GetAllGridFields(isGetInUseInfo);
                list = FilterUserGridFieldsFromDataSet(ds, gridFieldId);

                //store data set to cache, expiration per request
                VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        private UserGridFieldList FilterUserGridFieldsFromDataSet(DataSet ds, string gridFieldId)
        {
            if (ds == null || ds.Tables.Count <= 1 || ds.Tables[1].Rows == null)
            {
                return null;
            }
            var list = new UserGridFieldList();
            foreach (DataRow row in ds.Tables[1].Rows)
            {
                if (DataAccessHelper.ConvertToString(row["GridFieldID"]) != gridFieldId)
                    continue;

                var gridField = new UserGridField();
                gridField.BeginDataLoading();
                gridField.Id = DataAccessHelper.ConvertToString(row["UserGridFieldID"]);
                gridField.UserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
                gridField.GridFieldId = DataAccessHelper.ConvertToString(row["GridFieldID"]);
                gridField.DisplayType = DataAccessHelper.ConvertToString(row["DisplayType"]);
                gridField.DefaultGridCodeId = DataAccessHelper.ConvertToString(row["DefaultGridCodeID"]);
                gridField.DefaultGridText = DataAccessHelper.ConvertToString(row["DefaultGridText"]);
                gridField.UserLoginName = DataAccessHelper.ConvertToString(row["username"]);
                gridField.UserDisplayName = DataAccessHelper.ConvertToString(row["display_name"]);
                gridField.EndDataLoading();
                list.Add(gridField);
            }
            return list;
        }

        public GridCodeList GetAllGridCodes(string gridFieldId, bool getAllIndicator = false, bool isGetInUseInfo = true, bool isNoCache = false)
        {
            GridCodeList list = null;
            try
            {
                //read from cache
                var cacheKey = string.Format("GridDataAccessManager.GetAllUserGridCodes()_{0}_{1}_{2}", _gridDaoManager.UserId,
                                             gridFieldId, getAllIndicator.ToString());
                var dsFromCache = VelocityCacheManager.Read(cacheKey);

                if (dsFromCache != null && !isNoCache)
                {
                    return GetGridCodesFromDataSet(dsFromCache as DataSet, isGetInUseInfo);
                }

                //not exist in cache
                DataSet ds = _gridDaoManager.GetAllUserGridCodes(gridFieldId, getAllIndicator, isGetInUseInfo);
                list = GetGridCodesFromDataSet(ds, isGetInUseInfo);

                //store data set to cache, expiration per request
                VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;

        }

        public UserGridCodeList GetAllUserGridCodes(string gridFieldId, string gridCodeId, bool getAllIndicator = true, bool isGetInUseInfo = true, string nocache = "false")
        {
            UserGridCodeList list = null;
            try
            {
                var isnocacheuser = Convert.ToBoolean(nocache);
                //read from cache
                var cacheKey = string.Format("GridDataAccessManager.GetAllUserGridCodes()_{0}_{1}_{2}", _gridDaoManager.UserId,
                                            gridFieldId, getAllIndicator.ToString());
                var dsFromCache = VelocityCacheManager.Read(cacheKey);
                if (dsFromCache != null && !isnocacheuser)
                {
                    return FilterAllUserGridCodesFromDataSet(dsFromCache as DataSet, gridCodeId);
                }

                //not exist in cache
                DataSet ds = _gridDaoManager.GetAllUserGridCodes(gridFieldId, getAllIndicator, isGetInUseInfo);
                list = FilterAllUserGridCodesFromDataSet(ds, gridCodeId);

                //store data set to cache, expiration per request
                VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        private UserGridCodeList FilterAllUserGridCodesFromDataSet(DataSet ds, string gridCodeId)
        {
            if (ds == null || ds.Tables.Count <= 1 || ds.Tables[1].Rows == null)
            {
                return null;
            }
            var list = new UserGridCodeList();
            foreach (DataRow row in ds.Tables[1].Rows)
            {
                if (DataAccessHelper.ConvertToString(row["GridCodeID"]) != gridCodeId)
                    continue;

                var code = new UserGridCode();
                code.BeginDataLoading();
                code.Id = DataAccessHelper.ConvertToString(row["UserGridCodeID"]);
                code.GridCodeId = DataAccessHelper.ConvertToString(row["GridCodeID"]);
                code.UserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
                code.UserDisplayName = DataAccessHelper.ConvertToString(row["display_name"]);
                code.UserLoginName = DataAccessHelper.ConvertToString(row["username"]);
                code.EndDataLoading();
                list.Add(code);
            }
            return list;
        }
        # endregion

        public GridFieldList GetAllGridFieldWithAuthorizedCodeForUser()
        {
            GridFieldList result = null;
            try
            {
                var startTime = DateTime.Now;
                Logger.Write("New Grid Redesign", string.Format("_gridDaoManager.GetGridFieldsWithAuthorizedCodeForUser: {0}", startTime), false);
                DataSet ds = _gridDaoManager.GetGridFieldsWithAuthorizedCodeForUser();
                Logger.Write("New Grid Redesign", string.Format("Timing: {0}", DateTime.Now.Subtract(startTime).TotalMilliseconds), false);

                startTime = DateTime.Now;
                Logger.Write("New Grid Redesign", string.Format("GetAllGridFieldGridCodeFromDataSet: {0}", startTime), false);
                result = GetAllGridFieldGridCodeFromDataSet(ds);
                Logger.Write("New Grid Redesign", string.Format("Timing: {0}", DateTime.Now.Subtract(startTime).TotalMilliseconds), false);

            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
            return result;
        }

        public string CreateGridField(GridField gridField)
        {
            string gridFieldId = string.Empty;
            try
            {
                _gridDaoManager.UpdateGridField(gridField.GridFieldId, gridField.SOPGridFieldId, gridField.Name,
                                                gridField.FreeTextIndicator, gridField.FreeTextCharacterLimit,
                                                gridField.Sequence, gridField.LockedIndicator, gridField.ActiveIndicator,
                                                gridField.UserViewAllGridCodesIndicator, gridField.ValidateIndicator,
                                                gridField.SlipReportSequence);
                ClearCacheGridFields();
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
            return gridFieldId;

        }

        public void UpdateGridField(GridField gridField)
        {
            try
            {
                _gridDaoManager.UpdateGridField(gridField.GridFieldId, gridField.SOPGridFieldId, gridField.Name,
                                                gridField.FreeTextIndicator, gridField.FreeTextCharacterLimit,
                                                gridField.Sequence, gridField.LockedIndicator, gridField.ActiveIndicator,
                                                gridField.UserViewAllGridCodesIndicator, gridField.ValidateIndicator,
                                                gridField.SlipReportSequence);
                ClearCacheGridFields();
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteGridField(string gridFieldId)
        {
            try
            {
                _gridDaoManager.DeleteGridField(gridFieldId);
                ClearCacheGridFields();
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }

        }

        public UserGridFieldList GetUserGridFields(string gridFieldId)
        {
            UserGridFieldList list = null;
            try
            {
                //read from cache
                var cacheKey = string.Format("GridDataAccessManager.GetUserGridFields()_{0}", gridFieldId);
                var dsFromCache = VelocityCacheManager.Read(cacheKey);
                if (dsFromCache != null) return GetUserGridFieldsFromDataSet(dsFromCache as DataSet);

                //not exist in cache
                DataSet ds = _gridDaoManager.GetUserGridFields(gridFieldId);
                list = GetUserGridFieldsFromDataSet(ds);

                //store data set to cache, expiration per request
                VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        public string CreateUserGridField(UserGridField userGridField)
        {

            string userGridFieldId = string.Empty;
            try
            {
                _gridDaoManager.UpdateUserGridField(userGridField.UserGridFieldId, userGridField.GridFieldId,
                                                    userGridField.UserId, userGridField.DisplayType,
                                                    userGridField.DefaultGridCodeId, userGridField.DefaultGridText);
                ClearCacheUserGridFields(userGridField.GridFieldId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
            return userGridFieldId;

        }

        public void UpdateUserGridField(UserGridField userGridField)
        {
            try
            {
                _gridDaoManager.UpdateUserGridField(userGridField.UserGridFieldId, userGridField.GridFieldId,
                                                    userGridField.UserId, userGridField.DisplayType,
                                                    userGridField.DefaultGridCodeId, userGridField.DefaultGridText);
                ClearCacheUserGridFields(userGridField.GridFieldId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteUserGridField(UserGridField userGridField)
        {
            try
            {
                _gridDaoManager.DeleteUserGridField(userGridField.UserGridFieldId);
                ClearCacheUserGridFields(userGridField.GridFieldId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public GridCodeList GetGridCodes(string gridFieldId, bool getAllIndicator = false, bool isGetInUseInfo = true)
        {
            GridCodeList list = null;
            try
            {
                //read from cache
                var cacheKey = string.Format("GridDataAccessManager.GetGridCodes()_{0}_{1}_{2}", _gridDaoManager.UserId,
                                             gridFieldId, getAllIndicator.ToString());
                var dsFromCache = VelocityCacheManager.Read(cacheKey);
                if (dsFromCache != null) return GetGridCodesFromDataSet(dsFromCache as DataSet, isGetInUseInfo);

                //not exist in cache
                DataSet ds = _gridDaoManager.GetGridCodes(gridFieldId, getAllIndicator, isGetInUseInfo);
                list = GetGridCodesFromDataSet(ds, isGetInUseInfo);

                //store data set to cache, expiration per request
                VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;

        }

        public void CreateGridCode(GridCode gridCode)
        {
            try
            {
                _gridDaoManager.UpdateGridCode(gridCode.GridCodeId, gridCode.GridFieldId, gridCode.Code,
                                               gridCode.Literal, gridCode.EffectiveDate, gridCode.ExpirationDate,
                                               gridCode.ActiveIndicator, gridCode.Sequence);
                ClearCacheGridCodes(gridCode.GridFieldId);
                ClearCacheGridCodes(gridCode.GridFieldId, true);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void UpdateGridCode(GridCode gridCode)
        {
            try
            {
                _gridDaoManager.UpdateGridCode(gridCode.GridCodeId, gridCode.GridFieldId, gridCode.Code,
                                               gridCode.Literal, gridCode.EffectiveDate, gridCode.ExpirationDate,
                                               gridCode.ActiveIndicator, gridCode.Sequence);
                ClearCacheGridCodes(gridCode.GridFieldId);
                ClearCacheGridCodes(gridCode.GridFieldId, true);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteGridCode(GridCode gridCode)
        {
            try
            {
                _gridDaoManager.DeleteGridCode(gridCode.GridCodeId);
                ClearCacheGridCodes(gridCode.GridFieldId);
                ClearCacheGridCodes(gridCode.GridFieldId, true);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public string CreateUserGridCode(UserGridCode userGridCode)
        {
            string userGridCodeID = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(userGridCode.GridCodeId))
                    throw new Exception("Grid Code ID cannot be null");
                _gridDaoManager.UpdateUserGridCode(userGridCode.UserGridCodeId, userGridCode.GridCodeId,
                                                   userGridCode.UserId);
                ClearCacheUserGridCodes(userGridCode.GridCodeId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
            return userGridCodeID;

        }

        public void UpdateUserGridCode(UserGridCode userGridCode)
        {
            try
            {
                if (string.IsNullOrEmpty(userGridCode.GridCodeId))
                    throw new Exception("Grid Code ID cannot be null");
                _gridDaoManager.UpdateUserGridCode(userGridCode.UserGridCodeId, userGridCode.GridCodeId,
                                                   userGridCode.UserId);
                ClearCacheUserGridCodes(userGridCode.GridCodeId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteUserGridCode(UserGridCode userGridCode)
        {
            try
            {
                _gridDaoManager.DeleteUserGridCode(userGridCode.UserGridCodeId);
                ClearCacheUserGridCodes(userGridCode.GridCodeId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        #region GridTemplate

        public GridTemplateList GetGridTemplates()
        {
            GridTemplateList gridTemplateList = null;
            try
            {
                DataSet ds = _gridDaoManager.GetGridTemplates();
                gridTemplateList = GetGridTemplatesFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }

            return gridTemplateList;

        }

        public GridTemplate GetGridTemplate(string gridTemplateId)
        {
            GridTemplate gridTemplate = null;
            try
            {
                DataSet ds = _gridDaoManager.GetGridTemplate(gridTemplateId);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    gridTemplate = GetGridTemplateFromDataRow(ds.Tables[0].Rows[0]);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
            return gridTemplate;

        }

        public GridTemplateList GetGridTemplatesByAuthorizedUser(string authorizedUserId, bool isGetAll = false)
        {
            GridTemplateList gridTemplateList = null;
            try
            {
                var cacheKey = string.Format("GridDataAccessManager.GetGridTemplatesByAuthorizedUser{0}{1}", authorizedUserId, isGetAll);
                var dsFromCache = VelocityCacheManager.Read(cacheKey) as DataSet;

                if (dsFromCache != null) return GetGridTemplatesFromDataSet(dsFromCache);

                dsFromCache = _gridDaoManager.GetGridTemplatesByAuthorizedUser(authorizedUserId, isGetAll);
                gridTemplateList = GetGridTemplatesFromDataSet(dsFromCache);

                VelocityCacheManager.Write(cacheKey, dsFromCache, GridCacheConstants.CommonGridCacheLevel);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
            return gridTemplateList;
        }

        //public GridTemplateList GetGridTemplatesByUserId()
        //{
        //    GridTemplateList list = null;
        //    try
        //    {
        //        DataSet ds = _gridDaoManager.GetGridTemplatesByUserId();
        //        list = GetGridTemplatesFromDataSet(ds);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new CartGridLoadFailedException(ex.Message);
        //    }
        //    return list;
        //}

        public string CreateGridTemplate(GridTemplate gridTemplate)
        {
            Dictionary<string, string> gridTemplateFieldList = DataConverter.ConverGridTemplateFieldToDictionary(gridTemplate);
            string gridTemplateId = string.Empty;
            try
            {
                _gridDaoManager.UpdateGridTemplate(gridTemplate.GridTemplateId, gridTemplate.OwnerUserId, gridTemplate.Name, gridTemplate.Description, gridTemplate.EnableIndicator, gridTemplateFieldList);
                ClearCacheGridTemplateAuthorizedUser(gridTemplate.OwnerUserId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
            return gridTemplateId;

        }

        public void UpdateGridTemplate(GridTemplate gridTemplate)
        {
            DataSet ds = _gridDaoManager.GetGridFieldPositionMap(gridTemplate.GridTemplateId);
            Dictionary<string, string> fieldMap =
                ds.Tables[0].AsEnumerable().ToDictionary(
                    dr => "GridField" + DataAccessHelper.ConvertToString(dr["Position"]) + "ID",
                    dr => DataAccessHelper.ConvertToString(dr["GridFieldID"]));
            try
            {
                _gridDaoManager.UpdateGridTemplate(gridTemplate.GridTemplateId, gridTemplate.OwnerUserId, gridTemplate.Name, gridTemplate.Description, gridTemplate.EnableIndicator, fieldMap);
                ClearCacheGridTemplateAuthorizedUser(gridTemplate.OwnerUserId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void DeleteGridTemplate(GridTemplate gridTemplate)
        {
            try
            {
                _gridDaoManager.DeleteGridTemplate(gridTemplate.GridTemplateId);
                ClearCacheGridTemplateAuthorizedUser(gridTemplate.OwnerUserId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public UserGridTemplateList GetUserGridTemplates(string gridTemplateId)
        {
            UserGridTemplateList list = null;
            
            try
            {
                DataSet ds = _gridDaoManager.GetUserGridTemplates(gridTemplateId);
                list = GetUserGridTemplateFromDataSet(ds);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        public List<CommonGridTemplate> GetGridTemplatesByUser(string userId)
        {
            List<CommonGridTemplate> list = null;
            try
            {
                DataSet ds = _gridDaoManager.GetGridTemplatesByUser(userId);
                list = GetGridTemplateByUserFromDataSet(ds);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        public void CreateUserGridTemplate(UserGridTemplate userGridTemplate)
        {
            try
            {
                _gridDaoManager.UpdateUserGridTemplate(userGridTemplate.UserGridTemplateId, userGridTemplate.UserId, userGridTemplate.RowExpensionRight, userGridTemplate.Sequence, userGridTemplate.GridTemplateId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }

        }

        public void UpdateUserGridTemplate(UserGridTemplate userGridTemplate)
        {
            try
            {
                _gridDaoManager.UpdateUserGridTemplate(userGridTemplate.UserGridTemplateId, userGridTemplate.UserId, userGridTemplate.RowExpensionRight, userGridTemplate.Sequence, userGridTemplate.GridTemplateId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void DeleteUserGridTemplate(string userGridTemplateId)
        {
            try
            {
                _gridDaoManager.DeleteUserGridTemplate(userGridTemplateId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public GridTemplateLineList GetGridTemplateLines(string gridTemplateId)
        {
            GridTemplateLineList list = null;
            try
            {
                DataSet ds = _gridDaoManager.GetGridTemplateLines(gridTemplateId);
                //DataSet map = _gridDaoManager.GetGridFieldPositionMap(gridTemplateId);
                list = GetGridTemplateLinesFromDataSet(ds, null);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;

        }

        public GridTemplateLineList GetGridTemplateLinesWithPaging(string gridTemplateId, int? pageIndex = null, int? pageSize = null)
        {
            GridTemplateLineList list = null;
            try
            {
                DataSet ds = _gridDaoManager.GetGridTemplateLinesWithPaging(gridTemplateId, pageIndex, pageSize);
                //DataSet map = _gridDaoManager.GetGridFieldPositionMap(gridTemplateId);
                list = GetGridTemplateLinesFromDataSet(ds, null);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;

        }

        public void UpdateGridFieldPositionInTemplate(string gridTemplateId)
        {
            try
            {
                _gridDaoManager.UpdateGridFieldPositionInTemplate(gridTemplateId);
            }
            catch (Exception ex)
            {

                throw new CartGridSaveFailedException(ex.Message);
            }
        }
        public void CreateGridTemplateLine(GridTemplateLine gridTemplateLine)
        {
            UpdateGridTemplateLine(gridTemplateLine);
        }

        public void UpdateGridTemplateLine(GridTemplateLine gridTemplateLine)
        {
            DataSet map = _gridDaoManager.GetGridFieldPositionMap(gridTemplateLine.GridTemplateId);
            Dictionary<string, string> paramList = DataConverter.ConverGridCodeInTemplateToDictionary(gridTemplateLine, map);
            if (paramList.Count <= 0)
                throw new CartGridDatabaseException("Can not get GridField position");
            try
            {
                _gridDaoManager.UpdateGridTemplateLine(gridTemplateLine.GridTemplateLineId, gridTemplateLine.Quantity,
                                                       gridTemplateLine.Sequence, gridTemplateLine.EnableIndicator,
                                                       gridTemplateLine.GridTemplateId, paramList);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);

            }
        }

        public void DeleteGridTemplateLine(string gridTemplateLineId)
        {
            try
            {
                _gridDaoManager.DeleteGridTemplateLine(gridTemplateLineId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        #endregion

        #region NEW GRID

        public List<CommonGridTemplateLine> LoadCartGridDistribution(string userId,string cartId, string orgId, out int cartGridOption, out string templateId)
        {
            try {
                var gridTemplateLines = new List<CommonGridTemplateLine>();
                cartGridOption = 0;
                templateId = string.Empty;
                var ds = _gridDaoManager.GetCartGridDistribution(userId, cartId, out cartGridOption, out templateId);
                
                gridTemplateLines = GetGridTemplateLinesFromDataSet(ds);
                return gridTemplateLines;
            }
            catch (Exception ex) { throw new CartGridLoadFailedException(ex.Message); }
            return null;
        }

        public bool SaveCartGridDistribution(string userId, string cartId, int cartGridOption, string templateId, List<CommonGridTemplateLine> gridTemplateLines)
        {
            try
            {
                var sortedLines = gridTemplateLines.OrderBy(r => r.Sequence).ToList();
                List<SqlDataRecord> gridLines = DataConverter.ConvertGridTemplateLinesToDataSetNew(sortedLines);
                return _gridDaoManager.SaveCartGridDistribution(userId, cartId, cartGridOption, templateId, gridLines);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
            return false;
        }
    
        public UserGridFieldsCodes GetUserGridFieldsCodes(string userId, string orgId)
        {
            try
            {
                var defaultQuantity = 0;
                var ds = _gridDaoManager.GetUserGridFieldsCodes(userId, orgId, out defaultQuantity);
                var userGridFieldCodes = RefineUserGridFieldsCodes(ds);
                userGridFieldCodes.DefaultQuantity = defaultQuantity;

                return userGridFieldCodes;
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public List<CommonBaseGridUserControl.UIUserGridField> GetGridFieldsByUser(string userId)
        {
            try
            {
                var gridFields = new List<CommonBaseGridUserControl.UIUserGridField>();
                var ds = _gridDaoManager.GetGridFieldsByUser(userId);
                if (ds != null && ds.Tables.Count > 0)
                {
                    var fieldTable = ds.Tables[0];
                    foreach (DataRow fieldRow in fieldTable.Rows)
                    {
                        var field = new CommonBaseGridUserControl.UIUserGridField();
                        field.GridFieldID = fieldRow["GridFieldID"].ToString();
                        field.DisplayType = fieldRow["DisplayType"].ToString();
                        field.DefaultGridCodeID = fieldRow["DefaultGridCodeID"].ToString();
                        field.DefaultGridText = fieldRow["DefaultGridText"].ToString();
                        field.UserGridFieldID = fieldRow["UserGridFieldID"].ToString();
                        gridFields.Add(field);
                    }
                }
                return gridFields;
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        private UserGridFieldsCodes RefineUserGridFieldsCodes(DataSet dsFieldCode)
        {
            var userGridFieldCodes = new UserGridFieldsCodes();
            if (dsFieldCode != null && dsFieldCode.Tables.Count == 2)
            {
                var fieldTable = dsFieldCode.Tables[0];
                var codeTable = dsFieldCode.Tables[1];
                var gridFields = new List<CommonBaseGridUserControl.UIUserGridField>();
                foreach (DataRow fieldRow in fieldTable.Rows)
                {
                    var field = new CommonBaseGridUserControl.UIUserGridField();
                    field.GridFieldID = fieldRow["GridFieldID"].ToString();
                    field.DisplayType = fieldRow["DisplayType"].ToString();
                    field.DefaultGridCodeID = fieldRow["DefaultGridCodeID"].ToString();
                    field.DefaultGridText = fieldRow["DefaultGridText"].ToString();
                    field.UserGridFieldID = fieldRow["UserGridFieldID"].ToString();
                    gridFields.Add(field);
                }
                var gridCodes = new List<CommonBaseGridUserControl.UIGridCode>();
                foreach (DataRow codeRow in codeTable.Rows)
                {
                    var code = new CommonBaseGridUserControl.UIGridCode();
                    code.ID = codeRow["GridCodeID"].ToString();
                    code.IsAuthorized = true;
                    code.Code = codeRow["Code"].ToString();
                    code.Literal = codeRow["Literal"].ToString();
                    code.EffectiveDate = DataAccessHelper.ConvertToDateTime(codeRow["EffectiveDate"]);
                    code.ExpirationDate = DataAccessHelper.ConvertToDateTime(codeRow["ExpirationDate"]);
                    code.Disable = !DataAccessHelper.ConvertToBool(codeRow["ActiveIndicator"]);
                    code.GridFieldID = codeRow["GridFieldID"].ToString();
                    gridCodes.Add(code);
                }
                userGridFieldCodes.UserGridFields = gridFields;
                userGridFieldCodes.UserGridCodes = gridCodes;
            }

            return userGridFieldCodes;
        }

        private static readonly string USER_DEFAULT_GRID_TMPL_CACHE_KEY = "USER_DEFAULT_GRID_TMPL_CACHE_KEY_{0}_{1}";
        public List<CommonGridTemplateLine> GetDefaultBasketGridTemplate(string userId, string cartId)
        {
            try
            {
                var cacheKey = string.Format(USER_DEFAULT_GRID_TMPL_CACHE_KEY, userId, cartId);
                var gridTemplateLines = VelocityCacheManager.Read(cacheKey) as List<CommonGridTemplateLine>;
                if (gridTemplateLines == null)
                {
                    var ds = _gridDaoManager.GetDefaultBasketGridTemplate(userId, new List<string>() { cartId });
                    gridTemplateLines = GetGridTemplateLinesFromDataSet(ds);
                    VelocityCacheManager.Write(cacheKey, gridTemplateLines, VelocityCacheLevel.Session);
                }

                return gridTemplateLines;
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException("procTS360GetDefaultBasketGridTemplate:"+ex.Message);
            }
        }

        private List<CommonGridTemplateLine> GetGridTemplateLinesFromDataSet(DataSet ds)
        {
            var results = new List<CommonGridTemplateLine>();
            if (ds != null && ds.Tables.Count > 0)
            {
                var gridTmplTable = ds.Tables[0];
                foreach (DataRow row in gridTmplTable.Rows)
                {
                    var line = new CommonGridTemplateLine
                    {
                        ID = row["GridTemplateLineID"].ToString(),
                        GridTemplateID = row["GridTemplateID"].ToString(),
                        AgencyCodeID = row["AgencyCodeID"].ToString(),
                        ItemTypeID = row["ItemTypeID"].ToString(),
                        CollectionID = row["CollectionID"].ToString(),
                        CallNumberText = row["CallNumberText"].ToString(),
                        UserCode1ID = row["UserCode1ID"].ToString(),
                        UserCode2ID = row["UserCode2ID"].ToString(),
                        UserCode3ID = row["UserCode3ID"].ToString(),
                        UserCode4ID = row["UserCode4ID"].ToString(),
                        UserCode5ID = row["UserCode5ID"].ToString(),
                        UserCode6ID = row["UserCode6ID"].ToString(),
                        Qty = DataAccessHelper.ConvertToInt(row["Quantity"]),
                        Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]),
                        EnabledIndicator = DataAccessHelper.ConvertToBool(row["EnabledIndicator"]),
                        //
                        IsTempDisabled = DataAccessHelper.ConvertToBool(row["TempDisabledIndicator"]),
                        //
                        CreatedBy = row["CreatedBy"].ToString(),
                        UpdatedBy = row["UpdatedBy"].ToString()
                    };

                    var createdDateTime = DataAccessHelper.ConvertToDateTime(row["CreatedDateTime"]);
                    if (createdDateTime != null)
                    {
                        line.CreatedDateTime = createdDateTime.Value;
                    }

                    createdDateTime = DataAccessHelper.ConvertToDateTime(row["UpdatedDateTime"]);
                    if (createdDateTime != null)
                    {
                        line.UpdatedDateTime = createdDateTime.Value;
                    }
                    results.Add(line);
                }
            }

            return results;
        }

        public void SaveGridLinesAsAGridTemplate(string userId, List<CommonGridTemplateLine> gridTemplateLines, string templateName, bool needToSaveQuantity,
           bool isDefault, string defaultBasketId, out string newTemplateNameIfDuplicated, out string newGridTemplateId,
           bool overwriteGridDistributionOption)
        {
            try
            {
                List<SqlDataRecord> gridLines = DataConverter.ConvertGridTemplateLinesToDataSetNew(gridTemplateLines);
                _gridDaoManager.SaveGridLinesAsAGridTemplate(gridLines, templateName, templateName, true,
                    needToSaveQuantity, isDefault, defaultBasketId, out newTemplateNameIfDuplicated, out newGridTemplateId, overwriteGridDistributionOption);

                if (isDefault)
                {
                    var cacheKey = string.Format(USER_DEFAULT_GRID_TMPL_CACHE_KEY, userId, defaultBasketId);
                    VelocityCacheManager.SetExpired(cacheKey);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public List<CommonGridTemplateLine> GetGridTemplateLinesNew(string gridTemplateId)
        {
            try
            {
                var gridTemplateLines = new List<CommonGridTemplateLine>();
                var ds = _gridDaoManager.GetGridTemplateLines(gridTemplateId);
                gridTemplateLines = GetGridTemplateLinesFromDataSet(ds);
                return gridTemplateLines;
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        #endregion

        #region support methods
        public List<GridTemplateOwner> GetGridTemplateOwners()
        {
            List<GridTemplateOwner> list = null;
            try
            {
                DataSet ds = _gridDaoManager.GetGridTemplateOwners();
                list = GetGridTemplateOwnersFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        public List<SOPGridField> GetSOPGridFieldList()
        {
            List<SOPGridField> list = null;
            try
            {
                DataSet ds = _gridDaoManager.GetSOPGridFieldList();
                list = GetSOPGridFieldListFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;
        }

        private GridTemplateList GetGridTemplatesFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var gridTemplateList = new GridTemplateList();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                GridTemplate template = GetGridTemplateFromDataRow(row);
                if (IsValidTemplate(template))
                {
                    gridTemplateList.Add(template);
                }
            }
            return gridTemplateList;
        }

        private bool IsValidTemplate(GridTemplate gridTpl)
        {
            if (gridTpl == null) return false;

            var isAutoName = !string.IsNullOrEmpty(gridTpl.Name) && gridTpl.Name[0] == '(' && gridTpl.Name[gridTpl.Name.Length - 1] == ')';

            if (gridTpl.IsGridDistribution || string.IsNullOrEmpty(gridTpl.Name) || (string.IsNullOrEmpty(gridTpl.Description) && isAutoName)) 
                return false;

            return true;
        }

        private GridTemplate GetGridTemplateFromDataRow(DataRow row)
        {
            GridTemplate template = null;
            var orgID = DataAccessHelper.ConvertToString(row["u_org_id"]);
            if (orgID == OrganizationId)
            {
                template = new GridTemplate();
                template.BeginDataLoading();
                if (!string.IsNullOrEmpty(row["Name"].ToString()))
                {
                    template.Id = DataAccessHelper.ConvertToString(row["GridTemplateID"]);
                    template.OwnerUserId = DataAccessHelper.ConvertToString(row["OwnerUserID"]);
                    template.OwnerUserName = DataAccessHelper.ConvertToString(row["display_name"]);
                    template.Description = DataAccessHelper.ConvertToString(row["Description"]);
                    template.Name = DataAccessHelper.ConvertToString(row["Name"]);
                    template.EnableIndicator = Parser.ToBool(row["EnabledIndicator"]);
                    template.GridTemplateLineCount = DataAccessHelper.ConvertToInt(row["GridTemplateLinesCount"]);
                    template.UserGridTemplatesCount = DataAccessHelper.ConvertToInt(row["UserGridTemplatesCount"]);
                    template.LastModidied = DataAccessHelper.ConvertToDateTime(row["UpdatedDateTime"]) ?? DateTime.Today;
                    template.IsGridDistribution = DataAccessHelper.ConvertToBool(row["IsGridDistribution"]);
                    template.GridDistributionOption = DataAccessHelper.ConvertToIntNullable(row["GridDistributionOptionID"]);
                    template.DefaultBasketSummaryId = DataAccessHelper.ConvertToString(row["DefaultBasketSummaryID"]);
                    template.IsUserDefaultGridTemplate = DataAccessHelper.ConvertToBool(row["IsUserDefaultTemplate"]);
                }
                template.EndDataLoading();
            }
            return template;
        }
        private UserGridTemplateList GetUserGridTemplateFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var gridTemplateList = new UserGridTemplateList();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var template = new UserGridTemplate();
                template.BeginDataLoading();
                template.Id = DataAccessHelper.ConvertToString(row["UserGridTemplateID"]);
                template.GridTemplateId = DataAccessHelper.ConvertToString(row["GridTemplateID"]);
                template.UserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
                template.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
                template.RowExpensionRight = DataAccessHelper.ConvertToString(row["RowExpansionRight"]);
                template.UserDisplayName = DataAccessHelper.ConvertToString(row["display_name"]);
                template.UserLoginName = DataAccessHelper.ConvertToString(row["username"]);
                template.EndDataLoading();
                gridTemplateList.Add(template);
            }

            return gridTemplateList;
        }

        private List<CommonGridTemplate> GetGridTemplateByUserFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var gridTemplateList = new List<CommonGridTemplate>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var isGridDistribution = DataAccessHelper.ConvertToBool(row["IsGridDistribution"]);

                if (string.IsNullOrEmpty(row["Name"].ToString())) continue;

                var template = new CommonGridTemplate();
                template.GridTemplateId = DataAccessHelper.ConvertToString(row["GridTemplateID"]);
                template.OwnerUserID = DataAccessHelper.ConvertToString(row["OwnerUserID"]);
                template.OwnerUserName = DataAccessHelper.ConvertToString(row["OwnerUserName"]);
                template.Description = DataAccessHelper.ConvertToString(row["Description"]);
                template.Name = DataAccessHelper.ConvertToString(row["Name"]);
                template.DefaultBasketSummaryID = DataAccessHelper.ConvertToString(row["DefaultBasketSummaryID"]);
                template.EnabledIndicator = Parser.ToBool(row["EnabledIndicator"]);
                template.NumberOfRows = DataAccessHelper.ConvertToInt(row["LineCount"]);
                template.LastModified = DataAccessHelper.ConvertToDateTime(row["UpdatedDateTime"]) ?? DateTime.Today;
                template.RowExpansionRight = DataAccessHelper.ConvertToString(row["RowExpansionRight"]);
                template.IsDefaultTemplate = DataAccessHelper.ConvertToBool(row["IsDefaultTemplate"]);
                template.IsGridDistribution = isGridDistribution;
                template.GridDistributionOption = DataAccessHelper.ConvertToIntNullable(row["GridDistributionOptionID"]);

                gridTemplateList.Add(template);
            }

            return gridTemplateList;
        }
        private GridCodeList GetGridCodesFromDataSet(DataSet ds, bool isGetInUseInfo = true)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var list = new GridCodeList(isGetInUseInfo);
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var code = new GridCode();
                code.BeginDataLoading();
                code.Id = DataAccessHelper.ConvertToString(row["GridCodeID"]);
                code.GridFieldId = DataAccessHelper.ConvertToString(row["GridFieldID"]);
                code.Code = DataAccessHelper.ConvertToString(row["Code"]);
                code.Literal = DataAccessHelper.ConvertToString(row["Literal"]);
                if (row["EffectiveDate"] != DBNull.Value)
                    code.EffectiveDate = DataAccessHelper.ConvertToDateTime(row["EffectiveDate"]);
                if (row["ExpirationDate"] != DBNull.Value)
                    code.ExpirationDate = DataAccessHelper.ConvertToDateTime(row["ExpirationDate"]);
                code.ActiveIndicator = DataAccessHelper.ConvertToBool(row["ActiveIndicator"]);
                code.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
                if ((code.ExpirationDate >= DateTime.Today && code.EffectiveDate <= DateTime.Today) || code.EffectiveDate >= DateTime.Today || (string.IsNullOrEmpty(row["ExpirationDate"].ToString())))
                    code.IsExpired = false;
                else
                    code.IsExpired = true;
                code.IsUsing = DataAccessHelper.ConvertTo<bool>(row, "IsUsing");//Parser.ToBool(row["IsUsing"]);
                code.UserIDs = row.Table.Columns.Contains("UserIDs") ? DataAccessHelper.ConvertToString(row["UserIDs"]) : "";
                code.AssignedUsersCount = row.Table.Columns.Contains("NumberOfUsers") ? DataAccessHelper.ConvertToInt(row["NumberOfUsers"]) : 0;
                code.EndDataLoading();
                list.Add(code);
            }
            return list;
        }
        private List<CommonBaseGridUserControl.UIUserGridCode> GetUserGridCodesFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var list = new List<CommonBaseGridUserControl.UIUserGridCode>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var code = new CommonBaseGridUserControl.UIUserGridCode();
                
                code.UserGridCodeID = DataAccessHelper.ConvertToString(row["UserGridCodeID"]);
                code.GridFieldID = DataAccessHelper.ConvertToString(row["GridFieldID"]);
                code.ID = DataAccessHelper.ConvertToString(row["GridCodeID"]);
                code.UserID = DataAccessHelper.ConvertToString(row["u_user_id"]);
                code.Code = DataAccessHelper.ConvertToString(row["Code"]);
                code.Literal = DataAccessHelper.ConvertToString(row["Literal"]);
                code.EffectiveDate = DataAccessHelper.ConvertToDateTimeNull(row, "EffectiveDate");
                code.ExpirationDate = DataAccessHelper.ConvertToDateTimeNull(row, "ExpirationDate");
                code.Disable = !DataAccessHelper.ConvertToBool("ActiveIndicator");                
                list.Add(code);
            }
            return list;
        }

        private GridFieldList GetAllGridFieldGridCodeFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 1 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var gridCodeList = new List<GridCode>();
            var allGridCodeList = new List<GridCode>();
            foreach (DataRow row in ds.Tables[1].Rows)
            {
                GridCode gridCode = new GridCode
                                        {
                                            GridFieldId = DataAccessHelper.ConvertToString(row["GridFieldID"]),
                                            ActiveIndicator = DataAccessHelper.ConvertToBool(row["ActiveIndicator"]),
                                            Id = DataAccessHelper.ConvertToString(row["GridCodeID"]),
                                            Code = DataAccessHelper.ConvertToString(row["Code"]),
                                            Literal = DataAccessHelper.ConvertToString(row["Literal"]),
                                            EffectiveDate = DataAccessHelper.ConvertToDateTime(row["EffectiveDate"]),
                                            ExpirationDate = DataAccessHelper.ConvertToDateTime(row["ExpirationDate"]),
                                            Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]),
                                            IsAuthorized = DataAccessHelper.ConvertToBool(row["IsAuthorized"])
                                        };

                allGridCodeList.Add(gridCode);
                //var isAuthorized = DataAccessHelper.ConvertToBool(row["IsAuthorized"]);
                //if (gridCode.EffectiveDate <= DateTime.Today && (gridCode.ExpirationDate == null || gridCode.ExpirationDate > DateTime.Today))
                {
                    gridCodeList.Add(gridCode);
                }
            }

            var list = new GridFieldList();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                string gridFieldID = DataAccessHelper.ConvertToString(row["GridFieldID"]);
                bool isFreeText = DataAccessHelper.ConvertToBool(row["FreeTextIndicator"]);
                GridCodeList gridCodes = new GridCodeList();
                GridCodeList allGridCodes = new GridCodeList();
                if (!isFreeText)
                {
                    gridCodes.AddRange(gridCodeList.FindAll(item => item.GridFieldId == gridFieldID));
                    allGridCodes.AddRange(allGridCodeList.FindAll(item => item.GridFieldId == gridFieldID));
                }

                var userGridFieldList = new UserGridFieldList();
                var displayType = DataAccessHelper.ConvertToString(row["DisplayType"]);
                var defaultGridText = DataAccessHelper.ConvertToString(row["DefaultGridText"]);
                if (!string.IsNullOrEmpty(displayType) || !string.IsNullOrEmpty(defaultGridText))
                {
                    var userGridField = new UserGridField
                                            {
                                                Id = gridFieldID,
                                                DefaultGridCodeId =
                                                    DataAccessHelper.ConvertToString(row["DefaultGridCodeId"]),
                                                DefaultGridText =
                                                    DataAccessHelper.ConvertToString(row["DefaultGridText"]),
                                                DisplayType =
                                                    DataAccessHelper.ConvertToString(row["DisplayType"]),
                                                UserId = this.UserId
                                            };
                    userGridFieldList = new UserGridFieldList { userGridField };
                }
                var gridField = new GridField
                                          {
                                              Id = gridFieldID,
                                              ActiveIndicator = DataAccessHelper.ConvertToBool(row["ActiveIndicator"]),
                                              FreeTextIndicator = isFreeText,
                                              SOPGridFieldId = DataAccessHelper.ConvertToInt(row["SOPGridFieldID"]),
                                              OrganizationId = DataAccessHelper.ConvertToString(row["u_org_id"]),
                                              Name = DataAccessHelper.ConvertToString(row["Name"]),
                                              FreeTextCharacterLimit =
                                                  DataAccessHelper.ConvertToInt(row["FreeTextCharacterLimit"]),
                                              Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]),
                                              LockedIndicator = DataAccessHelper.ConvertToBool(row["LockedIndicator"]),
                                              ValidateIndicator =
                                                  DataAccessHelper.ConvertToBool(row["ValidateIndicator"]),
                                              SlipReportSequence =
                                                  DataAccessHelper.ConvertToInt(row["SlipReportSequence"]),
                                              GridCodes = gridCodes,
                                              AllGridCodes = allGridCodes,
                                              UserGridFields = userGridFieldList
                                          };
                list.Add(gridField);
            }
            return list;
        }
        //private GridFieldList GetGridFieldsFromDataSet(DataSet ds, bool isGetInUseInfo = true)
        //{
        //    if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
        //    {
        //        return null;
        //    }
        //    var list = new GridFieldList();
        //    foreach (DataRow row in ds.Tables[0].Rows)
        //    {
        //        var gridField = new GridField();
        //        gridField.BeginDataLoading();
        //        gridField.Id = DataAccessHelper.ConvertToString(row["GridFieldID"]);
        //        gridField.SOPGridFieldId = DataAccessHelper.ConvertToInt(row["SOPGridFieldID"]);
        //        gridField.OrganizationId = DataAccessHelper.ConvertToString(row["u_org_id"]);
        //        gridField.Name = DataAccessHelper.ConvertToString(row["Name"]);
        //        gridField.FreeTextIndicator = DataAccessHelper.ConvertToBool(row["FreeTextIndicator"]);
        //        gridField.FreeTextCharacterLimit = DataAccessHelper.ConvertToInt(row["FreeTextCharacterLimit"]);
        //        gridField.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
        //        gridField.LockedIndicator = DataAccessHelper.ConvertToBool(row["LockedIndicator"]);
        //        gridField.ActiveIndicator = DataAccessHelper.ConvertToBool(row["ActiveIndicator"]);
        //        gridField.UserViewAllGridCodesIndicator = DataAccessHelper.ConvertToBool(row["UserViewAllGridCodesIndicator"]);
        //        gridField.ValidateIndicator = DataAccessHelper.ConvertToBool(row["ValidateIndicator"]);
        //        gridField.SlipReportSequence = DataAccessHelper.ConvertToInt(row["SlipReportSequence"]);
        //        gridField.IsUsing = DataAccessHelper.ConvertTo<bool>(row, "IsUsing");//DataAccessHelper.ConvertToBool(row["IsUsing"]);
        //        gridField.IsGetInUseInfo = isGetInUseInfo;
        //        gridField.EndDataLoading();
        //        list.Add(gridField);
        //    }
        //    return list;
        //}
        private UserGridFieldList GetUserGridFieldsFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var list = new UserGridFieldList();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var gridField = new UserGridField();
                gridField.BeginDataLoading();
                gridField.Id = DataAccessHelper.ConvertToString(row["UserGridFieldID"]);
                gridField.UserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
                gridField.GridFieldId = DataAccessHelper.ConvertToString(row["GridFieldID"]);
                gridField.DisplayType = DataAccessHelper.ConvertToString(row["DisplayType"]);
                gridField.DefaultGridCodeId = DataAccessHelper.ConvertToString(row["DefaultGridCodeID"]);
                gridField.DefaultGridText = DataAccessHelper.ConvertToString(row["DefaultGridText"]);
                gridField.UserLoginName = DataAccessHelper.ConvertToString(row["username"]);
                gridField.UserDisplayName = DataAccessHelper.ConvertToString(row["display_name"]);
                gridField.EndDataLoading();
                list.Add(gridField);
            }
            return list;
        }
        private GridTemplateLineList GetGridTemplateLinesFromDataSet(DataSet ds, DataSet map)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var list = new GridTemplateLineList();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var templateLine = new GridTemplateLine();
                templateLine.BeginDataLoading();
                templateLine.Id = DataAccessHelper.ConvertToString(row["GridTemplateLineID"]);
                templateLine.Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]);
                templateLine.GridTemplateId = DataAccessHelper.ConvertToString(row["GridTemplateID"]);
                templateLine.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
                templateLine.EnableIndicator = DataAccessHelper.ConvertToBool(row["EnabledIndicator"]);
                templateLine.GridFieldCodeInTemplates = new GridFieldCodeInTemplateList();

                for (int i = 0; i < 10; i++)
                {
                    if (row["GridField" + (i + 1).ToString() + "ID"] != DBNull.Value)
                        templateLine.GridFieldCodeInTemplates.Add(new GridFieldCodeInTemplate
                                                                      {
                                                                          GridCodeId =
                                                                              DataAccessHelper.ConvertToString(
                                                                                  row["GridCode" + (i + 1).ToString() + "ID"
                                                                                      ]),
                                                                          GridFieldId =
                                                                              DataAccessHelper.ConvertToString(
                                                                                  row["GridField" + (i + 1).ToString() + "ID"
                                                                                      ]),
                                                                          GridText =
                                                                              DataAccessHelper.ConvertToString(
                                                                                  row["GridText" + (i + 1).ToString()]),
                                                                          GridCode = DataAccessHelper.ConvertToString(
                                                                                  row["GridCodeValue" + (i + 1).ToString()]),
                                                                          IsAuthorized = DataAccessHelper.ConvertToBool(
                                                                                  row["IsAuthorized" + (i + 1).ToString()]),
                                                                          IsFreeText = DataAccessHelper.ConvertToBool(
                                                                                  row["FreeTextIndicator" + (i + 1).ToString()]),
                                                                          Status = Parser.ToFieldCodeStatus(DataAccessHelper.ConvertToInt(row["GridCodeState" + (i + 1).ToString()]))
                                                                      });
                }
                templateLine.EndDataLoading();
                list.Add(templateLine);
            }
            return list;
        }
        private List<GridTemplateOwner> GetGridTemplateOwnersFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var list = new List<GridTemplateOwner>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var owner = new GridTemplateOwner();
                owner.OwnerUserId = DataAccessHelper.ConvertToString(row["OwnerUserId"]);
                owner.Name = DataAccessHelper.ConvertToString(row["display_name"]);
                list.Add(owner);
            }
            return list;
        }
        private List<SOPGridField> GetSOPGridFieldListFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows == null)
            {
                return null;
            }
            var list = new List<SOPGridField>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var field = new SOPGridField();
                field.SOPGridFieldId = DataAccessHelper.ConvertToInt(row["SOPGridFieldID"]);
                field.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);
                field.Literal = DataAccessHelper.ConvertToString(row["Literal"]);
                list.Add(field);
            }
            return list;
        }

        private UserPreference GetUserPreferenceFromDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count < 1)
            {
                return null;
            }
            var userPref = new UserPreference();
            DataRow row = ds.Tables[0].Rows[0];
            userPref.BeginDataLoading();
            userPref.PrimaryCartId = DataAccessHelper.ConvertToString(row["PrimaryBasketID"]);
            userPref.DefaultGridTemplateId = DataAccessHelper.ConvertToString(row["DefaultGridTemplateID"]);
            userPref.Id = DataAccessHelper.ConvertToString(row["u_user_id"]);
            userPref.DefaultQuantity = DataAccessHelper.ConvertToInt(row["DefaultQuantity"]);
            userPref.EndDataLoading();
            return userPref;
        }

        private void ClearCacheGridCodes(string gridFieldId, bool allIndicator = false)
        {
            var cacheKey = string.Format("GridDataAccessManager.GetGridCodes()_{0}_{1}_{2}", _gridDaoManager.UserId,
                                             gridFieldId, allIndicator.ToString());
            VelocityCacheManager.SetExpired(cacheKey);
        }

        private void ClearCacheUserGridCodes(string gridCodeId)
        {
            var cacheKey = string.Format("GridDataAccessManager.GetUserGridCodes()_{0}", gridCodeId);
            VelocityCacheManager.SetExpired(cacheKey);
        }

        private void ClearCacheGridFields()
        {
            var cacheKey = string.Format("GridDataAccessManager.GetGridFields()_{0}", _gridDaoManager.OrganizationId);
            VelocityCacheManager.SetExpired(cacheKey);
        }

        private void ClearCacheUserGridFields(string gridFieldId)
        {
            var cacheKey = string.Format("GridDataAccessManager.GetUserGridFields()_{0}", gridFieldId);
            VelocityCacheManager.SetExpired(cacheKey);
        }

        public void ClearCacheGridTemplateAuthorizedUser(string authorizedUserId)
        {
            var cacheKey = string.Format("GridDataAccessManager.GetGridTemplatesByAuthorizedUser_{0}", authorizedUserId);
            VelocityCacheManager.SetExpired(cacheKey);
        }

        #endregion

        public UserPreference GetUserPreference()
        {
            UserPreference userPref = null;
            try
            {
                DataSet ds = _gridDaoManager.GetUserPreference();
                userPref = GetUserPreferenceFromDataSet(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
            return userPref;
        }

        public void UpdateUserPreference(UserPreference userPreference)
        {
            _gridDaoManager.UpdateUserPreference(userPreference.PrimaryCartId, userPreference.DefaultGridTemplateId);
        }

        public List<UserGridTemplate> GetUserGridTemplates(string gridTemplateId, string orgId, int pageIndex, int pageSize, out int total)
        {
            try
            {
                DataSet ds = _gridDaoManager.GetUserGridTemplate(gridTemplateId, orgId, pageIndex, pageSize, out total);
                return GetUserGridTemplateFromDataset(ds);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridLoadFailedException(ex.Message);
            }
        }

        public List<UserGridTemplate> GetUserGridTemplateFromDataset(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {
                return new List<UserGridTemplate>();
            }
            var userGridTemplates = new List<UserGridTemplate>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var ugt = new UserGridTemplate();
                ugt.Id = DataAccessHelper.ConvertToString(row["UserGridTemplateID"]);
                ugt.GridTemplateId = DataAccessHelper.ConvertToString(row["GridTemplateID"]);
                ugt.UserId = DataAccessHelper.ConvertToString(row["u_user_id"]);
                ugt.UserLoginName = DataAccessHelper.ConvertToString(row["username"]);
                ugt.UserDisplayName = DataAccessHelper.ConvertToString(row["display_name"]);
                ugt.RowExpensionRight = DataAccessHelper.ConvertToString(row["RowExpansionRight"]);
                ugt.Sequence = DataAccessHelper.ConvertToInt(row["Sequence"]);

                userGridTemplates.Add(ugt);
            }
            return userGridTemplates;
        }
        public void UpdateUserGridTemplates(List<UserGridTemplate> userGridTemplates)
        {
            var ugtRecords = DataConverter.GetUtblUserGridTemplates(userGridTemplates);
            _gridDaoManager.UpdateUserGridTemplates(ugtRecords);
        }

        public void SaveUserGridTemplates(string userId, List<CommonGridTemplate> gridTemplatesForUpdate, List<string> gridTemplateIDsForDelete)
        {
            var updatedDataRecords = DataConverter.ConvertGridTemplatesToDatatSet(gridTemplatesForUpdate);
            var deletedDataRecords = DataConverter.ConvertGuidsToDataSet(gridTemplateIDsForDelete);

            _gridDaoManager.SaveUserGridTemplates(userId, updatedDataRecords, deletedDataRecords);
        }

        public void CopyGridTemplates(List<string> gridTemplateIds, string userId)
        {
            try
            {
                _gridDaoManager.CopyGridTemplates(gridTemplateIds, userId);
            }
            catch (Exception ex)
            {
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void UpdateUserGridFieldSlipReportSequence(List<CommonBaseGridUserControl.UIGridField> gridFields)
        {
            try
            {
                _gridDaoManager.UpdateUserGridFieldSlipReportSequence(OrganizationId, UserId, gridFields);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void SaveGridFieldsGridCodes(List<string> deletedGridCodes, List<CommonBaseGridUserControl.UIGridField> changedGridFields, List<CommonBaseGridUserControl.UIGridCode> changedGridCodes, string espFundCodeFieldID, string espBranchCodeFieldID, string ilsFundCodeFieldID, string ilsLocationCodeFieldID,
                 string ilsMemberCodeRemainderFieldId, int ilsMemberCodeLength, bool ilsPassEntireLocationAsRemainder, string ilsPassPOAsLineNoteFieldId, string ilsCollectionCodeFieldId)
        {
            _gridDaoManager.SaveGridFieldsGridCodes(OrganizationId, UserId, deletedGridCodes, changedGridFields, changedGridCodes, espFundCodeFieldID, espBranchCodeFieldID,
                ilsFundCodeFieldID, ilsLocationCodeFieldID, ilsMemberCodeRemainderFieldId, ilsMemberCodeLength, ilsPassEntireLocationAsRemainder, ilsPassPOAsLineNoteFieldId, ilsCollectionCodeFieldId);
        }

        public void SaveGridTemplate(string organizationId, string gridTemplateId, string owerId, string templateName, string templateDescriptions,
            bool enableIndicator, List<CommonGridTemplateLine> gridTemplateLines, List<string> deletedLineIDs, string cartId, bool isDefault)
        {
            try
            {
                // order by sequence
                var sortedLines = gridTemplateLines.OrderBy(r => r.Sequence).ToList();

                List<SqlDataRecord> gridLines = DataConverter.ConvertGridTemplateLinesToDataSetNew(sortedLines);

                _gridDaoManager.SaveGridTemplate(organizationId, gridTemplateId, owerId, templateName,
                    templateDescriptions, enableIndicator, gridLines, deletedLineIDs, cartId, isDefault);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void SaveUserGridFieldsCodes(string userId, List<CommonBaseGridUserControl.UIUserGridField> userGridFieldObjects, int defaultQuantity)
        {
            try
            {
                var sqlDataRecords = DataConverter.ConvertUIUserGridFieldToDataSet(userGridFieldObjects);
                _gridDaoManager.SaveUserGridFieldsCodes(userId, sqlDataRecords, defaultQuantity);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void SaveUserAssignedGridFieldsCodes(List<string> userGridCodeAssignToUser, string userId)
        {
            try
            {
                var sqlDataRecords = DataConverter.ConvertGuidsToDataSet(userGridCodeAssignToUser);
                _gridDaoManager.SaveUserAssignedGridFieldsCodes(sqlDataRecords, userId);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
            }
        }

        public void ClearDefaultSettingUserGridTemplate(string userId)
        {
            _gridDaoManager.ClearDefaultSettingUserGridTemplate(userId);
        }

        public List<CommonBaseGridUserControl.UIUserGridCode> GetUserGridCodes(string userId)
        {
            var list = new List<CommonBaseGridUserControl.UIUserGridCode>();
            try
            {
                //read from cache
                //var cacheKey = string.Format("GridDataAccessManager.GetUserGridCodes()_{0}", userId);
                //var dsFromCache = VelocityCacheManager.Read(cacheKey);
                //if (dsFromCache != null) return GetUserGridCodesFromDataSet(dsFromCache as DataSet);

                //not exist in cache
                var ds = _gridDaoManager.GetUserGridCodes(userId);
                list = GetUserGridCodesFromDataSet(ds);

                //store data set to cache, expiration per request
                //VelocityCacheManager.Write(cacheKey, ds, CacheLevel);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
            return list;

        }

        public string GetDefaultGridTemplateId(string userId, string cartId)
        {
            try
            {
                return _gridDaoManager.GetDefaultGridTemplateId(userId, cartId);
            }
            catch (Exception ex)
            {
                throw new CartGridLoadFailedException(ex.Message);
            }
        }
    }
}
