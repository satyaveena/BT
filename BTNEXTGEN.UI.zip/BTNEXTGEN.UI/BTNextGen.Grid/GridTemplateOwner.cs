﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class GridTemplateOwner
    {
        public string OwnerUserId { get; set; }

        public string Name { get; set; }

    }
}
