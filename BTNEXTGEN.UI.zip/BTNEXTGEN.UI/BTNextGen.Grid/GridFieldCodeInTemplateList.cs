﻿using System;
using System.Linq;
using System.Text;
using BTNextGen.VelocityCaching;

namespace BTNextgen.Grid
{
    public class GridFieldCodeInTemplateList : EditableObjectCollection<GridFieldCodeInTemplate, GridDataAccessManager>
    {
        /// <summary>
        /// Sort grid field column by the gridFieldList sequence
        /// </summary>
        /// <param name="gridFieldList"></param>
        public void SortByGridFieldsOrder(GridFieldList gridFieldList)
        {
            var gridFieldCodeInTemplates = Items.ToDictionary(gridFieldCodeInTemplate => gridFieldCodeInTemplate.GridFieldId);                         
            var sortedList = gridFieldList.Select(gridField => gridFieldCodeInTemplates[gridField.GridFieldId]).ToList();
            Items.Clear();
            Items.AddRange(sortedList);
        }
    }
}
