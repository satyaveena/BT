﻿using System;
using System.Collections.Generic;

namespace BTNextgen.Grid
{
    public class GridTemplateLine : EditableObject<GridDataAccessManager>
    {        
        public string GridTemplateLineId
        {
            get { return Id; }            
        }

        private string _gridTemplateId;
        public string GridTemplateId
        {
            get { return _gridTemplateId; }
            internal set
            {
                SetChanged();
                _gridTemplateId = value;
            }
        }

        private int _quantity;
        public int Quantity
        {
            get { return _quantity; }
            set
            {
                SetChanged();
                _quantity = value;
            }
        }

        private int _sequence;
        public int Sequence
        {
            get { return _sequence; }
            set
            {
                SetChanged();
                _sequence = value;
            }
        }

        private bool _enableIndicator;
        public bool EnableIndicator
        {
            get { return _enableIndicator; }
            set
            {
                SetChanged();
                _enableIndicator = value;
            }
        }


        public bool ValidIndicator { get; internal set; }

        public GridFieldCodeInTemplateList GridFieldCodeInTemplates { get; internal set; }        

        public GridTemplateLine()
        {
            GridFieldCodeInTemplates = new GridFieldCodeInTemplateList();
        }                      

        protected override void PersistAsNew()
        {
            //Save all at one
            CurrentDataAccessManager.CreateGridTemplateLine(this);
        }

        protected override void PersistAsUpdate()
        {
            //Save all at one
            CurrentDataAccessManager.UpdateGridTemplateLine(this);
        }

        protected override void PersistAsDelete()
        {
            //Save all at one
            CurrentDataAccessManager.DeleteGridTemplateLine(Id);
        }

        /// <summary>
        /// Sort grid field column by the gridFieldList sequence
        /// </summary>
        /// <param name="gridFieldList"></param>
        //public void SortByGridFieldSequence(GridFieldList gridFieldList)
        //{
        //    GridFieldCodeInTemplates.SortByGridFieldsOrder(gridFieldList);
        //}
    }
}
