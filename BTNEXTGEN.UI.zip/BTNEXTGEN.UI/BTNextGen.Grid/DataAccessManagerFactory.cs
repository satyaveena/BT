﻿using BTNextgen.Grid.Cart;

namespace BTNextgen.Grid
{
    public static class DataAccessManagerFactory
    {
        public static TD CreateDataAccessManager<TD>() where TD:DataAccessManager
        {
            var type = typeof (TD);            
            switch (type.Name)
            {
                case "GridDataAccessManager":
                    return (new GridDataAccessManager()) as TD;
                case "CartGridDataAccessManager":
                    return (new CartGridDataAccessManager()) as TD;
                default:
                    return null;
            }
        }
    }
}
