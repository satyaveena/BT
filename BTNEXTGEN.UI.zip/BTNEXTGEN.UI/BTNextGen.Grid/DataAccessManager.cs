﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Grid.DataAccess;

namespace BTNextgen.Grid
{
    public class DataAccessManager
    {
        public bool TransactionStarted { get; private set; }

        internal string OrganizationId { get; set; }

        internal string UserId { get; set; }

        private DAOManager _daoManager;
        
        public virtual void BeginTransaction()
        {
            if (!TransactionStarted)
            {
                _daoManager.BeginTransaction();
                TransactionStarted = true;
            }                
        }

        public virtual void CommitTransaction()
        {
            if (TransactionStarted)
            {
                _daoManager.CommitTransaction();
                TransactionStarted = false;    
            }            
        }

        public virtual void RollBackTransaction()
        {
            if (TransactionStarted)
            {
                _daoManager.RollBackTransaction();
                TransactionStarted = false;
            }              
        }

        public virtual void LoadById<T>(T editableObject)
        {
            
        }

        public void Initialize()
        {

            if(_daoManager==null)
                _daoManager = GetDAOManager();
            //
            _daoManager.UserId = UserId;
            _daoManager.OrganizationId = OrganizationId;
        }

        protected virtual DAOManager GetDAOManager()
        {
            return null;
        }
    }
}
