﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Grid.Exception;

namespace BTNextgen.Grid
{
    public class GridCodeList : EditableObjectCollection<GridCode, GridDataAccessManager>
    {
        private readonly bool _isGetInUseInfo = true;
        public GridCodeList(bool isGetInUseInfo = true)
        {
            _isGetInUseInfo = isGetInUseInfo;
        }
        public override void Add(GridCode item)
        {
            if (!IsGridCodeExisting(item.Code))
                base.Add(item);
            else
            {
                throw new GridException(4, "Grid code already exists’");
            }
        }

        public void AddWithoutValidation(GridCode item)
        {
            base.Add(item);
        }

        private bool IsGridCodeExisting(string gridCode)
        {
            return Items.Any(item => item.Code == gridCode);
        }

        public IEnumerable<GridCode> GetActiveGridCodes()
        {
            var gridCodes = from c in Items
                            where c.ActiveIndicator
                            select c;
            return gridCodes;
        }

        protected override IEnumerable<GridCode> InternalLoadItems(Dictionary<string, object> parameters)
        {
            var isNoCache = false;
            if (parameters.Keys.Contains("IsNoCache"))
            { isNoCache = Convert.ToBoolean(parameters["IsNoCache"].ToString()); }
            return CurrentDataAccessManager.GetAllGridCodes(parameters["GridFieldId"].ToString(), Convert.ToBoolean(parameters["GetAll"].ToString()), _isGetInUseInfo, isNoCache);
        }

        public Dictionary<string, bool> GetGridCodesAssignedToUser(string userId)
        {
            var result = new Dictionary<string, bool>();
            foreach (var gridCode in Items)
            {
                var userGridCodeList = gridCode.UserGridCodes;
                if (userGridCodeList.Any(i => i.UserId.ToLower() == userId.ToLower()))
                {
                    result.Add(gridCode.GridCodeId, true);
                }
                else
                {
                    result.Add(gridCode.GridCodeId, false);
                }
            }
            return result;
        }

        public bool CheckDuplicateName()
        {
            var fieldNameNum = Items.Select(item => item.Code).Distinct(StringComparer.CurrentCultureIgnoreCase).Count();
            if (fieldNameNum < Items.Count)
                return true;
            return false;
        }
    }
}
