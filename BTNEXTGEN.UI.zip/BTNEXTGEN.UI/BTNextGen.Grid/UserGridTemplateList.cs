﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserGridTemplateList : EditableObjectCollection<UserGridTemplate, GridDataAccessManager>
    {
        protected override IEnumerable<UserGridTemplate> InternalLoadItems(Dictionary<string, object> parameters)
        {
            return CurrentDataAccessManager.GetUserGridTemplates(parameters["GridTemplateId"].ToString());            
        }
    }
}
