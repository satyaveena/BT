﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class UserGridTemplate : EditableObject<GridDataAccessManager>
    {        
        public string UserGridTemplateId
        {
            get { return Id; }            
        }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set
            {
                SetChanged();
                _userId = value;
            }
        }

        //For example: btadmin
        public string UserLoginName { get; internal set; }

        //Fist name, Last name
        public string UserDisplayName { get; internal set; }

        private string _gridTemplateId;
        public string GridTemplateId
        {
            get { return _gridTemplateId; }
            set
            {
                SetChanged();
                _gridTemplateId = value;
            }
        }

        private int _sequence;
        public int Sequence
        {
            get { return _sequence; }
            set
            {
                SetChanged();
                _sequence = value;
            }
        }

        private string _rowExpensionRight;
        public string RowExpensionRight
        {
            get { return _rowExpensionRight; }
            set
            {
                SetChanged();
                _rowExpensionRight = value;
            }
        }

        public bool IsAssigned { get; set; }

        protected override void PersistAsNew()
        {
            CurrentDataAccessManager.CreateUserGridTemplate(this);
        }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateUserGridTemplate(this);
        }

        protected override void PersistAsDelete()
        {
            CurrentDataAccessManager.DeleteUserGridTemplate(Id);
        }
    }
}
