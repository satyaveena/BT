﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.Grid
{
    public enum FieldCodeStatus
    {
        Usable = 0,
        Disabled = 1,
        Expired = 2,
        FutureDate=3
    }
}
