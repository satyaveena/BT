﻿using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Grid;
using BTNextGen.VelocityCaching;
using BTNextgen.Grid.Cart;

namespace BTNextgen.Grid
{
    public class CartGridContext
    {
        internal string OrganizationId { get; set; }

        internal string UserId { get; set; }

        private GridManager _currentGridManager;

        private CartGridManager _currentCartGridManager;

        private GridDataAccessManager _currentGridDataAccessManager;

        private CartGridDataAccessManager _currentCartGridDataAccessManager;

        public GridManager GridManager { get { return CreateGridManager(); }}

        public CartGridManager CartGridManager { get { return CreateCartGridManager(); } }

        /// <summary>
        /// Current User/Organization Context.
        /// </summary>
        public static CartGridContext Current
        {
            get {
                return GetCurrentCartGridContext();
            }
        }

        internal CartGridContext()
        {

        }

        private static CartGridContext GetCurrentCartGridContext()
        {
            var cacheKey = GetCurrentCartGridContextCacheKey();
            var currentCartGridContext = VelocityCacheManager.Read(cacheKey);
            if (currentCartGridContext == null)
            {
                currentCartGridContext = CreateContext(SiteContext.Current.OrganizationId, SiteContext.Current.UserId);
                VelocityCacheManager.Write(cacheKey, currentCartGridContext, GridCacheConstants.CommonGridCacheLevel);
            }
            return (CartGridContext) currentCartGridContext;
        }

        private static string GetCurrentCartGridContextCacheKey()
        {
            return "CurrentCartGridContext_Key";
        }

        public void Impersonate(string organizationId, string userId)
        {
            OrganizationId = organizationId;
            UserId = userId;
            //
            _currentGridDataAccessManager.UserId = userId;
            _currentGridDataAccessManager.OrganizationId = organizationId;

            _currentCartGridDataAccessManager.UserId = userId;
            _currentCartGridDataAccessManager.OrganizationId = organizationId;
            //
            _currentGridDataAccessManager.Initialize();
            _currentCartGridDataAccessManager.Initialize();            
        }

        public void Impersonate(string organizationId)
        {
            Impersonate(organizationId, UserId);
        }

        public void UndoImpersonate()
        {
            OrganizationId = SiteContext.Current.OrganizationId;
            UserId = SiteContext.Current.UserId;
            //
            _currentGridDataAccessManager.UserId = UserId;
            _currentGridDataAccessManager.OrganizationId = OrganizationId;

            _currentCartGridDataAccessManager.UserId = UserId;
            _currentCartGridDataAccessManager.OrganizationId = OrganizationId;
            //
            _currentGridDataAccessManager.Initialize();
            _currentCartGridDataAccessManager.Initialize();            
        }
       
        private void Initialize()
        {
            _currentGridDataAccessManager = CreateGridDataAccessManager();
            _currentGridDataAccessManager.Initialize();
            
            //
            _currentCartGridDataAccessManager = CreateCartGridDataAccessManager();
            _currentCartGridDataAccessManager.Initialize();
        }        

        internal GridDataAccessManager CreateGridDataAccessManager()
        {
            var currentGridDataAccessManager = DataAccessManagerFactory.CreateDataAccessManager<GridDataAccessManager>();
            currentGridDataAccessManager.OrganizationId = this.OrganizationId;
            currentGridDataAccessManager.UserId = this.UserId;            
            return currentGridDataAccessManager;
        }

        internal CartGridDataAccessManager CreateCartGridDataAccessManager()
        {
            var currentCartGridDataAccessManager = DataAccessManagerFactory.CreateDataAccessManager<CartGridDataAccessManager>();
            currentCartGridDataAccessManager.OrganizationId = this.OrganizationId;
            currentCartGridDataAccessManager.UserId = this.UserId;
            return currentCartGridDataAccessManager;
        }

        private GridManager CreateGridManager()
        {
            return _currentGridManager ?? (_currentGridManager = new GridManager {CurrentDataAccessManager = _currentGridDataAccessManager});
        }

        private CartGridManager CreateCartGridManager()
        {
            return _currentCartGridManager ?? (_currentCartGridManager = new CartGridManager() {CurrentDataAccessManager = _currentCartGridDataAccessManager});
        }       

        private static CartGridContext CreateContext(string organizationId, string userId)
        {
            var cartGridContext = new CartGridContext {OrganizationId = organizationId, UserId = userId};
            cartGridContext.Initialize();
            return cartGridContext;            
        }

        /// <summary>
        /// Unique current DataAccessManager per request
        /// </summary>
        /// <typeparam name="TD"></typeparam>
        /// <returns></returns>
        internal TD CurrentDataAccessManager<TD>() where TD:DataAccessManager
        {
            var type = typeof(TD);
            switch (type.Name)
            {
                case "GridDataAccessManager":
                    return _currentGridDataAccessManager as TD;
                case "CartGridDataAccessManager":
                    return _currentCartGridDataAccessManager as TD;
                default:
                    return null;
            }
        }                
    }
}
