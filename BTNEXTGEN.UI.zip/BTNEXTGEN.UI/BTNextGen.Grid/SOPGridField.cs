﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class SOPGridField
    {
        public int SOPGridFieldId { get; set; }

        public string Literal { get; set; }

        public int Sequence { get; set; }

        public int CharacterLimit { get; set; }
    }
}
