﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextgen.Grid
{
    public class GridTemplateLineList : EditableObjectCollection<GridTemplateLine, GridDataAccessManager>
    {
        protected override IEnumerable<GridTemplateLine> InternalLoadItems(Dictionary<string, object> parameters)
        {
            var gridTemplateId = parameters["GridTemplateId"].ToString();
            var pageIndex = (int?) (parameters["PageIndex"]);
            var pageSize = (int?) (parameters["PageSize"]);
            if (pageIndex != null & pageSize != null)
                return CurrentDataAccessManager.GetGridTemplateLinesWithPaging(gridTemplateId, pageIndex, pageSize);
            else
                return CurrentDataAccessManager.GetGridTemplateLines(gridTemplateId);
        }

        /// <summary>
        /// Sort grid field column by the gridFieldList sequence
        /// </summary>
        /// <param name="gridFieldList"></param>
        //public void SortByGridFieldsOrder(GridFieldList gridFieldList)
        //{
        //    foreach (var gridTemplateLine in Items)
        //    {
        //        gridTemplateLine.SortByGridFieldSequence(gridFieldList);
        //    }
        //}
        public override void Save()
        {
            if (Items.Count > 0 && !string.IsNullOrEmpty(Items[0].GridTemplateId))
            {
                CurrentDataAccessManager.UpdateGridFieldPositionInTemplate(Items[0].GridTemplateId);
            }
            base.Save();
        }
    }
}
