﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextgen.Grid;

namespace BTNextGen.Grid
{
    public class UserPreference : EditableObject<GridDataAccessManager>
    {        
        private string _primaryCartId;
        public string PrimaryCartId
        {
            get { return _primaryCartId; }
            set
            {
                SetChanged();
                _primaryCartId = value;
            }
        }

        private string _defaultGridTemplateId;
        public string DefaultGridTemplateId
        {
            get { return _defaultGridTemplateId; }
            set
            {
                SetChanged();
                _defaultGridTemplateId = value;
            }
        }

        public int DefaultQuantity { get; set; }

        protected override void PersistAsUpdate()
        {
            CurrentDataAccessManager.UpdateUserPreference(this);
        }
    }
}
