﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid;
using BTNextGen.Grid.DataAccess;
using BTNextGen.Grid.Exception;

namespace BTNextgen.Grid
{
    public abstract class EditableObject<TD> where TD : DataAccessManager
    {
        protected bool HasChanged;

        protected bool IsLoading;

        internal bool RemovedIndicator { get; set; }        

        public string Id { get; set; }//Object primary Key               

        protected TD CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<TD>(); }
        }

        protected EditableObject()
        {
            
        }

        protected EditableObject(string id)
        {
            BeginDataLoading();
            this.LoadById(id);
            EndDataLoading();
        }
       
        protected void SetChanged()
        {
            if(!IsLoading)
                HasChanged = true;
        }

        protected void SetUnChanged()
        {
            HasChanged = false;
        }

        internal bool IsDataChanged()
        {
            return HasChanged;
        }

        internal void BeginDataLoading()
        {
            IsLoading = true;
        }

        internal void EndDataLoading()
        {
            IsLoading = false;
        }

        public void MarkRemove()
        {
            RemovedIndicator = true;
        }

        protected virtual void Validate()
        {

        }       

        public virtual void Save()
        {
            Validate();
            //            
            try
            {
                if (!CurrentDataAccessManager.TransactionStarted)
                {
                    PersistWithTransactionOwner();
                }
                else
                {
                    InternalSaveObjects();
                }
            }
            catch (CartGridSaveFailedException ex)
            {
                Logger.LogException(ex);
                throw new CartGridSaveFailedException(ex.Message);
                //throw new CartGridSaveFailedException("Internal database error.");
            }            
        }

        private void InternalSaveObjects()
        {
            if (RemovedIndicator && !IsCascaseDelete())
            {
                MarkSubObjectToBeRemoved();
                SaveSubObjects();
                Persist();
                SetUnChanged();
            }
            else
            {
                Persist();
                SaveSubObjects();
                SetUnChanged();
            }
        }

        /// <summary>
        /// Check if supporting CascaseDelete by database or not.
        /// Default: the CascaseDelete is supported by the database.
        /// </summary>
        /// <returns></returns>
        protected bool IsCascaseDelete()
        {
            return true;
        }

        protected virtual void MarkSubObjectToBeRemoved()
        {
            
        }

        protected virtual void SaveSubObjects()
        {
            
        }

        private void PersistWithTransactionOwner()
        {
            try
            {
                CurrentDataAccessManager.BeginTransaction();
                //
                InternalSaveObjects();    
                //
                CurrentDataAccessManager.CommitTransaction();
            }
            catch (Exception)
            {
                CurrentDataAccessManager.RollBackTransaction();
                throw;
            }
        }

        private void Persist()
        {
            //No primary->create new.
            if(string.IsNullOrEmpty(Id))
            {
                Id = Guid.NewGuid().ToString("B");//Create Primary Key
                PersistAsNew();
            }
            else
            {
                if (RemovedIndicator)
                    //Delete from repository
                    PersistAsDelete();
                else
                {
                    if (IsDataChanged())
                        PersistAsUpdate();
                }
            }
        }

        public void LoadById(string id)
        {
            Id = id;
            LoadById();
        }

        protected virtual void LoadById()
        {
            CurrentDataAccessManager.LoadById(this);
        }

        /// <summary>
        /// Create new and return PrimaryKey
        /// </summary>
        /// <returns></returns>
        protected virtual void PersistAsNew()
        {
            
        }

        protected virtual void PersistAsUpdate()
        {
            //All DAO
        }

        protected virtual void PersistAsDelete()
        {
            //All DAO
        }        
    }
}
