﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid.Helpers;
using BTNextgen.Grid.Cart.Shared;
using Microsoft.SqlServer.Server;
using CartMixMode = BT.TS360Constants.CartMixMode;
using ExceptionCategory = BT.TS360Constants.ExceptionCategory;

namespace BTNextGen.Grid.DataAccess
{
    public class CartGridDAOManager : DAOManager
    {
        private const int LongStoreRunningTimeOut = 180;
        private const string BackgroundProcessCode = "1000";

        public void SetUserId(string id)
        {
            UserId = id;
        }
        public void SetOrgId(string id)
        {
            OrganizationId = id;
        }
        #region CartLineExtension methods

        public DataSet GetCartGridExtension(List<string> lineItemIdList, bool shouldValidate, string errorCodeFilter)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_CART_GRID_HEADERS, conn);
            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured) { Value = DataAccessHelper.GenerateDataRecords(lineItemIdList, "BasketLineItemID") };
            sqlParameter[1] = new SqlParameter("@ShouldValidateIndicator", SqlDbType.Bit) { Value = shouldValidate };
            sqlParameter[2] = new SqlParameter("@ValidationTypes", SqlDbType.VarChar, 255) { Value = errorCodeFilter };
            sqlParameter[3] = new SqlParameter("@u_org_id", OrganizationId);
            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public string CreateCartLineExtension(DataSet ds)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region CartLineItem methods

        public DataSet GetErrorLineItems(string cartId, string errorCodeFilter, int pageSize, int pageNumber,
            string orderedBy, out int totalPage, string direction)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_ERROR_LINE_ITEMS, conn);

            var sqlParameter = new SqlParameter[8];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@ValidationTypes", errorCodeFilter);
            sqlParameter[2] = new SqlParameter("@PageNumber", pageNumber);
            sqlParameter[3] = new SqlParameter("@pageSize", pageSize);
            if (string.IsNullOrEmpty(orderedBy))
                sqlParameter[4] = new SqlParameter("@SortBy", DBNull.Value);
            else
                sqlParameter[4] = new SqlParameter("@SortBy", orderedBy);
            sqlParameter[5] = new SqlParameter("@TotalPage", SqlDbType.Int) { Direction = ParameterDirection.Output };
            sqlParameter[6] = new SqlParameter("@u_org_id", OrganizationId);

            bool inputDirection = string.Compare(direction, "desc", StringComparison.OrdinalIgnoreCase) == 0 ||
                                  string.Compare(direction, "descending", StringComparison.OrdinalIgnoreCase) == 0 ||
                                  direction == "1";
            sqlParameter[7] = new SqlParameter("@Direction", inputDirection);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            totalPage = DataAccessHelper.ConvertToInt(cmd.Parameters["@TotalPage"].Value);
            return ds;
        }
        //public DataSet GetCartGridLines(List<string> lineItemIdList, bool shouldValidate, string validationTypes, out bool hasError, out string errorCode)
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_CART_GRID_LINES, conn);

        //    var sqlParameter = new SqlParameter[7];
        //    sqlParameter[0] = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured) { Value = DataAccessHelper.GenerateDataRecords(lineItemIdList, "BasketLineItemID") };
        //    //sqlParameter[0] = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured)
        //    //{
        //    //    Value = DataAccessHelper.GenerateDataRecords(new List<string> { lineItemId }, "BasketLineItemID")

        //    //};
        //    sqlParameter[1] = new SqlParameter("@ShouldValidateIndicator", shouldValidate);
        //    sqlParameter[2] = new SqlParameter("@ValidationTypes", validationTypes);
        //    sqlParameter[3] = new SqlParameter("@u_org_id", OrganizationId);
        //    sqlParameter[4] = new SqlParameter("@u_user_id", UserId);
        //    sqlParameter[5] = new SqlParameter("@HasError", SqlDbType.Bit) { Direction = ParameterDirection.Output };
        //    sqlParameter[6] = new SqlParameter("@ErrorCodes", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
        //    cmd.Parameters.AddRange(sqlParameter);
        //    var da = new SqlDataAdapter(cmd);
        //    var ds = new DataSet();
        //    conn.Open();
        //    try
        //    {
        //        da.Fill(ds);
        //        HandleCartGridException(cmd);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //    hasError = DataAccessHelper.ConvertToBool(cmd.Parameters["@HasError"]);
        //    errorCode = DataAccessHelper.ConvertToString(cmd.Parameters["@ErrorCodes"]);
        //    return ds;
        //}

        //public DataSet FindGridFieldCodeInCart(string cartId, string gridFieldId, string gridCodeId, string gridText, int pageSize, int pageNumber, string orderBy, bool direction, out int totalPage)
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_FIND_GRID_FIELD_CODE_IN_CART, conn);

        //    var sqlParameter = new SqlParameter[9];
        //    sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
        //    sqlParameter[1] = new SqlParameter("@GridFieldID", gridFieldId);
        //    sqlParameter[2] = new SqlParameter("@GridCodeID", gridCodeId);
        //    sqlParameter[3] = new SqlParameter("@FreeText", gridText);
        //    sqlParameter[4] = new SqlParameter("@PageSize", pageSize);
        //    sqlParameter[5] = new SqlParameter("@PageNumber", pageNumber);
        //    sqlParameter[6] = new SqlParameter("@SortBy", orderBy);
        //    sqlParameter[7] = new SqlParameter("@Direction", direction);
        //    sqlParameter[8] = new SqlParameter("@TotalLines", SqlDbType.Int) { Direction = ParameterDirection.Output };

        //    cmd.Parameters.AddRange(sqlParameter);
        //    var da = new SqlDataAdapter(cmd);
        //    var ds = new DataSet();
        //    conn.Open();
        //    try
        //    {
        //        da.Fill(ds);
        //        HandleCartGridException(cmd);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //    totalPage = DataAccessHelper.ConvertToInt(cmd.Parameters["@TotalLines"]);
        //    return ds;
        //}
        public void UpdateCartGridLine(string cartGridLineId, string cartLineItemId, int quantity, int sequence, Dictionary<string, object> paramList)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_CART_GRID_LINE);
            var sqlParameter = new SqlParameter[34];
            sqlParameter[0] = new SqlParameter("@BasketGridLineID", cartGridLineId);
            sqlParameter[1] = new SqlParameter("@BasketLineItemID", cartLineItemId);

            int i = 2;
            foreach (var item in paramList)
            {
                sqlParameter[i] = new SqlParameter(item.Key, item.Value);
                i++;
            }
            sqlParameter[32] = new SqlParameter("@Quantity", quantity);
            sqlParameter[33] = new SqlParameter("@u_user_id", UserId);
            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        //public void UpdateAllCartGridLines(string userId, List<SqlDataRecord> basketGridLines)
        //{
        //    var conn = this.CreateSqlConnection();
        //    //var dbConnection = CreateSqlConnection();
        //    var command = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_ALL_CART_GRID_LINE, conn);

        //    //<Parameter>
        //    var sqlParameters = new SqlParameter[2];
        //    sqlParameters[0] = new SqlParameter("@GridLineInfo", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = basketGridLines };
        //    sqlParameters[1] = new SqlParameter("@u_user_id", userId);
        //    //sqlParameters[2] = new SqlParameter("@BasketLineItemId", basketLineItemID);
        //    command.Parameters.AddRange(sqlParameters);
        //    conn.Open();
        //    try
        //    {
        //        command.ExecuteNonQuery();
        //        HandleCartGridException(command);
        //    }
                
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}

        public void UpdateAllCartGridLines(string userId, IEnumerable<SqlDataRecord> basketGridLines, List<string> deletedGridLines)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_ALL_CART_GRID_LINE, conn);
            List<string> deletedDistinctGridLines = (deletedGridLines != null) ? deletedGridLines.Distinct().ToList() : null;
            if (basketGridLines == null || !basketGridLines.Any()) basketGridLines = null;
            //<Parameter>
            var sqlParameters = new SqlParameter[3];
            sqlParameters[0] = new SqlParameter("@GridLineInfo", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = basketGridLines };
            sqlParameters[1] = new SqlParameter("@u_user_id", userId);
            sqlParameters[2] = new SqlParameter("@DeletedBasketGridLineIDs", SqlDbType.Structured)
                              {
                                  Value =
                                      DataAccessHelper
                                      .GenerateDataRecords(
                                          deletedDistinctGridLines,
                                          "GUID")
                              };

            command.Parameters.AddRange(sqlParameters);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartGridException(command);
            }

            finally
            {
                conn.Close();
            }
        }

        public void DeleteCartGridLine(string id)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_CART_GRID_LINE);
            var sqlParameter = new SqlParameter("@BasketGridLineID", id);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public void UpdateCartGridHeader(List<string> lineItemIds)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.PROC_UPDATE_GRID_FIELD_POSITION_IN_TEMPLATE_HEADER, conn);

            //var lineItemIDParam = new SqlParameter("@BasketLineItemIds", SqlDbType.NVarChar, 50)
            //{
            //    Direction = ParameterDirection.Input,
            //    Value = lineItemId
            //};
            var lineItemIDParam = new SqlParameter("@BasketLineItemIds", SqlDbType.Structured)
            {
                Value = DataAccessHelper.GenerateDataRecords(lineItemIds, "BasketLineItemID")
            };
            command.Parameters.Add(lineItemIDParam);

            var orgIDParam = new SqlParameter("@u_org_id", SqlDbType.NVarChar, 50)
                                 {
                                     Direction = ParameterDirection.Input,
                                     Value = OrganizationId
                                 };
            command.Parameters.Add(orgIDParam);

            var userIDParam = new SqlParameter("@u_user_id", UserId);
            command.Parameters.Add(userIDParam);

            var gridTemplateIDParam = new SqlParameter("@GridTemplateID", DBNull.Value);
            command.Parameters.Add(gridTemplateIDParam);

            //var queryParam = new SqlParameter("@Query", SqlDbType.NVarChar, -1)
            //                     {
            //                         Direction = ParameterDirection.Output
            //                     };
            //command.Parameters.Add(queryParam);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet GetCartLineItemNoteQuantities(List<string> lineItemIds)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_CART_LINE_ITEM_NOTE_QUANTITES, conn);

            var sqlParameter = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured)
            {
                Value = DataAccessHelper.GenerateDataRecords(lineItemIds, "BasketLineItemID")
            };
            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        public DataSet GetNotesByBTKeys(string cartId, List<string> btkeys)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_NOTES_BY_BTKEYS, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@BTKeys", SqlDbType.Structured) { Value = DataAccessHelper.GenerateDataRecords(btkeys, "BTKey") };

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetNotesByBTKeys(string cartId, string userId, List<string> btkeys, List<string> lineItemIds = null)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_USER_NOTES_BY_BTKEYS, conn);

            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@UserID", userId);
            if (btkeys == null) btkeys = new List<string>();
            sqlParameter[2] = new SqlParameter("@BTKeyList", SqlDbType.Structured)
                                  {
                                      Value = DataAccessHelper.GenerateDataRecords(btkeys, "BTKey")
                                  };
            if (lineItemIds == null) lineItemIds =  new List<string>();
            sqlParameter[3] = new SqlParameter("@LineItemIdList", SqlDbType.Structured)
                                  {
                                      Value = DataAccessHelper.GenerateDataRecords(lineItemIds, "BasketLineItemID")
                                  };

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
       
        public void UpdateCartLineItemNoteQuantity(string cartLineItemId, string cartUserLineItemNoteId, string cartUserLineItemId, int? quantity, string note)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_CART_LINE_ITEM_NOTE_QUANTITY,conn);

            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@BasketLineItemID", cartLineItemId);
            if (string.IsNullOrEmpty(cartUserLineItemNoteId))
                sqlParameter[1] = new SqlParameter("@BasketUserLineItemNoteID", DBNull.Value);
            else
                sqlParameter[1] = new SqlParameter("@BasketUserLineItemNoteID", cartUserLineItemNoteId);
            if (string.IsNullOrEmpty(cartUserLineItemId))
                sqlParameter[2] = new SqlParameter("@BasketUserLineItemID", DBNull.Value);
            else
                sqlParameter[2] = new SqlParameter("@BasketUserLineItemID", cartUserLineItemId);
            if (quantity == null)
                sqlParameter[3] = new SqlParameter("@Quantity", DBNull.Value);
            else
                sqlParameter[3] = new SqlParameter("@Quantity", quantity);
            sqlParameter[4] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[5] = new SqlParameter("@Note", note);

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteCartLineItemNoteQuantity(string cartLineItemId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_CART_LINE_ITEM_QUANTITY,conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketLineItemID", cartLineItemId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

        }

        public void RemoveGridFromLineItems(List<string> lineItemIdList, bool keepQuantity)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_REMOVE_GRID_FROM_LINE_ITEMS, conn);
            //List<SqlDataRecord> inputDS = DataConverter.ConvertCartLineExtensionToDataSet(lineItemIdList);
            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured) { Value = DataAccessHelper.GenerateDataRecords(lineItemIdList, "BasketLineItemID") };
            sqlParameter[1] = new SqlParameter("@UserID", UserId);
            sqlParameter[2] = new SqlParameter("@KeepQuantityIndicator", keepQuantity);

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }

        public void ApplyTemplateToCartTitles(string gridTemplateId, string cartId, bool nonGridOnly, bool replace, bool allowDuplicate, 
            bool applyUnauthorized = false)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_APPLY_TEMPLATE_TO_TITLES, conn);
            //TODO: Need to revise 
            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[1] = new SqlParameter("@UserID", UserId);
            sqlParameter[2] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[3] = new SqlParameter("@NonGridOnly", nonGridOnly);
            sqlParameter[4] = new SqlParameter("@Replace", replace);
            sqlParameter[5] = new SqlParameter("@ApplyUnauthorizedCodes", applyUnauthorized);

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }

            finally
            {
                conn.Close();
            }
        }

        public void DeleteZeroQuantityTitlesAndGridLines(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_ZERO_QUANTITY, conn);
            var sqlParameter = new SqlParameter[1];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            //sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }
        #endregion

        #region CartGrid methods
        public DataSet GetCartSummary(out int nonRankedCount, string cartId, string userId = "")
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(BT.TS360Constants.StoredProcedureName.PROC_BASKET_MANAGEMENT_GET_BASKET_BYID, conn);
            //var sqlParameter = new SqlParameter("@BasketSummaryID", cartId);

            var sqlParameters = new SqlParameter[3];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", cartId);
            if (!string.IsNullOrEmpty(userId))
                sqlParameters[1] = new SqlParameter("@UserID", userId);
            else
            {
                sqlParameters[1] = new SqlParameter("@UserID", DBNull.Value);
            }
            sqlParameters[2] = new SqlParameter("@PendingRankCount", SqlDbType.Int) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameters);
            conn.Open();
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();

            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            nonRankedCount = DataAccessHelper.ConvertToInt(cmd.Parameters["@PendingRankCount"].Value);

            return ds;
        }

        public DataSet GetGridSummary(string cartId, string field1Type, string field2Type, string field3Type, bool viewMineOnly, string sortBy, bool? direction)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_SUMMARY, conn);
            var sqlParameter = new SqlParameter[8];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            if (!string.IsNullOrEmpty(field1Type))
            {
                sqlParameter[1] = new SqlParameter("@GridField1Type", field1Type);
            }
            else
            {
                sqlParameter[1] = new SqlParameter("@GridField1Type", DBNull.Value);
            }
            if (!string.IsNullOrEmpty(field2Type))
            {
                sqlParameter[2] = new SqlParameter("@GridField2Type", field2Type);
            }
            else
            {
                sqlParameter[2] = new SqlParameter("@GridField2Type", DBNull.Value);
            }
            if (!string.IsNullOrEmpty(field3Type))
            {
                sqlParameter[3] = new SqlParameter("@GridField3Type", field3Type);
            }
            else
            {
                sqlParameter[3] = new SqlParameter("@GridField3Type", DBNull.Value);
            }

            sqlParameter[4] = new SqlParameter("@u_user_ID", UserId);
            sqlParameter[5] = new SqlParameter("@Is_ViewMine_Only", viewMineOnly);

            if (string.IsNullOrEmpty(sortBy))
            {
                sqlParameter[6] = new SqlParameter("@SortBy", DBNull.Value);
            }
            else
            {
                sqlParameter[6] = new SqlParameter("@SortBy", sortBy);
            }
            if (direction == null)
            {
                sqlParameter[7] = new SqlParameter("@Direction", DBNull.Value);
            }
            else
            {
                sqlParameter[7] = new SqlParameter("@Direction", direction);
            }

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();

            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public DataSet GetGridSummaryDetails(string cartId, string gridField1Type, string gridField2Type, string gridField3Type, string gridValue1, string gridValue2, string gridValue3, int pageNumber, int pageSize, string orderBy, bool? direction, bool viewMineOnly, out int totalItems)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_SUMMARY_DETAIL, conn);
            var sqlParameter = new SqlParameter[13];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@GridField1ID", gridValue1);
            sqlParameter[2] = new SqlParameter("@GridField2ID", gridValue2);
            sqlParameter[3] = new SqlParameter("@GridField3ID", gridValue3);
            sqlParameter[4] = new SqlParameter("@PageNumber", pageNumber);
            sqlParameter[5] = new SqlParameter("@PageSize", pageSize);
            if (string.IsNullOrEmpty(orderBy))
            {
                sqlParameter[6] = new SqlParameter("@OrderBy", DBNull.Value);
            }
            else
            {
                sqlParameter[6] = new SqlParameter("@OrderBy", orderBy);
            }
            if (direction == null)
            {
                sqlParameter[7] = new SqlParameter("@Direction", DBNull.Value);
            }
            else
            {
                sqlParameter[7] = new SqlParameter("@Direction", direction);
            }
            if (viewMineOnly)
                sqlParameter[8] = new SqlParameter("@u_user_id", UserId);
            else
            {
                sqlParameter[8] = new SqlParameter("@u_user_id", DBNull.Value);
            }
            sqlParameter[9] = new SqlParameter("@TotalItemCount", SqlDbType.Int) { Direction = ParameterDirection.Output };

            sqlParameter[10] = new SqlParameter("@GridField1Type", gridField1Type);
            sqlParameter[11] = new SqlParameter("@GridField2Type", gridField2Type);
            sqlParameter[12] = new SqlParameter("@GridField3Type", gridField3Type);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();

            conn.Open();

            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                totalItems = DataAccessHelper.ConvertToInt(sqlParameter[12].Value);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public void AddProductTocart(List<SqlDataRecord> products, string toCartId, List<SqlDataRecord> cartGridLines, out string PermissionViolationMessage,
            out int totalAddingQuantity)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_ADD_PRODUCT_TO_CART, conn);
            cmd.CommandTimeout = 180;
            var sqlParameter = new SqlParameter[11];
            sqlParameter[0] = new SqlParameter("@DestinationBasketSummaryID", toCartId) { Direction = ParameterDirection.InputOutput };
            sqlParameter[1] = new SqlParameter("@UserID", UserId);
            if (products == null || products.Count == 0)
            {
                sqlParameter[2] = new SqlParameter("@BasketLineItems", SqlDbType.Structured);
                sqlParameter[2].Value = null;
            }
            else
            {
                sqlParameter[2] = new SqlParameter("@BasketLineItems", SqlDbType.Structured) { Value = products.Distinct(new SqlDataRecordComparerByBTKey()).ToList() };
            }
            sqlParameter[3] = new SqlParameter("@BasketLineItemOrderStatus", "A");
            sqlParameter[4] = new SqlParameter("@DeleteSourceLineItems", false);
            if (cartGridLines == null || cartGridLines.Count == 0)
            {
                sqlParameter[5] = new SqlParameter("@utblBasketGridLine", SqlDbType.Structured);
                sqlParameter[5].Value = null;
            }
            else
            {
                sqlParameter[5] = new SqlParameter("@utblBasketGridLine", SqlDbType.Structured) { Value = cartGridLines };
            }
            sqlParameter[6] = new SqlParameter("@MaxLinesPerCartNumber", CartHelper.MaxLinesPerCart);
            sqlParameter[7] = new SqlParameter("@All_or_MyQty_or_TitleOnly", DBNull.Value);
            sqlParameter[8] = new SqlParameter("@OverRide_Warning", DBNull.Value);
            sqlParameter[9] = new SqlParameter("@PermissionViolationMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            sqlParameter[10] = new SqlParameter("@TotalAddingQuantity", SqlDbType.Int) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
                PermissionViolationMessage = cmd.Parameters["@PermissionViolationMessage"].Value as string;
                if (
                    !int.TryParse(cmd.Parameters["@TotalAddingQuantity"].Value.ToString(),
                        out totalAddingQuantity))
                {
                    totalAddingQuantity = 0;
                }
            }
            finally
            {
                conn.Close();
            }
        }

        public void AddBatchEntryToBackground(string fileName, string toCartId, string userID, List<SqlDataRecord> cartGridLines,
            string eSuppliers, Boolean IsValidateBTKey, string organizationID)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_ADD_BATCH_TO_BACKGROUND_PROCESSING, conn);
            cmd.CommandTimeout = 180;
            var sqlParameter = new SqlParameter[7];
            sqlParameter[0] = new SqlParameter("@DestinationBasketSummaryID", toCartId);
            sqlParameter[1] = new SqlParameter("@UserID", UserId);
            sqlParameter[2] = new SqlParameter("@FilePath", fileName);
            
            if (cartGridLines == null || cartGridLines.Count == 0)
            {
                sqlParameter[3] = new SqlParameter("@utblBasketGridLine", SqlDbType.Structured);
                sqlParameter[3].Value = null;
            }
            else
            {
                sqlParameter[3] = new SqlParameter("@utblBasketGridLine", SqlDbType.Structured) { Value = cartGridLines };
            }

            sqlParameter[4] = new SqlParameter("@eSuppliers", eSuppliers);
            sqlParameter[5] = new SqlParameter("@IsValidateBTKey", IsValidateBTKey);
            sqlParameter[6] = new SqlParameter("@OrganizationID", organizationID);

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }
        /* Removed unused parameters and merged with AddProductTocart(List<SqlDataRecord> products, string toCartId, List<SqlDataRecord> cartGridLines)
            public void AddProductTocart(List<SqlDataRecord> products, string toCartId, List<SqlDataRecord> cartGridLines, string toCartName, string toFolderId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_ADD_PRODUCT_TO_CART, conn);
            var sqlParameter = new SqlParameter[9];
            sqlParameter[0] = new SqlParameter("@DestinationBasketSummaryID", toCartId) { Direction = ParameterDirection.InputOutput };
            //sqlParameter[1] = new SqlParameter("@DestinationBasketName", toCartName);
            //sqlParameter[2] = new SqlParameter("@DestinationBasketFolderID", toFolderId);
            sqlParameter[1] = new SqlParameter("@UserID", UserId);
            if (products == null)
            {
                sqlParameter[2] = new SqlParameter("@BasketLineItems", SqlDbType.Structured);
            }
            else
            {
                sqlParameter[2] = new SqlParameter("@BasketLineItems", SqlDbType.Structured) { Value = products };
            }
            sqlParameter[3] = new SqlParameter("@BasketLineItemOrderStatus", "A");
            sqlParameter[4] = new SqlParameter("@DeleteSourceLineItems", false);

            //sqlParameter[7] = new SqlParameter("@utblISBNUPC", SqlDbType.Structured);

            if (cartGridLines == null || cartGridLines.Count == 0)
            {
                sqlParameter[5] = new SqlParameter("@utblBasketGridLine", SqlDbType.Structured);
            }
            else
            {                
                sqlParameter[5] = new SqlParameter("@utblBasketGridLine", SqlDbType.Structured) { Value = cartGridLines };
            }

            sqlParameter[6] = new SqlParameter("@All_or_MyQty_or_TitleOnly", DBNull.Value);
            sqlParameter[7] = new SqlParameter("@OverRide_Warning", DBNull.Value);
            sqlParameter[8] = new SqlParameter("@PermissionViolationMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }*/

        public DataSet GetGridFieldCodePositionInBasket(string lineItemId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_FIELD_POSITION_IN_CART, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketLineItemId", lineItemId);
            sqlParameter[1] = new SqlParameter("@u_org_id", OrganizationId);
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public DataSet GetGridFieldCodePositionInBasketForLineItems(List<string> lineItemIds)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_FIELD_POSITION_IN_CART_LineItems, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketLineItemIds", SqlDbType.Structured) { Value = DataAccessHelper.GenerateDataRecords(lineItemIds, "BasketLineItemID") };
            sqlParameter[1] = new SqlParameter("@u_org_id", OrganizationId);
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public DataSet CheckEBookAccountForOrg(string cartId, string orgId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_CHECK_EBOOK_ACCOUNT_INFO, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryId", cartId);
            sqlParameter[1] = new SqlParameter("@u_org_id", orgId);
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public void TransferCartToUser(string cartId, List<SqlDataRecord> userIds, bool keepCopyIndicator)
        {
            if (userIds.Count == 0 || string.IsNullOrEmpty(cartId))
            { }
            else
            {
                var conn = this.CreateSqlConnection();
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_TRANSFER_CART_TO_USERS, conn);
                var sqlParameter = new SqlParameter[4];
                sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);

                sqlParameter[1] = new SqlParameter("@UserIDs", SqlDbType.Structured);
                sqlParameter[1].Value = userIds != null && userIds.Count > 0 ? (object)userIds : null;

                sqlParameter[2] = new SqlParameter("@KeepCopyIndicator", keepCopyIndicator);
                sqlParameter[3] = new SqlParameter("@u_user_id", UserId);

                cmd.Parameters.AddRange(sqlParameter);

                conn.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    HandleCartGridException(cmd);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        /// <summary>
        /// Append, Replace or Delete notes to all titles in a cart.
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="note"></param>
        /// <param name="requestType">Append, Replace or Delete</param>
        public void ModifyNoteToAllTitles(string cartId, string note, string requestType)
        {
            // if note is null, store will delete all notes.

            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_MODIFY_NOTE_TO_ALL_TITLES, conn);
            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@Note", note);
            sqlParameter[2] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[3] = new SqlParameter("@ActionType", requestType);
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet GetLengthOfLongestNote(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_LENGTH_LONGEST_NOTE, conn);
            //var sqlParameter = new SqlParameter("@BasketSummaryID", cartId);

            var sqlParameters = new SqlParameter[1];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", cartId);
            cmd.Parameters.AddRange(sqlParameters);
            conn.Open();
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();

            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public DataSet SearchWithinCartByNote(string cartId, string facetPath, string keywork, int pageNumber, int pageSize, string orderedBy, out int totalLines)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SEARCH_WITHITN_BASKET_NOTE, conn);
            var sqlParameter = new SqlParameter[9];
            sqlParameter[0] = new SqlParameter("@FacetPath", facetPath);
            sqlParameter[1] = new SqlParameter("@Keyword", keywork);
            sqlParameter[2] = new SqlParameter("@PageNumber", pageNumber);
            sqlParameter[3] = new SqlParameter("@pageSize", pageSize);
            sqlParameter[4] = new SqlParameter("@orderBy", orderedBy);
            sqlParameter[5] = new SqlParameter("@Direction", true);
            sqlParameter[6] = new SqlParameter("@UserID", UserId);
            sqlParameter[7] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[8] = new SqlParameter("@TotalLines", SqlDbType.Int) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                totalLines = DataAccessHelper.ConvertToInt(cmd.Parameters["@TotalLines"]);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public void RemoveGridFromCart(string cartId, bool keepQuantity)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_REMOVE_GRID_FROM_CART, conn);
            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@keepQuantityIndicator", keepQuantity);
            sqlParameter[2] = new SqlParameter("@UserID", UserId);

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }

        public void SetBlankGridLineToCart(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_BLANK_GL_TO_CART, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet SplitCartToGridAndNonGrid(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SPLIT_CART_TO_GRID_AND_NONGRID, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);

            cmd.Parameters.AddRange(sqlParameter);

            var ds = new DataSet();
            var da = new SqlDataAdapter(cmd);

            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                return ds;
            }
            finally
            {
                conn.Close();
            }
        }

        public CartMixMode CheckCartContainsBothGridAndNonGridTitles(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_BASKET_MANAGEMENT_CHECK_CONTAIN_MIX, conn);
            var sqlParameter = new SqlParameter[1];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                var returnObj = cmd.ExecuteScalar();
                var result = -1;
                int.TryParse(returnObj.ToString(), out result);
                var cartMixMode = (CartMixMode) result;
                HandleCartGridException(cmd);
                return cartMixMode;
            }
            finally
            {
                conn.Close();
            }
        }

        public int ReplaceAllGridFieldCodeInCart(string cartId, GridFieldType gridFieldType, string gridCodeId, string gridText, string newGridCodeId,
            string newFreeTextId, out int totalCount)
        {
            var existingvalue = gridFieldType != GridFieldType.CallNumber ? gridCodeId : gridText;
            if (existingvalue == "-1")
            {
                existingvalue = "";
            }
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_REPLACE_ALL_GRID_FIELD_CODE_IN_BASKET, conn);
            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@GridFieldType", gridFieldType.ToString());
            sqlParameter[2] = new SqlParameter("@ExistingValue", existingvalue);
            sqlParameter[3] = new SqlParameter("@NewValue", gridFieldType != GridFieldType.CallNumber ? newGridCodeId : newFreeTextId);
            sqlParameter[4] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[5] = new SqlParameter("@RowCount", SqlDbType.Int) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();

            try
            {
                cmd.ExecuteNonQuery();

                totalCount = DataAccessHelper.ConvertToInt(sqlParameter[5].Value);

                var paramValue = cmd.Parameters["returnVal"].Value;
                if (paramValue.ToString() == BackgroundProcessCode)
                {
                    return 1;
                }

                HandleCartGridException(cmd);
                
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }

        public int ReplaceAllGridLineQuantityInCart(string cartId, int currentQty, int newQty, out int totalCount)
        {
            totalCount = 0;

            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand("procTS360ReplaceAllGridLineQuantityInBasket", conn);
            var sqlParameter = new SqlParameter[5];

            sqlParameter[0] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) {Value = cartId};
            sqlParameter[1] = new SqlParameter("@u_user_id", SqlDbType.NVarChar, 50) {Value = UserId};
            sqlParameter[2] = new SqlParameter("@CurrentQuantity", SqlDbType.Int) { Value = currentQty };
            sqlParameter[3] = new SqlParameter("@NewQuantity", SqlDbType.Int) { Value = newQty };
            sqlParameter[4] = new SqlParameter("@RowCount", SqlDbType.Int) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();

            try
            {
                cmd.ExecuteNonQuery();
                
                var paramValue = cmd.Parameters["returnVal"].Value;
                if (paramValue.ToString() == BackgroundProcessCode)
                {
                    return 1;
                }

                HandleCartGridException(cmd);
                totalCount = DataAccessHelper.ConvertToInt(sqlParameter[4].Value);
            }
            catch (SqlException sqlException)
            {
                Logger.RaiseException(sqlException, ExceptionCategory.CartGrid);
                return -1;
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }

        public bool CheckDuplicatedCartGridLineTemplate(string gridTemplateId, string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_CHECK_DUPLICATE_GRID_LINE_TEMPLATE_CART, conn);
            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[2] = new SqlParameter("@Duplicate", SqlDbType.Bit) { Direction = ParameterDirection.Output };
            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();

            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
                return Parser.ToBool(sqlParameter[2].Value);
            }
            finally
            {
                conn.Close();
            }
        }        

        public DataSet GetCountForLineItems(string cartId, List<string> lineItemIds)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_NOTE_COUNT_FOR_LINEITEM, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured) { Value = DataConverter.ConverUserIDsToDataSet(lineItemIds) };
            cmd.Parameters.AddRange(sqlParameter);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                return ds;
            }
            finally
            {
                conn.Close();
            }
        }

        #endregion
        #region Cart Grid Template methods
        //public DataSet GetDefaultCartGridTemplate(string cartId, string userId)
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_DEFAULT_CART_GRID_TEMPLATE, conn);

        //    var sqlParameter = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Value = cartId };
        //    var sqlParameterUserId = new SqlParameter("@UserId", SqlDbType.NVarChar, 50) { Value = UserId };
        //    cmd.Parameters.Add(sqlParameter);
        //    cmd.Parameters.Add(sqlParameterUserId);
        //    var da = new SqlDataAdapter(cmd);
        //    var ds = new DataSet();
        //    conn.Open();
        //    try
        //    {
        //        da.Fill(ds);
        //        HandleCartGridException(cmd);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }

        //    return ds;

        //}
        public bool HasDefaultCartGridTemplate(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_HAS_DEFAULT_CART_GRID_TEMPLATE, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@HasDefaultTemplateIndicator", SqlDbType.Bit) { Direction = ParameterDirection.Output };

            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            bool defaultTemplateIndicator = false;
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                defaultTemplateIndicator = DataAccessHelper.ConvertToBool(cmd.Parameters["@HasDefaultTemplateIndicator"]);
            }
            finally
            {
                conn.Close();
            }

            return defaultTemplateIndicator;
        }
        //public void SaveGridLinesAsAGridTemplate(List<SqlDataRecord> gridLines, string templateName, string description,
        //    bool enabledIndicator, bool needToSaveQuantity, out string newTemplateNameIfDuplicated)
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SAVE_GRID_LINES_AS_GRID_TEMPLATE, conn);
        //    var sqlParameter = new SqlParameter[10];
        //    sqlParameter[0] = new SqlParameter("@GridTemplateLines", SqlDbType.Structured) { Value = gridLines };
        //    sqlParameter[1] = new SqlParameter("@TemplateName", templateName);
        //    sqlParameter[2] = new SqlParameter("@Description", description);
        //    sqlParameter[3] = new SqlParameter("@EnabledIndicator", enabledIndicator);
        //    sqlParameter[4] = new SqlParameter("@saveQtyIndicator", needToSaveQuantity);
        //    sqlParameter[5] = new SqlParameter("@UserID", UserId);
        //    sqlParameter[6] = new SqlParameter("@NewTemplateName", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
        //    sqlParameter[7] = new SqlParameter("@IsDefault", false);
        //    sqlParameter[8] = new SqlParameter("@BasketSummaryID", DBNull.Value);
        //    sqlParameter[9] = new SqlParameter("@u_org_id", OrganizationId);
        //    cmd.Parameters.AddRange(sqlParameter);
        //    conn.Open();
        //    try
        //    {
        //        cmd.ExecuteNonQuery();
        //        HandleCartGridException(cmd);
        //        newTemplateNameIfDuplicated = DataAccessHelper.ConvertToString(cmd.Parameters["@NewTemplateName"].Value);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}
        //public void SaveGridLinesAsDefaultGridTemplate(List<SqlDataRecord> gridLines, Dictionary<string, object> fieldList, string cartId)
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SAVE_GRID_LINES_AS_GRID_TEMPLATE, conn);
        //    var sqlParameter = new SqlParameter[20];
        //    if(gridLines!= null && gridLines.Count > 0)
        //    {
        //        sqlParameter[0] = new SqlParameter("@GridTemplateLines", SqlDbType.Structured) { Value = gridLines };
        //    }
        //    else
        //    {
        //        sqlParameter[0] = new SqlParameter("@GridTemplateLines", SqlDbType.Structured) { Value = null };
        //    }
        //    sqlParameter[1] = new SqlParameter("@TemplateName", string.Empty);
        //    sqlParameter[2] = new SqlParameter("@Description", string.Empty);
        //    sqlParameter[3] = new SqlParameter("@EnabledIndicator", true);
        //    sqlParameter[4] = new SqlParameter("@saveQtyIndicator", true);
        //    sqlParameter[5] = new SqlParameter("@UserID", UserId);
        //    sqlParameter[6] = new SqlParameter("@NewTemplateName", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
        //    sqlParameter[7] = new SqlParameter("@IsDefault", true);
        //    sqlParameter[8] = new SqlParameter("@BasketSummaryID", cartId);
        //    sqlParameter[9] = new SqlParameter("@u_org_id", OrganizationId);
        //    int i = 10;
        //    foreach (var item in fieldList)
        //    {
        //        sqlParameter[i] = new SqlParameter(item.Key, item.Value);
        //        i++;
        //    }
        //    cmd.Parameters.AddRange(sqlParameter);
        //    conn.Open();
        //    try
        //    {
        //        cmd.ExecuteNonQuery();
        //        HandleCartGridException(cmd);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}
        public bool CheckDuplicateDefaultTemplateForCart(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_CART_CHECK_DUPLICATE_DEFAULT_TEMPLATE, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@Duplicate", SqlDbType.Bit) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            bool isDuplicate = false;
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                isDuplicate = Parser.ToBool(cmd.Parameters["@Duplicate"].Value);
            }
            finally
            {
                conn.Close();
            }
            return isDuplicate;
        }

        public void PasteGridLineFromClipboard360ToCart(List<SqlDataRecord> gridLines, string toCartId, bool duplicatedAllow, bool mergeQuantityBySum)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_PASTE_GRID_LINE_FROM_CLIPBOARD, conn);

            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", toCartId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[2] = new SqlParameter("@BasketGridLinesToPaste", SqlDbType.Structured) { Value = gridLines };
            
            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }
        public void CreateCopyOfCart(List<SqlDataRecord> cartIDs, string newCartName, string folderId, int copyType, bool copyESP)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_COPY_BASKETS, conn);
            cmd.CommandTimeout = LongStoreRunningTimeOut;

            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@BasketSummaryIDs", SqlDbType.Structured) { Value = cartIDs };
            sqlParameter[1] = new SqlParameter("@NewBasketName", newCartName);
            sqlParameter[2] = new SqlParameter("@UserFolderID", folderId);
            sqlParameter[3] = new SqlParameter("@u_user_id", UserId);

            if (copyType == 4)
            {
                sqlParameter[4] = new SqlParameter("@CopyType", DBNull.Value);
            }
            else
            {
                sqlParameter[4] = new SqlParameter("@CopyType", copyType);
            }

            sqlParameter[5] = new SqlParameter("@CopyESP", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = copyESP };

            cmd.Parameters.AddRange(sqlParameter);
            

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd, StoredProcedureName.PROC_COPY_BASKETS+":");
            }
            finally
            {
                conn.Close();
            }
        }

        public bool ValidateGridInCartForLibrarySystemAccount(string cartId, string accountId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_VALIDATE_GRID_IN_CART_FOR_LIBRARY_SYSTEM_ACCOUNT, conn);

            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@UserId", UserId);
            sqlParameter[2] = new SqlParameter("@AccountID", accountId);
            sqlParameter[3] = new SqlParameter("@HasError", SqlDbType.Bit) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return Parser.ToBool(sqlParameter[3].Value);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="isDeleteGridTemplate"></param>
        /// <returns></returns>
        public bool DeleteDefaultGridTemplate(string cartId, bool isDeleteGridTemplate)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_DEFAULT_GRID_TEMPLATE, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameter[1] = new SqlParameter("@IsDeleteGridTemplate", isDeleteGridTemplate);

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return true;

        }

        public void ConvertPBookToEBook(string sourceBasketSummaryID, string newCartName, string folderId, string userID, string eSupplierPreference, string digitalFormatPerference)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_CREATE_EBOOK_BASKETS, conn);
            cmd.CommandTimeout = LongStoreRunningTimeOut;

            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@SourceBasketSummaryID", sourceBasketSummaryID);
            sqlParameter[1] = new SqlParameter("@BasketName", newCartName);
            sqlParameter[2] = new SqlParameter("@BasketFolderID", folderId);
            sqlParameter[3] = new SqlParameter("@UserID", userID);
            sqlParameter[4] = new SqlParameter("@eSupplierPreference", eSupplierPreference);
            sqlParameter[5] = new SqlParameter("@DigitalFormatPreference", digitalFormatPerference);

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }


        #endregion

        #region Shared Cart

        public bool IsSharedCart(string cartId)
        {
            var isSharedCart = false;
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcIsSharedCart, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
            sqlParameter[1] = new SqlParameter("@IsSharedCart", SqlDbType.Bit) { Direction = ParameterDirection.Output };

            cmd.Parameters.Add(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                isSharedCart = Parser.ToBool(sqlParameter[1].Value);
            }
            finally
            {
                conn.Close();
            }

            return isSharedCart;
        }

        public bool IsPremiumSharedCart(string cartId)
        {
            var isPremiumSharedCart = false;
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcIsPremiumSharedCart, conn);
            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
            sqlParameter[1] = new SqlParameter("@IsPremiumSharedCart", SqlDbType.Bit) { Direction = ParameterDirection.Output };

            cmd.Parameters.Add(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                isPremiumSharedCart = Parser.ToBool(sqlParameter[1].Value);
            }
            finally
            {
                conn.Close();
            }

            return isPremiumSharedCart;
        }

        public void UpdateCartUserGroup(List<SqlDataRecord> cartUserGroupMember, string cartUserGroupId, string name, string updatedBy, bool workflowEnabled = true)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360SetBasketUserGroup);

            var cartUserGroupIdParam = new SqlParameter("@BasketUserGroupId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartUserGroupId
            };

            var userIdParam = new SqlParameter("@UserId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = UserId
            };

            var orgIdParam = new SqlParameter("@u_org_id", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = DBNull.Value
            };

            var nameParam = new SqlParameter("@Name", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = name
            };

            var descriptionParam = new SqlParameter("@Description", SqlDbType.NVarChar, 4000)
            {
                Direction = ParameterDirection.Input,
                Value = string.Empty
            };

            var cartUserGroupMemberParam = new SqlParameter("@UserGroupMember", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = cartUserGroupMember
            };

            var workflowEnabledParam = new SqlParameter("@WorkflowEnabled", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = workflowEnabled ? 1 : 0
            };

            List<SqlDataRecord> sqlDeleteMembers = null;
            var membersToDeleteParam = new SqlParameter("@MembersToDelete", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = sqlDeleteMembers
            };

            var groupModifiedByParam = new SqlParameter("@UpdatedBy", updatedBy);

            command.Parameters.AddRange(new[]{
                                        cartUserGroupIdParam, userIdParam, orgIdParam,
                                        nameParam, descriptionParam,
                                        cartUserGroupMemberParam, workflowEnabledParam, membersToDeleteParam, groupModifiedByParam
                    });
            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void DeleteCartUserGroup(string id)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360DeleteBasketUserGroup);

            var cartUserGroupIdParam = new SqlParameter("@CartUserGroupId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };

            command.Parameters.Add(cartUserGroupIdParam);
            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void UpdateCartUserGroupMember(string cartUserGroupMemberId, string cartUserGroupId, string userId,
                                              List<SqlDataRecord> stage, bool isOwner)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetUserGroupMember);

            var cartUserGroupMemberIdParam = new SqlParameter("@BasketUserGroupMemberId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartUserGroupMemberId
            };

            var cartUserGroupIdParam = new SqlParameter("@BasketUserGroupId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartUserGroupId
            };

            var cartUserIdParam = new SqlParameter("@UserId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userId
            };

            var isOwnerParam = new SqlParameter("@IsOwner", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = isOwner
            };

            var stagesParam = new SqlParameter("@MemberWorkflowStages", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = stage
            };
            command.Parameters.AddRange(new[]{
                                        cartUserGroupMemberIdParam, cartUserGroupIdParam,
                                        cartUserIdParam, isOwnerParam, stagesParam
                    });
            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void DeleteCartUserGroupMember(string id)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcDeleteUserGroupMember);

            var cartUserGroupMemberIdParam = new SqlParameter("@BasketUserGroupMemberId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };

            command.Parameters.AddRange(new[]{
                                        cartUserGroupMemberIdParam
                    });

            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public string CreateOrganizationWorkflowStage(OrganizationWorkflowStage organizationWorkflowStage)
        {
            var organizationWorkflowStageId = Guid.NewGuid().ToString();

            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetOrgWorkflowStage, conn);

            var organizationWorkflowStageIdParam = new SqlParameter("@OrganizationWorkflowStageId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStageId
            };

            var organizationIdParam = new SqlParameter("@OrganizationId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.OrganizationId
            };

            var stageParam = new SqlParameter("@Stage", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.Stage
            };

            var stageAliasParam = new SqlParameter("@StageAlias", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.StageAlias
            };

            command.Parameters.AddRange(new[]{
                                        organizationWorkflowStageIdParam, organizationIdParam, stageAliasParam, stageParam
                    });

            conn.Open();
            try
            {
                command.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }

            return organizationWorkflowStageId;
        }

        public void UpdateOrganizationWorkflowStage(OrganizationWorkflowStage organizationWorkflowStage)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetOrgWorkflowStage, conn);

            var organizationWorkflowStageIdParam = new SqlParameter("@OrganizationWorkflowStageId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.OrganizationWorkflowStageId
            };

            var organizationIdParam = new SqlParameter("@OrganizationId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.OrganizationId
            };

            var stageParam = new SqlParameter("@Stage", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.Stage
            };

            var stageAliasParam = new SqlParameter("@StageAlias", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationWorkflowStage.StageAlias
            };

            command.Parameters.AddRange(new[]{
                                        organizationWorkflowStageIdParam, organizationIdParam, stageAliasParam, stageParam
                    });

            conn.Open();
            try
            {
                command.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteOrganizationWorkflowStage(string id)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcDeleteOrgWorkflowStage);

            var organizationWorkflowStageIdParam = new SqlParameter("@OrganizationWorkflowStageId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };

            command.Parameters.AddRange(new[]{
                                        organizationWorkflowStageIdParam
                    });

            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void UpdateSharedCartMember(string basketUserId, string userId, string cartId, bool hasOwner, List<SqlDataRecord> workflowStages)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetSharedCartMember);

            var sharedCartMemberIdParam = new SqlParameter("@BasketUserID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = basketUserId
            };

            var userIdParam = new SqlParameter("@UserId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userId
            };

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            var hasOwnerParam = new SqlParameter("@HasOwner", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = hasOwner
            };

            var sharedCartMemberWorkflowStageParam = new SqlParameter("@MemberWorkflowStages", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = workflowStages
            };

            command.Parameters.AddRange(new[]{
                                        sharedCartMemberIdParam, userIdParam, cartIdParam, hasOwnerParam, sharedCartMemberWorkflowStageParam
                    });
            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void DeleteSharedCartMember(string id)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcDeleteSharedCartMember);

            var sharedCartMemberIdParam = new SqlParameter("@BasketUserID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };
            var currentUser = new SqlParameter("@u_user_id", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = UserId
            };
            command.Parameters.Add(sharedCartMemberIdParam);
            command.Parameters.Add(currentUser);

            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void UpdateSharedCartMemberWorkflowStage(string sharedCartMemberWorkflowStageId, string basketUserId, int stage, DateTime? completionDate)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetMemberWorkflowStage);

            var sharedCartMemberWorkflowStageIdParam = new SqlParameter("@BasketUserWorkflowStageID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = sharedCartMemberWorkflowStageId
            };

            var sharedCartMemberIdParam = new SqlParameter("@BasketUserID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = basketUserId
            };

            var stageParam = new SqlParameter("@WorkflowStageID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = stage
            };

            var completionDateTimeParam = new SqlParameter("@CompletionDate", SqlDbType.DateTime)
            {
                Direction = ParameterDirection.Input
            };
            if (completionDate != null)
            {
                completionDateTimeParam.Value = completionDate.Value;
            }
            else
            {
                completionDateTimeParam.Value = DBNull.Value;
            }

            var modifiedByParam = new SqlParameter("@ModifiedBy", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = UserId
            };

            command.Parameters.AddRange(new[]
                                            {
                                                sharedCartMemberWorkflowStageIdParam, sharedCartMemberIdParam,
                                                stageParam, completionDateTimeParam, modifiedByParam

                                            });
            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void DeleteSharedCartMemberWorkflowStage(string id)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcDeleteMemberWorkflowStage);

            var sharedCartMemberWorkflowStageIdParam = new SqlParameter("@BasketUserWorkflowStageID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };

            command.Parameters.Add(sharedCartMemberWorkflowStageIdParam);

            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void UpdateSharedCartWorkflow(string sharedCartWorkflowId, string timeZone)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetSharedCartWorkflow);

            var sharedCartWorkflowIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = sharedCartWorkflowId
            };

            object tzObject;
            if (string.IsNullOrEmpty(timeZone))
            {
                tzObject = DBNull.Value;
            }
            else
            {
                tzObject = timeZone;
            }

            var timeZoneParam = new SqlParameter("@TimeZone", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = tzObject
            };

            command.Parameters.AddRange(new[]{
                                        sharedCartWorkflowIdParam, timeZoneParam
                    });

            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void DeleteSharedCartWorkflow(string id)
        {
            //var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcDeleteSharedCartWorkflow);

            var sharedCartWorkflowIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };

            command.Parameters.Add(sharedCartWorkflowIdParam);

            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void UpdateSharedCartWorkflowStage(string sharedCartWorkflowStageId, string cartId, int stage, DateTime? completionDate, DateTime? endDateTime, int status)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcSetWorkflowStage);

            var sharedCartWorkflowStageIdParam = new SqlParameter("@BasketWorkflowStageId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = sharedCartWorkflowStageId
            };
            var basketSummaryIdParam = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            var stageParam = new SqlParameter("@WorkflowStageID", SqlDbType.NVarChar, 255)
            {
                Direction = ParameterDirection.Input,
                Value = stage
            };

            var completionDateParam = new SqlParameter("@CompletionDateTime", SqlDbType.DateTime)
            {
                Direction = ParameterDirection.Input
            };
            if (completionDate.HasValue)
            {
                completionDateParam.Value = completionDate.Value;
            }
            else
            {
                completionDateParam.Value = DBNull.Value;
            }

            var endDateTimeParam = new SqlParameter("@EndDateTime", SqlDbType.DateTime)
            {
                Direction = ParameterDirection.Input
            };
            if (endDateTime.HasValue)
            {
                endDateTimeParam.Value = endDateTime.Value;
            }
            else
            {
                endDateTimeParam.Value = DBNull.Value;
            }

            var statusParam = new SqlParameter("@WorkflowStatusID", SqlDbType.NVarChar, 255)
            {
                Direction = ParameterDirection.Input,
                Value = status
            };


            command.Parameters.AddRange(new[]{
                                        sharedCartWorkflowStageIdParam, stageParam, completionDateParam, endDateTimeParam, statusParam,
                                        basketSummaryIdParam
                    });


            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void DeleteSharedCartWorkflowStage(string id)
        {
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcDeleteWorkflowStage);

            var sharedCartWorkflowStageIdParam = new SqlParameter("@BasketWorkflowStageID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = id
            };

            command.Parameters.Add(sharedCartWorkflowStageIdParam);


            command.ExecuteNonQuery();
            HandleCartGridException(command);
        }

        public void ShareCart(string cartId, string requisitionType)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcShareCart, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            command.Parameters.Add(cartIdParam);
            var IsSharedBasketGridEnabled = new SqlParameter("@IsSharedBasketGridEnabled", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = requisitionType == "1"
            };

            command.Parameters.Add(IsSharedBasketGridEnabled);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }
        }

        public bool HasSharedCartProfile(string cartId, out string ownerId)
        {
            var hasSharedCartProfile = false;

            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcHasSharedCartProfile, conn);

            var sharedCartWorkflowStageIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            var hasSharedCartProfileParam = new SqlParameter("@HasProfile", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Output
            };

            var basketOwnerId = new SqlParameter("@OwnerID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Output
            };

            command.Parameters.AddRange(new[]{
                                        sharedCartWorkflowStageIdParam, hasSharedCartProfileParam, basketOwnerId
                    });

            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartGridException(command);
                hasSharedCartProfile = Parser.ToBool(hasSharedCartProfileParam.Value);
                ownerId = DataAccessHelper.ConvertToString(basketOwnerId.Value);
            }
            finally
            {
                conn.Close();
            }
            return hasSharedCartProfile;
        }

        public DataSet GetSharedCartSummary(string cartId, bool viewMineOnly, string sortBy, bool? direction)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcGetSharedCartSummary, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            var userIdParam = new SqlParameter("@UserID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = UserId
            };

            var viewMineOnlyParam = new SqlParameter("@ViewMineOnly", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = viewMineOnly
            };


            var sortByParam = new SqlParameter("@SortBy", SqlDbType.NVarChar);
            if (string.IsNullOrEmpty(sortBy))
                sortByParam.Value = DBNull.Value;
            else
                sortByParam.Value = sortBy;

            var directionParam = new SqlParameter("@Direction", SqlDbType.Bit);
            if (direction == null)
                directionParam.Value = DBNull.Value;
            else
                directionParam.Value = direction;

            command.Parameters.AddRange(new[] { cartIdParam, userIdParam, viewMineOnlyParam, sortByParam, directionParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetSharedCartSummaryDetail(string cartId, string userId, string sortBy, bool? direction)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcGetSharedCartSummaryDetail, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };
            var userIdParam = new SqlParameter("@u_user_id", userId);

            var sortByParam = new SqlParameter("@SortBy", SqlDbType.VarChar);
            if (string.IsNullOrEmpty(sortBy))
                sortByParam.Value = DBNull.Value;
            else
                sortByParam.Value = sortBy;
            var directionParam = new SqlParameter("@Direction", SqlDbType.Bit);
            if (direction == null)
                directionParam.Value = DBNull.Value;
            else
            {
                directionParam.Value = direction;
            }

            command.Parameters.AddRange(new[] { cartIdParam, userIdParam, sortByParam, directionParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public DataSet GetCartUserGroups()
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetBasketUserGroups, conn);

            var cartIdParam = new SqlParameter("@u_user_id", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = UserId
            };

            command.Parameters.Add(cartIdParam);

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetCartUserGroupMembers(string cartUserGroupId)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetBasketUserGroupMembers, conn);

            var cartUserGroupIdParam = new SqlParameter("@BasketUserGroupId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartUserGroupId
            };

            command.Parameters.Add(cartUserGroupIdParam);

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public IEnumerable<OrganizationWorkflowStage> GetOrganizationWorkflowStages(string cartId, string organizationId)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetBasketUserGroupMembers, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            var orgIdParam = new SqlParameter("@OrgId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = organizationId
            };

            command.Parameters.AddRange(new[] { cartIdParam, orgIdParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return Converter.ConvertToListOrganizationWorkflowStage(ds);
        }

        public DataSet GetSharedCartMembers(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetSharedCartMembers, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            command.Parameters.AddRange(new[] { cartIdParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetSharedCartMemberWorkflowStages(string cartId, List<string> sharedCartMemberIds)
        {
            if(string.IsNullOrEmpty(cartId) || sharedCartMemberIds == null || sharedCartMemberIds.Count == 0) return new DataSet();

            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetSharedCartMemberWorkflowStages, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            //TFS 18016 - Elmah-System.ArgumentException-General: System.Data-There are no records in the SqlDataRecord enumeration
            var sharedCartMemberIdSqlRecords = DataConverter.ConverUserIDsToDataSet(sharedCartMemberIds);
            if (!sharedCartMemberIdSqlRecords.Any()) return new DataSet();
            
            var cartUserIdListParam = new SqlParameter("@BasketUserIDs", SqlDbType.Structured)
                                      {
                                          Value = sharedCartMemberIdSqlRecords
                                      };

            //var sharedCartMemberIdParam = new SqlParameter("@BasketUserID", SqlDbType.NVarChar, 50) {Value = string.Empty};

            command.Parameters.AddRange(new[] { cartIdParam, cartUserIdListParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetSharedCartWorkflow(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetSharedCartWorkflows, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };
            var modifiedByParam = new SqlParameter("@ModifiedBy", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = UserId
            };
            var currentDateTimeParam = new SqlParameter("@CurrentDateTime", SqlDbType.DateTime)
            {
                Direction = ParameterDirection.Input,
                Value = CommonHelper.GetCurrentDateTimeByTimeZone()
            };

            command.Parameters.AddRange(new[] { cartIdParam, modifiedByParam, currentDateTimeParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetSharedCartWorkflowStages(string cartId)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360GetCartWorkflowStages, conn);

            var cartIdParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            command.Parameters.AddRange(new[] { cartIdParam });

            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        #endregion

        public string CreateCartGridLine(DataSet ds)
        {
            throw new NotImplementedException();
        }

        #region NEW GRID
        public DataSet GetCartGridLines(List<string> lineItemIdList)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_BASKET_LINE_ITEM_GRIDS, conn);

            var sqlParameter = new SqlParameter[1];
            sqlParameter[0] = new SqlParameter("@BasketLineItemIDs", SqlDbType.Structured)
                              {
                                  Value =
                                      DataAccessHelper
                                      .GenerateDataRecords(
                                          lineItemIdList,
                                          "GUID")
                              };
            
            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        #endregion
    }
}
