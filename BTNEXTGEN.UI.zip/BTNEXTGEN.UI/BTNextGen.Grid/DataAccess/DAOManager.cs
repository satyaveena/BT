﻿using System;
using System.Data;
using System.Data.SqlClient;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Grid.Exception;

namespace BTNextGen.Grid.DataAccess
{
    public class DAOManager : IDAOManager
    {
        internal string OrganizationId { get; set; }

        internal string UserId { get; set; }

        private bool _transactionStarted;

        private SqlTransaction _transaction;

        private SqlConnection _connection;

        private string _connectionString;

        protected virtual string ConnectionString
        {
            get
            {
                if (_connectionString == null)
                {
                    _connectionString = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.OrdersConnectionstring).Value;
                    // Cut out Provider
                    if (_connectionString.ToLower().Contains("provider"))
                    {
                        int firstDelimeter = _connectionString.IndexOf(';');
                        _connectionString = _connectionString.Substring(firstDelimeter + 1);
                    }
                }
                return _connectionString;
            }
        }

        #region Implementation of IDAOManager

        public void BeginTransaction()
        {
            if (!_transactionStarted)
            {
                _transactionStarted = true;
                _connection = new SqlConnection(ConnectionString);
                _connection.Open();
                _transaction = _connection.BeginTransaction();
            }
        }

        public void CommitTransaction()
        {
            if (_transactionStarted)
            {
                _transaction.Commit();
                _connection.Close();
                _transactionStarted = false;
            }
        }

        public void RollBackTransaction()
        {
            if (_transactionStarted)
            {
                _transaction.Rollback();
                _connection.Close();
                _transactionStarted = false;
            }
        }

        #endregion

        protected SqlConnection CreateSqlConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        protected virtual SqlCommand CreateSqlCommand(string commandText)
        {
            return new SqlCommand(commandText, _connection);
        }

        protected virtual SqlCommand CreateSpSqlCommand(string storedProcedureName)
        {
            var spSqlCommand = CreateSpSqlCommandWithTransaction(storedProcedureName, _connection);

            var paramErrorMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar, -1) { Direction = ParameterDirection.Output };

            var paramReturnValue = new SqlParameter("returnVal", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue };

            spSqlCommand.Parameters.Add(paramErrorMessage);
            spSqlCommand.Parameters.Add(paramReturnValue);
            return spSqlCommand;
        }

        protected virtual SqlCommand CreateSpSqlCommand(string storedProcedureName, SqlConnection connection)
        {
            var spSqlCommand = new SqlCommand(storedProcedureName, connection) { CommandType = CommandType.StoredProcedure };
            var paramErrorMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar, -1) { Direction = ParameterDirection.Output };

            var paramReturnValue = new SqlParameter("returnVal", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue };

            spSqlCommand.Parameters.Add(paramErrorMessage);
            spSqlCommand.Parameters.Add(paramReturnValue);
            return spSqlCommand;
        }

        private SqlCommand CreateSpSqlCommandWithTransaction(string storedProcedureName, SqlConnection connection)
        {
            var spSqlCommand = new SqlCommand(storedProcedureName, connection) { CommandType = CommandType.StoredProcedure, Transaction = _transaction };
            return spSqlCommand;
        }

        protected void HandleCartGridException(SqlCommand command, string procName="")
        {
            var paramValue = command.Parameters["returnVal"].Value;
            var returnCode = -1;

            if (paramValue != null)
            {
                returnCode = DataAccessHelper.ConvertToInt(paramValue);
            }

            if (returnCode == 0)
                return;

            //Error
            paramValue = command.Parameters["@ErrorMessage"].Value;
            var errorMessage = paramValue != null ? paramValue.ToString() : "";

            var exception = new CartGridDatabaseException(errorMessage);
            if (!string.IsNullOrEmpty(procName)) exception.Source = procName + exception.Source;

            if (string.Compare(errorMessage, "Grid codes cannot be deleted because they are in use.", StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, "The basket must be grid enabled.", StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, CartGridDatabaseException.UNAUTHORIZED_TO_EDIT_OR_REPLACE_GRID_LINES_MESSAGE, StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, "Invalid parameters: Basket is not Open state.", StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, "BasketState is not Open.", StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, CartGridDatabaseException.CART_DUPLICATE_NAME, StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, "Grid field assgined to ILS Location, Fund or Collection cannot be inactive", StringComparison.OrdinalIgnoreCase) == 0 ||
                string.Compare(errorMessage, "Replacement will create duplicate grid, cannot proceed", StringComparison.OrdinalIgnoreCase) == 0)
            {
                exception.IsBusinessError = true;
            }
            else
                Logger.Write("CartGridDatabaseException", errorMessage);

            throw exception;
        }
    }
}
