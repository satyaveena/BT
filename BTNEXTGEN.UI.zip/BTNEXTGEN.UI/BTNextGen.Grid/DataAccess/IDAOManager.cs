﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.Grid.DataAccess
{
    public interface IDAOManager
    {       
        void BeginTransaction();

        void CommitTransaction();

        void RollBackTransaction();       
    }
}
