﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextgen.Grid;
using BTNextGen.Grid.Helpers;
using Microsoft.SqlServer.Server;

namespace BTNextGen.Grid.DataAccess
{
    public class GridDAOManager : DAOManager
    {
        #region PE methods

        public DataSet GetAllGridFields(bool isGetInUseInfo = true)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_ALL_USER_GRID_FIELDS, conn);
            var sqlParameter = new SqlParameter("@u_org_id", OrganizationId);
            var sqlParameterInUse = new SqlParameter("@GetInUseInfo", isGetInUseInfo);
            cmd.Parameters.Add(sqlParameter);
            cmd.Parameters.Add(sqlParameterInUse);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetAllUserGridCodes(string gridFieldId, bool getAll, bool isGetInUseInfo = true)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_ALL_USER_GRID_CODES, conn);
            var sqlParameter = new SqlParameter[4];
            //sqlParameter[0] = new SqlParameter("@GridFieldID", gridFieldId);
            sqlParameter[0] = new SqlParameter("@GridFieldIDs", SqlDbType.Structured)
            {
                Value = DataAccessHelper.GenerateDataRecords(new List<string> { gridFieldId }, "GridFieldID")

            };
            sqlParameter[1] = new SqlParameter("@GetAll", getAll);
            sqlParameter[2] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[3] = new SqlParameter("@GetInUseInfo", isGetInUseInfo);
            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        #endregion

        #region Grid Code methods
        public DataSet GetGridCodes(string gridFieldId, bool getAll, bool isGetInUseInfo = true)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_CODES, conn);
            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@GridFieldID", gridFieldId);
            sqlParameter[1] = new SqlParameter("@GetAll", getAll);
            sqlParameter[2] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[3] = new SqlParameter("@GetInUseInfo", isGetInUseInfo);
            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public void UpdateGridCode(string gridCodeId, string gridFieldId, string code, string literal, DateTime? effectiveDate, DateTime? expirationDate, bool activeIndicator, int sequence)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_GRID_CODE);
            var sqlParameter = new SqlParameter[9];
            sqlParameter[0] = new SqlParameter("@GridCodeID", gridCodeId);
            sqlParameter[1] = new SqlParameter("@GridFieldID", gridFieldId);
            sqlParameter[2] = new SqlParameter("@Code", code);
            sqlParameter[3] = new SqlParameter("@Literal", literal);
            if (effectiveDate == null)
                sqlParameter[4] = new SqlParameter("@EffectiveDate", DBNull.Value);
            else
                sqlParameter[4] = new SqlParameter("@EffectiveDate", effectiveDate);
            if (expirationDate == null)
                sqlParameter[5] = new SqlParameter("@ExpirationDate", DBNull.Value);
            else
                sqlParameter[5] = new SqlParameter("@ExpirationDate", expirationDate);
            sqlParameter[6] = new SqlParameter("@ActiveIndicator", activeIndicator);
            if (string.IsNullOrEmpty(UserId))
            {
                sqlParameter[7] = new SqlParameter("@u_user_id", "VietAdmin");
            }
            else
            {
                sqlParameter[7] = new SqlParameter("@u_user_id", UserId);
            }

            sqlParameter[8] = new SqlParameter("@Sequence", sequence);

            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        public void DeleteGridCode(string gridCodeId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_GRID_CODE);
            var sqlParameter = new SqlParameter("@GridCodeID", gridCodeId);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public DataSet GetUserGridCodes(string userId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_USER_GRID_CODES, conn);

            var sqlParameter = new SqlParameter("@u_user_id", SqlDbType.VarChar, 255) { Value = userId };

            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public void UpdateUserGridCode(string userGridCodeId, string gridCodeId, string userId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_USER_GRID_CODE);
            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@UserGridCodeID", userGridCodeId);
            sqlParameter[1] = new SqlParameter("@GridCodeID", gridCodeId);
            if (string.IsNullOrEmpty(userId))
            {
                sqlParameter[2] = new SqlParameter("@u_user_id", "VietAdmin");
            }
            else
            {
                sqlParameter[2] = new SqlParameter("@u_user_id", userId);
            }

            if (string.IsNullOrEmpty(UserId))
            {
                sqlParameter[3] = new SqlParameter("@UpdatedBy", "VietAdmin");
            }
            else
            {
                sqlParameter[3] = new SqlParameter("@UpdatedBy", UserId);
            }

            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        public void DeleteUserGridCode(string userGridCodeId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_USER_GRID_CODE);
            var sqlParameter = new SqlParameter("@UserGridCodeID", userGridCodeId);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        #endregion

        #region Grid Field methods
        public DataSet GetGridFieldsWithAuthorizedCodeForUser()
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_ALL_GRID_FIELD_WITH_CODE, conn);
            var orgParameter = new SqlParameter("@u_org_id", OrganizationId);
            var userParameter = new SqlParameter("@u_user_id", UserId);
            cmd.Parameters.Add(orgParameter);
            cmd.Parameters.Add(userParameter);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        //public DataSet GetGridFields(bool isGetInUseInfo = true)
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_FIELDS, conn);
        //    var sqlParameter = new SqlParameter("@u_org_id", OrganizationId);
        //    var sqlParameterInUse = new SqlParameter("@GetInUseInfo", isGetInUseInfo);
        //    cmd.Parameters.Add(sqlParameter);
        //    cmd.Parameters.Add(sqlParameterInUse);

        //    var da = new SqlDataAdapter(cmd);
        //    var ds = new DataSet();
        //    conn.Open();
        //    try
        //    {
        //        da.Fill(ds);
        //        HandleCartGridException(cmd);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }

        //    return ds;
        //}

        public void UpdateGridField(string gridFieldId, int sopGridFieldId, string name, bool freetextIndicator, int freetextCharacterLimit, int sequence, bool lockedIndicator, bool activeIndicator, bool userViewAllIndicator, bool validateIndicator, int slipReportSequence)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_GRID_FIELD);

            var sqlParameter = new SqlParameter[13];
            sqlParameter[0] = new SqlParameter("@GridFieldID", gridFieldId);
            if (sopGridFieldId == 0)
                sqlParameter[1] = new SqlParameter("@SOPGridFieldID", DBNull.Value);
            else
                sqlParameter[1] = new SqlParameter("@SOPGridFieldID", sopGridFieldId);
            sqlParameter[2] = new SqlParameter("@u_org_id", OrganizationId);
            sqlParameter[3] = new SqlParameter("@Name", name);
            sqlParameter[4] = new SqlParameter("@FreeTextIndicator", freetextIndicator);
            sqlParameter[5] = new SqlParameter("@FreeTextCharacterLimit", freetextCharacterLimit);
            sqlParameter[6] = new SqlParameter("@Sequence", sequence);
            sqlParameter[7] = new SqlParameter("@LockedIndicator", lockedIndicator);
            sqlParameter[8] = new SqlParameter("@ActiveIndicator", activeIndicator);
            sqlParameter[9] = new SqlParameter("@UserViewAllGridCodesIndicator", userViewAllIndicator);
            sqlParameter[10] = new SqlParameter("@ValidateIndicator", validateIndicator);
            sqlParameter[11] = new SqlParameter("@SlipReportSequence", slipReportSequence);
            if (string.IsNullOrEmpty(UserId))
            {
                sqlParameter[12] = new SqlParameter("@u_user_id", UserId) { Value = "VietAdmin" };
            }
            else
            {
                sqlParameter[12] = new SqlParameter("@u_user_id", UserId) { Value = UserId };
            }

            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public void DeleteGridField(string gridFieldId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_GRID_FIELD);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@GridFieldID", gridFieldId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
        }

        public DataSet GetUserGridFields(string gridFieldId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_USER_GRID_FIELDS, conn);

            var sqlParameter = new SqlParameter("@GridFieldID", gridFieldId);
            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        public void UpdateUserGridField(string userGridFieldId, string gridFieldId, string userId, string displayType, string defaultGridCodeId, string defaultGridText)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_USER_GRID_FIELD);

            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@UserGridFieldID", userGridFieldId);
            sqlParameter[1] = new SqlParameter("@GridFieldID", gridFieldId);
            sqlParameter[2] = new SqlParameter("@u_user_id", userId);
            sqlParameter[3] = new SqlParameter("@DisplayType", displayType);
            if (string.IsNullOrEmpty(defaultGridCodeId))
                sqlParameter[4] = new SqlParameter("@DefaultGridCodeID", DBNull.Value);
            else
                sqlParameter[4] = new SqlParameter("@DefaultGridCodeID", defaultGridCodeId);
            if (string.IsNullOrEmpty(defaultGridText))
                sqlParameter[5] = new SqlParameter("@DefaultGridText", DBNull.Value);
            else
                sqlParameter[5] = new SqlParameter("@DefaultGridText", defaultGridText);
            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public void DeleteUserGridField(string userGridFieldId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_USER_GRID_FIELD);
            var sqlParameter = new SqlParameter("@UserGridFieldID", userGridFieldId);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public void UpdateUserGridFieldSlipReportSequence(string orgId, string userId, List<CommonBaseGridUserControl.UIGridField> gridFields)
        {
            using (var conn = this.CreateSqlConnection())
            {
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360SaveSlipReportForGridField, conn);

                var sqlParameter = new SqlParameter[3];

                sqlParameter[0] = new SqlParameter("@u_org_id", SqlDbType.VarChar, 50) { Value = orgId };
                sqlParameter[1] = new SqlParameter("@u_user_id", SqlDbType.VarChar, 50) { Value = userId };
                sqlParameter[2] = new SqlParameter("@GridFieldsSequence", SqlDbType.Structured)
                {
                    Value = DataConverter.GetUtblUiGridFields(gridFields)
                };

                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
        }

        public void SaveGridFieldsGridCodes(string orgId, string userId, List<string> deletedGridCodes, List<CommonBaseGridUserControl.UIGridField> changedGridFields,
            List<CommonBaseGridUserControl.UIGridCode> changedGridCodes, string espFundCodeFieldID, string espBranchCodeFieldID, string ilsFundCodeFieldID, string ilsLocationCodeFieldID,
            string ilsMemberCodeRemainderFieldId, int ilsMemberCodeLength, bool ilsPassEntireLocationAsRemainder, string ilsPassPOAsLineNoteFieldId, string ilsCollectionCodeField)
        {
            using (var conn = this.CreateSqlConnection())
            {
                var cmd = this.CreateSpSqlCommand(BT.TS360Constants.StoredProcedureName.ProcTs360SaveGridFieldGridCode, conn);

                var sqlParameter = new SqlParameter[15];
                sqlParameter[0] = new SqlParameter("@u_org_id", SqlDbType.VarChar, 50) { Value = orgId };

                sqlParameter[1] = new SqlParameter("@u_user_id", SqlDbType.VarChar, 50) { Value = userId };

                sqlParameter[2] = new SqlParameter("@GridFieldForSaving", SqlDbType.Structured)
                {
                    Value = DataConverter.GetUtblUiGridFields(changedGridFields)
                };

                sqlParameter[3] = new SqlParameter("@GridCodeForDeleting", SqlDbType.Structured)
                {
                    Value = ConvertToListArgumentTable(deletedGridCodes, CreateArgumentTable())
                };

                sqlParameter[4] = new SqlParameter("@GridCodeForSaving", SqlDbType.Structured)
                {
                    Value = DataConverter.GetUtblGridCodes(changedGridCodes)
                };

                sqlParameter[5] = new SqlParameter("@GridCodeUserIdsForSaving", SqlDbType.Structured)
                {
                    Value = DataConverter.GetUtblGridCodesUserIdsForSaving(changedGridCodes)
                };

                sqlParameter[6] = new SqlParameter("@ESPFundCodeFieldID", SqlDbType.VarChar, 50) { Value = espFundCodeFieldID };
                sqlParameter[7] = new SqlParameter("@ESPBranchCodeFieldID", SqlDbType.VarChar, 50) { Value = espBranchCodeFieldID };

                sqlParameter[8] = new SqlParameter("@ILSFundCodeFieldID", SqlDbType.VarChar, 50) { Value = ilsFundCodeFieldID };
                sqlParameter[9] = new SqlParameter("@ILSLocationCodeFieldID", SqlDbType.VarChar, 50) { Value = ilsLocationCodeFieldID };

                if (!string.IsNullOrEmpty(ilsMemberCodeRemainderFieldId))
                {
                    sqlParameter[10] = new SqlParameter("@ILSMemberCodeRemainderFieldID", SqlDbType.VarChar, 50) { Value = ilsMemberCodeRemainderFieldId };
                }
                else
                {
                    sqlParameter[10] = new SqlParameter("@ILSMemberCodeRemainderFieldID", DBNull.Value);
                }

                if (ilsMemberCodeLength > 0)
                {
                    sqlParameter[11] = new SqlParameter("@ILSMemberCodeLength", SqlDbType.TinyInt) { Value = ilsMemberCodeLength };
                }
                else
                {
                    sqlParameter[11] = new SqlParameter("@ILSMemberCodeLength", DBNull.Value);
                }

                sqlParameter[12] = new SqlParameter("@ILSPassEntireLocationToRemainder", SqlDbType.Bit) { Value = ilsPassEntireLocationAsRemainder };

                if (ilsPassPOAsLineNoteFieldId != null)
                {
                    sqlParameter[13] = new SqlParameter("@ILSPassPOLineNumberFieldID", SqlDbType.VarChar, 50) { Value = ilsPassPOAsLineNoteFieldId };
                }
                else
                {
                    sqlParameter[13] = new SqlParameter("@ILSPassPOLineNumberFieldID", SqlDbType.VarChar, 50) { Value = DBNull.Value };
                }

                if(!string.IsNullOrEmpty(ilsCollectionCodeField))
                    sqlParameter[14] = new SqlParameter("@ILSCollectionCodeFieldID", SqlDbType.VarChar, 50) { Value = ilsCollectionCodeField };
                else
                    sqlParameter[14] = new SqlParameter("@ILSCollectionCodeFieldID", SqlDbType.VarChar, 50) { Value = DBNull.Value };

                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
        }

        #endregion

        #region Grid Template methods

        public string CreateGridTemplate(DataSet gridTemplate)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_GRID_TEMPLATE);
            string gridFieldID = string.Empty;
            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("GridTemplate", SqlDbType.Structured) { Value = gridTemplate };
            sqlParameter[1] = new SqlParameter("u_user_id", UserId) { Value = UserId };
            sqlParameter[2] = new SqlParameter("GridTemplateID", SqlDbType.VarChar, 255) { Direction = ParameterDirection.Output };
            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            gridFieldID = DataAccessHelper.ConvertToString(cmd.Parameters["GridTemplateID"]);
            HandleCartGridException(cmd);
            return gridFieldID;
        }
        public void UpdateGridTemplate(string gridTemplateId, string ownerUserId, string name, string description, bool enableIndicator, Dictionary<string, string> fieldIDlist)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_GRID_TEMPLATE);

            var sqlParameter = new SqlParameter[17];
            sqlParameter[0] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[1] = new SqlParameter("@OwnerUserID", ownerUserId);
            sqlParameter[2] = new SqlParameter("@Name", name);
            sqlParameter[3] = new SqlParameter("@Description", description);
            if (fieldIDlist.ContainsKey("GridField1ID"))
                sqlParameter[4] = new SqlParameter("@GridField1ID", fieldIDlist["GridField1ID"]);
            else
                sqlParameter[4] = new SqlParameter("@GridField1ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField2ID"))
                sqlParameter[5] = new SqlParameter("@GridField2ID", fieldIDlist["GridField2ID"]);
            else
                sqlParameter[5] = new SqlParameter("@GridField2ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField3ID"))
                sqlParameter[6] = new SqlParameter("@GridField3ID", fieldIDlist["GridField3ID"]);
            else
                sqlParameter[6] = new SqlParameter("@GridField3ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField4ID"))
                sqlParameter[7] = new SqlParameter("@GridField4ID", fieldIDlist["GridField4ID"]);
            else
                sqlParameter[7] = new SqlParameter("@GridField4ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField5ID"))
                sqlParameter[8] = new SqlParameter("@GridField5ID", fieldIDlist["GridField5ID"]);
            else
                sqlParameter[8] = new SqlParameter("@GridField5ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField6ID"))
                sqlParameter[9] = new SqlParameter("@GridField6ID", fieldIDlist["GridField6ID"]);
            else
                sqlParameter[9] = new SqlParameter("@GridField6ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField7ID"))
                sqlParameter[10] = new SqlParameter("@GridField7ID", fieldIDlist["GridField7ID"]);
            else
                sqlParameter[10] = new SqlParameter("@GridField7ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField8ID"))
                sqlParameter[11] = new SqlParameter("@GridField8ID", fieldIDlist["GridField8ID"]);
            else
                sqlParameter[11] = new SqlParameter("@GridField8ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField9ID"))
                sqlParameter[12] = new SqlParameter("@GridField9ID", fieldIDlist["GridField9ID"]);
            else
                sqlParameter[12] = new SqlParameter("@GridField9ID", DBNull.Value);
            if (fieldIDlist.ContainsKey("GridField10ID"))
                sqlParameter[13] = new SqlParameter("@GridField10ID", fieldIDlist["GridField10ID"]);
            else
                sqlParameter[13] = new SqlParameter("@GridField10ID", DBNull.Value);

            sqlParameter[14] = new SqlParameter("@EnabledIndicator", enableIndicator);
            sqlParameter[15] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[16] = new SqlParameter("u_org_id", OrganizationId);
            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        public DataSet GetGridTemplatesByAuthorizedUser(string authorizedUserId, bool isGetAll = false)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATES, conn);

            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@u_org_id", DBNull.Value);
            sqlParameter[1] = new SqlParameter("@u_user_id", authorizedUserId);
            sqlParameter[2] = new SqlParameter("@GridTemplateID", DBNull.Value);
            sqlParameter[3] = new SqlParameter("@IsGetAll", SqlDbType.Bit) { Value = isGetAll};

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public DataSet GetGridTemplates()
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATES, conn);

            var sqlParameter = new SqlParameter[3];
            if (string.IsNullOrEmpty(OrganizationId))
            {
                sqlParameter[0] = new SqlParameter("@u_org_id", DBNull.Value);
            }
            else
            {
                sqlParameter[0] = new SqlParameter("@u_org_id", OrganizationId);
            }
            sqlParameter[1] = new SqlParameter("@u_user_id", DBNull.Value);
            sqlParameter[2] = new SqlParameter("@GridTemplateID", DBNull.Value);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public DataSet GetGridTemplate(string gridTemplateId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATES, conn);

            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@u_org_id", DBNull.Value);
            sqlParameter[1] = new SqlParameter("@u_user_id", DBNull.Value);
            sqlParameter[2] = new SqlParameter("@GridTemplateID", gridTemplateId);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        //public DataSet GetGridTemplatesByUserId()
        //{
        //    var conn = this.CreateSqlConnection();
        //    var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATES, conn);

        //    var sqlParameter = new SqlParameter[3];
        //    sqlParameter[0] = new SqlParameter("@u_org_id", DBNull.Value);
        //    sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
        //    sqlParameter[2] = new SqlParameter("@GridTemplateID", DBNull.Value);

        //    cmd.Parameters.AddRange(sqlParameter);
        //    var da = new SqlDataAdapter(cmd);
        //    var ds = new DataSet();
        //    conn.Open();
        //    try
        //    {
        //        da.Fill(ds);
        //        HandleCartGridException(cmd);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }

        //    return ds;
        //}

        public void DeleteGridTemplate(string gridTemplateId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_GRID_TEMPLATE);
            var sqlParameter = new SqlParameter("@GridTemplateID", gridTemplateId);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        public DataSet GetGridTemplateOwners()
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATE_OWNERS, conn);

            var sqlParameter = new SqlParameter("@u_org_id", OrganizationId);

            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        public DataSet GetSOPGridFieldList()
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_SOP_GRID_FIELD_LIST, conn);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        public DataSet GetUserGridTemplates(string gridTemplateId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_USER_GRID_TEMPLATES, conn);

            var sqlParameter = new SqlParameter("@GridTemplateID", gridTemplateId);

            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetGridTemplatesByUser(string userId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATES_BY_USER, conn);
            var sqlParameter = new SqlParameter("@u_user_id", userId);

            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        public DataSet GetUserPreference()
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_USER_DEFAULT_GRID_TEMPLATE, conn);

            var sqlParameter = new SqlParameter("@u_user_id", UserId);

            cmd.Parameters.Add(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        public void UpdateUserPreference(string primaryBasketId, string defaultGridTemplateId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_USER_DEFAULT_GRID_TEMPLATE);

            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@PrimaryBasketID", primaryBasketId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[2] = new SqlParameter("@DefaultGridTemplateID", defaultGridTemplateId);

            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        public void UpdateUserGridTemplate(string userGridTemplateId, string userId, string rowExpRight, int sequence, string gridTemplateId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_USER_GRID_TEMPLATE);

            var sqlParameter = new SqlParameter[5];
            sqlParameter[0] = new SqlParameter("@UserGridTemplateID", userGridTemplateId);
            sqlParameter[1] = new SqlParameter("@u_user_id", userId);
            sqlParameter[2] = new SqlParameter("@RowExpansionRight", rowExpRight);
            sqlParameter[3] = new SqlParameter("@Sequence", sequence);
            sqlParameter[4] = new SqlParameter("@GridTemplateId", gridTemplateId);
            cmd.Parameters.AddRange(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public void SaveUserGridTemplates(string userId, List<SqlDataRecord> gridTemplatesForUpdate, List<SqlDataRecord> gridTemplateIDsForDelete)
        {
            if (!string.IsNullOrEmpty(userId))
            {
                var conn = CreateSqlConnection();
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_USER_GRID_TEMPLATES, conn);

                var sqlParameters = new SqlParameter[3];
                sqlParameters[0] = new SqlParameter("@UserID", userId);
                sqlParameters[1] = new SqlParameter("@GridTemplateInfo", SqlDbType.Structured) { Value = gridTemplatesForUpdate };
                sqlParameters[2] = new SqlParameter("@DeletedGridTemplateIDs", SqlDbType.Structured) { Value = gridTemplateIDsForDelete };

                cmd.Parameters.AddRange(sqlParameters);

                conn.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    HandleCartGridException(cmd);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public void DeleteUserGridTemplate(string userGridTemplateId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_USER_GRID_TEMPLATE);
            var sqlParameter = new SqlParameter("@UserGridTemplateID", userGridTemplateId);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        
        public DataSet GetCartGridDistribution(string userId, string cartId, out int gridOption, out string templateId) {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTS360GetGridDistribution, conn);

            var sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@UserID", userId);
            sqlParameter[1] = new SqlParameter("@BasketSummaryId", cartId);
            sqlParameter[2] = new SqlParameter("@GridDistributionOption", SqlDbType.Int) { Direction = ParameterDirection.Output };
            sqlParameter[3] = new SqlParameter("@GridTemplateID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
            //
            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
                //
                gridOption = DataAccessHelper.ConvertToInt(cmd.Parameters["@GridDistributionOption"].Value);
                templateId = DataAccessHelper.ConvertToString(cmd.Parameters["@GridTemplateId"].Value);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetGridTemplateLines(string gridTemplateId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATE_LINES, conn);

            var sqlParameter = new SqlParameter[1];
            sqlParameter[0] = new SqlParameter("@GridTemplateID", gridTemplateId);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        public DataSet GetGridTemplateLinesWithPaging(string gridTemplateId, int? pageIndex = null, int? pageSize = null)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_TEMPLATE_LINES_WITH_PAGING, conn);

            var sqlParameter = new SqlParameter[5];
            sqlParameter[0] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[1] = new SqlParameter("@u_org_id", OrganizationId);
            sqlParameter[2] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[3] = new SqlParameter("@PageIndex", pageIndex);
            sqlParameter[4] = new SqlParameter("@PageSize", pageSize);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public void UpdateGridTemplateLine(string templateLineId, int quantity, int sequence, bool enabledIndicator, string gridTemplateId, Dictionary<string, string> codeList)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SET_GRID_TEMPLATE_LINE);

            var sqlParameter = new SqlParameter[6];
            sqlParameter[0] = new SqlParameter("@GridTemplateLineID", templateLineId);
            sqlParameter[1] = new SqlParameter("@u_user_id", UserId);
            sqlParameter[2] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[3] = new SqlParameter("@Quantity", quantity);
            sqlParameter[4] = new SqlParameter("@Sequence", sequence);
            sqlParameter[5] = new SqlParameter("@EnabledIndicator", enabledIndicator);

            cmd.Parameters.AddRange(sqlParameter);
            foreach (var item in codeList)
            {
                cmd.Parameters.Add(new SqlParameter("@" + item.Key, item.Value));
            }
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }
        public void DeleteGridTemplateLine(string gridTemplateLineId)
        {
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_DELETE_GRID_TEMPLATE_LINE);

            var sqlParameter = new SqlParameter("@GridTemplateLineID", gridTemplateLineId);
            cmd.Parameters.Add(sqlParameter);
            cmd.ExecuteNonQuery();
            HandleCartGridException(cmd);
        }

        public DataSet GetGridFieldPositionMap(string gridTemplateId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_FIELD_POSITION, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[1] = new SqlParameter("@u_org_id", OrganizationId);

            cmd.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public void UpdateGridFieldPositionInTemplate(string gridTemplateId)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.PROC_UPDATE_GRID_FIELD_POSITION_IN_TEMPLATE_HEADER, conn);

            var lineItemIDParam = new SqlParameter("@BasketLineItemIds", SqlDbType.Structured) { Value = null };

            command.Parameters.Add(lineItemIDParam);

            var orgIDParam = new SqlParameter("@u_org_id", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = OrganizationId
            };
            command.Parameters.Add(orgIDParam);

            var gridTemplateIDParam = new SqlParameter("@GridTemplateID", SqlDbType.NVarChar, 50)
                                          {
                                              Direction = ParameterDirection.Input,
                                              Value = gridTemplateId
                                          };
            command.Parameters.Add(gridTemplateIDParam);

            var userIDParam = new SqlParameter("@u_user_id", UserId);
            command.Parameters.Add(userIDParam);


            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet GetUserGridTemplate(string gridTemplateId, string orgId, int pageIndex, int pageSize, out int total)
        {
            total = 0;
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_USER_GRID_TEMPLATES_PAGING, conn);

            var sqlParameter = new SqlParameter[5];
            sqlParameter[0] = new SqlParameter("@GridTemplateID", gridTemplateId);
            sqlParameter[1] = new SqlParameter("@OrgId", orgId);
            sqlParameter[2] = new SqlParameter("@PageIndex", pageIndex);
            sqlParameter[3] = new SqlParameter("@PageSize", pageSize);
            sqlParameter[4] = new SqlParameter("@Total", SqlDbType.Int) { Direction = ParameterDirection.Output };

            command.Parameters.AddRange(sqlParameter);
            var da = new SqlDataAdapter(command);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(command);

                total = DataAccessHelper.ConvertToInt(command.Parameters["@Total"].Value);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public void UpdateUserGridTemplates(List<SqlDataRecord> userGridTemplates)
        {
            var conn = this.CreateSqlConnection();
            var command = this.CreateSpSqlCommand(StoredProcedureName.PROC_UPDATE_USER_GRID_TEMPLATES, conn);

            var userGridTemplatesParam = new SqlParameter("@UserGridTemplates", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = userGridTemplates
            };

            command.Parameters.Add(userGridTemplatesParam);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartGridException(command);
            }
            finally
            {
                conn.Close();
            }
        }

        public void CopyGridTemplates(List<string> gridTemplateIds, string userId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_COPY_GRID_TEMPLATE, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = CreateTableParameter("@GridTemplateIDs", "utblCSGuids",
                                                    ConvertToListArgumentTable(gridTemplateIds, CreateArgumentTable()));
            sqlParameter[1] = new SqlParameter("@UserID", userId);

            cmd.Parameters.AddRange(sqlParameter);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }
        }

        #endregion
        #region NEW GRID
        public DataSet GetUserGridFieldsCodes(string userId, string orgId, out int defaultQuantity)
        {
            defaultQuantity = 0;
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_FIELD_GRID_CODE_BY_USER, conn);

            var sqlParameter = new SqlParameter[3];
            sqlParameter[0] = new SqlParameter("@u_org_id", orgId);
            sqlParameter[1] = new SqlParameter("@u_user_id", userId);
            sqlParameter[2] = new SqlParameter("@DefaultQuantity", SqlDbType.Int) { Direction = ParameterDirection.Output };

            cmd.Parameters.AddRange(sqlParameter);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);

                defaultQuantity = DataAccessHelper.ConvertToInt(cmd.Parameters["@DefaultQuantity"].Value);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetGridFieldsByUser(string userId)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_GRID_FIELD_BY_USER, conn);

            var sqlParameter = new SqlParameter("@u_user_id", userId);

            cmd.Parameters.Add(sqlParameter);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public DataSet GetDefaultBasketGridTemplate(string userId, List<string> cartIds)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_GET_DEFAULT_BASKET_GRID_TEMPLATE, conn);

            var sqlParameter = new SqlParameter[2];
            sqlParameter[0] = CreateTableParameter("@BasketSummaryIDs", "utblCSGuids",
                                                    ConvertToListArgumentTable(cartIds, CreateArgumentTable()));
            sqlParameter[1] = new SqlParameter("@UserId", userId);

            cmd.Parameters.AddRange(sqlParameter);

            var da = new SqlDataAdapter(cmd);
            var ds = new DataSet();
            conn.Open();
            try
            {
                da.Fill(ds);
                HandleCartGridException(cmd, StoredProcedureName.PROC_GET_DEFAULT_BASKET_GRID_TEMPLATE+":");
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public void SaveGridLinesAsAGridTemplate(List<SqlDataRecord> gridLines, string templateName, string description,
            bool enabledIndicator, bool needToSaveQuantity, bool isDefault, string defaultBasketId, 
            out string newTemplateNameIfDuplicated, out string newGridTemplateId, bool overwriteGridDistributionOption)
        {
            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand(StoredProcedureName.PROC_SAVE_GRID_LINES_AS_GRID_TEMPLATE, conn);
            var sqlParameter = new SqlParameter[12];
            sqlParameter[0] = new SqlParameter("@GridTemplateLines", SqlDbType.Structured);
            
            sqlParameter[0].Value = gridLines;
            sqlParameter[1] = new SqlParameter("@TemplateName", templateName);
            sqlParameter[2] = new SqlParameter("@Description", description);
            sqlParameter[3] = new SqlParameter("@EnabledIndicator", enabledIndicator);
            sqlParameter[4] = new SqlParameter("@saveQtyIndicator", needToSaveQuantity);
            sqlParameter[5] = new SqlParameter("@UserID", UserId);
            sqlParameter[6] = new SqlParameter("@NewTemplateName", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            sqlParameter[7] = new SqlParameter("@IsDefault", isDefault);
            sqlParameter[8] = new SqlParameter("@BasketSummaryID", defaultBasketId);
            sqlParameter[9] = new SqlParameter("@u_org_id", OrganizationId);
            sqlParameter[10] = new SqlParameter("@GridTemplateID", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };

            sqlParameter[11] = new SqlParameter("@OverwriteGridDistributionOption", SqlDbType.Bit) { Value = overwriteGridDistributionOption };

            cmd.Parameters.AddRange(sqlParameter);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
                newTemplateNameIfDuplicated = DataAccessHelper.ConvertToString(cmd.Parameters["@NewTemplateName"].Value);
                newGridTemplateId = DataAccessHelper.ConvertToString(cmd.Parameters["@GridTemplateID"].Value);
            }
            finally
            {
                conn.Close();
            }
        }

        #endregion
        private SqlParameter CreateTableParameter(string parameterName, string parameterTypeName, DataTable value)
        {
            return new SqlParameter
            {
                ParameterName = parameterName,
                SqlDbType = SqlDbType.Structured,
                TypeName = parameterTypeName,
                Value = value
            };
        }

        private DataTable CreateArgumentTable()
        {
            var dt = new DataTable("utblCSGuids");
            dt.Columns.Add("GUID", typeof(string));
            return dt;
        }

        private DataTable ConvertToListArgumentTable(IEnumerable<string> items, DataTable dt)
        {
            if (items != null)
            {
                var list = items.ToList();
                if (list.Any())
                    list.ForEach(r => dt.Rows.Add(r));
            }
            return dt;
        }

        public bool SaveCartGridDistribution(string userId, string cartId, int cartGridOption, string templateId, List<SqlDataRecord> gridTemplate)
        {
            using (var conn = this.CreateSqlConnection()) {
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTS360SaveGridDistribution, conn);
                var sqlParameter = new SqlParameter[5];
                sqlParameter[0] = new SqlParameter("@u_user_id", SqlDbType.NVarChar, 50) { Value = userId };

                sqlParameter[1] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Value = cartId };

                sqlParameter[2] = new SqlParameter("@GridDistributionOptionID", SqlDbType.SmallInt) { Value = cartGridOption };

                sqlParameter[3] = new SqlParameter("@GridTemplateID", SqlDbType.NVarChar, 50) { Value = templateId };

                sqlParameter[4] = new SqlParameter("@GridTemplateLinesInfo", SqlDbType.Structured) { Value = gridTemplate != null && gridTemplate.Count > 0 ? gridTemplate : null };
                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
                return true;
            }
            
        }

        public void SaveGridTemplate(string organizationId, string gridTemplateId, string owerId, string templateName, string templateDescriptions,
            bool enableIndicator, List<SqlDataRecord> gridTemplate, List<string> deletedLineIDs, string cartId, bool isDefault)
        {
            using (var conn = this.CreateSqlConnection())
            {
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360SaveGridTemplate, conn);

                var sqlParameter = new SqlParameter[10];
                sqlParameter[0] = new SqlParameter("@u_org_id", SqlDbType.NVarChar, 50) { Value = organizationId };

                sqlParameter[1] = new SqlParameter("@GridTemplateID", SqlDbType.NVarChar, 50) { Value = gridTemplateId };

                sqlParameter[2] = new SqlParameter("@OwnerUserID", SqlDbType.NVarChar, 50) { Value = owerId };

                sqlParameter[3] = new SqlParameter("@Name", SqlDbType.NVarChar, 255) { Value = templateName };

                sqlParameter[4] = new SqlParameter("@Description", SqlDbType.NVarChar, 1000) { Value = templateDescriptions };

                sqlParameter[5] = new SqlParameter("@EnabledIndicator", SqlDbType.Bit) { Value = enableIndicator };

                sqlParameter[6] = new SqlParameter("@GridTemplateLinesInfo", SqlDbType.Structured)
                { Value = gridTemplate != null && gridTemplate.Count > 0 ? gridTemplate : null };

                sqlParameter[7] = CreateTableParameter("@DeletedGridTemplateLineIDs", "utblCSGuids",
                    ConvertToListArgumentTable(deletedLineIDs, CreateArgumentTable()));
                            
                if (string.IsNullOrEmpty(cartId))
                    sqlParameter[8] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Value = DBNull.Value };
                else
                    sqlParameter[8] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Value = cartId };

                sqlParameter[9] = new SqlParameter("@IsDefault", SqlDbType.Bit) { Value = isDefault };

                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
        }

        public void SaveUserGridFieldsCodes(string userId, List<SqlDataRecord> sqlDataRecords, int defaultQuantity)
        {
            using (var conn = this.CreateSqlConnection())
            {
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360SaveUserGridFieldsCodes, conn);

                var sqlParameter = new SqlParameter[3];
                sqlParameter[0] = new SqlParameter("@u_user_id", SqlDbType.NVarChar, 50) { Value = userId };

                sqlParameter[1] = new SqlParameter("@GridFieldsInfo", SqlDbType.Structured) { Value = sqlDataRecords };

                sqlParameter[2] = new SqlParameter("@DefaultQuantity", SqlDbType.Int) { Value = defaultQuantity };

                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
        }

        public void SaveUserAssignedGridFieldsCodes(List<SqlDataRecord> sqlDataRecords, string userId)
        {
            using (var conn = this.CreateSqlConnection())
            {
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTS360UpdateUserGridCodes, conn);

                var sqlParameter = new SqlParameter[2];
                sqlParameter[0] = new SqlParameter("@u_user_id", SqlDbType.NVarChar, 50) { Value = userId };

                sqlParameter[1] = new SqlParameter("@GridCodeIDs", SqlDbType.Structured) { Value = sqlDataRecords };

                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
        }

        public void ClearDefaultSettingUserGridTemplate(string userId)
        {
            using (var conn = this.CreateSqlConnection())
            {
                var cmd = this.CreateSpSqlCommand(StoredProcedureName.ProcTs360ClearDefaultSettingOfGridTemplate, conn);

                var sqlParameter = new SqlParameter[1];
                sqlParameter[0] = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Value = userId };

                conn.Open();
                cmd.Parameters.AddRange(sqlParameter);
                cmd.ExecuteNonQuery();
                HandleCartGridException(cmd);
            }
        }

        public string GetDefaultGridTemplateId(string userId, string cartId)
        {
            var defaultGridTplId = "";

            var conn = this.CreateSqlConnection();
            var cmd = this.CreateSpSqlCommand("procTS360GetDefaultGridTempalteID", conn);
            var sqlParameterUser = new SqlParameter("@u_user_id", userId);
            var paramCartId = new SqlParameter("@BasketSummaryID", cartId);
            var paramDefaultGridTplId = new SqlParameter("@DefaultGridTemplateID", SqlDbType.NVarChar, 50);
            paramDefaultGridTplId.Direction = ParameterDirection.Output;

            cmd.Parameters.AddRange(new SqlParameter[] { sqlParameterUser, paramCartId, paramDefaultGridTplId});
            conn.Open();

            try
            {
                cmd.ExecuteNonQuery();

                if (paramDefaultGridTplId.Value != null && paramDefaultGridTplId.Value != DBNull.Value)
                {
                    defaultGridTplId = paramDefaultGridTplId.Value.ToString();
                }
                HandleCartGridException(cmd);
            }
            finally
            {
                conn.Close();
            }

            return defaultGridTplId;
        }
    }
}
