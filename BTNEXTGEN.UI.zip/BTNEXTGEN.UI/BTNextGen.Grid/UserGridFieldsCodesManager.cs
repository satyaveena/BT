﻿using System;
using System.Collections.Generic;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextgen.Grid;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.VelocityCaching;

namespace BTNextGen.Grid
{
    public class UserGridFieldsCodesManager
    {
        private static UserGridFieldsCodesManager _instance = null;
        private static readonly string USER_GRID_FIELDS_CACHE_KEY = "USER_GRID_FIELDS_CACHE_KEY_{0}";
        private static readonly string USER_OBJECT_CACHE_KEY = "USER_OBJECT_CACHE_KEY_{0}";

        protected GridDataAccessManager CurrentDataAccessManager
        {
            get { return CartGridContext.Current.CurrentDataAccessManager<GridDataAccessManager>(); }
        }

        public static UserGridFieldsCodesManager Instance
        {
            get { return _instance ?? (_instance = new UserGridFieldsCodesManager()); }
        }

        public UserGridFieldsCodes GetUserGridFieldsCodes(string userId, string orgId)
        {
            var userGridFieldCodes = new UserGridFieldsCodes();

            userGridFieldCodes = GetUserGridFieldsCodesFromAppCache(userId, orgId);
            if (userGridFieldCodes != null) return userGridFieldCodes;

            userGridFieldCodes = new UserGridFieldsCodes();
            if (CommonHelper.IsAuthorizeToUseAllGridCodes(orgId))
            {
                var gridCodes = new List<CommonBaseGridUserControl.UIGridCode>();
                var orgGridFieldCodes = DistributedCacheHelper.GetActiveGridFieldsForOrg(orgId, true);
                foreach (var gf in orgGridFieldCodes)
                {
                    gridCodes.AddRange(gf.UIGridCodes);
                }

                gridCodes.ForEach(item => item.IsAuthorized = true);

                userGridFieldCodes.UserGridCodes = gridCodes;
                userGridFieldCodes.UserGridFields = GetUserGridFields(userId);
                userGridFieldCodes.DefaultQuantity = GetDefaultQuantity(userId);
            }
            else
            {
                userGridFieldCodes = CurrentDataAccessManager.GetUserGridFieldsCodes(userId, orgId);
            }

            StoreUserGridFieldsCodesToAppCache(userId, orgId, userGridFieldCodes);

            return userGridFieldCodes;
        }

        private int GetDefaultQuantity(string userId)
        {
            try
            {
                var cacheKey = string.Format(USER_OBJECT_CACHE_KEY, userId);
                var userObj = VelocityCacheManager.Read(cacheKey, VelocityCacheLevel.Session) as UserPreference;
                if (userObj == null)
                {
                    userObj = CurrentDataAccessManager.GetUserPreference();
                    VelocityCacheManager.Write(cacheKey, userObj, VelocityCacheLevel.Session);
                }
                if (userObj != null) 
                    return userObj.DefaultQuantity;
            }
            catch (System.Exception ex)
            {
                Logger.LogException(ex);
            }
            return 0;
        }

        private static UserGridFieldsCodes GetUserGridFieldsCodesFromAppCache(string userId, string orgId)
        {
            var cacheKey = string.Format("GetUserGridFieldsCodesCacheKey_{0}_{1}", userId, orgId);

            return VelocityCacheManager.Read(cacheKey, VelocityCacheLevel.Request) as UserGridFieldsCodes;
        }

        private static void StoreUserGridFieldsCodesToAppCache(string userId, string orgId, UserGridFieldsCodes userGridFieldsCodes)
        {
            var cacheKey = string.Format("GetUserGridFieldsCodesCacheKey_{0}_{1}", userId, orgId);

            VelocityCacheManager.Write(cacheKey, userGridFieldsCodes, VelocityCacheLevel.Request);
        }

        private List<CommonBaseGridUserControl.UIUserGridField> GetUserGridFields(string userId)
        {
            var cacheKey = string.Format(USER_GRID_FIELDS_CACHE_KEY, userId);
            var userGridFields = VelocityCacheManager.Read(cacheKey,VelocityCacheLevel.Farm) as List<CommonBaseGridUserControl.UIUserGridField>;

            if (userGridFields == null)
            {
                userGridFields = CurrentDataAccessManager.GetGridFieldsByUser(userId);
                VelocityCacheManager.Write(cacheKey, userGridFields, VelocityCacheLevel.Farm);
            }
            return userGridFields;
        }

        public List<CommonBaseGridUserControl.UIUserGridCode> GetUserGridCodes(string userId)
        {
            return CurrentDataAccessManager.GetUserGridCodes(userId);
        }

        public void SaveUserGridFieldsCodes(string userId, List<CommonBaseGridUserControl.UIUserGridField> userGridFieldObjects, int defaultQuantity)
        {
            CurrentDataAccessManager.SaveUserGridFieldsCodes(userId, userGridFieldObjects, defaultQuantity);
            var cacheKey = string.Format(USER_GRID_FIELDS_CACHE_KEY, userId);
            VelocityCacheManager.SetExpired(cacheKey);

            var userObjCacheKey = string.Format(USER_OBJECT_CACHE_KEY, userId);
            VelocityCacheManager.SetExpired(userObjCacheKey);
        }

        public void SaveUserAssignedGridFieldsCodes(List<string> userGridCodeAssignToUser, string userId)
        {
            CurrentDataAccessManager.SaveUserAssignedGridFieldsCodes(userGridCodeAssignToUser, userId);            
        }

        public void ClearDefaultSettingUserGridTemplate(string userId)
        {
            CurrentDataAccessManager.ClearDefaultSettingUserGridTemplate(userId);
        }
    }

    public class UserGridFieldsCodes
    {
        public List<CommonBaseGridUserControl.UIUserGridField> UserGridFields { get; set; }

        public List<CommonBaseGridUserControl.UIGridCode> UserGridCodes { get; set; }

        public int DefaultQuantity { get; set; }

        public UserGridFieldsCodes()
        {
            DefaultQuantity = 0;
        }
    }
}
