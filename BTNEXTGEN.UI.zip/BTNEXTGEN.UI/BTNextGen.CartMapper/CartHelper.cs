﻿using System;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.CartFramework;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.VelocityCaching;
using BT.TS360Constants;
namespace BTNextGen.CartMapper
{
    public class CartAccountHelper
    {
        public static void GetDefaulAccountId(string eSupplier, string cartId, string userId, out string entAccountId, 
            out string bookAccountId, out Dictionary<string, string> defaultESupplierAccountIds, out string vipAccountId)
        {
            defaultESupplierAccountIds = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            bookAccountId = string.Empty;
            entAccountId = string.Empty;
            vipAccountId = string.Empty;

            if (string.IsNullOrEmpty(cartId)) return;
            if (string.IsNullOrEmpty(userId)) return;

            // TFS_24932: PE_Cart Details pageload: remove duplicated call to procTS360GetBasketByID
            Cart currentCart = VelocityCacheManager.Read(BT.TS360Constants.SessionVariableName.CartDetailsCartCacheKey) as Cart;
            if (currentCart == null || String.Compare(currentCart.CartId, cartId, true) != 0)
            {
                currentCart = CartContext.Current.GetCartManagerForUser(userId).GetCartById(cartId);
            }

            if (currentCart != null && currentCart.CartAccounts != null)
            {
                bool hasOneBoxAccount = false;
                var cartAccounts = currentCart.CartAccounts.Where(acct => acct != null);
                foreach (var account in cartAccounts)
                {
                    if (account.AccountType == (int) AccountType.VIP)
                    {
                        vipAccountId = account.ERPAccountGUID;
                    }
                    else if (!string.IsNullOrEmpty(account.ESupplierID))
                    {
                        if (!string.IsNullOrEmpty(account.AccountID))
                        {
                            if (!defaultESupplierAccountIds.ContainsKey(account.ESupplierID))
                                defaultESupplierAccountIds.Add(account.ESupplierID, account.ERPAccountGUID);
                        }
                    }
                    else if (account.AccountType == (int)AccountType.OneBox)
                    {
                        bookAccountId = entAccountId = account.ERPAccountGUID;
                        hasOneBoxAccount = true;
                    }
                    else if (account.AccountType == (int)AccountType.Book)
                        bookAccountId = account.ERPAccountGUID;
                    else if (account.AccountType == (int)AccountType.Entertainment)
                        entAccountId = account.ERPAccountGUID;
                }

                if (hasOneBoxAccount)
                    return;

                var isHomeDeliveryOnly = false;

                ProductSearchController.ApplyHomeDelivery(entAccountId, ref entAccountId, ref bookAccountId, out isHomeDeliveryOnly);
                if (!isHomeDeliveryOnly)
                    ProductSearchController.ApplyHomeDelivery(bookAccountId, ref entAccountId, ref bookAccountId, out isHomeDeliveryOnly);
            }
        }
    }
}
