//-----------------------------------------------------------------------
// <copyright file="ShoppingController.cs" company="Microsoft">
//     Copyright � Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary></summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using BTNextGen.CartFramework;
using BTNextGen.Commerce.Portal.Common.Constants;
using Microsoft.Commerce.Common.MessageBuilders;
using Microsoft.Commerce.Contracts;
using Microsoft.Commerce.Contracts.Messages;
using BTNextGen.Pipeline.Inventory;
using AccountType = BT.TS360Constants.AccountType;
using CacheKeyConstant = BT.TS360Constants.CacheKeyConstant;
using DefaultDuplicateCarts = BT.TS360Constants.DefaultDuplicateCarts;
using DefaultDuplicateOrders = BT.TS360Constants.DefaultDuplicateOrders;
using ExceptionCategory = BT.TS360Constants.ExceptionCategory;
using MarketType = BT.TS360Constants.MarketType;
using ProductSupportedHtmlTag = BT.TS360Constants.ProductSupportedHtmlTag;
using SessionVariableName = BT.TS360Constants.SessionVariableName;
using SiteTermName = BT.TS360Constants.SiteTermName;

namespace BTNextGen.CartMapper
{
    using Commerce.Portal.Common;
    using Commerce.Portal.Common.ActiveCreditCardService;
    using Commerce.Portal.Common.Caching;
    using Commerce.Portal.Common.Controllers;
    using Commerce.Portal.Common.DataAccessObject;
    using Commerce.Portal.Common.Exceptions;
    using Commerce.Portal.Common.Helpers;
    using Commerce.Portal.Common.Logging;
    using Commerce.Portal.Common.Model;
    using Commerce.Portal.Common.Search;
    using BTNextgen.Grid.Cart;
    using VelocityCaching;
    using LineItem = CartFramework.Order.LineItem;
    using CartFolder = CartFramework.CartFolder;
    using BT.TS360Constants;
    using ServiceContracts = BT.TS360API.ServiceContracts;
    /// <summary>
    /// The Shopping Controller class exposes methods to modify Baskets, ShopperLists.
    /// </summary>
    public class CartMapping
    {
        #region Private fields

        /// <summary>
        /// Default Basket Name
        /// </summary>
        public const string DefaultBasketName = "Default";
        private Dictionary<string, string> PrimCartBtkeyLineItemId = new Dictionary<string, string>();
        #endregion Private Fields

        #region Constructors

        public static CartMapping Instance
        {
            get { return new CartMapping(); }
        }

        #endregion Constructors

        #region Public Methods

        public void ResetCacheCartById(string cartId)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            if (cartManager == null) return;

            cartManager.SetCartChanged(cartId);
        }

        public void AddToCartName4BatchEntry(List<LineItem> listItem, string cartId, out string lastIsbnUpcProcessed,
            out string PermissionViolationMessage, out int totalAddingQtyForGridDistribution)
        {
            lastIsbnUpcProcessed = string.Empty;
            PermissionViolationMessage = null;
            totalAddingQtyForGridDistribution = 0;
            if (listItem != null && listItem.Count > 0)
            {
                CartBatchEntryManager.AddLineItemsToCart(listItem, cartId, out PermissionViolationMessage, out totalAddingQtyForGridDistribution);
                lastIsbnUpcProcessed = GetLastItemProcessed(listItem);

                ResetCacheCartById(cartId);
                HttpHelper.ForceCartRepriceInBackgroundRequest(cartId);
            }
        }

        /// <summary>
        /// Adds a list of items to cart.
        /// </summary>
        /// <param name="basketId">The basket.</param>
        /// <param name="addLineItems">The list of line items to add to cart.</param>
        public void AddToCartName(string basketId, List<LineItem> addLineItems, out string PermissionViolationMessage,
            out int totalAddingQtyForGridDistribution, bool needToReprice = true)
        {
            PermissionViolationMessage = null;
            totalAddingQtyForGridDistribution = 0;
            if (!string.IsNullOrEmpty(basketId))
            {
                Cart cart = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId).GetCartById(basketId);
                cart.AddLineItems(addLineItems, out PermissionViolationMessage, out totalAddingQtyForGridDistribution, needToReprice);
            }
        }

        public Dictionary<string, string> FindQuantity(IEnumerable<string> btKeys)
        {
            var quantities = new Dictionary<string, string>();
            var primaryCart = GetPrimaryCartObject();
            if (btKeys != null && btKeys.Count() > 0)
            {
                if (primaryCart != null)
                {
                    var defaultQuantityInPrimaryCart = primaryCart.GetQuantitiesByBtkeys(btKeys.ToList());
                    if (defaultQuantityInPrimaryCart != null)
                    {
                        foreach (var btKey in btKeys)
                        {
                            quantities.Add(btKey,
                                           defaultQuantityInPrimaryCart.ContainsKey(btKey)
                                               ? defaultQuantityInPrimaryCart[btKey].ToString()
                                               : string.Empty);
                        }
                    }
                }
                else
                {
                    foreach (var btKey in btKeys)
                    {
                        quantities.Add(btKey, string.Empty);
                    }
                }
            }
            return quantities;
        }

        private static string GetLastItemProcessed(List<LineItem> list)
        {
            if (list == null || list.Count == 0) return string.Empty;

            var lastIndex = list.Count - 1;
            var lastIsbn = list[lastIndex].ISBN;
            if (!string.IsNullOrEmpty(lastIsbn))
            {
                return lastIsbn;
            }
            return list[lastIndex].Upc;
        }

        /// <summary>
        /// For fixng #5080, incorrect SharedUser
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="variantId"></param>
        /// <param name="quantity"></param>
        /// <param name="catalog"></param>
        /// <param name="basketName"></param>
        /// <param name="productType"></param>
        /// <param name="note"></param>
        /// <param name="isbn"></param>
        /// <param name="gtin"></param>
        /// <param name="upc"></param>
        /// <param name="poPerLine"></param>
        /// <param name="bibNumber"></param>
        /// <param name="sharedUserId"></param>
        /// <returns></returns>
        public string AddToCartNameWithSharedUser(string productId, string variantId, int quantity,
                                                            string catalog, string basketName, string productType,
                                                            string note, string isbn, string gtin, string upc,
                                                            string poPerLine, string title, string author, out string PermissionViolationMessage,
            out int totalAddingQtyForGridDistribution, string bibNumber = "", string sharedUserId = "")
        {
            var basket = GetBasketByName(basketName);
            PermissionViolationMessage = "";
            totalAddingQtyForGridDistribution = 0;

            if (!string.IsNullOrEmpty(productId) && !string.IsNullOrEmpty(catalog) && basket != null)
            {
                if (string.IsNullOrEmpty(variantId))
                {
                    variantId = null;
                }

                productType = CommonHelper.MapProductTypeToNumber(productType);

                var lineItem = new LineItem
                {
                    CatalogName = catalog,
                    ProductId = productId,
                    VariantId = variantId,
                    Quantity = quantity,
                    BTItemType = productType,
                    BTKey = productId,
                    BTGTIN = gtin,
                    BTISBN = isbn,
                    BTUPC = upc,
                    BTLineItemNote = note,
                    PONumber = poPerLine,
                    Bib = bibNumber,
                    Title = title,
                    Author = author
                };
                var cart = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId).GetCartById(basket.Id);
                if (cart != null)
                {
                    if (!string.IsNullOrEmpty(sharedUserId))
                        cart.UserId = sharedUserId;
                    cart.AddLineItems(new List<LineItem>() { lineItem }, out PermissionViolationMessage, out totalAddingQtyForGridDistribution);
                }
            }
            if (basket == null)
                return string.Empty;
            return basket.Id;
        }

        #endregion Public Methods

        #region Extended Methods - Basket Controller

        /// <summary>
        /// Method to retreive all BasketLists of the current user (after the Execute Method has been called)
        /// </summary>
        /// <returns>The collection of Basket requested.</returns>
        public List<Basket> GetBaskets()
        {
            return GetBaskets(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the baskets of selected user.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public List<Basket> GetBaskets(string userId)
        {
            try
            {
                Carts carts = CartContext.Current.GetCartManagerForUser(userId).GetAllCarts();
                if (carts != null && carts.Count > 0)
                {
                    return carts.ToBaskets();
                }
            }
            catch (Exception exception)
            {
                Logger.LogException(exception);
            }

            return null;
        }

        public int GetBasketTotalLineItems(string basketId, string userId)
        {
            Cart cart = CartContext.Current.GetCartManagerForUser(userId).GetCartById(basketId);
            if (cart != null)
            {
                return cart.LineItemCount;
            }
            return 0;
        }

        /// <summary>
        /// Gets the line items in basket.
        /// </summary>
        /// <param name="basketId">The basket id.</param>
        /// <returns></returns>
        public List<LineItem> GetLineItemsInBasket(string basketId)
        {
            Cart cart = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId).GetCartById(basketId);
            return cart.GetAllCartLines();
        }

        public List<LineItem> GetLineItemsInBasketBySearch(string basketId, string facetPath, string keyword, int sortBy, int pageSize,
                                                            int pageNum, out int totalLines, GridFieldType gridFieldType, string gridCodeId,
                                                            string gridText, string keywordType, int sortDirection = 0, bool isFindAndReplace = false,
                                                            bool isFreeText = false, bool isSharedCart = false, string[] matchingBTKeys = null
            , int? quantity = null)
        {
            totalLines = 0;
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            if (cartManager != null)
            {
                Cart cart = cartManager.GetCartById(basketId);

                var lineItems = cart.GetCartLines(facetPath, keyword, pageNum, pageSize, sortBy, out totalLines, gridFieldType, gridCodeId,
                                                  gridText, keywordType, sortDirection, isFindAndReplace, isFreeText, isSharedCart, matchingBTKeys, quantity);
                return lineItems;
            }
            return null;
        }

        public List<SearchResultInventoryStatusArg> GetInventoryStatusArgs(string basketId, string facetPath, string keyword, int sortBy, int pageSize,
                                                            int pageNum, out int totalLines, string keywordType,
                                                            int sortDirection = 0, bool isSharedCart = false)
        {
            totalLines = 0;
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            if (cartManager != null)
            {
                // TFS_24932: PE_Cart Details pageload: remove duplicated call to procTS360GetBasketByID
                var cart = VelocityCacheManager.Read(SessionVariableName.CartDetailsCartCacheKey) as Cart;
                if (cart == null || String.Compare(cart.CartId, basketId, true) != 0)
                {
                    cart = cartManager.GetCartById(basketId);
                }

                var lineItems = cart.GetCartLinesInventoryArgs(facetPath, keyword, pageNum, pageSize, sortBy,
                    out totalLines, keywordType, sortDirection, isSharedCart);
                return lineItems;
            }
            return null;
        }

        public List<SearchResultInventoryStatusArg> GetInventoryStatusArgs(Cart cart, string facetPath, string keyword, int sortBy, int pageSize,
                                                            int pageNum, out int totalLines, string keywordType,
                                                            int sortDirection = 0, bool isSharedCart = false)
        {
            totalLines = 0;
            if (cart != null)
            {
                var lineItems = cart.GetCartLinesInventoryArgs(facetPath, keyword, pageNum, pageSize, sortBy,
                    out totalLines, keywordType, sortDirection, isSharedCart);

                return lineItems;
            }
            return null;
        }

        /// <summary>
        /// Gets the baskets by folder id.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <returns>list of basket contained in this folder</returns>
        public List<Basket> GetBasketsByFolderId(string folderId)
        {
            //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
            if (string.IsNullOrEmpty(folderId)) return null;
            //
            var siteContext = SiteContext.Current;
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(siteContext.UserId);
            CartFolder cartFolder = cartManager.GetCartFolderById(folderId);
            if (cartFolder != null)
            {
                try
                {
                    Carts carts = cartFolder.GetCarts();
                    if (carts != null)
                    {
                        IEnumerable<Basket> baskets = from cart in carts
                                                      select cart.ToBasket(siteContext.UserId);
                        return baskets.ToList();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogException(ex);
                }
            }
            return null;
        }

        /// <summary>
        /// Gets the baskets by folder id.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <param name="listBasket">The list basket.</param>
        /// <returns></returns>
        public List<Basket> GetBasketsByFolderId(string folderId, List<Basket> listBasket)
        {
            return GetBasketsByProperty(Basket.PropertyName.FolderId, folderId, listBasket);
        }

        /// <summary>
        /// Gets the list carts in folder and its sub-folders.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <param name="listBasket">The basket list.</param>
        /// <param name="allFolders"></param>
        /// <returns>
        /// List of carts in folder and its sub-folder
        /// </returns>
        private List<Basket> GetBasketsByFolderIdRecursive(string folderId, List<Basket> listBasket,
                                                           ICollection<CartFolder> allFolders)
        {
            List<Basket> listBasketInFolder = GetBasketsByFolderId(folderId, listBasket) ?? new List<Basket>();
            ICollection<CartFolder> subFolderList = GetCartFolderListByParentFolderId(folderId, allFolders);
            if (subFolderList != null && subFolderList.Count > 0)
            {
                foreach (var listBasketInSubFolder in
                    subFolderList.Select(
                        folder => GetBasketsByFolderIdRecursive(folder.CartFolderId, listBasket, allFolders)).Where(
                            listBasketInSubFolder => listBasketInSubFolder != null && listBasketInSubFolder.Count > 0))
                {
                    listBasketInFolder.AddRange(listBasketInSubFolder);
                }
            }
            return (listBasketInFolder.Count > 0) ? listBasketInFolder : new List<Basket>();
        }

        /// <summary>
        /// Gets the list carts in folder and its sub-folders.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <returns>
        /// List of carts in folder and its sub-folder
        /// </returns>
        public List<Basket> GetBasketsByFolderIdRecursive(string folderId)
        {
            List<Basket> listBasket = GetBaskets();
            ICollection<CartFolder> allFolders = GetCurrentUserFolderList();
            return GetBasketsByFolderIdRecursive(folderId, listBasket, allFolders);
        }

        /// <summary>
        /// Gets the baskets by B&T NextGen property.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="value">The value of given property.</param>
        /// <param name="listBasket"></param>
        /// <returns>list of basket had property with given value</returns>
        public List<Basket> GetBasketsByProperty(string propertyName, string value, List<Basket> listBasket)
        {
            var resultList = new List<Basket>();
            foreach (Basket basket in listBasket)
            {
                Type type = basket.GetType();
                if (type.GetProperty(propertyName).GetValue(basket, null).ToString() == value)
                {
                    resultList.Add(basket);
                }
            }
            return resultList;
        }


        /// <summary>
        /// Creates the basket.
        /// </summary>
        /// <param name="basketName">Name of the basket.</param>
        /// <param name="folderId">The folder id.</param>
        /// <param name="isPrimary"></param>
        /// <returns>The created basket</returns>
        public Cart CreateBasket(string basketName, string folderId, bool isPrimary = false)
        {
            return CreateBasket(basketName, folderId, SiteContext.Current.UserId);
        }

        private Cart CreateBasket(string basketName, string folderId, string userId, bool isPrimary = false)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);

            var cartAccounts = new List<CartAccount>();

            var profileController = ProfileController.Current;
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);
            profileController.UserProfileRelated.DefaultBookAccountNeeded = true;
            profileController.UserProfileRelated.DefaultEntertainmentAccountNeeded = true;
            var user = profileController.GetUserById(userId);

            if (user != null)
            {
                if (user.DefaultBookAccount != null)
                {
                    var account = ((Account)user.DefaultBookAccount.Target);

                    if (account != null)
                    {
                        var bookAccount = new CartAccount
                                              {
                                                  AccountID = account.AccountNumber,
                                                  AccountType = (int)AccountType.Book
                                              };
                        cartAccounts.Add(bookAccount);
                    }
                }
                if (user.DefaultEntertainmentAccount != null)
                {
                    var account = ((Account)user.DefaultEntertainmentAccount.Target);

                    if (account != null)
                    {
                        var entAccount = new CartAccount
                                             {
                                                 AccountID = account.AccountNumber,
                                                 AccountType = (int)AccountType.Entertainment
                                             };

                        cartAccounts.Add(entAccount);
                    }
                }
            }

            //Add default empty book account
            if (!IsContainsGivenAccountType(AccountType.Book, cartAccounts))
            {
                cartAccounts.Add(new CartAccount
                {
                    AccountID = string.Empty,
                    AccountType = (int)AccountType.Book
                });
            }
            //Add default empty entertainment account
            if (!IsContainsGivenAccountType(AccountType.Entertainment, cartAccounts))
            {
                cartAccounts.Add(new CartAccount
                {
                    AccountID = string.Empty,
                    AccountType = (int)AccountType.Entertainment
                });
            }

            Cart cart = cartManager.CreateCart(basketName, isPrimary, folderId, cartAccounts);
            return cart;
        }

        private static bool IsContainsGivenAccountType(AccountType accountType, IEnumerable<CartAccount> cartAccounts)
        {
            if (cartAccounts != null)
            {
                foreach (var cartAccount in cartAccounts)
                {
                    if (cartAccount.AccountType == (int)accountType)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Creates the basket.
        /// </summary>
        /// <param name="basketName">Name of the basket.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="folderId">The folder id.</param>
        /// <param name="bookAccountNumber">The book account id.</param>
        /// <param name="entertainmentAccountId">The entertainment account id.</param>
        /// <param name="ebookAccountIds">Ebook account ids</param>
        /// <param name="pONumber">The p O number.</param>
        /// <param name="status">The status.</param>
        /// <param name="activePrimaryCart">if set to <c>true</c> [active primary cart].</param>
        /// <returns>The created basket</returns>
        public Basket CreateBasket(string basketName, string userId, string folderId, string bookAccountNumber,
                                   string entertainmentAccountId, Dictionary<AccountType, string> ebookAccountIds,
                                   string pONumber, string status, bool activePrimaryCart, string vipAccountId = null)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);

            var cartAccounts = new List<CartAccount>
                                   {
                                       new CartAccount
                                           {
                                               AccountID = bookAccountNumber ?? string.Empty,
                                               AccountType = (int) AccountType.Book,
                                               PONumber = pONumber
                                           },
                                       new CartAccount
                                           {
                                               AccountID = entertainmentAccountId ?? string.Empty,
                                               AccountType = (int) AccountType.Entertainment,
                                               PONumber = pONumber
                                           }
                                       
                                   };
            var orgPremiumServicesStatus = OrganizationDAO.Instance.GetOrganizationPremiumServices(SiteContext.Current.OrganizationId);
            var marketType = SiteContext.Current.MarketType.HasValue ? SiteContext.Current.MarketType.Value : MarketType.Any;
            if (marketType == MarketType.Retail && IsUSCountry(SiteContext.Current.CountryCode) && orgPremiumServicesStatus.vipEnabled)
            {
                cartAccounts.Add(new CartAccount
                                               {
                                                   AccountID = vipAccountId ?? string.Empty,
                                                   AccountType = (int)AccountType.VIP,
                                                   PONumber = pONumber
                                               });
            }
            //Add ebook accounts
            if (ebookAccountIds != null)
            {
                cartAccounts.AddRange(ebookAccountIds.Keys.Select(accountType => new CartAccount()
                                                                                     {
                                                                                         AccountID = ebookAccountIds[accountType],
                                                                                         AccountType = (int)accountType,
                                                                                         PONumber = pONumber
                                                                                     }));
            }

            Cart cart = cartManager.CreateCart(basketName, activePrimaryCart, folderId, cartAccounts);

            return cart.ToBasket();
        }

        private static bool IsUSCountry(string countryCode)
        {
            bool isUS = false;

            if (!string.IsNullOrEmpty(countryCode))
            {
                isUS = (countryCode == "US" || countryCode == "USA");
            }
            return isUS;
        }

        /// <summary>
        /// Creates the primary basket.
        /// </summary>
        /// <param name="basketName">Name of the basket.</param>
        /// <param name="folderId">The folder id.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public Cart CreatePrimaryBasket(string basketName, string folderId, string userId)
        {
            return CreateBasket(basketName, folderId, userId, true);
        }

        public Cart SetCartAsPrimaryByName(string cartName)
        {
            if (!string.IsNullOrEmpty(SiteContext.Current.UserId) && !string.IsNullOrEmpty(cartName))
            {
                var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
                if (cartManager != null)
                {
                    var cart = cartManager.GetCartByName(cartName);
                    var result = cartManager.SetCartAsPrimary(cart.CartId);
                    cartManager.SetPrimaryCartChanged();
                    return result;
                }
            }
            return null;
        }

        public Cart SetCartAsPrimaryById(string cartId)
        {
            if (!string.IsNullOrEmpty(SiteContext.Current.UserId) && !string.IsNullOrEmpty(cartId))
            {
                CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
                if (cartManager != null)
                {
                    var result = cartManager.SetCartAsPrimary(cartId);
                    cartManager.SetPrimaryCartChanged();
                    return result;
                }
            }
            return null;
        }

        /// <summary>
        /// Restores the baskets.
        /// </summary>
        /// <param name="basketIds"></param>
        /// <param name="targetFolderId"></param>
        public void RestoreBaskets(List<string> basketIds, string targetFolderId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            cartManager.RestoreCarts(basketIds, targetFolderId);
        }

        public void CopyCartListToFolder(List<string> cartIds, string destFolderId, CartCopyType cartCopyType, bool copyESP)
        {
            //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
            if (string.IsNullOrEmpty(destFolderId))
                return;
            //
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            cartManager.CreateCopyOfCarts(cartIds, destFolderId, cartCopyType, copyESP);
        }

        /// <summary>
        /// Delete baskets
        /// </summary>
        /// <param name="basketIds"></param>
        /// <param name="userId"></param>
        public void DeleteBaskets(List<string> basketIds, string userId = "")
        {
            CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId).DeleteCarts(basketIds, userId);
        }

        /// <summary>
        /// Gets the primary cart.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public Cart GetPrimaryCart(string userId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            return cartManager.GetPrimaryCart();
        }

        /// <summary>
        /// Gets the primary cart.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        //public Cart GetPrimaryCart(string userId)
        //{
        //    CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
        //    Cart cart = cartManager.GetPrimaryCart();            
        //    return cart;
        //}

        /// <summary>
        /// Gets the primary cart.
        /// </summary>
        /// <returns></returns>
        public Cart GetPrimaryCart()
        {
            return GetPrimaryCart(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the basket by id.
        /// </summary>
        /// <param name="basketId">The basket id.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public Basket GetBasketById(string basketId, string userId)
        {
            var cart = GetCartById(basketId, userId);
            if (cart != null)
            {
                return cart.ToBasket();
            }
            return null;
        }

        public Cart GetCartById(string cartId, string userId, bool isSubmitOrder = false)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);

            var cart = isSubmitOrder ? cartManager.GetCartByIdForSubmitting(cartId) : cartManager.GetCartById(cartId);
            AddCartObjectToSessionCacheForOneRequest(cart);
            return cart;
        }

        public Cart GetCartByIdForOrg(string cartId, string orgId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForOrganization(orgId);
            return cartManager.GetCartById(cartId);
        }

        public bool CheckBasketforCalMerch(string cartId, string userId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            return cartManager.CheckBasketforCalMerch(cartId);
        }

        #region LineItems in Cart

        /// <summary>
        /// Updates the line items quantity to cart.
        /// </summary>
        /// <param name="updatedLineItems">The updated line items.</param>
        /// <param name="cartId">The destination basket.</param>
        /// <param name="needToReprice">Reprice needs indicator</param>
        public void UpdateLineItemsQuantityToCart(List<LineItem> updatedLineItems, string cartId, bool needToReprice = true, string contextUserId = "")
        {
            if (updatedLineItems == null || updatedLineItems.Count == 0 || string.IsNullOrEmpty(cartId))
                return;

            var dict = new Dictionary<string, Dictionary<string, string>>();
            foreach (var lineItem in updatedLineItems)
            {
                if (lineItem != null)
                {
                    dict.Add(lineItem.Id, new Dictionary<string, string>
                                          {
                                              {"Quantity", lineItem.Quantity.ToString()},
                                              {"PoNumber", lineItem.PONumber},
                                              {"BibNumber", lineItem.Bib}
                                          });
                }
            }

            var cart = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId).GetCartById(cartId);
            if (cart != null)
                cart.UpdateLineItemsQuantity(dict, needToReprice, contextUserId);
        }

        /// <summary>
        /// Updates the line items quantity to cart.
        /// </summary>
        /// <param name="lineItemQuantities"> </param>
        /// <param name="cartId">The destination basket.</param>
        /// <param name="userId"> </param>
        /// <param name="needToReprice">Reprice needs indicator</param>
        /// <param name="lineItemIds"> </param>
        public void UpdateLineItemsQuantityForQuickCart(string[] lineItemIds, string[] lineItemQuantities, string cartId, string userId, bool needToReprice = true)
        {
            var dict = new Dictionary<string, Dictionary<string, string>>();
            for (var i = 0; i < lineItemIds.Count(); i++)
            {
                dict.Add(lineItemIds[i], new Dictionary<string, string>
                                                   {
                                                       {"Quantity", lineItemQuantities[i]},
                                                       {"PoNumber", null},
                                                       {"BibNumber", null}
                                                   });
            }
            var cart = new Cart(cartId, userId, "");
            cart.UpdateLineItemsQuantity(dict, needToReprice);
        }

        /// <summary>
        /// Updates the line items PO and BIB number to cart.
        /// </summary>
        /// <param name="updatedLineItems">The updated line items.</param>
        /// <param name="cartId">The destination basket.</param>
        /// <param name="needToReprice">Reprice needs indicator</param>
        public void UpdateLineItemsInfoToCart(List<LineItem> updatedLineItems, string cartId, bool needToReprice = true)
        {
            if (updatedLineItems == null || updatedLineItems.Count == 0)
                return;

            var dict = new Dictionary<string, Dictionary<string, string>>();
            foreach (var lineItem in updatedLineItems)
            {
                dict.Add(lineItem.Id, new Dictionary<string, string>
                                                   {
                                                       {"Quantity", lineItem.Quantity.ToString()},
                                                       {"PoNumber", lineItem.PONumber},
                                                       {"BibNumber", lineItem.Bib}
                                                   });
            }
            var cart = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId).GetCartById(cartId);
            cart.UpdateLineItemsInfo(dict, needToReprice);
        }

        public void UpdateLineItemsNotesToCart(List<LineItem> updatedLineItems, string cartId, string userId)
        {
            var dict = new Dictionary<string, Dictionary<string, string>>();
            foreach (var lineItem in updatedLineItems)
            {
                dict.Add(lineItem.Id, new Dictionary<string, string>
                                                   {
                                                       {"Note", lineItem.BTLineItemNote}
                                                   });
            }
            var cart = CartContext.Current.GetCartManagerForUser(userId).GetCartById(cartId);
            cart.UpdateLineItemsNotes(dict);
        }

        public PrimaryCart GetPrimaryCartObject()
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            if (cartManager == null) return null;

            Cart cart = cartManager.GetPrimaryCart();
            if (cart != null)
            {
                var primaryCart = new PrimaryCart { Cart = cart };
                return primaryCart;
            }
            return null;
        }

        /// <summary>
        /// Deletes the line item in cart.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="lineItemIds">The line item ids.</param>
        /// <param name="basketId">The basket.</param>
        public Dictionary<string, string> DeleteLineItemInCart(string basketId, string userId, List<string> lineItemIds, bool isCallPricingService = true)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            if (cartManager != null)
            {
                var errorTable = cartManager.RemoveCartLineItems(basketId, lineItemIds, isCallPricingService);
                return errorTable;
            }
            return null;
        }

        #endregion

        #region Move Carts

        /// <summary>
        /// Moves the cart to pre-definded folder.
        /// </summary>
        /// <param name="selectedCart">The selected cart.</param>
        /// <param name="destinationFolderId">The destination folder id.</param>
        /// <param name="newCartStatus">The cart status.</param>
        public void MoveCartToFolder(Basket selectedCart, string destinationFolderId, string newCartStatus)
        {
            var selectedCarts = new List<Basket> { selectedCart };
            var destinationFolderIds = new List<string> { destinationFolderId };
            MoveCartListToFolder(selectedCarts, destinationFolderIds);
        }

        /// <summary>
        /// Moves the cart to folder.
        /// </summary>
        /// <param name="basketName">Name of the basket.</param>
        /// <param name="destinationFolderId">The destination folder id.</param>
        /// <param name="userId">The user id.</param>
        public void MoveCartToFolder(string basketName, string destinationFolderId, string userId)
        {
            Basket selectedCart = GetBasketByName(basketName, userId);
            CartContext.Current.GetCartManagerForUser(userId).MoveCartToFolder(selectedCart.Id, destinationFolderId);
        }

        public void MoveCartListIdToFolder(List<string> cartIds, string destinationFolderId, string userId)
        {
            CartContext.Current.GetCartManagerForUser(userId).MoveCartsToFolder(cartIds, destinationFolderId);
        }


        /// <summary>
        /// Moves the carts in pre-defined folder.
        /// </summary>
        /// <param name="sourceFolderId">The source folder id.</param>
        /// <param name="destinationFolderId">The destination folder id.</param>
        /// <param name="newCartStatus">The cart status.</param>
        public void MoveCartsByFolderId(string sourceFolderId, string destinationFolderId, string newCartStatus)
        {
            List<Basket> listBasketInFolder = GetBasketsByFolderIdRecursive(sourceFolderId);
            if (listBasketInFolder == null || listBasketInFolder.Count <= 0) return;
            MoveCartListIdToFolder(listBasketInFolder.Select(b => b.Id).ToList(), destinationFolderId,
                                   listBasketInFolder[0].UserId);
        }

        /// <summary>
        /// Moves the cart list to folder.
        /// </summary>
        /// <param name="basketList">The basket list.</param>
        /// <param name="destinationFolderIdList">The destination folder id list.</param>
        public void MoveCartListToFolder(List<Basket> basketList, List<string> destinationFolderIdList)
        {
            for (int i = 0; i < basketList.Count; i++)
            {
                CartContext.Current.GetCartManagerForUser(basketList[i].UserId).MoveCartToFolder(basketList[i].Id,
                                                                                                 destinationFolderIdList
                                                                                                     [i]);
            }
        }

        #endregion

        #region Archive and Restore Carts

        public void ArchiveCarts(string userId, List<string> cartIDs)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            cartManager.ArchiveCarts(cartIDs);
        }

        #endregion

        #endregion

        #region Extended Methods - Basket Controller for admin - control multi user's basket

        public void UpdateLineItemNotes(string basketId, string lineItemId, string lineItemNotes, string userId)
        {
            Cart cart = CartContext.Current.GetCartManagerForUser(userId).GetCartById(basketId);
            if (cart != null)
            {
                cart.UpdateLineItemNote(lineItemNotes, lineItemId);
            }
        }

        #endregion

        #region NextGen baskets

        /// <summary>
        /// Gets the ordered line items.
        /// </summary>
        /// <param name="basketId">The basket id.</param>
        /// <returns></returns>
        public Dictionary<string, List<OrderedLineItems>> GetOrderedLineItems(string basketId)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            Dictionary<string, List<OrderedLineItems>> orderedLines = cartManager.GetOrderedLineItems(basketId);

            string entertainmentWarehouse;
            string bookWarehouse;
            GetPrimaryWarehouseInAssociatedAccount(basketId, out bookWarehouse, out entertainmentWarehouse);
            AssignPrimaryWarehouseIfNeeded(orderedLines, bookWarehouse, entertainmentWarehouse);
            return orderedLines;
        }

        /// <summary>
        /// Gets the ordered line items.
        /// </summary>
        /// <param name="basketId">The basket id.</param>
        /// <param name="btKey">The bt key.</param>
        /// <returns></returns>
        public List<OrderedLineItems> GetOrderedLineItems(string basketId, string btKey)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            List<OrderedLineItems> orderedLines = cartManager.GetOrderedLineItems(basketId, btKey);
            string entertainmentWarehouse;
            string bookWarehouse;
            GetPrimaryWarehouseInAssociatedAccount(basketId, out bookWarehouse, out entertainmentWarehouse);
            AssignPrimaryWarehouseIfNeeded(orderedLines, bookWarehouse, entertainmentWarehouse);
            return orderedLines;
        }

        internal void GetPrimaryWarehouseInAssociatedAccount(string basketId, out string bookWarehouse,
                                                             out string entertainmentWarehouse)
        {
            Basket basket = GetBasketById(basketId);

            bookWarehouse = GetPrimaryWarehouse(basket.BookAccountId);
            entertainmentWarehouse = GetPrimaryWarehouse(basket.EntertainmentAccountId);
        }

        public string GetPrimaryWarehouse(string accountId)
        {
            string primaryWarehouse = string.Empty;

            if (!string.IsNullOrEmpty(accountId))
            {
                AdministrationProfileController profileControllerForAdmin = AdministrationProfileController.Current;
                profileControllerForAdmin.AccountRelated.PrimaryWarehouseNeeded = true;
                Account account = profileControllerForAdmin.GetAccountById(accountId);

                if (account != null && account.PrimaryWarehouse != null)
                {
                    Warehouse wareHouse = account.PrimaryWarehouse.Target;
                    if (wareHouse != null)
                    {
                        primaryWarehouse = wareHouse.Code;
                    }
                }
            }
            return primaryWarehouse;
        }

        private void AssignPrimaryWarehouseIfNeeded(Dictionary<string, List<OrderedLineItems>> orderedLines,
                                                    string bookWarehouse, string entertainmentWarehouse)
        {
            foreach (var keyValuePair in orderedLines)
            {
                AssignPrimaryWarehouseIfNeeded(keyValuePair.Value, bookWarehouse, entertainmentWarehouse);
            }
        }

        private void AssignPrimaryWarehouseIfNeeded(IEnumerable<OrderedLineItems> orderedLines, string bookWarehouse,
                                                    string entertainmentWarehouse)
        {
            foreach (OrderedLineItems orderedLineItem in orderedLines)
            {
                AssignPrimaryWarehouseIfNeeded(orderedLineItem, bookWarehouse, entertainmentWarehouse);
            }
        }

        internal void AssignPrimaryWarehouseIfNeeded(OrderedLineItems orderedLineItem, string bookWarehouse,
                                                     string entertainmentWarehouse)
        {
            if (string.IsNullOrEmpty(orderedLineItem.WareHouse))
            {
                if (orderedLineItem.ProductType == "0" || orderedLineItem.ProductType.ToLower() == "book")
                {
                    orderedLineItem.WareHouse = bookWarehouse;
                }
                else
                {
                    orderedLineItem.WareHouse = entertainmentWarehouse;
                }
            }
        }

        /// <summary>
        /// Gets the next gen basket by id.
        /// </summary>
        /// <param name="basketId">The basket id.</param>
        /// <returns></returns>
        public Basket GetBasketById(string basketId)
        {
            return GetBasketById(basketId, SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the next gen basket.
        /// </summary>
        /// <param name="basketName">Name of the basket.</param>
        /// <returns></returns>
        public Basket GetBasketByName(string basketName)
        {
            return GetBasketByName(basketName, SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the next gen basket.
        /// </summary>
        /// <param name="basketName">Name of the basket.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        private Basket GetBasketByName(string basketName, string userId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            Cart cart = cartManager.GetCartByName(basketName);
            return cart != null ? cart.ToBasket() : null;
        }

        public bool IsPrimaryCartOfUser(string cartId, string userId)
        {
            if (string.IsNullOrEmpty(userId)) return false;

            var cart = GetPrimaryCart(userId);
            if (cart == null) return false;

            return cart.CartId == cartId;
        }

        #endregion

        #region CyberSource

        private List<string> GetCreditCardList(string accountId)
        {
            var listResult = new List<string>();

            // Get current CC list of Account
            var queryAccount = new CommerceQuery<Account>();
            queryAccount.SearchCriteria.Model.Id = accountId;
            queryAccount.Model.Properties.Add(CommerceEntity.PropertyName.Id);

            {
                var queryCcList = new CommerceQueryRelatedItem<CreditCard>(Account.RelationshipName.CreditCards);
                queryCcList.Model.Properties.Add(CommerceEntity.PropertyName.Id);

                queryAccount.RelatedOperations.Add(queryCcList);
            }
            //
            var helper = new BrokerHelper();
            helper.AddRequest(queryAccount);
            helper.Execute();
            //
            var response = (CommerceQueryOperationResponse)helper.Responses[0];
            var result = (Account)response.CommerceEntities[0];
            if (result != null && result.CreditCards != null && result.CreditCards.Count > 0)
            {
                listResult.AddRange(
                    result.CreditCards.Select(creditCard => (CreditCard)creditCard.Target).Select(item => item.Id));
            }
            return listResult;
        }

        /// <summary>
        /// Deletes the credit cart.
        /// </summary>
        /// <param name="accountId">The account id.</param>
        /// <param name="creditCard">The credit card.</param>
        public void DeleteCreditCard(string accountId, CreditCard creditCard)
        {
            var helper = new BrokerHelper();
            var creditCardId = creditCard.Id;
            var addressId = creditCard.BillingAddressId;
            if (!string.IsNullOrEmpty(creditCardId))
            {
                var creditCardDelete = new CommerceDelete<CreditCard, CommerceModelSearch<CreditCard>>();
                creditCardDelete.SearchCriteria.Model.Id = creditCardId;
                helper.AddRequest(creditCardDelete);
            }
            //
            if (!string.IsNullOrEmpty(addressId))
            {
                var addressDelete = new CommerceDelete<Address, CommerceModelSearch<Address>>();
                addressDelete.SearchCriteria.Model.Id = addressId;
                helper.AddRequest(addressDelete);
            }
            //
            if (!string.IsNullOrEmpty(accountId))
            {

                List<SendCreditCardERPActiveCreditCards> cclist = new List<SendCreditCardERPActiveCreditCards>();

                var req = new CommerceRequest();
                req.Operations = new List<CommerceOperation>();
                List<string> lstAccountId = new List<string>();
                string newprimaryCCId = null;
                UpdateAccountForCreditCard(accountId, creditCardId, cclist, req, lstAccountId, false, out newprimaryCCId);
                //do not need to send CC when removing
                if (cclist.Count > 0)
                {
                    BizTalkServiceInstance biz = new BizTalkServiceInstance();
                    SendCreditCardERP ccContainer = new SendCreditCardERP();
                    ccContainer.SendCreditCardERPDetails = cclist.ToArray();

                    try
                    {
                        biz.SendActiveCreditCardERP(ccContainer);
                        //send to Biztalk successfully
                        //if (!string.IsNullOrEmpty(newprimaryCCId))
                        //{
                        //    var successCreditCard = new CommerceCreate<CreditCard>();
                        //    successCreditCard.Model.Id = newprimaryCCId;
                        //    successCreditCard.Model.TransmittedToERP = true;
                        //    req.Operations.Add(successCreditCard.ToOperation());
                        //}
                        //foreach (string accId in lstAccountId)
                        //    SetERPinAccount(accId, req, true);
                    }
                    catch (Exception ex)
                    {
                        Logger.Write("CreditCard", ex.Message);
                    }

                }
                if (req.Operations.Count > 0)
                    SiteContext.ProcessRequest(req);

            }
            helper.Execute();
        }

        /// <summary>
        /// Updates the credit card.
        /// </summary>
        /// <param name="accountId">The account id.</param>
        /// <param name="billToAddress">The bill to address.</param>
        /// <param name="creditCard">The credit card.</param>
        public void UpdateCreditCard(string accountId, Address billToAddress, CreditCard creditCard)
        {
            var helper = new BrokerHelper();
            if (!string.IsNullOrEmpty(creditCard.BillingAddressId))
            {
                var addressUpdate = new CommerceUpdate<Address, CommerceModelSearch<Address>>();
                addressUpdate.SearchCriteria.Model.Id = creditCard.BillingAddressId;
                addressUpdate.Model.Properties[Address.PropertyName.LastName] = billToAddress.LastName;
                addressUpdate.Model.Properties[Address.PropertyName.FirstName] = billToAddress.FirstName;
                addressUpdate.Model.Properties[Address.PropertyName.AddressName] = billToAddress.AddressName;
                addressUpdate.Model.Properties[Address.PropertyName.City] = billToAddress.City;
                addressUpdate.Model.Properties[Address.PropertyName.CountryRegionCode] = billToAddress.CountryRegionCode;
                addressUpdate.Model.Properties[Address.PropertyName.StateProvinceCode] = billToAddress.StateProvinceCode;
                addressUpdate.Model.Properties[Address.PropertyName.PhoneNumber] = billToAddress.PhoneNumber;
                addressUpdate.Model.Properties[Address.PropertyName.ZipPostalCode] = billToAddress.ZipPostalCode;
                helper.AddRequest(addressUpdate);
            }
            else
            {
                var newAddress = new CommerceCreate<Address>();
                creditCard.BillingAddressId = Guid.NewGuid().ToString();
                newAddress.Model.Id = creditCard.BillingAddressId;
                newAddress.Model.LastName = billToAddress.LastName;
                newAddress.Model.FirstName = billToAddress.FirstName;
                newAddress.Model.AddressName = billToAddress.AddressName;
                newAddress.Model.City = billToAddress.City;
                newAddress.Model.CountryRegionCode = billToAddress.CountryRegionCode;
                newAddress.Model.StateProvinceCode = billToAddress.StateProvinceCode;
                newAddress.Model.PhoneNumber = billToAddress.PhoneNumber;
                newAddress.Model.ZipPostalCode = billToAddress.ZipPostalCode;
                helper.AddRequest(newAddress);
            }
            bool isPrimary = false;
            if (!string.IsNullOrEmpty(creditCard.Id))
            {
                var creditCartUpdate = new CommerceUpdate<CreditCard, CommerceModelSearch<CreditCard>>();
                creditCartUpdate.SearchCriteria.Model.Id = creditCard.Id;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.ExpirationYear] = creditCard.ExpirationYear;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.ExpirationMonth] = creditCard.ExpirationMonth;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.CreditCardNumber] =
                    creditCard.CreditCardNumber;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.BTCreditCardToken] =
                    creditCard.BTCreditCardToken;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.CreditCardType] = creditCard.CreditCardType;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.Alias] = creditCard.Alias;
                creditCartUpdate.Model.Properties[CreditCard.PropertyName.CreditCardIdentifier] = creditCard.CreditCardIdentifier;

                //creditCartUpdate.Model.Properties[CreditCard.PropertyName.SubscriptionId] = creditCard.SubscriptionId;
                //creditCartUpdate.Model.Properties[CreditCard.PropertyName.SubscriptionIdPublicSignature] = creditCard.SubscriptionIdPublicSignature;
                creditCartUpdate.Model.Properties[PaymentAccount.PropertyName.BillingAddressId] = creditCard.BillingAddressId;
                CreditCard cc = AdministrationProfileController.Current.GetCreditCardById(creditCard.Id);
                if (cc != null && cc.PrimaryIndicator.HasValue && cc.PrimaryIndicator.Value)
                {
                    creditCartUpdate.Model.Properties[CreditCard.PropertyName.TransmittedToERP] = false;
                    isPrimary = true;
                }
                helper.AddRequest(creditCartUpdate);

            }

            helper.Execute();
            if (!string.IsNullOrEmpty(creditCard.Id) && isPrimary)
                AdministrationProfileController.Current.SendCreditCardToBiztalk(accountId, creditCard);
        }

        public void AddAditionalCreditCard(string accountId, Address billToAddress, CreditCard creditCard)
        {
            var creditCardList = GetCreditCardList(accountId);
            // Create Address object
            var newAddress = new CommerceCreate<Address>();
            var addressId = Guid.NewGuid().ToString();
            newAddress.Model.Id = addressId;
            newAddress.Model.LastName = billToAddress.LastName;
            newAddress.Model.FirstName = billToAddress.FirstName;
            newAddress.Model.AddressName = billToAddress.AddressName;
            newAddress.Model.City = billToAddress.City;
            newAddress.Model.CountryRegionCode = billToAddress.CountryRegionCode;
            newAddress.Model.StateProvinceCode = billToAddress.StateProvinceCode;
            newAddress.Model.PhoneNumber = billToAddress.PhoneNumber;
            newAddress.Model.ZipPostalCode = billToAddress.ZipPostalCode;

            // Create Credit Card
            var newCreditCard = new CommerceCreate<CreditCard>();
            var creditCardId = Guid.NewGuid().ToString();
            newCreditCard.Model.Id = creditCardId;
            newCreditCard.Model.ExpirationYear = creditCard.ExpirationYear;
            newCreditCard.Model.ExpirationMonth = creditCard.ExpirationMonth;
            newCreditCard.Model.CreditCardNumber = creditCard.CreditCardNumber;
            newCreditCard.Model.CreditCardIdentifier = creditCard.CreditCardIdentifier;
            newCreditCard.Model.BTCreditCardToken = creditCard.BTCreditCardToken;
            newCreditCard.Model.Alias = creditCard.Alias;
            newCreditCard.Model.BillingAddressId = addressId;
            newCreditCard.Model.CreditCardType = creditCard.CreditCardType;
            newCreditCard.Model.TransmittedToERP = false;//Set 2 values as default : BT-1889 TFS 636 - Credit Cards flags
            //newCreditCard.Model.SubscriptionId = creditCard.SubscriptionId;
            //newCreditCard.Model.SubscriptionIdPublicSignature = creditCard.SubscriptionIdPublicSignature;
            newCreditCard.Model.PrimaryIndicator = true;
            newCreditCard.Model.Properties[CreditCard.PropertyName.CardContactUser] = SiteContext.Current.UserId;

            var req = new CommerceRequest();
            req.Operations = new List<CommerceOperation> { newAddress.ToOperation(), newCreditCard.ToOperation() };
            /////////////////

            SendCreditCardERPActiveCreditCards cc = new SendCreditCardERPActiveCreditCards();

            cc.alias = creditCard.Alias;
            cc.card_type = creditCard.CreditCardType;
            cc.cardID = creditCardId;
            cc.erp_account_id = string.Empty;//erp account will be updated below UpdateAccountForCreditCard
            cc.expiration_month = byte.Parse(creditCard.ExpirationMonth.ToString());
            cc.expiration_year = ushort.Parse(creditCard.ExpirationYear.ToString());
            cc.last_4_digits = creditCard.CreditCardIdentifier;
            cc.is_Tolas = string.Empty;//will be updated below UpdateAccountForCreditCard
            //////////////////
            List<SendCreditCardERPActiveCreditCards> cclist = new List<SendCreditCardERPActiveCreditCards>();
            cclist.Add(cc);
            List<string> lstAccountId = new List<string>();
            string newprimaryCCId = null;
            UpdateAccountForCreditCard(accountId, creditCardId, cclist, req, lstAccountId, true, out newprimaryCCId);
            if (string.IsNullOrEmpty(cc.erp_account_id))
                cclist.Remove(cc);


            try
            {
                if (cclist.Count > 0)
                {
                    BizTalkServiceInstance biz = new BizTalkServiceInstance();
                    SendCreditCardERP ccContainer = new SendCreditCardERP();
                    ccContainer.SendCreditCardERPDetails = cclist.ToArray();
                    biz.SendActiveCreditCardERP(ccContainer);
                }
                //send to Biztalk successfully
                //var successCreditCard = new CommerceCreate<CreditCard>();
                //successCreditCard.Model.Id = creditCardId;
                //successCreditCard.Model.TransmittedToERP = true;
                //req.Operations.Add(successCreditCard.ToOperation());

                //foreach (string accId in lstAccountId)
                //    SetERPinAccount(accId, req, true);
            }
            catch (Exception ex)
            {
                Logger.Write("CreditCard", ex.Message);
            }
            SiteContext.ProcessRequest(req);
        }

        private void UpdateAccountForCreditCard(string accountId, string creditCardId, List<SendCreditCardERPActiveCreditCards> cclist, CommerceRequest req, List<string> lstAccountId, bool isAddCC, out string newPrimaryCardId)
        {
            newPrimaryCardId = null;
            var profileContext = AdministrationProfileController.Current;
            var currentAccount = profileContext.GetAccountForCreditCard(accountId);
            if (currentAccount == null)
            {
                Logger.Write("TS360", "currentAccount is null in UpdateAccountForCreditCard", false);
                return;
            }

            if (isAddCC)
            {
                if (currentAccount.AccountType == AccountType.Entertainment.ToString())//TOLAS
                {
                    if (cclist.Count == 1)
                    {
                        cclist[0].is_Tolas = true.ToString();
                        cclist[0].erp_account_id = currentAccount.AccountNumber;
                        lstAccountId.Add(currentAccount.Id);
                    }
                }
                AddCreditCardintoAccount(creditCardId, currentAccount.Id, req);
            }
            else
            {
                CreditCard newPrimaryCC = null;
                string newPrimaryId = RemoveCreditCardinAccount(creditCardId, currentAccount.Id, req, out newPrimaryCC);
                if (!string.IsNullOrEmpty(newPrimaryId) && newPrimaryCC != null)//old primary card is deleted
                {
                    var cc = AdministrationProfileController.Current.CopyCreditCard(newPrimaryCC);
                    cc.is_Tolas = (currentAccount.AccountType == AccountType.Entertainment.ToString()).ToString();
                    cc.erp_account_id = currentAccount.AccountNumber;
                    cclist.Add(cc);
                    lstAccountId.Add(currentAccount.Id);
                    newPrimaryCardId = newPrimaryId;

                }
                //if (currentAccount.AccountType == AccountType.Entertainment.ToString())//TOLAS
                //{
                //    if (newPrimaryCC != null)
                //    {
                //        SendCreditCardERPActiveCreditCards cc = CopyCreditCard(newPrimaryCC);
                //        cc.erp_account_id = currentAccount.AccountNumber;
                //        cc.is_Tolas = true.ToString();
                //        cclist.Add(cc);
                //    }
                //}
            }
            //}
            //else//SOP//
            if (currentAccount.AccountType != AccountType.Entertainment.ToString())// not TOLAS
            {

                //set true in order not to send the account to SOP.
                SetERPinAccount(currentAccount.Id, req, true);

                //account = (Account)currentAccount.BillToAccount.Target;
                ICollection<Account> lstAcc = AccountDAO.Instance.GetShipToAccountsByBilltoId(currentAccount.Id);
                foreach (Account acc in lstAcc)
                {
                    if (isAddCC)
                    {
                        var cc = CopyCreditCard(cclist[0]);
                        cc.is_Tolas = (acc.AccountType == AccountType.Entertainment.ToString()).ToString();
                        cc.erp_account_id = acc.AccountNumber;
                        cclist.Add(cc);

                        AddCreditCardintoAccount(creditCardId, acc.Id, req);
                        lstAccountId.Add(acc.Id);
                    }
                    else
                    {
                        CreditCard newPrimaryCC = null;
                        string newPrimaryId = RemoveCreditCardinAccount(creditCardId, acc.Id, req, out newPrimaryCC);
                        if (!string.IsNullOrEmpty(newPrimaryId) && newPrimaryCC != null)//old primary card is deleted
                        {
                            var cc = AdministrationProfileController.Current.CopyCreditCard(newPrimaryCC);
                            cc.is_Tolas = (currentAccount.AccountType == AccountType.Entertainment.ToString()).ToString();
                            cc.erp_account_id = acc.AccountNumber;
                            cclist.Add(cc);
                            lstAccountId.Add(acc.Id);

                        }
                    }
                }
            }
        }


        private SendCreditCardERPActiveCreditCards CopyCreditCard(SendCreditCardERPActiveCreditCards copyingCC)
        {
            SendCreditCardERPActiveCreditCards cc = new SendCreditCardERPActiveCreditCards();
            cc.alias = copyingCC.alias;
            cc.card_type = copyingCC.card_type;
            cc.cardID = copyingCC.cardID;
            cc.erp_account_id = copyingCC.erp_account_id;
            cc.expiration_month = copyingCC.expiration_month;
            cc.expiration_year = copyingCC.expiration_year;
            cc.last_4_digits = copyingCC.last_4_digits;
            cc.is_Tolas = cc.is_Tolas;
            return cc;
        }
        private string UpdatePrimaryCreditCard(string creditCardId, string accountId, CommerceRequest req, out CreditCard newPrimaryCC, bool isAddCC)
        {
            var profileContext = AdministrationProfileController.Current;
            var account = profileContext.GetAccountForCreditCard(accountId);
            var cmRelationShipList = account.CreditCards;
            string newPrimaryId = string.Empty;
            string currentPrimaryIdDeleted = string.Empty;
            newPrimaryCC = null;
            if (cmRelationShipList != null && cmRelationShipList.Count > 0)
            {
                foreach (var cmRelationShip in cmRelationShipList)
                {
                    if (cmRelationShip != null && cmRelationShip.Target != null && cmRelationShip.Target.Id != null)
                    {
                        if (isAddCC)//unset other CC's primary column
                            req.Operations.Add(SetPrimaryCreditCard(cmRelationShip.Target.Id, false).ToOperation());
                        else
                        {
                            CreditCard cc = (CreditCard)cmRelationShip.Target;
                            if (cc.Id == creditCardId && cc.PrimaryIndicator.HasValue && cc.PrimaryIndicator.Value)
                                currentPrimaryIdDeleted = cc.Id;
                            else
                            {
                                newPrimaryId = cc.Id;
                                newPrimaryCC = cc;
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(currentPrimaryIdDeleted) && !string.IsNullOrEmpty(newPrimaryId) && !isAddCC)
                    req.Operations.Add(SetPrimaryCreditCard(newPrimaryId, true).ToOperation());
            }
            if (!string.IsNullOrEmpty(currentPrimaryIdDeleted))//deleting primary card
                return newPrimaryId;//can be empty or new primaryid
            return null;//deleting normal card or add new CC
        }
        private string RemoveCreditCardinAccount(string creditCardId, string accountId, CommerceRequest req, out CreditCard newPrimaryCC)
        {
            var newPrimaryId = UpdatePrimaryCreditCard(creditCardId, accountId, req, out newPrimaryCC, false);

            var ccListResult = GetCreditCardList(accountId);
            ccListResult.Remove(ccListResult.Where(c => c == creditCardId).FirstOrDefault());

            // Update CC list of Account
            var updateAccount = new CommerceUpdate<Account>();
            updateAccount.SearchCriteria.Model.Id = accountId;
            updateAccount.Model.Properties[Account.RelationshipName.CreditCards] = ccListResult.Count > 0 ? ccListResult.ToArray() : null;
            if (newPrimaryId != null)//old primary card is deleted
                updateAccount.Model.Properties[Account.RelationshipName.PreferredCreditCard] = string.IsNullOrEmpty(newPrimaryId) ? null : newPrimaryId;
            req.Operations.Add(updateAccount.ToOperation());

            return newPrimaryId;
        }
        private void AddCreditCardintoAccount(string creditCardId, string accountId, CommerceRequest req)
        {
            CreditCard newPrimaryCC = null;
            UpdatePrimaryCreditCard(creditCardId, accountId, req, out newPrimaryCC, true);

            // Add CC ID to ccList
            var creditCardList = GetCreditCardList(accountId);
            creditCardList.Add(creditCardId);

            // Update CC list of Account
            var updateAccount = new CommerceUpdate<Account>();
            updateAccount.SearchCriteria.Model.Id = accountId;
            updateAccount.Model.Properties[Account.RelationshipName.CreditCards] = creditCardList.ToArray();
            updateAccount.Model.Properties[Account.RelationshipName.PreferredCreditCard] = creditCardId;
            updateAccount.Model.Properties[Account.PropertyName.CCTransmittedToERP] = false;
            req.Operations.Add(updateAccount.ToOperation());
        }
        private void SetERPinAccount(string accountId, CommerceRequest req, bool isTransmittedtoERP)
        {
            var updateAccount = new CommerceUpdate<Account>();
            updateAccount.SearchCriteria.Model.Id = accountId;
            updateAccount.Model.CCTransmittedToERP = isTransmittedtoERP;
            req.Operations.Add(updateAccount.ToOperation());
        }
        private CommerceUpdate<CreditCard> SetPrimaryCreditCard(string creditCardId, bool isPrimary)
        {
            var updateCreditCard = new CommerceUpdate<CreditCard>();
            updateCreditCard.SearchCriteria.Model.Id = creditCardId;
            updateCreditCard.Model.PrimaryIndicator = isPrimary;
            return updateCreditCard;
        }
        #endregion

        #region Search and appy Pricing, Promotion for basket

        public List<LineItem> SearchByBasket(string basketId, string facetPath, string keyword, int sortBy,
                                                int pageSize, int pageNumber, GridFieldType gridFieldType, string gridCodeId, string gridText,
                                                string keywordType, out int totalLines, int sortDirection = 0,
                                                bool isFindAndReplace = false, bool isFreeText = false, bool isSharedCart = false, int? quantity = null)
        {
            var lineItems = GetLineItemsInBasketBySearch(basketId, facetPath, keyword, sortBy, pageSize,
                                                         pageNumber, out totalLines, gridFieldType, gridCodeId, gridText,
                                                         keywordType, sortDirection, isFindAndReplace,
                                                         isFreeText, isSharedCart, null, quantity);
            //return lineItems;
            MapProductFormatForOriginalEntryItems(lineItems);
            return lineItems;
        }

        //Search basket when uses function refine search inventory in cart details
        public List<LineItem> SearchByBasketWithFacets(string basketId, string facetPath, string keyword, int sortBy,
                                                int pageSize, int pageNumber, GridFieldType gridFieldType, string gridCodeId, string gridText,
                                                string keywordType, out int totalLines, int sortDirection = 0,
                                                bool isFindAndReplace = false, bool isFreeText = false, bool isSharedCart = false, bool isWriteFacetsSession = false)
        {
            var inventoryStatusArgList = GetInventoryStatusArgs(basketId, facetPath, keyword, sortBy, 9999,
                                                         1, out totalLines,
                                                         keywordType, sortDirection, isSharedCart);
            string matchingBtkeys;
            var cartLineFacet = InventoryHelper4MongoDb.GetInstance(basketId)
                                .GetInventoryFacetForCartDetails(inventoryStatusArgList, out matchingBtkeys, facetPath);

            if (isWriteFacetsSession)
            {
                var cacheKey = string.Format(Commerce.Portal.Common.Constants.CacheKeyConstant.CART_FACETS, basketId);
                VelocityCacheManager.Write(cacheKey, cartLineFacet, VelocityCacheLevel.Session);

                var cacheKey1 = string.Format(Commerce.Portal.Common.Constants.CacheKeyConstant.CART_MATCHING_BTKEYS_FROM_NOSQL, basketId);
                VelocityCacheManager.Write(cacheKey1, matchingBtkeys, VelocityCacheLevel.Session);
            }

            if (!string.IsNullOrEmpty(matchingBtkeys))
            {
                string[] btkeys = matchingBtkeys.Split(';');
                return GetLineItemsInBasketBySearch(basketId, facetPath, keyword, sortBy, pageSize,
                    pageNumber, out totalLines, gridFieldType, gridCodeId, gridText, keywordType, sortDirection,
                    isFindAndReplace, isFreeText, isSharedCart, btkeys);
            }
            else
                totalLines = 0;
            
            return new List<LineItem>();
        }

        //private string ExtractInventoryFacet(string facetPath)
        //{
        //    if (string.IsNullOrEmpty(facetPath)) return "";

        //    if (facetPath.Contains(InventoryHelper4MongoDb.Not_Available_for_Shipping))
        //        return InventoryHelper4MongoDb.Not_Available_for_Shipping;
        //    if (facetPath.Contains(InventoryHelper4MongoDb.Available_in_Primary_Warehouse))
        //        return InventoryHelper4MongoDb.Available_in_Primary_Warehouse;
        //    if (facetPath.Contains(InventoryHelper4MongoDb.Available_in_Secondary_Warehouse))
        //        return InventoryHelper4MongoDb.Available_in_Secondary_Warehouse;
        //    if (facetPath.Contains(InventoryHelper4MongoDb.Available_in_Other_Warehouses))
        //        return InventoryHelper4MongoDb.Available_in_Other_Warehouses;
        //    if (facetPath.Contains(InventoryHelper4MongoDb.Available_in_VIP_warehouses))
        //        return InventoryHelper4MongoDb.Available_in_VIP_warehouses;
        //    return "";
        //}

        private void MapProductFormatForOriginalEntryItems(List<LineItem> lineItems)
        {
            if (lineItems != null && lineItems.Count > 0)
            {
                var oEFormats = CommonHelper.GetSiteTerm(SiteTermName.OriginalEntryPhysicalFormat);

                foreach (var lineItem in lineItems)
                {
                    if (lineItem.IsOriginalEntryItem)
                    {
                        lineItem.FormatLiteral = CommonHelper.GetOriginalEntryFormat(lineItem.FormatLiteral, oEFormats);
                        if (string.IsNullOrEmpty(lineItem.ProductType))
                            lineItem.ProductType = string.Empty;
                    }
                }
            }
        }

        #endregion

        /// <summary>
        /// Generates the new name of the basket.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <param name="cartId">The cart id.</param>
        /// <returns></returns>
        public string GenerateNewBasketName(string userId, string cartId)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            var cart = cartManager.GetCartById(cartId);
            if (cart != null)
            {
                return cartManager.GenerateNewBasketName(cart.CartName);
            }
            return string.Empty;
        }

        /// <summary>
        /// Gets the name of the folder.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <param name="userFolders">The user folders.</param>
        /// <returns></returns>
        public string GetFolderName(string folderId, ICollection<CartFolder> userFolders)
        {
            string folderName = string.Empty;
            folderId = folderId.ToLower();
            foreach (CartFolder folder in userFolders)
            {
                if (folderId == folder.CartFolderId.ToLower())
                {
                    List<string> listName = GetFolderHiearchyContainBasket(folder, userFolders, 0);
                    for (int j = listName.Count - 1; j >= 0; j--)
                    {
                        folderName += listName[j] + " / ";
                    }
                    folderName = folderName.Substring(0, folderName.Length - 2);
                    break;
                }
            }
            return folderName;
        }

        /// <summary>
        /// Gets the folder hiearchy contain basket.
        /// </summary>
        /// <param name="folder">The folder.</param>
        /// <param name="userFolders">The user folders.</param>
        /// <param name="level">The level.</param>
        /// <returns></returns>
        private List<string> GetFolderHiearchyContainBasket(CartFolder folder, IEnumerable<CartFolder> userFolders,
                                                            int level)
        {
            var folderName = new List<string>();
            if (folder != null)
            {
                folderName.Add(folder.CartFolderName);

                if (!string.IsNullOrEmpty(folder.ParentFolderId) && userFolders != null)
                {
                    foreach (CartFolder cartFolder in userFolders)
                    {
                        if (cartFolder.CartFolderId.ToLower() == folder.ParentFolderId.ToLower() &&
                            cartFolder.CartFolderId.ToLower() != folder.CartFolderId.ToLower())
                        {
                            if (level < 2)
                            {
                                folderName.AddRange(GetFolderHiearchyContainBasket(cartFolder, userFolders, level + 1));
                            }
                            break;
                        }
                    }
                }
            }
            return folderName;
        }

        #region #######################CART FOLDER CONTROLLER #######################################

        #region Public Properties

        /// <summary>
        /// Gets or sets a value indicating whether this instance is cache empty.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is cache empty; otherwise, <c>false</c>.
        /// </value>
        public bool IsCacheEmpty { get; set; }

        #endregion

        #region BTNG Custom

        #region Get BasketFolders

        #region Get Current User's BasketFolders

        /// <summary>
        /// Gets the current user's basket foldes.
        /// </summary>
        /// <returns></returns>
        public ICollection<CartFolder> GetCurrentUserFolderList()
        {
            return GetFolderListByUserId(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the user defined cart folders.
        /// </summary>
        /// <param name="allFolders">All folders.</param>
        /// <param name="includedShared"></param>
        /// <returns></returns>
        public ICollection<CartFolder> GetUserDefinedCartFolders(ICollection<CartFolder> allFolders, bool includedShared = false)
        {
            if (allFolders == null)
            {
                return null;
            }

            if (!includedShared)
            {
                return
                allFolders.Where(
                    item =>
                    item.FolderType == CartFolderType.NormalFolderType ||
                    item.FolderType == CartFolderType.DefaultFolderType ||
                    item.FolderType == CartFolderType.RootFolderType).
                    ToList();
            }
            return
                allFolders.Where(
                    item =>
                    item.FolderType == CartFolderType.NormalFolderType ||
                    item.FolderType == CartFolderType.DefaultFolderType ||
                    item.FolderType == CartFolderType.SharedReceivedFolderType ||
                    item.FolderType == CartFolderType.ReceivedFolderType ||
                    item.FolderType == CartFolderType.RootFolderType).
                    ToList();

        }

        public ICollection<CartFolder> GetUserDefinedSharedCartFolders(ICollection<CartFolder> allFolders)
        {
            if (allFolders == null)
            {
                return null;
            }
            return
                allFolders.Where(
                    item =>
                    item.FolderType == CartFolderType.SharedReceivedFolderType).
                    ToList();
        }

        public ICollection<CartFolder> GetUserDefinedReceivedCartFolders(ICollection<CartFolder> allFolders)
        {
            if (allFolders == null)
            {
                return null;
            }

            // user-defined folders
            var results = allFolders.Where(
                    item =>
                    item.FolderType == CartFolderType.RootFolderType ||
                    item.FolderType == CartFolderType.DefaultFolderType ||
                    item.FolderType == CartFolderType.NormalFolderType
                    ).ToList();


            // received folders
            results.AddRange(allFolders.Where(item => item.FolderType == CartFolderType.ReceivedFolderType).ToList());

            // BT First Look folder. Expect no sub folder.
            var btFirstLookFolder = allFolders.FirstOrDefault(item => item.FolderType == CartFolderType.BtcartFolderType
                                                                    && item.TotalCarts > 0);
            if (btFirstLookFolder != null)
                results.Add(btFirstLookFolder);

            // ESP folder
            results.AddRange(allFolders.Where(item => item.FolderType == CartFolderType.ESPFolderType).ToList());

            return results;
        }

        /// <summary>
        /// Gets the last sequence number.
        /// </summary>
        /// <param name="parentId">The parent id.</param>
        /// <returns></returns>
        public int GetLastSequenceNumber(string parentId)
        {
            return GetLastSequenceNumber(parentId, SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the folder by id.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <returns></returns>
        public CartFolder GetCartFolderById(string folderId)
        {
            return string.IsNullOrEmpty(folderId) ? null : GetCartFolderById(folderId, SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the ordered basket folder.
        /// </summary>
        /// <returns></returns>
        public CartFolder GetOrderedFolder()
        {
            return GetOrderedFolder(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the archived basket folder.
        /// </summary>
        /// <returns></returns>
        public CartFolder GetArchivedFolder()
        {
            var result = VelocityCacheManager.Read(OrdersConstants.ManageCartsArchivedCartFolderCacheKey) as CartFolder;
            if (result == null)
            {
                result = GetArchivedFolder(SiteContext.Current.UserId);
                VelocityCacheManager.Write(OrdersConstants.ManageCartsArchivedCartFolderCacheKey, result, VelocityCacheLevel.Session);
            }
            return result;
        }

        /// <summary>
        /// Gets the bt basket folder.
        /// </summary>
        /// <returns></returns>
        public CartFolder GetBtCartFolder()
        {
            return GetBtCartFolder(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the deleted basket folder.
        /// </summary>
        /// <returns></returns>
        public CartFolder GetDeletedFolder()
        {
            return GetDeletedFolder(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Gets the normal basket folders by parent folder id.
        /// </summary>
        /// <param name="parentId">The parent id.</param>
        /// <returns></returns>
        public ICollection<CartFolder> GetNormalBasketFoldersByParentFolderId(string parentId, bool includedShared = false)
        {
            return GetNormalBasketFoldersByParentFolderId(parentId, SiteContext.Current.UserId, includedShared);
        }

        #endregion

        #region Get Custom User's BasketFolders

        /// <summary>
        /// Gets the folders.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public ICollection<CartFolder> GetFolderListByUserId(string userId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);

            if (cartManager == null) return null;

            return cartManager.GetCartFolders();
        }

        /// <summary>
        /// Gets the folders by parent folder id.
        /// </summary>
        /// <param name="parentId">The parent id.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public ICollection<CartFolder> GetFoldersByParentFolderId(string parentId, string userId)
        {
            CartFolders cartFolders = CartContext.Current.GetCartManagerForUser(userId).GetCartFolders();
            if (cartFolders != null)
            {
                return
                    cartFolders.Where(
                        cartFolder =>
                        string.Compare(cartFolder.ParentFolderId, parentId, StringComparison.OrdinalIgnoreCase) == 0).
                        ToList();
            }
            return null;
        }

        /// <summary>
        /// Gets the normal basket folders by parent folder id.
        /// </summary>
        /// <param name="parentId">The parent id.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="includedShared"></param>
        /// <returns></returns>
        public ICollection<CartFolder> GetNormalBasketFoldersByParentFolderId(string parentId, string userId, bool includedShared = false)
        {
            if (string.IsNullOrEmpty(userId)) return new Collection<CartFolder>();
            if (!includedShared)
            {
                return
                GetFoldersByParentFolderId(parentId, userId).Where(
                    item =>
                    item.FolderType == CartFolderType.NormalFolderType ||
                    item.FolderType == CartFolderType.DefaultFolderType ||
                    item.FolderType == CartFolderType.RootFolderType).
                    ToList();
            }
            return
                GetFoldersByParentFolderId(parentId, userId).Where(
                    item =>
                    item.FolderType == CartFolderType.NormalFolderType ||
                    item.FolderType == CartFolderType.DefaultFolderType ||
                    item.FolderType == CartFolderType.SharedReceivedFolderType ||
                    item.FolderType == CartFolderType.ReceivedFolderType ||
                    item.FolderType == CartFolderType.RootFolderType).
                    ToList();
        }

        /// <summary>
        /// Gets the last sequence number.
        /// </summary>
        /// <param name="parentId">The parent id.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public int GetLastSequenceNumber(string parentId, string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new NextGenApplicationException(NextGenApplicationException.ExceptionOrderNullUser);
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            return (int)cartManager.GetUserFolderSequence(parentId, (int)CartFolderPositionType.MaxSequence);
        }

        /// <summary>
        /// Gets the type of the folder by.
        /// </summary>
        /// <param name="folderType">Type of the folder.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public ICollection<CartFolder> GetFoldersByType(CartFolderType folderType, string userId)
        {
            if (string.IsNullOrEmpty(userId)) return null;

            CartFolders cartFolders = CartContext.Current.GetCartManagerForUser(userId).GetCartFolders();
            if (cartFolders != null)
            {
                return cartFolders.Where(cartFolder => cartFolder != null && cartFolder.FolderType == folderType).ToList();
            }
            return null;
        }

        /// <summary>
        /// Gets the folder by id.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        private CartFolder GetCartFolderById(string folderId, string userId)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
            if (cartManager != null && !string.IsNullOrEmpty(folderId))
            {
                return cartManager.GetCartFolderById(folderId);
            }
            return null;
        }

        /// <summary>
        /// Gets the special basket folder.
        /// </summary>
        /// <param name="folderType">Type of the folder.</param>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        private CartFolder GetSpecialBasketFolder(CartFolderType folderType, string userId)
        {
            //if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(folderType)) return null;
            CartFolder result = GetFoldersByType(folderType, userId).FirstOrDefault();

            return (result != null && result.FolderType != CartFolderType.RootFolderType
                    && result.FolderType != CartFolderType.NormalFolderType && result.FolderType != CartFolderType.DefaultFolderType)
                       ? result
                       : null;
        }

        /// <summary>
        /// Gets the ordered basket folder.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public CartFolder GetOrderedFolder(string userId)
        {
            return GetSpecialBasketFolder(CartFolderType.OrderedFolderType, userId);
        }

        /// <summary>
        /// Gets the archived basket folder.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public CartFolder GetArchivedFolder(string userId)
        {
            return GetSpecialBasketFolder(CartFolderType.ArchivedFolderType, userId);
        }

        /// <summary>
        /// Gets the bt basket folder.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public CartFolder GetBtCartFolder(string userId)
        {
            return GetSpecialBasketFolder(CartFolderType.BtcartFolderType, userId);
        }

        /// <summary>
        /// Gets the deleted basket folder.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public CartFolder GetDeletedFolder(string userId)
        {
            return GetSpecialBasketFolder(CartFolderType.DeletedFolderType, userId);
        }

        /// <summary>
        /// Gets the cart folder list by parent folder id.
        /// </summary>
        /// <param name="parentFolderId">The parent folder id.</param>
        /// <returns></returns>
        public ICollection<CartFolder> GetCartFolderListByParentFolderId(string parentFolderId, bool includedShared = false)
        {
            return GetNormalBasketFoldersByParentFolderId(parentFolderId, includedShared);
        }

        /// <summary>
        /// Gets the cart folder list by parent folder id.
        /// </summary>
        /// <param name="parentFolderId">The parent folder id.</param>
        /// <param name="allFolders">All folders.</param>
        /// <returns></returns>
        public ICollection<CartFolder> GetCartFolderListByParentFolderId(string parentFolderId,
                                                                         ICollection<CartFolder> allFolders)
        {
            return GetNormalBasketFoldersByParentFolderId(parentFolderId);
        }

        #endregion

        #endregion

        #region Initialize

        /// <summary>
        /// Initializes the basket folders.
        /// </summary>
        /// <param name="userId">The user id.</param>
        public void InitializeBasketFolders(string userId)
        {
            if (string.IsNullOrEmpty(userId)) return;
            try
            {
                var cartManager = CartContext.Current.GetCartManagerForUser(userId);
                var userFolder = cartManager.GetCartFolders();

                if (userFolder == null || userFolder.Count == 0)
                {
                    InitSpecialBasketFolders(CartFolder.OrderedFolderName, CartFolderType.OrderedFolderType, 0, userId);
                    InitSpecialBasketFolders(CartFolder.BtcartFolderName, CartFolderType.BtcartFolderType, 2, userId);
                    InitSpecialBasketFolders(CartFolder.ArchivedFolderName, CartFolderType.ArchivedFolderType, 3, userId);
                    InitSpecialBasketFolders(CartFolder.DeletedFolderName, CartFolderType.DeletedFolderType, 4, userId);
                    InitSpecialBasketFolders(CartFolder.DefaultFolderName, CartFolderType.DefaultFolderType, 0, userId);
                    InitSpecialBasketFolders(CartFolder.SharedReceivedFolderName, CartFolderType.SharedReceivedFolderType, 1, userId);
                    InitSpecialBasketFolders(CartFolder.ReceivedFolderName, CartFolderType.ReceivedFolderType, 1, userId);
                }
                else if (userFolder.Count == 1 && userFolder.First().FolderType == CartFolderType.SharedReceivedFolderType)
                {//User has only one folder called SharedReceivedFolder which is created when another user sharing a cart to him
                    InitSpecialBasketFolders(CartFolder.OrderedFolderName, CartFolderType.OrderedFolderType, 0, userId);
                    InitSpecialBasketFolders(CartFolder.BtcartFolderName, CartFolderType.BtcartFolderType, 2, userId);
                    InitSpecialBasketFolders(CartFolder.ArchivedFolderName, CartFolderType.ArchivedFolderType, 3, userId);
                    InitSpecialBasketFolders(CartFolder.DeletedFolderName, CartFolderType.DeletedFolderType, 4, userId);
                    InitSpecialBasketFolders(CartFolder.DefaultFolderName, CartFolderType.DefaultFolderType, 0, userId);
                }
                else
                {
                    var isExistNormalFolder = false;
                    foreach (var cartFolder in userFolder)
                    {
                        if (cartFolder.FolderType == CartFolderType.DefaultFolderType)
                        {
                            isExistNormalFolder = true;
                            if (GetPrimaryCart(userId) == null)
                            {
                                CreatePrimaryBasket(CreateBasketNameForUser(userId), cartFolder.CartFolderId, userId);
                            }
                            break;
                        }
                    }

                    if (!isExistNormalFolder)
                    {
                        InitSpecialBasketFolders(CartFolder.DefaultFolderName, CartFolderType.DefaultFolderType, 0, userId);
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.RaiseException(ex, ExceptionCategory.Order);
            }
        }

        /// <summary>
        /// Initializes system folders for new user.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool InitializeSystemFoldersForNewUser(string userId)
        {
            try
            {
                var cartManager = CartContext.Current.GetCartManagerForUser(userId);

                var createdFolders = cartManager.CreateSystemCartFolders();

                var defaultFolder = createdFolders.FirstOrDefault(r => r.Value == CartFolderType.DefaultFolderType);
                if (!string.IsNullOrEmpty(defaultFolder.Key))
                {
                    // create default primary basket
                    CreatePrimaryBasket(CreateBasketNameForUser(userId), defaultFolder.Key, userId);
                }

                return true;
            }
            catch (CartManagerException ex)
            {
                if (!ex.isBusinessError)
                    Logger.RaiseException(ex, ExceptionCategory.Order);
            }
            catch (Exception ex)
            {
                Logger.RaiseException(ex, ExceptionCategory.Order);
            }

            return false;
        }

        /// <summary>
        /// Inits the special basket folders.
        /// </summary>
        /// <param name="folderName">Name of the folder.</param>
        /// <param name="folderType">Type of the folder.</param>
        /// <param name="sequence">The sequence.</param>
        /// <param name="userId">The user id.</param>
        private void InitSpecialBasketFolders(string folderName, CartFolderType folderType, int sequence,
                                              string userId)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            var newCartFolder = cartManager.CreateCartFolder(folderName, null, folderType, sequence);

            if (folderType == CartFolderType.DefaultFolderType && GetPrimaryCart(userId) == null)
            {
                CreatePrimaryBasket(CreateBasketNameForUser(userId), newCartFolder.CartFolderId, userId);
            }
        }

        #endregion

        #region Update BasketFolder

        /// <summary>
        /// Updates the sequence number for basket folder.
        /// </summary>
        /// <param name="sequence">The sequence.</param>
        /// <param name="folderId">The folder id.</param>
        /// <returns></returns>
        public bool UpdateSequenceNumberForBasketFolder(float sequence, string folderId)
        {
            if (string.IsNullOrEmpty(folderId))
            {
                //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
                return false;
            }
            //    throw new NextGenApplicationException(NextGenApplicationException.ExceptionOrderNullFolderId);

            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            CartFolder cartFolder = cartManager.GetCartFolderById(folderId);
            if (cartFolder != null)
            {
                if (cartFolder.FolderType == CartFolderType.ESPFolderType || cartFolder.FolderType == CartFolderType.SharedReceivedFolderType
                    || cartFolder.FolderType == CartFolderType.BtcartFolderType)
                    return false;
                cartFolder.UpdateSequence(sequence);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Updates the parent folder for basket folder.
        /// </summary>
        /// <param name="parentFolderId">The parent folder id.</param>
        /// <param name="folderId">The folder id.</param>
        /// <returns></returns>
        public bool UpdateParentFolderForBasketFolder(string parentFolderId, string folderId)
        {
            if (string.IsNullOrEmpty(folderId))
            {
                //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
                return false;
            }
            //    throw new NextGenApplicationException(NextGenApplicationException.ExceptionOrderNullFolderId);

            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            CartFolder cartFolder = cartManager.GetCartFolderById(folderId);

            if (cartFolder != null)
            {
                //TFS16808 Prevent to move sub Shared/Received folder to root level.
                if (cartFolder.FolderType == CartFolderType.SharedReceivedFolderType && string.IsNullOrEmpty(parentFolderId))
                    return false;

                cartFolder.MoveTo(parentFolderId);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Updates the name of the basket folder.
        /// </summary>
        /// <param name="folderName">Name of the folder.</param>
        /// <param name="folderId">The folder id.</param>
        /// <returns></returns>
        public bool UpdateBasketFolderName(string folderName, string folderId)
        {
            if (string.IsNullOrEmpty(folderId))
            {
                //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
                return false;
            }
            //    throw new NextGenApplicationException(NextGenApplicationException.ExceptionOrderNullFolderId);

            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            CartFolder cartFolder = cartManager.GetCartFolderById(folderId);
            if (cartFolder != null)
            {
                cartFolder.Rename(folderName);
                return true;
            }
            return false;
        }

        #endregion

        #region Create BasketFolder

        /// <summary>
        /// Creates the basket folder.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <param name="folderId">The folder id.</param>
        /// <param name="folderName">Name of the folder.</param>
        /// <param name="parentId">The parent id.</param>
        /// <param name="folderType">Type of the folder.</param>
        /// <param name="sequence">The sequence.</param>
        /// <param name="desc">The desc.</param>
        /// <returns></returns>
        public bool CreateBasketFolder(string userId, string folderName, string parentId, CartFolderType folderType,
                                       int sequence, string desc, out string folderId)
        {
            folderId = null;
            if (string.IsNullOrEmpty(folderName))
            {
                return false;
            }

            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            CartFolder cartFolder = cartManager.CreateCartFolder(folderName, parentId, folderType, sequence);
            if (cartFolder != null)
            {
                folderId = cartFolder.CartFolderId;
                return true;
            }
            return false;
        }

        #endregion

        #region Delete BasketFolder

        /// <summary>
        /// Deletes the basket folder.
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <returns></returns>
        public bool DeleteBasketFolder(string folderId)
        {
            if (String.IsNullOrEmpty(folderId)) return false;

            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            CartFolder cartFolder = cartManager.GetCartFolderById(folderId);
            if (cartFolder != null)
            {
                cartFolder.Delete();
                return true;
            }
            return false;
        }

        #endregion

        #region BTNG Extensions

        public string CreateBasketNameForUser(string userId)
        {
            ISiteContext siteContext = SiteContext.Current;

            if (string.IsNullOrEmpty(userId)) return null;
            ProfileController profileController = ProfileController.Current;
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.UserName);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);
            UserProfile user = profileController.GetUserById(userId);

            string defaultCartName = user != null ? user.UserName : siteContext.UserName;

            defaultCartName = defaultCartName.Split('@')[0]; // x@yahoo.com -> x
            if (string.IsNullOrEmpty(defaultCartName)) defaultCartName = "1"; // "@gmail.com" -> "" -> 1

            //create unique basket name
            var cartMgr = CartContext.Current.GetCartManagerForUser(userId);
            defaultCartName = cartMgr.GenerateNewBasketNameForUser(defaultCartName);
            return defaultCartName;
        }

        #endregion

        #region Primary Folder

        /// <summary>
        /// Finds the primary folder.
        /// </summary>
        /// <returns></returns>
        public CartFolder FindPrimaryFolder()
        {
            return FindPrimaryFolder(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Finds the primary folder.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public CartFolder FindPrimaryFolder(string userId)
        {
            if (string.IsNullOrEmpty(userId)) return null;
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            Cart cart = cartManager.GetPrimaryCart();
            //Bug 7891:ELMAH: BTNextGen.CartFramework.CartManagerException
            if (cart != null && !string.IsNullOrEmpty(cart.CartFolderID))
            {
                return cartManager.GetCartFolderById(cart.CartFolderID);
            }
            return null;
        }

        /// <summary>
        /// Finds the root folder contains primary cart.
        /// </summary>
        /// <returns></returns>
        public CartFolder FindRootFolderContainsPrimaryCart()
        {
            return FindRootFolderContainsPrimaryCart(SiteContext.Current.UserId);
        }

        /// <summary>
        /// Finds the root folder contains primary cart.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns></returns>
        public CartFolder FindRootFolderContainsPrimaryCart(string userId)
        {
            //return string.IsNullOrEmpty(userId) ? null : OrdersDAO.Instance.FindRootFolderContainsPrimaryCart(userId);            
            CartFolder primaryFolder = FindPrimaryFolder(userId);
            if (primaryFolder == null) return null;
            string parentId = primaryFolder.ParentFolderId;
            if (string.IsNullOrEmpty(parentId))
                return primaryFolder;
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            while (!string.IsNullOrEmpty(parentId))
            {
                CartFolder folder = cartManager.GetCartFolderById(parentId);
                if (folder != null)
                {
                    parentId = folder.ParentFolderId;
                    if (string.IsNullOrEmpty(parentId))
                    {
                        return folder;
                    }
                }
                else
                {
                    break;
                }
            }
            return null;
        }

        /// <summary>
        /// Determines whether [is folder and sub folders contains primary cart] [the specified folder id].
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <returns>
        /// 	<c>true</c> if [is folder and sub folders contains primary cart] [the specified folder id]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsFolderAndSubFoldersContainsPrimaryCart(string folderId)
        {
            return IsFolderAndSubFoldersContainsPrimaryCart(folderId, SiteContext.Current.UserId);
        }

        /// <summary>
        /// Determines whether [is folder and sub folders contains primary cart] [the specified folder id].
        /// </summary>
        /// <param name="folderId">The folder id.</param>
        /// <param name="userId">The user id.</param>
        /// <returns>
        /// 	<c>true</c> if [is folder and sub folders contains primary cart] [the specified folder id]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsFolderAndSubFoldersContainsPrimaryCart(string folderId, string userId)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(folderId)) return false;
            return OrdersDAO.Instance.IsFolderAndSubFoldersContainsPrimaryCart(userId, folderId);
        }

        /// <summary>
        /// Move primary folder to top
        /// </summary>
        /// <param name="primaryFolder"></param>
        public void MovePrimaryFolderUp(CartFolder primaryFolder)
        {
            if (primaryFolder != null)
            {
                var primaryFolderId = primaryFolder.CartFolderId;
                var oldSequenceNumber = primaryFolder.Sequence;
                if (UpdateSequenceNumberForBasketFolder(0, primaryFolderId))
                {
                    //Just get the Normal Folder List
                    var rootFolders = GetNormalBasketFoldersByParentFolderId(null);
                    if (rootFolders != null && rootFolders.Count > 0)
                    {
                        var foldersNeedUpdateSequenceNumber = rootFolders.Where(folder => folder.Sequence <= oldSequenceNumber && folder.CartFolderId != primaryFolderId);
                        foreach (var folder in foldersNeedUpdateSequenceNumber)
                        {
                            UpdateSequenceNumberForBasketFolder(folder.Sequence + 1, folder.CartFolderId);
                        }
                    }
                }
            }
        }

        #endregion

        #endregion

        #endregion

        #region Extension Methods

        public List<SiteTermObject> GetProductDuplicateIndicator(List<string> listId, List<string> listBteKeys,
                                                                 string basketId, bool isRequiredCheckDupCarts = true, bool isRequiredCheckDupOrder = true)
        {
            var list = new List<SiteTermObject>();
            //
            string itemsCheckOrder, itemsCheckCart;
            Dictionary<string, bool> itemsCheckHoldings;
            var holdingsType = string.Empty;
            string holdingsFlag;
            bool runHoldingsDupCheck = false;
            //
            bool sucess = CheckForDuplicates(SiteContext.Current.UserId, listId, listBteKeys, out itemsCheckOrder,
                                             out itemsCheckCart, basketId, out itemsCheckHoldings, out holdingsFlag,
                                             isRequiredCheckDupCarts, isRequiredCheckDupOrder);
            if (!sucess)
                return list;
            itemsCheckOrder = itemsCheckOrder.TrimEnd(';');
            itemsCheckCart = itemsCheckCart.TrimEnd(';');
            if (!isRequiredCheckDupCarts)
            {
                itemsCheckCart = itemsCheckOrder.Replace("O", "N").Replace("o", "N");
            }
            if (!isRequiredCheckDupOrder)
            {
                itemsCheckOrder = itemsCheckCart.Replace("C", "N").Replace("c", "N");
            }
            //
            string[] arrOrder = itemsCheckOrder.Split(';');
            string[] arrCart = itemsCheckCart.Split(';');
            //
            if (arrOrder.Length != arrCart.Length || arrOrder.Length != listId.Count || arrCart.Length != listId.Count)
                return list;

            if (holdingsFlag.ToLower() == "user" || holdingsFlag.ToLower() == "org")
            {
                runHoldingsDupCheck = true;
                holdingsType = holdingsFlag.ToLower() == "user"
                                    ? "My Holdings Duplicate"
                                    : "Organization Holdings Duplicate";
            }

            if (runHoldingsDupCheck)
            {
                if (itemsCheckHoldings != null && itemsCheckHoldings.Count > 0)
                {
                    //list.AddRange(
                    //arrOrder.Select(
                    //    (t, i) => new SiteTermObject(listId[i], CombineProductDuplicated(arrCart[i], t, itemsCheckHoldings[i], holdingsFlag ), basketId)));

                    for (int i = 0; i < arrOrder.Length; i++)
                    {
                        var btKey = listId[i];
                        var combinedProduct = CombineProductDuplicated(arrCart[i], arrOrder[i], itemsCheckHoldings[btKey], holdingsFlag);

                        var item = new SiteTermObject(btKey, combinedProduct, basketId);
                        list.Add(item);
                    }
                }
            }
            else
            {
                list.AddRange(
                arrOrder.Select(
                    (t, i) => new SiteTermObject(listId[i], CombineProductDuplicated(arrCart[i], t, false, holdingsFlag), basketId)));
            }

            List<SiteTermObject> list4Session = list.Where(o => !String.IsNullOrEmpty(o.Value)).ToList();

            // assign to Session
            SiteContext.Current.Session[SessionVariableName.DupsDictionary] = list4Session;

            //
            return list;
        }



        public bool CheckInPrimary(string _btKey)
        {
            if (PrimCartBtkeyLineItemId == null || PrimCartBtkeyLineItemId.Count <= 0)
            {
                var primaryCart = CartMapper.CartMapping.Instance.GetPrimaryCartObject();
                if (primaryCart == null) return false;
                PrimCartBtkeyLineItemId = primaryCart.GetLineItemBtKeys();
            }

            var lineItemId = string.Empty;
            if (PrimCartBtkeyLineItemId != null &&
                (!string.IsNullOrEmpty(_btKey) && PrimCartBtkeyLineItemId.TryGetValue(_btKey, out lineItemId)))
            {
                return true;

            }
            return false;
        }

        public ServiceContracts.CartsDupCheckResponse GetCartsAndHoldingDuplicates(string userId, string basketId, List<string> listBtKeys, List<string> listBteKeys, bool isRequiredCheckDupCarts = true, bool isRequiredCheckDupOrder = true)
        {
            var result = new ServiceContracts.CartsDupCheckResponse();
            result.DuplicateItems = new List<ServiceContracts.CartDuplicateItem>();

            //get dupCheckCartType, downloadedCheckType
            var orgId = SiteContext.Current.OrganizationId;

            var userProfile = CSObjectProxy.GetUserProfileForSearchResult();

            if (userProfile == null) return null;

            string dupCheckOrderType;
            string dupCheckCartType;

            if (!isRequiredCheckDupCarts)
                dupCheckCartType = "None";
            else
                dupCheckCartType = userProfile.DefaultDuplicateCarts;

            if (!isRequiredCheckDupOrder)
                dupCheckOrderType = "None";
            else
                dupCheckOrderType = userProfile.DefaultDuplicateOrders;

            string downloadedCheckType = SiteContext.Current.DefaultDownloadedCarts;

            //get list dup Item
            const string delimited = ";";
            string itemBteKeys = "";
            string itemListKeys = listBtKeys.Aggregate("", (current, btKey) => current + (btKey + delimited));
            itemListKeys = itemListKeys.TrimEnd(';');

            if (listBteKeys != null)
            {
                foreach (string bteKey in listBteKeys)
                {
                    itemBteKeys += (bteKey ?? "NA") + delimited;
                }

                // remove last delimited char
                if (itemBteKeys.EndsWith(delimited))
                    itemBteKeys = itemBteKeys.Remove(itemBteKeys.Length - 1);
            }

            if (string.Compare(dupCheckCartType, DefaultDuplicateCarts.MyCarts.ToString(), true) == 0)
                orgId = null;

            // Cart Duplicates from database. Result string sample: 'C;C;C;C;N;C;C;C;N;'
            var itemsCheckCart = CartDAO.Instance.CheckForCartDuplicates(orgId, userId, basketId, itemListKeys, itemBteKeys, dupCheckCartType, downloadedCheckType);

            // split result string and add to results
            if (!string.IsNullOrEmpty(itemsCheckCart))
            {
                itemsCheckCart = itemsCheckCart.TrimEnd(';');
                string[] arrCart = itemsCheckCart.Split(';');

                if (arrCart.Length == listBtKeys.Count)
                {
                    for (int i = 0; i < listBtKeys.Count; i++)
                    {
                        var duplicateItem = new ServiceContracts.CartDuplicateItem()
                        {
                            BTKey = listBtKeys[i],
                            IsDuplicated = (arrCart[i].ToLower() == "c")
                        };

                        // add DupC item
                        result.DuplicateItems.Add(duplicateItem);
                    }
                }
            }

            //Batch Entry - validate ISBN/BTKey: No need to check Holding Duplicates. 

            return result;
        }

        public bool CheckForDuplicates(string userId, List<string> listBtKeys, List<string> listBteKeys,
                                       out string itemsCheckOrder, out string itemsCheckCart, string basketId,
            out Dictionary<string, bool> itemsCheckHoldings, out String holdingsFlag,
            bool isRequiredCheckDupCarts = true, bool isRequiredCheckDupOrder = true)
        {
            itemsCheckOrder = string.Empty;
            itemsCheckCart = string.Empty;
            itemsCheckHoldings = null;
            holdingsFlag = "None";

            if (listBtKeys == null || listBtKeys.Count == 0)
                return false;

            string itemBteKeys = "";
            string itemListKeys = listBtKeys.Aggregate("", (current, btKey) => current + (btKey + ";"));
            itemListKeys = itemListKeys.TrimEnd(';');
            const string delimited = ";";

            var userProfile = CSObjectProxy.GetUserProfileForSearchResult();

            if (userProfile == null) return false;

            var organizationId = userProfile.Organization.Target.Id;

            holdingsFlag = userProfile.HoldingsFlag ?? "None";
            string defaultDuplicateOrders;
            string defaultDuplicateCarts;

            if (!isRequiredCheckDupCarts)
                defaultDuplicateCarts = "None";
            else
                defaultDuplicateCarts = userProfile.DefaultDuplicateCarts;
            if (!isRequiredCheckDupOrder)
                defaultDuplicateOrders = "None";
            else
                defaultDuplicateOrders = userProfile.DefaultDuplicateOrders;

            string defaultDownloadedCarts = SiteContext.Current.DefaultDownloadedCarts;

            if (listBteKeys != null)
            {
                foreach (string bteKey in listBteKeys)
                {
                    itemBteKeys += (bteKey ?? "NA") + delimited;
                }

                // remove last delimited char
                if (itemBteKeys.EndsWith(delimited))
                    itemBteKeys = itemBteKeys.Remove(itemBteKeys.Length - 1);
            }

            return CartContext.Current.GetCartManagerForUser(userId).CheckForDuplicates(itemListKeys, itemBteKeys,
                                                                                        defaultDuplicateCarts,
                                                                                        defaultDuplicateOrders,
                                                                                        organizationId, userId,
                                                                                        out itemsCheckOrder,
                                                                                        out itemsCheckCart, basketId,
                                                                                        out itemsCheckHoldings, holdingsFlag, defaultDownloadedCarts);
        }

        private void CreateAccountAndAccount8IdList(CommerceRelationship commerceRelationship, string delimited,
                                                    ref bool isContainTolasAccount, ref string accountList,
                                                    ref string account8List)
        {
            var account = (Account)commerceRelationship.Target;

            //Huy modified: account.Id => account.AccountNumber
            accountList = accountList + account.AccountNumber + delimited;

            bool isTolasAccount = account.IsTOLAS.HasValue && account.IsTOLAS.Value;
            isContainTolasAccount = isContainTolasAccount || isTolasAccount;

            account8List += account.Account8Id == null ? String.Empty + delimited : account.Account8Id + delimited;
        }

        public string CombineProductDuplicated(string cart, string order, bool isInHoldingsQueue, string holdingsFlag)
        {
            string result = "";
            if (cart.ToLower() == "c")
                result += ProductSupportedHtmlTag.DupC;
            //this is not required for release 1
            if (order.ToLower() == "o")
                result += ProductSupportedHtmlTag.DupO;

            if (isInHoldingsQueue)
            {
                if (holdingsFlag.ToLower() == "user")
                    result += ProductSupportedHtmlTag.DupHUser;
                else if (holdingsFlag.ToLower() == "org")
                    result += ProductSupportedHtmlTag.DupHOrg;
            }

            if (!String.IsNullOrEmpty(result) && isInHoldingsQueue)
                result = ProductSupportedHtmlTag.DupBeginImage + result + ProductSupportedHtmlTag.DupEndImage +
                         ProductSupportedHtmlTag.DivCb;
            else if (!String.IsNullOrEmpty(result))
                result = ProductSupportedHtmlTag.DupBeginImage + result + ProductSupportedHtmlTag.DupEndImage +
                         ProductSupportedHtmlTag.DivCb;
            //
            return result;
        }

        public string CombineProductDuplicated(string cart, string order, bool isInHoldingsQueue)
        {
            string result = "";
            if (cart.ToLower() == "c")
                result += ProductSupportedHtmlTag.DupC;
            //this is not required for release 1
            if (order.ToLower() == "o")
                result += ProductSupportedHtmlTag.DupO;

            if (isInHoldingsQueue)
                result += ProductSupportedHtmlTag.DupH;

            if (!String.IsNullOrEmpty(result))
                result = ProductSupportedHtmlTag.DupBeginImage + result + ProductSupportedHtmlTag.DupEndImage +
                         ProductSupportedHtmlTag.DivCb;
            //
            return result;
        }

        public DuplicateCartTitle GetDuplicateCartReferences(string userId, string itemKey, string basketId)
        {
            ProfileController profileController = ProfileController.Current;
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultDuplicateCarts);

            var userProfile = profileController.GetUserById(userId);
            //
            if (userProfile == null)
                return null;
            //
            string organizationId = userProfile.OrganizationId;
            string defaultDuplicateCarts = userProfile.DefaultDuplicateCarts;

            if (defaultDuplicateCarts == DefaultDuplicateCarts.MyCarts.ToString())
            {
                organizationId = string.Empty;
            }

            var downloadCheckType = SiteContext.Current.DefaultDownloadedCarts;
            var duplicateCartTitle = CartContext.Current.GetCartManagerForUser(userId).GetDuplicateCartReferences(basketId, itemKey, organizationId, userId,
                downloadCheckType);

            return duplicateCartTitle;
        }

        public DuplicateCartTitle GetDuplicateOrderReferences(string userId, string btKey, string currentBasketId)
        {
            const string delimited = ";";
            //
            var profileController = ProfileController.Current;
            profileController.UserProfileRelated.AccountViewOrderNeeded = true;
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultDuplicateOrders);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultDuplicateCarts);

            var userProfile = profileController.GetUserById(userId);
            //
            if (userProfile == null)
                return null;
            //
            string organizationId = userProfile.OrganizationId;
            string defaultDuplicateOrders = userProfile.DefaultDuplicateOrders;
            string defaultDuplicateCarts = userProfile.DefaultDuplicateCarts;
            var downloadCheckType = SiteContext.Current.DefaultDownloadedCarts;
            
            var duplicateCartTitle =
                CartContext.Current.GetCartManagerForUser(userId).GetDuplicateOrderReferences(currentBasketId, btKey,
                                                                                           organizationId, downloadCheckType,
                                                                                           defaultDuplicateCarts, defaultDuplicateOrders);
            return duplicateCartTitle;
        }

        public List<string> GetBasketIdListFromName(IEnumerable<string> basketNames)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            return (from basketName in basketNames
                    select cartManager.GetCartByName(basketName)
                        into cart
                        where cart != null
                        select cart.CartId).ToList();
        }

        public List<LineItem> DownloadBasket(string userId, string basketId, bool isChangeStatus)
        {
            var cart = CartContext.Current.GetCartManagerForUser(userId).GetCartById(basketId);

            string orderedDownloadedUserId;
            if (!isChangeStatus)
            {
                orderedDownloadedUserId = string.Empty;
            }
            else
            {
                orderedDownloadedUserId = SiteContext.Current.IsProxyActive ? SiteContext.Current.BtUserId : SiteContext.Current.UserId;
            }

            return cart.DowndloadExport(isChangeStatus, orderedDownloadedUserId);
        }

        public void ChangeBasketToDownloadStatus(string userId, string basketId, string orderedDownloadedUserId)
        {
            CartContext.Current.GetCartManagerForUser(userId).SetCartToDownloaded(basketId, orderedDownloadedUserId);
        }
        #endregion

        public string POLineNumber { get; set; }

        private void AddCartObjectToSessionCacheForOneRequest(Cart cart)
        {
            VelocityCacheManager.Write(SessionVariableName.CartDetailsCartCacheKey, cart,
                   VelocityCacheLevel.Session);
        }

        public int ApplyDuplicates(List<string> cartIDs, string userID, int thesholdLimit, out string newcartId, out string newcartname,
             out int numberOfItemApplied, string defaultDuplicateOrders, string defaultDuplicateCarts, string downloadCheckType, bool moveToNewCart)
        {
            newcartname = newcartId = string.Empty;
            numberOfItemApplied = 0;

            var userProfile = CSObjectProxy.GetUserProfileForSearchResult();
            if (userProfile == null) return -100;

            var organizationId = userProfile.Organization.Target.Id;
            
            return CartContext.Current.GetCartManagerForUser(userID).ApplyDuplicates(cartIDs, userID, thesholdLimit, out newcartId,
                                                             out newcartname, out numberOfItemApplied,
                                                             defaultDuplicateCarts, defaultDuplicateOrders, organizationId,
                                                             downloadCheckType, moveToNewCart);
        }

        public void SetCartAsActiveOrInActive(string cartId, string userId, bool isActive, int maxActiveCarts)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            if (cartManager != null)
            {
                cartManager.SetCartAsActiveOrInActive(cartId, isActive, maxActiveCarts);

                cartManager.SetCartChanged(cartId);
            }
        }
    }
}
