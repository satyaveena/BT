﻿using System.Collections.Generic;
using System.Linq;
using BTNextGen.CartFramework;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Constants;
using BT.TS360Constants;

namespace BTNextGen.CartMapper
{
    public static class CartExtension
    {
        public static Basket ToBasket(this Cart cart, string userId = "", bool flatStuff = false)
        {
            var basket = new Basket
                             {
                                 Id = cart.CartId,
                                 Name = cart.CartName,
                                 TotalBackOrderQuantity = cart.TotalBackOrderQuantity,
                                 TotalCancelQuantity = cart.TotalCancelQuantity,
                                 Total = cart.Total,
                                 CartTotalListPrice = cart.CartTotalListPrice,
                                 CartTotalNetPrice = cart.CartTotalNetPrice,
                                 CartTotal = cart.Total,
                                 OrganizationId = cart.OrgId,
                                 UserId = cart.CartOwnerId,
                                 CartUserSharedId = cart.CartUserSharedId,
                                 LastUpdated = cart.UpdatedDateTime,
                                 DateCreated = cart.CreatedDateTime,
                                 SpecialInstructions = cart.SpecialInstruction,
                                 BTNote = cart.Note,
                                 FolderId = cart.CartFolderID,
                                 FolderName = cart.CartFolderName,
                                 LineItemsCount = cart.LineItemCount,
                                 BTStatus = cart.BTStatus,
                                 BookAccountId = GetDefaulAccountId(cart.CartAccounts, (int)AccountType.Book),
                                 EntertainmentAccountId = GetDefaulAccountId(cart.CartAccounts, (int)AccountType.Entertainment),
                                 IsArchived = cart.IsArchived ? 1 : 0,
                                 ItemsCount = cart.TotalOrderQuantity,
                                 ShippingTotal = cart.ShippingTotal,
                                 CartOwner = cart.CartOwnerName,
                                 HasProfile = !flatStuff ? cart.HasProfile : cart.IsShared,
                                 IsShared = cart.IsShared,
                                 HasGridLine = cart.HasGridLine,
                                 IsPremium = cart.IsPremium,
                                 HasPermission = cart.HasPermission,
                                 OneClickMARCIndicator = cart.OneClickMARCIndicator,
                                 FTPErrorMessage = cart.FTPErrorMessage,
                                 HasOwner = cart.HasOwner,
                                 HasContribution = cart.HasContribution,
                                 HasReview = cart.HasReview,
                                 HasAcquisition = cart.HasAcquisition,
                                 CurrentWorkflowStage = cart.CurrentWorkflow,
                                 HasWorkflow = cart.HasWorkflow,
                                 HasReviewAcquisitionPermission = cart.HasReviewAcquisitionPermission,
                                 IsMixedProduct = cart.IsMixedProduct,
                                 ESPStateTypeId = cart.ESPStateTypeId,
                                 HasESPRanking = cart.HasESPRanking,
                                 ESPStateTypeLiteral = cart.ESPStateTypeLiteral,
                                 ContainsAMixOfGridNNonGrid = cart.ContainsAMixOfGridNNonGrid
                             };

            basket.IsPrimary = !flatStuff
                                   ? (string.IsNullOrEmpty(userId)
                                          ? cart.IsPrimaryCart ? 1 : 0
                                          : cart.IsPrimaryCartOfUser(userId) ? 1 : 0)
                                   : (cart.IsPrimary ? 1 : 0);
            return basket;
        }

        public static List<Basket> ToBaskets(this Carts carts, string userId = "", bool flatStuff = false)
        {
            return (from cart in carts
                    select cart.ToBasket(userId, flatStuff)).ToList();
        }

        private static string GetDefaulAccountId(List<CartAccount> cartAccounts, int accountType)
        {
            if (cartAccounts != null && cartAccounts.Count > 0)
            {
                foreach (var cartAccount in cartAccounts)
                {
                    if (cartAccount.AccountType == accountType)
                    {
                        return cartAccount.ERPAccountGUID;
                    }
                }
            }
            return string.Empty;
        }
    }
}
