﻿using System.Collections.Generic;
using System.Linq;
using BTNextGen.CartFramework;
using LineItem = BTNextGen.CartFramework.Order.LineItem;

namespace BTNextGen.CartMapper
{
    public static class CartBatchEntryManager
    {
        public static void AddLineItemsToCart(List<LineItem> lineItems, string cartId, out string PermissionViolationMessage, 
            out int totalAddingQtyForGridDistribution)
        {                                   
            var i = 0;
            const int batchSize = 2000;
            var count = batchSize;
            CartDAO.Instance.InitializeConnectionString();
            PermissionViolationMessage = null;
            totalAddingQtyForGridDistribution = 0;

            while (count == batchSize)
            {
                var items = lineItems.Skip(i).Take(batchSize);
                count = items.Count();
                if (count == 0) break;
                i += count;
                int tempAdding = 0;
                CartMapping.Instance.AddToCartName(cartId, items.ToList(), out PermissionViolationMessage, out tempAdding, false);
                totalAddingQtyForGridDistribution += tempAdding;
            }       
        }
    }
}
