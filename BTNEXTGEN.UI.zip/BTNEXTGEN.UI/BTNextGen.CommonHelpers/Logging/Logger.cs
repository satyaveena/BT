﻿using System;
using BTNextGen.CommonHelpers.Configuration;
using BTNextGen.CommonHelpers.Constants;
using BTNextGen.Elmah;

namespace BTNextGen.CommonHelpers.Logging
{
    /// <summary>
    /// Class used for logging exception information and function call traceability
    /// </summary>
    public static class Logger
    {
        private const string CategoryGrouped = ": ";

        public static void RaiseExceptionNoUls(Exception exception, ExceptionCategory exceptionCategory)
        {
            RaiseException(exception, exceptionCategory, false);
        }

        public static void RaiseException(Exception exception, ExceptionCategory exceptionCategory, bool writeToUls = true)
        {
            if (writeToUls)
            {
                UlsLoggingService.Log(exceptionCategory.ToString(), exception);
            }

            exception.Source = exceptionCategory + CategoryGrouped + exception.Source;
            ErrorSignal.FromCurrentContext().Raise(exception);
        }

        public static void RaiseException(string message, ExceptionCategory exceptionCategory, bool writeToUls = true)
        {
            var exception = new Exception(message);
            RaiseException(exception, exceptionCategory, writeToUls);
        }

        /// <summary>
        /// Write logging information from message and category
        /// </summary>
        /// <param name="category">Free text category</param>
        /// <param name="message">Free text message</param>
        /// <param name="writeToDb">Indicator of writing to DB</param>
        public static void Write(string category, string message, bool writeToDb = true)
        {
            UlsLoggingService.Log(category, message);

            if (writeToDb)
            {
                var exception = new Exception(message);
                exception.Source = category +
                                   (exception.Source == null ? string.Empty : (CategoryGrouped + exception.Source));
                ErrorSignal.FromCurrentContext().Raise(exception);
            }
        }

        /// <summary>
        /// Log a single exception object
        /// </summary>
        /// <param name="exception">Exception object</param>
        public static void LogException(Exception exception)
        {
            ErrorSignal.FromCurrentContext().Raise(exception);
        }

        /// <summary>
        /// Log function call for traceability
        /// </summary>
        /// <param name="category">Category Enumeration</param>
        /// <param name="message">ClassName:FunctionName:ParameterValue:UserID:TimeStamp</param>
        public static void DebugTraceLog(ExceptionCategory category, string message)
        {
            //TODO:READ DebugTrace global config from cache
            //if it is ‘on’, then perform logging
            var appSetting = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.DebugTrace);
            if (appSetting != null && !string.IsNullOrEmpty(appSetting.Value)
                && appSetting.Value.ToLower() == "on")
            {
                var exception = new Exception(message);
                exception.Source = category.ToString();

                ErrorSignal.FromCurrentContext().Raise(exception);
            }
            //endif
        }
    }
}
