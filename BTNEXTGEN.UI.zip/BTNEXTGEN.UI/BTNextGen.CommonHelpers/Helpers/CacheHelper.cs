﻿//-----------------------------------------------------------------------
// <copyright file="CacheHelper.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary></summary>
//-----------------------------------------------------------------------

using System;
using System.Web;
using System.Web.Caching;

namespace BTNextGen.CommonHelpers.Helpers
{
    /// <summary>
    /// Cache Helper class
    /// </summary>
    public static class CacheHelper
    {
        private const int DefaultCacheMinutes = 60;

        /// <summary>
        /// Gets the specified cache key.
        /// </summary>
        /// <param name="cacheKey">The cache key.</param>
        /// <returns>The cached Object</returns>
        public static object Get(string cacheKey)
        {            
            return HttpContext.Current.Cache.Get(cacheKey);
        }

        /// <summary>
        /// Writes the specified cache key.
        /// </summary>
        /// <param name="cacheKey">The cache key.</param>
        /// <param name="value">The object to cache.</param>
        public static void Write(string cacheKey, object value)
        {
            if (value != null)
            {
                DateTime absoluteExpiration = DateTime.Now.AddMinutes(DefaultCacheMinutes);
                Write(cacheKey, value, absoluteExpiration);
            }
        }

        /// <param name="cacheKey"> </param>
        /// <param name="value">The object to cache.</param>
        /// <param name="cacheMinutes"> </param>
        public static void Write(string cacheKey, object value, int cacheMinutes)
        {
            if (value != null)
            {
                DateTime absoluteExpiration = DateTime.Now.AddMinutes(cacheMinutes);
                Write(cacheKey, value, absoluteExpiration);
            }
        }

        private static void Write(string cacheKey, object value, DateTime absoluteExpiration)
        {
            HttpRuntime.Cache.Add(
                  cacheKey,
                  value,
                  null,
                  absoluteExpiration,
                  Cache.NoSlidingExpiration,
                  CacheItemPriority.Normal,
                  null);
        }

        /// <summary>
        /// Writes the specified cache key.
        /// </summary>
        /// <param name="cacheKey">The cache key.</param>
        /// <param name="value">The object to cache.</param>
        public static void Write(string cacheKey, object value, TimeSpan slidingExpiration)
        {
            HttpRuntime.Cache.Add(
                   cacheKey,
                   value,
                   null,
                   Cache.NoAbsoluteExpiration,
                   slidingExpiration,
                   CacheItemPriority.Normal,
                   null);
        }

        /// <summary>
        /// Writes the specified cache key.
        /// </summary>
        /// <param name="cacheKey">The cache key.</param>
        /// <param name="value">The object to cache.</param>
        /// <param name="dependency">The dependency.</param>
        public static void Write(string cacheKey, object value, CacheDependency dependency)
        {
            HttpRuntime.Cache.Add(
                   cacheKey,
                   value,
                   dependency,
                   Cache.NoAbsoluteExpiration,
                   Cache.NoSlidingExpiration,
                   CacheItemPriority.Normal,
                   null);
        }

        /// <summary>
        /// This is a special overloads to use when SP objects are related to this cache entry
        /// </summary>
        /// <param name="cacheKey">The cache key.</param>
        /// <param name="value">The object to cache.</param>
        /// <param name="itemId">The item id.</param>
        public static void Write(string cacheKey, object value, string itemId)
        {
            Write(cacheKey, value);

            //// Some SP events will be raised when these SP items are updated. They will only have the SP ID,
            //// so we need to track the correlation between ID and the cachekey used in web parts.
            Write(itemId, cacheKey);
        }

        /// <summary>
        /// Write cache not removable
        /// </summary>
        /// <param name="cacheKey"></param>
        /// <param name="value"></param>
        /// <param name="cacheNotRemovable"></param>
        public static void Write(string cacheKey, object value, bool cacheNotRemovable)
        {
            if (cacheNotRemovable)
            {
                HttpContext.Current.Cache.Add(
                    cacheKey,
                    value,
                    null,
                    System.Web.Caching.Cache.NoAbsoluteExpiration,
                    System.Web.Caching.Cache.NoSlidingExpiration,
                    CacheItemPriority.NotRemovable,
                    null);
            }
            else
            {
                Write(cacheKey, value);
            }
        }

        /// <summary>
        /// Remove
        /// </summary>
        /// <param name="cacheKey"></param>
        public static void Remove(string cacheKey)
        {
            HttpContext.Current.Cache.Remove(cacheKey);
        }
        
    }
}
