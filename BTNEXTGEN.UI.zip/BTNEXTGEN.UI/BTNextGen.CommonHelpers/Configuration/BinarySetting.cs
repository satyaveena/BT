﻿namespace BTNextGen.CommonHelpers.Configuration
{
    public class BinarySetting
    {
        public string Key { get; set; }

        public byte[] Data { get; set; }

        public string Description { get; set; }
    }
}
