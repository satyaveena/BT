﻿using System;
using System.Collections.Generic;
using BTNextGen.CommonHelpers.Constants;
using BTNextGen.CommonHelpers.Helpers;
using BTNextGen.CommonHelpers.Logging;
using Microsoft.SharePoint;

namespace BTNextGen.CommonHelpers.Configuration
{
    public static class GlobalConfiguration
    {
        #region Const

        private const string GlobalConfigurationCacheKey = "__GlobalConfigurationCacheKey";
        private const string GlobalFileCacheKey = "__GlobalFileCacheKey";

        #endregion

        #region public methods

        /// <summary>
        /// Read AppSetting
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static AppSetting ReadAppSetting(string key)
        {
            var settings = GetSettings();
            if (settings == null)
                return null;
            if (string.IsNullOrEmpty(key))
            {
                return null;
            }

            //
            if (settings.ContainsKey(key))
            {
                return settings[key];
            }
            else
            {
                Logger.Write("GlobalConfiguration", string.Format("Key: {0} is not existed", key), false);
                return null;
            }
        }

        /// <summary>
        /// Read Global File Setting
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static BinarySetting ReadBinarySetting(string key)
        {
            var settings = GetFileSettings();
            return settings.ContainsKey(key) ? settings[key] : null;
        }

        #endregion

        #region private methods

        private static Dictionary<string, AppSetting> GetSettings()
        {
            var settings = CacheHelper.Get(GlobalConfigurationCacheKey) as Dictionary<string, AppSetting>;
            if (settings == null)
            {
                //
                settings = new Dictionary<string, AppSetting>();
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.RootWeb.Url))
                    {
                        using (SPWeb web = site.RootWeb)
                        {
                            var spList = web.Lists["GlobalConfiguration"];
                            foreach (SPListItem item in spList.Items)
                            {
                                var setting = new AppSetting
                                {
                                    Key = item["Title"] as string,
                                    Value = item["Value"] as string,
                                    Description = String.Empty
                                };

                                if (!settings.ContainsKey(setting.Key))
                                {
                                    settings.Add(setting.Key, setting);
                                }
                            }

                            CacheHelper.Write(GlobalConfigurationCacheKey, settings);
                        }
                    }
                });
            }
            return settings;
        }

        private static Dictionary<string, BinarySetting> GetFileSettings()
        {
            var settings = CacheHelper.Get(GlobalFileCacheKey) as Dictionary<string, BinarySetting>;
            if (settings != null)
                return settings;
            //
            settings = new Dictionary<string, BinarySetting>();           
            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (var site = new SPSite(SPContext.Current.Site.RootWeb.Url))
                {
                    using (var web = site.RootWeb)
                    {

                        var spList = web.Lists["GlobalFileSetting"];
                        foreach (SPListItem item in spList.Items)
                        {
                            var setting = new BinarySetting
                            {
                                Key = item["Title"] as string,
                                Description = item["Description"] as string,
                                Data = item.File.OpenBinary()
                            };
                            //
                            if (!settings.ContainsKey(setting.Key))
                                settings.Add(setting.Key, setting);
                        }
                        CacheHelper.Write(GlobalFileCacheKey, settings);
                    }
                }
            });            
            return settings;
        }

        #endregion

        public static int GetSessionTimeout()
        {
            int timeout;
            var readAppSetting = ReadAppSetting(GlobalConfigurationKey.Sessiontimeout);
            Int32.TryParse(readAppSetting.Value, out timeout);
            return timeout;
        }

        public static bool IsEnabledSingleActiveUserSession()
        {
            var readAppSetting = ReadAppSetting(GlobalConfigurationKey.Enabledsingleactiveusersession);
            if (readAppSetting != null)
                return readAppSetting.Value.ToLower() == "true";
            return false;
        }

        public static int GetRememberMeDurationTimeout()
        {
            int timeout = 0;
            var readAppSetting = ReadAppSetting(GlobalConfigurationKey.RememberMeDuration);
            if (readAppSetting != null)
                Int32.TryParse(readAppSetting.Value, out timeout);
            return timeout;
        }
    }
}
