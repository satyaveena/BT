//-----------------------------------------------------------------------
// <copyright file="Enums.cs" company="Microsoft">
//     Copyright � Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>The Common Enums class</summary>
//-----------------------------------------------------------------------

namespace BTNextGen.CommonHelpers.Constants
{
    /// <summary>
    /// Site terms names
    /// </summary>
    public enum SiteTermName
    {
        /// <summary>
        /// None site terms
        /// </summary>
        None = -1,

        /// <summary>
        /// Countries site terms
        /// </summary>
        Countries = 0,

        /// <summary>
        /// Regions site terms
        /// </summary>
        Regions = 1,

        /// <summary>
        /// Credit Card Types
        /// </summary>
        CreditCardTypes = 2,

        /// <summary>
        /// Provinces site term
        /// </summary>
        Provinces = 3,

        /// <summary>
        /// States site term
        /// </summary>
        States = 4,

        /// <summary>
        /// Months site term
        /// </summary>
        Months = 5,

        /// <summary>
        /// Years site term
        /// </summary>
        Years = 6,
        #region BTNextGen
        AudienceTypes = 7,
        ProductType = 8,
        MarketType = 9,
        CartFormats = 10,
        SortOrder = 11,
        CartSortBy = 12,
        DefaultDuplicateCarts = 13,
        DefaultDuplicateOrders = 14,
        ResultFormat = 15,
        ResultSortBy = 16,
        ProductTypeFilters = 17,
        UserRole = 18,
        ReviewType = 19,
        OrganizationStatus = 20,
        AdvSearchBook_SearchTerms = 21,
        AdvSearchBookFilterAttribute = 22,
        AdvSearchBookFilterFormat = 23,
        AdvSearchBookFilterLanguague = 24,
        AdvSearchBookFilterPublisherStatus = 25,
        AdvSearchBookFilterLexileScale = 26,
        AdvSearchBookFilterARInterestLevel = 27,
        AdvSearchBookFilterPublishDate = 28,
        DisableReasonCode = 29,
        AdvSearchMusicFilterFormat = 30,
        AdvSearchMusicFilterGenre = 31,
        AdvSearchMovieFilterFormat = 32,
        AdvSearchMovieFilterGenre = 33,
        AdvSearchMusicSearchTerms = 34,
        AdvSearchMovieSearchTerms = 35,
        AdvSearchMusicFilterPublishDate = 36,
        FeeType = 37,
        AddressType = 38,
        CartFolderType = 39,
        UserFunctions = 40,
        OrganizationAdminFunctions = 41,
        BTAdminFunctions = 42,
        BTUserRoleType = 43,
        AdvSearchBookFilterStockStatusServiceCenter = 44,
        AdvSearchBookFilterInventory = 45,
        AdvSearchBookFilterClassification = 46,
        AdvSearchBookFilterStockStatusOnHand = 47,
        AdvSearchBookFilterEdition = 48,
        ResultPerPageTable = 49,
        ResultPerPageTile = 50,
        SecurityQuestions = 51,
        FeeDescription = 52,
        US_en_US = 53,
        OnhandInventoryStatus = 54,
        OrganizationType = 55,
        CartStatus = 56,
        card_type = 57,
        AdvSearchBookFilterPublisherStatusExclude = 58,
        AdvSearchBookFilterRCInterestLevel = 59,
        payment_terms = 60,
        AccountType = 61,
        ISBNLinkDisplayed = 62,
        GiftWrapping = 63,
        OnhandInventoryStatusItemDetails = 64,
        ShippingMethod = 65,
        eSuppliers = 66,
         //ResultsPerPage
        ResultsPerPage = 69
        #endregion BTNextGen
    }

    /// <summary>
    /// Address Detail user Cart Drawer Mode
    /// </summary>
    public enum CartDrawerMode
    {
        /// <summary>
        /// Indicates which action is user for Folders
        /// </summary>
        Folder = 0,
        /// <summary>
        /// Indicates which action is user for Carts
        /// </summary>
        Cart = 1,
        /// <summary>
        /// Indicates action used for dragging Folders
        /// </summary>
        DragFolder = 2,
        /// <summary>
        /// Indicates action used for dragging Carts
        /// </summary>
        DragCart = 3,
        /// <summary>
        /// Initialize Special Folder
        /// </summary>
        InitializeSpecialFolder = 4,
        /// <summary>
        /// Refresh Tree Only
        /// </summary>
        None = 5,
        /// <summary>
        /// Drag Drop in Same Tree
        /// </summary>
        DragDropInSameTree = 6
    }

    /// <summary>
    /// Detail User CartFolder Mode
    /// </summary>
    public enum CartFolderMode
    {
        /// <summary>
        /// Indicates this is an address with no preferences.
        /// </summary>
        None = 0,
        /// <summary>
        /// Special Folder Node DataBound Action
        /// </summary>
        SpecialFolderNodeDataBound = 1,
        /// <summary>
        /// Special Folder Node Edit CartFolder Name Action
        /// </summary>
        EditCartFolderName = 2,
        /// <summary>
        /// Special Folder Node Request Postback Action
        /// </summary>
        RequestPostBack = 3,
        /// <summary>
        /// Drag CartFolder Action
        /// </summary>
        DragCartFolder = 4,
        /// <summary>
        /// Drag & Drop folder in same tree
        /// </summary>
        DragDropInSameTree = 5,
        /// <summary>
        /// Max Exceeded Level
        /// </summary>
        MaxExceededLevel = 6,
        /// <summary>
        /// Create New Folder Error
        /// </summary>
        CreateNewFolderError = 7,
        /// <summary>
        /// Edit Folder Name Error
        /// </summary>
        EditFolderNameError = 8
    }

    /// <summary>
    /// Address Detail user control mode
    /// </summary>
    public enum ControlMode
    {
        /// <summary>
        /// Indicates user control is not set to any mode
        /// </summary>
        None = 0,

        /// <summary>
        /// Indicates user control is in edit mode.
        /// </summary>
        Edit = 1,

        /// <summary>
        /// Indicates user control is in create mode.
        /// </summary>
        Create = 2,

        /// <summary>
        /// Indicates user control is in delete mode.
        /// </summary>
        Delete = 3,

        /// <summary>
        /// Indicates user control is in view mode.
        /// </summary>
        View = 4,

        GetInventoryForHorizontalMode = 5,

        Reset = 6
    }

    /// <summary>
    /// Custom mode
    /// </summary>
    public enum CustomMode
    {
        /// <summary>
        /// Indicates user control will redirect to another page or open new window.
        /// </summary>
        Redirect = 0,

        /// <summary>
        /// Re-use Create of control mode
        /// </summary>
        Create = 1,

        /// <summary>
        /// Re-use view of control mode
        /// </summary>
        View = 2,

        /// <summary>
        /// For Edit User
        /// </summary>
        EditUser = 3,

        /// <summary>
        /// For Edit account
        /// </summary>
        EditAccount = 4,

        /// <summary>
        /// Save new user
        /// </summary>
        SaveNewUser = 5,

        None = 6,

        SearchMode = 7
    }

    /// <summary>
    /// Admin Search mode
    /// </summary>
    public enum AdminSeachMode
    {
        /// <summary>
        /// Search For Account
        /// </summary>
        SearchOrganization = 0,

        /// <summary>
        /// Search For Account that begin with search key
        /// </summary>
        SearchAccountBegin = 1,

        /// <summary>
        /// Search For Account that contains search key
        /// </summary>
        SearchAccountContains = 2,

        /// <summary>
        /// Search For users
        /// </summary>
        SeacrhUser = 3
    }

    /// <summary>
    /// Search Content Types
    /// </summary>
    public enum SearchContentType
    {
        /// <summary>
        /// content type not selected
        /// </summary>
        None = 0,

        /// <summary>
        /// Product catalog content type
        /// </summary>
        ProductCatalog = 1,

        /// <summary>
        /// Site content type
        /// </summary>
        SiteContent = 2,
    }

    public enum ProductType
    {
        Book = 0,
        //Entertainment = 1,
        Music = 2,
        Movie = 3
    }

    public enum ProductStatus
    {
        A = 0, //Active
        D = 1, //Deleted
        R = 2, //
        All
    }

    public enum FeeTypeEnum
    {
        PerUnit = 0,
        PerOrder = 1
    }

    public enum AddressType
    {
        Standard = 0,
        APO_FPO = 1
    }

    public enum AccountType
    {
        Book = 0,
        Entertainment = 1,
        BTDML = 4,
        EBRRY = 5,
        NETLB = 6,
        GALEE = 7,
        eBook = 2, // will be removed
        BookEntertainment = 10
    }

    public enum AjaxServiceStatus
    {
        Success = 0,
        Fail = 1,
        LimitationFail = 2
    }

    public enum ProductTypeFilter
    {
        ProductTypeDetail = 0,
        ProductTypeCatalog = 1
    }

    public enum UserStatus
    {
        InactiveAccount = 0,
        ActiveAccount = 1,
        RequiresApproval = 2,
        RequiresActivate = 3
    }

    public enum InactiveCredential
    {
        ActiveIndicator = 0,
        InactiveIndicator = 1
    }

    public enum AgreementStatus
    {
        AcceptAgreement = 1,
        SetAudienceProductType = 2,
        ChangePassword = 3,
        ContinueWithoutChangePassword = 4,
        LoadData = 5
    }

    public enum BTLoginStatus
    {
        LoggingIn = 1,
        Authenticate = 2,
        LoggedIn = 3,
        LoginError = 4,
        OnLoad = 5,
        ConfirmActiveUser
    }

    public enum OrganizationListStatus
    {
        LoadOrganization = 1,
        LoadMarketAndUserType = 2
    }

    /// <summary>
    /// Internal/External Admin
    /// </summary>
    public enum AdminRole
    {
        InternalAdmin = 0,
        ExternalAdmin = 1
    }

    /// <summary>
    /// User Role Type
    /// </summary>
    public enum BTUserRoleType
    {
        OrganizationAdmin,
        BTAdmin,
        NormalUser
    }

    /// <summary>
    /// Using to check if User is Admin or not
    /// </summary>
    public enum UserRoleFunction
    {
        AddNonNGOrganization,
        CreateNewOrganization,
        MaintainOrganization,
    }

    public enum HomeDeliveryStatus
    {
        LoadNewFeeType = 1,
        LoadNewAddressType = 2,
        LoadFeeType = 3,
        LoadShippingMethod = 4,
        LoadFeeAndShippingMethod = 5,
        AddNewFeeType = 6,
        AddNewShippingMethod = 7,
        SaveFeeAndShippingMethod = 8,
        LoadNewShippingMethod = 9
    }

    /// <summary>
    /// Permission Type
    /// </summary>
    public enum PermissionType
    {
        BTAdmin,
        BTUser,
        OrganizationAdmin,
        OrganizationUser,
        IsBTEmployee,
        ViewOrganizationList,
        ViewOrganizationDetail,
        ViewAccounts,
        ViewUsers,
        CreateOrganization,
        SearchOrganization,
        SearchAccounts,
        SearchUsers,
        EditOrganizationDetail,
        ViewAccountDetail,
        ViewAccountAssignment,
        EditAccountAssignment,
        ViewCartAdmin,
        ViewUserDetail,
        CreateUser,
        EditAccounts,
        EditUsers,
        EditAccountDetail,
        EditUserDetail,
        SubmitOrder
    }

    public enum CartActionMode
    {
        None = 0,
        MoveToFolder = 1,
        Print = 2,
        SubmitOrder = 3,
        CopyCancelledLineItems = 4,
        CopyBackorderedLineItems = 5,
        DownloadExport = 6,
        Merge = 7,
        Archive = 8,
        Restore = 9,
        SetPrimary = 10,
        CopyCarts = 11,
        EditCartName = 12,
        InitModalPopup = 13,
        CreateCart = 14,
        CreateFolder = 15,
        DragDrop = 16
    }

    public enum ProductListView
    {
        Table = 0,
        Stacked = 1,
        Tile = 2,
        CoverFlow = 3
    }

    public enum InventoryMode
    {
        Horizontal = 0,
        Vertical = 1
    }

    /// <summary>
    /// Review & Submit Order Mode
    /// </summary>
    public enum SubmitOrderMode
    {
        /// <summary>
        /// View Summary
        /// </summary>
        ViewSummary = 0,
        /// <summary>
        /// View Home Delivery
        /// </summary>
        ViewHomeDelivery = 1,
        /// <summary>
        /// On Change Entertainment Account
        /// </summary>
        OnChangeEntertainmentAccount = 2,
        /// <summary>
        /// On Change Book Account
        /// </summary>
        OnChangeBookAccount = 3,
        /// <summary>
        /// Change Cost Summry View
        /// </summary>
        ChangeShippingMethod = 4,

        /// <summary>
        /// Persist change option
        /// </summary>
        PersistChange = 5,

        /// <summary>
        /// Chaneg Gift wrapping
        /// </summary>
        ChangeGiftWrapping = 6,

        /// <summary>
        /// Submit Mode
        /// </summary>
        SubmitOrderAction = 7,

        OnChangeEBookAccount = 8
    }

    public enum DownloadExportMode
    {
        Simple = 0,
        POS = 1,
        BasicTitle = 2,
        BasicTitleExpanded = 3,
        BasicMARC = 4
    }
    public enum FilterMode
    {
        None = 0,
        RecentCart = 1,
        AccountType = 2,
        CartStatus = 3,
        Users = 4,
        View = 5
    }

    public enum ForgotPasswordStatus
    {
        ReceivedUserName = 0,
        ReceivedUserSecurityAnswer = 1,
        ReceivedPersonalData = 2,
        ReceivedPickUpSecurityQuestionAndAnswerAndPassword = 3,
        SecurityAnswerValidated = 4
    }

    public enum MarketType
    {
        Any = -1,
        Retail = 0,
        PublicLibrary = 1,
        AcademicLibrary = 2,
        SchoolLibrary = 3,
    }

    public enum ItemsViewMode
    {
        CoverFlow = 0,
        Table
    }

    public enum BatchEntryTab
    {
        Basic = 0,
        CopyPaste = 1,
        ImportFromFile = 2
    }

    public enum SearchResultIsDirectFrom
    {
        AdvancedSearch = 1, // advanced search
        PagesWithBTKeyList = 2 // homw page,menu,contentmanagement.
    }

    public enum NewReleasesCalendarStatus
    {
        ViewNextMonth = 0,
        ViewPreviousMonth = 1,
        ViewCurrentMonth = 2
    }

    public enum ImageSize
    {
        Small = 0,
        Medium = 1,
        Large = 2
    }

    public enum ExceptionCategory
    {
        Admin, Account, User, ContenManagement, Search, Order, General, Permission, Menu, Pricing,
        DistributedCache
    }

    /// <summary>
    /// BTB Publisher Status for Inventory & Item Details
    /// </summary>
    public enum BTBPublisherStatus
    {
        PublisherOutOfStock,
        NotYetPublished,
        NotDefined
    }

    /// <summary>
    /// BTE Inactive Flag for Inventory & Item Details
    /// </summary>
    public enum BTEInactiveFlag
    {
        SupplierOutOfStock,
        NotYetPublished,
        NotDefined
    }

    /// <summary>
    /// Onhand Inventory Status Inventory & Item Details
    /// </summary>
    public enum OnhandInventoryStatus
    {
        InStock,
        AvailableToBackorder,
        AvailableToPreorder,
        EmptyStock
    }

    public enum DefaultDuplicateCarts
    {
        AllCarts,
        MyCarts
    }

    public enum DefaultDuplicateOrders
    {
        AllAccounts,
        MyAccounts
    }

    public enum HoldingsFlag
    {
        none,
        user,
        org
    }


    public enum OrganizationType
    {
        Customer,
        BTNG
    }

    public enum ItemDetailsTab
    {
        DetailsTab = 0,
        AdditionalTab = 1,
        MusicTab = 2,
        AlternateFormatTab = 3,
        ReviewsTab = 4,
        TOCTab = 5,
        ExcerptsTab = 6
    }

    public enum UserFunctions
    {
        SubmitOrder,
        CreateNewOrganization,
        MaintainOrganization,
        CreateUser,
        MaintainUser,
        NotDefined
    }

    public enum PaymentTerms
    {
        CreditCardTerms = 1,
        NormalTerms = 2
    }

    public enum ItemDetailsMode
    {
        None = 0,
        GetAdditionalVersions = 1,
        GetItemNetPriceWhenItemInCart = 2,
        GetItemNetPriceWhenItemNotInCart = 3
    }

    public enum CartSummaryMode
    {
        None = 0,
        SubmitOrder = 1,
        Save = 2,
        Cancel = 3
    }

    // These values are used in CartDrawerScripts.js, CartState object
    public enum CartStatus
    {
        Open = 1,
        Ordered = 2,
        Downloaded = 3,
        Submitted = 4,
        Deleted = -1
    }    
}


