﻿
namespace BTNextGen.CommonHelpers.Constants
{
    public class GlobalConfigurationKey
    {
        public const string FastUrl = "FAST_Url";
        public const string Sessiontimeout = "SessionTimeOut";
        public const string Enabledsingleactiveusersession = "EnabledSingleActiveUserSession";
        public const string RememberMeDuration = "Remember_Me_Duration";
        public const string Auto_Suggest_Collection = "Auto_Suggest_Collection";
        public const string CmCachingDuration = "CM_Caching_Duration";
        public const string RealtimeWsSysid = "RealTime_WS_SysID";
        public const string RealtimeWsSyspass = "RealTime_WS_SysPass";
        public const string CsprofileConnectionstring = "CSProfile_ConnectionString";
        //public const string NgConnectionstring = "NG_ConnectionString";
        public const string ProductcatalogConnectionstring = "ProductCatalog_ConnectionString";
        public const string OrdersConnectionstring = "Orders_ConnectionString";
        public const string CsproductcatalogConnectionstring = "CSProductCatalog_ConnectionString";
        public const string NgFarmactiveusersessionConnectionstring = "NG_FarmActiveUserSession_ConnectionString";       
        public const string MAX_LINES_PER_CART_TITLE = "Max_Lines_Per_Cart";
        public const string SearchExecutorUrlSetting = "FAST_Url";
        public const string DebugTrace = "DebugTrace";
        public const string CsMarketingUserid = "CS_Marketing_UserId";
        public const string StockcheckserviceUrl = "StockCheckService_URL";
        public const string CcmuzeUrl = "CCMuze_URL";
        public const string LogsConnectionstring = "Logs_ConnectionString";
        public const string Createretailuseremailsubject = "CreateRetailUserEmailSubject";
        public const string Createlibraryuseremailsubject = "CreateLibraryUserEmailSubject";
        public const string Cybersourceurl = "CyberSourceUrl";
        public const string CPSIA_WARNING_BASE_URL = "CPSIA_Warning_Base_URL";
        public const string CPSIA_WARNING_USERID = "CPSIA_Warning_User_ID";
        public const string CUSTOMER_SERVICE_LINK = "Customer_Service_Link";
        public const string ShowListcarouselbracket = "Show_ListCarouselBracket";
        public const string Publicationsubscriptionlink = "PublicationSubscriptionLink";
        public const string Commercesitename = "CommerceSiteName";
        public const string Suggestion_Items_Limit = "Suggestion_Items_Limit";
        public const string Suggestion_Delay_Time = "Suggestion_Delay_Time";
        public const string SubmitorderRetry = "SubmitOrder_Retry";
        public const string DemandBucketCachingMinutesKey = "DemandBucketCachingMinutes";
        public const string BasicMARCAverageDownloadSpeed = "BasicMARCAverageDownloadSpeed";
        public const string MARCWebServiceUrl = "MARCWebServiceURL";
        public const string CartCacheExpireDuration = "Cart_Cache_Expire_Duration";
        public const string PricingBatchSize = "Pricing_Batch_Size";
        public const string PricingBatchWaitingTime = "Pricing_Batch_WaitingTime";
        public const string PromotionServiceUrl = "PromotionService_Url";
        public const string TolasPricingServiceUrl = "PricingService_URL";
        public const string GaleLiteral = "GaleLiteral";
        public const string catURL = "CAT_URL";
        public const string SqlCmdTimeout = "SqlCommandTimeout";
        public const string PromotionServiceBatchSize = "PromotionServiceBatchSize";
    }

    public static class AccountStringType
    {
        public const string Book = "Book";
        public const string Entertainment = "Entertainment";
        public const string OneBox = "One-Box";
    }

   
}
