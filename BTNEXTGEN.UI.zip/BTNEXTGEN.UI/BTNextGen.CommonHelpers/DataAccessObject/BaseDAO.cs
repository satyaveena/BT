using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using BTNextGen.CommonHelpers.Constants;

namespace BTNextGen.CommonHelpers.DataAccessObject
{
    public abstract class BaseDAO
    {   
        public abstract string ConnectionString
        { 
            get;
        }

        protected virtual SqlConnection CreateSqlConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        protected virtual SqlCommand CreateSqlCommand(string commandName, SqlConnection sqlConnection)
        {
            return new SqlCommand(commandName, sqlConnection);
        }

        protected virtual SqlCommand CreateSqlSpCommand(string spName, SqlConnection sqlConnection)
        {
            return new SqlCommand(spName, sqlConnection) { CommandType = CommandType.StoredProcedure };
        }

        protected SqlParameter[] CreateSqlParamaters(int numberOfParams)
        {
            return new SqlParameter[numberOfParams];
        }

        #region DAO Helper
        /// <summary>
        /// Convert an object to GUID
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static Guid ConvertToGUID(object obj)
        {
            if (null != obj)
            {
                return new Guid(obj.ToString());
            }
            else
                return Guid.Empty;
        }


        /// <summary>
        /// Convert an object to string
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string ConvertToString(object obj)
        {
            if (null != obj && DBNull.Value != obj)
            {
                return obj.ToString();
            }
            return string.Empty;
        }

        /// <summary>
        /// Convert an object to Int
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static int ConvertToInt(object obj)
        {
            int returnValue = 0;
            if (null != obj)
            {
                int.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        public static string ConvertCartStatus(object obj)
        {
            var returnValue = string.Empty;
            if (obj != null && obj != DBNull.Value)
            {
                var cartStatus = obj.ToString();
                var enumCartStatus = (CartStatus)Enum.Parse(typeof(CartStatus), cartStatus);
                if (enumCartStatus == CartStatus.Downloaded)
                    returnValue = CartStatus.Downloaded.ToString();
                else if (enumCartStatus == CartStatus.Open)
                    returnValue = CartStatus.Open.ToString();
                else if (enumCartStatus == CartStatus.Ordered)
                    returnValue = CartStatus.Ordered.ToString();
                else if (enumCartStatus == CartStatus.Submitted)
                    returnValue = CartStatus.Submitted.ToString();
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to byte
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static byte ConvertToByte(object obj)
        {
            byte returnValue = 0;
            if (null != obj)
            {
                byte.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to bool
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool ConvertToBool(object obj)
        {
            bool returnValue = false;
            if (null != obj)
            {
                bool.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to decimal
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static decimal ConvertToGetDecimal(object obj)
        {
            decimal returnValue = 0;
            if (null != obj)
            {
                decimal.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to datetime
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static DateTime? ConvertToDateTime(object obj)
        {
            DateTime? returnValue = null;
            if (System.DBNull.Value != obj)
            {
                DateTime temp;
                DateTime.TryParse(obj.ToString(), out temp);
                returnValue = temp;
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to long
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static long ConvertToLong(object obj)
        {
            long returnValue = 0;
            if (null != obj)
            {
                long.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to double
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static double ConvertTodouble(object obj)
        {
            double returnValue = 0;
            if (null != obj)
            {
                double.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }
        /// <summary>
        /// Convert an object to decimal
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static decimal ConvertTodecimal(object obj)
        {
            decimal returnValue = 0;
            if (null != obj)
            {
                decimal.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// ConvertToMultipleValue
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public static string[] ConvertToStringArray(string item)
        {
            // invalid string
            if (string.IsNullOrEmpty(item)) return null;

            var results = new List<string>();

            var temp = item.Split(';');

            // invalid string
            if (temp.Length == 0 || temp.Length == 1) return null;

            for(var i = 1; i< temp.Length; i++)
            {
                results.Add(temp[i]);
            }

            return results.Count == 0 ? null : results.ToArray();
        }

        #endregion

        protected object GetDBNullValueIfAny(object o)
        {
            if (o == null)
            {
                return DBNull.Value;
            }
            return o;
        }

        public static T ConvertTo<T>(DataRow row, string columnName)
        {
            if (row.Table.Columns.Contains(columnName))
            {
                if (!row.IsNull(columnName))
                {
                    return row.Field<T>(columnName);
                }
            }
            return default(T);
        }
    }
}