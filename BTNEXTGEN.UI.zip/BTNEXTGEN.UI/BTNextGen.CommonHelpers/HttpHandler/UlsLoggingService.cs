﻿using System;
using System.Collections.Generic;
using BTNextGen.CommonHelpers.Constants;
using Microsoft.SharePoint.Administration;

namespace BTNextGen.CommonHelpers
{
    public class UlsLoggingService : SPDiagnosticsServiceBase
    {
        public const string CommerceServerCategory = "Commerce Server";
        const string DiagnosticAreaName = "NextGen Portal";

        private static UlsLoggingService _current;

        public static UlsLoggingService Current
        {
            get
            {
                if (_current == null)
                {
                    _current = new UlsLoggingService();
                }

                return _current;
            }
        }

        private UlsLoggingService()
            : base("NextGen Portal Logging Service", SPFarm.Local)
        {
        }

        protected override IEnumerable<SPDiagnosticsArea> ProvideAreas()
        {
            List<SPDiagnosticsArea> areas = new List<SPDiagnosticsArea>
            {
                new SPDiagnosticsArea(DiagnosticAreaName, new List<SPDiagnosticsCategory>
                {
                    new SPDiagnosticsCategory(CommerceServerCategory, TraceSeverity.Unexpected, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Account.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Admin.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.ContenManagement.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.General.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Menu.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Order.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Permission.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Pricing.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.Search.ToString(), TraceSeverity.Verbose, EventSeverity.Error),
                    new SPDiagnosticsCategory(ExceptionCategory.User.ToString(), TraceSeverity.Verbose, EventSeverity.Error)
                })
            };

            return areas;
        }

        public static void Log(string categoryName, Exception exception)
        {
            if (exception != null)
            {
                Log(categoryName, exception.ToString());
            }
        }

        public static void Log(string categoryName, string errorMessage)
        {
            SPDiagnosticsCategory category = UlsLoggingService.Current.Areas[DiagnosticAreaName].Categories[categoryName];
            if (category == null)
            {
                category = new SPDiagnosticsCategory(categoryName, TraceSeverity.Verbose, EventSeverity.Error);
            }

            UlsLoggingService.Current.WriteTrace(0, category, category.TraceSeverity, errorMessage);
        }
    }
}
