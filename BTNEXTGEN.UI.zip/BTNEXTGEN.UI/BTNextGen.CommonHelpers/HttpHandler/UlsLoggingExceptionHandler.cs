﻿namespace BTNextGen.CommonHelpers
{
    using System;
    using Microsoft.Commerce.Common;
    /// <summary>
    /// UlsLoggingExceptionHandler class
    /// </summary>
    public class UlsLoggingExceptionHandler : IExceptionHandler
    {
        /// <summary>
        /// Handle exception
        /// </summary>
        /// <param name="exception">input exception</param>
        /// <returns>result exception</returns>
        public Exception HandleException(Exception exception)
        {
            if (exception != null)
            {
                UlsLoggingService.Log(UlsLoggingService.CommerceServerCategory, exception);          
            }
            return exception;
        }

        /// <summary>
        /// Gets initialization data
        /// </summary>
        public string InitializationData
        {
            get;
            set;
        }
    }
}
