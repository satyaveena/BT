using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Text;

namespace BTNextGen.LiveChat.UI.WebControls.WebParts
{
    [Guid("d778caa3-9633-46ca-b156-13260dc27d9f")]
    public class LiveChatWebPart : Microsoft.SharePoint.WebPartPages.WebPart
    {
        #region [ Page variables ]

        private bool _error = false;
        private string _skill = string.Empty;
        private string _email = string.Empty;
        private string _acctName = string.Empty;
        private string _acctNmbr = string.Empty;
        private string _mrktSkin = string.Empty;
        private string _cityStateZip = string.Empty;
        private string _contact = string.Empty;
        private string _adminRights = string.Empty;
        private string _mrktType = string.Empty;
        private string _jsOverRide = string.Empty;
        private string _url = string.Empty;
        private string _jsapi = string.Empty;

        private StringBuilder sbBaseJS = null;
        private StringBuilder sbJSApi = null;

        #endregion

        #region [ Custom Properties ]

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Skill")]
        [WebDescription("Field used to determine agent to ping")]
        public string Skill
        {
            get
            {
                if (string.IsNullOrEmpty(_skill))
                {
                    _skill = "default skill";
                }
                return _skill;
            }
            set { _skill = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Email")]
        [WebDescription("Email Address")]
        public string Email
        {
            get
            {
                if (string.IsNullOrEmpty(_email))
                {
                    _email = "someone@somewhere.com";
                }
                return _email;
            }
            set { _email = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Account Name")]
        [WebDescription("Account Name")]
        public string AccountName
        {
            get
            {
                if (string.IsNullOrEmpty(_acctName))
                {
                    _acctName = "default account name";
                }
                return _acctName;
            }
            set { _acctName = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Account Number")]
        [WebDescription("Account Number")]
        public string AccountNumber
        {
            get
            {
                if (string.IsNullOrEmpty(_acctNmbr))
                {
                    _acctNmbr = "default account number";
                }
                return _acctNmbr;
            }
            set { _acctNmbr = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Market Skin")]
        [WebDescription("Market Skin")]
        public string MarketSkin
        {
            get
            {
                if (string.IsNullOrEmpty(_mrktSkin))
                {
                    _mrktSkin = "default market skin";
                }
                return _mrktSkin;
            }
            set { _mrktSkin = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("City, State, Zip")]
        [WebDescription("City, State, Zip")]
        public string CityStateZip
        {
            get
            {
                if (string.IsNullOrEmpty(_cityStateZip))
                {
                    _cityStateZip = "default city, state, zip";
                }
                return _cityStateZip;
            }
            set { _cityStateZip = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Contact")]
        [WebDescription("Contact")]
        public string Contact
        {
            get
            {
                if (string.IsNullOrEmpty(_contact))
                {
                    _contact = "default contact";
                }
                return _contact;
            }
            set { _contact = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Admin Rights")]
        [WebDescription("Admin Rights")]
        public string Admin
        {
            get
            {
                if (string.IsNullOrEmpty(_adminRights))
                {
                    _adminRights = "default admin rights";
                }
                return _adminRights;
            }
            set { _adminRights = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("Market Type")]
        [WebDescription("Market Type")]
        public string MarketType
        {
            get
            {
                if (string.IsNullOrEmpty(_mrktType))
                {
                    _mrktType = "default market type";
                }
                return _mrktType;
            }
            set { _mrktType = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("Live Person Configuration")]
        [WebDisplayName("JavaScript")]
        [WebDescription("JavaScript code to Launch LivePerson Chat")]
        public string JS
        {
            get
            {
                sbBaseJS = new StringBuilder();
                sbBaseJS.AppendFormat("<!-- BEGIN LivePerson Button Code -->");
                sbBaseJS.AppendFormat("<div id=\"lpButDivID-1300319720694\"></div>");
                //sbBaseJS.AppendFormat("{0}",JavaScriptApi);
                sbBaseJS.AppendFormat("<!-- END LivePerson Button Code -->");
                _jsOverRide = sbBaseJS.ToString();

                return _jsOverRide;
            }

            set { _jsOverRide = value; }
        }

        private string JavaScriptApi
        {
            get
            {
                sbJSApi = new StringBuilder();
                sbJSApi.AppendFormat(" <script type=\"text/javascript\">");
                sbJSApi.AppendFormat(" var lpChatConfig = { ");
                sbJSApi.AppendFormat(" apiKey : '66a2b5d32',"); //change key
                sbJSApi.AppendFormat(" lpServer : 'server.iad.liveperson.net',");
                sbJSApi.AppendFormat(" lpNumber : '12345678'"); // change number
                sbJSApi.AppendFormat(" };");
                sbJSApi.AppendFormat(" lpChatConfig.lpAddScript = function(src, ignore) {var c = lpChatConfig;if(typeof(c.lpProtocol)=='undefined'){c.lpProtocol = (document.location.toString().indexOf(\"https:\")==0) ? \"https\" : \"http\";}if (typeof(src) == 'undefined' || typeof");
                sbJSApi.AppendFormat(" (src) == 'object') {src = c.lpChatSrc ? c.lpChatSrc : '/hcp/html/lpChatAPI.js';};if (src.indexOf('http') != 0) {src = c.lpProtocol + \"://\" + c.lpServer + src + '?site=' + c.lpNumber;} else {if (src.indexOf('site=') < 0) {if (src.indexOf");
                sbJSApi.AppendFormat(" ('?') < 0)src = src + '?'; else src = src + '&';src = src + 'site=' + c.lpNumber;}};var s = document.createElement('script');s.setAttribute('type', 'text/javascript');s.setAttribute('charset', 'iso-8859-1');s.setAttribute('src',");
                sbJSApi.AppendFormat(" src);document.getElementsByTagName('head').item(0).appendChild(s);}");
                sbJSApi.AppendFormat(" if (window.attachEvent) window.attachEvent('onload', lpChatConfig.lpAddScript);");
                sbJSApi.AppendFormat(" else window.addEventListener('load', lpChatConfig.lpAddScript, false);");
                sbJSApi.AppendFormat(" lpc.setCustomVariable('skill','{0}';)", Skill);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('Email','{0}';)", Email);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('AccountName','{0}';)", AccountName);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('AccountNumber','{0};')", AccountNumber);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('MarketSkin','{0}';)", MarketSkin);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('CityStateZip','{0}';)", CityStateZip);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('Contact','{0}';)", Contact);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('Admin','{0}';)", Admin);
                sbJSApi.AppendFormat(" lpc.setCustomVariable('MarketType','{0}';)", MarketType);
                sbJSApi.AppendFormat(" </script>");

                _jsapi = sbJSApi.ToString();
                return _jsapi;
            }
        }

        #endregion

        #region [ Page Events ]

        protected override void CreateChildControls()
        {
            if (!_error)
            {
                try
                {
                    this.Controls.Clear();
                    base.CreateChildControls();
                    this.Controls.Add(new LiteralControl(this.JS));
                }
                catch (Exception ex)
                {
                    HandleException(ex);
                }
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            if (!_error)
            {
                try
                {
                    base.OnLoad(e);
                    this.EnsureChildControls();
                }
                catch (Exception ex)
                {
                    HandleException(ex);
                }
            }
        }

        #endregion

        #region [ Page Methods ]

        public LiveChatWebPart()
        {
            this.ExportMode = WebPartExportMode.All;
        }
        /// <summary>
        /// Clear all child controls and add an error message for display.
        /// </summary>
        /// <param name="ex"></param>
        private void HandleException(Exception ex)
        {
            this._error = true;
            this.Controls.Clear();
            this.Controls.Add(new LiteralControl(ex.Message));
        }
        #endregion

    }
}
