﻿using System;
using System.Diagnostics;
using System.ServiceProcess;
using System.Threading;

namespace BTNextGen.Pricing.RepriceService
{
    public partial class RepriceServiceHandler : ServiceBase
    {
        private readonly RepriceServiceMain _repriceServiceMain = null;
        private Thread _repriceThread = null;
        
        public RepriceServiceHandler(RepriceServiceMain repriceServiceMain)
        {
            _repriceServiceMain = repriceServiceMain;

            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            var repriceThreadStart = new ThreadStart(RepriceProcess);
            _repriceThread = new Thread(repriceThreadStart);
            try
            {
                _repriceThread.Start();

                log4net.Config.BasicConfigurator.Configure();
                repriceServiceLog.WriteEntry("###############RepriceService start..................###############");
            }
            catch (Exception ex)
            {
                repriceServiceLog.WriteEntry(string.Format("###############RepriceService start failed: {0}", ex.ToString()), EventLogEntryType.Error);
            }
        }

        protected override void OnStop()
        {
            try
            {
                if (_repriceThread != null)
                {
                    _repriceThread.Abort();
                }

                repriceServiceLog.WriteEntry("###############RepriceService stop..................###############");
            }
            catch (Exception ex)
            {
                repriceServiceLog.WriteEntry(string.Format("###############RepriceService stop failed: {0}", ex.ToString()), EventLogEntryType.Error);
            }
        }

        public void RepriceProcess()
        {
            int idleTime = 30000;
            int.TryParse(_repriceServiceMain.IdleTime, out idleTime);

            var batchWaitingTime = 100;
            int.TryParse(_repriceServiceMain.BatchWaitingTime, out batchWaitingTime);

            while (true)
            {
                if (CheckConditions())
                {
                    if (Monitor.TryEnter(this, 300))
                    {
                        try
                        {
                            var pricingController = new PricingController();
                            pricingController.DoBackgroundPrice(batchWaitingTime, _repriceServiceMain.BasketPostfixCharacterSet);
                        }
                        catch (Exception ex)
                        {
                            // Write to Event Viewer
                            repriceServiceLog.WriteEntry(ex.ToString(), EventLogEntryType.Error);
                        }
                        finally
                        {
                            Monitor.Exit(this);
                        }
                    }
                }

                // in case of no data to reprice or exception
                Thread.Sleep(idleTime);
            }
        }

        #region Helpers

        private bool CheckConditions()
        {
            bool checkTime;
            bool checkDayOfWeek;
            bool checkExceptionDate;
            try
            {
                //parse start time
                var startHour = int.Parse(_repriceServiceMain.StartTime.Substring(0, 2));
                var startMin = int.Parse(_repriceServiceMain.StartTime.Substring(3, 2));
                //parse end time
                var endHour = int.Parse(_repriceServiceMain.EndTime.Substring(0, 2));
                var endMin = int.Parse(_repriceServiceMain.EndTime.Substring(3, 2));

                checkTime = (startHour < DateTime.Now.Hour || (startHour == DateTime.Now.Hour && startMin <= DateTime.Now.Minute))
                         && (endHour > DateTime.Now.Hour || (endHour == DateTime.Now.Hour && endMin >= DateTime.Now.Minute));
                checkDayOfWeek =
                    _repriceServiceMain.DayOfWeek.Contains(DateTime.Today.DayOfWeek.ToString().Substring(0, 3).ToUpper());
                checkExceptionDate = !(_repriceServiceMain.ExceptionDate.Contains(DateTime.Today.ToString("MM/dd/yyyy")));
                //repriceServiceLog.WriteEntry(
                //    string.Format("###############Checking Condition Result - Time:{0}, DayofWeek:{1}, ExceptionDate:{2}###############", checkTime,
                //                  checkDayOfWeek, checkExceptionDate));
            }
            catch (Exception ex)
            {
                repriceServiceLog.WriteEntry(ex.ToString(), EventLogEntryType.Error);
                return false;
            }
            return checkTime && checkDayOfWeek && checkExceptionDate;
        }

        #endregion
    }
}
