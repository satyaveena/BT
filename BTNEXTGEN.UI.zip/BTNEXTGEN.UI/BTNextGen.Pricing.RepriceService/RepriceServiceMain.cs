﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;

namespace BTNextGen.Pricing.RepriceService
{
    public class RepriceServiceMain
    {
        #region Properties
        public string StartTime
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["RepriceStartTime"]; }
        }

        public string EndTime
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["RepriceEndTime"]; }
        }

        public string DayOfWeek
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["RepriceDayOfWeek"]; }
        }

        public string ExceptionDate
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["ExceptionDate"]; }
        }

        public string IdleTime
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["RepriceIDLETime"]; }
        }

        public string BatchWaitingTime
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["BatchWaitingTime"]; }
        }

        public string BasketPostfixCharacterSet
        {
            get { return System.Configuration.ConfigurationManager.AppSettings["BasketPostfixCharacterSet"]; }
        }

        //public string BasketLineItemBatchSize
        //{
        //    get { return System.Configuration.ConfigurationManager.AppSettings["BasketLineItemBatchSize"]; }
        //}

        //public string MaxThreadCount
        //{
        //    get { return System.Configuration.ConfigurationManager.AppSettings["MaxThreadCount"]; }
        //}
        #endregion

        public RepriceServiceMain()
        {
            //int maxThreadCount = 100;
            //try
            //{
            //    maxThreadCount = int.Parse(MaxThreadCount);                
            //}
            //catch
            //{
                
            //}
            //finally
            //{
            //    ThreadPool.SetMaxThreads(maxThreadCount, maxThreadCount);
            //}
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {            
            var rePricingServiceMain = new RepriceServiceMain();
            ServiceBase.Run(new RepriceServiceHandler(rePricingServiceMain));
        }
    }
}
