﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.ServiceProcess;


namespace BTNextGen.Pricing.RepriceService
{
    [RunInstaller(true)]
    public partial class RepriceServiceInstaller : System.Configuration.Install.Installer
    {
        private readonly ServiceInstaller _serviceInstaller;
        private readonly ServiceProcessInstaller _serviceProcessInstaller;
        public RepriceServiceInstaller()
        {
            InitializeComponent();

            _serviceInstaller = new ServiceInstaller();
            _serviceProcessInstaller = new ServiceProcessInstaller();

            _serviceInstaller.StartType = ServiceStartMode.Automatic;
            _serviceInstaller.ServiceName = "BTNextGenRepriceService";
            _serviceInstaller.Description = "The purpose of the Re-pricing windows service application" +
                                            " is to trigger/call the Pricing Engine to re-price carts " +
                                            "in the system if there are any line items/carts which need to be re-priced.";

            _serviceProcessInstaller.Account = ServiceAccount.LocalSystem;

            Installers.Add(_serviceInstaller);
            Installers.Add(_serviceProcessInstaller);
            
        }
    }
}
