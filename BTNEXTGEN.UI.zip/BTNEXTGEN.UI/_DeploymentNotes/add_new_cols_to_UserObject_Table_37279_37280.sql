use Nextgen_profiles;

ALTER TABLE dbo.UserObject ADD u_alt_format_search_sort_by nvarchar(50) NULL;
ALTER TABLE dbo.UserObject ADD u_alt_format_search_sort_order nvarchar(50) NULL;

ALTER TABLE dbo.UserObject ADD u_alt_format_cart_sort_by nvarchar(50) NULL;
ALTER TABLE dbo.UserObject ADD u_alt_format_cart_sort_order nvarchar(50) NULL;

Go

update dbo.UserObject Set u_alt_format_search_sort_by = 'ngformatliteral' where u_alt_format_search_sort_by is null;
update dbo.UserObject Set u_alt_format_cart_sort_by = 'ngformatliteral' where u_alt_format_cart_sort_by is null;
update dbo.UserObject Set u_alt_format_search_sort_order = 'Ascending' where u_alt_format_search_sort_order is null;
update dbo.UserObject Set u_alt_format_cart_sort_order = 'Ascending' where u_alt_format_cart_sort_order is null;

GO