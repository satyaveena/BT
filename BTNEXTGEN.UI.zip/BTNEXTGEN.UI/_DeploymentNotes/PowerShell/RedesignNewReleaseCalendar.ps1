# TFS 30417: Redesign New Release Calendar

Write-Host ""
Write-Host "=== PROCESSING ..."

if(-not(
Get-PSSnapin | Where { $_.Name -eq "Microsoft.SharePoint.PowerShell"})
) {
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}
#Define variables
$isNotRequired = $false
$publishingSiteUrl = "http://ts360devauth.baker-taylor.com/sites/publishing"
$collaborationSiteUrl = "http://ts360devauth.baker-taylor.com/sites/collaboration"
$newReleaseCalendarListName = "NewReleaseCalendar"
$preOrderDateFieldName = "PreOrderDate"
$productTypeFieldName = "ProductType"
$dateFieldType = "DateTime"
$choiceFieldType = "Choice"

[void][System.reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint")
function AddNewFieldsAndList($siteUrl)
{
	$site = new-object Microsoft.SharePoint.SPSite($siteUrl) 
	$web = $site.rootweb

	# add new fields to NewReleaseCalendar list
	$nrcList = $web.Lists[$newReleaseCalendarListName]
	if($nrcList -ne $null)
	{
		# add PreOrder Date if not exist
		if($nrcList.Fields.ContainsField($preOrderDateFieldName) -eq $false)
		{
			$nrcList.Fields.Add($preOrderDateFieldName, $dateFieldType, $isNotRequired)
			$field = $nrcList.Fields[$preOrderDateFieldName]
			$field.Title = "PreOrder Date"
			$field.DisplayFormat = "DateOnly"
			$field.Update($true);
			
			$spView = $nrcList.DefaultView;
			$spView.ViewFields.Add($preOrderDateFieldName);
			$spView.ViewFields.MoveFieldTo($preOrderDateFieldName, 2);
			$spView.Update();
		}
		
		# add ProductType if not exist
		if($nrcList.Fields.ContainsField($productTypeFieldName) -eq $false)
		{
			$nrcList.Fields.Add($productTypeFieldName, $choiceFieldType, $isNotRequired)
			$typeField = $nrcList.Fields[$productTypeFieldName]
			$typeField.Title = "Product Type"
			#Add array as Choices
			$productTypes = @("Book","Movie","Music")
			$typeField.choices.addrange($productTypes)
			$typeField.Update($true)
			
			$spView = $nrcList.DefaultView;
			$spView.ViewFields.Add($productTypeFieldName);
			$spView.ViewFields.MoveFieldTo($productTypeFieldName, 4);
			$spView.Update();
		}
	}

	# create NRCFeaturedTitles list from NewReleaseCalendar list
	$featuredTitlesListName = "NRCFeaturedTitles"
	if($web.Lists.TryGetList($featuredTitlesListName) -eq $null)
	{
		$id = [Guid]::NewGuid()
		$templateName = [String]::Format("{0}-{1}",$nrcList.Title,$id.ToString());
		$templateFileName = $templateName;
		#Save the list as a list template
		$isSaveListData = $false
		$nrcList.SaveAsTemplate($templateFileName, $templateName, $nrcList.Description, $isSaveListData)
		
		#Create a new list from the template
		$listTemplate = $site.GetCustomListTemplates($web)[$templateName]
		$web.Lists.Add($featuredTitlesListName, "New Release Calendar - FeaturedTitles", $listTemplate);
		$web.Update()
		
		$featuredList = $web.Lists[$featuredTitlesListName];
		
		#show the new list on quick launch
		$featuredList.OnQuickLaunch = $true
		$featuredList.Update();
		
		#make PreOrder required
		$f1 = $featuredList.Fields["PreOrder Date"]
		$f1.Required = $true
		$f1.Update();
		
		#make ProductType required
		$f2 = $featuredList.Fields["Product Type"]
		$f2.Required = $true
		$f2.Update();
		
		#Delete the list template from the List Template Gallery            
		$listTemplates = $web.Lists["List Template Gallery"]
		$lt = $listTemplates.Items | ?{$_.Title -eq $templateName}
		if($lt -ne $null){$lt.Delete();}
	}

	$web.Dispose()
	$site.Dispose()
}

function CreateNewFeaturedTitleSpreadsheetsLibrary($siteUrl)
{
	$site = new-object Microsoft.SharePoint.SPSite($siteUrl) 
	$web = $site.rootweb
	$sourceLibName = "New Release Spreadsheets"
	$newLibName = "New FeaturedTitle Spreadsheets"
	
	# create lib from New Release Spreadsheets lib
	$sourceLib = $web.Lists[$sourceLibName]
	if($sourceLib -ne $null -And $web.Lists.TryGetList($newLibName) -eq $null)
	{
		$id = [Guid]::NewGuid()
		$templateName = [String]::Format("{0}-{1}", $sourceLib.Title,$id.ToString());
		$templateFileName = $templateName;
		#Save the lib as a lib template
		$isSaveListData = $false
		$sourceLib.SaveAsTemplate($templateFileName, $templateName, $sourceLib.Description, $isSaveListData)
		
		#Create a new lib from the template
		$libTemplate = $site.GetCustomListTemplates($web)[$templateName]
		$web.Lists.Add($newLibName, $newLibName, $libTemplate);
		$web.Update()
		
		$featuredLib = $web.Lists[$newLibName];
		
		#show the new list on quick launch
		$featuredLib.OnQuickLaunch = $true
		$featuredLib.Update();
		
		#Delete the list template from the List Template Gallery            
		$listTemplates = $web.Lists["List Template Gallery"]
		$lt = $listTemplates.Items | ?{$_.Title -eq $templateName}
		if($lt -ne $null){$lt.Delete();}
	}
	
	$web.Dispose()
	$site.Dispose()
}

#Update publishing site
AddNewFieldsAndList($publishingSiteUrl);

#Update collaboration site
AddNewFieldsAndList($collaborationSiteUrl);

#Create New Featured Title Spreadsheets in collaboration site
CreateNewFeaturedTitleSpreadsheetsLibrary($collaborationSiteUrl);

Write-Host "=== COMPLETED."

