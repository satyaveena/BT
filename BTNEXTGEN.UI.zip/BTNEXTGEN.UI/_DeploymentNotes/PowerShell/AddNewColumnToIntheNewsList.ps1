if(-not(
Get-PSSnapin | Where { $_.Name -eq "Microsoft.SharePoint.PowerShell"})
) {
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}
#Define variables
$isRequired = $false
$listName = "InTheNews"
$siteUrl = "http://vmae743452:6580/sites/publishing"
$fieldName = "News Document"
$fieldtype = "URL"

[void][System.reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint")
$site = new-object Microsoft.SharePoint.SPSite($siteUrl) 
$web = $site.rootweb 
$spList = $web.Lists[$listName]
if($spList -ne $null)
{
$spList.Fields.Add($fieldName,$fieldtype,$isRequired)
$spView = $spList.DefaultView;
$spView.ViewFields.Add($fieldName);
$spView.Update();
}
$web.Dispose()
$site.Dispose()

