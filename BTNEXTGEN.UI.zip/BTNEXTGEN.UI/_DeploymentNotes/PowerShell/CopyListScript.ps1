if(-not(
Get-PSSnapin | Where { $_.Name -eq "Microsoft.SharePoint.PowerShell"})
) {
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}
#Define variables
$SiteUrl = "http://vmae743452:6580/sites/publishing";
$SourceListName = "SpecialCodeHelp";
$DestinationListName = "MarcProfileDescription";

#Get the source and destination sites (SPWeb objects)            
$site = New-Object Microsoft.SharePoint.SPSite($SiteUrl)
$web =  $site.OpenWeb()
$destinationSite = New-Object Microsoft.SharePoint.SPSite($SiteUrl);
$destinationWeb = $destinationSite.OpenWeb()

#Connect to the source list            
$sourceList = $web.Lists[$SourceListName];
#Create a unique name to use when saving the list as a template.            
$id = [Guid]::NewGuid()
$templateName = [String]::Format("{0}-{1}",$sourceList.Title,$id.ToString());
$templateFileName = $templateName;
#Save the list as a list template. The forth parameter of the SaveAsTemplate method takes a boolean value indicating whether to save list data with the list.            
$sourceList.SaveAsTemplate($templateFileName, $templateName, $sourceList.Description, $false)
#Get the list template that was just saved            
$listTemplate = $site.GetCustomListTemplates($web)[$templateName]
#Create a new list at the destination web using the list template created from the source list            
$destinationWeb.Lists.Add($destinationListName, "MarcProfileDescription", $listTemplate);
$destinationWeb.Update()
#Clean Up            
#Delete the list the list template for, the List Template Gallery            
$listTemplates = $site.RootWeb.Lists["List Template Gallery"]
$lt = $listTemplates.Items | ?{$_.Title -eq $templateName}
if($lt -ne $null){$lt.Delete();}
#Dispose of the SPWeb and SPSite objects            
$web.Dispose();
$site.Dispose();
$destinationWeb.Dispose();
$destinationSite.Dispose();
