USE [Nextgen_profiles]
GO

/****** Object:  StoredProcedure [dbo].[procTS360OAuthGetUserByName]    Script Date: 03/27/2015 13:06:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
=============================================
Author:			Huy Nguyen
Create date:	03-24-2015
Description:	Return user info for OAuth SSO
=============================================
*/
CREATE PROCEDURE [dbo].[procTS360OAuthGetUserByName]
	@UserName	nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	o.u_Name as OrganizationName
			, CASE o.u_web_market_type 
					WHEN 0 THEN 'Retail'
					WHEN 1 THEN 'Public Library' 
					WHEN 2 THEN 'Academic Library'
					WHEN 3 THEN 'School Library' 
					END as MarketType
			, u.u_user_name as UserName
			, u.u_user_alias as UserAlias
			, u.u_email_address as EmailAddress			
	FROM	dbo.UserObject AS U
	JOIN	dbo.OrganizationObject AS O
	ON		U.u_org_id = O.u_org_id	
	WHERE	u.u_user_name = @UserName

	RETURN 0
END
GO


