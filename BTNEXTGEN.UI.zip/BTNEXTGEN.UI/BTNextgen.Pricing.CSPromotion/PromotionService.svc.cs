﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using System.Collections;
using Microsoft.CommerceServer.Runtime.Orders;
using Microsoft.CommerceServer.Runtime;
using Microsoft.CommerceServer.Runtime.Profiles;
using Microsoft.Commerce.Common.MessageBuilders;
using Microsoft.Commerce.Contracts.Messages;
using Basket = Microsoft.CommerceServer.Runtime.Orders.Basket;
using BTNextGen.Commerce.Portal.Common;

namespace BTNextgen.Pricing.CSPromotion
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class PromotionService : IPromotionService
    {
        /// <summary>
        /// Constant for CS Promotion Pricing
        /// </summary>
        private const string TargetingContextAll = "ALL";

        /// <summary>
        /// Variables for CS Promotion
        /// </summary>
        private Hashtable _operations;
        private string _basketName = "";
        private string _marketType = "";
        private string _myPrefProductType = "";
        private string _myPrefAudienceType = "";

        #region CS Promotion Real-time

        /// <summary>
        /// Calculate Promotion Price
        /// </summary>
        /// <param name="btKey"></param>
        /// <param name="productCatalog"></param>
        /// <param name="userId"></param>
        /// <param name="totalLineQuantity"></param>
        /// <param name="totalOrderQuantity"></param>
        /// <param name="marketType"></param>
        /// <param name="myPrefProductType"></param>
        /// <param name="myPrefAudienceType"></param>
        /// <returns></returns>
        public decimal CalculatePromotionPrice(string btKey, string productCatalog,
                string userId, int totalLineQuantity, int totalOrderQuantity,
                string marketType, string myPrefProductType, string myPrefAudienceType)
        {
            var discountPrice = (decimal)0.0;

            // Setting for TargetingContext
            this._marketType = marketType;
            this._myPrefProductType = myPrefProductType ?? string.Empty;
            this._myPrefAudienceType = myPrefAudienceType ?? string.Empty;

            var basket = CreateEmptyBasket();
            //
            var lineItemEx = AddProductToBasket(basket, btKey, productCatalog, totalLineQuantity);
            var pipelineInfo = CreateBasketPipelineInfo(userId);
            //            

            basket.RunPipeline(pipelineInfo);

            discountPrice = lineItemEx.BTSalePrice;

            basket.Delete();

            return discountPrice;
        }

        /// <summary>
        /// Create Basket Pipeline Info
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private PipelineInfo CreateBasketPipelineInfo(string userId)
        {
            var pipelineInfo = new PipelineInfo("Basket", OrderPipelineType.Basket);
            var user = GetUserProfileObject(userId);
            pipelineInfo.Profiles.Add("UserObject", user);

            var ctx = CommerceContext.Current;

            ctx.TargetingSystem.TargetingContextProfile.Properties["market_type"].Value = _marketType;
            ctx.TargetingSystem.TargetingContextProfile.Properties["product_type"].Value = AddAllValue(this._myPrefProductType);
            ctx.TargetingSystem.TargetingContextProfile.Properties["audience_type"].Value = AddAllValue(this._myPrefAudienceType);

            pipelineInfo.Profiles.Add("targetingContext", ctx.TargetingSystem.TargetingContextProfile);

            return pipelineInfo;
        }

        /// <summary>
        /// Add Product To Basket
        /// </summary>
        /// <param name="basket"></param>
        /// <param name="productId"></param>
        /// <param name="productCatalog"></param>
        /// <param name="quantity"></param>
        /// <returns></returns>
        private static LineItemEx AddProductToBasket(Basket basket, string productId, string productCatalog, int quantity)
        {
            var lineItemEx = new LineItemEx { ProductId = productId, ProductCatalog = productCatalog, Quantity = quantity };
            basket.OrderForms[0].LineItems.Add(lineItemEx);
            return lineItemEx;
        }

        /// <summary>
        /// Get User Profile Object
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private Profile GetUserProfileObject(string userId)
        {
            CommerceContext.Current.UserID = userId;

            var user = CommerceContext.Current.UserProfile;

            return user;
        }

        /// <summary>
        /// Create Empty Basket
        /// </summary>
        /// <returns></returns>
        private Basket CreateEmptyBasket()
        {
            Basket basket = CommerceContext.Current.OrderSystem.GetBasket(Guid.NewGuid());
            basket.OrderForms.Add(new OrderFormEx());

            return basket;
        }

        /// <summary>
        /// Add All Value
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private static string AddAllValue(string item)
        {
            const string delimiter = ";";

            if (item == "")
                return string.Empty;

            return TargetingContextAll + delimiter + item;
        }

        #endregion
    }
}
