﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BTNextgen.Pricing.CSPromotion
{    
    [ServiceContract]
    public interface IPromotionService
    {

        [OperationContract]
        decimal CalculatePromotionPrice(string btKey, string productCatalog,
                                        string userId, int totalLineQuantity, int totalOrderQuantity,
                                        string marketType, string myPrefProductType, string myPrefAudienceType);

    }
}
