﻿using BTNextGen.Commerce.Portal.Common.Controllers;
using Microsoft.Commerce.Contracts;
using BTNextGen.Commerce.Portal.Common.Configuration;

namespace BTNextGen.Commerce.Portal.Common.Caching
{
    //Centalize CSObject loading for specific purpose with caching to improve the performance.
    public static class CSObjectProxy
    {
        const string searchResultCacheKey = "__UserProfileForSearchResult";

        const string cartDrawerCacheKey = "__UserProfileForCartDrawer";

        public static void SetDirtyUserProfile()
        {
            var userCacheKey = string.Concat(searchResultCacheKey, SiteContext.Current.UserId);
            SessionCacheManager.Remove(userCacheKey);

            var userCartCacheKey = string.Concat(cartDrawerCacheKey, SiteContext.Current.UserId);
            SessionCacheManager.Remove(userCartCacheKey);
        }

        public static UserProfile GetUserProfileForSearchResult()
        {
            // overload method doesnt work in this case, create empty method. 
            return GetUserProfileForSearchResult("");
        }

        public static UserProfile GetUserProfileForSearchResult(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                userId = SiteContext.Current.UserId;

            var userCacheKey = searchResultCacheKey + userId;
            var value = SessionCacheManager.Get(userCacheKey);
            if (value != null)
            {
                return (UserProfile) value;
            }
            //
            var profileController = ProfileController.Current;
            //
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.ProductTypeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.BTAccountStatus);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.CartSortOrder);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.CartSortBy);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.CartFormat);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteLineItem);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.ShowAddToCartTooltip);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.FunctionList);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.IsBTEmployee);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);

            //
            profileController.UserProfileRelated.OrganizationNeeded = true;
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.PersonalProductURL);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.ISBNLookupCode);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.ProductLookupDeactivated);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.ProductLookupIndex);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.ProductSuffixLookup);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.ISBNLinkDisplayed);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVPersonalProductURL);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVUPCLookupCode);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVProductLookupDeactivated);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVProductLookupIndex);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVProductSuffixLookup);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVUseUPC14);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AVUseISBN);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.ReviewTypes);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.EntertainmentProduct);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.TableOfContents);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AccountCount);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.WebOrder);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.IsBTEmployee);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.MARCProfilerEnabled);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.IsFullMarcProfile);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.FulltextReviews);
            profileController.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AllWarehouse);
            //
            profileController.UserProfileRelated.AccountCreateCartNeeded = true;
            profileController.UserProfileRelated.DefaultBookAccountNeeded = true;
            profileController.UserProfileRelated.DefaultEntertainmentAccountNeeded = true;
            profileController.UserProfileRelated.DefaultOneBoxAccountNeeded = true;
            profileController.UserProfileRelated.DefaultVIPAccountNeeded = true;
            profileController.UserProfileRelated.SalesRepNeeded = true;

            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteLineItem);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteFolder);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteCart);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultBookAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultEntertainmentAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultOneBoxAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultVIPAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.RelationshipName.DefaultVIPAccount);
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.eSupplier);
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.AccountType);
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.AccountNumber);
            profileController.AccountPropertiesToReturn.Add(CommerceEntity.PropertyName.Id);
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.ProductType);
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.IsShippingAccount);
            
            //
            profileController.UserProfileRelated.AccountViewOrderNeeded = true;
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.IsTOLAS);
            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.Account8Id);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultDuplicateOrders);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultDuplicateCarts);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultDownloadedCarts);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.HoldingsFlag);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.HoldingsUploaded);
            
            //
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.RelationshipName.DefaulteSuppliersAccount);
            profileController.OrganizationPropertiesToReturn.Add(Organization.RelationshipName.DefaulteSuppliersAccount);

            profileController.AccountPropertiesToReturn.Add(Account.PropertyName.IsVIP);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.BookIncludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.BookExcludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DigitalIncludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DigitalExcludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.MusicIncludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.MusicExcludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.MovieIncludeFilter);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.MovieExcludeFilter);

            //
            var userProfile = profileController.GetUserById(userId);

            //Cache userProfile in 15 minutes. This cache will be remove when users change their myPreference.
            if(userProfile!=null)
                SessionCacheManager.Add(userCacheKey, userProfile, GlobalConfiguration.UserProfileDurationCache);
            //
            return userProfile;
        }

        public static UserProfile GetUserProfileForCartDrawer()
        {
            var value = SessionCacheManager.Get(cartDrawerCacheKey);
            if (value != null)
            {
                return (UserProfile) value;
            }
            //
            var profileController = ProfileController.Current;
            //
            profileController.UserProfileRelated.AccountCreateCartNeeded = true;
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteLineItem);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteFolder);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.WarningDeleteCart);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultBookAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultEntertainmentAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.DefaultVIPAccountId);
            profileController.UserProfilePropertiesToReturn.Add(UserProfile.RelationshipName.DefaultVIPAccount);
            //
            var userProfile = profileController.GetUserById(SiteContext.Current.UserId);

            //Cache userProfile in 15 minutes. This cache will be remove when users change their myPreference.
            if (userProfile != null)
                SessionCacheManager.Add(cartDrawerCacheKey, userProfile, 1);
            //
            return userProfile;
        }   
    }
}
