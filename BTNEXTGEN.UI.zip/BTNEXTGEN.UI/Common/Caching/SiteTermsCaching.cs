﻿using System.Collections.Generic;
using System.Threading;
using BTNextGen.Commerce.Portal.Common.Constants;
using Microsoft.Commerce.Contracts;
using System.Web;
using System.Web.Caching;
using System;

namespace BTNextGen.Commerce.Portal.Common.Caching
{
    public static class SiteTermsCaching
    {
        private const int DefaultCacheDuration = 24;//hours

        private static readonly Dictionary<SiteTermName, CommerceRelationshipList> Repository = new Dictionary<SiteTermName, CommerceRelationshipList>();

        private static readonly ReaderWriterLockSlim Lock = new ReaderWriterLockSlim();

        /// <summary>
        /// Get SiteTerm from Cache
        /// </summary>
        /// <param name="siteTermName"></param>
        /// <returns></returns>
        public static CommerceRelationshipList Get(SiteTermName siteTermName)
        {
            Lock.EnterReadLock();
            try
            {
                CommerceRelationshipList result = HttpContext.Current.Cache[siteTermName.ToString()] as CommerceRelationshipList;
                
                return result;
            }
            finally
            {
                Lock.ExitReadLock();
            }
        }

        /// <summary>
        /// Set SiteTerm to Cache
        /// </summary>
        /// <param name="siteTermName"></param>
        /// <param name="siteTerms"></param>
        public static void Set(SiteTermName siteTermName, CommerceRelationshipList siteTerms)
        {
            Lock.EnterWriteLock();
            try
            {
                CommerceRelationshipList cacheSiteTerm = HttpContext.Current.Cache[siteTermName.ToString()] as CommerceRelationshipList;

                if (cacheSiteTerm != null)
                    HttpContext.Current.Cache.Remove(siteTermName.ToString());

                HttpContext.Current.Cache.Add(siteTermName.ToString(), siteTerms, null, DateTime.Now.AddHours(DefaultCacheDuration), Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);

            }
            finally
            {
                Lock.ExitWriteLock();
            }
        }
    }
}
