﻿using System;
using System.Web;

namespace BTNextGen.Commerce.Portal.Common.Caching
{
    public static class SessionCacheManager
    {
        public static void Add(string key, object value, int minutes)
        {
            var item = new SessionCacheItem {CachedObject = value, ExpirationTime = DateTime.Now.AddMinutes(minutes)};
            SiteContext.Current.Session[key] = item;
        }

        public static void Remove(string key)
        {
            SiteContext.Current.Session[key] = null;
        }

        public static object Get(string key)
        {
            var item = SiteContext.Current.Session[key] as SessionCacheItem;
            if (item != null)
            {
                if (!item.IsExpired())
                    return item.CachedObject;
            }
            return null;
        }
    }
}
