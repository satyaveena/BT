﻿using System;

namespace BTNextGen.Commerce.Portal.Common.Caching
{
    public class SessionCacheItem
    {
        public DateTime ExpirationTime { get; set; }

        public DateTime Created { get; set; }

        public object CachedObject { get; set; }

        public SessionCacheItem()
        {
            Created = DateTime.Now;
        }

        public bool IsExpired()
        {
            return ExpirationTime < DateTime.Now;
        }
    }
}
