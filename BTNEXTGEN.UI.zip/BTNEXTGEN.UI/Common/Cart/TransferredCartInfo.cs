﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using BTNextGen.Commerce.Portal.Common.Search;

namespace BTNextGen.Commerce.Portal.Common.Cart
{
    public class TransferredCartInfo
    {
        public string BasketSummaryID;
        public string TransferredFrom;
        public string TransferredTo;
        public DateTime? TransferredFromDate;
        public DateTime? TransferredToDate;
       
    }
}
