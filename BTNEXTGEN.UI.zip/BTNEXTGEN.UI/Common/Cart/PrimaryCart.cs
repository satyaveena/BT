﻿using System.Collections.Generic;

namespace BTNextGen.Commerce.Portal.Common.Cart
{
    public class PrimaryCart
    {
        private Dictionary<string, LineItem> _indexedLineItems;

        public Basket Basket { get; set; }

        private List<LineItem> _lineItems;
        public List<LineItem> LineItems
        {
            get { return _lineItems; }
            set
            {
                _lineItems = value;
                _indexedLineItems = new Dictionary<string, LineItem>();
                foreach (var lineItem in value)
                {
                    if (!_indexedLineItems.ContainsKey(lineItem.BTKey))
                    {
                        _indexedLineItems.Add(lineItem.BTKey, lineItem);
                    }
                }
            }
        }

        public int GetDefaultQuantity(string btKey)
        {
            if (_indexedLineItems != null)
            {
                LineItem item;
                _indexedLineItems.TryGetValue(btKey, out item);
                if (item != null)
                {
                    var quan = item.Quantity ?? 0;
                    return (int) quan;
                }
            }
            return -1;
        }

        public string GetBasketName()
        {
            if (Basket != null)
                return Basket.Name;
            return string.Empty;
        }
    }
}
