﻿using System;
using BT.TS360Constants;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common.Helpers;
using System.Web;
namespace BTNextGen.Commerce.Portal.Common.Ajax
{
    public class BaseAjaxService
    {
        public BaseAjaxService()
        {
            //HttpContext.Current.Server.ScriptTimeout = 45;
        }

        #region Localization
        /// <summary>
        /// Gets the localized string.
        /// </summary>
        /// <param name="className">Name of the class.</param>
        /// <param name="resourceKey">The resource key.</param>
        /// <returns>The localized string.</returns>
        public string GetLocalizedString(string className, string resourceKey)
        {
            return ResourceHelper.GetLocalizedString(className, resourceKey);
        }

        /// <summary>
        /// Gets the localized string using DefaultResourceClassName.
        /// </summary>        
        /// <param name="resourceKey">The resource key.</param>
        /// <returns>The localized string.</returns>
        public string GetLocalizedString(string resourceKey)
        {
            var resourceName = GetDefaultResourceName();
            return ResourceHelper.GetLocalizedString(resourceName, resourceKey);
        }

        private ResourceName GetDefaultResourceName()
        {
            var resourceName = (ResourceName)Enum.Parse(typeof(ResourceName), GetDefaultResourceClassName(), true);
            return resourceName;
        }

        protected virtual string GetDefaultResourceClassName()
        {
            return "Common";
        }

        // This function for user is allowed or not is allowed
        protected static bool IsAllowed(PermissionType permission)
        {
            var permissions = ProfileController.Current.GetCurrentUserPermissions(false);
            return (permissions != null) && permissions.AllowedPermissions.Contains(permission);// true;
        }
        #endregion  
    }
}
