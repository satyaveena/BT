﻿using System.Runtime.Serialization;
using BTNextGen.Commerce.Portal.Common.Constants;

namespace BTNextGen.Commerce.Portal.Common.Ajax
{
    [DataContract]
    public class AjaxServiceResult<T>
    {
        [DataMember]
        public T Data { get; set; }

        [DataMember]
        public AjaxServiceStatus Status { get; set; }

        [DataMember]
        public string SystemError { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }

        public AjaxServiceResult()
        {
            Status = AjaxServiceStatus.Success;
        }
    }
}
