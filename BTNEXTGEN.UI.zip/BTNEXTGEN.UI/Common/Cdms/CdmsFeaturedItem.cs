﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.Commerce.Portal.Common.Cdms
{
    public class CdmsFeaturedItem
    {
        public string FeaturedKey { get; set; }
        public string FeaturedName { get; set; }
        public string FeaturedItemKey { get; set; }
        public string FeaturedItemName { get; set; }
        public int FeaturedItemCount { get; set; }
    }
}
