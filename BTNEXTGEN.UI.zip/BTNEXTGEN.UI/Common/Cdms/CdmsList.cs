﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.Commerce.Portal.Common.Cdms
{
    public class CdmsList
    {
        public string CdmsListId { get; set; }
        public string CdmsListName { get; set; }
        public int NumberOfItems { get; set; }
        public int NumberOfUsers { get; set; }
        public int NumberOfOrgs { get; set; }
        public DateTime DispatchDate { get; set; }
    }

}
