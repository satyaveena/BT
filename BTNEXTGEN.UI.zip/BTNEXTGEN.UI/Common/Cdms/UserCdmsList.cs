﻿
using System;
using System.Data;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;

namespace BTNextGen.Commerce.Portal.Common.Cdms
{
    public class UserCdmsList
    {
        public string Id { get; set; }

        public string UserId { get; set; }

        public string UserLoginName { get; set; }

        public string UserDisplayName { get; set; }

        public string CdmsListId { get; set; }

        public static UserCdmsList CreateUserCdmsListFromDataRow(DataRow dataRow)
        {
            try
            {
                var cartFolder = new UserCdmsList()
                {
                    Id = DataAccessHelper.ConvertToString(dataRow["Id"]),
                    UserId = DataAccessHelper.ConvertToString(dataRow["UserId"]),
                    UserLoginName = DataAccessHelper.ConvertToString(dataRow["UserLoginName"]),
                    UserDisplayName = DataAccessHelper.ConvertToString(dataRow["UserDisplayName"]),
                    CdmsListId = DataAccessHelper.ConvertToString(dataRow["CdmsListId"]),
                };
                return cartFolder;
            }
            catch (Exception exception)
            {
                Logger.LogException(exception);
                throw;
            }
        }
    }
}
