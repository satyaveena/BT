﻿using System;

namespace BTNextGen.Commerce.Portal.Common.Administration
{
    [Serializable]
    public class UnassignedAccount
    {
        public string AccountName { get; set; }
        public string AccountNumber { get; set; }
        public string Id { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string ProductType { get; set; }
    }
}
