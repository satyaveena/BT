﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Helpers;

namespace BTNextGen.UnitTest
{
    public class DBAccessHelper
    {
        private static SqlConnection _conn = null;
        private static void CreateConnectionString()
        {
            var connectString = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.OrdersConnectionstring).Value;
            //var connectString = @"Provider=SQLOLEDB.1;Password=P@ssword123;Persist Security Info=True;User ID=sa;Initial Catalog=Orders;Data Source=SHAREPOINT-SVR\R25Repository";
            // Cut out Provider
            if (connectString.ToLower().Contains("provider"))
            {
                int firstDelimeter = connectString.IndexOf(';');
                connectString = connectString.Substring(firstDelimeter + 1);
            }

            _conn = new SqlConnection(connectString);
            
        }
        public static string GetValidUserIdFromOrgID(string orgId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd = new SqlCommand("SELECT TOP 1 u_user_id FROM CommerceServer.Nextgen_profiles.dbo.UserObject WHERE u_org_id = '" + orgId + "'", _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }
            
            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["u_user_id"]);
            }
            return string.Empty;
        }
        public static string GetOrgByUserId(string userId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd = new SqlCommand("SELECT TOP 1 u_org_id FROM CommerceServer.Nextgen_profiles.dbo.UserObject WHERE u_user_id = '" + userId + "'", _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["u_org_id"]);
            }
            return string.Empty;
        }
        public static void GetUserIdAndOrgIdPair(out string userId, out string orgId )
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd = new SqlCommand("SELECT TOP 1 u_user_id, u_org_id FROM CommerceServer.Nextgen_profiles.dbo.UserObject", _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            orgId = string.Empty;
            userId = string.Empty;
            try
            {
                da.Fill(ds);
            }
            
            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                userId = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["u_user_id"]);
                orgId = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["u_org_id"]);
            }
            
        }

        public static string GetCartIdWithLineItems()
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(
                    "SELECT TOP 1 BasketSummaryID FROM BasketLineItems BLI, BasketOrderForm BOF WHERE BOF.BasketOrderFormId = BLI.BasketOrderFormId",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketSummaryID"]);
            }
            return string.Empty;
        }

        public static string GetCartIdByLineItem(string lineItemID)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(
                    "SELECT TOP 1 BasketSummaryID FROM BasketLineItems BLI, BasketOrderForm BOF WHERE BOF.BasketOrderFormId = BLI.BasketOrderFormId AND BLI.BasketLineItemID = '" + lineItemID + "'",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketSummaryID"]);
            }
            return string.Empty;
        }
        public static string GetLineItemIdByUserId(string userId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(
                    "SELECT TOP 1 BasketLineItemId FROM BasketLineItems BLI, BasketOrderForm BOF, BasketSummary BS WHERE BOF.BasketOrderFormId = BLI.BasketOrderFormId and BS.BasketSummaryID = BOF.BasketSummaryID and BasketOwnerID = '" + userId + "'",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketLineItemId"]);
            }
            return string.Empty;
        }
        public static string GetUserIdWithNoEmptyCart()
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(@"SELECT TOP 1 BasketOwnerID 
                                FROM BasketLineItems BLI, BasketOrderForm BOF, BasketSummary BS, BasketUsers BU
                                WHERE BOF.BasketOrderFormId = BLI.BasketOrderFormId 
                                AND BS.BasketSummaryID = BOF.BasketSummaryID
                                AND BS.BasketOwnerID = BU.u_user_id", _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketOwnerID"]);
            }
            return string.Empty;
        }

        public static string GetCartIdWithDefaultTemplate()
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand("SELECT TOP 1 DefaultBasketSummaryID FROM GridTemplates WHERE DefaultBasketSummaryID IS NOT NULL",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["DefaultBasketSummaryID"]);
            }
            return string.Empty;
        }
        public static string GetSharedCartID(string userId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand("SELECT TOP 1 BasketSummaryID FROM BasketUser WHERE u_user_id = '" + userId + "'",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketSummaryID"]);
            }
            return string.Empty;
        }
        public static string GetMenberIdByUserId(string userId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(
                    "SELECT TOP 1 BasketUserID FROM BasketUsers WHERE u_user_id = '" + userId + "'",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketUserID"]);
            }
            return string.Empty;
        }
        public static string GetCartIdByUserId(string userId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(
                    "SELECT TOP 1 BasketSummaryID FROM BasketSummary WHERE BasketOwnerID = '" + userId + "' and BasketStateID = 1",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketSummaryID"]);
            }
            return string.Empty;
        }
        public static string GetLineItemIDAndOwnerIdOfGrid(out string userId)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd =
                new SqlCommand(
                    @"select BLI.BasketLineItemId , BS.BasketOwnerID 
                        from BasketGridLines BGL, BasketGridHeaders BGH, BasketLineItems BLI, BasketOrderForm BOF, BasketSummary BS 
                        where BGL.BasketGridHeaderID=BGH.BasketGridHeaderID 
                        and BGH.BasketLineItemId = BLI.BasketLineItemId 
                        and BLI.BasketOrderFormId = BOF.BasketOrderFormId 
                        and BOF.BasketSummaryID = BS.BasketSummaryID",
                    _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                userId = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketOwnerID"]);
                return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["BasketLineItemId"]);
            }
            userId = string.Empty;
            return string.Empty;
        }
        public static string GetFolderIdByCartId(string cartID)
        {
            if (_conn == null)
            {
                CreateConnectionString();
            }
            SqlCommand cmd = new SqlCommand(@"SELECT TOP 1 [UserFolderID]
  FROM [Orders].[dbo].[BasketUserFolders]
  WHERE BasketSummaryID = '" + cartID + "'", _conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            
            _conn.Open();
            try
            {
                da.Fill(ds);
            }

            finally
            {
                _conn.Close();
            }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
               return DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["UserFolderID"]);
               
            }
            
            return string.Empty;
        }
    }
}
