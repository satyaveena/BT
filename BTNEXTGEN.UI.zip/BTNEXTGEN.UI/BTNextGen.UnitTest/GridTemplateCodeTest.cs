﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextgen.Grid;
using Sharepoint.UnitTesting;

namespace BTNextGen.UnitTest
{
    public class GridTemplateCodeTest:SpUnitTesting
    {
        private const int DefaultSopGridFieldId = 1;

        private CartGridContext _context = null;
        private string _organizationId;
        private string _userId;

        public override void InitializeTestContext()
        {
            _context = CartGridContext.Current;
            _organizationId = "{a186eafc-eeab-48f4-8daf-7639668500d2}";
            _userId = "{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}";
            _context.Impersonate(_organizationId, _userId);
            //_context.Impersonate("u_org_id", Guid.NewGuid().ToString());
        }

        public override void FinalizeTestContext()
        {
            _context.UndoImpersonate();
        }
        [SpUnitTestMethod(Description = "Test Get Grid Templates of an organization")]
        public void TestGetGridTemplate()
        {
            var gridManager = _context.GridManager;
            var templateList = gridManager.GetGridTemplates();
            if (templateList == null)
            {
                TestFail("The return Grid Template List cannot be null");
            }
            
        }
        //[SpUnitTestMethod(Description = "Test Create/Delete Grid Templates of an organization")]
        //public void TestCreateDeleteGridTemplate()
        //{
        //    var gridManager = _context.GridManager;
            
        //    var gridFields = gridManager.GetGridFields();
        //    var gridField = new GridField { Name = "GiangGridField1", Sequence = 0 };

        //    gridField.SOPGridFieldId = DefaultSopGridFieldId;
        //    //create grid code
        //    GridCode code = new GridCode { Code = "TestCode1", ActiveIndicator = true, EffectiveDate = DateTime.Today, ExpirationDate = DateTime.Today.AddDays(100), IsExpired = false, Literal = "GridCode1" };
        //    gridField.GridCodes.Add(code);
        //    //Test create
        //    gridFields.Add(gridField);
        //    gridFields.Save();
            
        //    GridTemplate template = new GridTemplate
        //                                {
        //                                    OwnerUserId = _userId,
        //                                    Description = "Test Create GridTemplate",
        //                                    EnableIndicator = true,
        //                                    Name = "TestGridTempate"
        //                                };
        //    //GridTemplateLine line = new GridTemplateLine();
        //    GridTemplateList list = new GridTemplateList();
        //    //line.GridFieldCodeInTemplates.Add(new GridFieldCodeInTemplate
        //    //                                      {GridCodeId = code.GridCodeId, GridFieldId = gridField.GridFieldId});
        //    //template.GridTemplateLines.Add(line);
        //    ////template.GridTemplateLines.Firs
        //    //template.Save();
        //    list.Add(template);
        //    list.Save();
        //    var templateList = gridManager.GetGridTemplatesByOwnerUser("{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}");
        //    if(templateList == null)
        //        TestFail("Fail to create, then retrieve grid templates");
        //    //
        //    //Clean up

        //    //template.GridTemplateLines.Remove(line);
        //    //template.GridTemplateLines.Save();
        //    template.Save();
        //    code.MarkRemove();
        //    code.Save();
        //    list.Remove(template);
        //    list.Save();
        //    gridField.GridCodes.Remove(code);
        //    gridFields.Remove(gridField);
        //    gridFields.Save();
        //}
        [SpUnitTestMethod(Description = "Test Create/Get/Delete User Grid Templates of an organization")]
        public void TestCreateDeleteUserGridTemplate()
        {
            var gridManager = _context.GridManager;
            var templateList = gridManager.GetGridTemplatesByAuthorizedUser("{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}");
            var template = templateList.FirstOrDefault();
            UserGridTemplate userTemplate = new UserGridTemplate
                                                {
                                                    GridTemplateId = template.GridTemplateId,
                                                    Sequence = 3,
                                                    RowExpensionRight = "All",
                                                    UserId = _userId
                                                };
            UserGridTemplateList userGridTemplateList = new UserGridTemplateList();
            userGridTemplateList.Add(userTemplate);
            userGridTemplateList.Save();
            var userTemplate1 = template.UserGridTemplates;
            if(userTemplate1 == null)
                TestFail("Fail to create, then retrieve grid templates");
            userGridTemplateList.Remove(userTemplate);
            userGridTemplateList.Save();
        }
        //[SpUnitTestMethod(Description = "Test Create/Get/Delete Grid Templates Line of an organization")]
        //public void TestCreateDeleteTemplateLine()
        //{
        //    var gridManager = _context.GridManager;
        //    var templateList = gridManager.GetGridTemplatesByAuthorizedUser("{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}");
        //    GridTemplate template = new GridTemplate
        //    {
        //        OwnerUserId = _userId,
        //        Description = "Test Create GridTemplate",
        //        EnableIndicator = true,
        //        Name = "TestGridTempate3"
        //    };
        //    var gridFields = gridManager.GetGridFields();//gridManager.GetGridFieldsByAuthorizedUser("{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}");
        
        //    GridTemplateLine line = new GridTemplateLine {EnableIndicator = true, Quantity = 2};
        //    int i = 1;
        //    GridCodeList gridCodeList = new GridCodeList();
        //    foreach (GridField gridField in gridFields)
        //    {
        //        //create grid code
        //        GridCode code = new GridCode { Code = "GiangTestCode" + i.ToString(), ActiveIndicator = true, EffectiveDate = DateTime.Today, ExpirationDate = DateTime.Today.AddDays(100), IsExpired = false, Literal = "GiangGridCode1" };
        //        gridField.GridCodes.Add(code);
        //        gridField.Save();
        //        line.GridFieldCodeInTemplates.Add(new GridFieldCodeInTemplate { GridFieldId = gridField.GridFieldId, GridCodeId = code.GridCodeId });
        //        gridCodeList.Add(code);
        //        i++;
        //    }
        //    template.GridTemplateLines.Add(line);
        //    template.Save();
        //    var gridTemplate = gridManager.GetGridTemplateById(template.GridTemplateId);
        //    if (gridTemplate.GridTemplateLines != null && gridTemplate.GridTemplateLines.Count <= 0)
        //    {
        //        TestFail("Fail to create then retrieve grid template line");
        //    }
            
        //    //Clean up
        //    foreach (GridCode gridCode in gridCodeList)
        //    {
        //        gridCode.MarkRemove();
        //    }
        //    gridCodeList.Save();
        //    foreach (GridFieldCodeInTemplate gridFieldCode in line.GridFieldCodeInTemplates)
        //    {
        //        gridFieldCode.MarkRemove();
        //    }
            
        //    line.MarkRemove();
        //    template.GridTemplateLines.Remove(line);
        //    template.MarkRemove();
        //    template.Save();
        //}
        [SpUnitTestMethod(Description = "Test Create/Get/Delete Grid Templates Line of an organization")]
        public void TestGetTemplateLine()
        {
            _context.Impersonate("{1787d06a-1149-47a9-b4c1-6bb4ebe3740b}", "{165e31f5-484b-4153-b652-1f3de306c46e}");
            var gridManager = _context.GridManager;
            var templateLines = gridManager.GetGridTemplateById("{1307c82b-b4e4-4832-bd71-79fcbbbb3f7f}").GridTemplateLines;

        }
    }
}
