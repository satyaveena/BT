﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common;
using Sharepoint.UnitTesting;

namespace BTNextGen.UnitTest
{
    [SpUnitTestClass(Description = "Example Test")]
    public class ExampleTest : SpUnitTesting
    {        
       
    }
}
