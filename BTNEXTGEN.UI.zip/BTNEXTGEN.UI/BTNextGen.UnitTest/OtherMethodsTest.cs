﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.CartFramework;
using BTNextgen.Grid;
using Sharepoint.UnitTesting;

namespace BTNextGen.UnitTest
{
    public class OtherMethodsTest : SpUnitTesting
    {
        private const string DefaultSopGridFieldId = "{0022BF54-847B-4EF4-AAC0-621F5812SOP1}";

        private CartGridContext _context = null;
        private string _organizationId;
        private string _userId;

        public override void InitializeTestContext()
        {
            _context = CartGridContext.Current;
            _organizationId = "{a186eafc-eeab-48f4-8daf-7639668500d2}";//Guid.NewGuid().ToString();
            _userId = "{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}";//Guid.NewGuid().ToString();
            _context.Impersonate(_organizationId,_userId);
            //_context.Impersonate(Guid.NewGuid().ToString(), Guid.NewGuid().ToString());
        }

        public override void FinalizeTestContext()
        {
            _context.UndoImpersonate();
        }
        [SpUnitTestMethod(Description = "Test SOP Grid Field List of an organization")]
        public void TestGetSOPGridFieldList()
        {
            var gridManager = _context.GridManager;
            var sopFieldList = gridManager.GetAvailableSOPGridFieldList();
            if (sopFieldList == null)
            {
                TestFail("The return SOP Grid Field List cannot be null");
            }

        }
        //[SpUnitTestMethod(Description = "Test Get Grid Field of an organization")]
        //public void TestGetGridFieldList()
        //{
        //    var gridManager = _context.GridManager;
        //    var fieldList = gridManager.GetGridFields();
        //    if (fieldList == null)
        //    {
        //        TestFail("The return SOP Grid Field List cannot be null");
        //    }
        //    var fieldList1 = gridManager.GetGridFieldsByAuthorizedUser(_userId);
        //}
        [SpUnitTestMethod(Description = "Test append not to all titles")]
        public void TestAppendNoteToAllTitles()
        {
            var manager = _context.CartGridManager;
            var cartID = "{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}";
            manager.ModifyNoteToAllTitles(cartID, "Test append note to all Titles", "Append");
            var cartManager = new CartManager(_userId, _organizationId, true);
            int totalCarts = 0;
            //var result = cartManager.GetCartsBySearch(string.Empty, "Test append note to all Titles", 1, 9, 0,
            //                                          string.Empty, out totalCarts);
            //if (totalCarts == 0 || result == null)
            //{
            //    TestFail("Can not append text and then search by notes");
            //}
        }

        [SpUnitTestMethod(Description = "Test get line item by search")]
        public void TestGetLIneItemBySearch()
        {
            var cartManger = new CartManager("{c89d5bc9-aaf2-4648-85b2-79ff5076db56}", _organizationId, true);
            var cart = cartManger.GetCartById("{26ab70ae-8c75-491a-b398-a0831c0ae382}");
            int total = 0;
            //var result = cart.GetCartLines(string.Empty, "mai", 1, 9, 1, out total, 0, true);
            //if (total <= 0 || result == null)
            //{
            //    TestFail("Test search LineItem by Notes failed");
            //}
        }
        [SpUnitTestMethod(Description = "Test Validate Grid In Cart For Library System Account")]
        public void TestValidateGridInCartForLibrarySystemAccount()
        {
            var cartGridManger = _context.CartGridManager;
            var cartId = DBAccessHelper.GetCartIdByUserId(_userId);
            var result = cartGridManger.ValidateGridInCartForLibrarySystemAccount(cartId, string.Empty);
        }
    }
}
