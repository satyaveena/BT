﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextgen.Grid;
using Sharepoint.UnitTesting;

namespace BTNextGen.UnitTest
{
    [SpUnitTestClass(Description = "Test GridField and GridCode")]
    public class GridFieldGridCodeTest : SpUnitTesting
    {
        private const int DefaultSopGridFieldId = 1;

        private CartGridContext _context = null;
        private string _organizationId;
        private string _userId;

        public override void InitializeTestContext()
        {
            _context = CartGridContext.Current;
            _organizationId = Guid.NewGuid().ToString();
            _userId = Guid.NewGuid().ToString();
            _context.Impersonate(_organizationId, _userId);
            //_context.Impersonate("u_org_id", Guid.NewGuid().ToString());
        }

        public override void FinalizeTestContext()
        {
            _context.UndoImpersonate(); 
        }

        //[SpUnitTestMethod(Description = "Test Get Grid Fields of an organization")]
        //public void TestGetGridFields()
        //{
        //    var gridManager = _context.GridManager;
        //    var gridFields = gridManager.GetGridFields();
        //    if(gridFields==null)
        //        TestFail("The return GridFields cannot be null");
        //    //
                       
        //}

        //[SpUnitTestMethod(Description = "Test Create GridField for an organization")]
        //public void TestCreateDeleteGridField()
        //{
        //    var gridManager = _context.GridManager;
        //    var gridFields = gridManager.GetGridFields();
        //    var gridField = new GridField {Name = "GiangGridField1", Sequence = 0, ActiveIndicator = true, UserViewAllGridCodesIndicator =  true};
        //    //gridField.SOPGridFieldId = DefaultSopGridFieldId;
        //    //Test create
        //    gridFields.Add(gridField);
        //    gridFields.Save();
        //    //
        //    var gridField1 = gridManager.GetGridFields().GetObjectById(gridField.GridFieldId);
        //    if(gridField1 == null)
        //        TestFail("Fail to create, then retrieve gridfields for an organization");
        //    //
        //    //Clean up
        //    gridFields.Remove(gridField);
        //    gridFields.Save();                        
        //}

        //[SpUnitTestMethod(Description = "Test Update a GridField information")]
        //public void TestUpdateGridField()
        //{
        //    var gridManager = _context.GridManager;
        //    var gridFields = gridManager.GetGridFields();
        //    var gridField = new GridField { Name = "GiangGridField2", Sequence = 0, ActiveIndicator = true, UserViewAllGridCodesIndicator = true };
        //    //gridField.SOPGridFieldId = DefaultSopGridFieldId;
        //    gridFields.Add(gridField);
        //    gridFields.Save();
        //    //
        //    var gridFields1 = gridManager.GetGridFields();
        //    var gridfield1 = gridFields1.FirstOrDefault();
        //    gridfield1.Name = "test";
        //    gridFields1.Save();
        //    //
        //    var gridFields2 = gridManager.GetGridFields();
        //    var gridfield2 = gridFields2.GetObjectById(gridField.GridFieldId);
        //    if (gridfield2.Name!="test")
        //        TestFail("Fail to update GridField information");
        //    //Test delete
        //    gridFields2.Remove(gridfield2);
        //    gridFields2.Save();           
        //}
        //[SpUnitTestMethod(Description = "Test Get Grid Fields of an organization")]
        //public void TestGetGridCodes()
        //{
        //    _context.Impersonate("{a186eafc-eeab-48f4-8daf-7639668500d2}","{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}");
        //    var gridManager = _context.GridManager;
        //    var gridFields = gridManager.GetGridFields();
        //    var gridField = gridFields.GetObjectById("{0022BF54-847B-4EF4-AAC0-621F58129916}");
        //    var gridCodes1 = gridField.GridCodes;
        //    var gridCodes2 = gridField.AllGridCodes;
        //    if (gridCodes1.Count == gridCodes2.Count)
        //    {
        //        TestFail("Not refine grid code right");
        //    }
        //    //

        //}

        //[SpUnitTestMethod(Description = "Test Create GridCode for an organization")]
        //public void TestCreateDeleteGridCode()
        //{
        //    var gridManager = _context.GridManager;
        //    var gridFields = gridManager.GetGridFields();
        //    var gridField = new GridField { Name = "GiangGridField3", Sequence = 0, ActiveIndicator = true};
        //    //gridField.SOPGridFieldId = DefaultSopGridFieldId;
        //    //create grid code
        //    GridCode code = new GridCode{Code = "TestCode1",ActiveIndicator = true, IsExpired = false, Literal = "GridCode1"};
        //    gridField.GridCodes.Add(code);
        //    //Test create
        //    gridFields.Add(gridField);
        //    gridFields.Save();
        //    //
        //    GridField first = gridManager.GetGridFields().First();
        //    var gridCode1 = first.GridCodes;
        //    if (gridCode1.Count == 0)
        //        TestFail("Fail to create, then retrieve gridcodes for an gridfield");
            
        //    //
        //    //Clean up
        //    code.MarkRemove();
        //    code.Save();
        //    gridField.GridCodes.Remove(code);
        //    gridFields.Remove(gridField);
        //    gridFields.Save();
            
        //}

       // [SpUnitTestMethod(Description = "Test Create UserGridField for an organization")]
       // public void TestCreateDeleteUserGridFields()
       // {
       //     var gridManager = _context.GridManager;
       //     var gridFields = gridManager.GetGridFields();
       //     var gridField = new GridField { Name = "GiangGridField4", Sequence = 0 , ActiveIndicator = true};

         
       //     gridField.SOPGridFieldId = DefaultSopGridFieldId;

       //     //create grid code
       //     GridCode code = new GridCode { Code = "TestCode1", ActiveIndicator = true, EffectiveDate = DateTime.Today, ExpirationDate = DateTime.Today.AddDays(100), IsExpired = false, Literal = "GridCode1" };
       //     gridField.GridCodes.Add(code);
       //     gridFields.Add(gridField);
       //     gridFields.Save();
       //     //create user grid field
       //     UserGridField userGridField = new UserGridField{DefaultGridCodeId = code.GridCodeId, DisplayType = "Code", UserId = Guid.NewGuid().ToString()};
       //     gridField.UserGridFields.Add(userGridField);
       //     //Test create
       //     //gridFields.Add(gridField);
       //     gridField.Save();
       //     //
       //     var userGridFields = gridManager.GetGridFields().First().UserGridFields;
       //     if (userGridFields.Count == 0)
       //         TestFail("Fail to create, then retrieve user grid fields for an gridfield");

       //     //
       //     //Clean up
       //     gridField.UserGridFields.Remove(userGridField);
       //     gridField.Save();

       //     gridField.GridCodes.Remove(code);
       //     gridField.Save();
            
       //     gridFields.Remove(gridField);
       //     gridFields.Save();
       //}
       // [SpUnitTestMethod(Description = "Test Create UserGridCode for an organization")]
       // public void TestCreateDeleteUserGridCodes()
        //{
        //    var gridManager = _context.GridManager;
        //    var gridFields = gridManager.GetGridFields();
        //    var gridField = new GridField { Name = "GiangGridField5", Sequence = 0 ,ActiveIndicator = true};

        //    gridField.SOPGridFieldId = DefaultSopGridFieldId;

        //    //create grid code
        //    GridCode code = new GridCode { Code = "TestCode1", ActiveIndicator = true, EffectiveDate = DateTime.Today, ExpirationDate = DateTime.Today.AddDays(100), IsExpired = false, Literal = "GridCode1" };
        //    gridField.GridCodes.Add(code);
        //    gridFields.Add(gridField);
        //    gridFields.Save();
        //    UserGridCode userCode = new UserGridCode{GridCodeId = code.GridCodeId, UserId = _userId};
        //    code.UserGridCodes.Add(userCode);
        //    code.Save();

        //    GridCode gridCode = gridManager.GetGridFields().First().GridCodes.First();
        //    var userGridCodes = gridCode.UserGridCodes;
        //    if (userGridCodes.Count == 0)
        //        TestFail("Fail to create, then retrieve user grid codes for an gridfield");

        //    //
        //    //Clean up
        //    code.UserGridCodes.Remove(userCode);
        //    code.Save();
        //    gridField.GridCodes.Remove(code);
        //    gridField.Save();
            
        //    gridFields.Remove(gridField);
        //    gridFields.Save();
        //}
        //[SpUnitTestMethod(Description = "Test Create UserGridCode for an organization")]
        //public void TestDuplicateGridFieldGridCode()
        //{
        //    var gridFields = new GridFieldList();
        //    gridFields.Add(new GridField
        //                       {
        //                           Name = "GridField1",
        //                           FreeTextIndicator = true,
        //                           FreeTextCharacterLimit = 100
        //                       });
        //    gridFields.Add(new GridField
        //    {
        //        Name = "GridField2",
        //        FreeTextIndicator = true,
        //        FreeTextCharacterLimit = 100
        //    });
        //    gridFields.Add(new GridField
        //    {
        //        Name = "GridFIELD1",
        //        FreeTextIndicator = true,
        //        FreeTextCharacterLimit = 100
        //    });
        //    gridFields.Last().GridCodes.Add(new GridCode{ Code = "ABC", Literal = "test test"});
        //    gridFields.Last().GridCodes.Add(new GridCode { Code = "AAA", Literal = "test test" });
        //    gridFields.First().GridCodes.Add(new GridCode { Code = "ABC", Literal = "test test" });
        //    gridFields.First().GridCodes.Add(new GridCode { Code = "abc", Literal = "test test" });

        //    if(!gridFields.CheckDuplicateName())
        //        TestFail("Grid Field Name check duplicate running wrong");
        //    if(gridFields.Last().GridCodes.CheckDuplicateName())
        //        TestFail("Grid Code Name check duplicate running wrong");
        //    if (!gridFields.First().GridCodes.CheckDuplicateName())
        //        TestFail("Grid Code Name check duplicate running wrong");
        //}
    }
}
