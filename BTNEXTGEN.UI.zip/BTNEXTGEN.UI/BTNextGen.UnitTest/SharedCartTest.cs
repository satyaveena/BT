﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.CartFramework;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart.Shared;
using Sharepoint.UnitTesting;

namespace BTNextGen.UnitTest
{
    public class SharedCartTest:SpUnitTesting
    {
        private const string DefaultSopGridFieldId = "{0022BF54-847B-4EF4-AAC0-621F5812SOP1}";

        private CartGridContext _context = null;
        private string _organizationId;
        private string _userId;

        public override void InitializeTestContext()
        {
            _context = CartGridContext.Current;
            //DBAccessHelper.GetUserIdAndOrgIdPair(out _userId, out _organizationId);
            _userId = "{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}";
            _organizationId = "{a186eafc-eeab-48f4-8daf-7639668500d2}";
            _context.Impersonate(_organizationId, _userId);
        }
        public override void FinalizeTestContext()
        {
            _context.UndoImpersonate();
        }

        [SpUnitTestMethod(Description = "Test Get Shared Cart Summary")]
        public void TestSharedCartSummaryAndDetail()
        {
            var cartManager = _context.CartGridManager;
            var userId = "{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}";
            string orgid = DBAccessHelper.GetOrgByUserId(userId);
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            var cartSummary = cartManager.GetSharedCartSummary("{063AC6F2-AC6E-4476-87BB-1B9845C27FE4}", false, "Total Quantity", true);
            if (cartSummary == null)
                TestFail("The return Shared Cart cannot be null");
            var cartSummaryDetail = cartManager.GetSharedCartSummaryItemDetail("{063AC6F2-AC6E-4476-87BB-1B9845C27FE4}", cartSummary.Items.First().UserId,
                                                                               "Title", true);
            if(cartSummaryDetail == null)
                TestFail("The return SharedCartSummaryDetail cannot be null");
        }

        [SpUnitTestMethod(Description = "Test Check Shared Cart Profile")]
        public void TestHasSharedProfile()
        {
            var cartManager = _context.CartGridManager;
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            var userid = string.Empty;
            var cartSummary = cartManager.HasSharedCartProfile("{3ede8fc8-3f58-4834-9bf8-8fd4b100bc42}", out userid);
            if (!cartSummary || string.IsNullOrEmpty(userid))
                TestFail("Can not check shared cart profile");
            var group = cartManager.GetCartUserGroup("{587dc472-87f1-4fd7-aaba-6ad5b237d9b0}");
            if(group==null||group.Members.Count==0)
                TestFail("Can not get group member");
        }

        [SpUnitTestMethod(Description = "Test Get Basket User Group")]
        public void TestCreateGetDeleteBasketUserGroup()
        {
            var cartManager = _context.CartGridManager;
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            CartUserGroupList groupList = new CartUserGroupList();
            CartUserGroup userGroup = new CartUserGroup();
            userGroup.Name = "Giang Test Create UserGroup";
            groupList.Add(userGroup);
            groupList.Save();
            var cartUsergroup = cartManager.GetCartUserGroups();
            if (cartUsergroup == null)
                TestFail("The return user group cannot be null");
            //_context.UndoImpersonate();
            //Clean up
            groupList.Remove(userGroup);
            groupList.Save();
        }

        [SpUnitTestMethod(Description = "Test Get Basket User Group Member")]
        public void TestCreateGetDeleteBasketUserGroupMember()
        {
            var cartManager = _context.CartGridManager;
            var userId = DBAccessHelper.GetValidUserIdFromOrgID(_organizationId);
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            CartUserGroupList groupList = new CartUserGroupList();
            CartUserGroup userGroup = new CartUserGroup();
            userGroup.Name = "Giang Test Create UserGroup";
            CartUserGroupMemberList memberList = new CartUserGroupMemberList();
            memberList.Add(new CartUserGroupMember { HasAcquisition = true, HasContribution = true, HasRequisition = true, HasReview = true, IsOwner = true, UserId = userId });
            memberList.Add(new CartUserGroupMember { HasAcquisition = true, HasContribution = false, HasRequisition = true, HasReview = true, IsOwner = false, UserId = "{56429f1f-ae76-4b8e-abc3-ce6b9f73b886}" });
            userGroup.Members.AddRange(memberList);
            groupList.Add(userGroup);
            groupList.Save();
            var cartUsergroup = cartManager.GetCartUserGroup(userGroup.CartUserGroupId);
            var member = cartUsergroup.Members;
            if (member == null || member.Count==0)
                TestFail("The return user group cannot be null");
            //_context.UndoImpersonate();
            //Clean up
            groupList.Remove(userGroup);
            groupList.Save();
        }

        [SpUnitTestMethod(Description = "Test Get/Create/Delete Basket Workflow")]
        public void TestCreateGetDeleteBasketWorkflowAndStage()
        {
            var cartManager = _context.CartGridManager;
            //var cartWorkflow = new SharedCartWorkflow();
            //string cartID = DBAccessHelper.GetCartIdWithLineItems();
            //cartWorkflow.SharedCartWorkflowId = cartID;
            //cartWorkflow.TimeZone = "GMT (+7)";
            //cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage{StageAlias = "Contribution", Stage = WorkflowStage.Contribution, Status = WorkflowStatus.InProgress, EndDateTime = DateTime.Today.AddDays(20)});
            //cartWorkflow.Save();

            var cartProfile = cartManager.GetSharedCartProfile("{050cc9fc-1aac-4908-93e4-5ee2db3b3f6b}");
            var workflows = cartProfile.Workflow;
            var stages = workflows.WorkflowStages;
            var current = stages.Last();
            var next = stages.NextStage(current);
            var previous = stages.PreviousStage(current);

            //var testStage = stages;
            //if(workflows == null)
            //{
            //    TestFail("Can not create then get workflow of a cart");
            //}

            ////clean up
            //cartWorkflow.MarkRemove();
            //cartWorkflow.Save();
        }

        [SpUnitTestMethod(Description = "Test Get/Create/Delete Basket User Workflow")]
        public void TestCreateGetDeleteBasketUserWorkflowAndStage()
        {
            var cartManager = _context.CartGridManager;
            var cartWorkflow = new SharedCartWorkflow();
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            cartWorkflow.SharedCartWorkflowId = cartID;
            cartWorkflow.TimeZone = "GMT (+7)";
            cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage{StageAlias = "Contribution", Stage = WorkflowStage.Contribution, Status = WorkflowStatus.InProgress, EndDateTime = DateTime.Today.AddMonths(2)});
            cartWorkflow.Save();

            var cartProfile = cartManager.GetSharedCartProfile(cartID);
            
            var memberWorkflow = new SharedCartMember();
            var sharedCartGroup = cartManager.GetCartUserGroups().FirstOrDefault();
            var userId = DBAccessHelper.GetUserIdWithNoEmptyCart();
            var sharedCartMemberId = DBAccessHelper.GetMenberIdByUserId(userId);
            memberWorkflow.HasOwner = true;
            memberWorkflow.HasContribution = true;
            memberWorkflow.HasAcquisition = true;
            memberWorkflow.HasRequisition = true;
            memberWorkflow.SharedCartProfile = cartProfile;
            //memberWorkflow.SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage{IsCompleted = false, Stage = WorkflowStage.Contribution, StageFinished = false, SharedCartMemberId =  sharedCartMemberId});
            memberWorkflow.UserId = userId;
            memberWorkflow.CartId = cartID;
            memberWorkflow.Save();

            //get to check
            var userWorkflows = cartManager.GetSharedCartMemberWorkflowStages(cartID, cartProfile.SharedCartMembers.First().SharedCartMemberId);
            if (userWorkflows == null || userWorkflows.Count <= 0)
            {
                TestFail("Can not create than get user workflow/stage");
            }
            //clean up
            cartWorkflow.MarkRemove();
            cartWorkflow.Save();
            memberWorkflow.MarkRemove();
            memberWorkflow.Save();
            
        }
        [SpUnitTestMethod(Description = "Test Save ShareCartProfile members")]
        public void TestSaveSharedCartProfile()
        {
            var cartManager = _context.CartGridManager;
            var userID = DBAccessHelper.GetValidUserIdFromOrgID(_organizationId);
            var sharedCartProfile = cartManager.GetSharedCartProfile("{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}");
            //var sharecartmember1 = new SharedCartMember
            //                          {
            //                              CartId = "{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}",
            //                              SharedCartProfile = sharedCartProfile,
            //                              HasOwner = true,
            //                              UserId = userID
            //                          };
            ////sharecartmember.SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage { IsCompleted = false, Stage = WorkflowStage.Contribution, StageFinished = false });
            //var defaultMember = sharedCartProfile.SharedCartMembers.FirstOrDefault();
            //var stages = defaultMember.SharedCartMemberWorkflowStages;
            //sharedCartProfile.SharedCartMembers.Add(sharecartmember);

            var cartWorkflow = new SharedCartWorkflow();
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            cartWorkflow.SharedCartWorkflowId = "{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}";
            cartWorkflow.TimeZone = "GMT (+7)";
            //cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Contribution", Stage = WorkflowStage.Contribution, Status = WorkflowStatus.Completed, EndDateTime = DateTime.Today.AddDays(-2)});
            //cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Review", Stage = WorkflowStage.Review, Status = WorkflowStatus.NotStarted, EndDateTime = DateTime.Today.AddDays(10) });
            //cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Requisition", Stage = WorkflowStage.Requisition, Status = WorkflowStatus.NotStarted, EndDateTime = DateTime.Today.AddDays(10) });
            //cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Acquisition", Stage = WorkflowStage.Acquisition, Status = WorkflowStatus.NotStarted });
            sharedCartProfile.Workflow = cartWorkflow;
            var tet1 = sharedCartProfile.Workflow.WorkflowStages.First(i => i.Stage == WorkflowStage.Acquisition);
            sharedCartProfile.Workflow.WorkflowStages.First(i => i.Stage == WorkflowStage.Acquisition).EndDateTime = tet1.EndDateTime;
            sharedCartProfile.SharedCartMembers.First().HasOwner = true;
            sharedCartProfile.Save();
            var testprofile = cartManager.GetSharedCartProfile("{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}");
            var testmember = testprofile.SharedCartMembers;
            if(testmember == null || testmember.Count == 0)
                TestFail("can not get shared cart member");
            var testworkflow = testprofile.Workflow;
            if(testworkflow == null)
                TestFail("can not get workflow");
            //sharedCartProfile.SharedCartMembers.Remove(sharedCartProfile.SharedCartMembers.FirstOrDefault());
            //sharedCartProfile.Workflow.MarkRemove();
            sharedCartProfile.Save();
        }
        [SpUnitTestMethod(Description = "Test Save Transfer Basket members")]
        public void TestTransferBasketToUser()
        {
            var manager = _context.CartGridManager;
            var cartContext = new CartManager(_userId, _organizationId, true);
            var cartId = DBAccessHelper.GetCartIdByUserId(_userId);
            var user2 = DBAccessHelper.GetValidUserIdFromOrgID(_organizationId);
            manager.TransferCartToUsers(cartId, new List<string>{user2}, true);
            var cart = cartContext.GetCartById("{3ede8fc8-3f58-4834-9bf8-8fd4b100bc42}");
            if(cart.UserId != "{fba3f66e-6199-4dd0-9567-c691695e205f}")
                TestFail("The userid is " + cart.UserId);
        }

        [SpUnitTestMethod(Description = "Test Save Transfer Basket members")]
        public void TestSharedCartWorkflow()
        {
            var cartManager = _context.CartGridManager;
            var userID = DBAccessHelper.GetValidUserIdFromOrgID(_organizationId);
            var sharedCartProfile = cartManager.GetSharedCartProfile("{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}");
            //var sharecartmember1 = new SharedCartMember
            //                          {
            //                              CartId = "{10B00FA3-3D7D-4C19-991D-BBCCC43F53E8}",
            //                              SharedCartProfile = sharedCartProfile,
            //                              HasOwner = true,
            //                              UserId = userID
            //                          };
            //sharecartmember.SharedCartMemberWorkflowStages.Add(new SharedCartMemberWorkflowStage { IsCompleted = false, Stage = WorkflowStage.Contribution, StageFinished = false });
            //var defaultMember = sharedCartProfile.SharedCartMembers.FirstOrDefault();
            //var stages = defaultMember.SharedCartMemberWorkflowStages;
            //sharedCartProfile.SharedCartMembers.Add(sharecartmember);

            var cartWorkflow =sharedCartProfile.Workflow;
            string cartID = DBAccessHelper.GetCartIdWithLineItems();
            cartWorkflow.SharedCartWorkflowId = cartID;
            cartWorkflow.TimeZone = "GMT (+7)";
            cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Contribution", Stage = WorkflowStage.Contribution, Status = WorkflowStatus.NotStarted});
            cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Review", Stage = WorkflowStage.Review, Status = WorkflowStatus.NotStarted });
            cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Requisition", Stage = WorkflowStage.Requisition, Status = WorkflowStatus.NotStarted, EndDateTime = DateTime.Today.AddDays(10) });
            cartWorkflow.WorkflowStages.Add(new SharedCartWorkflowStage { StageAlias = "Acquisition", Stage = WorkflowStage.Acquisition, Status = WorkflowStatus.NotStarted });
            sharedCartProfile.Workflow = cartWorkflow;
            //var tet1 = sharedCartProfile.Workflow.WorkflowStages.First(i => i.Stage == WorkflowStage.Acquisition);
            //sharedCartProfile.Workflow.WorkflowStages.First(i => i.Stage == WorkflowStage.Acquisition).EndDateTime = tet1.EndDateTime;
            //sharedCartProfile.SharedCartMembers.First().HasOwner = true;
            sharedCartProfile.Save();
            var sharedCartMemberWorkflowStage =
                cartManager.GetSharedCartProfile(cartID).SharedCartMembers.First().SharedCartMemberWorkflowStages;
            if(sharedCartMemberWorkflowStage.Count < cartWorkflow.WorkflowStages.Count)
                TestFail("Can not add user workflowstge when add workflow stage");
            //Clean up
            sharedCartProfile.Workflow.MarkRemove();
            sharedCartProfile.Save();
        }
        [SpUnitTestMethod(Description = "Test Save Transfer Basket members")]
        public void TestBasketUserGroupAndMembers()
        {
            var cartGridManager = _context.CartGridManager;
            var group = new CartUserGroup();
            group.Name = "Test Group";
            var member = new CartUserGroupMember();
            member.IsOwner = true;
            member.HasAcquisition = true;
            member.HasRequisition = true;
            member.UserId = DBAccessHelper.GetUserIdWithNoEmptyCart();
            group.Members.Add(member);
            group.Save();

            var testGroup = cartGridManager.GetCartUserGroup(group.CartUserGroupId);
            var testMember = testGroup.Members;
            if(testGroup == null ||testMember.Count == 0)
                TestFail("Can not create and get group and member");
            group.MarkRemove();
            group.Save();
        }
    }
}
