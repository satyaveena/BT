﻿//-----------------------------------------------------------------------
// <copyright file="CommerceLoginPage.aspx.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>A Customized Login page for Sharepoint Forms Based Authentication.  </summary>
//-----------------------------------------------------------------------

using System;
using System.Web.UI;
using Sharepoint.UnitTesting;

namespace BTNextGen.UnitTest
{
    /// <summary>
    /// Sharepoint Unite Test Page for BTNextgen
    /// </summary>
    public partial class SharePointUnitTest : Page
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);             
        }

        protected void btnTest_Click(object sender, EventArgs e)
        {
            string filterClass = Request["className"];
            string filterMethod = Request["methodName"];
            const string unitTestAssemblyName = "BTNextGen.UnitTest, Version=1.0.0.0, Culture=neutral, PublicKeyToken=aae20afbbe14a27c";
            string testResult = SpUnitTestingEngine.ExecuteTesting(unitTestAssemblyName, filterClass, filterMethod);            
            LabelResult.Text = testResult;
        }    
    }
}

