﻿#Set-ExecutionPolicy Unrestricted
function Uninstall-Solution([string]$packageName)
{
    Write-Host "Upinstall solution $packageName ..."
    # ensure previous version of solution package solution package is already deployed
    $solution = Get-SPSolution | where-object {$_.Name -eq $packageName}
    if ($solution -ne $null) {
      if($solution.Deployed -eq $true){
        Uninstall-SPSolution -Identity $packageName –AllWebApplications -Confirm:$false
    	Write-Host "Successfully Uninstall solution $packageName"
      }
      else {
        Write-Host "Solution package $packageName cannot be Uninstalled because it is not deployed"
      }
    }
}
$NextGenURL  = "http://lcaoserver:5280"
$spAdminServiceName = "SPAdminV4"

$SolutionPackageName1  = "MicrosoftCommerceBTNextGenSiteSPServer2010.wsp"
$SolutionPackageName2  = "MicrosoftCommerceWebParts.wsp"
$SolutionPackageName3  = "BTNextGen.ContentManagement.wsp"

$SharePointPS = "Microsoft.SharePoint.Powershell"
$snapin = Get-PSSnapin | where-object {$_.Name -eq $SharePointPS}
if ($snapin -eq $null) {
  Add-PSSnapin $SharePointPS
}

Write-Host "Removing site collectoin $NextGenURL ..."

Remove-SPSite -Identity $NextGenURL -Confirm:$false



Uninstall-Solution $SolutionPackageName1
Uninstall-Solution $SolutionPackageName2
Uninstall-Solution $SolutionPackageName3

Write-Host "Stoping Service $spAdminServiceName ..."

Stop-Service -Name $spAdminServiceName

Write-Host "starting jobs ..."

Start-SPAdminJob -Verbose

Write-Host "Starting Service $spAdminServiceName ..."

Start-Service -Name $spAdminServiceName

Write-Host "Removing solution $SolutionPackageName1 ..."



Remove-SPSolution –Identity $SolutionPackageName1 -Confirm:$false
Write-Host "Removing solution $SolutionPackageName2 ..."

Remove-SPSolution –Identity $SolutionPackageName2 -Confirm:$false
Write-Host "Removing solution $SolutionPackageName3 ..."

Remove-SPSolution –Identity $SolutionPackageName3 -Confirm:$false

