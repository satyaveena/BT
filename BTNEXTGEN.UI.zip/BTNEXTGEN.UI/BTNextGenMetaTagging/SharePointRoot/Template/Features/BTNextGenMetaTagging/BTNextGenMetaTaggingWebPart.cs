using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace BTNextGenMetaTagging.UI.WebControls.WebParts
{
    [Guid("962c27f6-f532-403b-be35-0e20302f574f")]
    public class BTNextGenMetaTaggingWebPart : Microsoft.SharePoint.WebPartPages.WebPart
    {
        private bool _error = false;
        private string _metaTag = null;

        #region [ Custom Properties]
        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(true)]
        [System.ComponentModel.Category("WebTrends Tagging")]
        [WebDisplayName("MetaTag")]
        [WebDescription("Metatags ';' delimited")]
        public string MetaTag
        {
            get
            {
                if (_metaTag == null)
                {
                    _metaTag = ";";
                }
                return _metaTag;
            }
            set { _metaTag = value; }
        }

        #endregion

        #region [ Page Methods ]
        public BTNextGenMetaTaggingWebPart()
        {
            this.ExportMode = WebPartExportMode.All;
        }

        protected override void CreateChildControls()
        {
            if (!_error)
            {
                try
                {

                    base.CreateChildControls();
                    this.Controls.Add(new LiteralControl(this.MetaTag));
                }
                catch (Exception ex)
                {
                    HandleException(ex);
                }
            }
        }

        /// <summary>
        /// Ensures that the CreateChildControls() is called before events.
        /// Use CreateChildControls() to create your controls.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            if (!_error)
            {
                try
                {
                    base.OnLoad(e);
                    this.EnsureChildControls();

                    LoadMetaTags();
                    
                }
                catch (Exception ex)
                {
                    HandleException(ex);
                }
            }
        }

        private void LoadMetaTags()
        {
            string metaTags = MetaTag;

            string[] splitMeta = metaTags.Split(';');
            string[] content = null;
            for (int i = 0; i < splitMeta.Length; i++)
            {
                if (splitMeta[i].ToString() != string.Empty)
                {
                    content = splitMeta[i].Split(',');
                    HtmlMeta meta = new HtmlMeta();
                    meta.Name = content[0].ToString();
                    meta.Content = content[1].ToString();

                    this.Page.Master.FindControl("PlaceHolderAdditionalPageHead").Controls.Add(meta);         
                }
                
            }
        }

        /// <summary>
        /// Clear all child controls and add an error message for display.
        /// </summary>
        /// <param name="ex"></param>
        private void HandleException(Exception ex)
        {
            this._error = true;
            this.Controls.Clear();
            this.Controls.Add(new LiteralControl(ex.Message));
        }

        #endregion
    }
}
