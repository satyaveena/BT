﻿#Set-ExecutionPolicy RemoteSigned
# ensure previous version of solution package solution package is already deployed
#$solution = Get-SPSolution | where-object {$_.Name -eq $SolutionPackageName}
#if ($solution -ne $null) {
#  if($solution.Deployed -eq $true){
#    Update-SPSolution -Identity $SolutionPackageName -LiteralPath $SolutionPackagePath -Local -GACDeployment -Force
#	Write-Host "Successfully updated solution $SolutionPackageName"
#  }
#  else {
#    Write-Host "Solution package $SolutionPackageName cannot be updated because it is not deployed"
#  }
#}

function Update-Solution([string]$packagePath, [string]$packageName)
{
    Write-Host "Adding solution $packageName ..."
    # ensure previous version of solution package solution package is already deployed
    $solution = Get-SPSolution | where-object {$_.Name -eq $packageName}
    if ($solution -ne $null) {
      if($solution.Deployed -eq $true){
        Update-SPSolution -Identity $packageName -LiteralPath $packagePath -Local -GACDeployment -Force
    	Write-Host "Successfully updated solution $packageName"
      }
      else {
        Write-Host "Solution package $packageName cannot be updated because it is not deployed"
      }
    }
    else
    {
      # add new solution
      Add-SPSolution $packageName
      Install-SPSolution –Identity $packageName -WebApplication http://lcaoserver:5580/ –GACDeployment 
    }
}

$SolutionPackageName1  = "BTNextGenMetaTagging.wsp"

$SolutionPackagePath1 = $SolutionPackageName1

$SharePointPS = "Microsoft.SharePoint.Powershell"
$snapin = Get-PSSnapin | where-object {$_.Name -eq $SharePointPS}
if ($snapin -eq $null) {
  Add-PSSnapin $SharePointPS
}

Update-Solution $SolutionPackagePath1 $SolutionPackageName1
