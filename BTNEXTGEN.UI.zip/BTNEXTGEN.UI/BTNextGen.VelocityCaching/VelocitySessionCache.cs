﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace BTNextGen.VelocityCaching
{
    internal interface IVelocitySessionCache
    {

    }

    internal class VelocitySessionCache : IVelocityCache, IVelocitySessionCache
    {
        private static VelocitySessionCache _instance;

        public static VelocitySessionCache Instance
        {
            get { return _instance ?? (_instance = new VelocitySessionCache()); }
        }

        private VelocitySessionCache()
        {

        }

        /// <summary>
        /// Write Cache
        /// </summary>
        /// <param name="cacheKey">Cache key</param>
        /// <param name="value">Object to cache</param>        
        /// <param name="cacheDuration">Cache duration in minutes</param>
        public void Write(string cacheKey, object value, int cacheDuration)
        {
            if (HttpContext.Current != null && HttpContext.Current.Session != null)
            {
                var item = new VelocityCacheItem { CachedObject = value, ExpirationTime = DateTime.Now.AddMinutes(cacheDuration) };
                cacheKey = ConvertToProxyKeyName(cacheKey);
                HttpContext.Current.Session[cacheKey] = item;
            }
        }

        /// <summary>
        /// Read Cache by CacheKey
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        /// <returns></returns>
        public object Read(string cacheKey)
        {
            if (HttpContext.Current != null && HttpContext.Current.Session != null)
            {
                cacheKey = ConvertToProxyKeyName(cacheKey);
                var item = HttpContext.Current.Session[cacheKey] as VelocityCacheItem;
                if (item != null)
                {
                    if (!item.IsExpired())
                        return item.CachedObject;
                }
            }
            return null;
        }

        public void SetExpired(string cacheKey)
        {            
            if (HttpContext.Current != null && HttpContext.Current.Session != null)
            {
                cacheKey = ConvertToProxyKeyName(cacheKey);
                HttpContext.Current.Session[cacheKey] = null;
            }
        }

        private const string ProxiedUserId = "proxieduserid";
        public const string ProxyUserSuffix = "_PROXYUSER";

        private bool IsInProxySession()
        {
            //check param "proxieduserid" on querystring of a http request of a web page
            var proxiedUserId = HttpContext.Current.Request.QueryString[ProxiedUserId];
            if (!string.IsNullOrEmpty(proxiedUserId))
                return true;
            //check param "proxieduserid" in the referer url of a WCF Ajax service
            var referedUrl = HttpContext.Current.Request.Headers["Referer"];
            if (!string.IsNullOrEmpty(referedUrl) && referedUrl.Contains(ProxiedUserId))
                return true;

            return false;
        }

        private string ConvertToProxyKeyName(string key)
        {
            if (IsInProxySession())
            {
                return key + ProxyUserSuffix;
            }
            return key;
        }
    }
}
