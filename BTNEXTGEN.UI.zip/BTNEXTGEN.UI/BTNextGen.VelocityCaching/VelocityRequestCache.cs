﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace BTNextGen.VelocityCaching
{
    internal class VelocityRequestCache : IVelocityCache
    {
        private static VelocityRequestCache _instance;

        public static VelocityRequestCache Instance
        {
            get { return _instance ?? (_instance = new VelocityRequestCache()); }
        }

        private VelocityRequestCache()
        {
            
        }       

        public void Write(string cacheKey, object value, int cacheDuration)
        {
            HttpContext.Current.Items[cacheKey] = value;
        }

        /// <summary>
        /// Read Cache by CacheKey
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        /// <returns></returns>
        public object Read(string cacheKey)
        {
            return HttpContext.Current.Items[cacheKey];            
        }

        public void SetExpired(string cacheKey)
        {
            HttpContext.Current.Items[cacheKey] = null;
        }        
    }
}
