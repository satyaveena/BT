﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.VelocityCaching
{
    internal static class VelocityCacheFactory
    {
        public static IVelocityCache GetVelocityCache(VelocityCacheLevel cacheLevel)
        {
            switch (cacheLevel)
            {
                case VelocityCacheLevel.Request:
                    {
                        return VelocityRequestCache.Instance;
                    }
                case VelocityCacheLevel.Session:
                    {
                        return VelocitySessionCache.Instance;
                    }
                case VelocityCacheLevel.WebFrontEnd:
                    {
                        return VelocityWebFrontEndCache.Instance;
                    }
                case VelocityCacheLevel.Farm:
                    {
                        VelocityFarmCache.ClusterServerString = VelocityCacheManager.ClusterServerString;
                        VelocityFarmCache.CacheName = VelocityCacheManager.DistributedCacheName;
                        VelocityFarmCache.EnvRegion = VelocityCacheManager.DistributedCacheEnvRegion;

                        if (VelocityCacheManager.IsFarmCacheAvailable)
                        {
                            return VelocityFarmCache.Instance;
                        }
                        return VelocityWebFrontEndCache.Instance;
                    }
            }
            return null;
        }
    }
}
