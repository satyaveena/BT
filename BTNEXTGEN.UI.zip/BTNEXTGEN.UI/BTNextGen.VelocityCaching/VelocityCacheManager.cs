﻿using System;
using System.Collections.Generic;
using System.Threading;
using BTNextGen.CommonHelpers;
using BTNextGen.CommonHelpers.Constants;
using BTNextGen.CommonHelpers.Logging;

namespace BTNextGen.VelocityCaching
{
    public static class VelocityCacheManager
    {
        private const int DefaultCacheDuration = 60;//Minutes
        public const int DefaultCacheDurationForFacet = 600;//Minutes

        private static readonly ReaderWriterLockSlim Lock = new ReaderWriterLockSlim();

        private static readonly Dictionary<string, IVelocityCache> CacheLevelKey = new Dictionary<string, IVelocityCache>();
        public static string ClusterServerString { get; set; }
        public static string DistributedCacheName { get; set; }
        public static int? CacheDuration { get; set; } // in minutes

        private static string _envRegion;
        public static string DistributedCacheEnvRegion
        {
            get { return _envRegion; }
            set
            {
                if (string.IsNullOrEmpty(_envRegion))
                {
                    _envRegion = value;
                }
            }
        }

        private static bool? _isFarmCacheAvailable;
        public static bool IsFarmCacheAvailable
        {
            get
            {
                if (!_isFarmCacheAvailable.HasValue)
                {
                    _isFarmCacheAvailable = VelocityFarmCache.Instance.IsCacheAvailable;

                    if (_isFarmCacheAvailable.Value) return _isFarmCacheAvailable.Value;

                    var ex = new Exception("Farm Cache is not available.");
                    Logger.RaiseExceptionNoUls(ex, ExceptionCategory.DistributedCache);
                }

                return _isFarmCacheAvailable.Value;
            }
        }

        /// <summary>
        /// Write Cache
        /// </summary>
        /// <param name="cacheKey">Cache key</param>
        /// <param name="value">Object to cache</param>
        /// <param name="cacheLevel">Cache Level</param>
        /// <param name="cacheDuration">Cache duration in minutes</param>
        public static void Write(string cacheKey, object value, VelocityCacheLevel cacheLevel, int cacheDuration)
        {
            var velocityCache = VelocityCacheFactory.GetVelocityCache(cacheLevel);
            if (velocityCache!=null)
            {
                velocityCache.Write(cacheKey, value, cacheDuration);
                SetVelocityCache(cacheKey, velocityCache);
            }                   
        }

        /// <summary>
        /// Write Cache using default cache duration, 60 minutes.
        /// </summary>
        /// <param name="cacheKey">Cache key</param>
        /// <param name="value">Object to cache</param>
        /// <param name="cacheLevel">Cache Level</param>
        public static void Write(string cacheKey, object value, VelocityCacheLevel cacheLevel)
        {
            Write(cacheKey, value, cacheLevel, CacheDuration.HasValue ? CacheDuration.Value : DefaultCacheDuration);
        }

        /// <summary>
        /// Read Cache by CacheKey
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        /// <param name="cacheLevel"></param>
        /// <returns></returns>
        public static object Read(string cacheKey, VelocityCacheLevel? cacheLevel = null)
        {
            if (cacheLevel == VelocityCacheLevel.Farm)
            {
                VelocityFarmCache.ClusterServerString = ClusterServerString;
                VelocityFarmCache.CacheName = DistributedCacheName;
                VelocityFarmCache.EnvRegion = DistributedCacheEnvRegion;

                if (IsFarmCacheAvailable)
                {
                    return VelocityFarmCache.Instance.Read(cacheKey);
                }
            }
            var iVelocityCacheReader = GetVelocityCache(cacheKey);
            return iVelocityCacheReader != null ? iVelocityCacheReader.Read(cacheKey) : null;
        }

        public static void SetExpired(string cacheKey, VelocityCacheLevel? cacheLevel = null)
        {
            if (cacheLevel == VelocityCacheLevel.Farm)
            {
                VelocityFarmCache.ClusterServerString = ClusterServerString;
                VelocityFarmCache.CacheName = DistributedCacheName;
                VelocityFarmCache.EnvRegion = DistributedCacheEnvRegion;

                if (IsFarmCacheAvailable)
                {
                    VelocityFarmCache.Instance.SetExpired(cacheKey);
                    return;
                }
            }

            var iVelocityCacheReader = GetVelocityCache(cacheKey);
            if (iVelocityCacheReader != null)
                iVelocityCacheReader.SetExpired(cacheKey);
        }

        private static IVelocityCache GetVelocityCache(string cacheKey)
        {
            Lock.EnterReadLock();
            try
            {
                return CacheLevelKey.ContainsKey(cacheKey) ? CacheLevelKey[cacheKey] : null;
            }
            finally
            {
                Lock.ExitReadLock();
            }           
        }

        private static void SetVelocityCache(string cacheKey, IVelocityCache value)
        {
            Lock.EnterWriteLock();
            try
            {
                if (CacheLevelKey.ContainsKey(cacheKey))
                    CacheLevelKey[cacheKey] = value;
                else
                    CacheLevelKey.Add(cacheKey, value);
            }
            finally
            {
                Lock.ExitWriteLock();
            }     
        }

        public static void SetFarmCacheExpired(string cacheKey)
        {
            if (IsFarmCacheAvailable)
            {
                VelocityFarmCache.Instance.SetExpired(cacheKey);
            }
            else
            {
                VelocityWebFrontEndCache.Instance.SetExpired(cacheKey);
            }
        }
    }
}
