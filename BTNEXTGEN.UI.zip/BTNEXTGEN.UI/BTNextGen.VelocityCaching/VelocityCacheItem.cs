﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.VelocityCaching
{
    internal class VelocityCacheItem
    {
        public DateTime ExpirationTime { get; set; }

        public DateTime Created { get; set; }

        public object CachedObject { get; set; }

        public VelocityCacheItem()
        {
            Created = DateTime.Now;
        }

        public bool IsExpired()
        {
            return ExpirationTime < DateTime.Now;
        }
    }
}
