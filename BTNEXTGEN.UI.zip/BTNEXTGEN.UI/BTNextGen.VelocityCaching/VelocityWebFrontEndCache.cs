﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace BTNextGen.VelocityCaching
{
    public sealed class VelocityWebFrontEndCache : IVelocityCache
    {
        private readonly ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();

        private readonly Dictionary<string, VelocityCacheItem> _cacheStorage = new Dictionary<string, VelocityCacheItem>();

        private static volatile VelocityWebFrontEndCache _instance;
        private static object syncRoot = new Object();

        public static VelocityWebFrontEndCache Instance
        {
            get
            {
                if (_instance != null) return _instance;

                lock (syncRoot)
                {
                    if (_instance == null)
                        _instance = new VelocityWebFrontEndCache();
                }

                return _instance;
            }
        }

        private VelocityWebFrontEndCache()
        {
        }

        /// <summary>
        /// Write Cache
        /// </summary>
        /// <param name="cacheKey">Cache key</param>
        /// <param name="value">Object to cache</param>        
        /// <param name="cacheDuration">Cache duration in minutes</param>
        public void Write(string cacheKey, object value, int cacheDuration)
        {
            _lock.EnterWriteLock();
            try
            {
                var item = new VelocityCacheItem { CachedObject = value, ExpirationTime = DateTime.Now.AddMinutes(cacheDuration) };
                if (_cacheStorage.ContainsKey(cacheKey))
                    _cacheStorage[cacheKey] = item;
                else
                {
                    _cacheStorage.Add(cacheKey, item);
                }
            }
            finally
            {
                _lock.ExitWriteLock();
            }            
        }

        /// <summary>
        /// Read Cache by CacheKey
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        /// <returns></returns>
        public object Read(string cacheKey)
        {
            _lock.EnterReadLock();
            try
            {
                if (_cacheStorage.ContainsKey(cacheKey))
                {
                    var item = _cacheStorage[cacheKey];
                    if (item != null)
                    {
                        if (!item.IsExpired())
                            return item.CachedObject;
                    }
                }
            }
            finally
            {
                _lock.ExitReadLock();
            }                  
            return null;
        }

        public void SetExpired(string cacheKey)
        {
            _lock.EnterWriteLock();
            try
            {
                if (_cacheStorage.ContainsKey(cacheKey))
                    _cacheStorage.Remove(cacheKey);
            }
            finally
            {
                _lock.ExitWriteLock();
            }                            
        }
    }
}
