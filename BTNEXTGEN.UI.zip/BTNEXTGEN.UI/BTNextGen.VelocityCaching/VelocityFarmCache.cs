﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Threading;
using BTNextGen.CommonHelpers.Constants;
using Microsoft.ApplicationServer.Caching;
using BTNextGen.CommonHelpers.Logging;

namespace BTNextGen.VelocityCaching
{
    public sealed class VelocityFarmCache : IVelocityCache
    {
        private readonly ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();

        private static string _clusterServerString;
        public static string ClusterServerString
        {
            get { return _clusterServerString; }
            set
            {
                if (string.IsNullOrEmpty(_clusterServerString))
                {
                    _clusterServerString = value;
                }
            }
        }

        private static string _cacheName;
        public static string CacheName
        {
            get { return _cacheName; }
            set
            {
                if (string.IsNullOrEmpty(_cacheName))
                {
                    _cacheName = value;
                }
            }
        }

        private static string _envRegion;
        public static string EnvRegion
        {
            get { return _envRegion; }
            set
            {
                if (string.IsNullOrEmpty(_envRegion))
                {
                    _envRegion = value;
                }
            }
        }

        private static DataCacheFactory _factory;
        private static DataCache _ts360Cache;

        private static volatile VelocityFarmCache _instance;
        private static readonly object SyncRoot = new Object();

        public static VelocityFarmCache Instance
        {
            get
            {
                if (_instance != null) return _instance;

                lock (SyncRoot)
                {
                    if (_instance == null)
                        _instance = new VelocityFarmCache();
                }

                return _instance;
            }
        }

        private VelocityFarmCache()
        {
            _ts360Cache = GetCache();

            if (_ts360Cache == null)
            {
                // re-try 5 times
                for (int i = 0; i < 5; i++)
                {
                    Thread.Sleep(500);
                    _ts360Cache = GetCache();
                    if (_ts360Cache != null)
                    {
                        break;
                    }
                }
            }
        }

        public bool IsCacheAvailable
        {
            get { return _ts360Cache != null; }
        }

        public static DataCache GetCache()
        {
            if (_factory == null)
            {
                InitilizeCacheFactory();
            }

            try
            {
                if (_factory == null) return null;

                var cache = _factory.GetCache(CacheName);
                if (!string.IsNullOrEmpty(EnvRegion))
                {
                    cache.CreateRegion(EnvRegion);
                }

                return cache;
            }
            catch (DataCacheException ex)
            {
                if (ex.ErrorCode != DataCacheErrorCode.RetryLater && ex.SubStatus != DataCacheErrorSubStatus.None)
                {
                    Logger.RaiseException(ex, ExceptionCategory.DistributedCache);
                }
            }
            return null;
        }

        private static void InitilizeCacheFactory()
        {
            //Pass configuration settings to cacheFactory constructor
            _factory = new DataCacheFactory();

            if (_factory == null)
            {
                _factory = new DataCacheFactory();

                if (_factory == null)
                {
                    // re-try 5 times
                    for (int i = 0; i < 5; i++)
                    {
                        Thread.Sleep(500);
                        _factory = new DataCacheFactory();
                        if (_factory != null)
                        {
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Write Cache
        /// </summary>
        /// <param name="cacheKey">Cache key</param>
        /// <param name="value">Object to cache</param>        
        /// <param name="cacheDuration">Cache duration in minutes</param>
        public void Write(string cacheKey, object value, int cacheDuration)
        {
            if (value == null) return;

            _lock.EnterWriteLock();
            try
            {
                if (_ts360Cache == null)
                {
                    _ts360Cache = GetCache();
                }

                try
                {
                    _ts360Cache.Put(cacheKey, value, TimeSpan.FromMinutes(cacheDuration), EnvRegion);
                }
                catch (DataCacheException dataCacheException)
                {
                    if (dataCacheException.ErrorCode == DataCacheErrorCode.RegionDoesNotExist)
                    {
                        _ts360Cache.CreateRegion(EnvRegion);
                        _ts360Cache.Put(cacheKey, value, TimeSpan.FromMinutes(cacheDuration), EnvRegion);
                    }
                    else if (dataCacheException.ErrorCode == DataCacheErrorCode.RetryLater)
                    {
                        // connection issue. wait for awhile and try again.
                        Thread.Sleep(500);
                        _ts360Cache.Put(cacheKey, value, TimeSpan.FromMinutes(cacheDuration), EnvRegion);
                    }
                }
            }
            finally
            {
                _lock.ExitWriteLock();
            }
        }

        /// <summary>
        /// Read Cache by CacheKey
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        /// <returns></returns>
        public object Read(string cacheKey)
        {
            if (_ts360Cache == null)
            {
                _ts360Cache = GetCache();
            }

            _lock.EnterReadLock();
            try
            {
                return _ts360Cache == null ? null : _ts360Cache.Get(cacheKey, EnvRegion);
            }
            catch (DataCacheException dataCacheException)
            {
                if (_ts360Cache == null) return null;
                if (dataCacheException.ErrorCode == DataCacheErrorCode.ReadThroughRegionDoesNotExist ||
                    dataCacheException.ErrorCode == DataCacheErrorCode.RegionDoesNotExist ||
                    dataCacheException.ErrorCode == DataCacheErrorCode.CacheAdminRegionNotPresent)
                {
                    _ts360Cache.CreateRegion(EnvRegion);
                    return _ts360Cache.Get(cacheKey, EnvRegion);
                }
                else if (dataCacheException.ErrorCode == DataCacheErrorCode.RetryLater)
                {
                    // connection issue. wait for awhile and try again.
                    Thread.Sleep(500);
                    return _ts360Cache.Get(cacheKey, EnvRegion);
                }
            }
            finally
            {
                _lock.ExitReadLock();
            }
            return null;
        }

        public object this[string key]
        {
            get
            {
                return Read(key);
            }
        }

        public void SetExpired(string cacheKey)
        {
            if (_ts360Cache == null)
            {
                _ts360Cache = GetCache();
            }

            try
            {
                try
                {
                    if (string.IsNullOrEmpty(EnvRegion))
                    {
                        _ts360Cache.Remove(cacheKey);
                    }
                    else
                    {
                        _ts360Cache.Remove(cacheKey, EnvRegion);
                    }
                }
                catch (DataCacheException dataCacheEx)
                {
                    // Elmah #24864 - connection issue
                    if (dataCacheEx.ErrorCode == DataCacheErrorCode.RetryLater)
                    {
                        // wait for awhile
                        Thread.Sleep(500);

                        // try again
                        if (string.IsNullOrEmpty(EnvRegion))
                        {
                            _ts360Cache.Remove(cacheKey);
                        }
                        else
                        {
                            _ts360Cache.Remove(cacheKey, EnvRegion);
                        }
                    }
                    else
                        throw;
                }
            }
            catch (Exception ex)
            {
                Logger.RaiseException(ex, ExceptionCategory.DistributedCache);
            }
        }
    }
}
