namespace BTNextGen.VelocityCaching
{
    internal interface IVelocityCache
    {
        /// <summary>
        /// Write Cache
        /// </summary>
        /// <param name="cacheKey">Cache key</param>
        /// <param name="value">Object to cache</param>        
        /// <param name="cacheDuration">Cache duration in minutes</param>
        void Write(string cacheKey, object value, int cacheDuration);

        /// <summary>
        /// Read Cache by CacheKey
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        /// <returns></returns>
        object Read(string cacheKey);

        /// <summary>
        /// Expire a cache
        /// </summary>
        /// <param name="cacheKey">Cache Key</param>
        void SetExpired(string cacheKey);
    }
}