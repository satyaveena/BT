﻿using System.Collections.Generic;
using System.ServiceModel;

namespace BTNextGen.Pricing.CSPromotionService
{    
    [ServiceContract]
    public interface IPromotionService
    {
        [OperationContract]
        decimal CalculatePromotionPrice(string btKey, string productCatalog,
                                        string userId, int totalLineQuantity, int totalOrderQuantity,
                                        string marketType, string myPrefProductType, string myPrefAudienceType);        
        
        [OperationContract]
        List<PromotionPrice> CalculatePromotionPrices(List<LineRepricedInfo> lineItemRepricedList);
        //List<Commerce.Portal.Common.Contracts.PromotionPrice> CalculatePromotionPrices(List<Commerce.Portal.Common.Contracts.LineRepricedInfo> lineItemRepricedList);

        [OperationContract]
        void CalculatePrice(string basketSummaryId);
    }
}
