﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.ServiceModel.Activation;
using System.Text;
using System.Threading;
using System.Xml;
using BT.TS360API.ServiceContracts;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Pricing;
using BTNextGen.Pricing.CSPromotionService;
using Microsoft.CommerceServer;
using Microsoft.CommerceServer.Marketing;
using Microsoft.CommerceServer.Runtime.Marketing;
using Microsoft.CommerceServer.Runtime.Orders;
using Microsoft.CommerceServer.Runtime;
using Microsoft.CommerceServer.Runtime.Profiles;
using Basket = Microsoft.CommerceServer.Runtime.Orders.Basket;
using BTNextGen.Commerce.Portal.Common;
using System.ServiceModel;

namespace BTNextGen.Pricing.CSPromotionService
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class PromotionService : IPromotionService
    {
        private static byte[] _basketBinary;
        /// <summary>
        /// Constant for CS Promotion Pricing
        /// </summary>
        private const string TargetingContextAll = "ALL";

        /// <summary>
        /// Variables for CS Promotion
        /// </summary>
        private string _marketType = "";
        private string _myPrefProductType = "";
        private string _myPrefAudienceType = "";

        private string _pig = "";
        private string _siteBranding = "";
        private string _orgId = "";
        private string _orgName = "";
        
        private static MarketingContext _marketingSystem;
        public static MarketingContext MarketingSystem
        {
            get
            {
                return _marketingSystem ??
                       (_marketingSystem = MarketingContext.Create(CommerceContext.Current.SiteName, null,
                                                                   AuthorizationMode.NoAuthorization));
            }
        }
        #region CS Promotion Real-time

        /// <summary>
        /// Calculate Promotion Price
        /// </summary>
        /// <param name="btKey"></param>
        /// <param name="productCatalog"></param>
        /// <param name="userId"></param>
        /// <param name="totalLineQuantity"></param>
        /// <param name="totalOrderQuantity"></param>
        /// <param name="marketType"></param>
        /// <param name="myPrefProductType"></param>
        /// <param name="myPrefAudienceType"></param>
        /// <returns></returns>
        public decimal CalculatePromotionPrice(string btKey, string productCatalog,
                string userId, int totalLineQuantity, int totalOrderQuantity,
                string marketType, string myPrefProductType, string myPrefAudienceType)
        {
            var discountPrice = (decimal)0.0;

            // Setting for TargetingContext
            this._marketType = marketType;
            this._myPrefProductType = myPrefProductType ?? string.Empty;
            this._myPrefAudienceType = myPrefAudienceType ?? string.Empty;

            var basket = CreateEmptyBasket();
            //
            var lineItemEx = AddProductToBasket(basket, btKey, productCatalog, totalLineQuantity);
            var pipelineInfo = CreateBasketPipelineInfo(userId);
            //            

            basket.RunPipeline(pipelineInfo);

            discountPrice = lineItemEx.BTSalePrice;

            basket.Delete();

            return discountPrice;
        }

        /// <summary>
        /// Create Basket Pipeline Info
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private PipelineInfo CreateBasketPipelineInfo(string userId)
        {
            var pipelineInfo = new PipelineInfo("Basket", OrderPipelineType.Basket);
            var user = GetUserProfileObject(userId);
            pipelineInfo.Profiles.Add("UserObject", user);

            var ctx = CommerceContext.Current;

            ctx.TargetingSystem.TargetingContextProfile.Properties["ProductInterestGroup"].Value = AddAllValue(this._pig);
            ctx.TargetingSystem.TargetingContextProfile.Properties["SiteBranding"].Value = _siteBranding;

            ctx.TargetingSystem.TargetingContextProfile.Properties["market_type"].Value = _marketType;
            ctx.TargetingSystem.TargetingContextProfile.Properties["product_type"].Value = AddAllValue(this._myPrefProductType);
            ctx.TargetingSystem.TargetingContextProfile.Properties["audience_type"].Value = AddAllValue(this._myPrefAudienceType);
            ctx.TargetingSystem.TargetingContextProfile.Properties["org_id"].Value = AddAllValue(this._orgId);
            ctx.TargetingSystem.TargetingContextProfile.Properties["org_name"].Value = AddAllValue(this._orgName);

            pipelineInfo.Profiles.Add("targetingContext", ctx.TargetingSystem.TargetingContextProfile);

            return pipelineInfo;
        }

        /// <summary>
        /// Add Product To Basket
        /// </summary>
        /// <param name="basket"></param>
        /// <param name="productId"></param>
        /// <param name="productCatalog"></param>
        /// <param name="quantity"></param>
        /// <returns></returns>
        private static LineItemEx AddProductToBasket(Basket basket, string productId, string productCatalog, int quantity)
        {
            var lineItemEx = new LineItemEx { ProductId = productId, ProductCatalog = productCatalog, Quantity = quantity };
            basket.OrderForms[0].LineItems.Add(lineItemEx);            
            return lineItemEx;
        }

        private static void ClearAllLineItemsInBasket(Basket basket)
        {
            basket.OrderForms[0].LineItems.Clear();
        }
           
        /// <summary>
        /// Get User Profile Object
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private Profile GetUserProfileObject(string userId)
        {
            CommerceContext.Current.UserID = userId;

            var user = CommerceContext.Current.UserProfile;

            return user;
        }

        /// <summary>
        /// Create Empty Basket
        /// </summary>
        /// <returns></returns>
        private Basket CreateEmptyBasket()
        {
            using (var basketMemoryStream = BasketMemoryStream())
            {
                var binaryFormatter = new BinaryFormatter();
                var emptyBasket = (Basket)binaryFormatter.Deserialize(basketMemoryStream);

                //
                emptyBasket.OrderForms.Add(new OrderFormEx());
                return emptyBasket;
            }
        }

        private static MemoryStream BasketMemoryStream()
        {
            if (_basketBinary == null)
            {
                var basket = CommerceContext.Current.OrderSystem.GetBasket(Guid.NewGuid());
                using (var stream = new MemoryStream())
                {
                    var bformatter = new BinaryFormatter();
                    //            
                    bformatter.Serialize(stream, basket);
                    _basketBinary = stream.ToArray();
                }
            }
            var basketMemoryStream = new MemoryStream(_basketBinary);
            return basketMemoryStream;
        }

        /// <summary>
        /// Add All Value
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private static string AddAllValue(string item)
        {
            const string delimiter = ";";

            //if (item == "")
            //    return string.Empty;

            return TargetingContextAll + delimiter + item;
        }

        /// <summary>
        /// Get top promotion code which is defined for a product
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="catalogName"></param>
        /// <returns></returns>
        public string GetTopPromotionCode(string productId, string catalogName)
        {
            var discountsFromCache = DiscountItemCollection.CreateFromCache("Discounts");
            var filter = new DiscountCriteriaFilter();
            filter.FilterOnAward = true;
            filter.FilterOnCondition = false;
            filter.IncludeDiscountsWithEligibilityRequirements = true;
            filter.IncludeDiscountsWithPromoCodes = true;
            filter.IncludeInactiveDiscounts = false;

            const string refineCatalog = "MarketingCatalog";

            string productId2 = string.Format("{0}({1})", productId, catalogName);
            DiscountItemCollection discounts;
            List<string> vcatsName = CatalogController.GetParentCategories(refineCatalog, productId2);
            if (vcatsName != null && vcatsName.Count > 0)
            {
                foreach (var catName in vcatsName)
                {
                    // Get the discount by category of product
                    discounts = discountsFromCache.ApplyCategoryFilter(filter, refineCatalog, catName);
                    if (discounts != null && discounts.Count > 0)
                    {
                        return GetFirstDiscountName(discounts);
                    }
                }
            }
            discounts = discountsFromCache.ApplyProductFilter(filter, catalogName, productId);
            if (discounts != null && discounts.Count > 0)
            {
                return GetFirstDiscountName(discounts);
            }
            // get discount from Cache by Category
            var catsName = CatalogController.GetParentCategories(catalogName, productId);
            if (catsName != null && catsName.Count > 0)
            {
                foreach (var catName in catsName)
                {
                    // Get the discount by category of product
                    discounts = discountsFromCache.ApplyCategoryFilter(filter, catalogName, catName);

                    if (discounts != null && discounts.Count > 0)
                    {
                        return GetFirstDiscountName(discounts);
                    }
                }
            }

            return string.Empty;
        }

        public List<PromotionPrice> CalculatePromotionPrices(List<LineRepricedInfo> lineItemRepricedList)
        {
            var result = new List<PromotionPrice>();
            foreach (var lineRepricedInfo in lineItemRepricedList)
            {
                var item = new PromotionPrice { BtKey = lineRepricedInfo.BTKey };
                string promoCode;
                item.Price = GetDiscountPrice(lineRepricedInfo, out promoCode);
                item.PromotionCode = promoCode;
                result.Add(item);
            }
            return result;
        }

        private decimal GetDiscountPrice(LineRepricedInfo lineRepricedInfo, out string promoCode)
        {
            var basket = CreateEmptyBasket();
            var discountPrice = (decimal)0.0;
            promoCode = string.Empty;
            var step = 0;
            try
            {
                // Setting for TargetingContext
                this._marketType = lineRepricedInfo.MarketType;
                if (!string.IsNullOrEmpty(lineRepricedInfo.ProductType))
                {
                    var productType = Enum.Parse(typeof(ProductType), lineRepricedInfo.ProductType);
                    this._myPrefProductType = ((int)productType).ToString(CultureInfo.InvariantCulture);
                }
                else
                {
                    this._myPrefProductType = lineRepricedInfo.ProductType;
                }
                this._myPrefAudienceType = lineRepricedInfo.AudienceType ?? string.Empty;
                this._pig = lineRepricedInfo.Pig ?? string.Empty;
                this._siteBranding = lineRepricedInfo.SiteBranding ?? string.Empty;
                this._orgId = lineRepricedInfo.OrgId;
                this._orgName = lineRepricedInfo.OrgName;
                var targetingParam = new TargetingParam()
                {
                    AudienceType = AddAllValue(this._myPrefAudienceType),
                    ProductType = AddAllValue(this._myPrefProductType),
                    MarketType = lineRepricedInfo.MarketType,
                    PIG = AddAllValue(this._pig),
                    SiteBranding = lineRepricedInfo.SiteBranding,
                    OrgId = AddAllValue(this._orgId),
                    OrgName = AddAllValue(this._orgName)
                };
                step = 1;
                promoCode = MarketingController.TargetProduct(lineRepricedInfo.BTKey, lineRepricedInfo.ProductCatalog,
                    targetingParam);
                step = 2;
                if (!string.IsNullOrEmpty(promoCode))
                {
                    var lineItemEx = AddProductToBasket(basket, lineRepricedInfo.BTKey, lineRepricedInfo.ProductCatalog,
                        lineRepricedInfo.TotalLineQuantity);
                    var pipelineInfo = CreateBasketPipelineInfo(lineRepricedInfo.UserId);
                    //            
                    step = 3;
                    basket.RunPipeline(pipelineInfo);
                    step = 4;
                    discountPrice = lineItemEx.BTSalePrice;
                    //
                    ClearAllLineItemsInBasket(basket); //Clear all line items in basket for basket reusing.
                    //
                }

            }
            catch (Exception ex)
            {
                var param = string.Format("BTKey:{0};UserID:{1};Step:{2}", lineRepricedInfo.BTKey, lineRepricedInfo.UserId, step);
                Logger.Write(ExceptionCategory.Pricing.ToString(), string.Format("{2}-{0}, {1}", ex.Message, ex.StackTrace, param));
            }
            finally
            {
                basket.Delete();
            }
            return discountPrice;
        }

        //public List<Commerce.Portal.Common.Contracts.PromotionPrice> CalculatePromotionPrices(List<Commerce.Portal.Common.Contracts.LineRepricedInfo> lineItemRepricedList)
        //{
        //    return CommonHelper.CalculatePromotionPrices(lineItemRepricedList);
        //}

        //private decimal GetDiscountPrice(LineRepricedInfo lineRepricedInfo, out string promoCode)
        //{
        //    var basket = CreateEmptyBasket();
        //    var discountPrice = (decimal)0.0;
        //    promoCode = string.Empty;
        //    var step = 0;
        //    try
        //    {
        //        // Setting for TargetingContext
        //        this._marketType = lineRepricedInfo.MarketType;
        //        if (!string.IsNullOrEmpty(lineRepricedInfo.ProductType))
        //        {
        //            var productType = Enum.Parse(typeof (ProductType), lineRepricedInfo.ProductType);
        //            this._myPrefProductType = ((int) productType).ToString(CultureInfo.InvariantCulture);
        //        }
        //        else
        //        {
        //            this._myPrefProductType = lineRepricedInfo.ProductType;
        //        }
        //        this._myPrefAudienceType = lineRepricedInfo.AudienceType ?? string.Empty;
        //        this._pig = lineRepricedInfo.Pig ?? string.Empty;
        //        this._siteBranding = lineRepricedInfo.SiteBranding ?? string.Empty;
        //        this._orgId = lineRepricedInfo.OrgId;
        //        this._orgName = lineRepricedInfo.OrgName;
        //        var targetingParam = new TargetingParam()
        //                             {
        //                                 AudienceType = AddAllValue(this._myPrefAudienceType),
        //                                 ProductType = AddAllValue(this._myPrefProductType),
        //                                 MarketType = lineRepricedInfo.MarketType,
        //                                 PIG = AddAllValue(this._pig),
        //                                 SiteBranding = lineRepricedInfo.SiteBranding,
        //                                 OrgId = AddAllValue(this._orgId),
        //                                 OrgName = AddAllValue(this._orgName)
        //                             };
        //        step = 1;
        //        promoCode = MarketingController.TargetProduct(lineRepricedInfo.BTKey, lineRepricedInfo.ProductCatalog,
        //            targetingParam);
        //        step = 2;
        //        if (!string.IsNullOrEmpty(promoCode))
        //        {
        //            var lineItemEx = AddProductToBasket(basket, lineRepricedInfo.BTKey, lineRepricedInfo.ProductCatalog,
        //                lineRepricedInfo.TotalLineQuantity);
        //            var pipelineInfo = CreateBasketPipelineInfo(lineRepricedInfo.UserId);
        //            //            
        //            step = 3;
        //            basket.RunPipeline(pipelineInfo);
        //            step =4;
        //            discountPrice = lineItemEx.BTSalePrice;
        //            //
        //            ClearAllLineItemsInBasket(basket); //Clear all line items in basket for basket reusing.
        //            //
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        var param = string.Format("BTKey:{0};UserID:{1};Step:{2}", lineRepricedInfo.BTKey, lineRepricedInfo.UserId,step);
        //        Logger.Write(ExceptionCategory.Pricing.ToString(), string.Format("{2}-{0}, {1}", ex.Message, ex.StackTrace,param)); 
        //    }
        //    finally
        //    {
        //        basket.Delete();
        //    }
        //    return discountPrice;
        //}

        private string GetFirstDiscountName(DiscountItemCollection discounts)
        {
            var topDiscount = discounts.First();
            if (topDiscount != null)
            {
                var discountName = topDiscount["Name"];
                if (discountName != null) return discountName.ToString();
            }
            return string.Empty;
        }

        public void CalculatePrice(string basketSummaryId)
        {
            //parsing configured data
            int batchWaitingTime = GetBatchWaitingTimeConfig();
            var pricingController = new PricingController();
            //calculating basket price
            pricingController.CalculatePrice(basketSummaryId, batchWaitingTime);
        }

        private int GetBatchWaitingTimeConfig()
        {
            int batchWaitingTime = 100;
            try
            {
                var sbatchWaitingTime = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.PricingBatchWaitingTime).Value;
                int.TryParse(sbatchWaitingTime, out batchWaitingTime);
            }
            catch
            {                
            }

            return batchWaitingTime;
        }

        #endregion
    }
}
