﻿using System.Runtime.Serialization;

namespace BTNextGen.Pricing.CSPromotionService
{
    [DataContract]
    public class PromotionPrice
    {
        [DataMember]
        public string BtKey { get; set; }

        [DataMember]
        public decimal Price { get; set; }

        [DataMember]
        public string PromotionCode { get; set; }
    }
}
