USE [NextGen]
GO

/****** Object:  Table [dbo].[CrawlInfo]    Script Date: 03/28/2011 11:21:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [dbo].[CrawlInfo]    Script Date: 03/28/2011 11:24:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CrawlInfo]') AND type in (N'U'))
DROP TABLE [dbo].[CrawlInfo]
GO

USE [NextGen]
GO

CREATE TABLE [dbo].[CrawlInfo](
	[LastUpdateCrawlStart] [datetime] NULL,
	[CurrentUpdateCrawlStart] [datetime] NULL
) ON [PRIMARY]

GO


INSERT INTO [NextGen].[dbo].[CrawlInfo]
           ([LastUpdateCrawlStart]
           ,[CurrentUpdateCrawlStart])
     VALUES
           ('1/1/1800',
           '1/1/1800')
GO


