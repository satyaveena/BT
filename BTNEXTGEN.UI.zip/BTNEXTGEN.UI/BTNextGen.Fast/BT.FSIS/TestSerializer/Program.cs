﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using BT.FSIS.WCF;
using System.IO;
//using Microsoft.Ceres


namespace BT.FSIS.TestSerializer
{
    class Program
    {
        static void Main(string[] args)
        {
            var cd1 = new ClusterDefinition("cluster1", "nav1");
            var cd2 = new ClusterDefinition("cluster2", "nav2");

            IList<ClusterDefinition> cDefs = new List<ClusterDefinition> { cd1, cd2 };

            var navDef1 = new NavigatorDefinition("attrib1", true, "people1", "peopleNav1", true, "no scope1", "title1");
            var navDef2 = new NavigatorDefinition("attrib2", true, "people2", "peopleNav2", true, "no scope2", "title2");

            IList<NavigatorDefinition> navDefList = new List<NavigatorDefinition> { navDef1, navDef2 };
            var navigation = new Navigation(5, navDefList);

            var executor1 = SearchExecutorFactory.Create("nothing", 12, cDefs, navigation, true);

            var termsOp = new RankOperator("dog cat");
            termsOp.Linguistics = false;
            termsOp.Mode = TermsOperatorMode.Any;
            termsOp.ReturnScope = "return scope terms";
            termsOp.Source = "esp";
            termsOp.Weight = 50;
            termsOp.Scopes.Add("scope1");
            termsOp.Scopes.Add("scope2");

            var phraseOp = new PhraseOperator("cow pig");
            phraseOp.Weight = 75;
            phraseOp.Source = "ims";
            phraseOp.Scopes.Add("scopeP1");
            phraseOp.Scopes.Add("scopeP2");
            phraseOp.Linguistics = true;

            var proximityOp = new ProximityOperator("water air");
            proximityOp.ExtraTermsAllowed = 3;
            proximityOp.Ordered = false;
            proximityOp.ReturnScope = "return scope prox";
            proximityOp.Scopes.Add("scopePro1");
            proximityOp.Scopes.Add("scopePro2");
            proximityOp.Source = "prox source";

            var boundaryOp = new BoundaryOperator("bird fish", BoundaryOperatorMode.Exact);
            boundaryOp.Linguistics = true;
            boundaryOp.ReturnScope = "boundary scope";
            boundaryOp.Source = "bdy";
            boundaryOp.Weight = 2;
            boundaryOp.Scopes.Add("scopeB1");
            boundaryOp.Scopes.Add("scopeB2");

            var rangeOp = new RangeOperator();
            rangeOp.Max = 50;
            rangeOp.MaxInclusive = false;
            rangeOp.Min = 20;
            rangeOp.MinInclusive = true;
            rangeOp.Source = "range source";
            rangeOp.Scopes.Add("scopeR1");
            rangeOp.Scopes.Add("scopeR1");

            var dateRangeOp = new RangeOperator();
            dateRangeOp.Max = DateTime.Now;
            dateRangeOp.MaxInclusive = false;
            dateRangeOp.Min = DateTime.Now.AddYears(-10);
            dateRangeOp.MinInclusive = true;
            dateRangeOp.Source = "range source";
            dateRangeOp.Scopes.Add("scopeR1");
            dateRangeOp.Scopes.Add("scopeR1");

            var numericIntOp = new NumericOperator(58);
            numericIntOp.Scopes.Add("num scope 1");
            numericIntOp.Scopes.Add("num scope 2");
            numericIntOp.Source = "num source";

            var numericDoubleOp = new NumericOperator(7.5);
            numericDoubleOp.Scopes.Add("num scope 1");
            numericDoubleOp.Scopes.Add("num scope 2");
            numericDoubleOp.Source = "num source";            
            
            var groupOp = new GroupOperator(GroupOperatorType.And);
            groupOp.Source = "group source";
            groupOp.Operators.Add(termsOp);
            groupOp.Operators.Add(phraseOp);
            groupOp.Operators.Add(boundaryOp);
            groupOp.Operators.Add(rangeOp);
            groupOp.Operators.Add(dateRangeOp);
            groupOp.Operators.Add(numericIntOp);
            groupOp.Operators.Add(numericDoubleOp);

            var search = new Search(groupOp);

            executor1.DefineSearch(search);


            //var imsRefinerEntry1 = new ImsRefinerEntry();
            //imsRefinerEntry1.ResultCount = 12;
            //imsRefinerEntry1.ResultRatio = 17;
            //imsRefinerEntry1.DisplayName = "ims refiner entry 1";
            //imsRefinerEntry1.Value = "ims refiner entry value 1";

            //var imsRefinerEntry2 = new ImsRefinerEntry();
            //imsRefinerEntry2.ResultCount = 212;
            //imsRefinerEntry2.ResultRatio = 217;
            //imsRefinerEntry2.DisplayName = "ims refiner entry 2";
            //imsRefinerEntry2.Value = "ims refiner entry value 2";

            //var imsRefiner = new ImsRefiner();
            //imsRefiner.DisplayName = "ims refiner";
            //imsRefiner.EntryCount = 2;
            //imsRefiner.FieldName = "ims refiner field";
            //imsRefiner.Entries.Add(imsRefinerEntry1);
            //imsRefiner.Entries.Add(imsRefinerEntry2);

            //var nav = new Navigator(imsRefiner);

            //var imsRefinerEntry = new ImsRefinerEntry();
            //imsRefinerEntry.DisplayName = "ims refiner entry";
            //imsRefinerEntry.ResultCount = 7;
            //imsRefinerEntry.ResultRatio = 1.11;
            //imsRefinerEntry.Value = "ims refiner value";

            //var navGroup = new NavigatorGroup(nav, imsRefinerEntry);
            //var navGroupRefinement = new NavigatorGroupRefinement(true, false, navGroup);
            //executor1.AddRefinement(navGroupRefinement);
            
            var findSimilarRefinement = new FindSimilarRefinement("doc title", "doc vector", true);
            executor1.AddRefinement(findSimilarRefinement);

            var clusterNodeRefinement = new ClusterNodeRefinement("cluster name", "some field", "some path", true, true);
            executor1.AddRefinement(clusterNodeRefinement);

            string serializedExecutor1 = executor1.Serialize();

            var executor2 = SearchExecutorFactory.CreateFromSerialized(serializedExecutor1);

            string serializedExecutor2 = executor2.Serialize();

            var file1 = File.CreateText("c:\\temp\\exec1.xml");
            file1.Write(serializedExecutor1);

            var file2 = File.CreateText("c:\\temp\\exec2.xml");
            file2.Write(serializedExecutor2);

            file1.Flush();
            file2.Flush();

        }
    }
}
