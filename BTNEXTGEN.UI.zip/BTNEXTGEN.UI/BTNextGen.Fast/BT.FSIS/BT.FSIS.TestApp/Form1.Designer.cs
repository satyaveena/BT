﻿namespace BT.FSIS.TestApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textTerms = new System.Windows.Forms.TextBox();
            this.textStatus = new System.Windows.Forms.TextBox();
            this.checkBoxThesaraus = new System.Windows.Forms.CheckBox();
            this.checkBoxSpellCheck = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.linkLabelDidYouMean = new System.Windows.Forms.LinkLabel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonNoneNav = new System.Windows.Forms.Button();
            this.buttonAllNav = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.listBoxRefinements = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.labelPageStatus = new System.Windows.Forms.Label();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.buttonApplyCluster = new System.Windows.Forms.Button();
            this.treeViewCluster = new System.Windows.Forms.TreeView();
            this.label4 = new System.Windows.Forms.Label();
            this.listBoxClusters = new System.Windows.Forms.ListBox();
            this.buttonNavApply = new System.Windows.Forms.Button();
            this.treeViewNav = new System.Windows.Forms.TreeView();
            this.grdNav = new System.Windows.Forms.DataGridView();
            this.NavName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NavDisplayName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NavCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.richTextBoxLog = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.treeViewCatBrowse = new System.Windows.Forms.TreeView();
            this.numericResults = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.textTerms1 = new System.Windows.Forms.TextBox();
            this.textField1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textTerms2 = new System.Windows.Forms.TextBox();
            this.textField2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textMinValue = new System.Windows.Forms.TextBox();
            this.textField3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxBool1 = new System.Windows.Forms.ComboBox();
            this.comboBoxBool2 = new System.Windows.Forms.ComboBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button2 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.textMaxValue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbIncludeMin = new System.Windows.Forms.CheckBox();
            this.cbIncludeMax = new System.Windows.Forms.CheckBox();
            this.boost1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.boost2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdNav)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericResults)).BeginInit();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(686, 12);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(75, 23);
            this.buttonSearch.TabIndex = 0;
            this.buttonSearch.Text = "&Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "General Terms";
            // 
            // textTerms
            // 
            this.textTerms.Location = new System.Drawing.Point(135, 14);
            this.textTerms.Name = "textTerms";
            this.textTerms.Size = new System.Drawing.Size(289, 20);
            this.textTerms.TabIndex = 5;
            // 
            // textStatus
            // 
            this.textStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textStatus.Location = new System.Drawing.Point(12, 692);
            this.textStatus.Name = "textStatus";
            this.textStatus.ReadOnly = true;
            this.textStatus.Size = new System.Drawing.Size(940, 20);
            this.textStatus.TabIndex = 7;
            // 
            // checkBoxThesaraus
            // 
            this.checkBoxThesaraus.AutoSize = true;
            this.checkBoxThesaraus.Location = new System.Drawing.Point(767, 12);
            this.checkBoxThesaraus.Name = "checkBoxThesaraus";
            this.checkBoxThesaraus.Size = new System.Drawing.Size(104, 17);
            this.checkBoxThesaraus.TabIndex = 11;
            this.checkBoxThesaraus.Text = "Use Thesauraus";
            this.checkBoxThesaraus.UseVisualStyleBackColor = true;
            // 
            // checkBoxSpellCheck
            // 
            this.checkBoxSpellCheck.AutoSize = true;
            this.checkBoxSpellCheck.Checked = true;
            this.checkBoxSpellCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSpellCheck.Location = new System.Drawing.Point(767, 36);
            this.checkBoxSpellCheck.Name = "checkBoxSpellCheck";
            this.checkBoxSpellCheck.Size = new System.Drawing.Size(83, 17);
            this.checkBoxSpellCheck.TabIndex = 12;
            this.checkBoxSpellCheck.Text = "Spell Check";
            this.checkBoxSpellCheck.UseVisualStyleBackColor = true;
            this.checkBoxSpellCheck.CheckedChanged += new System.EventHandler(this.checkBoxSpellCheck_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Did You Mean:";
            // 
            // linkLabelDidYouMean
            // 
            this.linkLabelDidYouMean.AutoSize = true;
            this.linkLabelDidYouMean.Location = new System.Drawing.Point(518, 20);
            this.linkLabelDidYouMean.Name = "linkLabelDidYouMean";
            this.linkLabelDidYouMean.Size = new System.Drawing.Size(0, 13);
            this.linkLabelDidYouMean.TabIndex = 14;
            this.linkLabelDidYouMean.Click += new System.EventHandler(this.linkLabelDidYouMean_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 141);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1111, 548);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buttonNoneNav);
            this.tabPage1.Controls.Add(this.buttonAllNav);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.listBoxRefinements);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.labelPageStatus);
            this.tabPage1.Controls.Add(this.buttonPrev);
            this.tabPage1.Controls.Add(this.buttonNext);
            this.tabPage1.Controls.Add(this.buttonLast);
            this.tabPage1.Controls.Add(this.buttonFirst);
            this.tabPage1.Controls.Add(this.buttonApplyCluster);
            this.tabPage1.Controls.Add(this.treeViewCluster);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.listBoxClusters);
            this.tabPage1.Controls.Add(this.buttonNavApply);
            this.tabPage1.Controls.Add(this.treeViewNav);
            this.tabPage1.Controls.Add(this.grdNav);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1103, 522);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Results";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonNoneNav
            // 
            this.buttonNoneNav.Location = new System.Drawing.Point(519, 485);
            this.buttonNoneNav.Name = "buttonNoneNav";
            this.buttonNoneNav.Size = new System.Drawing.Size(75, 23);
            this.buttonNoneNav.TabIndex = 28;
            this.buttonNoneNav.Text = "None";
            this.buttonNoneNav.UseVisualStyleBackColor = true;
            this.buttonNoneNav.Click += new System.EventHandler(this.buttonNoneNav_Click);
            // 
            // buttonAllNav
            // 
            this.buttonAllNav.Location = new System.Drawing.Point(438, 485);
            this.buttonAllNav.Name = "buttonAllNav";
            this.buttonAllNav.Size = new System.Drawing.Size(75, 23);
            this.buttonAllNav.TabIndex = 27;
            this.buttonAllNav.Text = "All";
            this.buttonAllNav.UseVisualStyleBackColor = true;
            this.buttonAllNav.Click += new System.EventHandler(this.buttonAllNav_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(893, 233);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 26;
            this.button1.Text = "Remove";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBoxRefinements
            // 
            this.listBoxRefinements.FormattingEnabled = true;
            this.listBoxRefinements.HorizontalScrollbar = true;
            this.listBoxRefinements.Location = new System.Drawing.Point(893, 27);
            this.listBoxRefinements.Name = "listBoxRefinements";
            this.listBoxRefinements.Size = new System.Drawing.Size(204, 199);
            this.listBoxRefinements.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(890, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Applied Refinenements";
            // 
            // labelPageStatus
            // 
            this.labelPageStatus.AutoSize = true;
            this.labelPageStatus.Location = new System.Drawing.Point(370, 285);
            this.labelPageStatus.Name = "labelPageStatus";
            this.labelPageStatus.Size = new System.Drawing.Size(0, 13);
            this.labelPageStatus.TabIndex = 23;
            // 
            // buttonPrev
            // 
            this.buttonPrev.Location = new System.Drawing.Point(91, 280);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(75, 23);
            this.buttonPrev.TabIndex = 22;
            this.buttonPrev.Text = "Previous";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Location = new System.Drawing.Point(171, 280);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(75, 23);
            this.buttonNext.TabIndex = 21;
            this.buttonNext.Text = "Next";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(252, 280);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(75, 23);
            this.buttonLast.TabIndex = 20;
            this.buttonLast.Text = "Last";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(9, 280);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(75, 23);
            this.buttonFirst.TabIndex = 19;
            this.buttonFirst.Text = "First";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // buttonApplyCluster
            // 
            this.buttonApplyCluster.Location = new System.Drawing.Point(794, 484);
            this.buttonApplyCluster.Name = "buttonApplyCluster";
            this.buttonApplyCluster.Size = new System.Drawing.Size(75, 23);
            this.buttonApplyCluster.TabIndex = 18;
            this.buttonApplyCluster.Text = "Apply";
            this.buttonApplyCluster.UseVisualStyleBackColor = true;
            this.buttonApplyCluster.Click += new System.EventHandler(this.buttonApplyCluster_Click);
            // 
            // treeViewCluster
            // 
            this.treeViewCluster.CheckBoxes = true;
            this.treeViewCluster.Location = new System.Drawing.Point(793, 306);
            this.treeViewCluster.Name = "treeViewCluster";
            this.treeViewCluster.Size = new System.Drawing.Size(244, 173);
            this.treeViewCluster.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(597, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Clusters";
            // 
            // listBoxClusters
            // 
            this.listBoxClusters.FormattingEnabled = true;
            this.listBoxClusters.Location = new System.Drawing.Point(600, 306);
            this.listBoxClusters.Name = "listBoxClusters";
            this.listBoxClusters.Size = new System.Drawing.Size(187, 173);
            this.listBoxClusters.TabIndex = 15;
            this.listBoxClusters.SelectedIndexChanged += new System.EventHandler(this.listBoxClusters_SelectedIndexChanged);
            // 
            // buttonNavApply
            // 
            this.buttonNavApply.Location = new System.Drawing.Point(357, 485);
            this.buttonNavApply.Name = "buttonNavApply";
            this.buttonNavApply.Size = new System.Drawing.Size(75, 23);
            this.buttonNavApply.TabIndex = 14;
            this.buttonNavApply.Text = "Apply";
            this.buttonNavApply.UseVisualStyleBackColor = true;
            this.buttonNavApply.Click += new System.EventHandler(this.buttonNavApply_Click);
            // 
            // treeViewNav
            // 
            this.treeViewNav.CheckBoxes = true;
            this.treeViewNav.Location = new System.Drawing.Point(357, 306);
            this.treeViewNav.Name = "treeViewNav";
            this.treeViewNav.Size = new System.Drawing.Size(237, 173);
            this.treeViewNav.TabIndex = 13;
            // 
            // grdNav
            // 
            this.grdNav.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdNav.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdNav.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdNav.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NavName,
            this.NavDisplayName,
            this.NavCount});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdNav.DefaultCellStyle = dataGridViewCellStyle2;
            this.grdNav.Location = new System.Drawing.Point(9, 306);
            this.grdNav.Name = "grdNav";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdNav.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grdNav.Size = new System.Drawing.Size(345, 194);
            this.grdNav.TabIndex = 12;
            this.grdNav.SelectionChanged += new System.EventHandler(this.grdNav_SelectionChanged);
            // 
            // NavName
            // 
            this.NavName.HeaderText = "Nav Name";
            this.NavName.Name = "NavName";
            // 
            // NavDisplayName
            // 
            this.NavDisplayName.HeaderText = "Display Name";
            this.NavDisplayName.Name = "NavDisplayName";
            // 
            // NavCount
            // 
            this.NavCount.HeaderText = "Count";
            this.NavCount.Name = "NavCount";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.Location = new System.Drawing.Point(7, 10);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.Size = new System.Drawing.Size(880, 264);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_ColumnHeaderMouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.richTextBoxLog);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1103, 522);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Log";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // richTextBoxLog
            // 
            this.richTextBoxLog.Location = new System.Drawing.Point(6, -72);
            this.richTextBoxLog.Name = "richTextBoxLog";
            this.richTextBoxLog.ReadOnly = true;
            this.richTextBoxLog.Size = new System.Drawing.Size(924, 588);
            this.richTextBoxLog.TabIndex = 0;
            this.richTextBoxLog.Text = "";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.treeViewCatBrowse);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1103, 522);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Browse";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            this.tabPage3.Enter += new System.EventHandler(this.tabPage3_Enter);
            // 
            // treeViewCatBrowse
            // 
            this.treeViewCatBrowse.Location = new System.Drawing.Point(10, 6);
            this.treeViewCatBrowse.Name = "treeViewCatBrowse";
            this.treeViewCatBrowse.Size = new System.Drawing.Size(491, 515);
            this.treeViewCatBrowse.TabIndex = 0;
            this.treeViewCatBrowse.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewCatBrowse_AfterSelect);
            this.treeViewCatBrowse.Click += new System.EventHandler(this.treeViewCatBrowse_Click);
            // 
            // numericResults
            // 
            this.numericResults.Location = new System.Drawing.Point(978, 12);
            this.numericResults.Name = "numericResults";
            this.numericResults.Size = new System.Drawing.Size(63, 20);
            this.numericResults.TabIndex = 17;
            this.numericResults.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(881, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Results Per Page";
            // 
            // textTerms1
            // 
            this.textTerms1.Location = new System.Drawing.Point(234, 40);
            this.textTerms1.Name = "textTerms1";
            this.textTerms1.Size = new System.Drawing.Size(190, 20);
            this.textTerms1.TabIndex = 23;
            // 
            // textField1
            // 
            this.textField1.Location = new System.Drawing.Point(86, 39);
            this.textField1.Name = "textField1";
            this.textField1.Size = new System.Drawing.Size(100, 20);
            this.textField1.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(192, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Terms";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(51, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Field";
            // 
            // textTerms2
            // 
            this.textTerms2.Location = new System.Drawing.Point(234, 66);
            this.textTerms2.Name = "textTerms2";
            this.textTerms2.Size = new System.Drawing.Size(190, 20);
            this.textTerms2.TabIndex = 27;
            // 
            // textField2
            // 
            this.textField2.Location = new System.Drawing.Point(86, 65);
            this.textField2.Name = "textField2";
            this.textField2.Size = new System.Drawing.Size(100, 20);
            this.textField2.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(192, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Terms";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(51, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Field";
            // 
            // textMinValue
            // 
            this.textMinValue.Location = new System.Drawing.Point(252, 93);
            this.textMinValue.Name = "textMinValue";
            this.textMinValue.Size = new System.Drawing.Size(91, 20);
            this.textMinValue.TabIndex = 31;
            // 
            // textField3
            // 
            this.textField3.Location = new System.Drawing.Point(86, 91);
            this.textField3.Name = "textField3";
            this.textField3.Size = new System.Drawing.Size(100, 20);
            this.textField3.TabIndex = 30;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(192, 94);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 29;
            this.label11.Text = "Min Value";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(51, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "Field";
            // 
            // comboBoxBool1
            // 
            this.comboBoxBool1.FormattingEnabled = true;
            this.comboBoxBool1.Items.AddRange(new object[] {
            "OR",
            "AND",
            "NOT",
            "XRANK"});
            this.comboBoxBool1.Location = new System.Drawing.Point(16, 40);
            this.comboBoxBool1.Name = "comboBoxBool1";
            this.comboBoxBool1.Size = new System.Drawing.Size(37, 21);
            this.comboBoxBool1.TabIndex = 32;
            this.comboBoxBool1.SelectedIndexChanged += new System.EventHandler(this.comboBoxBool1_SelectedIndexChanged);
            // 
            // comboBoxBool2
            // 
            this.comboBoxBool2.FormattingEnabled = true;
            this.comboBoxBool2.Items.AddRange(new object[] {
            "OR",
            "AND",
            "NOT",
            "XRANK"});
            this.comboBoxBool2.Location = new System.Drawing.Point(16, 66);
            this.comboBoxBool2.Name = "comboBoxBool2";
            this.comboBoxBool2.Size = new System.Drawing.Size(37, 21);
            this.comboBoxBool2.TabIndex = 33;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1129, 24);
            this.menuStrip2.TabIndex = 35;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.saveToolStripMenuItem.Text = "&Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(97, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(686, 61);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 23);
            this.button2.TabIndex = 36;
            this.button2.Text = "Large Query Test";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(810, 66);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 37;
            this.numericUpDown1.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // textMaxValue
            // 
            this.textMaxValue.Location = new System.Drawing.Point(415, 94);
            this.textMaxValue.Name = "textMaxValue";
            this.textMaxValue.Size = new System.Drawing.Size(91, 20);
            this.textMaxValue.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(355, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Max Value";
            // 
            // cbIncludeMin
            // 
            this.cbIncludeMin.AutoSize = true;
            this.cbIncludeMin.Location = new System.Drawing.Point(521, 95);
            this.cbIncludeMin.Name = "cbIncludeMin";
            this.cbIncludeMin.Size = new System.Drawing.Size(81, 17);
            this.cbIncludeMin.TabIndex = 40;
            this.cbIncludeMin.Text = "Include Min";
            this.cbIncludeMin.UseVisualStyleBackColor = true;
            // 
            // cbIncludeMax
            // 
            this.cbIncludeMax.AutoSize = true;
            this.cbIncludeMax.Location = new System.Drawing.Point(608, 95);
            this.cbIncludeMax.Name = "cbIncludeMax";
            this.cbIncludeMax.Size = new System.Drawing.Size(84, 17);
            this.cbIncludeMax.TabIndex = 41;
            this.cbIncludeMax.Text = "Include Max";
            this.cbIncludeMax.UseVisualStyleBackColor = true;
            // 
            // boost1
            // 
            this.boost1.Location = new System.Drawing.Point(467, 39);
            this.boost1.Name = "boost1";
            this.boost1.Size = new System.Drawing.Size(95, 20);
            this.boost1.TabIndex = 43;
            this.boost1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(425, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 42;
            this.label13.Text = "Boost";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // boost2
            // 
            this.boost2.Location = new System.Drawing.Point(467, 67);
            this.boost2.Name = "boost2";
            this.boost2.Size = new System.Drawing.Size(95, 20);
            this.boost2.TabIndex = 45;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(425, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 13);
            this.label14.TabIndex = 44;
            this.label14.Text = "Boost";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1129, 714);
            this.Controls.Add(this.boost2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.boost1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cbIncludeMax);
            this.Controls.Add(this.cbIncludeMin);
            this.Controls.Add(this.textMaxValue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.comboBoxBool2);
            this.Controls.Add(this.comboBoxBool1);
            this.Controls.Add(this.textMinValue);
            this.Controls.Add(this.textField3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textTerms2);
            this.Controls.Add(this.textField2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textTerms1);
            this.Controls.Add(this.textField1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numericResults);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.linkLabelDidYouMean);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.checkBoxSpellCheck);
            this.Controls.Add(this.checkBoxThesaraus);
            this.Controls.Add(this.textStatus);
            this.Controls.Add(this.textTerms);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.menuStrip2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdNav)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericResults)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textTerms;
        private System.Windows.Forms.TextBox textStatus;
        private System.Windows.Forms.CheckBox checkBoxThesaraus;
        private System.Windows.Forms.CheckBox checkBoxSpellCheck;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel linkLabelDidYouMean;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonNavApply;
        private System.Windows.Forms.TreeView treeViewNav;
        private System.Windows.Forms.DataGridView grdNav;
        private System.Windows.Forms.DataGridViewTextBoxColumn NavName;
        private System.Windows.Forms.DataGridViewTextBoxColumn NavDisplayName;
        private System.Windows.Forms.DataGridViewTextBoxColumn NavCount;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RichTextBox richTextBoxLog;
        private System.Windows.Forms.Button buttonApplyCluster;
        private System.Windows.Forms.TreeView treeViewCluster;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBoxClusters;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TreeView treeViewCatBrowse;
        private System.Windows.Forms.Label labelPageStatus;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.NumericUpDown numericResults;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBoxRefinements;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonNoneNav;
        private System.Windows.Forms.Button buttonAllNav;
        private System.Windows.Forms.TextBox textTerms1;
        private System.Windows.Forms.TextBox textField1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textTerms2;
        private System.Windows.Forms.TextBox textField2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textMinValue;
        private System.Windows.Forms.TextBox textField3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBoxBool1;
        private System.Windows.Forms.ComboBox comboBoxBool2;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox textMaxValue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbIncludeMin;
        private System.Windows.Forms.CheckBox cbIncludeMax;
        private System.Windows.Forms.TextBox boost1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox boost2;
        private System.Windows.Forms.Label label14;

    }
}

