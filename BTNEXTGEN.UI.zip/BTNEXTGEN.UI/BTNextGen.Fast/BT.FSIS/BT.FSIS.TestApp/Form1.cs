﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.ServiceModel;


using BT.FSIS;
using BT.FSIS.WCF;


namespace BT.FSIS.TestApp
{
    public partial class Form1 : Form
    {
        SearchResults m_currentResults = null;
        ISearchExecutor m_searchExecutor = null;
        string m_lastSortKey = null;
        bool m_sortAssending = true;

        private ISearchExecutor GetSearchExecutor(int count, bool useHandlers)
        {
            var url = System.Configuration.ConfigurationManager.AppSettings["SearchExecutorUrl"];

            ISearchExecutor searchExecutor = SearchExecutorFactory.Create(url, count,false);
            searchExecutor.AutoSearch = true;

            if (useHandlers)
            {
                AddHandlers(searchExecutor);
            }
            return searchExecutor;
        }
        
        private ISearchExecutor GetSearchExecutor(string savedSearch, bool useHandlers)
        {
            ISearchExecutor searchExecutor = SearchExecutorFactory.CreateFromSerialized(savedSearch,false);

            if (useHandlers)
            {
                AddHandlers(searchExecutor);
            }
            return searchExecutor;
        }

        private void AddHandlers(ISearchExecutor searchExecutor)
        {
            ICompletedSearchPublisher searchPublisher = (ICompletedSearchPublisher)searchExecutor;
            searchPublisher.AddCompletedSearchHandler(new CompletedSearchHandler(CompletedSearch));

            IBeginSearchPublisher beginSearchPublisher = (IBeginSearchPublisher)searchExecutor;
            beginSearchPublisher.AddBeginSearchHandler(new BeginSearchHandler(BeginSearch));
        }

        private void BeginSearch()
        {
            Cursor.Current = Cursors.WaitCursor;
            UseWaitCursor = true;
        }

        private void CompletedSearch(CompletedSearchEventArgs completedSearchEventArgs)
        {

            dataGridView1.Rows.Clear();
            grdNav.Rows.Clear();
            dataGridView1.Columns.Clear();
            listBoxClusters.Items.Clear();
            treeViewCluster.Nodes.Clear();
            treeViewNav.Nodes.Clear();
            labelPageStatus.Text = string.Empty;
            listBoxRefinements.Items.Clear();

            AutoWaitCursor autoWaitCursor = new AutoWaitCursor(this);

            using (autoWaitCursor)
            {

                if (!completedSearchEventArgs.DidSucceed)
                {
                    textStatus.Text = completedSearchEventArgs.Failure;
                    Log(string.Format("Error: {0}", textStatus.Text));
                    return;
                }

                m_currentResults = completedSearchEventArgs.SearchResults;
                textStatus.Text = string.Format("{0} Results", m_currentResults.DocumentCount);
                Log(textStatus.Text);
                Log(string.Format("Search Time {0}ms", m_currentResults.SearchTime));


                foreach (SearchTransformation tranformation in m_currentResults.SearchTransformations)
                {
                    Log(string.Format("Name: {0}, Search: {1}, MessageID: {3}, Message: {2}", tranformation.Name, tranformation.Search, tranformation.Message, tranformation.MessageId));
                }


                linkLabelDidYouMean.Text = m_currentResults.SpellCheckSuggestion;

                if (m_currentResults.ResultDocuments.Count == 0) return;

                dataGridView1.Columns.Add("Hit", "Hit");
                dataGridView1.Columns.Add("ngtitle", "Title");

                Document firstDoc = m_currentResults.ResultDocuments[0];
                foreach (string s in firstDoc.DocumentFields.Keys)
                {
                    dataGridView1.Columns.Add(s, s);
                }

                dataGridView1.Rows.Add(m_currentResults.ResultDocuments.Count);

                for (int i = 0; i < m_currentResults.ResultDocuments.Count; i++)
                {
                    dataGridView1.Rows[i].Cells["Hit"].Value = i + m_searchExecutor.Offset + 1;
                    var doc = m_currentResults.ResultDocuments[i];
                    foreach (string s in doc.DocumentFields.Keys)
                    {
                        dataGridView1.Rows[i].Cells[s].Value = doc.DocumentFields[s];
                    }
                }

                // Add the navigators
                foreach (BT.FSIS.Navigator nav in m_currentResults.Navigators)
                {
                    //if (!IsCluster(nav))
                    {
                        grdNav.Rows.Add(new object[] { nav.Name, nav.DisplayName, nav.DocumentCount });
                    }
                }


                // Add the clusters
                foreach (Cluster cluster in m_currentResults.Clusters)
                {
                    listBoxClusters.Items.Add(cluster.Name);
                }

                if (listBoxClusters.Items.Count > 0)
                {
                    listBoxClusters.SelectedIndex = 0;
                }

                // Set the status
                labelPageStatus.Text = string.Format("Showing {0}-{1} of {2}", m_searchExecutor.Offset + 1, m_searchExecutor.Offset + (int)numericResults.Value, m_searchExecutor.CurrentResults.DocumentCount);

                // Add the refinements
                foreach (SearchRefinement refinement in m_searchExecutor.Refinements)
                {
                    listBoxRefinements.Items.Add(refinement);
                }
            }
        }

        private bool IsCluster(Navigator nav)
        {
            foreach (Cluster cluster in m_currentResults.Clusters)
            {
                if (nav.Name == cluster.NavigatorName)
                {
                    return true;
                }
            }
            return false;
        }

        public Form1()
        {
            InitializeComponent();
            m_searchExecutor = GetSearchExecutor((int)numericResults.Value, true);
            comboBoxBool1.SelectedIndex = 0;
            comboBoxBool2.SelectedIndex = 0;
           
        }

        internal void Log(string message)
        {
            richTextBoxLog.AppendText("\r\n");
            richTextBoxLog.AppendText(message);
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            grdNav.DataSource = null;

            Search search = null;
            SearchOperator firstOperator = null;
            if (!string.IsNullOrEmpty(textTerms.Text))
            {
                TermsOperator terms = new TermsOperator(textTerms.Text, TermsOperatorMode.All);
                terms.Scopes.Add("ngcontent");
                search = new Search(terms);
                firstOperator = terms;
            }
            else
            {
                RangeOperator sizeOperator = new RangeOperator();
                sizeOperator.Min = 0;
                sizeOperator.Scopes.Add("size");
                search = new Search(sizeOperator);
                firstOperator = sizeOperator;
            }
            
            GroupOperator outsideOperator = new GroupOperator(GroupOperatorType.Or, new List<SearchOperator>(){firstOperator});
            search.SearchOperator = outsideOperator;

            if (!string.IsNullOrEmpty(textField1.Text) && !string.IsNullOrEmpty(textTerms1.Text))
            {
                TermsOperator termsOp = new TermsOperator(textTerms1.Text);
                termsOp.Scopes.Add(textField1.Text);
                int boost = 0;
                int.TryParse(boost1.Text, out boost);
                GroupOperator groupOperator = CreateGroupOperator((string)comboBoxBool1.SelectedItem, termsOp, boost);
                //groupOperator.Operators.Add(firstOperator);
                outsideOperator.Operators.Add(groupOperator);
               

                if (!string.IsNullOrEmpty(textField2.Text) && !string.IsNullOrEmpty(textTerms2.Text))
                {
                    TermsOperator termsOp2 = new TermsOperator(textTerms2.Text);
                    termsOp2.Scopes.Add(textField2.Text);
                    int.TryParse(boost2.Text, out boost);
                    GroupOperator groupOperator2 = CreateGroupOperator((string)comboBoxBool2.SelectedItem, termsOp2, boost);
                    outsideOperator.Operators.Add(groupOperator2);
                }
            }

            if (!string.IsNullOrEmpty(textField3.Text) && (!string.IsNullOrEmpty(textMinValue.Text) || !string.IsNullOrEmpty(textMaxValue.Text)))
            {
                RangeOperator rangeOperator = new RangeOperator();
                rangeOperator.Scopes.Add(textField3.Text);
                if(!string.IsNullOrEmpty(textMinValue.Text))
                {
                    rangeOperator.Min = Double.Parse(textMinValue.Text);
                }
                if(!string.IsNullOrEmpty(textMaxValue.Text))
                {
                    rangeOperator.Max = Double.Parse(textMaxValue.Text);
                }
                rangeOperator.MaxInclusive = cbIncludeMax.Checked;
                rangeOperator.MinInclusive = cbIncludeMin.Checked;
                GroupOperator groupOperator3 = CreateGroupOperator("AND", rangeOperator, 0);
                groupOperator3.Operators.Add(search.SearchOperator);
                outsideOperator.Operators.Add(groupOperator3);
            } 
            
            search.spellCheckType = checkBoxSpellCheck.Checked ? SpellCheckType.Suggest : SpellCheckType.None;
            search.Resubmit.Lemmatization = true;

            m_searchExecutor.DefineSearch(search);
        }

        private GroupOperator CreateGroupOperator(string booleanOperator, SearchOperator searchOperator, int boost)
        {
            GroupOperatorType type = GroupOperatorType.Or;
            if (booleanOperator == "OR")
            {
                type = GroupOperatorType.Or;
            }
            else if (booleanOperator == "AND")
            {
                type = GroupOperatorType.And;
            }
            else if (booleanOperator == "NOT")
            {
                type = GroupOperatorType.And;
                GroupOperator notOperator = new GroupOperator(GroupOperatorType.Not, new List<SearchOperator>(){searchOperator});
                return new GroupOperator(type, new List<SearchOperator>(){notOperator});
            }
            else if (booleanOperator == "XRANK")
            {
                type = GroupOperatorType.Or;
                GroupOperator xrankOperator = new GroupOperator(GroupOperatorType.XRank, new List<SearchOperator>() { searchOperator });
                xrankOperator.Boost = boost;
                return new GroupOperator(type, new List<SearchOperator>() { xrankOperator });
            }
            else
            {
                throw new InvalidOperationException();
            }

            return new GroupOperator(type, new List<SearchOperator>(){searchOperator});
        }

        private void grdNav_SelectionChanged(object sender, EventArgs e)
        {
            treeViewNav.Nodes.Clear();
            DataGridView grid = (DataGridView)sender;
            string navName = (string)grid.CurrentRow.Cells[0].Value;
            foreach (Navigator navigator in m_currentResults.Navigators)
            {
                if (navigator.Name == navName)
                {             
                    foreach( NavigatorGroup navGroup in navigator.NavigatorGroups )
                    {
                        TreeNode treeNode = new TreeNode(string.Format("{0} ({1})",navGroup.Value, navGroup.DocumentCount));
                        treeNode.Tag = navGroup;
                        treeViewNav.Nodes.Add(treeNode);
                    }
                }
            }
        }


        private void buttonNavApply_Click(object sender, EventArgs e)
        {
            GroupRefinement groupRefinement = new GroupRefinement(GroupRefinementType.Or);
            foreach (TreeNode treeNode in treeViewNav.Nodes)
            {
                if (treeNode.Checked && treeNode.Tag != null)
                {
                    NavigatorGroup navGroup = (NavigatorGroup)treeNode.Tag;
                    groupRefinement.Refinements.Add(navGroup.InclustionRefinement);
                }

            }

            if (groupRefinement.Refinements.Count > 0)
            {
                m_searchExecutor.AddRefinement(groupRefinement);
            }
            //ExecuteSearch();
        }

        private void ExecuteSearch()
        {
            m_currentResults = m_searchExecutor.ExecuteSearch(0);

           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void linkLabelDidYouMean_Click(object sender, EventArgs e)
        {
            foreach (ChangeTermRefinement refinemet in m_currentResults.SpellCheckSuggestionRefinement.Refinements)
            {
                m_searchExecutor.AddRefinement(refinemet);
                textTerms.Text = refinemet.ReplacementTerm;
                linkLabelDidYouMean.Text = string.Empty;
            }

            //ExecuteSearch();
        }

        private void checkBoxSpellCheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void listBoxClusters_SelectedIndexChanged(object sender, EventArgs e)
        {

            treeViewCluster.Nodes.Clear();
            ListBox listBox = (ListBox)sender;
            string clusterName = (string)listBox.SelectedItem;

            foreach (Cluster cluster in m_currentResults.Clusters)
            {
                if (cluster.Name == clusterName)
                {
                    TreeNode rootNode = treeViewCluster.Nodes.Add(string.Format("{0} ({1})", cluster.Name, cluster.TotalDocumentCount));

                    foreach (ClusterNode clusterNode in cluster.Nodes)
                    {
                        addClusterNodes(rootNode, clusterNode);
                    }
                    rootNode.ExpandAll();

                    break;
                }

            }

        }

        private void addClusterNodes(TreeNode parentNode, ClusterNode clusterNode)
        {
            TreeNode treeNode = new TreeNode(string.Format("{0} ({1})", clusterNode.Name, clusterNode.TotalDocumentCount));
            treeNode.Tag = clusterNode;
            parentNode.Nodes.Add(treeNode);
            
            foreach(ClusterNode node in clusterNode.SubNodes)
            {
                addClusterNodes(treeNode, node);
            }

        }

        private void buttonApplyCluster_Click(object sender, EventArgs e)
        {
            GroupRefinement groupRefinement = new GroupRefinement(GroupRefinementType.Or);
            applyClusterRefinements(treeViewCluster.Nodes[0], groupRefinement);
            m_searchExecutor.AddRefinement(groupRefinement);
            //ExecuteSearch();
        }

        private void applyClusterRefinements(TreeNode parentNode, GroupRefinement groupRefinement)
        {
           
            foreach (TreeNode treeNode in parentNode.Nodes)
            {
                applyClusterNodeRefinement(treeNode, groupRefinement);
            }

            
        }

        private void applyClusterNodeRefinement(TreeNode treeNode, GroupRefinement groupRefinement)
        {

            if (treeNode.Checked && treeNode.Tag != null)
            {
                ClusterNode clusterNode = (ClusterNode)treeNode.Tag;
                groupRefinement.Refinements.Add(clusterNode.SubtreeInclustionRefinement);
            }

            if (treeNode.Nodes.Count > 0)
            {
                applyClusterRefinements(treeNode, groupRefinement);
            }
        }

        private void applyCategoryNodeRefinement(TreeNode treeNode)
        {

            if (treeNode.Tag != null)
            {
                ClusterNode clusterNode = (ClusterNode)treeNode.Tag;
                m_searchExecutor.AddRefinement(clusterNode.SubtreeInclustionRefinement);
            }
        }
 
        private void tabPage3_Click(object sender, EventArgs e)
        {
           
        }

        private void tabPage3_Enter(object sender, EventArgs e)
        {
            ISearchExecutor searchExecutor = GetSearchExecutor(0, true);

            RangeOperator sizeOperator = new RangeOperator();
            sizeOperator.Min = 0;
            sizeOperator.Scopes.Add("size");

            Search search = new Search(sizeOperator);

            searchExecutor.DefineSearch(search);

            SearchResults results = searchExecutor.ExecuteSearch(0);

            foreach (Cluster cluster in results.Clusters)
            {
                if (cluster.Name == "Subject")
                {
                    TreeNode rootNode = treeViewCatBrowse.Nodes.Add(string.Format("{0} ({1})", cluster.Name, cluster.TotalDocumentCount));

                    foreach (ClusterNode clusterNode in cluster.Nodes)
                    {
                        addClusterNodes(rootNode, clusterNode);
                    }

                    rootNode.ExpandAll();

                    break;
                }

            }
        }

        private void treeViewCatBrowse_Click(object sender, EventArgs e)
        {

        }

        private void treeViewCatBrowse_AfterSelect(object sender, TreeViewEventArgs e)
        {
            RangeOperator sizeOperator = new RangeOperator();
            sizeOperator.Min = 0;
            sizeOperator.Scopes.Add("size");

            Search search = new Search(sizeOperator);

            m_searchExecutor.DefineSearch(search);

            applyCategoryNodeRefinement(((TreeView)sender).SelectedNode);
           
            tabPage1.Select();
            tabPage1.Focus();
            tabControl1.SelectedIndex = 0;
        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            m_searchExecutor.Offset = 0;
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            int offset = m_searchExecutor.CurrentResults.DocumentCount - (int)numericResults.Value;
            m_searchExecutor.Offset = offset < 0 ? 0 : offset;
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            int offset = m_searchExecutor.Offset + (int)numericResults.Value;
            if (offset < m_searchExecutor.CurrentResults.DocumentCount + (int)numericResults.Value)
            {
                m_searchExecutor.Offset = offset;
            }
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            int offset = m_searchExecutor.Offset - (int)numericResults.Value;
            m_searchExecutor.Offset = offset > 0 ? offset : 0;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SearchRefinement refinement = listBoxRefinements.SelectedItem as SearchRefinement;
            if (refinement != null)
            {
                m_searchExecutor.RemoveRefinement(refinement);
            }
        }

        private void buttonAllNav_Click(object sender, EventArgs e)
        {
            GroupRefinement allGroup = new GroupRefinement(GroupRefinementType.Or);
            foreach (TreeNode node in treeViewNav.Nodes)
            {
                NavigatorGroup navGroup = (NavigatorGroup)node.Tag;
                allGroup.Refinements.Add(navGroup.InclustionRefinement);
            }

            m_searchExecutor.AddRefinement(allGroup);
        }

        private void buttonNoneNav_Click(object sender, EventArgs e)
        {
            GroupRefinement allGroup = new GroupRefinement(GroupRefinementType.And);
            foreach (TreeNode node in treeViewNav.Nodes)
            {
                NavigatorGroup navGroup = (NavigatorGroup)node.Tag;
                allGroup.Refinements.Add(navGroup.ExclustionRefinement);
            }

            m_searchExecutor.AddRefinement(allGroup);
        }

        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewColumn column = dataGridView1.Columns[e.ColumnIndex];
            string sortKey = null;
            if(m_lastSortKey == null || m_lastSortKey != column.Name)
            {
                sortKey =  string.Format("+{0}", column.Name);
                m_sortAssending = true;
            }
            else if(m_sortAssending)
            {
                sortKey =  string.Format("-{0}", column.Name);
                m_sortAssending = !m_sortAssending;
            }
            else
            {
                sortKey =  string.Format("+{0}", column.Name);
                m_sortAssending = !m_sortAssending;
            }

            m_lastSortKey = column.Name;

            m_searchExecutor.AddRefinement(m_currentResults.GetChangeSortRefinement(new string[] {sortKey} ));
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.AddExtension = true;
            saveFileDialog.CheckPathExists = true;
            saveFileDialog.DefaultExt = ".search";
            if (DialogResult.OK == saveFileDialog.ShowDialog())
            {
                using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName, false))
                {
                    sw.Write(m_searchExecutor.Serialize());
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.AddExtension = true;
            openFileDialog.DefaultExt = ".search";
            if (DialogResult.OK == openFileDialog.ShowDialog())
            {
                using (StreamReader sr = new StreamReader(openFileDialog.FileName))
                {
                    m_searchExecutor = GetSearchExecutor(sr.ReadToEnd(), true);
                    m_searchExecutor.ExecuteSearch(0);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            while (m_searchExecutor.CurrentResults == null || !m_searchExecutor.CurrentResults.HasErrors)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < (int)numericUpDown1.Value; i++)
                {
                    sb.Append("0001971735");
                    sb.Append(" ");
                }

                textField1.Text = "ngbtkey";
                textTerms1.Text = sb.ToString();

                buttonSearch_Click(sender, e);

                numericUpDown1.Value += numericUpDown1.Increment;
            }
        }

        private void comboBoxBool1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

    class AutoWaitCursor : IDisposable
    {
        Control m_control;

        internal AutoWaitCursor(Control control)
        {
            m_control = control;
        }

        ~AutoWaitCursor()
        {
            m_control.UseWaitCursor = false;
        }

        public void Dispose()
        {
            m_control.UseWaitCursor = false;
            GC.SuppressFinalize(this);
        }
    }
}