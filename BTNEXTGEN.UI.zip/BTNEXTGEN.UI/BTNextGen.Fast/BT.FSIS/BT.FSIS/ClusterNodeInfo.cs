﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ClusterNodeInfo
    {
        string m_displayName;
        string m_sortKey;

        internal ClusterNodeInfo(string displayName, string sortKey)
        {
            m_displayName = displayName;
            m_sortKey = sortKey;
        }

        public string DisplayName { get { return m_sortKey; } }
        public string SortKey { get { return m_sortKey; } }
    }
}
