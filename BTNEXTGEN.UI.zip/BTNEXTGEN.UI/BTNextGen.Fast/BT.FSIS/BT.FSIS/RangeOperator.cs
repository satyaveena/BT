﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;
using System.Globalization;

namespace BT.FSIS
{
    public class RangeOperator : SearchOperator
    {
        object m_max;
        object m_min;

        public string ToFQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Join(":", Scopes.ToArray()));
            sb.Append(':');
            sb.Append("range(");

            if (Min == null)
            {
                sb.Append("min,");
            }
            else
            {
                if (Min is DateTime)
                {
                    sb.Append(string.Format("{0:yyyy-MM-dd}", Min));
                }
                else if (Min is Double)
                {
                    Double min;
                    Double.TryParse(Min.ToString(), out min);
                    sb.Append(min.ToString("F4", CultureInfo.InvariantCulture));
                }
                else
                {
                    sb.Append(Min.ToString());
                }
                sb.Append(',');
            }


            if (Max == null)
            {
                sb.Append("max");
            }
            else
            {
                if (Max is DateTime)
                {
                    sb.Append(string.Format("{0:yyyy-MM-dd}", Max));
                }
                else if (Max is Double)
                {
                    Double max;
                    Double.TryParse(Max.ToString(), out max);
                    sb.Append(max.ToString("F4", CultureInfo.InvariantCulture));

                }
                else
                {
                    sb.Append(Max.ToString());
                }
            }

           

            if (MinInclusive)
            {
                sb.Append(",from=\"GE\"");
            }

            if (MaxInclusive)
            {
                sb.Append(",to=\"LE\"");
            }

            sb.Append(")");

            return sb.ToString();
        }

        public ImsRangeOperator ToImsRangeOperator()
        {
            ImsRangeOperator imsRangeOperator = new ImsRangeOperator()
            {
                Scopes = this.Scopes,
                ReturnScope = this.ReturnScope,
                Source = this.Source,
            };

            if (Max != null && Max is Int32)
            {
                imsRangeOperator.SetMaximum((Int32)Max);
            }

            if (Max != null && Max is DateTime)
            {
                imsRangeOperator.SetMaximum((DateTime)Max);
            }

            if (Max != null && Max is Double)
            {
                imsRangeOperator.SetMaximum((Double)Max);
            }

            if (Min != null && Min is Int32)
            {
                imsRangeOperator.SetMinimum((Int32)Min);
            }

            if (Min != null && Min is DateTime)
            {
                imsRangeOperator.SetMinimum((DateTime)Min);
            }

            if (Min != null && Min is Double)
            {
                imsRangeOperator.SetMinimum((Double)Min);
            }

            imsRangeOperator.MinInclusive = this.MinInclusive;
            imsRangeOperator.MaxInclusive = this.MaxInclusive;

            return imsRangeOperator;
        }

        public bool MinInclusive { get; set; }
        public bool MaxInclusive { get; set; }

        public object Max 
        {
            get
            {
                return m_max;
            }
                
            set 
            {
                if(value is Int32 || value is DateTime || value is Double)
                {
                    if(Min != null && Min is Int32 && (value is DateTime || value is Double))
                    {
                        throw new ArgumentException("Min has been set to a DateTime.  Please use the same type.");
                    }
                    if (Min != null && Min is DateTime && (value is Int32 || value is Double))
                    {
                        throw new ArgumentException("Min has been set to an Int32.  Please use the same type.");
                    }
                    if (Min != null && Min is Double && (value is Int32 || value is DateTime))
                    {
                        throw new ArgumentException("Min has been set to an Double.  Please use the same type.");
                    }
                    m_max = value;
                }
                else
                {
                    throw new ArgumentException("Incompatible type used.  Type must be DateTime or Int32.");
                }
            } 
        }

        public object Min
        {
            get
            {
                return m_min;
            }

            set
            {
                if (value is Int32 || value is DateTime || value is Double)
                {
                    if (Max != null && Max is Int32 && (value is DateTime || value is Double))
                    {
                        throw new ArgumentException("Max has been set to a DateTime.  Please use the same type.");
                    }
                    if (Max != null && Max is DateTime && (value is Int32 || value is Double))
                    {
                        throw new ArgumentException("Max has been set to an Int32.  Please use the same type.");
                    }
                    if (Max != null && Max is Double && (value is DateTime || value is Int32))
                    {
                        throw new ArgumentException("Max has been set to an Double.  Please use the same type.");
                    }
                    m_min = value;
                }
                else
                {
                    throw new ArgumentException("Incompatible type used.  Type must be DateTime or Int32.");
                }
            }
        }

        protected override void ChangeTerm(ChangeTermRefinement changeRefinement)
        {
            return;
        }

        protected override void ChangeOperator(ChangeSearchOperatorRefinment changeOperatorRefinement)
        {
            return;
        }
    }
}
