﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public delegate void BeginSearchHandler();

    public interface IBeginSearchPublisher
    {
        void AddBeginSearchHandler(BeginSearchHandler beginSearchHandler);
        void RemoveBeginSearchHandler(BeginSearchHandler beginSearchHandler);
    }
}
