﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ClusterNodeRefinement : SearchRefinement
    {
        public ClusterNodeRefinement() : base(true, true) { }

        public ClusterNodeRefinement(string clusterName, string field, string clusterNodePath, bool exact, bool include )
            : base(true, true)
        {
            ClusterName = clusterName;
            ClusterNodePath = clusterNodePath;
            Exact = exact;
            Field = field;
            Include = include;
        }

        public string ClusterName { get; set; }
        public string ClusterNodePath { get; set; }
        public bool Exact { get; set; }
        public string Field { get; set; }
        public bool Include { get; set; }

        override internal SearchOperator SearchOperator
        {
            get
            {
                BoundaryOperator searchOperator = new BoundaryOperator(ClusterNodePath, Exact ? BoundaryOperatorMode.Exact : BoundaryOperatorMode.Start);
                searchOperator.Scopes.Add(Field);
                if (!Include)
                {
                    return new GroupOperator(GroupOperatorType.Not, new List<SearchOperator>{searchOperator});
                }

                return searchOperator;
            }
        }

        public override string ToString()
        {
            return ClusterNodePath;
        }
    }
}
