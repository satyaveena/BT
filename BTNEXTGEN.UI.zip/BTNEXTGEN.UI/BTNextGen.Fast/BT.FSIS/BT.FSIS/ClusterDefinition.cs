﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Xml.Serialization;


namespace BT.FSIS
{
    
    public delegate ClusterNodeInfo NameTranslatorDelegate(string path);

    public enum ClusterSort
    {
        Alpha,
        HitCount
    }

    public class ClusterDefinition
    {
        internal ClusterDefinition() { }

        public ClusterDefinition(string name, string navigator, ClusterSort sort)
        {
            Name = name;
            Navigator = navigator;
            Sort = sort;
        }

        public ClusterDefinition(string name, string navigator)
        {
            Name = name;
            Navigator = navigator;
        }

        public string Name { get; set; }
        public string Navigator { get; set; }
    
        [XmlIgnoreAttribute()]
        public NameTranslatorDelegate NameTranslator{get; set;}

        [DefaultValue('/')]
        public char PathSeparator { get; set; }
        public string Field { get; set; }

        public ClusterSort Sort { get; set; }

    }
}
