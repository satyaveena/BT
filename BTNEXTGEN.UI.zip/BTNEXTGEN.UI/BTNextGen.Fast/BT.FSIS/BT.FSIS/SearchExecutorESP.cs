﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml;

using System.ServiceModel;
using System.Net;
using System.Xml.Linq;
using System.Xml.Serialization;

using Com.FastSearch.Esp.Search.Http;
using Com.FastSearch.Esp.Search.Navigation;
using Com.FastSearch.Esp.Search.Query;
using Com.FastSearch.Esp.Search.Result;
using Com.FastSearch.Esp.Search.View;
using Com.FastSearch.Esp.Search;

namespace BT.FSIS.ESP
{
    public class SearchExecutorESP : ISearchExecutor, IBeginSearchPublisher, ICompletedSearchPublisher
    {
        private List<SearchRefinement> m_refinements;
        private bool m_searching = false;
        private event CompletedSearchHandler m_completedSearchEvent;
        private event BeginSearchHandler m_beginSearchEvent;
        private object m_lock = new object();
        private FindSimilarRefinement m_findSimilarRefinement;
        private List<ClusterDefinition> m_clusterDefs;
        private Navigation m_navigation;
        private Search m_currentSearch;
        private int m_offset;

        private static Dictionary<string, ISearchView> m_viewCache = new Dictionary<string, ISearchView>();

        public SearchExecutorESP()
        {
            m_refinements = new List<SearchRefinement>();
            m_currentSearch = new Search();
        }

        public SearchExecutorESP(string path, int count, IList<ClusterDefinition> clusterDefs, Navigation navigation)
        {
            WDMUrl = path;
           
            Count = count;
            m_refinements = new List<SearchRefinement>();
            m_clusterDefs = (List<ClusterDefinition>)clusterDefs;
            m_navigation = navigation; 
        }

        private static ISearchView GetSearchView(string view)
        {
            lock (m_viewCache)
            {
                if (!m_viewCache.ContainsKey(view))
                {
                    ISearchFactory searchFactory = SearchFactory.NewInstance(ConfigurationManager.AppSettings);
                    ISearchView searchView = searchFactory.GetSearchView(view);
                    m_viewCache.Add(view, searchView);
                }

                return m_viewCache[view];
            }
        }

        public string WDMUrl { get; set; }
        public SearchResults ExecuteSearch(int offset)
        {
            return ExecuteSearch(this, offset);
        }

        public void DefineSearch(Search search)
        {
            m_refinements.Clear(); 
            CurrentSearch = search;
        }

        public bool AutoSearch
        {
            get;
            set;
        }

        public int Offset
        {
            get
            {
                return m_offset;
            }

            set
            {
                m_offset = value;
                if (AutoSearch)
                {
                    ExecuteSearch(m_offset);
                }
            }
        }


        public bool IsSearching
        {
            get { return m_searching; }
        }

        public void RemoveRefinement(SearchRefinement refinement)
        {
            m_refinements.Remove(refinement);
            if (AutoSearch)
            {
                ExecuteSearch(0);
            }
        }

        public void AddRefinement(SearchRefinement[] refinements)
        {
            foreach(SearchRefinement refinement in refinements)
            {
                AddRefinement(refinement);
            }
        }

        public List<SearchRefinement> Refinements
        {
            get { return m_refinements; }
            set { m_refinements = value; }
        }

        public void AddRefinement(SearchRefinement refinement)
        {

            // Store the refinement in the refinements list if it is groupable. (NavigatorGroupRefinement, ClusterNodeRefinement, GroupRefinement)
            if (refinement.CanBeGrouped) 
            {
                m_refinements.Add(refinement);
            }
            else if (refinement is FindSimilarRefinement)
            {
                if (this.m_findSimilarRefinement != null) 
                {
                    m_refinements.Remove(m_findSimilarRefinement);
                }
                m_findSimilarRefinement = (FindSimilarRefinement)refinement;
                m_refinements.Add(refinement);
            }
            else if (refinement is ChangeTermRefinement) 
            {
                ChangeTermRefinement changeTermRefinement = (ChangeTermRefinement)refinement;
                CurrentSearch.SearchOperator.ApplyChangeTermRefinement(changeTermRefinement);
            }
            else if (refinement is SpellCheckSuggestionRefinement)
            {
                SpellCheckSuggestionRefinement spellRefinement = (SpellCheckSuggestionRefinement)refinement;
                foreach(ChangeTermRefinement changeRefinement in spellRefinement.Refinements)
                {
                    CurrentSearch.SearchOperator.ApplyChangeTermRefinement(changeRefinement);
                }
            }
            else if (refinement is ChangeSearchOperatorRefinment) 
            {
                ChangeSearchOperatorRefinment changeOperatorRefinement = (ChangeSearchOperatorRefinment)refinement;
                if (changeOperatorRefinement.TargetSearchOperator == CurrentSearch.SearchOperator) 
                {
                    if (changeOperatorRefinement.ReplacementSearchOperator != null) 
                    {
                        CurrentSearch.SearchOperator = changeOperatorRefinement.ReplacementSearchOperator;
                    }
                    else 
                    {
                        throw new ArgumentNullException("ReplacementSearchOperator: The default search operator cannot be removed.");
                    }
                }
                else 
                {
                    CurrentSearch.SearchOperator.ApplyChangeOperatorRefinement(changeOperatorRefinement);
                }
            }
            else if (refinement is AddSearchOperatorRefinement) 
            {
                CurrentSearch.SearchOperator = CurrentSearch.AddOperator(((ChangeSearchOperatorRefinment)refinement).TargetSearchOperator, ((ChangeSearchOperatorRefinment)refinement).ReplacementSearchOperator);
            }
            else if (refinement is ChangeSortRefinement)
            {
                CurrentSearch.SortElements = ((ChangeSortRefinement)refinement).SortElements;
            }

            if (AutoSearch)
            {
                ExecuteSearch(0);
            }

        }

        public bool IsRefinementAdded(SearchRefinement refinement, bool lookInGroups)
        {
            //Todo: Look in groups.
            bool found = m_refinements.Contains(refinement);
            
            if (!found && lookInGroups)
            {
                foreach(SearchRefinement aRefinement in m_refinements)
                {
                    if(aRefinement is GroupRefinement)
                    {
                        found = IsRefinementAdded(aRefinement as GroupRefinement, refinement);
                    }
                }
            }
            
            return found;
        }

        private bool IsRefinementAdded(GroupRefinement groupRefinement, SearchRefinement searchRefinement)
        {
            bool found = false;
            foreach (SearchRefinement aRefinement in groupRefinement.Refinements)
            {
                found = groupRefinement.Refinements.Contains(searchRefinement);
                if (!found && aRefinement is GroupRefinement)
                {
                    found = IsRefinementAdded(aRefinement as GroupRefinement, searchRefinement);
                }

                if (found)
                {
                    break;
                }
            }

            return found;
        }

        public void AddCompletedSearchHandler(CompletedSearchHandler beginSearchHandler)
        {
            m_completedSearchEvent += beginSearchHandler;
        }

        public void RemoveCompletedSearchHandler(CompletedSearchHandler beginSearchHandler)
        {
            m_completedSearchEvent -= beginSearchHandler;
        }

        public void AddBeginSearchHandler(BeginSearchHandler beginSearchHandler)
        {
            m_beginSearchEvent += beginSearchHandler;
        }

        public void RemoveBeginSearchHandler(BeginSearchHandler beginSearchHandler)
        {
            m_beginSearchEvent -= beginSearchHandler;
        }

        private void RaiseBeginSearch()
        {
            if (m_beginSearchEvent != null)
            {
                m_beginSearchEvent();
            }
        }

        private void RaiseCompletedSearch(bool succeeded, string error, SearchResults searchResults)
        {
            if (m_completedSearchEvent != null)
            {
                m_completedSearchEvent(new CompletedSearchEventArgs(succeeded, error, searchResults));
            }
        }


        //public IList<string> Fields
        //{
        //    get
        //    {
        //        Search search = new Search(
        //    }
        //}

        static SearchResults ExecuteSearch(SearchExecutorESP searchExecutor, int offset)
        {
            lock (searchExecutor.m_lock)
            {
                Search search = searchExecutor.CurrentSearch.Clone();

                // Get the refinements added to the search.
                GroupOperator refinementGroup = null;
                if (searchExecutor.m_refinements.Count > 0)
                {
                    refinementGroup = new GroupOperator(GroupOperatorType.And);
                  
                    foreach (SearchRefinement refinement in searchExecutor.m_refinements)
                    {
                        refinementGroup.Operators.Add(refinement.SearchOperator);
                    }

                    refinementGroup.Operators.Add(search.SearchOperator);

                    search.SearchOperator = refinementGroup;
                }
                try
                {
                    searchExecutor.m_searching = true;
                    searchExecutor.RaiseBeginSearch();

                    IQuery query = search.ToIQuery();

                    query.SetParameter(new SearchParameter(BaseParameter.HITS, searchExecutor.Count));
                    query.SetParameter(new SearchParameter(BaseParameter.OFFSET, offset));

                    ISearchView searchView = SearchExecutorESP.GetSearchView(search.ResultView);
                    IQueryResult queryResult = searchView.Search(query);


                    searchExecutor.CurrentResults = new SearchResults(queryResult, null, searchExecutor.m_clusterDefs);

                    searchExecutor.RaiseCompletedSearch(true, string.Empty, searchExecutor.CurrentResults);
                    //if (!responseContext.HasErrors())
                    //{
                    //    searchExecutor.CurrentResults = new SearchResults(resultGroup.ResultsList[0], null, searchExecutor.m_clusterDefs);
                    //    searchExecutor.RaiseCompletedSearch(true, string.Empty, searchExecutor.CurrentResults);

                    //}
                    //else
                    //{
                    //    StringBuilder errors = new StringBuilder();
                    //    foreach (XElement element in responseContext.GetErrors())
                    //    {
                    //        errors.AppendLine(element.Value);
                    //    }

                    //    searchExecutor.RaiseCompletedSearch(false, errors.ToString(), null);

                    //    searchExecutor.CurrentResults = new SearchResults(null, errors.ToString(), null);
                    //}

                    
                }
                catch (Exception e)
                {
                    var errorMsg = e.Message;
                    try
                    {
                        errorMsg += "\r\nFQL:\r\n" + search.SearchOperator.ToFQL();
                    }
                    catch
                    {
                    }

                    searchExecutor.RaiseCompletedSearch(false, errorMsg, null);
                    searchExecutor.CurrentResults = new SearchResults(errorMsg);
                }
                finally
                {
                    searchExecutor.m_searching = false;
                }
            }

            return searchExecutor.CurrentResults;
        }


        public IAsyncResult BeginExecuteSearch(int offset, ref SearchResults searchResults, AsyncCallback callback, object state)
        {
            throw new NotImplementedException();
        }

        public bool EndExecuteSearch(ref SearchResults searchResults, IAsyncResult asyncResult)
        {
            throw new NotImplementedException();
        }

        [XmlIgnoreAttribute()]
        public SearchResults CurrentResults
        {
            get; 
            private set;
        }

        public Search CurrentSearch
        {
            get
            {
                return m_currentSearch;
            }
                
            set
            {
                m_currentSearch = value;
                if (AutoSearch)
                {
                    ExecuteSearch(0);
                }
            }
        }

        public int Count
        {
            get;
            set;
        }

        public List<ClusterDefinition> Clusters
        {
            get { return m_clusterDefs; }
            set { m_clusterDefs = value; }
        }

        public Navigation SearchNavigation
        {
            get { return m_navigation; }
            set { m_navigation = value; }
        }

        public FindSimilarRefinement FindSimilarRefinement
        {
            get { return m_findSimilarRefinement; }
            set { m_findSimilarRefinement = value; }
        }

        public string Serialize()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(SearchExecutorESP));
            TextWriter textWriter = new StringWriter();
            serializer.Serialize(textWriter, this);

            return textWriter.ToString();
        }     
    }
}
