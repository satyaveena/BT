﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class NavigatorGroupRefinement : SearchRefinement
    {

        public NavigatorGroupRefinement() { }

        public NavigatorGroupRefinement(bool canBeRemoved, bool include, NavigatorGroup navigatorGroup)
            : base(canBeRemoved, true)
        {
            Include = include;
            Scopes = GetFieldsListFromScopeField(navigatorGroup.FieldName);
            FieldType = navigatorGroup.NavigatorType;
            Value = navigatorGroup.Value;
            MinValue = navigatorGroup.MinValue;
            MaxValue = navigatorGroup.MaxValue;
        }

        public bool Include { get; set; }

        private static List<string> GetFieldsListFromScopeField(string field)
        {
            string[] fields = field.Split(':');
            string lastField = fields[fields.Length - 1];
            int index = lastField.IndexOf('@');

            if (index != -1)
            {
                List<string> theList = new List<string>(fields);
                theList.RemoveAt(fields.Length - 1);
                theList.Add(lastField.Substring(0, index));
                theList.Add(lastField.Substring(index));
                return theList;
            }

            return new List<string>(fields);
        }

        public List<string> Scopes { get; set; }
        public FieldType FieldType { get; set; }
        public Object MinValue { get; set; }
        public Object MaxValue { get; set; }
        public string Value { get; set; }

        override internal SearchOperator SearchOperator
        {
            get
            {
               
                SearchOperator searchOperator = null;

                if (FieldType == FieldType.String)
                {
                    string fieldValue = Value;
                    bool startsWith = false;
                    bool endsWith = false;
                    if (fieldValue[0] == '^')
                    {
                        startsWith = true;
                        fieldValue = fieldValue.Substring(1);
                    }
                    if (fieldValue[fieldValue.Length - 1] == '$')
                    {
                        endsWith = true;
                        fieldValue = fieldValue.Substring(0, fieldValue.Length - 1);
                    }
                    if (fieldValue[0] == '"' && fieldValue[fieldValue.Length - 1] == '"')
                    {
                        fieldValue = fieldValue.Substring(1, fieldValue.Length - 1);
                    }


                    if (startsWith && endsWith)
                    {
                        searchOperator = new BoundaryOperator(fieldValue, BoundaryOperatorMode.Exact);
                    }
                    else if (startsWith)
                    {
                        searchOperator = new BoundaryOperator(fieldValue, BoundaryOperatorMode.Start);
                    }
                    else if (endsWith)
                    {
                        searchOperator = new BoundaryOperator(fieldValue, BoundaryOperatorMode.End);
                    }
                    else
                    {
                        searchOperator = new PhraseOperator(fieldValue);
                    }

                    searchOperator.Scopes = Scopes;
                }
                else
                {
                    RangeOperator rangeOperator = new RangeOperator();
                    rangeOperator.Min = MinValue;
                    rangeOperator.Max = MaxValue;
                    rangeOperator.MinInclusive = true;
                    rangeOperator.MaxInclusive = (FieldType != FieldType.Double);
                    rangeOperator.Scopes = Scopes;
                    searchOperator = rangeOperator;
                }
                if (!Include)
                {
                    GroupOperator groupOperator = new GroupOperator(GroupOperatorType.Not);
                    groupOperator.Operators.Add(searchOperator);
                    searchOperator = groupOperator; 
                }
                return searchOperator;
            }
        }

        public override string ToString()
        {
            return Value;
        }
    }
}