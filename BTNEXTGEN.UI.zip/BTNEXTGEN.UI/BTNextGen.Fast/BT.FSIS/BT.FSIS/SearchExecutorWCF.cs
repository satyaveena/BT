﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml;

using System.ServiceModel;
using System.Net;
using System.Xml.Linq;

using Microsoft.Ceres.InteractionEngine.Services;
using Microsoft.Ceres.InteractionEngine.Services.Admin;
using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;
using Microsoft.Ceres.InteractionEngine.Tools.ProcessingEngineApi;
using Microsoft.Ceres.InteractionUI.WdmPlugIns;
using System.Xml.Serialization;

namespace BT.FSIS.WCF
{
    public class SearchExecutorWCF : ISearchExecutor, IBeginSearchPublisher, ICompletedSearchPublisher
    {
        private Context m_imsContext = new Context();
        private List<SearchRefinement> m_refinements;
        private bool m_searching = false;
        private event CompletedSearchHandler m_completedSearchEvent;
        private event BeginSearchHandler m_beginSearchEvent;
        private object m_lock = new object();
        private FindSimilarRefinement m_findSimilarRefinement;
        private List<ClusterDefinition> m_clusterDefs;
        private Navigation m_navigation;
        private Search m_currentSearch;
        private int m_offset;

        public SearchExecutorWCF()
        {
            m_refinements = new List<SearchRefinement>();
            m_currentSearch = new Search();
        }

        public SearchExecutorWCF(string path, int count, IList<ClusterDefinition> clusterDefs, Navigation navigation)
        {
            WDMUrl = path;

            Count = count;
            m_refinements = new List<SearchRefinement>();
            m_clusterDefs = (List<ClusterDefinition>)clusterDefs;
            m_navigation = navigation;
        }

        public string WDMUrl { get; set; }
        public SearchResults ExecuteSearch(int offset)
        {
            return ExecuteSearch(this, offset);
        }

        public void DefineSearch(Search search)
        {
            m_refinements.Clear();
            CurrentSearch = search;
        }

        public bool AutoSearch
        {
            get;
            set;
        }

        public int Offset
        {
            get
            {
                return m_offset;
            }

            set
            {
                m_offset = value;
                if (AutoSearch)
                {
                    ExecuteSearch(m_offset);
                }
            }
        }


        public bool IsSearching
        {
            get { return m_searching; }
        }

        public void RemoveRefinement(SearchRefinement refinement)
        {
            m_refinements.Remove(refinement);
            if (AutoSearch)
            {
                ExecuteSearch(0);
            }
        }

        public void AddRefinement(SearchRefinement[] refinements)
        {
            foreach (SearchRefinement refinement in refinements)
            {
                AddRefinement(refinement);
            }
        }

        public List<SearchRefinement> Refinements
        {
            get { return m_refinements; }
            set { m_refinements = value; }
        }

        public void AddRefinement(SearchRefinement refinement)
        {

            // Store the refinement in the refinements list if it is groupable. (NavigatorGroupRefinement, ClusterNodeRefinement, GroupRefinement)
            if (refinement.CanBeGrouped)
            {
                m_refinements.Add(refinement);
            }
            else if (refinement is FindSimilarRefinement)
            {
                if (this.m_findSimilarRefinement != null)
                {
                    m_refinements.Remove(m_findSimilarRefinement);
                }
                m_findSimilarRefinement = (FindSimilarRefinement)refinement;
                m_refinements.Add(refinement);
            }
            else if (refinement is ChangeTermRefinement)
            {
                ChangeTermRefinement changeTermRefinement = (ChangeTermRefinement)refinement;
                CurrentSearch.SearchOperator.ApplyChangeTermRefinement(changeTermRefinement);
            }
            else if (refinement is SpellCheckSuggestionRefinement)
            {
                SpellCheckSuggestionRefinement spellRefinement = (SpellCheckSuggestionRefinement)refinement;
                foreach (ChangeTermRefinement changeRefinement in spellRefinement.Refinements)
                {
                    CurrentSearch.SearchOperator.ApplyChangeTermRefinement(changeRefinement);
                }
            }
            else if (refinement is ChangeSearchOperatorRefinment)
            {
                ChangeSearchOperatorRefinment changeOperatorRefinement = (ChangeSearchOperatorRefinment)refinement;
                if (changeOperatorRefinement.TargetSearchOperator == CurrentSearch.SearchOperator)
                {
                    if (changeOperatorRefinement.ReplacementSearchOperator != null)
                    {
                        CurrentSearch.SearchOperator = changeOperatorRefinement.ReplacementSearchOperator;
                    }
                    else
                    {
                        throw new ArgumentNullException("ReplacementSearchOperator: The default search operator cannot be removed.");
                    }
                }
                else
                {
                    CurrentSearch.SearchOperator.ApplyChangeOperatorRefinement(changeOperatorRefinement);
                }
            }
            else if (refinement is AddSearchOperatorRefinement)
            {
                CurrentSearch.SearchOperator = CurrentSearch.AddOperator(((ChangeSearchOperatorRefinment)refinement).TargetSearchOperator, ((ChangeSearchOperatorRefinment)refinement).ReplacementSearchOperator);
            }
            else if (refinement is ChangeSortRefinement)
            {
                CurrentSearch.SortElements = ((ChangeSortRefinement)refinement).SortElements;
            }

            if (AutoSearch)
            {
                ExecuteSearch(0);
            }

        }

        public bool IsRefinementAdded(SearchRefinement refinement, bool lookInGroups)
        {
            //Todo: Look in groups.
            bool found = m_refinements.Contains(refinement);

            if (!found && lookInGroups)
            {
                foreach (SearchRefinement aRefinement in m_refinements)
                {
                    if (aRefinement is GroupRefinement)
                    {
                        found = IsRefinementAdded(aRefinement as GroupRefinement, refinement);
                    }
                }
            }

            return found;
        }

        private bool IsRefinementAdded(GroupRefinement groupRefinement, SearchRefinement searchRefinement)
        {
            bool found = false;
            foreach (SearchRefinement aRefinement in groupRefinement.Refinements)
            {
                found = groupRefinement.Refinements.Contains(searchRefinement);
                if (!found && aRefinement is GroupRefinement)
                {
                    found = IsRefinementAdded(aRefinement as GroupRefinement, searchRefinement);
                }

                if (found)
                {
                    break;
                }
            }

            return found;
        }

        public void AddCompletedSearchHandler(CompletedSearchHandler beginSearchHandler)
        {
            m_completedSearchEvent += beginSearchHandler;
        }

        public void RemoveCompletedSearchHandler(CompletedSearchHandler beginSearchHandler)
        {
            m_completedSearchEvent -= beginSearchHandler;
        }

        public void AddBeginSearchHandler(BeginSearchHandler beginSearchHandler)
        {
            m_beginSearchEvent += beginSearchHandler;
        }

        public void RemoveBeginSearchHandler(BeginSearchHandler beginSearchHandler)
        {
            m_beginSearchEvent -= beginSearchHandler;
        }

        private void RaiseBeginSearch()
        {
            if (m_beginSearchEvent != null)
            {
                m_beginSearchEvent();
            }
        }

        private void RaiseCompletedSearch(bool succeeded, string error, SearchResults searchResults)
        {
            if (m_completedSearchEvent != null)
            {
                m_completedSearchEvent(new CompletedSearchEventArgs(succeeded, error, searchResults));
            }
        }


        //public IList<string> Fields
        //{
        //    get
        //    {
        //        Search search = new Search(
        //    }
        //}

        static SearchResults ExecuteSearch(SearchExecutorWCF searchExecutor, int offset)
        {
            lock (searchExecutor.m_lock)
            {
                Search search = searchExecutor.CurrentSearch;

                // Get the refinements added to the search.
                GroupOperator refinementGroup = null;
                if (searchExecutor.m_refinements.Count > 0)
                {
                    refinementGroup = new GroupOperator(GroupOperatorType.And);

                    foreach (SearchRefinement refinement in searchExecutor.m_refinements)
                    {
                        refinementGroup.Operators.Add(refinement.SearchOperator);
                    }

                    refinementGroup.Operators.Add(search.SearchOperator);
                }
                try
                {
                    searchExecutor.m_searching = true;
                    searchExecutor.RaiseBeginSearch();

                    Context context = new Context();
                    ImsSearch imsSearch = search.ToImsSearch();

                    if (refinementGroup != null)
                    {
                        imsSearch.SearchOperator = refinementGroup.ToImsGroupOperator();
                    }

                    imsSearch.Count = searchExecutor.Count;
                    imsSearch.Offset = offset;

                    if (search.Navigation != null)
                    {
                        imsSearch.Navigation = searchExecutor.m_navigation.ToImsNavigation();
                    }

                 
                    context.Root.Add(imsSearch.Element);

                   
                    //bool valid = context.ValidateAll();

                    string wdmURL = searchExecutor.WDMUrl;
                    if (wdmURL == null || wdmURL.Length == 0)
                    {
                        wdmURL = ConfigurationManager.AppSettings["WDMUrl"];
                    }
                   

                    WebClient client = new WebClient();
                    MemoryStream memStream = new MemoryStream();
                    XmlWriter xmlWriter = XmlWriter.Create(memStream);
                    context.WriteTo(xmlWriter);
                    xmlWriter.Flush();

                    Byte[] response = client.UploadData(wdmURL, memStream.ToArray());

                    memStream = new MemoryStream(response);

                    Context responseContext = Context.Parse(new StreamReader(memStream).ReadToEnd());

                            
                    ImsSearchResultsGroup resultGroup = responseContext.Root;
                    if (!responseContext.HasErrors())
                    {
                        searchExecutor.CurrentResults = new SearchResults(resultGroup.ResultsList[0], null, searchExecutor.m_clusterDefs);
                        searchExecutor.RaiseCompletedSearch(true, string.Empty, searchExecutor.CurrentResults);
 
                    }
                    else
                    {
                        StringBuilder errors = new StringBuilder();
                        foreach (XElement element in responseContext.GetErrors())
                        {
                            errors.AppendLine(element.Value);
                        }
                       
                        searchExecutor.RaiseCompletedSearch(false, errors.ToString(), null);

                        searchExecutor.CurrentResults = new SearchResults(errors.ToString());
                    }
                   
                }
                catch (Exception e)
                {
                    searchExecutor.RaiseCompletedSearch(false, e.Message, null);
                    searchExecutor.CurrentResults = new SearchResults(e.Message);
                }
                finally
                {
                    searchExecutor.m_searching = false;
                }
            }

            return searchExecutor.CurrentResults;
        }


        public IAsyncResult BeginExecuteSearch(int offset, ref SearchResults searchResults, AsyncCallback callback, object state)
        {
            throw new NotImplementedException();
        }

        public bool EndExecuteSearch(ref SearchResults searchResults, IAsyncResult asyncResult)
        {
            throw new NotImplementedException();
        }

        [XmlIgnoreAttribute()]
        public SearchResults CurrentResults
        {
            get;
            private set;
        }

        public Search CurrentSearch
        {
            get
            {
                return m_currentSearch;
            }

            set
            {
                m_currentSearch = value;
                if (AutoSearch)
                {
                    ExecuteSearch(0);
                }
            }
        }

        public int Count
        {
            get;
            set;
        }

        public List<ClusterDefinition> Clusters
        {
            get { return m_clusterDefs; }
            set { m_clusterDefs = value; }
        }

        public Navigation SearchNavigation
        {
            get { return m_navigation; }
            set { m_navigation = value; }
        }

        public FindSimilarRefinement FindSimilarRefinement
        {
            get { return m_findSimilarRefinement; }
            set { m_findSimilarRefinement = value; }
        }

        public string Serialize()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(SearchExecutorWCF));
            TextWriter textWriter = new StringWriter();
            serializer.Serialize(textWriter, this);

            return textWriter.ToString();
        }
    }
}
