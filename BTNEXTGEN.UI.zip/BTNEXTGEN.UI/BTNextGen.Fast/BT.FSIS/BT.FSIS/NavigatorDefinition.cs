﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;
using System.ComponentModel;

namespace BT.FSIS
{
    public class NavigatorDefinition
    {
        internal NavigatorDefinition(){ }

        public NavigatorDefinition(string attribute, bool documentsOnly, string field, string name, bool queryTermsOnly, string scope, string title)
        {
            Attribute = attribute;
            DocumentsOnly = documentsOnly;
            Field = field;
            Name = name;
            QueryTermsOnly = queryTermsOnly;
            Scope = scope;
            Title = title;
        }

        public string Attribute { get; set; }

        [DefaultValue(false)]
        public bool DocumentsOnly { get; set; }
        public string Field { get; set; }
        public string Name { get; set; }

        [DefaultValue(false)]
        public bool QueryTermsOnly { get; set; }
        public string Scope { get; set; }
        public string Title { get; set; }

        public ImsNavigatorDefinition ToImsNavigatorDefinition()
        {
            ImsNavigatorDefinition navDef = new ImsNavigatorDefinition();
            navDef.Field = this.Field;
            navDef.DocumentsOnly = this.DocumentsOnly;
            navDef.Name = this.Name;
            navDef.Scope = this.Scope;
            navDef.SearchTermsOnly = this.QueryTermsOnly;
            navDef.Title = this.Title;
            navDef.Attribute = this.Attribute;

            return navDef;
        }
    }
}
