﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Xml;

namespace BT.FSIS.Configuration
{
    public class AdminNodeSectionHandler : IConfigurationSectionHandler
    {

        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            List<AdminNode> nodes = new List<AdminNode>();
            foreach (XmlNode node in section.SelectNodes("Node"))
            {
                nodes.Add(
                    new AdminNode()
                    {
                        Host = node.Attributes["Host"].InnerText,
                        Port = node.Attributes["Port"].InnerText
                    }
                );
            }

            return nodes;
        }
    }

    public class AdminNode
    {
        public string Host { get; set; }
        public string Port { get; set; }
    }
}
