﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Xml;

namespace BT.FSIS.Configuration
{
    class ClusterDefinitionSectionHandler : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            List<ClusterDefinition> nodes = new List<ClusterDefinition>();
            foreach (XmlNode node in section.SelectNodes("cluster"))
            {
                nodes.Add(
                    new ClusterDefinition()
                    {
                        Name = node.Attributes["name"].InnerText,
                        Navigator = node.Attributes["navigator"].InnerText,
                        PathSeparator = node.Attributes["pathSeparator"] != null ? node.Attributes["pathSeparator"].InnerText[0] : '/',
                        Field = node.Attributes["field"] != null ? node.Attributes["field"].InnerText : null,
                        Sort = node.Attributes["sort"] != null ? (ClusterSort)Enum.Parse(typeof(ClusterSort), node.Attributes["sort"].InnerText) : ClusterSort.Alpha,
                    }
                );
            }

            return nodes;
        }
    }
}
