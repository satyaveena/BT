﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public enum GroupOperatorType
    {
        And,
        Filter,
        Not,
        Or,
        Rank,
        XRank
    }

    public class GroupOperator : SearchOperator
    {
        public GroupOperator()
        {
        }

        public GroupOperator(GroupOperatorType type, List<SearchOperator> operators)
        {
            Type = type;
            Operators = operators;
        }

        public GroupOperator(GroupOperatorType type) 
        { 
            Type = type;
            Operators = new List<SearchOperator>();
        }

        public string ToFQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Type.ToString());
            sb.Append("(");
            bool firstOperator = true;
            foreach (SearchOperator searchOperator in this.Operators)
            {
                if (!firstOperator)
                {
                    sb.Append(',');
                }
                sb.Append(searchOperator.ToFQL());
                firstOperator = false;
            }

            if (Type == GroupOperatorType.XRank)
            {
                sb.Append(string.Format(",boost={0},boostall={1}", Boost, BoostAll ? "yes" : "no"));
            }
            sb.Append(")");
            return sb.ToString();
        }

        public ImsGroupOperator ToImsGroupOperator()
        {
            ImsGroupOperator imsGroupOperator = new ImsGroupOperator()
            { 
                Boost = this.Boost, 
                BoostAll = this.BoostAll, 
                GroupType = this.ImsType, 
                ReturnScope = this.ReturnScope, 
                Scopes = this.Scopes, 
                Source = this.Source
            };

            foreach (SearchOperator searchOperator in this.Operators)
            {
                imsGroupOperator.Operators.Add(searchOperator.ToImsSearchOperator());
            }

            return imsGroupOperator;
        }

        public ImsGroupOperatorType ImsType
        {
            get
            {
                return (ImsGroupOperatorType)Enum.Parse(typeof(ImsGroupOperatorType), Type.ToString());
            }
        }

        public GroupOperatorType Type { get; set; }
        public int Boost { get; set; }
        public bool BoostAll { get; set; }
        public List<SearchOperator> Operators { get; set; }

        protected override void ChangeTerm(ChangeTermRefinement changeRefinement)
        {
            foreach(SearchOperator theOperator in Operators)
            {
                theOperator.ApplyChangeTermRefinement(changeRefinement);
            }
        }

        protected override void ChangeOperator(ChangeSearchOperatorRefinment changeOperatorRefinement)
        {
            foreach (SearchOperator theOperator in Operators)
            {
                if (changeOperatorRefinement.TargetSearchOperator == theOperator)
                {
                    Operators.Remove(theOperator);
                    if (changeOperatorRefinement.ReplacementSearchOperator != null)
                    {
                        Operators.Add(changeOperatorRefinement.ReplacementSearchOperator);
                    }
                }
            }
        }
    }
}
