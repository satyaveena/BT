﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public enum SpellCheckType
    {
        Correct,
        None,
        Suggest
    }

    public class SpellCheckSuggestionRefinement : SearchRefinement
    {
        private IList<ChangeTermRefinement> m_changeTermRefinements;

        public SpellCheckSuggestionRefinement(ChangeTermRefinement changeTermRefinements) : base(false, false)
        {
            m_changeTermRefinements = new List<ChangeTermRefinement>();
            m_changeTermRefinements.Add(changeTermRefinements);
        }

        public SpellCheckSuggestionRefinement(IList<ChangeTermRefinement> changeTermRefinements) : base(false, false)
        {
            m_changeTermRefinements = changeTermRefinements;
        }

        public IList<ChangeTermRefinement> Refinements { get { return m_changeTermRefinements; } }
    }
}
