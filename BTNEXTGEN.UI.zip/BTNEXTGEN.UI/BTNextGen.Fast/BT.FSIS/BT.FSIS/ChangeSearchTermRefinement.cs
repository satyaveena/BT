﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ChangeSearchTermRefinement : SearchRefinement
    {
        private string m_originalTerm;
        private string m_replacementTerm;

        internal ChangeSearchTermRefinement(string originalTerm, string replacementTerm, bool canBeRemoved) : base(canBeRemoved)
        {
            m_originalTerm = originalTerm;
            m_replacementTerm = replacementTerm;
        }

        public string OriginalTerm { get { return m_originalTerm; } }
        public string Replacementterm { get { return m_replacementTerm; } }
    }
}
