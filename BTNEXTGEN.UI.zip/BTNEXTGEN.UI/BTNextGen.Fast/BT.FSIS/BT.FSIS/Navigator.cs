﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

using Com.FastSearch.Esp.Search.Result;

namespace BT.FSIS
{
    public enum FieldType
    {
        String,
        Integer,
        Double,
        Datetime
    }

    public class Navigator
    {
        private List<NavigatorGroup> m_navGroups = new List<NavigatorGroup>();

        public Navigator() { }

        public Navigator(INavigator navigator)
        {
            DisplayName = navigator.DisplayName;
            DocumentCount = navigator.Hits;
            FieldName = navigator.Modifier;
            GroupCount = navigator.ModifierCount();

            Name = navigator.Name;
            Score = navigator.Score;
            Source = "ESP";
            FieldType = ConvertESPFieldType(navigator);
            Unit = navigator.Unit;

            IEnumerator nav = navigator.Modifiers().GetEnumerator();
            while (nav.MoveNext())
            {
                IModifier modifier = (IModifier)nav.Current;
                m_navGroups.Add(new NavigatorGroup(this, modifier));
            }
        }

        private FieldType ConvertESPFieldType(INavigator nav)
        {
            if(nav.Type == NavigatorType.DATETIME)
            {
                return FieldType.Datetime;
            }

            if(nav.Type == NavigatorType.DOUBLE)
            {
                return FieldType.Double;
            }

            if(nav.Type == NavigatorType.INTEGER)
            {
                return FieldType.Integer;
            }
            
            if(nav.Type == NavigatorType.STRING)
            {
                return FieldType.String;
            }

            throw new NotImplementedException();
        }

        public Navigator(ImsRefiner refiner)
        {
            DisplayName = refiner.DisplayName;
            DocumentCount = refiner.ResultCount.Value;
            FieldName = refiner.FieldName;
            GroupCount = refiner.EntryCount.Value;
        
            Name = refiner.Name;
            Score = refiner.Score.Value;
            Source = refiner.Source;
            FieldType = (FieldType) Enum.Parse(typeof(FieldType), refiner.FieldType.ToString());
            Unit = refiner.Unit;

            foreach (ImsRefinerEntry refinerEntry in refiner.Entries)
            {
                m_navGroups.Add(new NavigatorGroup(this, refinerEntry));
            }
        }

        public List<NavigatorGroup> NavigatorGroups
        {
            get { return m_navGroups; } 
            set { m_navGroups = value; }
        }

        public string DisplayName { get; private set; }
        public int DocumentCount { get; private set; }
        public string FieldName { get; private set; }
        public int GroupCount { get; private set; }
        
        public string Name { get; private set; }
        public double Score { get; private set; }
        public string Source { get; private set; }
        public FieldType FieldType { get; private set; }
        public string Unit { get; private set; }

    }
}
