﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class SearchOperatorFactory
    {
        public static SearchOperator CreateSearchOperatorFromImsSimpleLanguage(string search)
        {
            return CreateSearchOperatorFromImsSimpleLanguage(search, TermsOperatorMode.All);
        }

        public static SearchOperator CreateSearchOperatorFromImsSimpleLanguage(string search, TermsOperatorMode termsOperatorMode)
        {
            return CreateSearchOperatorFromImsSimpleLanguage(search, termsOperatorMode, 100);
        }

        public static SearchOperator CreateSearchOperatorFromImsSimpleLanguage(string search, TermsOperatorMode termsOperatorMode, int wieght)
        {
            return CreateSearchOperatorFromImsSimpleLanguage(search, termsOperatorMode, wieght, false);
        }

        public static SearchOperator CreateSearchOperatorFromImsSimpleLanguage(string search, TermsOperatorMode termsOperatorMode, int wieght, bool linguistics)
        {
            return CreateSearchOperatorFromImsSimpleLanguage(search, termsOperatorMode, wieght, linguistics, null);
        }

        public static SearchOperator CreateSearchOperatorFromImsSimpleLanguage(string search, TermsOperatorMode termsOperatorMode, int wieght, bool linguistics, string[] scopes)
        {
            return CreateSearchOperatorFromImsSimpleLanguage(search, termsOperatorMode, wieght, linguistics, scopes, string.Empty);
        }
        
        public static SearchOperator CreateSearchOperatorFromImsSimpleLanguage(string search, TermsOperatorMode termsOperatorMode, int wieght, bool linguistics, string[] scopes, string source)
        {
            return new TermsOperator(search, termsOperatorMode) { Weight = wieght, Linguistics = linguistics, Source = source, Scopes = scopes.ToList<string>() };
        }
    }
}
