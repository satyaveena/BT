﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class AddSearchOperatorRefinement : SearchRefinement
    {
        private SearchOperator m_searchOperator;

        public AddSearchOperatorRefinement(SearchOperator searchOperator) : base(false, false)
        {
            m_searchOperator = searchOperator;
        }

        override internal SearchOperator SearchOperator { get { return m_searchOperator; } }
    }
}
