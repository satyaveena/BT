﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;
using System.Xml.Serialization;

namespace BT.FSIS
{
    [XmlInclude(typeof(TermsOperator))]
    [XmlInclude(typeof(ProximityOperator))]
    [XmlInclude(typeof(PhraseOperator))]
    [XmlInclude(typeof(GroupOperator))]
    [XmlInclude(typeof(BoundaryOperator))]
    [XmlInclude(typeof(RangeOperator))]
    [XmlInclude(typeof(NumericOperator))]
    public abstract class SearchOperator
    {
        public SearchOperator()
        {
            Scopes = new List<string>();
        }

        public SearchOperator(string returnScope, IList<string> scopes, string source)
        {
            ReturnScope = returnScope;
            Scopes = (List<string>)scopes;
            Source = source;
        }

        public string ToFQL()
        {
            if (this is TermsOperator)
            {
                return ((TermsOperator)this).ToFQL();
            }

            if (this is RangeOperator)
            {
                return ((RangeOperator)this).ToFQL();
            }

            if (this is GroupOperator)
            {
                return ((GroupOperator)this).ToFQL();
            }

            if (this is BoundaryOperator)
            {
                return ((BoundaryOperator)this).ToFQL();
            }

            if (this is PhraseOperator)
            {
                return ((PhraseOperator)this).ToFQL();
            }

            throw new NotImplementedException();
        }

        public ImsSearchOperator ToImsSearchOperator()
        {
            if (this is TermsOperator)
            {
                return ((TermsOperator)this).ToImsTermsOperator();
            }

            if (this is RangeOperator)
            {
                return ((RangeOperator)this).ToImsRangeOperator();
            }

            if (this is GroupOperator)
            {
                return ((GroupOperator)this).ToImsGroupOperator();
            }

            if (this is BoundaryOperator)
            {
                return ((BoundaryOperator)this).ToImsBoundaryOperator();
            } 
            
            if (this is PhraseOperator)
            {
                return ((PhraseOperator)this).ToImsPhraseOperator();
            }

            throw new NotImplementedException();
        }
        
        // SearchOperator
        public void ApplyChangeTermRefinement(ChangeTermRefinement changeRefinement)
        {
            ChangeTerm(changeRefinement);
        }

        public void ApplyChangeOperatorRefinement(ChangeSearchOperatorRefinment changeOperatorRefinement)
        {
            ChangeOperator(changeOperatorRefinement);
        }

        public string ReturnScope { get; set; }
        public List<string> Scopes { get; set; }
        public string Source { get; set; }
        public string Tag { get; set; }
        
        protected abstract void ChangeTerm(ChangeTermRefinement changeRefinement);
        protected abstract void ChangeOperator(ChangeSearchOperatorRefinment changeOperatorRefinement);

    }
}
