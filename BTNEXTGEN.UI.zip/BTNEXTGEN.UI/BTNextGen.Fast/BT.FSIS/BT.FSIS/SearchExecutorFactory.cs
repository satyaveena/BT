﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Xml.Serialization;
using System.IO;
using BT.FSIS.ESP;

namespace BT.FSIS.WCF
{
    public class SearchExecutorFactory
    {
        public static ISearchExecutor Create(string path, int count)
        {   
            return Create(path, count, false);
        }

        public static ISearchExecutor Create(string path, int count, bool useESP)
        {
            return Create(path, count, useESP, null);
        }

        public static ISearchExecutor Create(string path, int count, bool useESP, List<ClusterDefinition> clusterDefinitions)
        {
            List<ClusterDefinition> clusters = clusterDefinitions == null
                ? (List<ClusterDefinition>)ConfigurationManager.GetSection("clusterDefinition")
                : clusterDefinitions;

            List<NavigatorDefinition> navigators = (List<NavigatorDefinition>)ConfigurationManager.GetSection("navigatorDefinition");
            Navigation navigation = new Navigation(100, navigators);
            return Create(path, count, clusters, navigation, useESP);
        }

        public static ISearchExecutor Create(string path, int count, IList<ClusterDefinition> clusterDefs, Navigation navigation, bool useESP)
        {
            //bool useESP = bool.Parse(ConfigurationManager.AppSettings["UseESP"]);
            if (useESP)
            {
                return new SearchExecutorESP(path, count, clusterDefs, navigation); 
            }
            else
            { 
                return new SearchExecutorWCF(path, count, clusterDefs, navigation); 
            }
        }

        public static ISearchExecutor CreateFromSerialized(string serializedExecutor, bool useESP)
        {
            //bool useESP = bool.Parse(ConfigurationManager.AppSettings["UseESP"]);
            XmlSerializer deserializer;
            if (useESP)
            {
                deserializer = new XmlSerializer(typeof(SearchExecutorESP));
            }
            else
            {
                deserializer = new XmlSerializer(typeof(SearchExecutorWCF));
            }

            TextReader textReader = new StringReader(serializedExecutor);
            SearchExecutorWCF executor;

            executor = (SearchExecutorWCF)deserializer.Deserialize(textReader);
            textReader.Close();

            return executor;
        }
    }
}
