﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ChangeSearchOperatorRefinment : SearchRefinement
    {
        private SearchOperator m_targetOperator;
        private SearchOperator m_replacementOperator;

        public ChangeSearchOperatorRefinment(SearchOperator targetOperator, SearchOperator replacementOperator) : base(false, false)
        {
            m_targetOperator = targetOperator;
            m_replacementOperator = replacementOperator;
        }

        public SearchOperator TargetSearchOperator { get { return m_targetOperator; } }
        public SearchOperator ReplacementSearchOperator { get { return m_replacementOperator; } }
    }
}
