﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public class AdditionalParameter
    {
        public AdditionalParameter() { }
        public AdditionalParameter(string name, string target, string value)
        {
            Name = name;
            Target = target;
            Value = value;
        }

        public ImsAdditionalParameter ToImsAdditionalParameter()
        {
            return new ImsAdditionalParameter()
            {
                Name = this.Name,
                Target = this.Target,
                Value = this.Value
            };
        }

        public string Name { get; set; }
        public string Target { get; set; }
        public string Value { get; set; }
    }
}
