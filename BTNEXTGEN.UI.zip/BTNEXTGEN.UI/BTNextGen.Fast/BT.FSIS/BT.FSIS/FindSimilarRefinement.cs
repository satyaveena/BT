﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class FindSimilarRefinement : SearchRefinement
    {
        private string m_documentTitle;
        private string m_docVector;
        private bool m_include;

        public FindSimilarRefinement() : base(true, false) { }

        public FindSimilarRefinement(string documentTitle, string docVector, bool include) : base(true, false)
        {
            m_documentTitle = documentTitle;
            m_docVector = docVector;
            m_include = include;
        }

        public string DocumentTitle
        { 
            get { return m_documentTitle; }
            set { m_documentTitle = value; }
        }

        public string DocVector
        { 
            get { return m_docVector; }
            set { m_docVector = value; }
        }

        public bool Include
        { 
            get { return m_include; }
            set { m_include = value; }
        }
    }
}
