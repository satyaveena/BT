﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public class PhraseOperator : TermsOperatorBase
    {
        public PhraseOperator() : base() { }

        public PhraseOperator(string terms)
            : base(terms)
        {

        }

        public string ToFQL()
        {
            PhraseOperator phraseOperator = this as PhraseOperator;
            return string.Format("\"{0}\":string(\"{1}\", mode=\"phrase\", weight=int32(\"{2}\"), linguistics=\"{3}\")", string.Join(":", Scopes.ToArray()), Terms, phraseOperator.Weight, phraseOperator.Linguistics ? "ON" : "OFF");
        }

        public ImsPhraseOperator ToImsPhraseOperator()
        {
            PhraseOperator phraseOperator = this as PhraseOperator;
            return new ImsPhraseOperator()
            {
                Linguistics = phraseOperator.Linguistics,
                Scopes = phraseOperator.Scopes,
                ReturnScope = phraseOperator.ReturnScope,
                Terms = phraseOperator.Terms,
                Source = phraseOperator.Source,
                Weight = phraseOperator.Weight,
                AnnotationClass = "user"
            };
        }
    }
}
