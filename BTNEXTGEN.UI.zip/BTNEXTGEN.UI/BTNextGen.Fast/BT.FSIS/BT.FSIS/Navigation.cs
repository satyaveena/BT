﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public class Navigation
    {
        private int m_hits;
        private List<NavigatorDefinition> m_navigators;

        public Navigation() { }

        public Navigation(int hits, IList<NavigatorDefinition> navigators)
        {
            m_hits = hits;
            m_navigators = (List<NavigatorDefinition>)navigators;
        }

        public int Hits
        { 
            get { return m_hits; }
            set { m_hits = value; }
        }

        public List<NavigatorDefinition> Navigators
        {
            get { return m_navigators; }
            set { m_navigators = value; }
        }


        public ImsNavigation ToImsNavigation()
        {
            ImsNavigation imsNavagation = new ImsNavigation();
            imsNavagation.Hits = this.Hits;
            foreach (NavigatorDefinition navigatorDef in this.Navigators)
            {
                imsNavagation.Navigators.Add(navigatorDef.ToImsNavigatorDefinition());
            }

            return imsNavagation;
        }
    }
}
