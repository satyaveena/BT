﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public enum TermsOperatorMode
    {
        All, 
        Any,
        AnyNoBoost,
        Phrase
    }
    
    public class TermsOperator : TermsOperatorBase
    {
        public TermsOperator() : base()
        {
        }

        public TermsOperator(string terms) : base(terms)
        {
        }

        public TermsOperator(string terms, TermsOperatorMode termsOperatorMode) : base(terms)
        {
            Mode = termsOperatorMode;
        }

        protected string ToFQLBoolean(TermsOperatorMode mode)
        {
            switch(mode)
            {
                case TermsOperatorMode.All:
                    return "AND";
                case TermsOperatorMode.Any:
                    return "OR";
                case TermsOperatorMode.Phrase:
                    return "PHRASE";
                case TermsOperatorMode.AnyNoBoost:
                    throw new NotImplementedException();
                default:
                    return "PHRASE";
            }
        }

        public string ToFQL()
        {
            TermsOperator termsOperator = this as TermsOperator;
            if (Scopes.Contains("ngcontent") || Scopes.Contains("autosuggestcontent"))
                return string.Format("\"{0}\":string(\"{1}\", mode=\"{2}\", weight=int32(\"{3}\"), linguistics=\"{4}\", annotation_class=\"user\")", string.Join(":", Scopes.ToArray()), Terms, ToFQLBoolean(termsOperator.Mode), termsOperator.Weight, termsOperator.Linguistics ? "ON" : "OFF");
            else
                return string.Format("\"{0}\":string(\"{1}\", mode=\"{2}\", weight=int32(\"{3}\"), linguistics=\"{4}\")", string.Join(":", Scopes.ToArray()), Terms, ToFQLBoolean(termsOperator.Mode), termsOperator.Weight, termsOperator.Linguistics ? "ON" : "OFF");
        }

        public ImsTermsOperator ToImsTermsOperator()
        {
            TermsOperator termsOperator = this as TermsOperator;
            return new ImsTermsOperator()
            {
                Linguistics = termsOperator.Linguistics,
                Mode = (ImsTermsOperatorMode)Enum.Parse(typeof(ImsTermsOperatorMode), termsOperator.Mode.ToString()),
                Scopes = termsOperator.Scopes,
                ReturnScope = termsOperator.ReturnScope,
                Terms = termsOperator.Terms,
                Source = termsOperator.Source,
                Weight = termsOperator.Weight,
                AnnotationClass = "user"
            };
        }

        public TermsOperatorMode Mode { get; set; }
    }
}
