﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace BT.FSIS
{
    public class TermsOperatorBase : SearchOperator
    {
        public TermsOperatorBase() { }

        public TermsOperatorBase(string terms)
        {
            Terms = terms;
            Linguistics = false;  // Default off.
            Weight = 100; // Default 100
        }

        public string Terms { get; set; }
        public bool Linguistics { get; set; }
        public int Weight { get; set; }

        protected override void ChangeTerm(ChangeTermRefinement changeRefinement)
        {
            ChangeTerm(changeRefinement.OriginalTerm, changeRefinement.ReplacementTerm);
        }

        protected override void ChangeOperator(ChangeSearchOperatorRefinment changeOperatorRefinement)
        {
            return;
        }

        private void ChangeTerm(string oldTerm, string newTerm)
        {
            if (!string.IsNullOrEmpty(Terms))
            {
                string[] terms = Regex.Split(Terms.Trim(), "\\s+");
                for (int i = 0; i < terms.Length; i++)
                {
                    if (terms[i] == oldTerm)
                    {
                        terms[i] = newTerm;
                    }
                }

                Terms = string.Join(" ", terms);
            }

        }
    }
 
}
