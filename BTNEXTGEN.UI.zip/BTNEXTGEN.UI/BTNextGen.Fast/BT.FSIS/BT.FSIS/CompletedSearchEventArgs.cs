﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class CompletedSearchEventArgs
    {
        private bool m_didSucceed;
        private string m_failure;
        private SearchResults m_searchResults;

        public CompletedSearchEventArgs(bool didSucceed, string failure, SearchResults searchResults)
        {
            m_didSucceed = didSucceed;
            m_failure = failure;
            m_searchResults = searchResults;
        }

        public SearchResults SearchResults { get { return m_searchResults; } }
        public bool DidSucceed { get { return m_didSucceed; } }
        public string Failure { get { return m_failure; } }
    }
}
