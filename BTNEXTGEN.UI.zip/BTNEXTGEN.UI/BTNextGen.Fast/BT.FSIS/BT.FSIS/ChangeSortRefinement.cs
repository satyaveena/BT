﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ChangeSortRefinement : SearchRefinement
    {
        private string[] m_sortElements;

        public ChangeSortRefinement(string[] sortElements) : base(false, false)
        {
            m_sortElements = sortElements;
        }

        public string[] SortElements { get { return m_sortElements; } }
    }
}
