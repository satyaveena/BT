﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

using Com.FastSearch.Esp.Search.Result;

namespace BT.FSIS
{
    public class Document
    {
        internal Document(IDocumentSummary documentSummary)
        {
            Dictionary<string, string> fieldDict = new Dictionary<string, string>();
            IEnumerator summeryEnum = documentSummary.SummaryFields();
            while (summeryEnum.MoveNext())
            {
                IDocumentSummaryField documentSummaryField = (IDocumentSummaryField)summeryEnum.Current;
                fieldDict.Add(documentSummaryField.Name, documentSummaryField.StringValue);
            }

            DocumentFields = fieldDict;
        }

        internal Document(ImsResult result)
        {
            DocumentFields = result.Fields;
        }

        public string Description 
        {
            get
            {
                if (!DocumentFields.Keys.Contains("teaser")) return string.Empty;
                return DocumentFields["teaser"] == null ? string.Empty : DocumentFields["teaser"];
            }
        }
        public string Id
        {
            get
            {
                return DocumentFields["internalid"];
            }
        }
        public string Source
        {
            get
            {
                if (!DocumentFields.Keys.Contains("source")) return string.Empty;
                return DocumentFields["source"] == null ? string.Empty : DocumentFields["source"];
            }
        }

        public string Title
        {
            get
            {
                if (!DocumentFields.Keys.Contains("title")) return string.Empty;
                return DocumentFields["title"] == null ? string.Empty : DocumentFields["title"];
            }
        }

        public string Uri
        {
            get
            {
                if (!DocumentFields.Keys.Contains("url")) return string.Empty;
                return DocumentFields["url"] == null ? string.Empty : DocumentFields["url"];
            }
        }

        public string BTKey
        {
            get
            {
                if (!DocumentFields.Keys.Contains("btkey")) return string.Empty;
                return DocumentFields["btkey"] == null ? string.Empty : DocumentFields["btkey"];
            }
        }

        public string ISBN13
        {
            get
            {
                if (!DocumentFields.Keys.Contains("isbn13")) return string.Empty;
                return DocumentFields["isbn13"] == null ? string.Empty : DocumentFields["isbn13"];
            }
        }

        public string ContentType
        {
            get
            {
                if (!DocumentFields.Keys.Contains("contenttype")) return string.Empty;
                return DocumentFields["contenttype"] == null ? string.Empty : DocumentFields["contenttype"];
            }
        }
        


        public IDictionary<string, string> DocumentFields { get; private set; }
        public FindSimilarRefinement ExcludeSimilarRefinement { get { throw new NotImplementedException(); } }
        public FindSimilarRefinement IncludeSimilarRefinement { get { throw new NotImplementedException(); } }
    }
}
