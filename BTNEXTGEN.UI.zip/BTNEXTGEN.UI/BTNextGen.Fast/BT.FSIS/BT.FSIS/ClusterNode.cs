﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ClusterNode
    {
        public ClusterNode()
        {
            SubNodes = new List<ClusterNode>();
        }

        public string ClusterName { get; set; }
        public SearchRefinement ExactExclustionRefinement { get; internal set; }
        public SearchRefinement ExactInclustionRefinement { get; internal set; }
        public int LocalDocumentCount { get; internal set; }
        public string Name { get; internal set; }
        public string Path { get; internal set; }
        public int SubNodeCount { get; internal set; }
        public List<ClusterNode> SubNodes { get; internal set; }
        public SearchRefinement SubtreeExclustionRefinement { get; internal set; }
        public SearchRefinement SubtreeInclustionRefinement { get; internal set; }
        public int TotalDocumentCount { get; internal set; }

        /// <summary>
        /// TFS 2000 for Publish Date facet.
        /// </summary>
        /// <param name="count"></param>
        public void SetTotalDocumentCount(int count)
        {
            TotalDocumentCount = count;
        }
        internal string PathName { get; set; }
        internal string SortKey { get; set; }

        static internal int CalculateLeafNodeCount(ClusterNode node)
        {
            if (node.SubNodes.Count == 0)
            {
                return 1;
            }

            int leafNodeCount = 0;
            for (var i = 0; i < node.SubNodes.Count; i++)
            {
                leafNodeCount += ClusterNode.CalculateLeafNodeCount(node.SubNodes[i]);
            }
            
            return leafNodeCount;
        }
    }
}
