﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Xml;

namespace BT.FSIS.Configuration
{
    class NavigatorDefinitionSectionHandler : IConfigurationSectionHandler
    {
        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            List<NavigatorDefinition> nodes = new List<NavigatorDefinition>();
            foreach (XmlNode node in section.SelectNodes("navigator"))
            {
                nodes.Add(
                    new NavigatorDefinition()
                    {
                        Name = node.Attributes["name"].InnerText,
                        DocumentsOnly = node.Attributes["documentsOnly"] != null ? bool.Parse(node.Attributes["documentsOnly"].InnerText) : false,
                        Field = node.Attributes["field"] != null ? node.Attributes["field"].InnerText : null,
                        Attribute = node.Attributes["attribute"] != null ? node.Attributes["attribute"].InnerText : null,
                        QueryTermsOnly = node.Attributes["queryTermsOnly"] != null ? bool.Parse(node.Attributes["queryTermsOnly"].InnerText) : false,
                        Scope = node.Attributes["scope"] != null ? node.Attributes["scope"].InnerText : null,
                        Title = node.Attributes["title"] != null ? node.Attributes["title"].InnerText : null,
                    }
                );
            }

            return nodes;
        }
    }
}
