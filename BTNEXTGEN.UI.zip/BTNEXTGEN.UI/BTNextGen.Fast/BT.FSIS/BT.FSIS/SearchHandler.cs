﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Web;
using System.Xml;
using System.ServiceModel;
using Microsoft.Ceres.InteractionEngine.Services;
using Microsoft.Ceres.InteractionEngine.Services.Admin;
using Microsoft.Ceres.InteractionEngine.Tools.ProcessingEngineApi;
using Microsoft.Ceres.InteractionUI.WdmPlugIns;
using BT.FSIS.Configuration;

namespace BT.FSIS.WDM
{
    public class SearchHandler : IHttpHandler
    {
        /// <summary>
        /// You will need to configure this handler in the web.config file of your 
        /// web and register it with IIS before being able to use it. For more information
        /// see the following link: http://go.microsoft.com/?linkid=8101007
        /// </summary>
        #region IHttpHandler Members

        public bool IsReusable
        {
            // Return false in case your Managed Handler cannot be reused for another request.
            // Usually this would be false in case you have some state information preserved per request.
            get { return true; }
        }

        public void ProcessRequest(HttpContext httpContext)
        {
            //Todo:  figure out how to get the admin server node from the web.config.
            //Configuration config = WebConfigurationManager.OpenWebConfiguration("\\");

            using (ChannelFactory<IProcessingEngineManager> adminfactory = new ChannelFactory<IProcessingEngineManager>("NetTcpBinding_IProcessingEngineManager"))
            {
                // Get our admin node:

                List<AdminNode> adminNodes = (List<AdminNode>)ConfigurationManager.GetSection("AdminNodes");

                string adminNode = string.Format("net.tcp://{0}:{1}", adminNodes[0].Host, adminNodes[0].Port);

                IProcessingEngineManager processingEngineManager = adminfactory.CreateChannel(new EndpointAddress(adminNode));

                IEnumerable<KeyValuePair<string, int>> runningInstances = processingEngineManager.GetRunningInstances();
       

                foreach (KeyValuePair<string, int> instance in runningInstances)
                {
                    using (ProcessingEngineClient client = new ProcessingEngineClient(instance.Key, instance.Value))
                    {

                        StreamReader reader = new StreamReader(httpContext.Request.InputStream);
                        Context inContext = Context.Parse(reader.ReadToEnd());
                        PlugInManager plugInManager = new PlugInManager();
                        plugInManager.ProcessPlugInRequests(httpContext, inContext);

                        Context retContext = client.ExecuteFlow(inContext);

                        plugInManager.ProcessPlugInResponses(httpContext, retContext);

                        // Read the response and write it back to the client.
                        XmlWriter xmlWriter = XmlWriter.Create(httpContext.Response.OutputStream);
                        retContext.WriteTo(xmlWriter);
                        xmlWriter.Flush();  
                        httpContext.Response.Flush();
                        break;  // Just use the first one for now.
                    }
                }
            }
        }

        #endregion
    }
}
