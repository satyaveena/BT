﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace BT.FSIS
{
    [XmlInclude(typeof(NavigatorGroupRefinement))]
    [XmlInclude(typeof(FindSimilarRefinement))]
    [XmlInclude(typeof(ClusterNodeRefinement))]
    [XmlInclude(typeof(GroupRefinement))]
    public abstract class SearchRefinement
    {
        public SearchRefinement() { }

        public SearchRefinement(bool canBeRemoved, bool canBeGrouped)
        {
            CanBeRemoved = canBeRemoved;
            CanBeGrouped = canBeGrouped;
        }

        public bool CanBeRemoved {get;set;}
        public bool CanBeGrouped {get;set;}
        public string Tag { get; set; }


        internal virtual SearchOperator SearchOperator { get { throw new NotImplementedException(); } }
    }
}
