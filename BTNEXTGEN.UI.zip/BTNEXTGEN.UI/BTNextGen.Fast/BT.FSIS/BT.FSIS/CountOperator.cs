﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class CountOperator : SearchOperator
    {
        public CountOperator(string phrase, int max, int min)
        {
            Phrase = phrase;
            Max = max;
            Min = min;
        }

        string Phrase { get; set; }
        int Max { get; set; }
        int Min { get; set; }

        protected override void ChangeTerm(ChangeTermRefinement changeRefinement)
        {
            return;
        }

        protected override void ChangeOperator(ChangeSearchOperatorRefinment changeOperatorRefinement)
        {
            return;
        }
    }
}
