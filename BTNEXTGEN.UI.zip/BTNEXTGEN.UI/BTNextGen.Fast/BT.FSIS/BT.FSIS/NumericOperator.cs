﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public enum NumericOperatorType
    {
        Int, 
        Float,
        Double,
        Date
    }

    public class NumericOperator : SearchOperator
    {
        private NumericOperatorType m_valueType;

        public int IntValue { get; set; }

        public DateTime DateTimeValue { get; set; }

        public float FloatValue { get; set; }

        public double DoubleValue { get; set; }

        public NumericOperator() { }

        public NumericOperator(int value)
        {
            m_valueType = NumericOperatorType.Int;
            IntValue = value;
        }

        public NumericOperator(float value)
        {
            m_valueType = NumericOperatorType.Float;
            FloatValue = value;
        }

        public NumericOperator(double value)
        {
            m_valueType = NumericOperatorType.Double;
            DoubleValue = value;
        }

        public NumericOperator(DateTime value)
        {
            m_valueType = NumericOperatorType.Date;
            DateTimeValue = value;
        }

        internal ImsNumericValueType ImsValueType
        {
            get
            {
                return (ImsNumericValueType)Enum.Parse(typeof(ImsNumericValueType), ValueType.ToString());
            }
        }

        public ImsNumericOperator ToImsNumericOperator()
        {
            ImsNumericOperator imsNumericOperator = new ImsNumericOperator() { ReturnScope = this.ReturnScope, Scopes = this.Scopes, Source = this.Source };
            switch (this.ValueType)
            {
                case NumericOperatorType.Date:
                    imsNumericOperator.SetValue(DateTimeValue);
                    break;
                case NumericOperatorType.Double:
                    imsNumericOperator.SetValue(DoubleValue);
                    break;
                case NumericOperatorType.Float:
                    imsNumericOperator.SetValue(FloatValue);
                    break;
                case NumericOperatorType.Int:
                    imsNumericOperator.SetValue(IntValue);
                    break;
            }

            return imsNumericOperator;
        }

        public NumericOperatorType ValueType
        { 
            get { return m_valueType; }
            set { m_valueType = value; }
        }

        protected override void ChangeTerm(ChangeTermRefinement changeRefinement)
        {
            return;
        }

        protected override void ChangeOperator(ChangeSearchOperatorRefinment changeOperatorRefinement)
        {
            return;
        }
    }
}
