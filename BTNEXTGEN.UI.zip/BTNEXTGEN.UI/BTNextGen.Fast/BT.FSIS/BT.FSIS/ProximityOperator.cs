﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ProximityOperator : TermsOperatorBase
    {
        public ProximityOperator() : base() { }
        public ProximityOperator(string terms) : base(terms) { }
        public int ExtraTermsAllowed { get; set; }
        public bool Ordered { get; set; }
    }
}
