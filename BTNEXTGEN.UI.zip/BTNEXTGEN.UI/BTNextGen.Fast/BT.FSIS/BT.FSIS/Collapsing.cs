﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace BT.FSIS
{
    public class Collapsing
    {

        internal Collapsing()
        {
            Enabled = ConfigurationManager.AppSettings["CollapsingEnabled"] != null ? bool.Parse(ConfigurationManager.AppSettings["CollapsingEnabled"]) : false;
            if(Enabled)
            {
                Field = ConfigurationManager.AppSettings["CollapsingField"] != null ? ConfigurationManager.AppSettings["CollapsingField"] : null;
                DocumentsToKeep = ConfigurationManager.AppSettings["CollapsingNumDocsToKeep"] != null ? int.Parse(ConfigurationManager.AppSettings["CollapsingNumDocsToKeep"]) : 1;
            }
        }

        public Collapsing(int documentsToKeep, string field)
        {
            DocumentsToKeep = documentsToKeep;
            Field = field;
            Enabled = true;
        }

        public int DocumentsToKeep { get; set; }
        public string Field { get; set; }
        public bool Enabled { get; set; }

    }
}
