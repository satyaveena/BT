﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

using Com.FastSearch.Esp.Search.Result;
using Com.FastSearch.Esp.Search.Navigation;

namespace BT.FSIS
{
    public class SearchResults
    {
        private List<Navigator> m_navigators = new List<Navigator>();
        private List<Cluster> m_clusters = new List<Cluster>();
        private List<Document> m_results = new List<Document>();
        private List<SearchTransformation> m_transformations = new List<SearchTransformation>();
        private SpellCheckSuggestionRefinement m_spellCheckRefinement = null;

        internal SearchResults(string errors)
        {
            Errors = errors;
        }

        internal SearchResults(IQueryResult espSearchResults, string errors, IList<ClusterDefinition> clusters)
        {
            if(espSearchResults != null)
            {
                bool doNavigators = true;
                System.Collections.ICollection navigators = null;
                try
                {
                    navigators = espSearchResults.Navigators();
                }
                catch (Exception)
                {
                    doNavigators = false; // no info available
                }

                if (doNavigators && navigators != null && navigators.Count > 0)
                {
                    IEnumerator nav = navigators.GetEnumerator();
                    while (nav.MoveNext())
                    {
                        INavigator navigator = (INavigator)nav.Current;
                        m_navigators.Add(new Navigator(navigator));
                    }
                }

                if (espSearchResults.Hits > 0)
                {
                    IEnumerator docs = espSearchResults.Documents();
                    int hit = 0;
                    while (docs.MoveNext() && hit++ < espSearchResults.Hits)
                    {
                        m_results.Add(new Document((IDocumentSummary)docs.Current));
                    }
                }

                addTransformations(espSearchResults);

                addClusters(clusters);

                DocumentCount = espSearchResults.DocCount;
                MaxRank = (int)espSearchResults.MaxRank;
                SearchTime = (int)espSearchResults.TimeUsed;
            }

            Errors = errors;
        }

        internal SearchResults(ImsSearchResults imsSearchResults, string errors, IList<ClusterDefinition> clusters)
        {
            if(imsSearchResults != null)
            {
                foreach (ImsRefiner refiner in imsSearchResults.Refiners)
                {
                    m_navigators.Add(new Navigator(refiner));
                }

                foreach (ImsResult imsResult in imsSearchResults.Results)
                {
                    m_results.Add(new Document(imsResult));
                }

                addTransformations(imsSearchResults);

                addClusters(clusters);

                DocumentCount = imsSearchResults.TotalResultCount.Value;
                MaxRank = (int)imsSearchResults.MaxRank;
                SearchTime = imsSearchResults.SearchTime.Value.Milliseconds;
            }

            Errors = errors;
        }

        private void addClusters(IList<ClusterDefinition> clusterDefs)
        { 
            if (clusterDefs != null && clusterDefs.Count > 0 && m_navigators.Count > 0)
            {
                // Find all the navigators mentioned in the cluster defs
                for (var i = 0; i < m_navigators.Count; i++)
                {
                    for (var j = 0; j < clusterDefs.Count; j++)
                    {
                        if (clusterDefs[j].Navigator == m_navigators[i].Name && m_navigators[i].FieldType == FieldType.String)
                        {
                            Cluster cluster = new Cluster();
                            cluster.AssignValues(m_navigators[i], clusterDefs[j]);
                            m_clusters.Add(cluster);
                        }
                    }
                }
            }
        }

        private void addTransformations(IQueryResult espSearchResults)
        {
            List<ChangeTermRefinement> changeRefinements = new List<ChangeTermRefinement>();

            IQueryTransformations qt = espSearchResults.GetQueryTransformations(false);
            foreach (IQueryTransformation trans in qt.AllQueryTransformations)
            {
                SearchTransformation newTransformation = new SearchTransformation()
                {
                    Search = trans.Query,
                    Action = trans.Action,
                    Custom = trans.Custom,
                    Message = trans.Message == null ? string.Empty : trans.Message,
                    MessageId = trans.MessageID,
                    Name = trans.Name
                };

                ProcessTransformation(changeRefinements, newTransformation);
            }

            qt = espSearchResults.GetQueryTransformations(true);
            foreach (IQueryTransformation trans in qt.AllQueryTransformations)
            {
                SearchTransformation newTransformation = new SearchTransformation()
                {
                    Search = trans.Query,
                    Action = trans.Action,
                    Custom = trans.Custom,
                    Message = trans.Message == null ? string.Empty : trans.Message,
                    MessageId = trans.MessageID,
                    Name = trans.Name
                };

                ProcessTransformation(changeRefinements, newTransformation);
            }

            if (changeRefinements.Count > 0)
            {
                m_spellCheckRefinement = new SpellCheckSuggestionRefinement(changeRefinements);
            }
        }

        private void addTransformations(ImsSearchResults imsSearchResults)
        {
            List<ChangeTermRefinement> changeRefinements = new List<ChangeTermRefinement>();
            foreach( ImsSearchTransformation transformation in imsSearchResults.SearchTransformations)
            {
                SearchTransformation newTransformation = new SearchTransformation()
                {
                    Search = transformation.Query, 
                    Action = transformation.Action, 
                    Custom = transformation.Custom, 
                    Message = transformation.Message == null ? string.Empty : transformation.Message, 
                    MessageId = (int)transformation.MessageId, Name = transformation.Name
                };

                ProcessTransformation(changeRefinements, newTransformation);
            }

            if (changeRefinements.Count > 0)
            {
                m_spellCheckRefinement = new SpellCheckSuggestionRefinement(changeRefinements);
            }
        }

        private void ProcessTransformation(List<ChangeTermRefinement> changeRefinements, SearchTransformation transformation)
        {
            //if (transformation.Name == "FastQT_DidYouMean" && ((int)transformation.MessageId == 4 || (int)transformation.MessageId == 7 || (int)transformation.MessageId == 12))
            //{
            //    Match match = Regex.Match(transformation.Custom, "(.*)->(.*)");


            //    if (match.Groups.Count == 3 && match.Groups[1].Value.Length > 0 && match.Groups[2].Value.Length > 0)
            //    {
            //        var changeTermRefinement = new ChangeTermRefinement(match.Groups[1].Value, match.Groups[2].Value);
            //        changeRefinements.Add(changeTermRefinement);
            //    }
            //}

            if (transformation.Name == "FastQT_DidYouMean" && ((int)transformation.MessageId == 14))
            {
                var changeTermRefinement = new ChangeTermRefinement(transformation.Custom, transformation.Search);
                changeRefinements.Add(changeTermRefinement);
            }

            m_transformations.Add(transformation);
        }


        public string Errors
        {
            get;
            private set;
        }

        public bool HasErrors { get { return Errors != null && Errors.Length > 0; } }

        public List<Cluster> Clusters 
        { 
            get { return m_clusters; } 
            set { m_clusters = value; }//TODO
        }
        
        public int DocumentCount
        {
            get;
            private set;
        }

        public int MaxRank
        {
            get;
            private set;
        }

        public List<Navigator> Navigators 
        {
            get 
            {
                return m_navigators;
            }
            set { m_navigators = value; }//TODO
        }

        public int SearchTime
        {
            get;
            private set;
        }

        public string SpellCheckSuggestion
        {
            get
            {
                if (SpellCheckSuggestionRefinement != null)
                {
                    return SpellCheckSuggestionRefinement.Refinements[0].ReplacementTerm;
                }

                return null;
            }
        }

        public IList<SearchTransformation> SearchTransformations { get { return m_transformations; } }
        public SpellCheckSuggestionRefinement SpellCheckSuggestionRefinement { get { return m_spellCheckRefinement; } }
        public AddSearchOperatorRefinement GetAddSearchOperatorRefinement(SearchOperator searchOperator)
        {
            return new AddSearchOperatorRefinement(searchOperator);
        }

        public ChangeSearchOperatorRefinment GetChangeSearchOperatorRefinement(SearchOperator targetSearchOperator, SearchOperator replacementSearchOperator)
        {
            return new ChangeSearchOperatorRefinment(targetSearchOperator, replacementSearchOperator);
        }

        public ChangeSortRefinement GetChangeSortRefinement(string[] sortElements)
        {
            return new ChangeSortRefinement(sortElements);
        }

        public Cluster GetCluster(string name)
        {
            foreach (Cluster cluster in m_clusters)
            {
                if (cluster.Name == name)
                {
                    return cluster;
                }
            }

            return null;
        }

        public GroupRefinement GetGroupRefinement(GroupRefinementType groupRefinementType, SearchRefinement[] refinements)
        {
            throw new NotImplementedException();
        }

        public Navigator GetNavigator(string name)
        {
            IList<Navigator> navs = GetNavigators(name);
            if (navs.Count > 0)
            {
                return navs[0];
            }

            return null;
        }

        public IList<Navigator> GetNavigators(string name)
        {
            List<Navigator> navigators = new List<Navigator>();
            foreach (Navigator navigator in m_navigators)
            {
                if (navigator.Name == name)
                {
                    navigators.Add(navigator);
                }
            }

            return navigators;
        }

        public IList<Document> ResultDocuments
        {
            get
            {
                return m_results;
            }
        }
    }
}
