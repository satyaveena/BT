﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

using Com.FastSearch.Esp.Search.Result;

namespace BT.FSIS
{
    public enum RangeType
    {
        NoRange,
        LowEndPoint,
        Middle,
        HighEndPoint
    }

    public class NavigatorGroup
    {
        private Navigator m_navigator;

        public NavigatorGroup() { }

        public NavigatorGroup(Navigator navigator, IModifier modifier)
        {
            DisplayName = modifier.Name;
            DocumentCount = modifier.Count;
            DocumentRatio = modifier.DocumentRatio;
            GroupValue = modifier.Value;
            m_navigator = navigator;
        }

        public NavigatorGroup(Navigator navigator, ImsRefinerEntry refinerEntry)
        {
            DisplayName = refinerEntry.DisplayName;
            DocumentCount = refinerEntry.ResultCount.Value;
            //DocumentRatio = refinerEntry.ResultRatio.Value;
            GroupValue = refinerEntry.Value;
            m_navigator = navigator;
        }

        public Navigator Navigator
        {
            get { return m_navigator; }
            set { m_navigator = value; }
        }


        public string DisplayName{ get; private set; }
        public int DocumentCount{ get; private set; }
        public double DocumentRatio{ get; private set; }
        private string GroupValue { get; set; }
        public string Value 
        { 
            get 
            {
                string groupValue = GroupValue;

                // Remove any invalid characters - ^ and/or " at the beginning, " and/or $ at the end
                if (groupValue[0] == '^')
                {
                    groupValue = groupValue.Substring(1);
                }

                if (groupValue[groupValue.Length - 1] == '$')
                {
                    groupValue = groupValue.Substring(0, groupValue.Length - 1);
                }

                if (groupValue[0] == '"' && groupValue[groupValue.Length - 1] == '"')
                {
                    groupValue = groupValue.Substring(1, groupValue.Length - 2);
                }

                return groupValue;
            } 
        }
        public SearchRefinement ExclustionRefinement { get { return new NavigatorGroupRefinement(false, false, this); } }
        public SearchRefinement InclustionRefinement { get { return new NavigatorGroupRefinement(false, true, this); } }
        public string FieldName{get{return m_navigator.FieldName;}}
        public object MaxValue { get; set; }
        public object MinValue { get; set; }
        public string NavigatorDisplayName { get { return m_navigator.DisplayName; } }
        public FieldType NavigatorType { get { return m_navigator.FieldType; } }
        public RangeType RangeType { get; set; }

    }
}
