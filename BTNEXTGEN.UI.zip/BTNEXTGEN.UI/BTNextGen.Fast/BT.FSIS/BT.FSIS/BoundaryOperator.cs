﻿using System;
using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;

namespace BT.FSIS
{
    public enum BoundaryOperatorMode
    {
        End,
        Exact,
        Start
    }

    public class BoundaryOperator : PhraseOperator
    {
        public BoundaryOperator()
        {
        }

        public BoundaryOperator(string terms, BoundaryOperatorMode boundaryOperatorMode) : base(terms)
        {
            Mode = boundaryOperatorMode;
        }

        public BoundaryOperatorMode Mode { get; set; }
        public bool OffWildCard { get; set; }

        private string GetBoundaryMode(BoundaryOperatorMode mode)
        {
            switch(mode)
            {
                case BoundaryOperatorMode.End:
                    return "ends-with";
                case BoundaryOperatorMode.Exact:
                    return "equals";
                case BoundaryOperatorMode.Start:
                    return "starts-with";
                default:
                    throw new NotImplementedException();
            }
        }

        public string ToFQL()
        {
            if(OffWildCard)
                return string.Format("{0}:{1}(string(\"{2}\",wildcard=\"off\"))", string.Join(":", Scopes.ToArray()), GetBoundaryMode(Mode), Terms);
            return string.Format("{0}:{1}(\"{2}\")", string.Join(":", Scopes.ToArray()), GetBoundaryMode(Mode), Terms);
        }

        public ImsBoundaryOperator ToImsBoundaryOperator()
        {
            BoundaryOperator boundaryOperator = this as BoundaryOperator;
            return new ImsBoundaryOperator()
            {
                Linguistics = boundaryOperator.Linguistics,
                Scopes = boundaryOperator.Scopes,
                ReturnScope = boundaryOperator.ReturnScope,
                Terms = boundaryOperator.Terms,
                Source = boundaryOperator.Source,
                Weight = boundaryOperator.Weight,
                Mode = (ImsBoundaryOperatorMode)Enum.Parse(typeof(ImsBoundaryOperatorMode), this.Mode.ToString())
                //AnnotationClass = "user"
            };
        }
    }
}
