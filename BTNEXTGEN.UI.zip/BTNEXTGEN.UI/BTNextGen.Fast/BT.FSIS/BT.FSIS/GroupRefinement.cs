﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BT.FSIS;

namespace BT.FSIS
{
    public enum GroupRefinementType
    {
        And,
        Or
    }

    public class GroupRefinement : SearchRefinement
    {
        public GroupRefinement() : base(false, true) { }

        public GroupRefinement(GroupRefinementType type)
            : base(false, true)
        {
            Type = type;
            Refinements = new List<SearchRefinement>();
        }

        public GroupRefinementType Type { get; set; }
        public List<SearchRefinement> Refinements
        {
            get;
            set;
        }


        override internal SearchOperator SearchOperator
        {
            get
            {
                if (Refinements.Count == 1)
                {
                    return Refinements[0].SearchOperator;
                }

                List<SearchOperator> operators = new List<SearchOperator>();
                foreach (SearchRefinement refinement in Refinements)
                {
                    operators.Add(refinement.SearchOperator);
                }

                return new GroupOperator(Type == GroupRefinementType.And ? GroupOperatorType.And : GroupOperatorType.Or, operators);
            }
        }

        override public string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Type);
            sb.Append("(");
            foreach (SearchRefinement refinement in Refinements)
            {
                sb.Append(refinement);
                sb.Append(" ");
            }
            sb.Append(")");
            return sb.ToString();
        }
    }
}