﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public interface ISearchExecutor
    {
        SearchResults ExecuteSearch(int offset);
        void DefineSearch(Search search);
        //IAsyncResult BeginExecuteSearch(int offset, ref SearchResults searchResults, AsyncCallback callback, Object state);
        //bool EndExecuteSearch(ref SearchResults searchResults, IAsyncResult asyncResult);

        SearchResults CurrentResults { get; }
        List<SearchRefinement> Refinements { get; }
        Search CurrentSearch { get; }
        int Count { get; }
        int Offset { get; set; }
        bool IsRefinementAdded(SearchRefinement refinement, bool lookInGroups);
        void AddRefinement(SearchRefinement refinement);
        void RemoveRefinement(SearchRefinement refinement);
        bool AutoSearch { get; set; }

        string Serialize();

        //IList<string> Fields { get; }
    }
}
