﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class Resubmit
    {
        internal Resubmit() 
        { 
            Enabled = ConfigurationManager.AppSettings["ResubmitEnabled"] != null ? bool.Parse(ConfigurationManager.AppSettings["ResubmitEnabled"]) : false;
            Synonyms = ConfigurationManager.AppSettings["ResubmitUseSynonyms"] != null ? bool.Parse(ConfigurationManager.AppSettings["ResubmitUseSynonyms"]) : false;
            Lemmatization = ConfigurationManager.AppSettings["ResubmitUseLemmatazation"] != null ? bool.Parse(ConfigurationManager.AppSettings["ResubmitUseLemmatazation"]) : false;
        }

        public Resubmit(bool lemmatization, bool synonyms)
        {
            Lemmatization = lemmatization;
            Synonyms = synonyms;
        }

        public bool Lemmatization { get; set; }
        public bool Synonyms { get; set; }
        public bool Enabled { get; set; }
    }
}
