﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public delegate void CompletedSearchHandler(CompletedSearchEventArgs completedSearchEventArgs);
    
    public interface ICompletedSearchPublisher
    {
        void AddCompletedSearchHandler(CompletedSearchHandler completedSearchHandler);
        void RemoveCompletedSearchHandler(CompletedSearchHandler completedSearchHandler);
    }
}
