﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class SearchTransformation
    {
        public string Action { get; set; }
        public string Custom { get; set; }
        public int MessageId { get; set; }
        public string Message { get; set; }
        public string Name { get; set; }
        public string Search { get; set; }
    }
}
