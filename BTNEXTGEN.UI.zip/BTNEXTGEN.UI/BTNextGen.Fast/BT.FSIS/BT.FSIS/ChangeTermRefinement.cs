﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class ChangeTermRefinement : SearchRefinement
    {
        private string m_originalTerm;
        private string m_replacmentTerm;

        public ChangeTermRefinement(string originalTerm, string replacementTerm) : base(false, false)
        {
            m_originalTerm = originalTerm;
            m_replacmentTerm = replacementTerm;
        }

        public string OriginalTerm { get { return m_originalTerm; } }
        public string ReplacementTerm { get { return m_replacmentTerm; } }

    }
}
