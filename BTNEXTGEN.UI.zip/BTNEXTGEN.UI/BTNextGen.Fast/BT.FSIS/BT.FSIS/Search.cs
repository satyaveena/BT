﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Runtime;

using Microsoft.Ceres.InteractionEngine.ContextModifiers.Ims;
using Microsoft.Ceres.InteractionEngine.Services;
using System.Xml.Serialization;

using Com.FastSearch.Esp.Search.Query;

namespace BT.FSIS
{
    public class Search
    {
        public Search()
        {
            Locale = CultureInfo.CurrentCulture;
            Resubmit = new Resubmit();
            Collapsing = new Collapsing();
        }

        public Search(SearchOperator searchOperator) 
        { 
            SearchOperator = searchOperator;
            Locale = CultureInfo.CurrentCulture;
            Resubmit = new Resubmit();
            Collapsing = new Collapsing();
        }

        internal Search Clone()
        {
            return (Search)this.MemberwiseClone();
        }

        public IQuery ToIQuery()
        {
            Query espQuery = new Query();

            if(this.Resubmit != null && this.Resubmit.Enabled)
            {
                int resubmitFlags = 0;
                if(this.Resubmit.Lemmatization)
                {
                    resubmitFlags |= 0x00000040;
                }

                if(this.Resubmit.Synonyms)
                {
                    resubmitFlags |= 0x08000000;
                }

                espQuery.SetParameter(new SearchParameter(BaseParameter.RESUBMITFLAGS, resubmitFlags));
            }

            //espQuery.SetParameter(new SearchParameter(BaseParameter.RESULT_VIEW, this.ResultView));
            //espQuery.SetParameter(new SearchParameter(BaseParameter.QT_PIPELINE, this.QTPipeline));

            if (this.Collapsing != null && this.Collapsing.Enabled)
            {
                throw new NotImplementedException();
            }

            //imsSearch.Locale = this.Locale;

            //espQuery.SetParameter(new SearchParameter(BaseParameter.RP_PIPELINE, this.RPPipeline));
            if (this.SortElements != null && this.SortElements.Length == 1)
            {
                //TODO:  Handle direction?
                espQuery.SetParameter(new SearchParameter(BaseParameter.SORT_BY, this.SortElements[0]));
            }
            else if (this.SortElements != null && this.SortElements.Length > 1)
            {
                throw new NotImplementedException();
            }

            if (this.spellCheckType != SpellCheckType.None)
            {
                espQuery.SetParameter(new SearchParameter(BaseParameter.SPELL, this.spellCheckType.ToString()));
            }
        
            if(this.TimeOut > 0)
            {
                espQuery.SetParameter(new SearchParameter(BaseParameter.TIMEOUT, this.TimeOut));
            }

            if (this.AdditionalParameters != null)
            {
                foreach (AdditionalParameter additionalParam in this.AdditionalParameters)
                {
                    espQuery.SetParameter(new SearchParameter(additionalParam.Name, additionalParam.Value));
                }
            }

            if (SearchOperator != null)
            {
                espQuery.QueryString = this.SearchOperator.ToFQL();
            }

            return espQuery;
        }

        public ImsSearch ToImsSearch()
        {
            ImsSearch imsSearch = new ImsSearch("imsSearch");

            if(this.Resubmit != null && this.Resubmit.Enabled)
            {
                imsSearch.Resubmit = new ImsResubmit();
                imsSearch.Resubmit.Lemmatization = this.Resubmit.Lemmatization;
                imsSearch.Resubmit.Synonyms = this.Resubmit.Synonyms;
            }

            imsSearch.ResultView = this.ResultView;
            imsSearch.QTPipeline = this.QTPipeline;
            //imsSearch.FreshnessBoost = this.FreshnessBoost;

            if (this.Collapsing != null && this.Collapsing.Enabled)
            {
                imsSearch.Collapsing = new ImsCollapsing();
                imsSearch.Collapsing.DocumentsToKeep = this.Collapsing.DocumentsToKeep;
                imsSearch.Collapsing.Field = this.Collapsing.Field;
            }

            imsSearch.Locale = this.Locale;
            imsSearch.RPPipeline = this.RPPipeline;
            imsSearch.SortElements = this.SortElements;
            imsSearch.SpellCheckType = (ImsSpellCheckType)Enum.Parse(typeof(ImsSpellCheckType), this.spellCheckType.ToString());
            imsSearch.Timeout = this.TimeOut;

            if (this.AdditionalParameters != null)
            {
                foreach (AdditionalParameter additionalParam in this.AdditionalParameters)
                {
                    imsSearch.AdditionalParameters.Add(additionalParam.ToImsAdditionalParameter());
                }
            }

            if (SearchOperator != null)
            {
                imsSearch.SearchOperator = this.SearchOperator.ToImsSearchOperator();
            }
            return imsSearch;
        }

        internal SearchOperator AddOperator(SearchOperator op1, SearchOperator op2)
        {
            SearchOperator returnOp = op1;

            if (op1 is GroupOperator && ((GroupOperator)op1).Type == GroupOperatorType.And && ((GroupOperator)op1).Scopes.Count == 0)
            {
                ((GroupOperator)op1).Operators.Add(op2);
            }
            else
            {
                returnOp = new GroupOperator(GroupOperatorType.And, new List<SearchOperator>(){op1, op2});
            }

            return returnOp;
        }

        public AdditionalParameter[] AdditionalParameters { get; set; }
        public ClusterDefinition[] Clusters { get; set; }
        public Collapsing Collapsing { get; set; }
        public DateTime FreshnessBoost { get; set; }

        [XmlIgnoreAttribute()]
        public CultureInfo Locale { get; set; }

        public Navigation Navigation { get; set; }
        public Resubmit Resubmit { get; set; }
        public string QTPipeline { get; set; }
        public string RPPipeline { get; set; }
        public string ResultView { get; set; }
        public SearchOperator SearchOperator { get; set; }
        public string[] SortElements { get; set; }
        public SpellCheckType spellCheckType { get; set; }
        public int TimeOut { get; set; }
    }
}
