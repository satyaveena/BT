﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.FSIS
{
    public class Cluster
    {
        public int LeafNodeCount { get; set; }
        public string Name { get; set; }
        public int NodeCount { get;  set; }
        public int TotalDocumentCount { get; set; }
        public List<ClusterNode> Nodes { get; set; }
        public string NavigatorName { get;  set; }
        public ClusterSort Sort { get; private set; }

        public Cluster()
        {
            Nodes = new List<ClusterNode>();
        }

        internal void AssignValues(Navigator navdata, ClusterDefinition clusterDef)
        {
            if (navdata.FieldType != FieldType.String)
            {
                throw new InvalidOperationException("Cluster cannot be created from a non-string navigator.");
            }

            Name = clusterDef.Name;
            Sort = clusterDef.Sort;
            NavigatorName = navdata.Name;
            TotalDocumentCount = navdata.DocumentCount;
            string clusterField = (clusterDef.Field != null) ? clusterDef.Field : navdata.FieldName;
            // create the cluster node tree
            for (var i = 0; i < navdata.NavigatorGroups.Count; i++)
            {
                string groupValue = navdata.NavigatorGroups[i].Value;

                // Remove any invalid characters - ^ and/or " at the beginning, " and/or $ at the end
                if (groupValue[0] == '^')
                {
                    groupValue = groupValue.Substring(1);
                }

                if (groupValue[groupValue.Length - 1] == '$')
                {
                    groupValue = groupValue.Substring(0, groupValue.Length - 1);
                }

                if (groupValue[0] == '"' && groupValue[groupValue.Length - 1] == '"')
                {
                    groupValue = groupValue.Substring(1, groupValue.Length - 2);
                }

                string[] pathElements = groupValue.Split(clusterDef.PathSeparator);
                ClusterNode currentNode = null;
                List<ClusterNode> currentSubnodes = Nodes;
                List<string> currentPath = new List<string>();
                for (var j = 0; j < pathElements.Length; j++)
                {
                    currentPath.Add(pathElements[j]);
                    // see if this node already exists
                    ClusterNode foundNode = null;
                    if (currentSubnodes != null)
                    {
                        for (var k = 0; k < currentSubnodes.Count && foundNode == null; k++)
                        {
                            if (currentSubnodes[k].PathName == pathElements[j])
                            {
                                foundNode = currentSubnodes[k];
                            }
                        }
                    }

                    // if this node doesn't exist, create it
                    var newNode = false;
                    if (foundNode == null)
                    {
                        newNode = true;
                        foundNode = new ClusterNode();
                        foundNode.Path = string.Join(new string(new char[] { clusterDef.PathSeparator }), currentPath.ToArray());
                        ClusterNodeInfo nodeInfo = null;
                        if (clusterDef.NameTranslator != null)
                        {
                            nodeInfo = clusterDef.NameTranslator(foundNode.Path);
                        }
                        else
                        {
                            nodeInfo = new ClusterNodeInfo(pathElements[j], pathElements[j]);
                        }

                        foundNode.Name = nodeInfo.DisplayName;
                        foundNode.ClusterName = clusterDef.Name;
                        foundNode.SortKey = nodeInfo.SortKey;
                        foundNode.PathName = pathElements[j];
                        foundNode.LocalDocumentCount = (j == pathElements.Length - 1) ? navdata.NavigatorGroups[i].DocumentCount : 0;
                        foundNode.ExactInclustionRefinement = new ClusterNodeRefinement(foundNode.ClusterName, clusterField, foundNode.Path, true, true);
                        foundNode.SubtreeInclustionRefinement = new ClusterNodeRefinement(foundNode.ClusterName, clusterField, foundNode.Path, false, true);
                        foundNode.ExactExclustionRefinement = new ClusterNodeRefinement(foundNode.ClusterName, clusterField, foundNode.Path, true, false);
                        foundNode.SubtreeExclustionRefinement = new ClusterNodeRefinement(foundNode.ClusterName, clusterField, foundNode.Path, false, false);
                        if (currentNode != null)
                        {
                            currentNode.SubNodeCount++;
                        }

                        foundNode.TotalDocumentCount += navdata.NavigatorGroups[i].DocumentCount;
                    }
                    else
                    {
                        foundNode.TotalDocumentCount += navdata.NavigatorGroups[i].DocumentCount;
                    }

                    // determine the correct sort location for this node
                    if (newNode)
                    {
                        var done = false;
                        for (var l = 0; l < currentSubnodes.Count && !done; l++)
                        {
                            bool doInsert = false;
                            if (Sort == ClusterSort.HitCount)
                            {
                                if (currentSubnodes[l].TotalDocumentCount < foundNode.TotalDocumentCount)
                                {
                                    doInsert = true;
                                }
                            }
                            else if (Sort == ClusterSort.Alpha)
                            {
                                if (currentSubnodes[l].SortKey.CompareTo(foundNode.SortKey) > 0)
                                {
                                    doInsert = true;
                                }
                            }
                            else
                            {
                                throw new InvalidOperationException("Invalid sort specified");
                            }

                            if (doInsert)
                            {
                                currentSubnodes.Insert(l, foundNode);
                                done = true;
                            }
                        }

                        if (!done)
                        {
                            currentSubnodes.Add(foundNode);
                        }
                    }
                    else
                    {
                        if (Sort == ClusterSort.HitCount)
                        {
                            // Reorder in-case the hitcount changed.


                            foreach (ClusterNode currentSortNode in currentSubnodes)
                            {
                                if (foundNode.TotalDocumentCount > currentSortNode.TotalDocumentCount)
                                {
                                    currentSubnodes.Remove(foundNode);
                                    currentSubnodes.Insert(currentSubnodes.IndexOf(currentSortNode), foundNode);
                                    break;
                                }
                            }
                        }
                    }

                    currentNode = foundNode;
                    currentSubnodes = currentNode.SubNodes;
                }
            }

            // calculate the counts for the cluster
            NodeCount = Nodes.Count;
            LeafNodeCount = 0;
            for (var i = 0; i < Nodes.Count; i++)
            {
                this.LeafNodeCount += ClusterNode.CalculateLeafNodeCount(Nodes[i]);
            }
        }
    }
}
