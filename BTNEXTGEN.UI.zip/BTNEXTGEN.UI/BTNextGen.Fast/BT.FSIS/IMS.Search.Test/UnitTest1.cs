﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AhlSys.IMS.Search;
using AhlSys.IMS.Search.WCF;

namespace AhlSys.IMS.Search.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestSimpleSearch()
        {
            ISearchExecutor searchExecutor = SearchExecutorFactory.Create();
            Search search = new Search(SearchOperatorFactory.CreateSearchOperatorFromImsSimpleLanguage("Obama"));
            searchExecutor.DefineSearch(search, 0, 10);
            while (searchExecutor.IsSearching) continue;
            SearchResults results = searchExecutor.Results;
        }
    }
}
