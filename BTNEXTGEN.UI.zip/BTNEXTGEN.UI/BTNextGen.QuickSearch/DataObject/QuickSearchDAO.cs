﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using BTNextGen.CartFramework;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BT.TS360Constants;
using BTNextGen.Commerce.Portal.Common.DataAccessObject;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using LineItem = BTNextGen.CartFramework.Order.LineItem;

namespace BTNextGen.QuickSearch.DataObject
{
    public class QuickSearchDAO : BaseDAO
    {
        private static QuickSearchDAO _instance;
        private string _connectionStringCache = string.Empty;
        private const string ConnectStringProvider = "provider";
        private const char Semicolon = ';';

        private QuickSearchDAO() { }

        public static QuickSearchDAO Instance
        {
            get { return _instance ?? (_instance = new QuickSearchDAO()); }
        }

        public override string ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_connectionStringCache))
                {
                    InitializeConnectionString();
                }
                return _connectionStringCache;
            }
        }

        public void InitializeConnectionString()
        {
            var connectString = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.OrdersConnectionstring).Value;
            if (connectString.ToLower().Contains(ConnectStringProvider))
            {
                int firstDelimeter = connectString.IndexOf(Semicolon);
                connectString = connectString.Substring(firstDelimeter + 1);
            }
            _connectionStringCache = connectString;
        }

        protected override SqlCommand CreateSqlSpCommand(string spName, SqlConnection sqlConnection)
        {
            var command = base.CreateSqlSpCommand(spName, sqlConnection);

            var paramErrorMessage = new SqlParameter("@ErrorMessage", SqlDbType.VarChar, -1) { Direction = ParameterDirection.Output };

            var paramReturnValue = new SqlParameter("returnVal", SqlDbType.Int) { Direction = ParameterDirection.ReturnValue };

            command.Parameters.Add(paramErrorMessage);
            command.Parameters.Add(paramReturnValue);

            return command;
        }

        internal DataSet GetActiveCarts(int topCartsNo, string userId)
        {
            var ds = new DataSet();

            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360QuickSearchGetActiveCarts, dbConnection);

            //<Parameter>
            var paramRowCountNo = new SqlParameter("@Rowcount", SqlDbType.Int) { Direction = ParameterDirection.Input, Value = topCartsNo };
            var paramUserId = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.AddRange(new[] { paramRowCountNo, paramUserId });

            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }

            return ds;
        }

        internal DataSet GetPrimaryCart(string userId)
        {
            var ds = new DataSet();

            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360QuickSearchGetPrimaryBasket, dbConnection);

            var sqlParameter = new SqlParameter("@u_user_id", SqlDbType.VarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParameter);

            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }

            return ds;
        }

        internal string AddProductsToCart(string userId, string cartName, string userFolderId, string cartId, List<LineItem> lineItems, out string PermissionViolationMessage)
        {
            var basketSummaryId = cartId;

            var linesDataSet = DataConverter.ConvertCartLineItemsToDataset(lineItems);

            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360QuickSearchAddProductToCart, dbConnection);

            var cartNameParam = new SqlParameter("@CartName", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartName
            };

            var userFolderIdParam = new SqlParameter("@UserFolderId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userFolderId
            };
            var userIdParam = new SqlParameter("@UserId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userId
            };
            var lineItemsParam = new SqlParameter("@BasketLineItems", SqlDbType.Structured)
                                     {
                                         Value = DataAccessHelper.GenerateDataRecords(linesDataSet)
                                     };
            var basketSummaryIdParam = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.InputOutput
            };
            if(string.IsNullOrEmpty(cartId))
            {
                basketSummaryIdParam.Value = DBNull.Value;
            }
            else
            {
                basketSummaryIdParam.Value = cartId;
            }
            var permissionViolationMessage = new SqlParameter("@PermissionViolationMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            command.Parameters.AddRange(new[]{
                                        cartNameParam, userFolderIdParam, userIdParam, lineItemsParam, basketSummaryIdParam, permissionViolationMessage
            });

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);
                basketSummaryId = basketSummaryIdParam.Value != null ? basketSummaryIdParam.Value.ToString() : cartId;
                PermissionViolationMessage = command.Parameters["@PermissionViolationMessage"].Value as string;
            }
            finally
            {
                dbConnection.Close();
            }
            return basketSummaryId;
        }

        private void HandleCartException(SqlCommand command)
        {
            var paramValue = command.Parameters["returnVal"].Value;
            var returnCode = -1;

            if (paramValue != null)
            {
                returnCode = DataAccessHelper.ConvertToInt(paramValue);
            }

            if (returnCode == 0)
                return;

            if (returnCode == 2)
            {
                var dupNameEx = new CartManagerException(CartManagerException.CART_DUPLICATE_NAME);
                throw dupNameEx;
            }

            //Error
            paramValue = command.Parameters["@ErrorMessage"].Value;
            var errorMessage = paramValue != null ? paramValue.ToString() : "";
            var exception = new CartManagerException(errorMessage);

            if (exception.Message.Equals(CartManagerException.CART_DUPLICATE_NAME))
            {
                exception.isBusinessError = true;
            }
            else
                Logger.RaiseException(exception, ExceptionCategory.Order);

            throw exception;
        }
    }
}
