﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BTNextGen.CartFramework;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.CartFramework.Order;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.QuickSearch.DataObject;
using BTNextGen.VelocityCaching;

namespace BTNextGen.QuickSearch
{
    public class QuickSearchManager
    {
        internal const string PrimaryCartCacheKeySuffix = "QUICK_PRIMARY_CART";
        private static QuickSearchManager _instance;

        private QuickSearchManager() { }

        public static QuickSearchManager Instance
        {
            get { return _instance ?? (_instance = new QuickSearchManager()); }
        }

        public Cart GetPrimaryCart(string userId)
        {
            //var cacheKey = GetPrimaryCartCacheKey(userId);
            //var cartFromCache = VelocityCacheManager.Read(cacheKey) as Cart;
            //if (cartFromCache != null) return cartFromCache;

            //var peBeginTime = Logger.DebugTraceLogBegin(ExceptionCategory.Search, "QuickSearchManager.GetPrimaryCart()");
            //var ds = QuickSearchDAO.Instance.GetPrimaryCart(userId);
            //Logger.DebugTraceLogEnd(ExceptionCategory.Search, "QuickSearchManager.GetPrimaryCart()", peBeginTime);
            //var cart = GetCartFromDataSet(ds, userId);
            //if (cart != null) {
            //    VelocityCacheManager.Write(cacheKey, cart, cart.IsShared ? VelocityCacheLevel.Request : VelocityCacheLevel.Session, PrimaryCartCacheExpiredDuration);
            //}            
            
            // get primary cart from distributed cache
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            var primaryCart = cartManager.GetPrimaryCart();

            return primaryCart;
        }

        public Carts GetActivesCart(string userId)
        {
            const int topCarts = 5;
            var ds = QuickSearchDAO.Instance.GetActiveCarts(topCarts, userId);
            return GetCartsFromDataSet(ds, userId);
        }

        public string AddProductsToCart(string userId, string cartName, string userFolderId, string cartId, List<LineItem> lineItems, out string PermissionViolationMessage)
        {
            var basketSummaryId = QuickSearchDAO.Instance.AddProductsToCart(userId, cartName, userFolderId, cartId, lineItems, out PermissionViolationMessage);

            // clear distributed cache
            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            cartManager.SetPrimaryCartChanged();

            return basketSummaryId;
        }

        private static Carts GetCartsFromDataSet(DataSet ds, string userId)
        {
            //Throw exception if no data returned from DAO
            if (ds == null ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var cartList = new List<Cart>();
            var strUserid = "";

            foreach (DataRow cartRow in ds.Tables[0].Rows)
            {
                var cart = GetCartFromDataRow(cartRow, userId);

                if (cart != null)
                {
                    cartList.Add(cart);

                    if (String.IsNullOrEmpty(strUserid))
                        strUserid = cart.UserId;
                }
            }

            var carts = new Carts(strUserid);
            carts.AddRange(cartList);

            return carts;
        }

        private static Cart GetCartFromDataRow(DataRow row, string userId)
        {
            var cartId = row["BasketSummaryID"].ToString(); 
            var cartName = row["BasketName"].ToString();

            if (String.IsNullOrEmpty(cartId) || String.IsNullOrEmpty(cartName))
                return null;

            var cart = new Cart(cartId, userId, string.Empty) {CartName = cartName};
            return cart;
        }
    } 
}
