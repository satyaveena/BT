﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.QuickSearch
{
    public static class StoreProcedureName
    {
        internal const string ProcTs360QuickSearchGetActiveCarts = "procTS360QuickSearchGetActiveCarts";
        internal const string ProcTs360QuickSearchGetPrimaryBasket = "procTS360QuickSearchGetPrimaryBasket";
        internal const string ProcTs360QuickSearchAddProductToCart = "procTS360QuickSearchAddProductToCart";
    }
}
