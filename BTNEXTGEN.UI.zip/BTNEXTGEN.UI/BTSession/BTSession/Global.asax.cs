﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Helpers;

namespace BTSession
{
    public class Global : Microsoft.SharePoint.ApplicationRuntime.SPHttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            CommonHelper.GetWalkmeSnippet();
            CommonHelper.GetGDPRSnippet();

            // initialize to get and cache access token
            ApiServiceHandlerHelper.GetApiAccessTokenValue();

            // initialize to get and cache SiteBrandings for SSO Login page (#38116)
            ApiServiceHandlerHelper.InitSSOLoginSiteBrandings();

            // initialize to get and cache all Pay Per Circulation subscriptions (#38697)
            ApiServiceHandlerHelper.InitPPCSubscriptions();

        }

        protected void Session_Start(object sender, EventArgs e)
        {
            string[] arrURL = new string[] { 
                "/Pages/eListProducts.aspx"
            };

            string returnURL = Request.Url.PathAndQuery;
            bool isReturn = false;
            foreach (string url in arrURL)
                if (returnURL.StartsWith(url, StringComparison.InvariantCultureIgnoreCase))
                {
                    isReturn = true;
                    break;
                }

            if (isReturn)
            {
                string keyURL = "BTReturnURL" + HttpContext.Current.Session.SessionID;
                HttpContext.Current.ApplicationInstance.Application[keyURL] = returnURL;
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
            //System.Diagnostics.Debugger.Launch();
        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}