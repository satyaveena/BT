﻿using System.Web;
using System.Web.SessionState;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.UI.Orders.Helper;
using BTNextGen.Commerce.Portal.UI.Search.Helper;

namespace BTNextGen.BackgroundProcess.HttpHandlers
{
    /// <summary>
    /// Summary description for ProductSearchHandler
    /// </summary>
    public class BackgroundProcessHandler : IHttpHandler, IReadOnlySessionState
    {
        public void ProcessRequest(HttpContext context)
        {
            if (context != null)
            {
                var cartId = context.Request.QueryString["cartId"];
                var fromCartPage = context.Request.QueryString["fromCartDetails"];
                var invt = context.Request.QueryString["inventorytype"];
                var refreshInvt = context.Request.QueryString["refreshInvt"];
                if (!string.IsNullOrEmpty(fromCartPage) && fromCartPage == "1")
                {
                    AdditionalProductInfo.LoadAdditionalLineItemInfo();
                }
                else if (!string.IsNullOrEmpty(cartId))
                {
                    CartFrameworkHelper.CalculatePrice(cartId);
                }
                else if (!string.IsNullOrEmpty(invt) || !string.IsNullOrEmpty(refreshInvt))
                {
                    if (!string.IsNullOrEmpty(invt))
                    {
                        DistributedCacheHelper.GetCurrentUserReservedType();
                    }
                    else
                    {
                        DistributedCacheHelper.UpdateCurrentUserReservedType();
                    }
                }
                else
                {
                    var fromCmNewReleases = context.Request.QueryString["cmNR"];
                    if (!string.IsNullOrEmpty(fromCmNewReleases) && fromCmNewReleases == "1")
                    {
                        CmBackgroundInfo.LoadProductInfoForNewReleases();
                    }
                    else
                    {
                        AdditionalProductInfo.LoadAdditionalProductInfo();
                    }
                }
            }
            else
            {
                AdditionalProductInfo.LoadAdditionalProductInfo();
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}