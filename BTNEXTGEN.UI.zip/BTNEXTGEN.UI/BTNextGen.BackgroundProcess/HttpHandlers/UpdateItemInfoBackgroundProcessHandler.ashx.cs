﻿using System.Web;
using System.Web.SessionState;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.UI.Orders.Helper;
using BTNextGen.Commerce.Portal.UI.Search.Helper;

namespace BTNextGen.BackgroundProcess.HttpHandlers
{
    /// <summary>
    /// Summary description for ProductSearchHandler
    /// </summary>
    public class UpdateItemInfoBackgroundProcessHandler : IHttpHandler, IReadOnlySessionState
    {
        public void ProcessRequest(HttpContext context)
        {
            if (context != null)
            {
                var uiHelper = new UpdateItemBackgroundHelper();
                uiHelper.UpdateItemOrderingInformation();
            }           
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}