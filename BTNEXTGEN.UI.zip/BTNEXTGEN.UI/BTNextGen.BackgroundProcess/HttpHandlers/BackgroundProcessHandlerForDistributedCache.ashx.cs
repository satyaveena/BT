﻿using System.Web;
using System.Web.SessionState;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.VelocityCaching;

namespace BTNextGen.BackgroundProcess.HttpHandlers
{
    /// <summary>
    /// Summary description for BackgroundProcessHandlerForDistributedCache
    /// </summary>
    public class BackgroundProcessHandlerForDistributedCache : IHttpHandler, IReadOnlySessionState
    {
        public void ProcessRequest(HttpContext context)
        {
            if (context != null)
            {
                var orgId = context.Request.QueryString["orgId"];
                if (string.IsNullOrEmpty(orgId)) return;

                var updateFieldCodeInd = context.Request.QueryString["ufci"];

                if (string.IsNullOrEmpty(updateFieldCodeInd))
                {
                    DistributedCacheHelper.PopulateGridFieldsCodesCacheData(orgId);
                    DistributedCacheHelper.PopulateGridTemplatesCacheData(orgId);
                }
                else
                {
                    switch (updateFieldCodeInd)
                    {
                        case "1":
                            DistributedCacheHelper.UpdateGridFieldsCodesCacheData(orgId);
                            break;
                        case "2":
                            DistributedCacheHelper.UpdateGridTemplatesCacheData(orgId);
                            break;
                        case "3":
                            // TODO: clean cache 
                            break;
                        case "4":
                            // TODO: clean cache 
                            break;
                    }
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}