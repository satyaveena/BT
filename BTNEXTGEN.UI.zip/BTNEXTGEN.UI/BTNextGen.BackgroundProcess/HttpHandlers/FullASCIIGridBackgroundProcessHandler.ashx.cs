﻿using System.Web;
using System.Web.SessionState;
using BTNextGen.CartFramework;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Commerce.Portal.Common.SlipAlertService;
using BTNextGen.Commerce.Portal.UI.Orders;
using BTNextGen.VelocityCaching;
using Microsoft.SharePoint;
using System;
using PermissionType = BT.TS360Constants.PermissionType;
using DownloadExportMode = BT.TS360Constants.DownloadExportMode;

namespace BTNextGen.BackgroundProcess.HttpHandlers
{
    /// <summary>
    /// Summary description for Mass Quantity
    /// </summary>
    public class FullASCIIGridBackgroundProcessHandler : IHttpHandler, IReadOnlySessionState
    {
        public void ProcessRequest(HttpContext context)
        {
            if (context != null)
            {
                var userId = VelocityCacheManager.Read("DownloadFullASCII_UserId") as string;
                var basketId = VelocityCacheManager.Read("DownloadFullASCII_basketId") as string;
                int sortBy = 1;
                var cache_SortBy = VelocityCacheManager.Read("DownloadFullASCII_SortBy") as int?;
                if (cache_SortBy != null)
                    sortBy = (int)cache_SortBy;
                var cache_Direction = VelocityCacheManager.Read("DownloadFullASCII_Direction") as string;
                var direction = String.IsNullOrEmpty(cache_Direction) ? "ASC" : cache_Direction;
                var odownloadExportMode = VelocityCacheManager.Read("DownloadFullASCII_downloadExportMode");
                var downloadExportMode = DownloadExportMode.FullASCIIGrid;
                if (odownloadExportMode != null)
                    downloadExportMode = (DownloadExportMode)odownloadExportMode;
                var changeStatus = VelocityCacheManager.Read("DownloadFullASCII_changeStatus") as string;
                var inclColHeading = VelocityCacheManager.Read("DownloadFullASCII_inclColHeading") as string;

                if (userId == null || basketId == null)
                {
                    string msg = (userId ?? "userId == null") + (basketId ?? "basketId == null");
                    Logger.Write("BackgroundDownloadCart", msg);
                    return;
                }
                try
                {

                    var cart = CartContext.Current.GetCartManagerForUser(userId).GetCartById(basketId);
                    string orderedDownloadedUserId;
                    if (changeStatus == "1")
                        orderedDownloadedUserId = SiteContext.Current.IsProxyActive ? SiteContext.Current.BtUserId : SiteContext.Current.UserId;
                    else
                        orderedDownloadedUserId = string.Empty;

                    var lineItems = cart.DowndloadExport(changeStatus == "1", orderedDownloadedUserId);
                    var permissions = ProfileController.Current.GetCurrentUserPermissions(false);
                    var isBtUser = (permissions != null) && permissions.AllowedPermissions.Contains(PermissionType.IsBTEmployee); // true;
                    var isShareCart = BasketHelper.IsCartShared(SiteContext.Current.UserId, basketId);
                    string temp = BasketHelper.InitializeDownloadContent(lineItems, cart, downloadExportMode, isBtUser,
                                                                         isShareCart, inclColHeading == "1");
                    temp = temp.Replace("<br>", "\n");
                    string fileName = cart.CartOwnerName + "_" + cart.CartName + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
                    string fullPath = string.Empty;
                    SPSecurity.RunWithElevatedPrivileges(delegate
                    {
                        using (var site = new SPSite(SPContext.Current.Site.RootWeb.Url + "/sites/publishing"))
                        {
                            using (SPWeb web = site.RootWeb)
                            {
                                web.AllowUnsafeUpdates = true;
                                var spList = web.Lists["DownloadFormat"];
                                byte[] content = System.Text.Encoding.ASCII.GetBytes(temp);
                                SPFolder folder = spList.RootFolder;
                                fullPath = folder.Url + "/" + fileName;
                                SPFile newFile = folder.Files.Add(fullPath, content);
                                newFile.Item.Update();
                                web.AllowUnsafeUpdates = false;
                            }
                        }
                    });

                    var slipAlert = new UserAlerts();
                    var svc1Getresp = slipAlert.GetUserAlertMessageTemplate(AlertMessageTemplateIDEnum.DownloadCartComplete, true);

                    string AlertMessageComplete = string.Empty;

                    if (svc1Getresp.Status == "OK")
                        AlertMessageComplete = svc1Getresp.AlertMessageTemplate;
                    else
                    {
                        AlertMessageComplete = @"Download Cart – Full ASCII including Grid has completed for cart <b>@cartname</b>. <a href = '@URL'><b>Download NOW</b></a>";
                        Logger.Write("BackgroundDownloadCart", svc1Getresp.ErrorMessage);
                    }

                    AlertMessageComplete = AlertMessageComplete.Replace("@cartname", cart.CartName);
                    AlertMessageComplete = AlertMessageComplete.Replace("@URL", "/sites/publishing/" + fullPath);
                    string userid = SiteContext.Current.UserId;

                    var svc1resp = new CreateUserAlertMessageResponse();
                    svc1resp = slipAlert.CreateUserAlertMessage(AlertMessageComplete, userid, AlertMessageTemplateIDEnum.DownloadCartComplete, true, "DownloadCartUI");

                    if (svc1resp.Status != "OK")
                    {
                        Logger.Write("BackgroundDownloadCart", svc1resp.ErrorMessage);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write("BackgroundDownloadCart", ex.Message);
                    var slipAlert = new UserAlerts();
                    var svc1Getresp = slipAlert.GetUserAlertMessageTemplate(AlertMessageTemplateIDEnum.DownloadCartFail, true);

                    string AlertMessageFail = string.Empty;

                    if (svc1Getresp.Status == "OK")
                        AlertMessageFail = svc1Getresp.AlertMessageTemplate;
                    else
                    {
                        AlertMessageFail = @"Download Cart – Full ASCII including Grid was unable to be completed for the cart <b>@cartname</b> due to a system issue. Please contact administrator.";
                        Logger.Write("BackgroundDownloadCart", svc1Getresp.ErrorMessage);
                    }
                    AlertMessageFail = AlertMessageFail.Replace("@cartname", basketId);
                    string userid = SiteContext.Current.UserId;

                    var svc1resp = slipAlert.CreateUserAlertMessage(AlertMessageFail, userid, AlertMessageTemplateIDEnum.DownloadCartFail,true, "DownloadCartUI");

                    if (svc1resp.Status != "OK")
                    {
                        Logger.Write("BackgroundDownloadCart", svc1resp.ErrorMessage);
                    }
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
