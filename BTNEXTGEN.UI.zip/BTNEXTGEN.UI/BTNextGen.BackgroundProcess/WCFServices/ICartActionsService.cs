﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace BTNextGen.BackgroundProcess.WCFServices
{
    [ServiceContract]
    public interface ICartActionsService
    {
        [OperationContract]
        void CreateCopyOfCart(string basketId, string userId, string newCartName, string destinationFolderId, string copyCartType, bool activePrimaryCart, bool copyESP);

        [OperationContract]
        void CopyCartsToFolder(List<string> cartIds, string userId, string destinationFolderId, string copyCartType, bool copyESP);

        [OperationContract]
        void MoveCartsToFolder(List<string> cartIds, string userId, string destinationFolderId);

        [OperationContract]
        void MergeCarts(string targetCartId, string userId, List<string> listCartsIdToMerge, List<string> listCartsIdToDelete);

        [OperationContract]
        void ApplyGridTemplate(string gridTemplateId, string userId, string orgId, int applyOption, List<string> listCartId, int duplicateOption);

        [OperationContract]
        void ApplyDefaultGridTemplate(string cartId, string userId, string orgId, int applyOption, int duplicateOption);
    }
}
