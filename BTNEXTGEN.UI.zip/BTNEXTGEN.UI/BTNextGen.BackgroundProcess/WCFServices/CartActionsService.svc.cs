﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.ServiceModel.Activation;
using System.Text;
using System.Threading;
using System.Xml;
using BTNextGen.BackgroundProcess.WCFServices;
using BTNextGen.CartFramework;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.DataAccessObject;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart;
using BTNextGen.Grid.Exception;
using System.ServiceModel;

namespace BTNextGen.BackgroundProcess.WCFServices
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)] 
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CartActionsService : ICartActionsService
    {
        public void CreateCopyOfCart(string basketId, string userId, string newCartName, string destinationFolderId,
            string copyCartType, bool activePrimaryCart, bool copyESP)
        {
            try
            {
                var createdDateTime = DateTime.Now;
                var copyType = (CartCopyType)Enum.Parse(typeof(CartCopyType), copyCartType);                
                CartGridContext.Current.Impersonate(SiteContext.Current.OrganizationId, userId);

                CartGridContext.Current.CartGridManager.CreateACopyOfCart(basketId, newCartName, destinationFolderId,
                    string.Empty, copyType, copyESP);
                var cart = SetCartAsPrimaryByName(newCartName, userId, activePrimaryCart);
                if (cart != null)
                {
                    CartFrameworkHelper.CalculatePrice(cart.CartId);
                }
                InsertUserAlertMessage(userId, (int)BTAlertDAO.UserAlertTemplateID.CopyCart,createdDateTime);
            }
            catch (CartManagerException cartManagerException)
            {
                if (!cartManagerException.isBusinessError)
                    Logger.LogException(cartManagerException);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            finally
            {
                CartGridContext.Current.UndoImpersonate();
            }
            
        }

        public void CopyCartsToFolder(List<string> cartIds, string userId, string destinationFolderId, string copyCartType, bool copyESP)
        {
            try
            {
                var createdDateTime = DateTime.Now;
                var cartCopyType = string.IsNullOrEmpty(copyCartType)
                                           ? CartCopyType.NoChoose
                                           : (CartCopyType)int.Parse(copyCartType);
                if (string.IsNullOrEmpty(destinationFolderId))
                    return;
                //
                var cartManager = CartContext.Current.GetCartManagerForUser(userId);
                cartManager.CreateCopyOfCarts(cartIds, destinationFolderId, cartCopyType, copyESP);

                InsertUserAlertMessage(userId, (int)BTAlertDAO.UserAlertTemplateID.CopyCart, createdDateTime);
            }
            catch (CartManagerException cartManagerException)
            {
                if (!cartManagerException.isBusinessError)
                    Logger.LogException(cartManagerException);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
        }

        public void MoveCartsToFolder(List<string> cartIds, string userId, string destinationFolderId)
        {
            try
            {
                var createdDateTime = DateTime.Now;
                CartContext.Current.GetCartManagerForUser(userId).MoveCartsToFolder(cartIds, destinationFolderId);
                InsertUserAlertMessage(userId, (int)BTAlertDAO.UserAlertTemplateID.MoveCart, createdDateTime);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
        }

        public void MergeCarts(string targetCartId, string userId, List<string> listCartsIdToMerge, List<string> listCartsIdToDelete)
        {
            try
            {
                var retVal = 0;
                var createdDateTime = DateTime.Now;
                string PermissionViolationMessage;
                string ErrorMessage;
                //get list cart id to be merged
                listCartsIdToMerge = listCartsIdToMerge.Where(x => x != targetCartId).ToList();
                var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);                
                var targetCart = cartManager.GetCartById(targetCartId);
                if (targetCart != null)
                {
                    cartManager = CartContext.Current.GetCartManagerForUser(targetCart.CartOwnerId);
                    retVal = cartManager.MergeCarts(targetCartId, listCartsIdToMerge, listCartsIdToDelete,
                        targetCart.CartAccounts, out PermissionViolationMessage, out ErrorMessage);

                    if ( retVal==1 )
                    {}
                    else
                    {
                        InsertUserAlertMessage(userId, (int)BTAlertDAO.UserAlertTemplateID.MergeCart, createdDateTime);    
                    }
                }
            }
            catch (CartManagerException cartManagerException)
            {
                if (!cartManagerException.isBusinessError)
                    Logger.LogException(cartManagerException);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }            
        }

        public void ApplyGridTemplate(string gridTemplateId, string userId, string orgId, int applyOption, List<string> listCartId, int duplicateOption)
        {
            try
            {
                CartGridContext.Current.Impersonate(orgId, userId);
                var createdDateTime = DateTime.Now;
                var applyMethod = (ApplyTemplateMethod) applyOption;

                var dupOptionFlag = duplicateOption == -1 || duplicateOption != 1;

                foreach (string cartId in listCartId)
                {
                    switch (applyMethod)
                    {
                        case ApplyTemplateMethod.ToAllTitles:
                            CartGridContext.Current.CartGridManager.ApplyTemplateToCartAppendToAllTitles(
                                gridTemplateId, cartId, dupOptionFlag);
                            break;
                        case ApplyTemplateMethod.ToNonGridTitles:
                            CartGridContext.Current.CartGridManager.ApplyTemplateToNonGridTitles(gridTemplateId,
                                cartId);
                            break;
                        default:
                            CartGridContext.Current.CartGridManager.ApplyTemplateToTitleAsReplace(gridTemplateId,
                                cartId);
                            break;
                    }
                }
                InsertUserAlertMessage(userId, (int) BTAlertDAO.UserAlertTemplateID.ApplyGridTemplate, createdDateTime);
            }
            catch (CartGridDatabaseException cartGridException)
            {
                if (!cartGridException.IsBusinessError)
                    Logger.Write("ApplyGridTemplatesToCarts", cartGridException.Message);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            finally
            {
                CartGridContext.Current.UndoImpersonate();
            }
        }

        public void ApplyDefaultGridTemplate(string cartId, string userId, string orgId, int applyOption, int duplicateOption)
        {
            try
            {
                CartGridContext.Current.Impersonate(orgId, userId);
                var createdDateTime = DateTime.Now;
                var applyMethod = (ApplyTemplateMethod)applyOption;

                var dupOptionFlag = duplicateOption == -1 || duplicateOption != 1;

                switch (applyMethod)
                {
                    case ApplyTemplateMethod.ToAllTitles:
                        CartGridContext.Current.CartGridManager.ApplyDefaultGridTemplateToCartAllTitle(cartId,
                                                                                                       dupOptionFlag,
                                                                                                       true);
                        break;
                    case ApplyTemplateMethod.ToNonGridTitles:
                        CartGridContext.Current.CartGridManager.ApplyDefaultGridTemplateToCartNonGridTitles(cartId);
                        break;
                    default:
                        CartGridContext.Current.CartGridManager.ApplyDefaultGridTemplateToCartAsAReplace(cartId);
                        break;
                }

                CartFrameworkHelper.CalculatePrice(cartId);

                InsertUserAlertMessage(userId, (int)BTAlertDAO.UserAlertTemplateID.ApplyGridTemplate, createdDateTime);
            }
            catch (CartGridDatabaseException ex)
            {
                if (!ex.IsBusinessError)
                    Logger.LogException(ex);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            finally
            {
                CartGridContext.Current.UndoImpersonate();
            }
        }

        private Cart SetCartAsPrimaryByName(string cartName, string userId, bool isActivePrimaryCart)
        {
            CartManager cartManager = CartContext.Current.GetCartManagerForUser(userId);
            var cart = cartManager.GetCartByName(cartName);
            if (cart != null)
            {
                if (isActivePrimaryCart)
                    cartManager.SetCartAsPrimary(cart.CartId);

                return cart;
            }

            return null;
        }

        private static void InsertUserAlertMessage(string userId, int alertMsgTemplateId, DateTime dateTime)
        {
            BTAlertDAO.Instance.InsertUserAlerts(userId, alertMsgTemplateId, dateTime);
        }
    }
}
