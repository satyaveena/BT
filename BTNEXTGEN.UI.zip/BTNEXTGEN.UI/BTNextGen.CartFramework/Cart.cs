﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BT.TS360Constants;

namespace BTNextGen.CartFramework
{
    using Helpers;
    using Order;
    using Commerce.Portal.Common.Constants;
    using LineItem = Order.LineItem;
    using Commerce.Portal.Common.Contracts;
    using BTNextGen.Commerce.Portal.Common.Search;
    using BT.TS360API.ServiceContracts.Request;
    using BT.TS360API.ServiceContracts.ILS;

    public class Cart : BaseCart
    {
        public string WorkflowTimeZone { get; set; }
        public bool EntertainmentHasGridLine { get; set; }

        #region Constructor
        /// <summary>
        /// Cart
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="userId"></param>
        internal Cart(string cartId, string userId)
        {
            this.CartId = cartId;
            this.UserId = userId;

            CartAccounts = new List<CartAccount>();
        }

        public Cart(string cartId, string userId, string orgId)
            : this(cartId, userId)
        {
            this.OrgId = orgId;
        }
        #endregion

        #region Public Properties

        /// <summary>
        /// Cart Id
        /// </summary>
        public string CartId { get; set; }
        public int NonRankedCount { get; set; }
        public string CartName { get; set; }

        public string BTStatus { get; set; }
        public Int64? ILSStatusId { get; set; }
        public string CartFolderID { get; set; }

        public string CartFolderName { get; set; }

        public int UserFolderTypeID { get; set; }

        public string OrgId { get; set; }

        public bool IsArchived { get; set; }

        public int LineItemCount { get; set; }

        public int TotalQuantity { get; set; }

        public int TotalOrderQuantity { get; set; }

        public int TotalCancelQuantity { get; set; }

        public int TotalBackOrderQuantity { get; set; }

        public int TotalInProcessQuantity { get; set; }

        public Decimal CartTotalListPrice { get; set; }

        public Decimal CartTotalNetPrice { get; set; }

        public Decimal ShippingTotal { get; set; }

        public Decimal FeeTotal { get; set; }

        public Decimal Total { get; set; }

        public string CreatedBy { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? CreatedDateTime { get; set; }

        public DateTime? UpdatedDateTime { get; set; }

        public string Note { get; set; }

        public string SpecialInstruction { get; set; }

        public List<CartAccount> CartAccounts { get; set; }

        public DateTime? NoteUpdatedDateTime { get; set; }

        public string NoteUpdatedBy { get; set; }

        public DateTime? SpecialInstructionsUpdatedDateTime { get; set; }

        public string SpecialInstructionsUpdatedBy { get; set; }

        public int TotalOELines { get; set; }

        public int TotalOEQuantity { get; set; }

        public int TitlesWithoutGrids { get; set; }

       

        public bool IsShared
        {
            get;
            set;
        }

        public bool IsReceived
        {
            get;
            set;
        }

        public bool HasProfile
        {
            get;
            set;
        }

        public bool HasGridLine { get; set; }

        public bool IsPremium
        {
            get;
            set;
        }

        /// <summary>
        /// Order form used for submitting order
        /// </summary>
        public OrderForm OrderForm { get; set; }

        public string CartOwnerId { get; set; }

        //user shared id, maybe cartownerid or pointer user id
        public string CartUserSharedId { get; set; }

        public string CartOwnerName { get; set; }

        public string OrderedDownloadedUser { get; set; }

        public bool OneClickMARCIndicator { get; set; }

        public string FTPErrorMessage { get; set; }

        public int ESPStateTypeId { get; set; }

        public int ESPFundStateTypeID { get; set; }

        public int ESPDistStateTypeID { get; set; }

        public int ESPRankStateTypeId { get; set; }

        public string LastESPStateTypeLiteral { get; set; }

        public string ESPStateTypeLiteral { get; set; }

        public string ESPJobURL { get; set; }

        public string ESPJobText { get; set; }

        public DateTime? SubmittedDate { get; set; }

        public bool HasESPRanking { get; set; }

        public int QuoteID { get; set; }

        public DateTime? QuoteExpiredDateTime { get; set; }

        public int BasketProcessingCategoryID { get; set; }

        public int FreezeLevel { get; set; }

        public bool IsActive { get; set; } // if TRUE, cart will be displayed in the Add/Copy/Move drop down (TFS 19189)

        #endregion

        #region Functional Static Methods
        internal static Cart CreateCart(string name, bool isPrimary, string folderId, List<CartAccount> cartAccounts, string userId, string gridTemplateId, int gridOptionId, List<CommonGridTemplateLine> gridLines)
        {
            var cart = CartDAOManager.CreateCart(name, isPrimary, folderId, cartAccounts, userId, gridTemplateId, gridOptionId, gridLines);

            //Notify carts changed
            cart.NotifyCartsChanged();

            ////Adding to cache
            //if (isPrimary)
            //{
            //    CartCacheManager.AddPrimaryCartToCache(cart, userId);
            //}

            return cart;
        }

        internal static Cart GetBlankCart(string cartId, string userId)
        {
            return new Cart(cartId, userId);
        }
        #endregion

        #region Functional Methods
        /// <summary>
        /// Set the cart as primary cart
        /// </summary>
        /// <returns>Primary cart with full properties.</returns>
        internal Cart SetAsPrimary()
        {
            var cart = CartDAOManager.SetCartAsPrimary(this.CartId, this.UserId);

            //Notify carts changed
            cart.NotifyCartsChanged();

            ////Adding to cache
            //CartCacheManager.AddPrimaryCartToCache(cart, cart.UserId);

            return cart;
        }

        internal void Delete()
        {
            var cartIDList = new List<string>() { this.CartId };
            CartDAOManager.DeleteCarts(cartIDList, this.UserId);

            this.NotifyCartsChanged();
            this.NotifyCartChanged(CartId);
        }

        //internal void Archive()
        //{
        //    var cartIDList = new List<string>() { this.CartId };
        //    CartDAOManager.ArchiveCarts(cartIDList, this.UserId);

        //    this.NotifyCartsChanged();
        //}

        internal void Restore(string toFolder)
        {
            var cartIDList = new List<string>() { this.CartId };
            CartDAOManager.RestoreCarts(cartIDList, toFolder, this.UserId);

            this.NotifyCartsChanged();
        }

        internal void MoveToFolder(string folderId)
        {
            var cartIDList = new List<string>() { this.CartId };
            CartDAOManager.MoveCartsToFolder(cartIDList, folderId, this.UserId);

            this.NotifyCartsChanged();
        }

        public List<LineItem> DowndloadExport(bool isChangeStatus, string orderedDownloadedUserId, int sortBy = 1, string sortDirection = "ASC")
        {
            var lineItems = CartDAOManager.DownloadExport(this.CartId, this.UserId, isChangeStatus, orderedDownloadedUserId, sortBy, sortDirection);
            
            this.NotifyCartChanged(this.CartId);

            return lineItems;
        }        

        public List<LineItem> GetLineItemsForPrint(int sortBy, string sortDirection)
        {
            var lineItems = CartDAOManager.GetLineItemForPrint(this.CartId, this.UserId, sortBy, sortDirection);
            return lineItems;
        }
        public List<LineItem> GetLineItemIDs()
        {
            var lineItems = CartDAOManager.GetLineItemIDs(this.CartId);
            return lineItems;
        }

        internal void Rename(string newCartName)
        {
            CartDAOManager.RenameCart(this.CartId, this.UserId, newCartName);
            this.NotifyCartChanged(this.CartId);
            this.NotifyTopNewestCartsChanged();
        }

        public void UpdateCartNote(string note)
        {
            CartDAOManager.UpdateCartNote(this.CartId, this.UserId, note);
            this.NotifyCartChanged(this.CartId);
        }

        public void UpdateCartSpecialInstructions(string specialInstructions)
        {
            CartDAOManager.UpdateCartSpecialInstructions(this.CartId, this.UserId, specialInstructions);
            this.NotifyCartChanged(this.CartId);
        }

        public void SetOneClickMARCStatus(string oneClickMARCStatus)
        {
            CartDAOManager.SetOneClickMARCStatus(this.CartId, oneClickMARCStatus);
            this.NotifyCartChanged(this.CartId);
        }

        public void ReleaseCartQuote(string userID)
        {
            CartDAOManager.ReleaseCartQuote(this.CartId, userID);
            this.NotifyCartChanged(this.CartId);
        }

        public void RequestCartQuote()
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion
            CartDAOManager.RequestCartQuote(this.CartId, this.UserId);
            NotifyCartChanged(this.CartId);
        }
        #endregion

        #region Cart Line methods

        public void AddLineItems(List<LineItem> lineItems, out string PermissionViolationMessage, 
            out int totalAddingQtyForGridDistribution, bool needToReprice = true)
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            CartDAOManager.AddLineItemsToCart(lineItems, this.CartId, this.UserId, out PermissionViolationMessage, out totalAddingQtyForGridDistribution);

            NotifyCartLineChanged(this.CartId);

            if (needToReprice)
            {
                this.WcfServiceCalculatePrice(this.CartId);
            }
        }
        public void AddExceed500LineItems(List<LineItem> lineItems)
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            CartDAOManager.AddExceed500LineItemsToCart(lineItems, this.CartId, this.UserId);

            NotifyCartLineChanged(this.CartId);
        }
        public void NotifyCartChangeIfPrimary()
        {
            if (IsPrimaryCart)
            {
                NotifyCartLineChanged(this.CartId);
            }
        }

        public void NotifyCartChangedWhenTranfer()
        {
            this.NotifyCartChanged(this.CartId);
        }

        public void CopyLineItems(List<LineItem> lineItems, string destinationId, string sourceCartId, string whatToCopy, out string PermissionViolationMessage, string userId = "")
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            if (string.IsNullOrEmpty(destinationId)) throw new CartManagerException(CartManagerException.DESTINATION_CART_ID_NULL);
            #endregion

            var contextUserId = string.IsNullOrEmpty(userId) ? this.UserId : userId;
            CartDAOManager.CopyLineItems(lineItems, destinationId, contextUserId, sourceCartId, CartFrameworkHelper.MaxLinesPerCart, whatToCopy, out PermissionViolationMessage);

            NotifyCartLineChanged(destinationId);

            this.WcfServiceCalculatePrice(destinationId);
        }

        public void CopyCancelledLineItems(string destinationId)
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            #endregion

            CartDAOManager.CopyCancelledLineItems(this.CartId, destinationId);

            NotifyCartLineChanged(destinationId);

            this.WcfServiceCalculatePrice(destinationId);
        }
        
        //public void MoveTitle(LineItem lineItem, string destinationCartId, string userId = "")
        //{
        //    #region Validation
        //    if (string.IsNullOrEmpty(this.CartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
        //    if (string.IsNullOrEmpty(destinationCartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
        //    if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
        //    #endregion
        //    var contextUserId = this.UserId;
        //    if (userId != "" && this.UserId != userId)
        //    {
        //        contextUserId = userId;
        //    }
        //    CartDAOManager.MoveCartTitle(lineItem, this.CartId, destinationCartId, contextUserId);

        //    this.NotifyCartLineChanged(destinationCartId);

        //    this.NotifyCartLineChanged(this.CartId);

        //    this.WcfServiceCalculatePrice(this.CartId);

        //    this.WcfServiceCalculatePrice(destinationCartId);
        //}


        public void MoveLineItems(List<LineItem> lineItems, string destinationCartId, out string PermissionViolationMessage, string userId = "")
        {
            #region Validation
            if (lineItems == null || lineItems.Count == 0) throw new CartManagerException(CartManagerException.CART_LINE_ITEM_NULL);
            if (destinationCartId == null) throw new CartManagerException(CartManagerException.DESTINATION_CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var contextUserId = this.UserId;
            if(userId != "" && this.UserId != userId)
            {
                contextUserId = userId;
            }
            CartDAOManager.MoveLineItems(lineItems, this.CartId, destinationCartId, contextUserId, out PermissionViolationMessage);
            
            this.NotifyCartLineChanged(CartId);

            this.NotifyCartLineChanged(destinationCartId);

            this.WcfServiceCalculatePrice(this.CartId);

            this.WcfServiceCalculatePrice(destinationCartId);
        }

        public Dictionary<string, string> RemoveLineItems(List<string> lineItemId, bool isCallPricingService = true)
        {
            #region Validation

            if (lineItemId == null || lineItemId.Count == 0)
                throw new CartManagerException(CartManagerException.CART_LINE_ITEM_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);

            #endregion

            var errorTable = CartDAOManager.RemoveLineItems(lineItemId, this.UserId, this.CartId);

            this.NotifyCartLineChanged(CartId);
            if (isCallPricingService)
                this.WcfServiceCalculatePrice(this.CartId);

            return errorTable;
        }

        public void UpdateLineItemNote(string note, string lineItemId)
        {
            #region Validation
            if (String.IsNullOrEmpty(lineItemId)) throw new CartManagerException(CartManagerException.CART_LINE_ITEM_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            CartDAOManager.UpdateLineItemNote(note, lineItemId, this.UserId);
        }

        public void UpdateLineItemsQuantity(Dictionary<string, Dictionary<string, string>> lineItems, bool needToReprice = true, string contextUserId = "")
        {
            
            #region Validation
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            if (lineItems.Count == 0) return;
            #endregion

            if (!string.IsNullOrEmpty(contextUserId))
            {
                UserId = contextUserId;
            }

            CartDAOManager.UpdateLineItemsQuantity(lineItems, this.UserId);

            this.NotifyCartLineChanged(this.CartId);

            if (needToReprice)
            {
                this.WcfServiceCalculatePrice(this.CartId);
            }
        }

        public void UpdateLineItemsInfo(Dictionary<string, Dictionary<string, string>> lineItems, bool needToReprice = true)
        {

            #region Validation
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            if (lineItems.Count == 0) return;
            #endregion

            CartDAOManager.UpdateLineItemsInfo(lineItems, this.UserId);

            this.NotifyCartLineChanged(this.CartId);
            if (needToReprice)
            {
                this.WcfServiceCalculatePrice(this.CartId);
            }
        }

        public void UpdateLineItemsNotes(Dictionary<string, Dictionary<string, string>> lineItems, bool needToReprice = true)
        {

            #region Validation
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            if (lineItems.Count == 0) return;
            #endregion

            CartDAOManager.UpdateLineItemsNotes(lineItems, this.UserId, this.CartId);
        }

        public void UpdateItemOrderingInformation(string lineItemId, int quantity, string poNumber, string bibNumber, bool needToUpdatePONumber, bool needToUpdateBIBNumber, string note, string basketSummaryId, string contextUserId = "")
        {
            #region Validation

            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            if (lineItemId == null) throw new CartManagerException("lineItemId is null");
            if (poNumber == null) throw new CartManagerException("poNumber is null");
            if (bibNumber == null) throw new CartManagerException("bibNumber is null");
            if (basketSummaryId == null) throw new ArgumentNullException("basketSummaryId");

            #endregion

            var userIdToUpdate = !string.IsNullOrEmpty(contextUserId) ? contextUserId : this.UserId;
            CartDAOManager.UpdateItemOrderingInfo(userIdToUpdate, lineItemId, quantity, poNumber, bibNumber, needToUpdatePONumber, needToUpdateBIBNumber, note, basketSummaryId);

            this.NotifyCartLineChanged(this.CartId);
        }

        public void UpdateAccounts(List<CartAccount> cartAccounts, bool raiseNotify = true)
        {
            CartDAOManager.UpdateAccounts(cartAccounts, CartId, UserId);
            if (raiseNotify)
                this.NotifyCartChanged(this.CartId);

            //this.WcfServiceCalculatePrice(this.CartId);
        }

        public List<AccountSummary> GetAccountsSummary()
        {
            return CartDAOManager.GetAccountsSummary(CartId);
        }

        public LineItem GetCartLineById(string id, string contextUserId = "")
        {
            var userIdForLine = !string.IsNullOrEmpty(contextUserId) ? contextUserId : UserId;
            return CartDAOManager.GetCartLineByID(id, userIdForLine);
        }

        public LineItem GetCartLineByBtKey(string btKey, string contextUserId = "")
        {
            return CartDAOManager.GetCartLineByBtKey(btKey, this.CartId);
        }

        public List<LineItem> GetCartLineByIds(List<string> ids)
        {
            return CartDAOManager.GetCartLineByIDs(ids, UserId);
        }

        public CartLineFacet GetCartLineFacet(string facetPath, string keyword, string keywordSearchBy)
        {
            return CartDAOManager.GetCartLineFacet(facetPath, CartId, UserId, keyword, keywordSearchBy);
        }

        public List<SearchResultInventoryStatusArg> GetCartLinesInventoryArgs(string facetPath, string keyword,
            int pageNumber, int pageSize, int sortBy,
            out int totalLines, string keywordType,
            int sortDirection = 0, bool isSharedCart = false)
        {
            var userId = UserId;
            if(isSharedCart)
            {
                userId = this.CartOwnerId;
            }

            return CartDAOManager.GetInventoryArgs(facetPath, keyword, pageNumber, pageSize, sortBy, CartId, userId,
                                               out totalLines, keywordType, sortDirection);
        }

        public List<LineItem> GetCartLines(string facetPath, string keyword, int pageNumber, int pageSize, int sortBy,
            out int totalLines, GridFieldType gridFieldType, string gridCodeId, string gridText, string keywordType, int sortDirection = 0,
            bool isFindAndReplace = false, bool isFreeText = false, bool isSharedCart = false, string[] matchingBTKeys = null, int? quantity = null)
        {
            var userId = UserId;
            if (isSharedCart)
            {
                // TFS #6670 -BTAdmin cannot view a shared cart of another user.
                userId = this.CartOwnerId;
            }

            return CartDAOManager.GetCartLines(facetPath, keyword, pageNumber, pageSize, sortBy, CartId, userId,
                                               out totalLines, gridFieldType, gridCodeId, gridText, keywordType,
                                               sortDirection, isFindAndReplace, isFreeText, matchingBTKeys, quantity);
        }

        public List<LineItem> GetCartLines(string facetPath)
        {
            return GetAllCartLines(facetPath);
        }

        public List<LineItem> GetAllCartLines(string facetPath = null)
        {
            int remainingLines = 0;
            var retLines = new List<LineItem>();
            byte pageIndex = 1;
            do
            {
                int totalLine;
                var lines = GetCartLines(facetPath, string.Empty, pageIndex, CartFrameworkConstants.LARGE_PAGE_SIZE, 0,
                                         out totalLine, GridFieldType.Unknown, string.Empty, string.Empty, string.Empty);
                if (lines != null && lines.Count > 0)
                {
                    retLines.AddRange(lines);
                    remainingLines = totalLine - retLines.Count;
                    pageIndex++;
                }
            } while (remainingLines > 0);

            return retLines;
        }

        public void ReflagPricingBasketLineItems()
        {
            if (this.CartId == null)
                throw new CartManagerException(CartManagerException.CART_ID_NULL);

            CartDAOManager.ReflagPricingBasketLineItems(this.CartId);
        }

        public bool IsPricing(bool needToReprice = false)
        {
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(this.UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            var isPricing = false;
            var cacheKey = string.Format(Commerce.Portal.Common.Constants.CacheKeyConstant.UserCartIsPricingKey, this.CartId, this.UserId);
            var flagFromCache = VelocityCaching.VelocityCacheManager.Read(cacheKey);
            if (flagFromCache != null)
            {
                isPricing = (bool)flagFromCache;
            }
            else
            {
                isPricing = CartDAOManager.IsCartPricing(this.CartId, this.UserId);
            }
            VelocityCaching.VelocityCacheManager.Write(cacheKey, isPricing, CartCacheConstants.CommonCartCacheLevel);
            //fix 2442: if the cart is being processed, trigger pricing right away
            if (isPricing)
            {
                if (needToReprice)
                {
                    this.WcfServiceCalculatePrice(this.CartId);
                    this.NotifyCartLineChanged(this.CartId);
                }          
                return true;
            }

            return false;
        }

        public bool IsHomeDeliveryCart()
        {
            var cartAccounts = this.CartAccounts;
            if (this.IsPrimary)
            {
                var cartCache = CartCacheManager.GetCartFromCache(this.CartId);
                if (cartCache != null)
                {
                    var primaryCart = cartCache;
                    cartAccounts = primaryCart.CartAccounts;
                }
            }
            if (cartAccounts == null || cartAccounts.Count < 1)
            {
                return false;
            }

            return cartAccounts.Any(cartAccount => cartAccount.IsHomeDelivery);
        }

        public bool HasBookAccount()
        {
            Cart cart = this;
            if (this.IsPrimary)
            {
                var cartCache = CartCacheManager.GetCartFromCache(this.CartId);
                if (cartCache != null)
                    cart = cartCache;
            }

            if (cart.CartAccounts != null && cart.CartAccounts.Count > 0)
            {
                return cart.CartAccounts.Any(cartAccount => (cartAccount.AccountType == (int)AccountType.Book
                                                            || cartAccount.AccountType == (int)AccountType.BTDML
                                                            || cartAccount.AccountType == (int)AccountType.EBRRY
                                                            || cartAccount.AccountType == (int)AccountType.NETLB
                                                            || cartAccount.AccountType == (int)AccountType.GALEE
                                                            ) && !string.IsNullOrEmpty(cartAccount.AccountID));
            }
            return false;
        }
        public bool HasZeroQuantityItem()
        {
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            return CartDAOManager.IsZeroQuantityExisted(this.CartId, this.UserId);
        }
        #endregion

        #region Submit Order
        public void SubmitOrder(string loggedInUserId, out string newBasketName, out string newBasketId, out string newOEBasketName, out string newOEBasketID, bool isVIP, bool isOrderAndHold, string orderedDownloadedUserId)
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion
            CartDAOManager.SubmitCart(this, this.UserId, loggedInUserId, out newBasketName, out newBasketId, out newOEBasketName, out newOEBasketID, isVIP, isOrderAndHold, orderedDownloadedUserId);
            NotifyCartChanged(this.CartId);
        }

        public Cart GetStoreAndCustomerView()
        {
            #region Validation
            if (this.CartId == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            #endregion
            this.OrderForm = CartDAOManager.GetStoreAndCustomerView(this.CartId);

            return this;
        }

        #endregion

        #region Implementation BaseCart

        public new bool IsPrimaryCart
        {
            get
            {
                return base.IsPrimaryCart(this.CartId, this.UserId);    
            }            
        }

        public bool IsPrimaryCartOfUser(string userId)
        {
            return base.IsPrimaryCart(this.CartId, userId);
        }

        public bool HasPermission { get; set; }

        public bool IsBtCart { get; set; }

        public bool IsPrimary { get; set; }

        public bool HasOwner { get; set; }

        public bool HasContribution { get; set; }

        public bool HasReview { get; set; }

        public bool HasAcquisition { get; set; }

        /// <summary>
        /// 1: Contribution
        /// 2: Requisition
        /// 3: Review
        /// 4: Acquisition
        /// 0: if the basket doesn’t has workflow
        /// </summary>
        public int CurrentWorkflow { get; set; }

        public bool CanDelete { get; set; }

        public bool CanDesignateAsPrimaryCart { get; set; }

        public bool HasWorkflow { get; set; }

        public bool HasReviewAcquisitionPermission { get; set; }

        public bool IsHomeDelivery { get; set; }

        public bool ContainsAMixOfGridNNonGrid { get; set; }

        public bool IsMixedProduct { get; set; }

        public bool IsSplitting { get; set; }

        public bool IsSharedBasketGridEnabled { get; set; }

        public bool IsTransferred { get; set; }
        public int GridDistributionOption { get; set; }

        #endregion

        #region Logging
        internal string GetCartLogString()
        {
            var sb = new StringBuilder();

            sb.Append("CartID:" + CartId + "\"");
            sb.Append("UserId:" + UserId + "\"");
            sb.Append("CartName:" + CartName + "\"");
            sb.Append("BTStatus:" + BTStatus + "\"");
            sb.Append("CartFolderID:" + CartFolderID + "\"");
            sb.Append("CartFolderName:" + CartFolderName + "\"");
            sb.Append("IsArchived:" + IsArchived + "\"");
            sb.Append("LineItemCount:" + LineItemCount + "\"");
            sb.Append("TotalQuantity:" + TotalQuantity + "\"");
            sb.Append("CartTotalListPrice:" + CartTotalListPrice + "\"");
            sb.Append("CartTotalNetPrice:" + CartTotalNetPrice + "\"");
            sb.Append("CreatedBy:" + CreatedBy + "\"");
            sb.Append("UpdatedBy:" + UpdatedBy + "\"");
            sb.Append("CreatedDateTime:" + CreatedDateTime + "\"");
            sb.Append("Note:" + Note + "\"");
            sb.Append("SpecialInstruction:" + SpecialInstruction + "\"");

            return sb.ToString();
        }
        #endregion

        public bool SaveOriginalEntry(OriginalEntry originalEntry, string pOLine, string bib, string userId, string notes, out int addedQuantity)
        {
            return CartDAOManager.SaveOriginalEntry(CartId, originalEntry, pOLine, bib, userId, notes, out addedQuantity);
        }

        public bool SaveOriginalEntryWithGrid(OriginalEntry originalEntry, List<CommonCartGridLine> cartGridLines, string pOLine, string bib, string note, string userId, out int addedQuantity)
        {
            return CartDAOManager.SaveOriginalEntryWithGrid(CartId, originalEntry, cartGridLines, pOLine, bib, note, userId, out addedQuantity);
        }

        public ILSAPIRequestResponse GetILSLog(string cartId)
        {
            return CartDAOManager.GetILSLog(cartId);
        }

        public ILSOrderValidationResponseStatus GetILSOrderingResponseStatus(string cartId)
        {
            return CartDAOManager.GetILSOrderingResponseStatusFromAPILog(cartId);
        }

        public ILSValidationRequestResponse GetILSValidationRequestResponse(string cartId)
        {
            return CartDAOManager.GetILSValidationRequestResponseFromAPILog(cartId);
        }

        public List<LineItem> GetTitles(string cartId)
        {
            return CartDAOManager.GetTitles(cartId, this.UserId);
        }
    }
}
