﻿using System;

namespace BTNextGen.CartFramework
{
    public enum CartFolderPositionType
    {
        MinSequence = 0,
        MaxSequence = 1
    }

  }
