﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Helpers;

namespace BTNextGen.CartFramework.Order
{

    public class ESPQueue
    {
        public ESPQueue()
        {
        }

        public string CartName { get; set; }
        public string ESPJobType { get; set; }
        public string BasketSummaryID { get; set; }
        public string ESPJobId { get; set; }
        public string OrganizationName { get; set; }
        public string ESPLibraryID { get; set; }
        public string UserName { get; set; }
        public DateTime SubmittedDate { get; set; }
        public string CartStatus { get; set; }
        public bool IsResetVisible { get; set; }
        public string UserId { get; set; }
    }
}
