﻿namespace BTNextGen.CartFramework.Order
{
    using System;
    public class DuplicateOrderReference
    {
        public DateTime? SubmittedDate { get; set; }
        public string PurchaseOrderId { get; set; }
        public string BTOrderId { get; set; }
        public int TotalOrderedQuantity { get; set; }
        public int TotalShippedQuantity { get; set; }
        public int TotalCancelledQuantity { get; set; }
        public int TotalBackOrderedQuantity { get; set; }
        public int TotalInProcessQuanity { get; set; }
        public int TotalOnSaleDateHoldQuantity { get; set; }
        public int TotalReservedAwaitingReleaseQuantity { get; set; }
    }

}
