﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common.com.btol.contentcafe2;

namespace BTNextGen.CartFramework.Order
{
    public class LineItemsAddtoCart
    {
       public string BTKey { get; set; }
       public int? Quantity { get; set; }
       public string ISBN { get; set; }
       public string PONumber { get; set; } 
       public string Id { get; set; } 
       public string Bib { get; set; }
       public string Title { get; set; }
       public string Author { get; set; }
    }
}
