﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.CartFramework.Order
{
    public class ShippingMethod
    {
        public string ShippingMethodExtID { get; set; }
        public decimal ShippingTotal { get; set; }
        public string BTShippingMethodGuid { get; set; }
        public string BTCarrierCode { get; set; }
    }
}
