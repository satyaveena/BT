﻿//-----------------------------------------------------------------------
// <copyright file="Fee.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>Defines the Fee class.</summary>
//-----------------------------------------------------------------------

namespace BTNextGen.CartFramework.Order
{
    /// <summary>
    /// Represents a user in the system.
    /// </summary>
    public class Fee
    {
        public bool HasStoreShippingFee { get; set; }
        public bool HasStoreGiftWrapFee { get; set; }
        public bool HasStoreProccessingFee { get; set; }
        public bool HasStoreOrderFee { get; set; }
    }
}
