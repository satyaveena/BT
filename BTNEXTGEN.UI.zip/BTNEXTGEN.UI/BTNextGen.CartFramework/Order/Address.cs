﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.CartFramework.Order
{
    public class Address
    {
        /// <summary>
        /// Address ID
        /// </summary>
        public string AddressID { get; set; }

        /// <summary>
        /// Address Line #1
        /// </summary>
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Address Line #2
        /// </summary>
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Address Line #3
        /// </summary>
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Address Line #4
        /// </summary>
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Flag PO Box
        /// </summary>
        public bool IsPoBox { get; set; }

        /// <summary>
        /// City
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Region Code
        /// </summary>
        public string RegionCode { get; set; }

        /// <summary>
        /// Postal Code
        /// </summary>
        public string PostalCode { get; set; }

        /// <summary>
        /// Country Code
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// Telephone Number
        /// </summary>
        public string TelNumber { get; set; }

        /// <summary>
        /// Email Address
        /// </summary>
        public string EmailAddress { get; set; }
    }
}
