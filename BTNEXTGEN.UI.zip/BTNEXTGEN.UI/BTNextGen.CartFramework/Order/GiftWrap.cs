﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.CartFramework.Order
{
    public class GiftWrap
    {
        public string BTGiftWrapCode { get; set; }

        public string BTGiftWrapString { get; set; }
    }
}
