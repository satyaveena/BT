﻿
namespace BTNextGen.CartFramework.Order
{
    public class OrderedLineItems
    {
        public string BasketId { get; set; }
        public string ProductType { get; set; }
        public string BTKey { get; set; }
        public string LineItemId { get; set; }
        public string OrderNumber { get; set; }
        public int ShippedQuantity { get; set; }
        public int CancelledQuantity { get; set; }
        public int InProcessQuantity { get; set; }
        public int BackOrderedQuantity { get; set; }
        public int ReversedAwaitingReleaseQuantity { get; set; }
        public int TotalOrderedQuantity { get; set; }
        public int OnSaleDateHoldQuantity { get; set; }
        public string WareHouse { get; set; }
        public string PONumber { get; set; }
        public string BTOrderDate { get; set; }
    }
}
