﻿namespace BTNextGen.CartFramework.Order
{
    using System;
    public class DuplicateCartReference
    {
        public string CartId { get; set; }
        public string LineItemKeys { get; set; }
        public string CartName { get; set; }
        public int Quantity { get; set; }
        public string SoldToId { get; set; }
        public string SoldToName { get; set; }
        public string BookAccountId { get; set; }
        public string EntertainmentAccountId { get; set; }
        public string ERPAccountNumber { get; set; }
        public string CartStatus { get; set; }
        public string CartStatusName { get; set; }
        public DateTime? LastUpdated { get; set; }
    }

}
