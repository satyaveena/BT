﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using BT.TS360Constants;

namespace BTNextGen.CartFramework
{
    public class CartFolders: BaseCartFolder, ICollection<CartFolder>
    {
        
        #region Constructor

        /// <summary>
        /// Cart Folders
        /// </summary>
        public CartFolders()
        {
            _items = new List<CartFolder>();
        }

        #endregion
     
        #region Internal Methods

        /// <summary>
        /// Creates default system folders for new user.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static Dictionary<string, CartFolderType> CreateSystemCartFolders(string userId)
        {
            return CartDAOManager.CreateSystemCartFolders(userId);
        }

        /// <summary>
        /// Get Cart Folders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal CartFolders GetCartFolders(string userId)
        {
            CartFolders cartFoldersCache = CartCacheManager.GetCartFoldersFromCache(userId);
            if (cartFoldersCache != null)
                return cartFoldersCache;

            CartFolders cartFolders = CartDAOManager.GetCartFolders(userId);

            if (cartFolders != null)
                CartCacheManager.AddCartFoldersToCache(cartFolders, userId);

            return cartFolders;

        }

        internal float GetUserFolderSequence(string parentFolderId, string userId, int positionType)
        {
            return CartDAOManager.GetUserFolderSequence(parentFolderId, userId, positionType);
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Get Cart Folder By Id
        /// </summary>
        /// <param name="folderId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public CartFolder GetCartFolderById(string folderId, string userId)
        {
            // We already checked Cache in the this.GetCartFolders(userId) ==> don't need to check one more time here
            //CartFolders cartFoldersCache = CartCacheManager.GetCartFoldersFromCache(userId);
            //if (cartFoldersCache != null)
            //{
            //    //Get Cart
            //    return cartFoldersCache.FirstOrDefault(cartFolder => cartFolder.CartFolderId == folderId);
            //}

            CartFolders cartFolders = this.GetCartFolders(userId);

            if (cartFolders != null)
            {
                //Get Cart
                return cartFolders.FirstOrDefault(cartFolder => cartFolder.CartFolderId.Equals(folderId, StringComparison.CurrentCultureIgnoreCase));
            }

            return null;
        }

        /// <summary>
        /// GetEnumerator
        /// </summary>
        /// <returns></returns>
        public IEnumerator<CartFolder> GetEnumerator()
        {
            return _items.GetEnumerator();
        }

        /// <summary>
        /// GetEnumerator
        /// </summary>
        /// <returns></returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return _items.GetEnumerator();
        }

        /// <summary>
        /// Add
        /// </summary>
        /// <param name="item"></param>
        public void Add(CartFolder item)
        {
            _items.Add(item);
        }

        /// <summary>
        /// Clear
        /// </summary>
        public void Clear()
        {
            _items.Clear();
        }

        /// <summary>
        /// Contains
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Contains(CartFolder item)
        {
            return _items.Contains(item);
        }

        /// <summary>
        /// Copy To
        /// </summary>
        /// <param name="array"></param>
        /// <param name="arrayIndex"></param>
        public void CopyTo(CartFolder[] array, int arrayIndex)
        {
            _items.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// Remove
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Remove(CartFolder item)
        {
            return _items.Remove(item);
        }

        /// <summary>
        /// Count
        /// </summary>
        public int Count
        {
            get { return _items.Count; }
        }

        /// <summary>
        /// A collection that is read-only does not allow the addition, removal, or modification of elements after the collection is created.
        /// </summary>
        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool DragAndDropCartFolder(string sourceFolderId, string destinationFolderId, string position)
        {
            return CartDAOManager.DragAndDropCartFolder(sourceFolderId, destinationFolderId, position);
        }

        public static void ClearCartFoldersCache(string userId)
        {
            CartCacheManager.SetCartFoldersCacheExpired(userId);
        }

        #endregion

        #region Private/Protected Properties

        /// <summary>
        /// Items for Collection
        /// </summary>
        protected readonly List<CartFolder> _items;

        #endregion

        internal override void NotifyCartFolderChanged()
        {
            throw new NotImplementedException();
        }

        internal override void NotifyCartsChanged()
        {
            throw new NotImplementedException();
        }

        internal override void NotifyPrimaryCartChanged()
        {
            throw new NotImplementedException();
        }

        internal override void NotifyTopNewestCartsChanged()
        {
            throw new NotImplementedException();
        }
    }
}
