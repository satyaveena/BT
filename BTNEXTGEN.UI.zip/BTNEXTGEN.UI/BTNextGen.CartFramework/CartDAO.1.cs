﻿using System;
using System.Collections.Generic;
using System.Linq;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Contracts;
using BTNextGen.Commerce.Portal.Common.DataItems;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Grid.Helpers;
using Microsoft.SqlServer.Server;
using DataConverter = BTNextGen.CartFramework.Helpers.DataConverter;
using OrderStatus = BT.TS360Constants.OrderStatus;
using SearchResultsSortField = BT.TS360Constants.SearchResultsSortField;

namespace BTNextGen.CartFramework
{
    using System.Data;
    using System.Data.SqlClient;
    using BT.TS360Constants;

    public partial class CartDAO
    {
        #region Cart Folder Methods

        /// <summary>
        /// Create Cart Folder
        /// </summary>
        /// <param name="name"></param>
        /// <param name="parentFolderId"></param>
        /// <param name="cartFolderType"></param>
        /// <param name="sequenceNo"></param>
        /// <param name="userId"></param>
        /// <param name="folderId"></param>
        /// <returns></returns>
        internal void CreateCartFolder(string name, string parentFolderId, int cartFolderType, float sequenceNo, string userId, out string folderId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_CREATE_USER_FOLDER, dbConnection);

            var folderNameParam = new SqlParameter(SpParameterName.Name, SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = name };
            command.Parameters.Add(folderNameParam);
            if (!string.IsNullOrEmpty(parentFolderId))
            {
                var parentFolderParam = new SqlParameter(SpParameterName.ParentFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = parentFolderId };
                command.Parameters.Add(parentFolderParam);
            }
            else
            {
                var parentFolderParam = new SqlParameter(SpParameterName.ParentFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = DBNull.Value };
                command.Parameters.Add(parentFolderParam);
            }

            var folderTypeParam = new SqlParameter("@FolderTypeID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartFolderType };
            var sequenceParam = new SqlParameter("@SequenceNo", SqlDbType.BigInt) { Direction = ParameterDirection.Input, Value = sequenceNo };
            var userParam = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            var userFolderIdParam = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
            command.Parameters.Add(folderTypeParam);
            command.Parameters.Add(sequenceParam);
            command.Parameters.Add(userParam);
            command.Parameters.Add(userFolderIdParam);
            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                folderId = command.Parameters[SpParameterName.UserFolderID].Value as string;

                this.HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Creates default system folders for new user.
        /// </summary>
        /// <param name="userId">A new user Id to create.</param>
        /// <returns></returns>
        internal DataSet CreateSystemCartFolders(string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_CREATE_USER_SYSTEM_FOLDERS, dbConnection);
            var sqlParamater = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParamater);
            dbConnection.Open();
            try
            {
                var ds = new DataSet();
                var sqlDa = new SqlDataAdapter(command);
                sqlDa.Fill(ds);

                HandleCartException(command);

                return ds;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Get Cart Folders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal DataSet GetCartFolders(string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_GET_FOLDER_BY_USER_ID, dbConnection);
            var sqlParamater = new SqlParameter("@Userid", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParamater);
            dbConnection.Open();
            try
            {
                var ds = new DataSet();
                var sqlDa = new SqlDataAdapter(command);
                sqlDa.Fill(ds);

                HandleCartException(command);

                return ds;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal DataSet GetCartFolder(string folderId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_GET_FOLDER_BYID, dbConnection);
            var sqlParamater = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = folderId };
            command.Parameters.Add(sqlParamater);
            dbConnection.Open();
            try
            {
                var ds = new DataSet();
                var sqlDa = new SqlDataAdapter(command);
                sqlDa.Fill(ds);

                HandleCartException(command);

                return ds;
            }
            finally
            {
                dbConnection.Close();
            }
            return null;
        }
        /// <summary>
        /// Delete Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal void DeleteCartFolder(string cartFolderId, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_DELETE_USER_FOLDER, dbConnection);
            var sqlParamater = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartFolderId };
            var sqlParamaterUserID = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParamater);
            command.Parameters.Add(sqlParamaterUserID);
            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Move Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="parentCartFolderId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal void MoveCartFolder(string cartFolderId, string parentCartFolderId, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_MOVE_USER_FOLDER, dbConnection);
            var sqlParamaterFolderID = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartFolderId };
            object parentCartFolderIdObject = DBNull.Value;
            if (!string.IsNullOrEmpty(parentCartFolderId))
                parentCartFolderIdObject = parentCartFolderId;
            var sqlParamaterParentFolderID = new SqlParameter(SpParameterName.ParentFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = parentCartFolderIdObject };
            var sqlParamaterUserID = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParamaterFolderID);
            command.Parameters.Add(sqlParamaterParentFolderID);
            command.Parameters.Add(sqlParamaterUserID);
            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        ///// <summary>
        ///// Archive Cart Folder
        ///// </summary>
        ///// <param name="cartFolderId"></param>
        ///// <param name="userId"></param>
        //internal void ArchiveCartFolder(string cartFolderId, string userId)
        //{
        //    var dbConnection = CreateSqlConnection();
        //    var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_ARCHIVE_USER_FOLDER, dbConnection);
        //    var sqlParamaterFolderID = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartFolderId };
        //    var sqlParamaterUserID = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };


        //    command.Parameters.Add(sqlParamaterFolderID);
        //    command.Parameters.Add(sqlParamaterUserID);
        //    dbConnection.Open();
        //    try
        //    {
        //        command.ExecuteNonQuery();
        //        HandleCartException(command);
        //    }
        //    finally
        //    {
        //        dbConnection.Close();
        //    }
        //}

        /// <summary>
        /// Rename
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="newCartFolderName"></param>
        /// <param name="userId"></param>
        internal void Rename(string cartFolderId, string newCartFolderName, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_RENAME_USER_FOLDER, dbConnection);
            var sqlParamaterFolderID = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartFolderId };
            var sqlParamaterFolderName = new SqlParameter(SpParameterName.Literal, SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = newCartFolderName };
            var sqlParamaterUserID = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParamaterFolderID);
            command.Parameters.Add(sqlParamaterFolderName);
            command.Parameters.Add(sqlParamaterUserID);
            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Update Sequence Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="sequenceNo"></param>
        /// <param name="userId"></param>
        internal void UpdateSequenceCartFolder(string cartFolderId, float sequenceNo, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_UPDATE_USER_FOLDER_SEQUENCE, dbConnection);
            var sqlParamaterFolderID = new SqlParameter(SpParameterName.UserFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartFolderId };
            var sqlParamaterSeqNo = new SqlParameter(SpParameterName.SequenceNo, SqlDbType.Float) { Direction = ParameterDirection.Input, Value = sequenceNo };
            var sqlParamaterUserID = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            command.Parameters.Add(sqlParamaterFolderID);
            command.Parameters.Add(sqlParamaterSeqNo);
            command.Parameters.Add(sqlParamaterUserID);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal object GetUserFolderSequence(string parentFolderId, string userId, int positionType)
        {
            object objParentFolderId = DBNull.Value;
            if (!string.IsNullOrEmpty(parentFolderId))
                objParentFolderId = parentFolderId;
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_GET_USER_FOLDER_SEQUENCE, dbConnection);
            var sqlParamaterParentFolderID = new SqlParameter(SpParameterName.ParentFolderID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = objParentFolderId };
            var sqlParamaterUserID = new SqlParameter(SpParameterName.UserID, SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            var sqlParamaterSeqNo = new SqlParameter(SpParameterName.PositionType, SqlDbType.Int) { Direction = ParameterDirection.Input, Value = positionType };
            command.Parameters.Add(sqlParamaterParentFolderID);
            command.Parameters.Add(sqlParamaterUserID);
            command.Parameters.Add(sqlParamaterSeqNo);
            dbConnection.Open();
            object result = null;
            try
            {
                result = command.ExecuteScalar();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
            return result;
        }
        #endregion

        #region Cart Line Methods

        private SqlParameter[] CreateLineItemParameters(string destCartId, string userId, List<SqlDataRecord> lineItems, char lineItemOrderStatus,
            bool isDelete, int maxLinesPerCart, string sourceCartId = null)
        {
            var sqlParameters = new SqlParameter[11];
            sqlParameters[0] = new SqlParameter("@SourceBasketSummaryID", sourceCartId);
            sqlParameters[1] = new SqlParameter("@DestinationBasketSummaryID", destCartId);
            sqlParameters[2] = new SqlParameter("@UserID", userId);
            sqlParameters[3] = new SqlParameter("@BasketLineItems", SqlDbType.Structured) { Value = lineItems };
            sqlParameters[4] = new SqlParameter("@BasketLineItemOrderStatus", lineItemOrderStatus);
            sqlParameters[5] = new SqlParameter("@DeleteSourceLineItems", isDelete);
            sqlParameters[6] = new SqlParameter("@MaxLinesPerCartNumber", SqlDbType.Int) { Value = maxLinesPerCart };
            sqlParameters[7] = new SqlParameter("@All_or_MyQty_or_TitleOnly", DBNull.Value);
            sqlParameters[8] = new SqlParameter("@OverRide_Warning", DBNull.Value);
            sqlParameters[9] = new SqlParameter("@PermissionViolationMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            sqlParameters[10] = new SqlParameter("@TotalAddingQuantity", SqlDbType.Int) { Direction = ParameterDirection.Output };
            return sqlParameters;
        }
        private SqlParameter[] CreateExceed500LineItemParameters(string cartId, string userId, List<SqlDataRecord> lineItems)
        {
            var sqlParameters = new SqlParameter[3];
            sqlParameters[0] = new SqlParameter("@UserID", userId);
            sqlParameters[1] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameters[2] = new SqlParameter("@BasketLineItems", SqlDbType.Structured) { Value = lineItems };
           // sqlParameters[3] = new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };
            return sqlParameters;
        }
        private const char DEFAULT_ORDER_STATUS = 'A';

        internal void AddLineItemsToCart(DataSet lineItems, string cartId, string userId, int maxLinesPerCart, out string PermissionViolationMessage,
            out int totalAddingQty)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_MERGE_LINE_ITEMS, dbConnection);

            var paramLineItems = DataAccessHelper.GenerateDataRecords(lineItems).Distinct(new SqlDataRecordComparerByBTKey()).ToList();
            
            var sqlParameters = CreateLineItemParameters(cartId, userId,
                                                         paramLineItems, DEFAULT_ORDER_STATUS, false, maxLinesPerCart);

            
            command.Parameters.AddRange(sqlParameters);
            command.CommandTimeout = 600;
            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
                PermissionViolationMessage = command.Parameters["@PermissionViolationMessage"].Value as string;
                if (!int.TryParse(command.Parameters["@TotalAddingQuantity"].Value.ToString(), out totalAddingQty))
                {
                    totalAddingQty = 0;
                }
            }
            finally
            {
                dbConnection.Close();
            }
        }
        internal void AddExceed500LineItemsToCart(DataSet lineItems, string cartId, string userId, int maxLinesPerCart)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_MERGE_EXCEED500_LINE_ITEMS, dbConnection);

            var paramLineItems = DataAccessHelper.GenerateDataRecords(lineItems).Distinct(new SqlDataRecordComparerByBTKey()).ToList();

            var sqlParameters = CreateExceed500LineItemParameters(cartId, userId, paramLineItems);

            command.Parameters.AddRange(sqlParameters);
            command.CommandTimeout = 600;
            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
                
            }
            finally
            {
                dbConnection.Close();
            }
        }
        internal void CopyLineItems(Dictionary<string, Dictionary<string, string>> lineItems, string destinationCartId, string userId,
            string sourceCartId, int maxLinesPerCart, string whatToCopy, out string PermissionViolationMessage)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360CopyLineItemsToNewCart, dbConnection);
            var sqlParameters = new SqlParameter[10];
            sqlParameters[0] = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Value = userId };
            sqlParameters[1] = new SqlParameter("@SourceBasketSummaryID", SqlDbType.NVarChar, 50) { Value = sourceCartId };
            sqlParameters[2] = new SqlParameter("@DestinationBasketSummaryID", SqlDbType.NVarChar, 50) { Value = destinationCartId };
            sqlParameters[3] = new SqlParameter("@BasketLineItems", SqlDbType.Structured)
            {
                Value = DataConverter.GetUtblProcTs360CopyLineItemsToNewCartDataRecords(lineItems).Distinct(new SqlDataRecordComparerByBTKey()).ToList()
            };
            sqlParameters[4] = new SqlParameter("@DeleteSourceLineItems", false);
            sqlParameters[5] = new SqlParameter("@BasketLineItemOrderStatus", SqlDbType.Char, 1) { Value = DEFAULT_ORDER_STATUS };
            sqlParameters[6] = new SqlParameter("@MaxLinesPerCartNumber", SqlDbType.Int) { Value = maxLinesPerCart };
            sqlParameters[7] = new SqlParameter("@All_or_MyQty_or_TitleOnly", SqlDbType.NVarChar, 5) { Value = whatToCopy };
            sqlParameters[8] = new SqlParameter("@OverRide_Warning", DBNull.Value);
            sqlParameters[9] = new SqlParameter("@PermissionViolationMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };

            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
                PermissionViolationMessage = command.Parameters["@PermissionViolationMessage"].Value as string;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal void CopyCancelledLineItems(string sourceCartId, string destinationCartId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_COPY_CANCELLED_LINE_ITEMS, dbConnection);
            var sqlParameters = new SqlParameter[2];
            sqlParameters[0] = new SqlParameter("@DestinationBasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = destinationCartId };
            sqlParameters[1] = new SqlParameter("@SourceBasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = sourceCartId };
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal void CopyTitle(Dictionary<string, Dictionary<string, string>> lineItem, string destinationCartId, string userId, int maxLinesPerCart)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_MERGE_LINE_ITEMS, dbConnection);
            //var lineItemIds = new List<string>() { lineItemId };

            var paramLineItems = DataConverter.GetUtblprocTS360MergeBasketLineItemsDataRecords(lineItem).Distinct(new SqlDataRecordComparerByBTKey()).ToList();

            var sqlParameters = CreateLineItemParameters(destinationCartId, userId,
                                                         paramLineItems,
                                                         DEFAULT_ORDER_STATUS, false, maxLinesPerCart);
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal void MoveTitle(Dictionary<string, Dictionary<string, string>> lineItem, string sourceCartId, string destinationCartId, string userId, int maxLinesPerCart)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_MERGE_LINE_ITEMS, dbConnection);

            var paramLineItems = DataConverter.GetUtblprocTS360MergeBasketLineItemsDataRecords(lineItem).Distinct(new SqlDataRecordComparerByBTKey()).ToList();

            var sqlParameters = CreateLineItemParameters(destinationCartId, userId,
                                                         paramLineItems,
                                                         DEFAULT_ORDER_STATUS, true, maxLinesPerCart, sourceCartId);
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal void MoveLineItems(Dictionary<string, Dictionary<string, string>> lineItems, string sourceCartId, string destinationCartId, string userId,
            int maxLinesPerCart, out string PermissionViolationMessage)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360MoveLineItemsToNewCart, dbConnection);
            var sqlParameters = new SqlParameter[10];
            sqlParameters[0] = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Value = userId };
            sqlParameters[1] = new SqlParameter("@SourceBasketSummaryID", SqlDbType.NVarChar, 50) { Value = sourceCartId };
            sqlParameters[2] = new SqlParameter("@DestinationBasketSummaryID", SqlDbType.NVarChar, 50) { Value = destinationCartId };
            sqlParameters[3] = new SqlParameter("@BasketLineItems", SqlDbType.Structured)
            {
                Value = DataConverter.GetUtblProcTs360CopyLineItemsToNewCartDataRecords(lineItems).Distinct(new SqlDataRecordComparerByBTKey()).ToList()
            };
            sqlParameters[4] = new SqlParameter("@DeleteSourceLineItems", true);
            sqlParameters[5] = new SqlParameter("@BasketLineItemOrderStatus", SqlDbType.Char, 1) { Value = DEFAULT_ORDER_STATUS };
            sqlParameters[6] = new SqlParameter("@MaxLinesPerCartNumber", SqlDbType.Int) { Value = maxLinesPerCart };
            sqlParameters[7] = new SqlParameter("@All_or_MyQty_or_TitleOnly", DBNull.Value);
            sqlParameters[8] = new SqlParameter("@OverRide_Warning", DBNull.Value);
            sqlParameters[9] = new SqlParameter("@PermissionViolationMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output };

            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
                PermissionViolationMessage = command.Parameters["@PermissionViolationMessage"].Value as string;
            }
            finally
            {
                dbConnection.Close();
            }
        }
        /// <summary>
        /// Remove cart lines
        /// </summary>
        /// <param name="lineItemIds"></param>
        /// <param name="userId"></param>
        internal DataSet RemoveLineItems(List<string> lineItemIds, string userId, string cartId)
        {
            var ds = new DataSet();
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_REMOVE_LINES, dbConnection);

            var lineItemIdsTable = DataAccessHelper.GenerateDataRecords(lineItemIds, "GUID", 50);

            //<Parameter>
            var sqlParameters = new SqlParameter[3];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameters[1] = new SqlParameter("@BasketLineItemIds", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = lineItemIdsTable };
            sqlParameters[2] = new SqlParameter("@u_user_id", userId);

            command.Parameters.AddRange(sqlParameters);
            var da = new SqlDataAdapter(command);
            dbConnection.Open();

            try
            {
                da.Fill(ds);
                //command.ExecuteNonQuery();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }

            //Table with 2 columns : BasketLineItemId and ErrorCode
            return ds;
        }

        /// <summary>
        /// Add/update a cartnote on a given line in a cart.
        /// </summary>
        /// <param name="note"></param>
        /// <param name="lineItemId"></param>
        /// <param name="userId"></param>
        internal void UpdateLineItemNote(string note, string lineItemId, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_UPDATE_LINE_ITEM_NOTE, dbConnection);

            //<Parameter>
            var sqlParameters = new SqlParameter[3];
            sqlParameters[0] = new SqlParameter("@Note", note);
            sqlParameters[1] = new SqlParameter("@BasketLineItemID", lineItemId);
            sqlParameters[2] = new SqlParameter("@UserID", userId);
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Update the quantity ordered for one or more lines in a cart.
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="userId"></param>
        internal void UpdateLineItemsQuantity(Dictionary<string, Dictionary<string, string>> lineItems, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_UPDATE_LINE_QUANTITIES, dbConnection);

            var lineItemsTable = DataConverter.GetLineItemsTable(lineItems);

            //<Parameter>
            var sqlParameters = new SqlParameter[2];
            sqlParameters[0] = new SqlParameter("@BasketUserLineItems", SqlDbType.Structured)
                                   {
                                       Direction = ParameterDirection.Input,
                                       Value = lineItemsTable
                                   };
            if (lineItemsTable.Count == 0) sqlParameters[0].Value = null;
            sqlParameters[1] = new SqlParameter("@UserID", userId);
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Update the PO and BIB number for one or more lines in a cart.
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="userId"></param>
        internal void UpdateLineItemsInfo(Dictionary<string, Dictionary<string, string>> lineItems, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_UPDATE_LINE_INFO, dbConnection);

            var lineItemsTable = DataConverter.GetLineItemsTable(lineItems);

            //<Parameter>
            var sqlParameters = new SqlParameter[2];
            sqlParameters[0] = new SqlParameter("@BasketUserLineItems", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = lineItemsTable
            };
            if (lineItemsTable.Count == 0) sqlParameters[0].Value = null;
            sqlParameters[1] = new SqlParameter("@UserID", userId);
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Update the PO and BIB number for one or more lines in a cart.
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="userId"></param>
        /// <param name="cartId"></param>
        internal void UpdateLineItemsNotes(Dictionary<string, Dictionary<string, string>> lineItems, string userId, string cartId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_UPDATE_LINE_NOTES, dbConnection);

            var lineItemsTable = DataConverter.GetLineItemsNotesTable(lineItems);

            //<Parameter>
            var sqlParameters = new SqlParameter[3];
            sqlParameters[0] = new SqlParameter("@BasketUserLineItemNotes", SqlDbType.Structured)
            {
                Direction = ParameterDirection.Input,
                Value = lineItemsTable
            };
            if (lineItemsTable.Count == 0) sqlParameters[0].Value = null;
            sqlParameters[1] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameters[2] = new SqlParameter("@UserID", userId);

            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal void UpdateItemOrderingInfo(string userId, string lineItemId, int quantity, string poLineNumber, string bibNumber,
            bool needToUpdatePONumber, bool needToUpdateBIBNumber, string note, string basketSummaryId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_UPDATE_ITEM_ORDERING_INFO, dbConnection);

            //<Parameter>
            var sqlParameters = new SqlParameter[7];
            sqlParameters[0] = new SqlParameter("@BasketLineItemId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = lineItemId
            };
            sqlParameters[1] = new SqlParameter("@UserId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userId
            };

            if (!needToUpdatePONumber)
            {
                sqlParameters[2] = new SqlParameter("@POLineItemNumber", SqlDbType.NVarChar, 50)
                {
                    Direction = ParameterDirection.Input,
                    Value = DBNull.Value
                };
            }
            else
            {
                sqlParameters[2] = new SqlParameter("@POLineItemNumber", SqlDbType.NVarChar, 50)
                {
                    Direction = ParameterDirection.Input,
                    Value = poLineNumber
                };
            }

            if (!needToUpdateBIBNumber)
            {
                sqlParameters[3] = new SqlParameter("@BIBNumber", SqlDbType.NVarChar, 25)
                {
                    Direction = ParameterDirection.Input,
                    Value = DBNull.Value
                };
            }
            else
            {
                sqlParameters[3] = new SqlParameter("@BIBNumber", SqlDbType.NVarChar, 25)
                {
                    Direction = ParameterDirection.Input,
                    Value = bibNumber
                };
            }
            
            
            if (note == null)
            {
                sqlParameters[4] = new SqlParameter("@Note", SqlDbType.NVarChar, 255)
                {
                    Direction = ParameterDirection.Input,
                    Value = DBNull.Value
                };
            }
            else
            {
                sqlParameters[4] = new SqlParameter("@Note", SqlDbType.NVarChar, 255)
                {
                    Direction = ParameterDirection.Input,
                    Value = note
                };
            }
            sqlParameters[5] = new SqlParameter("@Quantity", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = quantity
            };
            sqlParameters[6] = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = basketSummaryId
            };           
            
            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal void ReflagPricingBasketLineItems(string cartId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(BT.TS360Constants.StoredProcedureName.PROC_PRICING_REFLAG_BASKET_LINEITEMS, dbConnection);
            //<Parameter>
            var sqlParameter = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            command.Parameters.Add(sqlParameter);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();

                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal bool IsCartPricing(string cartId, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_IS_PRICING, dbConnection);
            //<Parameter>
            var sqlParameters = new SqlParameter[2];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            sqlParameters[1] = new SqlParameter("@UserID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userId
            };

            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                var returnObj = command.ExecuteScalar();

                HandleCartException(command);
                bool isProcessing;

                bool.TryParse(returnObj.ToString(), out isProcessing);

                return isProcessing;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal bool IsZeroQuantityExisted(string cartId, string userId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_IS_ZERO_QUANTITY_ITEM, dbConnection);
            //<Parameter>            
            var sqlParameters = new SqlParameter[2];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            sqlParameters[1] = new SqlParameter("@UserID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = userId
            };

            command.Parameters.AddRange(sqlParameters);
            dbConnection.Open();
            try
            {
                var returnObj = command.ExecuteScalar();

                var isExisted = Parser.ToBool(returnObj);

                return isExisted;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal bool CheckBasketforCalMerch(string cartId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_CHECK_BASKET_FOR_CAL_MERCH, dbConnection);
            //<Parameter>
            var sqlParameters = new SqlParameter[2];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            sqlParameters[1] = new SqlParameter("@HasCalMerch", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Output
            };

            command.Parameters.AddRange(sqlParameters);

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);

                return DataAccessHelper.ConvertToBool(command.Parameters["@HasCalMerch"].Value);
            }
            finally
            {
                dbConnection.Close();
            }
        }
        #endregion

        #region Submit Order

        /// <summary>
        /// Submit cart
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="userId"></param>
        /// <param name="orderForm"></param>
        /// <param name="accountDict"></param>
        /// <param name="specialInstruction"></param>
        /// <param name="newBasketName"></param>
        /// <param name="newBasketId"></param>
        /// <param name="newOEBasketName"></param>
        /// <param name="newOEBasketID"></param>
        internal void SubmitCart(string cartId, string userId, string loggedInUserId, Dictionary<string, string> orderForm, List<CartAccountSummary> accountDict, string specialInstruction,
            out string newBasketName, out string newBasketId, out string newOEBasketName, out string newOEBasketID, bool isVIP, bool isOrderAndHold, string orderedDownloadedUserId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_SUBMIT_BASKET, dbConnection);
            var accSqlMetadata = DataConverter.GetUtblBasketOrderFormsDataRecords(accountDict);
            var paramBasketID = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
            var paramUserId = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            var paramLoggedInUserId = new SqlParameter("@LoginUserID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = loggedInUserId };
            var paramAccount = new SqlParameter("@BasketOrderForms", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = accSqlMetadata };
            var paramSpecialInstruction = new SqlParameter("@SpecialInstructions", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = specialInstruction };

            var paramIsHomeDelivery = new SqlParameter("@HomeDeliveryIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = Boolean.Parse(orderForm["IsHomeDelivery"])
            };
            var paramHandlingTotal = new SqlParameter("@HandlingTotal", SqlDbType.Money) { Direction = ParameterDirection.Input, Value = 0 };
            if (orderForm.ContainsKey("HandlingTotal"))
            {
                paramHandlingTotal.Value = Decimal.Parse(orderForm["HandlingTotal"]);
            }

            var paramShippingTotal = new SqlParameter("@ShippingTotal", SqlDbType.Money) { Direction = ParameterDirection.Input, Value = 0 };
            if (orderForm.ContainsKey("ShippingTotal"))
            {
                paramShippingTotal.Value = Decimal.Parse(orderForm["ShippingTotal"]);
            }

            var paramSubTotal = new SqlParameter("@SubTotal", SqlDbType.Money) { Direction = ParameterDirection.Input, Value = 0 };
            if (orderForm.ContainsKey("SubTotal"))
            {
                paramSubTotal.Value = Decimal.Parse(orderForm["SubTotal"]);
            }

            var paramTaxTotal = new SqlParameter("@TaxTotal", SqlDbType.Money) { Direction = ParameterDirection.Input, Value = 0 };
            if (orderForm.ContainsKey("TaxTotal"))
            {
                paramTaxTotal.Value = Decimal.Parse(orderForm["TaxTotal"]);
            }

            var paramTotal = new SqlParameter("@Total", SqlDbType.Money) { Direction = ParameterDirection.Input, Value = 0 };
            if (orderForm.ContainsKey("Total"))
            {
                paramTotal.Value = Decimal.Parse(orderForm["Total"]);
            }

            var paramName = new SqlParameter("@Name", SqlDbType.NVarChar, 64) { Direction = ParameterDirection.Input, Value = orderForm["Name"] };
            var paramAddLine1 = new SqlParameter("@Line1", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = orderForm["AddressLine1"] };
            var paramAddLine2 = new SqlParameter("@Line2", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = orderForm["AddressLine2"] };
            var paramAddLine3 = new SqlParameter("@Line3", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = orderForm["AddressLine3"] };
            var paramAddLine4 = new SqlParameter("@Line4", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = orderForm["AddressLine4"] };
            var paramCity = new SqlParameter("@City", SqlDbType.NVarChar, 64) { Direction = ParameterDirection.Input, Value = orderForm["City"] };
            var paramPostalCode = new SqlParameter("@PostalCode", SqlDbType.NVarChar, 20) { Direction = ParameterDirection.Input, Value = orderForm["PostalCode"] };
            var paramCountryCode = new SqlParameter("@CountryCode", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = orderForm["CountryCode"] };
            var paramRegionCode = new SqlParameter("@RegionCode", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = orderForm["RegionCode"] };
            var paramPOBoxInd = new SqlParameter("@POBoxIndicator", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = bool.Parse(orderForm["IsPoBox"]) };
            var paramPhoneNum = new SqlParameter("@PhoneNumber", SqlDbType.NVarChar, 32) { Direction = ParameterDirection.Input, Value = orderForm["TelNumber"] };
            var paramEMail = new SqlParameter("@eMail", SqlDbType.NVarChar, 64) { Direction = ParameterDirection.Input, Value = orderForm["EmailAddress"] };
            var paramGiftWrapCode = new SqlParameter("@GiftWrapCode", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = orderForm["BTGiftWrapCode"] };
            var paramGiftWrapMessage = new SqlParameter("@GiftWrapMessage", SqlDbType.NVarChar, 300) { Direction = ParameterDirection.Input, Value = orderForm["BTGiftWrapString"] };
            var paramStoreShippingFee = new SqlParameter("@StoreShippingFeeIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = bool.Parse(orderForm["HasStoreShippingFee"])
            };
            var paramStoreGiftWrapFee = new SqlParameter("@StoreGiftWrapFeeIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = bool.Parse(orderForm["HasStoreGiftWrapFee"])
            };
            var paramStoreProccessingFee = new SqlParameter("@StoreProccessingFeeIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = bool.Parse(orderForm["HasStoreProccessingFee"])
            };
            var paramStoreOrderFee = new SqlParameter("@StoreOrderFeeIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = bool.Parse(orderForm["HasStoreOrderFee"])
            };
            var paramCostSummaryByIntAdmin = new SqlParameter("@CostSummaryByIntAdmin", SqlDbType.NVarChar, 2000) { Direction = ParameterDirection.Input, Value = orderForm["CostSummaryByIntAdmin"] };
            var paramCostSummaryByExtAdmin = new SqlParameter("@CostSummaryByExtAdmin", SqlDbType.NVarChar, 2000) { Direction = ParameterDirection.Input, Value = orderForm["CostSummaryByExtAdmin"] };
            var paramShippingMethodID = new SqlParameter("@ShippingMethodID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = orderForm["BTShippingMethodGuid"]
            };
            var paramShippingMethodExId = new SqlParameter("@ShippingMethodExId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = orderForm["ShippingMethodExtID"]
            };
            var paramCarrierCode = new SqlParameter("@CarrierCode", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = orderForm["BTCarrierCode"]
            };
            var paramBackOrderIndicator = new SqlParameter("@BackOrderIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = bool.Parse(orderForm["BackOrderIndicator"])
            };
            var paramNewBasketName = new SqlParameter("@NewBasketName", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
            var paramNewBasketSummaryID = new SqlParameter("@NewBasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
            var paramNewOEBasketName = new SqlParameter("@NewOEBasketName", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };
            var paramNewOEBasketSummaryID = new SqlParameter("@NewOEBasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Output };

            var paramIsVIP = new SqlParameter("@IsVIPCart", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = isVIP
            };

            var paramIsOrderAndHold = new SqlParameter("@OrderAndHoldShippingMethodIndicator", SqlDbType.Bit)
            {
                Direction = ParameterDirection.Input,
                Value = isOrderAndHold
            };

            var paramOrderedDownloadedUserId = new SqlParameter("@OrderedDownloadedUserId", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = orderedDownloadedUserId };
            command.Parameters.AddRange(new[]
                                            {
                                                paramBasketID, paramUserId, paramAccount, paramSpecialInstruction, paramIsHomeDelivery,
                                                paramHandlingTotal, paramShippingTotal, paramSubTotal, paramTaxTotal,
                                                paramTotal, paramName, paramAddLine1, paramAddLine2, paramAddLine3,
                                                paramAddLine4, paramCity, paramPostalCode, paramCountryCode, paramRegionCode,
                                                paramPOBoxInd, paramPhoneNum, paramEMail, paramGiftWrapCode,
                                                paramGiftWrapMessage, paramStoreShippingFee, paramStoreGiftWrapFee,
                                                paramStoreProccessingFee, paramStoreOrderFee, paramCostSummaryByIntAdmin, 
                                                paramCostSummaryByExtAdmin, paramShippingMethodID,
                                                paramShippingMethodExId, paramCarrierCode, paramBackOrderIndicator,
                                                paramNewBasketSummaryID, paramNewBasketName, 
                                                paramNewOEBasketName, paramNewOEBasketSummaryID, paramLoggedInUserId,
                                                paramIsVIP, paramIsOrderAndHold, paramOrderedDownloadedUserId
                                            });

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);

                newBasketName = command.Parameters["@NewBasketName"].Value as string;
                newBasketId = command.Parameters["@NewBasketSummaryID"].Value as string;
                newOEBasketName = command.Parameters["@NewOEBasketName"].Value as string;
                newOEBasketID = command.Parameters["@NewOEBasketSummaryID"].Value as string;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        /// <summary>
        /// Get Store and customer view
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        internal DataSet GetStoreAndCustomerView(string cartId)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_GET_BASKET_STORE_CUSTOMER_VIEW, dbConnection);
            var sqlParamater = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
            command.Parameters.Add(sqlParamater);
            dbConnection.Open();
            try
            {
                var ds = new DataSet();
                var sqlDa = new SqlDataAdapter(command);
                sqlDa.Fill(ds);
                HandleCartException(command);
                return ds;
            }
            finally
            {
                dbConnection.Close();
            }
        }
        #endregion

        #region Helper
        internal static CartFolderType ConvertToFolderType(object value)
        {
            int folderType = DataAccessHelper.ConvertToInt(value);
            return (CartFolderType)folderType;
        }
        #endregion

        //internal bool SaveOriginalEntry(string cartId, OriginalEntry originalEntry, string pOLine, string bib, string userId, string notes, bool isCopy, out int addedQuantity)
        //{
        //    var dbConnection = CreateSqlConnection();
        //    var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_ADD_ORIGINAL_ENTRY_TO_CART, dbConnection);
        //    var basketSummaryIDParam = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
        //    var originalEntryIDParam = new SqlParameter("@BasketOriginalEntryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = "{" + Guid.NewGuid().ToString() + "}" };

        //    if (isCopy)
        //    {
        //        originalEntryIDParam.Value = originalEntry.OriginalEntryId;
        //    }

        //    var titleParam = new SqlParameter("@Title", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.Title };
        //    var responsiblePartyParam = new SqlParameter("@ResponsibleParty", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.AuthorArtist ?? string.Empty };
        //    var physicalFormatParam = new SqlParameter("@PhysicalFormat", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.PhysicalFormat };
        //    var iSBNParam = new SqlParameter("@ISBN", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.ISBN ?? string.Empty };
        //    var uPCParam = new SqlParameter("@UPC", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.UPC ?? string.Empty };
        //    var publisherSupplierParam = new SqlParameter("@PublisherSupplier", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.PublisherSupplier ?? string.Empty };
        //    var publishedReleaseYearParam = new SqlParameter("@PublishedReleaseYear", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = DBNull.Value };
        //    if (!string.IsNullOrEmpty(originalEntry.PubReleaseYear))
        //    {
        //        publishedReleaseYearParam.Value = originalEntry.PubReleaseYear;
        //    }
        //    var listPriceParam = new SqlParameter("@ListPrice", SqlDbType.Decimal) { Direction = ParameterDirection.Input, Value = originalEntry.ListPrice };
        //    SqlParameter quantityParam = null;
        //    if(originalEntry.Quantity < 0) //TFS#8347
        //        quantityParam = new SqlParameter("@Quantity", DBNull.Value);
        //    else 
        //        quantityParam = new SqlParameter("@Quantity", SqlDbType.BigInt) { Direction = ParameterDirection.Input, Value = originalEntry.Quantity };

        //    var pOLineParam = new SqlParameter("@POLineNumber", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = pOLine ?? string.Empty };
        //    var bibParam = new SqlParameter("@BibNumber", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = bib ?? string.Empty };
        //    var hasGridParam = new SqlParameter("@HasGrid", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = false };
        //    var userIdParam = new SqlParameter("@user_id", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };

        //    //Grid params
        //    var noteParam = new SqlParameter("@Note", SqlDbType.NVarChar) { Direction = ParameterDirection.Input, Value = notes ?? string.Empty };
        //    //var gridLinesAndQuantityTable = DataConverter.GetGridLinesAndQuantityTable(null);
        //    //var gridLinesAndQuantityTableParam = new SqlParameter("@GridLineInfo", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = gridLinesAndQuantityTable };
        //    var gridCodesTable = DataConverter.GetGridCodesTable(null);
        //    var gridCodesTableParam = new SqlParameter("@GridCodeInfo", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = gridCodesTable };
        //    var isCopyParam = new SqlParameter("@IsCopy", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = isCopy };
        //    command.Parameters.AddRange(new[]{
        //                                basketSummaryIDParam,
        //                                originalEntryIDParam,
        //                                titleParam,
        //                                responsiblePartyParam,
        //                                physicalFormatParam,
        //                                iSBNParam,
        //                                uPCParam,
        //                                publisherSupplierParam,
        //                                publishedReleaseYearParam,
        //                                listPriceParam,
        //                                quantityParam,
        //                                pOLineParam,
        //                                bibParam,
        //                                noteParam,
        //                                userIdParam,
        //                                hasGridParam,
        //                                gridCodesTableParam,
        //                                //gridLinesAndQuantityTableParam,
        //                                isCopyParam
        //    });

        //    dbConnection.Open();
        //    try
        //    {
        //        var retQty = command.ExecuteScalar();
        //        HandleCartException(command);

        //        addedQuantity = DataAccessHelper.ConvertToInt(retQty);

        //        return true;
        //    }
        //    finally
        //    {
        //        dbConnection.Close();
        //    }
        //}

        internal bool SaveOriginalEntry(string cartId, OriginalEntry originalEntry, List<CommonCartGridLine> cartGridLines, string pOLine, string bib, string note, string userId,bool bHasGrid, out int addedQuantity)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_ADD_ORIGINAL_ENTRY_TO_CART, dbConnection);
            var basketSummaryIDParam = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
            var originalEntryIDParam = new SqlParameter("@BasketOriginalEntryId", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = "{" + Guid.NewGuid().ToString() + "}" };
            var titleParam = new SqlParameter("@Title", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.Title };
            var responsiblePartyParam = new SqlParameter("@ResponsibleParty", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.AuthorArtist };
            var physicalFormatParam = new SqlParameter("@PhysicalFormat", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.PhysicalFormat };
            var iSBNParam = new SqlParameter("@ISBN", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.ISBN };
            var uPCParam = new SqlParameter("@UPC", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.UPC };
            var publisherSupplierParam = new SqlParameter("@PublisherSupplier", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = originalEntry.PublisherSupplier };
            var publishedReleaseYearParam = new SqlParameter("@PublishedReleaseYear", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Input, Value = DBNull.Value };
            if (!string.IsNullOrEmpty(originalEntry.PubReleaseYear))
            {
                publishedReleaseYearParam.Value = originalEntry.PubReleaseYear;
            }
            var listPriceParam = new SqlParameter("@ListPrice", SqlDbType.Decimal) { Direction = ParameterDirection.Input, Value = originalEntry.ListPrice };
            SqlParameter quantityParam = null;
            if (originalEntry.Quantity < 0) //TFS#8347
                quantityParam = new SqlParameter("@Quantity", DBNull.Value);
            else
                quantityParam = new SqlParameter("@Quantity", SqlDbType.BigInt) { Direction = ParameterDirection.Input, Value = originalEntry.Quantity };

            //var quantityParam = new SqlParameter("@Quantity", SqlDbType.BigInt) { Direction = ParameterDirection.Input, Value = originalEntry.Quantity };
            var pOLineParam = new SqlParameter("@POLineNumber", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = pOLine };
            var bibParam = new SqlParameter("@BibNumber", SqlDbType.NVarChar, 80) { Direction = ParameterDirection.Input, Value = bib };
            var userIdParam = new SqlParameter("@user_id", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            //Grid params
            var noteParam = new SqlParameter("@Note", SqlDbType.NVarChar) { Direction = ParameterDirection.Input, Value = note };
            if (string.IsNullOrEmpty(note))
            {
                noteParam.Value = DBNull.Value;
            }            

            //var gridLinesAndQuantityTable = DataConverter.GetGridLinesAndQuantityTable(cartGridLines);
            //var gridLinesAndQuantityTableParam = new SqlParameter("@GridLineInfo", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = gridLinesAndQuantityTable };
            var gridCodesTable = DataConverter.ConvertCartGridLinesToDataSet(cartGridLines);

            var gridCodesTableParam = new SqlParameter("@GridCodeInfo", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = gridCodesTable };
            var hasGrid = new SqlParameter("@HasGrid", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = bHasGrid };
            var isCopyParam = new SqlParameter("@IsCopy", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = false };
            command.Parameters.AddRange(new[]{
                                        basketSummaryIDParam,
                                        originalEntryIDParam,
                                        titleParam,
                                        responsiblePartyParam,
                                        physicalFormatParam,
                                        iSBNParam,
                                        uPCParam,
                                        publisherSupplierParam,
                                        publishedReleaseYearParam,
                                        listPriceParam,
                                        quantityParam,
                                        pOLineParam,
                                        bibParam,
                                        userIdParam,
                                        noteParam,
                                        //gridLinesAndQuantityTableParam,
                                        gridCodesTableParam,
                                        hasGrid,
                                        isCopyParam
                                        
            });

            dbConnection.Open();
            try
            {
                var retQty = command.ExecuteScalar();
                HandleCartException(command);

                addedQuantity = DataAccessHelper.ConvertToInt(retQty);

                return true;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal DataSet GetCartLinesByNote(string facetPath, string keyword, int pageNumber, byte pageSize, int sortBy, string userId, string cartId, out int totalLines, int sortDirection)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_GET_CART_LINE_ITEMS_BY_NOTE, dbConnection);
            command.CommandTimeout = 300;

            //<Parameter>
            int total = 0;
            var sqlParameters = new SqlParameter[9];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", cartId);
            if (!string.IsNullOrEmpty(facetPath))
            {
                sqlParameters[1] = new SqlParameter("@FacetPath", facetPath);
            }
            else
            {
                sqlParameters[1] = new SqlParameter("@FacetPath", DBNull.Value);
            }

            if (!string.IsNullOrEmpty(keyword))
                sqlParameters[2] = new SqlParameter("@Keyword", keyword);
            else
            {
                sqlParameters[2] = new SqlParameter("@Keyword", DBNull.Value);
            }
            sqlParameters[3] = new SqlParameter("@PageNumber", pageNumber);
            sqlParameters[4] = new SqlParameter("@PageSize", pageSize);
            sqlParameters[5] = new SqlParameter("@orderedBy", CartFrameworkHelper.TransformSortOrderLineItem(sortBy));
            sqlParameters[6] = new SqlParameter("@TotalLines", total) { Direction = ParameterDirection.Output };
            sqlParameters[7] = new SqlParameter("@UserID", userId);
            sqlParameters[8] = new SqlParameter("@Direction", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = sortDirection };

            command.Parameters.AddRange(sqlParameters);

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
            totalLines = DataAccessHelper.ConvertToInt(command.Parameters["@TotalLines"].Value);
            return ds;
        }

        internal DataSet GetCartLinesByGridFieldCode(string cartId, string userId, GridFieldType gridFieldType, string gridCodeId,
            string gridText, int pageSize, int pageNumber, int sortBy, int sortDirection, out int totalLines, bool isFreeText,
            int? quantity = null)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_BASKET_GET_CART_LINE_ITEMS_BY_GRID_FIELD_CODE, dbConnection);
            command.CommandTimeout = 300;

            string sortbyLiteral = CartFrameworkHelper.TransformSortOrderLineItem(sortBy);
            
            //<Parameter>
            int total = 0;
            var sqlParameters = new SqlParameter[11];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameters[1] = new SqlParameter("@PageNumber", pageNumber);
            sqlParameters[2] = new SqlParameter("@PageSize", pageSize);
            sqlParameters[3] = new SqlParameter("@SortBy", sortbyLiteral);
            sqlParameters[4] = new SqlParameter("@TotalLines", total) { Direction = ParameterDirection.Output };
            sqlParameters[5] = new SqlParameter("@UserID", userId);
            sqlParameters[6] = new SqlParameter("@Direction", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = sortDirection };
            sqlParameters[7] = new SqlParameter("@GridFieldType", gridFieldType.ToString());

            if (!isFreeText)
            {
                sqlParameters[8] = new SqlParameter("@GridCodeID", gridCodeId);
                sqlParameters[9] = new SqlParameter("@CallNumber", DBNull.Value);
            }
            else
            {
                sqlParameters[8] = new SqlParameter("@GridCodeID", DBNull.Value);
                sqlParameters[9] = new SqlParameter("@CallNumber", gridText);
            }

            if (quantity.HasValue)
            {
                sqlParameters[8].Value = DBNull.Value;
                sqlParameters[9].Value = DBNull.Value;
            }

            sqlParameters[10] = new SqlParameter("@Quantity", SqlDbType.Int)
                                {
                                    Value =
                                        quantity.HasValue
                                            ? (object) quantity.Value
                                            : DBNull.Value
                                };

            command.Parameters.AddRange(sqlParameters);

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
            totalLines = DataAccessHelper.ConvertToInt(command.Parameters["@TotalLines"].Value);
            return ds;
        }

        internal bool DragAndDropCartFolder(string sourceFolderId, string destinationFolderId, string position)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360DragDropFolder, dbConnection);
            var sourceFolderIdParam = new SqlParameter("@SourceFolderID", SqlDbType.NVarChar, 50)
                                          {
                                              Direction = ParameterDirection.Input,
                                              Value = sourceFolderId
                                          };
            var destinationFolderIdParam = new SqlParameter("@DestinationFolderID", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = destinationFolderId
            };

            var positionParam = new SqlParameter("@Position", SqlDbType.Char, 5)
            {
                Direction = ParameterDirection.Input,
                Value = position
            };

            command.Parameters.AddRange(new[]{
                                        sourceFolderIdParam,
                                        destinationFolderIdParam,
                                        positionParam
            });

            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);

                return true;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        internal DataSet SearchOrders(string keyword, string sortBy, string sortDirection, int pageIndex, int pageSize,
            OrderStatus orderStatus, char searchOrderType, out int totalOrderCount, out int totalCarts)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360Searchorders, dbConnection);

            #region define params
            var keyWordParam = new SqlParameter("@Keyword", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = keyword
            };
            var sortByParam = new SqlParameter("@SortBy", SqlDbType.VarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = sortBy
            };

            var sortDirectionParam = new SqlParameter("@SortDirection", SqlDbType.VarChar, 4)
            {
                Direction = ParameterDirection.Input,
                Value = sortDirection
            };

            var pageIndexParam = new SqlParameter("@PageIndex", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = pageIndex
            };

            var pageSizeParam = new SqlParameter("@PageSize", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = pageSize
            };

            var orderStatusParam = new SqlParameter("@OrderStatus", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = (int)orderStatus
            };

            var searchOrderTypeParam = new SqlParameter("@SearchType", SqlDbType.Char)
            {
                Direction = ParameterDirection.Input,
                Value = searchOrderType
            };

            var totalOrdersParam = new SqlParameter("@TotalOrderCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            var totalCartsParam = new SqlParameter("@TotalCarts", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            #endregion

            command.Parameters.AddRange(new[]{
                                        keyWordParam,sortByParam,sortDirectionParam, pageIndexParam, pageSizeParam, orderStatusParam,
                                        searchOrderTypeParam, totalOrdersParam, totalCartsParam
            });

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
            totalOrderCount = DataAccessHelper.ConvertToInt(command.Parameters["@TotalOrderCount"].Value);
            totalCarts = DataAccessHelper.ConvertToInt(command.Parameters["@TotalCarts"].Value);
            return ds;
        }

        internal DataSet ViewOrdersQueue(string cartId, out int totalOrdersCount, out int totalCarts)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360ViewOrderQueue, dbConnection);

            #region define params
            var cartIdParam = new SqlParameter("@BasketSummaryId", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = cartId
            };

            var totalOrdersParam = new SqlParameter("@TotalOrderCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };

            var totalCartsParam = new SqlParameter("@TotalCarts", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            #endregion

            command.Parameters.AddRange(new[]{
                                        cartIdParam,totalOrdersParam, totalCartsParam
            });

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
            totalOrdersCount = DataAccessHelper.ConvertToInt(command.Parameters["@TotalOrderCount"].Value);
            totalCarts = DataAccessHelper.ConvertToInt(command.Parameters["@TotalCarts"].Value);
            return ds;
        }

        internal void RequestCartQuote(string cartID, string userID)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_BASKET_MANAGEMENT_REQUEST_QUOTE, dbConnection);

            //<Parameter>
            var paramBasketID = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartID };
            var paramUserID = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userID };

            command.Parameters.AddRange(new[] { paramBasketID, paramUserID });


            dbConnection.Open();
            try
            {
                command.ExecuteNonQuery();
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
        }

        public DataSet GetCartDetailsQuickView(string cartId, string userId, string sortBy, byte sortDirection,
            short pageSize, int pageNumber, bool recalculateHeader, out int nonRankedCount)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_GET_CART_DETAILS_QUICK_VIEW, dbConnection);
            command.CommandTimeout = 300;

           if (string.Equals(sortBy,SearchResultsSortField.SORT_ADD_TO_CART_DATE,StringComparison.OrdinalIgnoreCase))
            {
                sortBy = "basketorder";
            }

            //<Parameter>
            var sqlParameters = new SqlParameter[8];
            sqlParameters[0] = new SqlParameter("@BasketSummaryID", cartId);
            sqlParameters[1] = new SqlParameter("@UserID", userId);
            sqlParameters[2] = new SqlParameter("@SortBy", sortBy);
            sqlParameters[3] = new SqlParameter("@SortDirection", sortDirection);
            sqlParameters[4] = new SqlParameter("@PageSize", pageSize);
            sqlParameters[5] = new SqlParameter("@PageNumber", pageNumber);
            sqlParameters[6] = new SqlParameter("@RecalculateHeader", recalculateHeader);
            sqlParameters[7] = new SqlParameter("@PendingRankCount", SqlDbType.Int) { Direction = ParameterDirection.Output };
            
            command.Parameters.AddRange(sqlParameters);

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }

            nonRankedCount = DataAccessHelper.ConvertToInt(command.Parameters["@PendingRankCount"].Value);

            return ds;
        }

        internal DataSet SearchQuotations(string keyword, string searchBy, int pageIndex, int pageSize, string sortBy, int sortDirection, out int totalCarts)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTS360SearchQuotations, dbConnection);
            if(string.IsNullOrEmpty(sortBy))
                sortBy = string.Empty;
            if(string.IsNullOrEmpty(keyword))
                keyword = string.Empty;
            if (string.IsNullOrEmpty(searchBy))
                searchBy = string.Empty;
                
            #region define params
            var keyWordParam = new SqlParameter("@searchKey", SqlDbType.NVarChar, 150)
            {
                Direction = ParameterDirection.Input,
                Value = keyword
            };
            var searchByParam = new SqlParameter("@SearchBy", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = searchBy
            };
            var sortByParam = new SqlParameter("@orderBy", SqlDbType.VarChar, 50)
            {
                Direction = ParameterDirection.Input,
                Value = sortBy
            };

            var sortDirectionParam = new SqlParameter("@direction", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = sortDirection
            };

            var pageIndexParam = new SqlParameter("@selectedPage", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = pageIndex
            };

            var pageSizeParam = new SqlParameter("@pageSize", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = pageSize
            };
            var totalCartsParam = new SqlParameter("@TotalCarts", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            #endregion

            command.Parameters.AddRange(new[]{
                                        keyWordParam, searchByParam, sortByParam, sortDirectionParam, pageIndexParam, pageSizeParam, totalCartsParam });

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }
            totalCarts = DataAccessHelper.ConvertToInt(command.Parameters["@TotalCarts"].Value);
            return ds;
        }

        internal DataSet ViewESPQueue(string displayStatus, string cartStatus, int pageIndex, int pageSize, out int totalItems)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.ProcTs360ViewESPQueue, dbConnection);
            
            #region define params
            var displayStatusParam = new SqlParameter("@DisplayStatus", SqlDbType.VarChar, 5)
            {
                Direction = ParameterDirection.Input,
                Value = displayStatus
            };

            var cartStatusParam = new SqlParameter("@CartStatus", SqlDbType.VarChar, -1)
            {
                Direction = ParameterDirection.Input,
                Value = (object) cartStatus ?? DBNull.Value
            };

            var pageNumberParam = new SqlParameter("@PageNumber", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = pageIndex
            };

            var pageSizeParam = new SqlParameter("@pageSize", SqlDbType.Int)
            {
                Direction = ParameterDirection.Input,
                Value = pageSize
            };

            var totalItemsParam = new SqlParameter("@TotalItems", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };

            #endregion

            // add params
            command.Parameters.AddRange(new[] { displayStatusParam,
                                                cartStatusParam,
                                                pageNumberParam,
                                                pageSizeParam, 
                                                totalItemsParam 
                                            });

            var ds = new DataSet();
            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }

            totalItems = DataAccessHelper.ConvertToInt(command.Parameters["@TotalItems"].Value);

            return ds;
        }

        internal DataSet ApplyDuplicates(List<string> cartIDs, string userID, int maxLineLimit,
            string cartCheckType, string orderCheckType, string orgId, out int returnCode, string downloadCheckType, bool moveToNewCart)
        {
            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_TS360_GET_BASKETS_WITH_DUPLICATED_TITLES, dbConnection);//
            var cartIDsTable = DataAccessHelper.GenerateDataRecords(cartIDs, "GUID", 50);

            var cartIDsParam = new SqlParameter("@BasketIDs", SqlDbType.Structured) { Value = cartIDsTable };
            var userIDParam = new SqlParameter("@UserID", userID);
            var maxLineLimitParam = new SqlParameter("@MaxLineLimit", maxLineLimit);

            var cartCheckTypeParam = new SqlParameter("@cartCheckType", cartCheckType ?? string.Empty);
            var orderCheckTypeParam = new SqlParameter("@orderCheckType", orderCheckType ?? string.Empty);
            var downloadCheckTypeParam = new SqlParameter("@downloadCheckType", downloadCheckType ?? string.Empty);
            var moveToNewCartParam = new SqlParameter("@moveToNewCart", moveToNewCart);
            
            SqlParameter orgIdParam;
            if (orgId == null)
                orgIdParam = new SqlParameter("@orgId", DBNull.Value);
            else
                orgIdParam = new SqlParameter("@orgId", orgId);


            command.Parameters.AddRange(new[]{
                                        cartIDsParam,
                                        userIDParam,
                                        maxLineLimitParam,
                                        cartCheckTypeParam,
                                        orderCheckTypeParam,
                                        orgIdParam,
                                        downloadCheckTypeParam,
                                        moveToNewCartParam
            });
            var ds = new DataSet();

            var da = new SqlDataAdapter(command);
            dbConnection.Open();
            try
            {
                da.Fill(ds);
                var returnVal = -1;
                HandleCartException(command, out returnVal);
                returnCode = returnVal;
            }
            finally
            {
                dbConnection.Close();
            }
            return ds;
        }

        internal DataSet SetCartAsActiveOrInActive(string cartId, string userId, bool isActive, int maxActiveCarts)
        {
            var ds = new DataSet();

            var dbConnection = CreateSqlConnection();
            var command = CreateSqlSpCommand(StoreProcedureName.PROC_SET_ACTIVE_OR_INACTIVE_BASKET, dbConnection);

            //<Parameter>
            var paramBasketID = new SqlParameter("@BasketSummaryID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = cartId };
            var paramUserID = new SqlParameter("@UserID", SqlDbType.NVarChar, 50) { Direction = ParameterDirection.Input, Value = userId };
            var paramIsActiveIndicator = new SqlParameter("@IsActiveIndicator", SqlDbType.Bit) { Direction = ParameterDirection.Input, Value = isActive };
            var paramMaxActiveCarts = new SqlParameter("@MaxActiveCarts", SqlDbType.Int) { Direction = ParameterDirection.Input, Value = maxActiveCarts };
            command.Parameters.AddRange(new[] { paramBasketID, paramUserID, paramIsActiveIndicator, paramMaxActiveCarts });

            var da = new SqlDataAdapter(command);

            dbConnection.Open();
            try
            {
                da.Fill(ds);
                HandleCartException(command);
            }
            finally
            {
                dbConnection.Close();
            }

            return ds;
        }
    }
}
