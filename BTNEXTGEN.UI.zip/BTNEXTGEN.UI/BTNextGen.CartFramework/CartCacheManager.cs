﻿using System;
using System.Collections.Generic;
using System.Data;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.VelocityCaching;

namespace BTNextGen.CartFramework
{
    static internal class CartCacheManager
    {
        #region Constants

        //internal const string PRIMARY_CART_CACHE_KEY_SUFFIX = "PRIMARY_CART";
        internal const string TOP_NEWEST_CART_CACHE_KEY_SUFFIX = "TOP_NEWEST_CART";
        internal const string CART_CACHE_KEY_SUFFIX = "CART";
        internal const string CART_FOLDER_LIST_KEY_SUFFIX = "CART_FOLDER_LIST";
        internal const string CART_FOLDER_KEY_SUFFIX = "CART_FOLDER";
        internal const string CART_ORGANIZATION_PERMISSION_KEY_SUFFIX = "CART_ORGANIZATION_PERMISSION";
        internal const string CART_USER_PERMISSION_KEY_SUFFIX = "CART_USER_PERMISSION";
        #endregion

        #region Properties
        internal static int CartCacheExpiredDuration
        {
            get
            {
                int cartCacheExpired = 5;
                var valueFromGlobalConfiguration = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.CartCacheExpireDuration);
                if (valueFromGlobalConfiguration != null)
                {
                    int.TryParse(valueFromGlobalConfiguration.Value, out cartCacheExpired);
                }

                return cartCacheExpired;
            }
        }
        #endregion

        #region Caching functional methods for Cart Folder

        /// <summary>
        /// Get Cart Folders From Cache
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static CartFolders GetCartFoldersFromCache(string userId)
        {
            return VelocityCacheManager.Read(GetCartFolderListCacheKey(userId)) as CartFolders;
        }

        /// <summary>
        /// Add Cart Folders To Cache
        /// </summary>
        /// <param name="cartFolders"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static void AddCartFoldersToCache(CartFolders cartFolders, string userId)
        {
            VelocityCacheManager.Write(GetCartFolderListCacheKey(userId), cartFolders, CartCacheConstants.CartFolderCacheLevel);
        }

        internal static void SetCartFoldersCacheExpired(string userId)
        {
            VelocityCacheManager.SetExpired(GetCartFolderListCacheKey(userId));
        }

        #endregion

        #region Caching functional methods for Cart

        #region Get cart from cache
        ///// <summary>
        ///// Get Primary Cart From Cache
        ///// </summary>
        ///// <param name="userId"></param>
        ///// <returns></returns>
        //internal static Cart GetPrimaryCartFromCache(string userId)
        //{
        //    return VelocityCacheManager.Read(GetPrimaryCartCacheKey(userId)) as Cart;
        //}

        internal static Carts GetTopNewestCartFromCache(string userId)
        {
            return VelocityCacheManager.Read(GetTopNewestCartCacheKey(userId)) as Carts;
        }

        internal static Cart GetCartFromCache(string cartId)
        {
            return VelocityCacheManager.Read(GetCartCacheKey(cartId)) as Cart;
        }
        internal static DataSet GetCartDsFromCache(string cartId)
        {
            return VelocityCacheManager.Read(GetCartCacheKey(cartId), CartCacheConstants.FarmCacheLevel) as DataSet;
        }
        internal static DataSet GetCartFolderDataSetFromCache(string userId)
        {
            return VelocityCacheManager.Read(GetCartFolderListCacheKey(userId), CartCacheConstants.FarmCacheLevel) as DataSet;
        }
        #endregion

        #region Add cart to cache
        ///// <summary>
        ///// Add Primary Cart To Cache
        ///// </summary>
        ///// <param name="cart"></param>
        ///// <param name="userId"></param>
        //internal static void AddPrimaryCartToCache(Cart cart, string userId)
        //{
        //    VelocityCacheManager.Write(GetPrimaryCartCacheKey(userId), cart, CartCacheConstants.PrimaryCartCacheLevel);
        //}

        internal static void AddNewestCartToCache(Carts carts, string userId)
        {
            VelocityCacheManager.Write(GetTopNewestCartCacheKey(userId), carts, VelocityCacheLevel.Session, CartCacheExpiredDuration);
        }

        internal static void AddCartToCache(Cart cart)
        {
            VelocityCacheManager.Write(GetCartCacheKey(cart.CartId), cart, CartCacheConstants.CommonCartCacheLevel, CartCacheExpiredDuration);
        }

        internal static void AddCartFolderDataSetToCache(DataSet cartFolderDataSet, string userId)
        {
            VelocityCacheManager.Write(GetCartFolderListCacheKey(userId), cartFolderDataSet, CartCacheConstants.FarmCacheLevel);
        }

        #endregion

        #region Set cart cache expired
        /// <summary>
        /// Set expired for specified user's primary cart.
        /// </summary>
        /// <param name="userId"></param>
        internal static void SetPrimaryCartCacheExpired(string userId)
        {
            //VelocityCacheManager.SetExpired(GetPrimaryCartCacheKey(userId));
            CartFarmCacheHelper.SetExpiredPrimaryCart(userId);
        }

        internal static void SetTopNewestCartCacheExpired(string userId)
        {
            VelocityCacheManager.SetExpired(GetTopNewestCartCacheKey(userId));
        }

        internal static void SetCartCacheExpired(string cartId)
        {
            VelocityCacheManager.SetExpired(GetCartCacheKey(cartId));
        }
        internal static void SetCartFolderDistributedCacheExpired(List<string> userIdsList)
        {
            VelocityCacheManager.DistributedCacheName = GlobalConfiguration.DistributedCacheName;
            VelocityCacheManager.DistributedCacheEnvRegion = GlobalConfiguration.DistributedCache_Env_Region;

            foreach (var userId in userIdsList)
            {
                VelocityCacheManager.SetFarmCacheExpired(GetCartFolderListCacheKey(userId));
            }
        }
        #endregion

        #endregion

        #region Caching functional methods for Permission
        internal static CartPermission GetOrganizationPermissionFromCache()
        {
            return VelocityCacheManager.Read(GetOrganizationPermissionCacheKey()) as CartPermission;
        }

        internal static CartPermission GetUserPermissionFromCache()
        {
            return VelocityCacheManager.Read(GetUserPermissionCacheKey()) as CartPermission;
        }
        #endregion

        #region Utilities / Helper methods

        #region Cache Key
        //Cart
        //private static string GetPrimaryCartCacheKey(string userId)
        //{
        //    return String.Format("{0}_{1}_{2}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX,
        //                         PRIMARY_CART_CACHE_KEY_SUFFIX, userId);
        //}

        private static string GetTopNewestCartCacheKey(string userId)
        {
            return String.Format("{0}_{1}_{2}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX,
                                 TOP_NEWEST_CART_CACHE_KEY_SUFFIX, userId);
        }

        private static string GetCartCacheKey(string cartID)
        {
            return string.Format("{0}_{1}_{2}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX, CART_CACHE_KEY_SUFFIX, cartID);
        }

        private static string GetCartFolderListCacheKey(string userId)
        {
            return String.Format("{0}_{1}_{2}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX,
                                 CART_FOLDER_LIST_KEY_SUFFIX, userId);
        }

        //Permission
        private static string GetOrganizationPermissionCacheKey()
        {
            return String.Format("{0}_{1}_{2}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX,
                                 CART_ORGANIZATION_PERMISSION_KEY_SUFFIX, "");
        }

        private static string GetUserPermissionCacheKey()
        {
            return String.Format("{0}_{1}_{2}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX,
                                 CART_USER_PERMISSION_KEY_SUFFIX, "");
        }
        #endregion

        #endregion

        #region Cache for Cart Details in First time

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cart"></param>
        /// <param name="userId"></param>
        internal static void AddPrimaryCartToCacheForCartDetails(Cart cart, string userId)
        {
            // Cache Primary Cart
            var cacheKeyPrimaryCart = string.Format("{0}_{1}", userId,
                                                 BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.CART_DETAILS_PAGE_PRIMARY_CART);
            VelocityCacheManager.Write(cacheKeyPrimaryCart, cart, VelocityCacheLevel.Session);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static Cart GetPrimaryCartFromCartDetailsCache(string userId)
        {
            // Get Primary Cart in cache
            var cacheKeyPrimaryCart = string.Format("{0}_{1}", userId,
                                                 BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.CART_DETAILS_PAGE_PRIMARY_CART);
            var cart = VelocityCacheManager.Read(cacheKeyPrimaryCart) as Cart;

            if (GetPrimaryCartFromCacheForMiniCart(userId))
                return cart;

            if (GetPrimaryCartFromCacheForCartFilterData(userId))
                return cart;

            if (GetPrimaryCartFromCacheForAdditionalProduct(userId))
                return cart;

            if (GetPrimaryCartFromCacheForUpdateAllItems(userId))
                return cart;

            return null;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private static bool GetPrimaryCartFromCacheForMiniCart(string userId)
        {
            var cacheKeyMiniCart = string.Format("{0}_{1}", userId,
                                                 BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.
                                                     IS_CART_DETAILS_LAUNCH_MINI_CART);
            var cacheMiniCart = VelocityCacheManager.Read(cacheKeyMiniCart);
            if (cacheMiniCart != null && ((bool)cacheMiniCart))
            {
                var firstTime = string.Format("{0}_{1}", userId,
                                                     BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_MINI_CART_FIRST_TIME);
                var firstTimeObj = VelocityCacheManager.Read(firstTime);
                if (firstTimeObj != null && ((bool)firstTimeObj))
                {
                    VelocityCacheManager.Write(firstTime, false, VelocityCacheLevel.Session); //Reset NOT first time
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private static bool GetPrimaryCartFromCacheForCartFilterData(string userId)
        {
            var cacheKeyCartFilter = string.Format("{0}_{1}", userId,
                                                 BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_CART_DETAILS_LAUNCH_CART_FILTER_DATA);
            var cacheCartFilter = VelocityCacheManager.Read(cacheKeyCartFilter);
            if (cacheCartFilter != null && ((bool)cacheCartFilter))
            {
                var firstTime = string.Format("{0}_{1}", userId,
                                                     BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_CART_FILTER_DATA_FIRST_TIME);
                var firstTimeObj = VelocityCacheManager.Read(firstTime);
                if (firstTimeObj != null && ((bool)firstTimeObj))
                {
                    VelocityCacheManager.Write(firstTime, false, VelocityCacheLevel.Session);  //Reset NOT first time
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private static bool GetPrimaryCartFromCacheForAdditionalProduct(string userId)
        {
            var cacheKeyAdditional = string.Format("{0}_{1}", userId,
                                                 BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_CART_DETAILS_LAUNCH_ADDITIONAL_PRODUCT);
            var cacheAdditional = VelocityCacheManager.Read(cacheKeyAdditional);
            if (cacheAdditional != null && ((bool)cacheAdditional))
            {
                var firstTime = string.Format("{0}_{1}", userId,
                                                     BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_ADDITIONAL_PRODUCT_FIRST_TIME);
                var firstTimeObj = VelocityCacheManager.Read(firstTime);
                if (firstTimeObj != null && ((bool)firstTimeObj))
                {
                    VelocityCacheManager.Write(firstTime, false, VelocityCacheLevel.Session);  //Reset NOT first time
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private static bool GetPrimaryCartFromCacheForUpdateAllItems(string userId)
        {

            var cacheKeyUpdate = string.Format("{0}_{1}", userId,
                                                 BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_CART_DETAILS_LAUNCH_UPPDATE_ALL_ITEMS);
            var cacheUpdate = VelocityCacheManager.Read(cacheKeyUpdate);
            if (cacheUpdate != null && ((bool)cacheUpdate))
            {
                var firstTime = string.Format("{0}_{1}", userId,
                                                     BTNextGen.Commerce.Portal.Common.Constants.CacheKeyConstant.IS_UPPDATE_ALL_ITEMS_FIRST_TIME);
                var firstTimeObj = VelocityCacheManager.Read(firstTime);
                if (firstTimeObj != null && ((bool)firstTimeObj))
                {
                    VelocityCacheManager.Write(firstTime, false, VelocityCacheLevel.Session);  //Reset NOT first time
                    return true;
                }
            }

            return false;
        }

        #endregion

        public static void SetArchivedFolderExpired()
        {
            VelocityCacheManager.SetExpired(OrdersConstants.ManageCartsArchivedCartFolderCacheKey);
        }


    }
}
