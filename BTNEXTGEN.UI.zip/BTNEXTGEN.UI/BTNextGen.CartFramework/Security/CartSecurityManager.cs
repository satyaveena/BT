﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.CartFramework
{
    internal class CartSecurityManager
    {
        internal bool IsAllowed(string orgId, string userId, string methodCategory, string method)
        {
            if(String.IsNullOrEmpty(orgId)) throw new CartManagerException(CartManagerException.ORGANIZATION_ID_NULL);
            if (String.IsNullOrEmpty(userId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);

            var cachedOrgPermission = CartCacheManager.GetOrganizationPermissionFromCache();
            var cachedUserPermission = CartCacheManager.GetUserPermissionFromCache();

            return true;
        }

        private bool DetermineCartPermission(CartPermission permission)
        {
            throw new NotImplementedException();
        }
    }
}
