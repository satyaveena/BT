﻿
using System;
using System.Collections.Generic;
using System.Collections;
using BTNextGen.CartFramework.Helpers;
using BTNextgen.Grid.Cart;
using BTNextGen.Commerce.Portal.Common.Constants;
using BT.TS360Constants;

namespace BTNextGen.CartFramework
{
    public sealed class Carts : BaseCart, ICollection<Cart>
    {
        #region Constructor

        /// <summary>
        /// Carts
        /// </summary>
        /// <param name="userId"></param>
        public Carts(string userId)
        {
            this.UserId = userId;
            items = new List<Cart>();
        }

        #endregion

        #region Private/Protected Properties

        /// <summary>
        /// items for ICollection
        /// </summary>
        private readonly List<Cart> items;


        #endregion

        #region Public Methods

        /// <summary>
        /// GetEnumerator
        /// </summary>
        /// <returns></returns>
        public IEnumerator<Cart> GetEnumerator()
        {
            return items.GetEnumerator();
        }

        /// <summary>
        /// GetEnumerator
        /// </summary>
        /// <returns></returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return items.GetEnumerator();
        }

        /// <summary>
        /// Add
        /// </summary>
        /// <param name="item"></param>
        public void Add(Cart item)
        {
            items.Add(item);
        }

        public void AddRange(IEnumerable<Cart> collection)
        {
            items.AddRange(collection);
        }

        /// <summary>
        /// Clear
        /// </summary>
        public void Clear()
        {
            items.Clear();
        }

        /// <summary>
        /// Contains
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Contains(Cart item)
        {
            return items.Contains(item);
        }

        /// <summary>
        /// Copy To
        /// </summary>
        /// <param name="array"></param>
        /// <param name="arrayIndex"></param>
        public void CopyTo(Cart[] array, int arrayIndex)
        {
            items.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// Remove
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Remove(Cart item)
        {
            return items.Remove(item);
        }

        /// <summary>
        /// Count
        /// </summary>
        public int Count
        {
            get { return items.Count; }
        }

        /// <summary>
        /// A collection that is read-only does not allow the addition, removal, or modification of elements after the collection is created.
        /// </summary>
        public bool IsReadOnly
        {
            get { return false; }
        }

        #endregion

        #region Internal Methods

        ///// <summary>
        ///// Get Primary Cart
        ///// </summary>
        ///// <returns></returns>
        //internal Cart GetPrimaryCart()
        //{
        //    if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);

        //    Cart cartCache = CartCacheManager.GetPrimaryCartFromCache(this.UserId);
        //    //prevent the issue when CartOwnerId and BTStatus are null
        //    if (cartCache != null && cartCache.CartOwnerId != null && cartCache.BTStatus != null
        //        && cartCache.BTStatus != CartStatus.Submitted.ToString() && cartCache.BTStatus != CartStatus.Ordered.ToString())
        //    {
        //        if (IsDeleted(cartCache.BTStatus))
        //            return null;
        //        return cartCache;
        //    }

        //    var cart = CartDAOManager.GetPrimaryCart(this.UserId);
        //    if (cart != null && IsDeleted(cart.BTStatus))
        //        return null;

        //    if (cart != null)
        //    {
        //        CartCacheManager.AddPrimaryCartToCache(cart, this.UserId);
        //    }
        //    return cart;
        //}

        ///// <summary>
        ///// Get Primary Cart, not for mini cart
        ///// This will return the cart even it's status is Deleted or Submitted.
        ///// </summary>
        ///// <returns></returns>
        //internal Cart GetPrimaryCartNotForMinicart()
        //{
        //    if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);

        //    Cart cartCache = CartCacheManager.GetPrimaryCartFromCache(this.UserId);
        //    if (cartCache != null)
        //    {
        //        return cartCache;
        //    }

        //    var cart = CartDAOManager.GetPrimaryCart(this.UserId);

        //    if (cart != null)
        //    {
        //        CartCacheManager.AddPrimaryCartToCache(cart, this.UserId);
        //    }
        //    return cart;
        //}

        //private bool IsDeleted(string cartStatus)
        //{
        //    return cartStatus == CartStatus.Deleted.ToString();
        //}

        /// <summary>
        /// Get a cart with the specified id
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        internal Cart GetCartById(string cartId)
        {
            //if cart is primary
            var isPrimary = IsPrimaryCart(cartId, this.UserId);
            if (isPrimary)
            {
                return CartFarmCacheHelper.GetPrimaryCartNotForMinicart(this.UserId, cartId);
            }

            //normal cart
            var cartCache = CartCacheManager.GetCartFromCache(cartId);
            if (cartCache != null && cartCache.BTStatus != CartStatus.Submitted.ToString() &&
                            cartCache.BTStatus != CartStatus.Ordered.ToString())
                return cartCache;

            //not found cart in cache or submitted cart
            var cart = CartDAOManager.GetCartById(cartId, this.UserId);
            if (cart != null)
            {
                CartCacheManager.AddCartToCache(cart);
            }

            //// AppFabric
            //var cart = CartDAOManager.GetCartById(cartId, this.UserId);

            return cart;
        }

        /// <summary>
        /// Get a cart with the specified id
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        internal Cart GetCartByIdFromDB(string cartId)
        {
            var cart = CartDAOManager.GetCartById(cartId, this.UserId);
            if (cart != null)
            {
                CartCacheManager.AddCartToCache(cart);
            }

            return cart;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        internal Cart GetOriginalCart(string cartId)
        {
            var cart = CartDAOManager.GetCartById(cartId, this.UserId);
            return cart;
        }

        /// <summary>
        /// Get a cart with the specified id
        /// </summary>
        /// <param name="cartId"></param>
        /// <param name="needToReprice"></param>
        /// <returns></returns>
        internal Cart GetCartById(string cartId, bool needToReprice)
        {
            if (!needToReprice) return GetCartById(cartId);

            //Recalculate Price
            CartFrameworkHelper.CalculatePrice(cartId);

            var cart = CartDAOManager.GetCartById(cartId, this.UserId);
            if (cart != null)
            {
                CartCacheManager.AddCartToCache(cart);
            }
            return cart;
        }
        internal void ResetCacheCartById(string cartId)
        {
            //if cart is primary
            var isPrimary = IsPrimaryCart(cartId, this.UserId);
            if (isPrimary)
            {
                // remove primary cart from distributed cache
                CartFarmCacheHelper.SetExpiredPrimaryCart(this.UserId, cartId);
            }
            else//normal cart
                CartCacheManager.SetCartCacheExpired(cartId);
        }
        internal Carts GetTopNewestCarts(int topCartNum)
        {
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            return CartDAOManager.GetTopNewestCarts(topCartNum, UserId);
        }

        internal void DeleteCarts(List<string> cartIDs, string userId = "")
        {
            CartDAOManager.DeleteCarts(cartIDs, string.IsNullOrEmpty(userId) ? UserId : userId);

            NotifyCartsChanged(cartIDs);
        }

        internal void ArchiveCarts(List<string> cartIDs)
        {
            CartDAOManager.ArchiveCarts(cartIDs, UserId);

            NotifyCartsChanged(cartIDs);
            NotifyArchivedFolderChanged();
        }

        private void NotifyArchivedFolderChanged()
        {
            CartCacheManager.SetArchivedFolderExpired();
        }

        internal void RestoreCarts(List<string> cartIDs, string toFolder)
        {
            CartDAOManager.RestoreCarts(cartIDs, toFolder, UserId);

            this.NotifyCartsChanged(cartIDs);
            NotifyArchivedFolderChanged();
        }

        internal void CopyCarts(List<string> cartIDs, string folderId, CartCopyType cartCopyType, bool copyESP)
        {
            CartDAOManager.CopyCarts(cartIDs, folderId, UserId, null, cartCopyType, copyESP);

            this.NotifyCartsChanged(cartIDs);
        }

        internal int MergeCarts(string cartIdMerged, List<string> cartIdSelected, List<string> cartIdDeleted, List<CartAccount> targetCartAccounts, out string PermissionViolationMessage, out string ErrorMessage)
        {
            int retVal = CartDAOManager.MergeCarts(cartIdMerged, cartIdSelected, cartIdDeleted, targetCartAccounts, this.UserId, out PermissionViolationMessage, out ErrorMessage);

            if (retVal == 1)
            {
                
            }
            else if (retVal == 2)
            {
                var notifyCartIDs = new List<string>();
                notifyCartIDs.AddRange(cartIdSelected);
                notifyCartIDs.AddRange(cartIdDeleted);
                notifyCartIDs.Add(cartIdMerged);
                this.NotifyCartsChanged(notifyCartIDs);

                this.WcfServiceCalculatePrice(cartIdMerged);
            }

            return retVal;
        }

        internal void MoveCartsToFolder(List<string> cartId, string destinationFolderId)
        {
            CartDAOManager.MoveCartsToFolder(cartId, destinationFolderId, this.UserId);

            NotifyCartsChanged(cartId);
            NotifyArchivedFolderChanged();
        }
        #endregion

        internal CartFacet GetCartFacet(string facetPath, string userId, string orgId, string folderId, string keyword, string keywordType)
        {
            return CartDAOManager.GetCartFacet(facetPath, userId, orgId, folderId, keyword, keywordType);
        }

        internal CartFacet GetCartFacetForAdmin(string facetPath, string userId, string orgId, string folderId, string keyword, string keywordType)
        {
            return CartDAOManager.GetCartFacetForAdmin(facetPath, userId, orgId, folderId, keyword, keywordType);
        }

        internal Carts GetCartsForAdmin(string facetPath, string keyword, string keywordType, int pageNumber, int pageSize, int sortBy,
            int sortDirection, string folderId, string userId, string orgId, out int totalCarts, out int totalCartsInOrg, bool applyPricing = false,
            bool calculateOcsData = true)
        {
            if (string.IsNullOrEmpty(userId) && string.IsNullOrEmpty(orgId))
                throw new CartManagerException(CartManagerException.INVALID_PARAMETERS);
            Carts cartList = CartDAOManager.GetCartsForAdmin(facetPath, keyword, keywordType, pageNumber, pageSize, sortBy, sortDirection, folderId, userId, orgId,
                                           out totalCarts, out totalCartsInOrg, calculateOcsData);
            if (cartList == null)
            {
                return null;
            }
            if (applyPricing)
            {
                var result = new Carts(userId);
                foreach (var cart in cartList)
                {
                    Cart item = cartList.GetCartById(cart.CartId, true);

                    item.IsShared = cart.IsShared;
                    item.IsPremium = cart.IsPremium;
                    item.HasPermission = cart.HasPermission;
                    item.IsTransferred = cart.IsTransferred;                    

                    if (string.IsNullOrEmpty(item.OrgId))
                        item.OrgId = orgId;
                    result.Add(item);
                }

                return result;
            }
            return cartList;
        }

        internal Carts GetCartsBySearch(string facetPath, string keyword, int pageNumber, int pageSize, int sortBy,
            int sortDirection, string folderId, string userId, string orgId, string keywordType, out int totalCarts, bool applyPricing = false,
            bool calculateOcsData = true)
        {
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.INVALID_PARAMETERS);

            var cartList = CartDAOManager.GetCartsBySearch(facetPath, keyword, pageNumber, pageSize, sortBy,
                                                           sortDirection, folderId, userId, orgId, keywordType,
                                                           out totalCarts, calculateOcsData);
            if (cartList == null)
            {
                return null;
            }

            if (applyPricing)
            {
                var result = new Carts(userId);
                foreach (var cart in cartList)
                {
                    Cart item = cartList.GetCartById(cart.CartId, true);

                    item.IsShared = cart.IsShared;
                    item.IsPremium = cart.IsPremium;
                    item.HasPermission = cart.HasPermission;
                    item.IsTransferred = cart.IsTransferred;                    

                    result.Add(item);
                }

                return result;
            }
            return cartList;
        }

        internal Cart GetCartByName(string cartName, string userId)
        {
            return CartDAOManager.GetCartByName(cartName, userId);
        }

        internal Cart GetCartByIdWithOCSData(string cartId)
        {
            var cart = CartDAOManager.GetCartByIdWithOCSData(cartId, this.UserId);
            if (cart != null)
            {
                CartCacheManager.AddCartToCache(cart);
            }
            return cart;
        }

        public List<Cart> GetCartsForQuickManageCarts(string sortBy, string sortDirection, int pageIndex, int pageSize, string userId, out int totalCarts)
        {
            return CartDAOManager.GetCartsForQuickManageCarts(sortBy, sortDirection, pageIndex, pageSize,userId,
                                                                        out totalCarts);
        }

        internal Cart GetCartByIdForSubmitting(string cartId)
        {
            return CartDAOManager.GetCartByIdForSubmitting(cartId, this.UserId);
        }
    }
}
