﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextgen.Grid;
using BTNextgen.Grid.Cart;
using Microsoft.SqlServer.Server;
using CartSplitResult = BT.TS360Constants.CartSplitResult;
using ESPStateType = BT.TS360Constants.ESPStateType;
using OrderStatus = BT.TS360Constants.OrderStatus;
using SplitCartMode = BT.TS360Constants.SplitCartMode;

namespace BTNextGen.CartFramework
{
    using Order;
    using Commerce.Portal.Common.Cart;
    using Commerce.Portal.Common.DataItems;
    using Commerce.Portal.Common.Helpers;
    using Commerce.Portal.Common.Logging;
    using DataConverter = Helpers.DataConverter;
    using LineItem = Order.LineItem;
    using BTNextGen.Commerce.Portal.Common.Search;
    using BTNextGen.Commerce.Portal.Common.Contracts;
    using BTNextGen.Commerce.Portal.Common.Configuration;
    using System.Net;
    using System.Web.Script.Serialization;
    using BT.TS360API.ServiceContracts.Request;
    using BT.TS360API.ServiceContracts.ILS;

    static internal partial class CartDAOManager
    {
        #region Cart Methods

        /// <summary>
        /// Get Primary Cart
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static Cart GetPrimaryCart(string userId)
        {
            Cart cart = null;
            try
            {
                var cartDS = CartDAO.Instance.GetPrimaryCart(userId);
                cart = GetCartFromDataSet(cartDS, true);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return cart;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="isPrimary"></param>
        /// <param name="folderId"></param>
        /// <param name="cartAccounts"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static Cart CreateCart(string name, bool isPrimary, string folderId, List<CartAccount> cartAccounts, string userId, string gridTemplateId, int gridOptionId, List<CommonGridTemplateLine> gridLines)
        {
            #region Input Logging
            //log input data
            var inputLogMess = String.Format("CreateCart(Name:{0}, isPrimary:{1}, FolderId:{2}, CartAccounts:, UserID:{3} ",
                                        name, isPrimary, folderId, userId);
            Logger.Write("CartDAOManager", inputLogMess, false);
            #endregion

            Cart cart = null;
            List<CartAccountSummary> cartAccountSummaries = null;
            if (cartAccounts != null)
            {
                cartAccountSummaries = GetCartAccountDictionary(cartAccounts);
            }

            try
            {
                var cartId = CartDAO.Instance.CreateCart(name, isPrimary, folderId, cartAccountSummaries, userId, gridTemplateId, gridOptionId, gridLines);

                if (String.IsNullOrEmpty(cartId))
                    throw new CartManagerException(CartManagerException.CART_CREATE_FAILED);

                cart = GetCartById(cartId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            #region Output Logging
            //log output data
            Logger.Write("CartDAOManager", cart.GetCartLogString(), false);
            #endregion

            return cart;
        }

        /// <summary>
        /// Gets Cart by Cart's ID
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        internal static Cart GetCartById(string cartId, string userId = null)
        {
            Cart cart = null;

            if (string.IsNullOrEmpty(cartId)) return null;

            try
            {
                int nonRankedCount = 0;
                var cartDs = CartDAO.Instance.GetCart(cartId, userId, out nonRankedCount);
                cart = GetCartSummaryFromDataSet(cartDs);
                cart.NonRankedCount = nonRankedCount;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return cart;
        }

        internal static Cart SetCartAsPrimary(string cartId, string userId)
        {
            Cart cart = null;
            try
            {
                var cartDS = CartDAO.Instance.SetCartAsPrimary(cartId, userId);
                cart = GetCartFromDataSet(cartDS);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return cart;
        }

        internal static Cart GetCartByIdWithOCSData(string cartId, string userId = null)
        {
            Cart cart = null;

            if (string.IsNullOrEmpty(cartId)) return null;

            try
            {
                var cartDS = CartDAO.Instance.GetCartWithOCSData(cartId, userId);

                cart = GetCartFromDataSet(cartDS);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return cart;
        }

        internal static void UpdateAccounts(List<CartAccount> cartAccounts, string cartId, string userId)
        {
            try
            {
                var accounts = GetCartAccountDictionary(cartAccounts);
                CartDAO.Instance.UpdateAccounts(accounts, cartId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void UpdateAccounts(List<CartAccountSummary> cartAccounts, string cartId, string userId)
        {
            try
            {
                CartDAO.Instance.UpdateAccounts(cartAccounts, cartId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static List<AccountSummary> GetAccountsSummary(string cartId)
        {
            List<AccountSummary> accounts = null;
            try
            {
                DataSet result = CartDAO.Instance.GetAccountsSummary(cartId);
                accounts = GetAccountsSummaryFromDataSet(result);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return accounts;
        }

        internal static CartLineFacet GetCartLineFacet(string facetPath, string cartId, string userId, string keyword, string keywordSearchBy)
        {
            CartLineFacet facet = null;
            try
            {
                DataSet result = CartDAO.Instance.GetCartLineFacet(facetPath, cartId, keyword, keywordSearchBy);
                facet = GetCartLineFacetFromDataSet(result);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return facet;
        }

        internal static List<LineItem> GetCartLines(string facetPath, string keyword, int pageNumber,
            int pageSize, int sortBy, string cartId, string userId, out int totalLines, GridFieldType gridFieldType,
            string gridText, string gridCodeId, string keywordType,
            int sortDirection = 0, bool isFindAndReplace = false, bool isFreeText = false, string[] matchingBTKeys = null, int? quantity = null)
        {
            List<LineItem> result = null;
            totalLines = 0;
            try
            {
                if (isFindAndReplace)
                {
                    var ds = CartDAO.Instance.GetCartLinesByGridFieldCode(cartId, userId, gridFieldType, gridCodeId, gridText,
                                                                          pageSize, pageNumber, sortBy, sortDirection,
                                                                          out totalLines, isFreeText, quantity);
                    result = GetCartLinesFromDataSet(ds);
                }
                else
                {
                    string searchCartLineID = string.Empty;
                    var ds = CartDAO.Instance.GetCartLines(facetPath, keyword, pageNumber, pageSize, sortBy, userId, cartId,
                                                           out totalLines, searchCartLineID, keywordType, sortDirection, matchingBTKeys);
                    result = GetCartLinesFromDataSet(ds);
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        internal static List<SearchResultInventoryStatusArg> GetInventoryArgs(
            string facetPath, string keyword, int pageNumber,
            int pageSize, int sortBy, string cartId,
            string userId, out int totalLines, string keywordType, int sortDirection = 0)
        {
            List<SearchResultInventoryStatusArg> result = null;
            totalLines = 0;
            try
            {
                var ds = CartDAO.Instance.GetCartBtKeys(facetPath, keyword, pageNumber, pageSize, sortBy, userId, cartId,
                                                           out totalLines, keywordType, sortDirection);
                result = GetCartInventoryArgListDataSet(ds);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        private static List<SearchResultInventoryStatusArg> GetCartInventoryArgListDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            var result = new List<SearchResultInventoryStatusArg>();
            foreach (DataRow dataRow in ds.Tables[0].Rows)
            {
                var item = new SearchResultInventoryStatusArg
                {
                    BTKey = DataAccessHelper.ConvertTo<string>(dataRow, "BTKey"),
                    ProductType = dataRow.Table.Columns.Contains("ProductType") ? DataAccessHelper.ConvertToString(dataRow["ProductType"]) : string.Empty
                };
                result.Add(item);
            }
            return result;
        }

        internal static LineItem GetCartLineByID(string cartLineId, string userId)
        {
            List<LineItem> result = null;

            try
            {
                var cacheKey = string.Format("__GetCartLineByID_{0}_{1}", cartLineId, userId);
                var ds = VelocityCaching.VelocityCacheManager.Read(cacheKey) as DataSet;
                if (ds == null)
                {
                    ds = CartDAO.Instance.GetCartLineById(cartLineId, userId);
                    VelocityCaching.VelocityCacheManager.Write(cacheKey, ds, CartCacheConstants.CommonCartCacheLevel);
                }

                result = GetLineItemsFromDataSet(ds);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            if (result != null && result.Count > 0)
            {
                return result[0];
            }
            return null;
        }

        internal static LineItem GetCartLineByBtKey(string btkey, string cartId)
        {
            LineItem result = null;
            try
            {
                var cacheKey = string.Format("__GetCartLineByBTKey_{0}_{1}", btkey, cartId);
                var ds = VelocityCaching.VelocityCacheManager.Read(cacheKey) as DataSet;
                if (ds == null)
                {
                    ds = CartDAO.Instance.GetCartLineByBtKey(btkey, cartId);
                    VelocityCaching.VelocityCacheManager.Write(cacheKey, ds, CartCacheConstants.CommonCartCacheLevel);
                }

                if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                    return null;
                var row = ds.Tables[0].Rows[0];
                result = new LineItem
                {
                    Id = DataAccessHelper.ConvertTo<string>(row, "BasketLineItemId"),
                    BTKey = DataAccessHelper.ConvertTo<string>(row, "BTKey"),
                    Upc = DataAccessHelper.ConvertTo<string>(row, "UPC"),
                    ISBN = DataAccessHelper.ConvertTo<string>(row, "ISBN"),
                    Quantity = DataAccessHelper.ConvertTo<int>(row, "Quantity"),
                    ProductType = DataAccessHelper.ConvertTo<string>(row, "ProductType"),
                    CatalogName = DataAccessHelper.ConvertTo<string>(row, "ProductCatalog")
                };
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return result;
        }

        internal static List<LineItem> GetCartLineByIDs(List<string> lineItemIds, string userId)
        {
            List<LineItem> result = null;

            try
            {
                var ds = CartDAO.Instance.GetCartLineByIds(lineItemIds, userId);
                result = GetLineItemsFromDataSet(ds);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            if (result != null && result.Count > 0)
            {
                return result;
            }
            return null;
        }

        internal static Cart GetCartByName(string cartName, string userId)
        {
            Cart result = null;

            try
            {
                var ds = CartDAO.Instance.GetCartByName(cartName, userId);
                result = GetCartFromDataSet(ds);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return result;
        }

        internal static bool IsZeroQuantityExisted(string cartId, string userId)
        {
            try
            {
                return CartDAO.Instance.IsZeroQuantityExisted(cartId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return false;
        }

        public static List<OrderForm> SearchOrders(string keyword, string sortBy, string sortDirection, int pageIndex, int pageSize,
            OrderStatus orderStatus, char searchOrderType, out int totalOrderCount, out int totalCarts)
        {
            List<OrderForm> result = null;
            totalOrderCount = 0;
            totalCarts = 0;
            try
            {
                var ds = CartDAO.Instance.SearchOrders(keyword, sortBy, sortDirection, pageIndex, pageSize, orderStatus, searchOrderType,
                    out totalOrderCount, out totalCarts);
                result = GetOrderFormFromDataSet(ds, orderStatus);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            if (result != null && result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public static List<OrderForm> ViewOrderQueue(string cartId, out int totalOrderCount, out int totalCarts)
        {
            List<OrderForm> result = null;
            totalOrderCount = 0;
            totalCarts = 0;
            try
            {
                var ds = CartDAO.Instance.ViewOrdersQueue(cartId, out totalOrderCount, out totalCarts);
                result = GetOrderFormFromDataSetForViewOrderQueue(ds);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            if (result != null && result.Count > 0)
            {
                return result;
            }
            return null;
        }

        private static List<OrderForm> GetOrderFormFromDataSet(DataSet ds, OrderStatus orderStatus)
        {
            if (ds == null ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var results = new List<OrderForm>();
            var orderRows = ds.Tables[0].Rows;

            foreach (DataRow orderRow in orderRows)
            {
                results.Add(GetOrderFormFromDataRow(orderRow, orderStatus));
            }
            return results;
        }

        private static List<OrderForm> GetOrderFormFromDataSetForViewOrderQueue(DataSet ds)
        {
            if (ds == null ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var results = new List<OrderForm>();
            var orderRows = ds.Tables[0].Rows;

            foreach (DataRow orderRow in orderRows)
            {
                results.Add(GetOrderFormFromDataRowForViewOrderQueue(orderRow));
            }
            return results;
        }

        private static OrderForm GetOrderFormFromDataRowForViewOrderQueue(DataRow orderRow)
        {
            var strCartId = DataAccessHelper.ConvertToString(orderRow["BasketSummaryID"]);

            if (String.IsNullOrEmpty(strCartId))
                return null;

            var submittedDateTime = new DateTime();
            if (orderRow.Table.Columns.Contains("SubmitDateTime"))
            {
                var temp = DataAccessHelper.ConvertToDateTime(orderRow["SubmitDateTime"]);
                submittedDateTime = temp.HasValue ? temp.Value : new DateTime();
            }

            var orderForm = new OrderForm
            {
                CartName = DataConverter.ConvertTo<string>(orderRow, "BasketName"),
                CartStatus = DataConverter.ConvertTo<string>(orderRow, "BasketStatus"),
                OrderType = DataConverter.ConvertTo<string>(orderRow, "OrderType"),
                SubmittedDatetime = submittedDateTime,
                LastUpdated = submittedDateTime,
                PoNumber = DataConverter.ConvertTo<string>(orderRow, "PONumber"),
                ErpAccount = DataConverter.ConvertTo<string>(orderRow, "ERPAccount"),
                TransmisisonNumber = DataConverter.ConvertTo<int>(orderRow, "TransmissionNumber"),
                CartOwnersUserName = DataConverter.ConvertTo<string>(orderRow, "CartOwnersUserName"),
                CartOrganization = DataConverter.ConvertTo<string>(orderRow, "Organization"),
                OrderNumber = DataConverter.ConvertTo<string>(orderRow, "OrderNumber"),
                CartId = orderRow["BasketSummaryId"].ToString(),
                OrderFormId = DataConverter.ConvertTo<string>(orderRow, "BasketOrderFormID"),
                OrderStatusStringForUi = DataConverter.ConvertTo<string>(orderRow, "OrderFormStatus"),
                BasketOrderFormStateId = orderRow["BasketOrderFormStateId"].ToString()
            };

            return orderForm;
        }


        /*internal static ESPRankDetailInfo GetESPRankItemDetailsByID(string lineItemID)
        {
            ESPRankDetailInfo rankDetail = null;

            if (string.IsNullOrEmpty(lineItemID)) return null;

            try
            {
                var rankDS = CartDAO.Instance.GetESPRankItemDetails(lineItemID);

                rankDetail = GetESPRankDetail(rankDS);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return rankDetail;
        }*/

        internal static TransferredCartInfo GetTransferredCartDetailByID(string cartId)
        {
            var r = GetTransferredCartDetailByID(new List<string>() { cartId });
            return r.FirstOrDefault();
        }

        //internal static TransferredCartInfo GetTransferredCartDetailByID(string cartId)
        internal static List<TransferredCartInfo> GetTransferredCartDetailByID(List<string> cartIDs)
        {
            List<TransferredCartInfo> TransferDetail = new List<TransferredCartInfo>();
            //TransferredCartInfo TransferDetail = null;

            //if (string.IsNullOrEmpty(cartId)) return null;
            if (cartIDs == null || cartIDs.Count == 0) return TransferDetail;

            try
            {
                //var transferDetailDS = CartDAO.Instance.GetTransferDetail(cartId);
                var transferDetailDS = CartDAO.Instance.GetTransferDetail(cartIDs);

                TransferDetail = GetTransferDetailFromDataSet(transferDetailDS);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return TransferDetail;
        }

        internal static List<List<string>> GetESPInvalidCodesForPopup(string cartId)
        {
            var ESPInvalidCodesList = new List<List<string>>();
            if (string.IsNullOrEmpty(cartId)) return ESPInvalidCodesList;

            try
            {
                var ESPInvalidCodesDS = CartDAO.Instance.GetESPInvalidCodesForPopup(cartId);
                ESPInvalidCodesList = GetESPInvalidCodesFromDataSet(ESPInvalidCodesDS);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }


            return ESPInvalidCodesList;
        }
        #endregion

        #region Carts methods
        /// <summary>
        /// Gets carts in specified folder
        /// </summary>
        /// <param name="folderId"></param>
        /// <returns></returns>
        internal static Carts GetCarts(string folderId)
        {
            Carts carts = null;

            try
            {
                var cartsDs = CartDAO.Instance.GetCarts(folderId);
                carts = GetCartsFromDataSet(cartsDs);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        internal static List<Cart> GetCartsLite(string folderId, out int totalCarts)
        {
            totalCarts = 0;
            try
            {
                var cartsDs = CartDAO.Instance.GetCartsLite(folderId, out totalCarts);
                return GetCartsFromDataSetLite(cartsDs);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return null;
        }



        /// <summary>
        /// Gets top newest carts
        /// </summary>
        /// <param name="topCarts"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static Carts GetTopNewestCarts(int topCarts, string userId)
        {
            var carts = new Carts(userId);

            try
            {
                var ds = CartDAO.Instance.GetCarts(topCarts, userId);

                if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                    return null;

                foreach (DataRow cartRow in ds.Tables[0].Rows)
                {
                    var cart = GetCartFromDataRowForTopNewest(cartRow, userId);

                    if (cart != null)
                    {
                        carts.Add(cart);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        internal static Carts GetActiveRecentCarts(int topCarts, string userId)
        {
            Carts carts = null;

            try
            {
                var cartsDS = CartDAO.Instance.GetActiveRecentCarts(topCarts, userId);
                carts = GetCartsFromDataSet(cartsDS);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        internal static Carts GetCartsForAdmin(string facetPath, string keyword, string keywordType, int pageNumber, int pageSize,
            int sortBy, int sortDirection, string folderId, string userId, string orgId, out int totalCart, out int totalCartsInOrg,
            bool calculateOcsData = true)
        {
            Carts carts = null;
            totalCart = 0;
            totalCartsInOrg = 0;

            try
            {
                var cartsDs = CartDAO.Instance.GetCartsForAdmin(facetPath, keyword, keywordType, pageNumber, (byte)pageSize, sortBy, sortDirection,
                    userId, orgId, folderId, out totalCart, out totalCartsInOrg, calculateOcsData);

                carts = GetCartsFromDataSet(cartsDs);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        internal static Carts GetCartsBySearch(string facetPath, string keyword, int pageNumber, int pageSize,
            int sortBy, int sortDirection, string folderId, string userId, string orgId, string keywordType, out int totalCart,
            bool calculateOcsData = true)
        {
            Carts carts = null;
            totalCart = 0;

            try
            {
                var cartsDs = CartDAO.Instance.GetCartsBySearch(facetPath, keyword, pageNumber, (byte)pageSize, sortBy, sortDirection,
                                                                userId, orgId, folderId, keywordType, out totalCart,
                                                                calculateOcsData);

                carts = GetCartsFromDataSet(cartsDs);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        internal static Carts GetAllCartsForUser(int pageNumber, int pageSize, int sortBy, string sortDirection, string userId)
        {
            Carts carts = null;

            try
            {
                var ds = CartDAO.Instance.GetAllCartsForUser(pageNumber, (byte)pageSize, sortBy, sortDirection, userId);

                carts = GetCartsFromFlatCartViewDataSet(ds, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        private static Carts GetCartsFromFlatCartViewDataSet(DataSet ds, string ownerId)
        {
            //Throw exception if no data returned from DAO
            if (ds == null ||
                ds.Tables.Count == 0 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var cartList = new List<Cart>();

            foreach (DataRow cartRow in ds.Tables[0].Rows)
            {
                var cart = GetCartFromFlatCartViewDataRow(cartRow, ownerId);

                if (cart != null)
                {
                    cartList.Add(cart);
                }
            }

            var carts = new Carts(ownerId);
            carts.AddRange(cartList);

            return carts;
        }

        private static Cart GetCartFromFlatCartViewDataRow(DataRow flatRow, string ownerId)
        {
            var strCartId = DataAccessHelper.ConvertToString(flatRow["BasketSummaryID"]);
            if (String.IsNullOrEmpty(strCartId))
                return null;

            var gridOptionId = DataAccessHelper.ConvertToInt(flatRow["GridDistributionOptionID"]);
            if (gridOptionId == 0) gridOptionId = 1;
            var cart = new Cart(strCartId, ownerId)
            {
                CartName = DataConverter.ConvertTo<string>(flatRow, "BasketName"),
                CartOwnerId = ownerId,
                BTStatus = DataAccessHelper.ConvertCartStatus(flatRow["BasketStatus"]),
                CartFolderID = DataAccessHelper.ConvertToString(flatRow["FolderID"]),
                IsArchived = DataAccessHelper.ConvertToBool(flatRow["IsArchived"]),
                IsBtCart = DataAccessHelper.ConvertToBool(flatRow["IsBtCart"]),
                IsPrimary = DataAccessHelper.ConvertToBool(flatRow["IsPrimary"]),
                IsShared = DataAccessHelper.ConvertToBool(flatRow["IsShared"]),
                IsPremium = DataAccessHelper.ConvertToBool(flatRow["IsPremium"]),
                HasPermission = DataAccessHelper.ConvertToBool(flatRow["HasPermission"]),
                HasContribution = DataAccessHelper.ConvertToBool(flatRow["HasContribution"]),
                HasReview = DataAccessHelper.ConvertToBool(flatRow["HasReview"]),
                HasAcquisition = DataAccessHelper.ConvertToBool(flatRow["HasAcquisition"]),
                IsActive = flatRow.Table.Columns.Contains("IsBasketActive") && DataAccessHelper.ConvertToBool(flatRow["IsBasketActive"]),
                GridDistributionOption = gridOptionId,
                LineItemCount = DataAccessHelper.ConvertToInt(flatRow["TotalOrderLineCount"]),
                TotalQuantity = DataAccessHelper.ConvertToInt(flatRow["TotalOrderQuantity"]),
                CartTotalListPrice = DataAccessHelper.ConvertTodecimal(flatRow["TotalListPrice"]),
                CartTotalNetPrice = DataAccessHelper.ConvertTodecimal(flatRow["TotalNetPrice"]),
                CartFolderName = DataAccessHelper.ConvertToString(flatRow["UserFolderLiteral"])
            };

            return cart;
        }

        internal static void DeleteCarts(List<string> cartIDs, string userId)
        {
            try
            {
                CartDAO.Instance.DeleteCarts(cartIDs, userId);
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360DeleteBaskets:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }
        }

        internal static void ArchiveCarts(List<string> cartIDs, string userId)
        {
            try
            {
                CartDAO.Instance.ArchiveCarts(cartIDs, userId);
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360ArchiveBaskets:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }
        }

        internal static void RestoreCarts(List<string> cartIDs, string toFolder, string userId)
        {
            try
            {
                CartDAO.Instance.RestoreCarts(cartIDs, toFolder, userId);
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360RestoreBaskets:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }
        }

        internal static void CopyCarts(List<string> cartIDs, string folderId, string userId, string newCartName = null,
            CartCopyType cartCopyType = CartCopyType.NoChoose, bool copyESP = true)
        {
            try
            {
                CartDAO.Instance.CopyCarts(cartIDs, folderId, userId, newCartName, cartCopyType, copyESP);
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360CopyBaskets:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }
        }

        internal static int MergeCarts(string cartIdMerged, List<string> cartIdSelected, List<string> cartIdDeleted, List<CartAccount> targetCartAccounts, string userId, out string PermissionViolationMessage, out string ErrorMessage)
        {
            var retVal = 0;
            PermissionViolationMessage = "";
            ErrorMessage = "";
            try
            {
                retVal = CartDAO.Instance.MergeCarts(cartIdMerged, cartIdSelected, cartIdDeleted, GetCartAccountDictionary(targetCartAccounts), userId, out PermissionViolationMessage, out ErrorMessage);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return retVal;
        }

        internal static void MoveCartsToFolder(List<string> cartId, string destinationFolderId, string userId)
        {
            try
            {
                CartDAO.Instance.MoveCartsToFolder(cartId, destinationFolderId, userId);
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360MoveBaskets:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }
        }

        internal static List<LineItem> DownloadExport(string cartId, string userId, bool isChangeStatus, string orderedDownloadedUserId, int sortBy = 0, string sortDirection = "asc")
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            List<LineItem> lineItems = null;
            try
            {
                if (isChangeStatus)
                {
                    CartDAO.Instance.SetCartStatusDownloaded(cartId, userId, orderedDownloadedUserId);
                }
                var sortOrder = GetSortOrder(sortDirection);
                int totalItems;
                DataSet result = CartDAO.Instance.GetCartLinesWithTitle(cartId, userId, sortBy, out totalItems, sortOrder);
                lineItems = GetLineItemsFromDataSet(result);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return lineItems;
        }

        internal static List<LineItem> GetTitles(string cartId, string userId, int sortBy = 0, string sortDirection = "asc")
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            List<LineItem> lineItems = null;
            try
            {
                var sortOrder = GetSortOrder(sortDirection);
                int totalItems;
                DataSet result = CartDAO.Instance.GetCartLinesWithTitle(cartId, userId, sortBy, out totalItems, sortOrder);
                lineItems = GetLineItemsFromDataSet(result);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return lineItems;
        }

        internal static void SetCartStatusDownloaded(string cartId, string userId, string orderedDownloadedUserId)
        {
            CartDAO.Instance.SetCartStatusDownloaded(cartId, userId, orderedDownloadedUserId);
        }

        internal static List<LineItem> GetLineItemForPrint(string cartId, string userId, int sortBy, string sortDirection)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            List<LineItem> lineItems = null;
            try
            {
                int totalItems = 0;
                var sortOrder = GetSortOrder(sortDirection);
                DataSet result = CartDAO.Instance.GetCartLinesWithTitle(cartId, userId, sortBy, out totalItems, sortOrder);
                lineItems = GetLineItemsWithEspRankingsFromDataSet(result);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return lineItems;
        }

        private static SortOrder GetSortOrder(string sortDirection)
        {
            var sortOrder = SortOrder.Ascending;
            if (string.Compare(sortDirection, "desc", StringComparison.OrdinalIgnoreCase) == 0)
            {
                sortOrder = SortOrder.Descending;
            }
            return sortOrder;
        }

        internal static List<LineItem> GetLineItemIDs(string cartId)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            List<LineItem> lineItems = null;
            try
            {
                DataSet result = CartDAO.Instance.GetCartLineItemIDs(cartId);
                lineItems = GetLineItemIDsFromDataSet(result);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return lineItems;
        }
        private static List<LineItem> GetLineItemIDsFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var result = new List<LineItem>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var item = new LineItem
                {
                    Id = DataAccessHelper.ConvertTo<string>(row, "BasketLineItemId"),
                    BTKey = DataAccessHelper.ConvertTo<string>(row, "BTKey")
                };
                result.Add(item);
            }

            return result;
        }
        internal static void RenameCart(string cartId, string userId, string newCartName)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            try
            {
                CartDAO.Instance.RenameCart(cartId, newCartName, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void UpdateCartNote(string cartId, string userId, string note)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            try
            {
                CartDAO.Instance.UpdateCartNote(cartId, userId, note);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }
        internal static void UpdateCartSpecialInstructions(string cartId, string userId, string specialInstructions)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            try
            {
                CartDAO.Instance.UpdateCartSpecialInstruction(cartId, userId, specialInstructions);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static CartFacet GetCartFacet(string facetPath, string userId, string orgId, string folderId, string keyword, string keywordType)
        {
            if (string.IsNullOrEmpty(orgId) && string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.INVALID_PARAMETERS);

            DataSet ds = null;
            try
            {
                ds = CartDAO.Instance.GetCartFacet(facetPath, userId, orgId, folderId, keyword, keywordType);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return GetCartFacetFromDataSet(ds);
        }

        internal static CartFacet GetCartFacetForAdmin(string facetPath, string userId, string orgId, string folderId, string keyword, string keywordType)
        {
            if (string.IsNullOrEmpty(orgId) && string.IsNullOrEmpty(userId))
                throw new CartManagerException(CartManagerException.INVALID_PARAMETERS);
            DataSet ds = null;
            try
            {
                ds = CartDAO.Instance.GetCartFacetForAdmin(facetPath, userId, orgId, folderId, keyword, keywordType);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return GetCartFacetFromDataSet(ds);
        }

        internal static Dictionary<string, int> GetQuantitiesByBtKeys(string cartId, string userId, List<string> btKeys)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            var retDict = new Dictionary<string, int>();
            try
            {
                var ds = CartDAO.Instance.GetQuantitiesByBtKeys(cartId, userId, btKeys);
                if (ds != null && ds.Tables.Count > 0)
                {
                    var table = ds.Tables[0];

                    foreach (DataRow row in table.Rows)
                    {
                        var btkey = DataConverter.ConvertTo<string>(row, "BTKey");
                        var quantity = DataConverter.ConvertTo<int>(row, "Quantity");
                        if (!retDict.ContainsKey(btkey))
                        {
                            retDict.Add(btkey, quantity);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return retDict;
        }

        internal static List<List<string>> CheckBasketForTitles(string cartId, List<string> btKeys, List<string> lineItemIds, out int newLineCount, out int existingLineCount)
        {
            if (string.IsNullOrEmpty(cartId))
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            var retList = new List<List<string>>();
            newLineCount = 0;
            existingLineCount = 0;
            try
            {
                var ds = CartDAO.Instance.CheckBasketForTitles(cartId, btKeys, lineItemIds, out newLineCount, out existingLineCount);
                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        var tableNewLine = ds.Tables[0];
                        var newList =
                            (from DataRow row in tableNewLine.Rows select DataConverter.ConvertTo<string>(row, "NewBTKey"))
                                .ToList();
                        retList.Add(newList);
                    }
                    if (ds.Tables.Count > 1)
                    {
                        var tableExistingLine = ds.Tables[1];
                        var existingList =
                            (from DataRow row in tableExistingLine.Rows
                             select DataConverter.ConvertTo<string>(row, "ExistingBTKey")).ToList();
                        retList.Add(existingList);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return retList;
        }

        internal static void SetOneClickMARCStatus(string cartID, string oneClickMARCStatus)
        {
            try
            {
                CartDAO.Instance.SetOneClickMARCStatus(cartID, oneClickMARCStatus);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

        }

        internal static int SetQuantities(List<string> cartIDs, List<string> lineItemIDs, int massQuantity, string userID,
            int maxLineLimit, out int numberOfCarts, out int numberOfLineItems, out string errorMessage)
        {
            var result = 0;
            numberOfCarts = 0;
            numberOfLineItems = 0;
            errorMessage = string.Empty;
            try
            {
                result = CartDAO.Instance.SetQuantities(cartIDs, lineItemIDs, massQuantity, userID,
                    maxLineLimit, out numberOfCarts, out numberOfLineItems, out errorMessage);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
                return 2;
            }
            return result;
        }

        #endregion

        #region Utilitiy methods

        private static Cart GetCartFromDataRowForTopNewest(DataRow row, string userId)
        {
            var strCartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);

            if (String.IsNullOrEmpty(strCartId))
                return null;

            var cart = new Cart(strCartId, userId)
            {
                CartName = DataConverter.ConvertTo<string>(row, "BasketName"),
            };

            return cart;
        }

        private static Cart GetCartFromDataRow(DataRow row, bool isPrimaryCall = false)
        {
            var strCartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
            var strUserId = DataAccessHelper.ConvertToString(row["BasketOwnerID"]);
            var strFolderId = DataAccessHelper.ConvertToString(row["UserFolderID"]);

            if (String.IsNullOrEmpty(strCartId) || String.IsNullOrEmpty(strUserId))
                return null;

            var cartStatus = DataAccessHelper.ConvertCartStatus(row["BasketStateID"]);

            var cart = new Cart(strCartId, strUserId)
            {
                CartName = DataConverter.ConvertTo<string>(row, "BasketName"),
                CartOwnerId = DataConverter.ConvertTo<string>(row, "BasketOwnerID"),
                CartUserSharedId = DataConverter.ConvertTo<string>(row, "UserID"),
                BTStatus = cartStatus,
                CartFolderID = strFolderId,
                LineItemCount = DataAccessHelper.ConvertToInt(row["TotalOrderLineCount"]),
                CartTotalListPrice = DataAccessHelper.ConvertTodecimal(row["TotalListPrice"]),
                CartTotalNetPrice = DataAccessHelper.ConvertTodecimal(row["TotalNetPrice"]),
                ShippingTotal = DataAccessHelper.ConvertTodecimal(row["ShippingTotal"]),
                FeeTotal = DataAccessHelper.ConvertTodecimal(row["FeeTotal"]),
                Total = DataAccessHelper.ConvertTodecimal(row["Total"]),
                TotalOrderQuantity = DataAccessHelper.ConvertToInt(row["TotalOrderQuantity"]),
                TotalCancelQuantity = DataConverter.ConvertTo<int>(row, "TotalCancelQuantity"),
                TotalBackOrderQuantity = DataConverter.ConvertTo<int>(row, "TotalBackOrderQuantity"),
                TotalInProcessQuantity = DataConverter.ConvertTo<int>(row, "TotalInProcessQuantity"),
                Note = DataAccessHelper.ConvertToString(row["Note"]),
                SpecialInstruction = DataAccessHelper.ConvertToString(row["SpecialInstructions"]),
                CreatedBy = DataAccessHelper.ConvertToString(row["CreatedBy"]),
                UpdatedBy = DataAccessHelper.ConvertToString(row["UpdatedBy"]),
                CreatedDateTime = DataAccessHelper.ConvertToDateTime(row["CreatedDateTime"]),
                UpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["UpdatedDateTime"]),
                SubmittedDate = row.Table.Columns.Contains("SubmittedDate") ? DataAccessHelper.ConvertToDateTime(row["SubmittedDate"]) : null,
                NoteUpdatedBy = DataAccessHelper.ConvertToString(row["NoteUpdatedBy"]),
                NoteUpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["NoteUpdatedDateTime"]),
                SpecialInstructionsUpdatedBy = DataAccessHelper.ConvertToString(row["SpecialInstructionsUpdatedBy"]),
                SpecialInstructionsUpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["SpecialInstructionsUpdatedDateTime"]),
                TotalOELines = row.Table.Columns.Contains("TotalOELines") ? DataAccessHelper.ConvertToInt(row["TotalOELines"]) : 0,
                TotalOEQuantity = row.Table.Columns.Contains("TotalOEQuantity") ? DataAccessHelper.ConvertToInt(row["TotalOEQuantity"]) : 0,
                HasProfile = row.Table.Columns.Contains("HasProfile") && DataAccessHelper.ConvertToBool(row["HasProfile"]),
                IsShared = row.Table.Columns.Contains("IsShared") && DataAccessHelper.ConvertToBool(row["IsShared"]),
                HasGridLine = row.Table.Columns.Contains("HasGrids") && DataAccessHelper.ConvertToBool(row["HasGrids"]),
                IsPremium = row.Table.Columns.Contains("IsPremium") && DataAccessHelper.ConvertToBool(row["IsPremium"]),
                HasPermission = row.Table.Columns.Contains("HasPermission") && DataAccessHelper.ConvertToBool(row["HasPermission"]),
                CartOwnerName = DataConverter.ConvertTo<string>(row, "BasketOwnerName"),
                IsArchived = row.Table.Columns.Contains("ArchivedIndicator") && DataAccessHelper.ConvertToBool(row["ArchivedIndicator"]),
                CartFolderName = DataConverter.ConvertTo<string>(row, "FolderName"),
                TitlesWithoutGrids = row.Table.Columns.Contains("TitlesWithoutGrids") ? DataAccessHelper.ConvertToInt(row["TitlesWithoutGrids"]) : 0,
                EntertainmentHasGridLine = row.Table.Columns.Contains("EntertainmentHasGrids") && DataAccessHelper.ConvertToBool(row["EntertainmentHasGrids"]),
                WorkflowTimeZone = DataConverter.ConvertTo<string>(row, "TimeZone"),
                OneClickMARCIndicator = row.Table.Columns.Contains("OneClickMARCIndicator") && DataAccessHelper.ConvertToBool(row["OneClickMARCIndicator"]),
                FTPErrorMessage = row.Table.Columns.Contains("FTPErrorMessage") ? DataAccessHelper.ConvertToString(row["FTPErrorMessage"]) : "",
                HasOwner = row.Table.Columns.Contains("HasOwner") && DataAccessHelper.ConvertToBool(row["HasOwner"]),
                HasContribution = row.Table.Columns.Contains("HasContribution") && DataAccessHelper.ConvertToBool(row["HasContribution"]),
                HasReview = row.Table.Columns.Contains("HasReview") && DataAccessHelper.ConvertToBool(row["HasReview"]),
                HasAcquisition = row.Table.Columns.Contains("HasAquisition") && DataAccessHelper.ConvertToBool(row["HasAquisition"]),
                HasWorkflow = row.Table.Columns.Contains("HasWorkflow") && DataAccessHelper.ConvertToBool(row["HasWorkflow"]),
                HasReviewAcquisitionPermission = row.Table.Columns.Contains("HasReviewAcquisitionPermission") && DataAccessHelper.ConvertToBool(row["HasReviewAcquisitionPermission"]),
                IsMixedProduct = DataAccessHelper.ConvertToBool(row["IsMixedProduct"]),
                ESPStateTypeId = row.Table.Columns.Contains("ESPStateTypeId") ? DataAccessHelper.ConvertToInt(row["ESPStateTypeId"]) : (int)ESPStateType.None,
                HasESPRanking = row.Table.Columns.Contains("HasESPRanking") && DataAccessHelper.ConvertToBool(row["HasESPRanking"]),
                QuoteID = row.Table.Columns.Contains("QuoteID") ? DataAccessHelper.ConvertToInt(row["QuoteID"]) : 0,
                QuoteExpiredDateTime = row.Table.Columns.Contains("QuoteExpiredDateTime") ? DataAccessHelper.ConvertToDateTime(row["QuoteExpiredDateTime"]) : null,
                IsSplitting = row.Table.Columns.Contains("IsSplitting") && DataAccessHelper.ConvertToBool(row["IsSplitting"]),
                IsSharedBasketGridEnabled = row.Table.Columns.Contains("IsSharedBasketGridEnabled") && DataAccessHelper.ConvertToBool(row["IsSharedBasketGridEnabled"]),
                IsTransferred = row.Table.Columns.Contains("IsTransferred") && DataAccessHelper.ConvertToBool(row["IsTransferred"]),
                BasketProcessingCategoryID = row.Table.Columns.Contains("BasketProcessingCategoryID") ? DataAccessHelper.ConvertToInt(row["BasketProcessingCategoryID"]) : 0,
                ESPRankStateTypeId = row.Table.Columns.Contains("ESPRankStateTypeId") ? DataAccessHelper.ConvertToInt(row["ESPRankStateTypeId"]) : (int)ESPStateType.None,
                ESPDistStateTypeID = row.Table.Columns.Contains("ESPDistStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPDistStateTypeID"]) : (int)ESPStateType.None,
                ESPFundStateTypeID = row.Table.Columns.Contains("ESPFundStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPFundStateTypeID"]) : (int)ESPStateType.None,
                LastESPStateTypeLiteral = row.Table.Columns.Contains("LastESPStateType") ? DataAccessHelper.ConvertToString(row["LastESPStateType"]) : string.Empty,
                ESPJobText = row.Table.Columns.Contains("ESPJobText") ? DataAccessHelper.ConvertToString(row["ESPJobText"]) : string.Empty,
                ESPJobURL = row.Table.Columns.Contains("ESPJobURL") ? DataAccessHelper.ConvertToString(row["ESPJobURL"]) : string.Empty,
                FreezeLevel = row.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(row["BasketFrozenLevelIndicator"]) : 0,
                IsActive = row.Table.Columns.Contains("IsBasketActive") && DataAccessHelper.ConvertToBool(row["IsBasketActive"]),
                OrderedDownloadedUser = row.Table.Columns.Contains("OrderedDownloadedUser") ? DataAccessHelper.ConvertToString(row["OrderedDownloadedUser"]) : string.Empty,
                GridDistributionOption = row.Table.Columns.Contains("GridDistributionOptionID") ?
                    DataAccessHelper.ConvertToInt(row["GridDistributionOptionID"]) : -1,
                ILSStatusId = DataConverter.ConvertTo<Int64?>(row, "ILSStatusID")
            };

            cart.CurrentWorkflow = row.Table.Columns.Contains("CurrentWorkflow") ? GetCurrentWorkFlow(row["CurrentWorkflow"]) : 0;
            cart.IsPrimary = isPrimaryCall || DataAccessHelper.ConvertToBool(row["IsPrimary"]);

            cart.UserFolderTypeID = row.Table.Columns.Contains("UserFolderTypeID") ? DataAccessHelper.ConvertToInt(row["UserFolderTypeID"]) : -1;

            RefineContainsMixGridNonGridForCart(cart);

            return cart;
        }

        private static int GetCurrentWorkFlow(object p)
        {
            var valueString = p.ToString();

            if (valueString == "1" ||
                string.Compare(valueString, "Contribution", StringComparison.OrdinalIgnoreCase) == 0)
            {
                return 1;
            }
            else if (valueString == "2" ||
               string.Compare(valueString, "Requisition", StringComparison.OrdinalIgnoreCase) == 0)
            {
                return 2;
            }
            else if (valueString == "3" ||
               string.Compare(valueString, "Review", StringComparison.OrdinalIgnoreCase) == 0)
            {
                return 3;
            }
            else if (valueString == "4" ||
               string.Compare(valueString, "Acquisition", StringComparison.OrdinalIgnoreCase) == 0)
            {
                return 4;
            }
            else if (valueString == "5" ||
           string.Compare(valueString, "Closed", StringComparison.OrdinalIgnoreCase) == 0)
            {
                return 5;
            }
            else
            {
                return 0;
            }

        }
        private static Cart GetCartSummaryFromDataRow(DataRow row, bool isPrimaryCall = false)
        {
            var strCartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
            var strUserId = DataAccessHelper.ConvertToString(row["BasketOwnerID"]);
            var strFolderId = DataAccessHelper.ConvertToString(row["UserFolderID"]);

            if (String.IsNullOrEmpty(strCartId) || String.IsNullOrEmpty(strUserId))
                return null;

            var cartStatus = DataAccessHelper.ConvertCartStatus(row["BasketStateID"]);

            var cart = new Cart(strCartId, strUserId)
            {
                CartName = DataConverter.ConvertTo<string>(row, "BasketName"),
                CartOwnerId = DataConverter.ConvertTo<string>(row, "BasketOwnerID"),
                CartUserSharedId = DataConverter.ConvertTo<string>(row, "UserID"),
                BTStatus = cartStatus,
                CartFolderID = strFolderId,
                LineItemCount = DataAccessHelper.ConvertToInt(row["TotalOrderLineCount"]),
                CartTotalListPrice = DataAccessHelper.ConvertTodecimal(row["TotalListPrice"]),
                CartTotalNetPrice = DataAccessHelper.ConvertTodecimal(row["TotalNetPrice"]),
                ShippingTotal = DataAccessHelper.ConvertTodecimal(row["ShippingTotal"]),
                FeeTotal = DataAccessHelper.ConvertTodecimal(row["FeeTotal"]),
                Total = DataAccessHelper.ConvertTodecimal(row["Total"]),
                TotalOrderQuantity = DataAccessHelper.ConvertToInt(row["TotalOrderQuantity"]),
                TotalCancelQuantity = DataConverter.ConvertTo<int>(row, "TotalCancelQuantity"),
                TotalBackOrderQuantity = DataConverter.ConvertTo<int>(row, "TotalBackOrderQuantity"),
                TotalInProcessQuantity = DataConverter.ConvertTo<int>(row, "TotalInProcessQuantity"),
                Note = DataAccessHelper.ConvertToString(row["Note"]),
                SpecialInstruction = DataAccessHelper.ConvertToString(row["SpecialInstructions"]),
                CreatedBy = DataAccessHelper.ConvertToString(row["CreatedBy"]),
                UpdatedBy = DataAccessHelper.ConvertToString(row["UpdatedBy"]),
                CreatedDateTime = DataAccessHelper.ConvertToDateTime(row["CreatedDateTime"]),
                UpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["UpdatedDateTime"]),
                NoteUpdatedBy = DataAccessHelper.ConvertToString(row["NoteUpdatedBy"]),
                NoteUpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["NoteUpdatedDateTime"]),
                SpecialInstructionsUpdatedBy = DataAccessHelper.ConvertToString(row["SpecialInstructionsUpdatedBy"]),
                SpecialInstructionsUpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["SpecialInstructionsUpdatedDateTime"]),
                TotalOELines = row.Table.Columns.Contains("TotalOELines") ? DataAccessHelper.ConvertToInt(row["TotalOELines"]) : 0,
                TotalOEQuantity = row.Table.Columns.Contains("TotalOEQuantity") ? DataAccessHelper.ConvertToInt(row["TotalOEQuantity"]) : 0,
                HasProfile = row.Table.Columns.Contains("HasProfile") && DataAccessHelper.ConvertToBool(row["HasProfile"]),
                IsShared = row.Table.Columns.Contains("IsShared") && DataAccessHelper.ConvertToBool(row["IsShared"]),
                HasGridLine = row.Table.Columns.Contains("HasGrids") && DataAccessHelper.ConvertToBool(row["HasGrids"]),
                IsPremium = row.Table.Columns.Contains("IsPremium") && DataAccessHelper.ConvertToBool(row["IsPremium"]),
                HasPermission = row.Table.Columns.Contains("HasPermission") && DataAccessHelper.ConvertToBool(row["HasPermission"]),
                CartOwnerName = DataConverter.ConvertTo<string>(row, "BasketOwnerName"),
                IsArchived = row.Table.Columns.Contains("ArchivedIndicator") && DataAccessHelper.ConvertToBool(row["ArchivedIndicator"]),
                CartFolderName = DataConverter.ConvertTo<string>(row, "FolderName"),
                TitlesWithoutGrids = row.Table.Columns.Contains("TitlesWithoutGrids") ? DataAccessHelper.ConvertToInt(row["TitlesWithoutGrids"]) : 0,
                EntertainmentHasGridLine = row.Table.Columns.Contains("EntertainmentHasGrids") && DataAccessHelper.ConvertToBool(row["EntertainmentHasGrids"]),
                WorkflowTimeZone = DataConverter.ConvertTo<string>(row, "TimeZone"),
                OneClickMARCIndicator = row.Table.Columns.Contains("OneClickMARCIndicator") && DataAccessHelper.ConvertToBool(row["OneClickMARCIndicator"]),
                FTPErrorMessage = row.Table.Columns.Contains("FTPErrorMessage") ? DataAccessHelper.ConvertToString(row["FTPErrorMessage"]) : "",
                HasOwner = row.Table.Columns.Contains("HasOwner") && DataAccessHelper.ConvertToBool(row["HasOwner"]),
                HasContribution = row.Table.Columns.Contains("HasContribution") && DataAccessHelper.ConvertToBool(row["HasContribution"]),
                HasReview = row.Table.Columns.Contains("HasReview") && DataAccessHelper.ConvertToBool(row["HasReview"]),
                HasAcquisition = row.Table.Columns.Contains("HasAquisition") && DataAccessHelper.ConvertToBool(row["HasAquisition"]),
                HasWorkflow = row.Table.Columns.Contains("HasWorkflow") && DataAccessHelper.ConvertToBool(row["HasWorkflow"]),
                HasReviewAcquisitionPermission = row.Table.Columns.Contains("HasReviewAcquisitionPermission") && DataAccessHelper.ConvertToBool(row["HasReviewAcquisitionPermission"]),
                IsMixedProduct = DataAccessHelper.ConvertToBool(row["IsMixedProduct"]),
                ESPStateTypeId = row.Table.Columns.Contains("ESPStateTypeId") ? DataAccessHelper.ConvertToInt(row["ESPStateTypeId"]) : (int)ESPStateType.None,
                SubmittedDate = row.Table.Columns.Contains("SubmittedDate") ? DataAccessHelper.ConvertToDateTime(row["SubmittedDate"]) : null,
                HasESPRanking = row.Table.Columns.Contains("HasESPRanking") && DataAccessHelper.ConvertToBool(row["HasESPRanking"]),
                QuoteID = row.Table.Columns.Contains("QuoteID") ? DataAccessHelper.ConvertToInt(row["QuoteID"]) : 0,
                QuoteExpiredDateTime = row.Table.Columns.Contains("QuoteExpiredDateTime") ? DataAccessHelper.ConvertToDateTime(row["QuoteExpiredDateTime"]) : null,
                IsSplitting = row.Table.Columns.Contains("IsSplitting") && DataAccessHelper.ConvertToBool(row["IsSplitting"]),
                IsSharedBasketGridEnabled = row.Table.Columns.Contains("IsSharedBasketGridEnabled") && DataAccessHelper.ConvertToBool(row["IsSharedBasketGridEnabled"]),
                IsActive = row.Table.Columns.Contains("IsBasketActive") && DataAccessHelper.ConvertToBool(row["IsBasketActive"]),
                BasketProcessingCategoryID = row.Table.Columns.Contains("BasketProcessingCategoryID") ? DataAccessHelper.ConvertToInt(row["BasketProcessingCategoryID"]) : 0,
                ESPRankStateTypeId = row.Table.Columns.Contains("ESPRankStateTypeId") ? DataAccessHelper.ConvertToInt(row["ESPRankStateTypeId"]) : (int)ESPStateType.None,
                ESPDistStateTypeID = row.Table.Columns.Contains("ESPDistStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPDistStateTypeID"]) : (int)ESPStateType.None,
                ESPFundStateTypeID = row.Table.Columns.Contains("ESPFundStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPFundStateTypeID"]) : (int)ESPStateType.None,
                LastESPStateTypeLiteral = row.Table.Columns.Contains("LastESPStateType") ? DataAccessHelper.ConvertToString(row["LastESPStateType"]) : string.Empty,
                ESPJobText = row.Table.Columns.Contains("ESPJobText") ? DataAccessHelper.ConvertToString(row["ESPJobText"]) : string.Empty,
                ESPJobURL = row.Table.Columns.Contains("ESPJobURL") ? DataAccessHelper.ConvertToString(row["ESPJobURL"]) : string.Empty,
                FreezeLevel = row.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(row["BasketFrozenLevelIndicator"]) : 0,
                OrderedDownloadedUser = DataConverter.ConvertTo<string>(row, "OrderedDownloadedUser"),
                GridDistributionOption = DataAccessHelper.ConvertToInt(row["GridDistributionOptionID"]),
                ILSStatusId = DataConverter.ConvertTo<Int64?>(row, "ILSStatusID")
            };

            cart.CurrentWorkflow = row.Table.Columns.Contains("CurrentWorkflow") ? GetCurrentWorkFlow(row["CurrentWorkflow"]) : 0;
            cart.IsPrimary = isPrimaryCall || DataAccessHelper.ConvertToBool(row["IsPrimary"]);

            RefineContainsMixGridNonGridForCart(cart);

            return cart;
        }

        private static void RefineContainsMixGridNonGridForCart(Cart cart)
        {
            cart.ContainsAMixOfGridNNonGrid = cart.HasGridLine && cart.TitlesWithoutGrids > 0 && cart.LineItemCount != cart.TitlesWithoutGrids;
        }

        private static OrderForm GetOrderFormFromDataRow(DataRow row, OrderStatus orderStatus)
        {
            var strCartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
            //var strUserId = DataAccessHelper.ConvertToString(row["CartOwnersLoginID"]); <== Store return NOthing

            if (String.IsNullOrEmpty(strCartId))
                return null;

            var submittedDateTime = new DateTime();
            if (row.Table.Columns.Contains("SubmitDateTime"))
            {
                var temp = DataAccessHelper.ConvertToDateTime(row["SubmitDateTime"]);
                submittedDateTime = temp.HasValue ? temp.Value : new DateTime();
            }

            var orderForm = new OrderForm
            {
                CartName = DataConverter.ConvertTo<string>(row, "BasketName"),
                OrderType = DataConverter.ConvertTo<string>(row, "OrderType"),
                SubmittedDatetime = submittedDateTime,
                PoNumber = DataConverter.ConvertTo<string>(row, "PONumber"),
                ErpAccount = DataConverter.ConvertTo<string>(row, "ERPAccount"),
                TransmisisonNumber = DataConverter.ConvertTo<int>(row, "TransmissionNumber"),
                CartOwnersUserName = DataConverter.ConvertTo<string>(row, "CartOwnersUserName"),
                CartOrganization = DataConverter.ConvertTo<string>(row, "Organization"),
                OrderNumber = DataConverter.ConvertTo<string>(row, "OrderNumber"),
                CartId = row["BasketSummaryId"].ToString(),
                OrderFormId = DataConverter.ConvertTo<string>(row, "BasketOrderFormID"),
                OrderStatus = orderStatus,
                CartOwnerUserId = DataConverter.ConvertTo<string>(row, "CartOwnerUserID"),
                CartOwnerOrgId = DataConverter.ConvertTo<string>(row, "CartOwnerOrgID"),
            };

            return orderForm;
        }

        private static OrderStatus GetOrderStatus(int orderStatus)
        {
            switch (orderStatus)
            {
                case 0:
                    return OrderStatus.Submitted;
                case 1:
                    return OrderStatus.Ordered;
                default:
                    return OrderStatus.All;
            }
        }

        private static CartAccount GetCartAccountFromDataRow(DataRow row)
        {
            var strAccountId = DataAccessHelper.ConvertToString(row["AccountID"]);
            var strBasketSummaryId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);

            if (String.IsNullOrEmpty(strAccountId) || String.IsNullOrEmpty(strBasketSummaryId))
                return null;

            var cartAcc = new CartAccount()
            {
                AccountID = strAccountId,
                AccountType = DataConverter.GetOldAccountTypeID(DataAccessHelper.ConvertToInt(row["BasketAccountTypeID"])),
                ESupplierID = DataAccessHelper.ConvertToString(row["ESupplierID"]),
                AccountERPNumber = DataAccessHelper.ConvertToString(row["AccountERPNumber"]),
                PONumber = DataAccessHelper.ConvertToString(row["PONumber"]),
                BasketSummaryID = strBasketSummaryId,
                ERPAccountGUID = DataAccessHelper.ConvertToString(row["ERPAccountGUID"]),
                AccountAlias = DataAccessHelper.ConvertToString(row["AccountAlias"]),
                IsHomeDelivery = row.Table.Columns.Contains("IsHomeDelivery") && DataAccessHelper.ConvertToBool(row["IsHomeDelivery"]),
                NumberOfBuilding = GetNumberOfBuilding(row["NumberOfBuilding"]),
                ProcessingCharge = DataAccessHelper.ConvertTodecimal(row["ProcessingCharges"]),
            };

            return cartAcc;
        }

        private static int GetNumberOfBuilding(object obj)
        {
            int returnValue = 1;
            if (null != obj)
            {
                Int32.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        internal static Cart GetCartFromDataSet(DataSet ds, bool isPrimaryCall = false)
        {
            if (ds == null || ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count == 0)
                return null;

            //Primary Cart information
            var cartInfoRow = ds.Tables[0].Rows[0];

            var cart = GetCartFromDataRow(cartInfoRow, isPrimaryCall);

            if (cart != null)
            {
                if (ds.Tables.Count == 2)
                {
                    //Accounts
                    foreach (DataRow accountRow in ds.Tables[1].Rows)
                    {
                        var cartAccount = GetCartAccountFromDataRow(accountRow);

                        if (cartAccount != null)
                            cart.CartAccounts.Add(cartAccount);
                    }
                }
            }

            return cart;
        }
        private static Cart GetCartSummaryFromDataSet(DataSet ds, bool isPrimaryCall = false)
        {
            if (ds == null ||
                ds.Tables.Count < 2 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            //Primary Cart information
            var cartInfoRow = ds.Tables[0].Rows[0];

            var cart = GetCartSummaryFromDataRow(cartInfoRow, isPrimaryCall);

            if (cart != null)
            {
                //Accounts
                foreach (DataRow accountRow in ds.Tables[1].Rows)
                {
                    var cartAccount = GetCartAccountFromDataRow(accountRow);

                    if (cartAccount != null)
                        cart.CartAccounts.Add(cartAccount);
                }
            }

            return cart;
        }

        private static Carts GetCartsFromDataSet(DataSet ds)
        {
            //Throw exception if no data returned from DAO
            if (ds == null ||
                ds.Tables.Count == 0 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var cartList = new List<Cart>();//new Dictionary<string, Cart>();
            var strUserid = "";

            foreach (DataRow cartRow in ds.Tables[0].Rows)
            {
                var cart = GetCartFromDataRow(cartRow);

                if (cart != null)
                {
                    //if (!cartList.ContainsKey(cart.CartId))
                    //    cartList.Add(cart.CartId, cart);
                    //else
                    cartList.Add(cart);

                    if (String.IsNullOrEmpty(strUserid))
                        strUserid = cart.UserId;
                }
            }

            if (ds.Tables.Count > 1)
            {
                foreach (DataRow accRow in ds.Tables[1].Rows)
                {
                    // temp AddToCart -> cover code by try catch
                    try
                    {
                        var account = GetCartAccountFromDataRow(accRow);

                        if (account != null)
                        {
                            foreach (var cart in cartList.Where(cart => cart.CartId == account.BasketSummaryID))
                            {
                                cart.CartAccounts.Add(account);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.LogException(ex);
                    }
                }
            }

            var carts = new Carts(strUserid);
            carts.AddRange(cartList);

            return carts;
        }

        private static List<Cart> GetCartsFromDataSetLite(DataSet ds)
        {
            //Throw exception if no data returned from DAO
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var cartList = new List<Cart>();

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var strCartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
                if (String.IsNullOrEmpty(strCartId))
                    continue;

                var gridOptionId = DataAccessHelper.ConvertToInt(row["GridDistributionOptionID"]);
                if (gridOptionId == 0) gridOptionId = 1;

                var cart = new Cart(strCartId, string.Empty)
                {
                    CartName = DataConverter.ConvertTo<string>(row, "BasketName"),
                    BTStatus = DataAccessHelper.ConvertCartStatus(row["BasketStateID"]),
                    CartFolderID = DataAccessHelper.ConvertToString(row["UserFolderID"]),
                    IsShared = row.Table.Columns.Contains("IsShared") && DataAccessHelper.ConvertToBool(row["IsShared"]),
                    IsPremium = row.Table.Columns.Contains("IsPremiumBasket") && DataAccessHelper.ConvertToBool(row["IsPremiumBasket"]),
                    IsArchived = row.Table.Columns.Contains("ArchivedIndicator") && DataAccessHelper.ConvertToBool(row["ArchivedIndicator"]),
                    IsBtCart = row.Table.Columns.Contains("IsBTBasket") && DataAccessHelper.ConvertToBool(row["IsBTBasket"]),
                    IsPrimary = row.Table.Columns.Contains("IsPrimary") && DataAccessHelper.ConvertToBool(row["IsPrimary"]),
                    IsActive = row.Table.Columns.Contains("IsBasketActive") && DataAccessHelper.ConvertToBool(row["IsBasketActive"]),
                    IsSharedBasketGridEnabled = row.Table.Columns.Contains("IsSharedBasketGridEnabled") && DataAccessHelper.ConvertToBool(row["IsSharedBasketGridEnabled"]),
                    CanDelete = row.Table.Columns.Contains("CanDeleteMoveOrRestore") && DataAccessHelper.ConvertToBool(row["CanDeleteMoveOrRestore"]),
                    CanDesignateAsPrimaryCart = row.Table.Columns.Contains("CanDesignatePrimary") && DataAccessHelper.ConvertToBool(row["CanDesignatePrimary"]),
                    HasPermission = row.Table.Columns.Contains("HasPermission") && DataAccessHelper.ConvertToBool(row["HasPermission"]),
                    FreezeLevel = row.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(row["BasketFrozenLevelIndicator"]) : 0,
                    GridDistributionOption = gridOptionId,
                    LineItemCount = DataAccessHelper.ConvertToInt(row["TotalOrderLineCount"]),
                    TotalQuantity = DataAccessHelper.ConvertToInt(row["TotalOrderQuantity"]),
                    CartTotalListPrice = DataAccessHelper.ConvertTodecimal(row["TotalListPrice"]),
                    CartTotalNetPrice = DataAccessHelper.ConvertTodecimal(row["TotalNetPrice"]),
                    CartFolderName = DataAccessHelper.ConvertToString(row["UserFolderLiteral"])
                };
                cartList.Add(cart);
            }
            return cartList;
        }

        private static List<CartAccountSummary> GetCartAccountDictionary(List<CartAccount> accounts)
        {
            if (accounts == null || accounts.Count == 0)
                return null;

            var cartAccountSummaries = new List<CartAccountSummary>();

            foreach (var cartAccount in accounts)
            {
                var cartAccountSummary = new CartAccountSummary()
                {
                    AccountID = cartAccount.AccountID,
                    BasketAccountTypeID = DataConverter.GetNewAccountTypeID(cartAccount.AccountType).ToString(),
                    PONumber = cartAccount.PONumber,
                    AccountAlias = cartAccount.AccountAlias
                };

                cartAccountSummaries.Add(cartAccountSummary);
            }

            return cartAccountSummaries;
        }

        private static List<LineItem> GetLineItemsWithEspRankingsFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var result = new List<LineItem>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var item = GetLineItemFromDataRow(row);

                // get esp rankings
                item.ESPOverallRanking = DataAccessHelper.ConvertTo<decimal?>(row, "ESPOverallRanking");
                item.ESPBisacRanking = DataAccessHelper.ConvertTo<decimal?>(row, "ESPBisacRanking");

                result.Add(item);
            }

            return result;
        }

        private static List<LineItem> GetLineItemsFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var result = new List<LineItem>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var item = GetLineItemFromDataRow(row);
                //item.PublishDate = DataAccessHelper.ConvertTo<DateTime>(row, "PublishDate");
                item.Acknowledgements = GetLineItemAckFromDataSet(ds, item.Id);
                result.Add(item);
            }

            return result;
        }

        private static LineItem GetLineItemFromDataRow(DataRow row)
        {

            var res = new LineItem
            {
                Id = DataAccessHelper.ConvertTo<string>(row, "BasketLineItemId"),
                BasketOrderFormId = DataAccessHelper.ConvertTo<string>(row, "BasketOrderFormId"),
                ISBN10 = DataAccessHelper.ConvertTo<string>(row, "ISBN10"),
                BTKey = DataAccessHelper.ConvertTo<string>(row, "BTKey"),
                Title = DataAccessHelper.ConvertTo<string>(row, "Title"),
                Author = DataAccessHelper.ConvertTo<string>(row, "Author"),
                Publisher = DataAccessHelper.ConvertTo<string>(row, "Publisher"),
                ListPrice = DataAccessHelper.ConvertTo<decimal>(row, "ListPrice"),
                ContractPrice = DataAccessHelper.ConvertTo<decimal>(row, "ContractPrice"),
                SalePrice = DataAccessHelper.ConvertTo<decimal>(row, "SalePrice"),
                ExtendedPrice = DataAccessHelper.ConvertTo<decimal>(row, "ExtendedPrice"),
                BTDiscountPercent = DataAccessHelper.ConvertTo<decimal>(row, "DiscountPercent"),
                Lccn = DataAccessHelper.ConvertTo<string>(row, "LCCN"),
                DeweyNormalized = DataAccessHelper.ConvertTo<string>(row, "DeweyNormalized"),
                DeweyNative = DataAccessHelper.ConvertTo<string>(row, "DeweyNative"),
                FormatLiteral = DataAccessHelper.ConvertTo<string>(row, "FormatLiteral"),
                Edition = DataAccessHelper.ConvertTo<string>(row, "Edition"),
                PublishDate = DataAccessHelper.ConvertToDateTimeNull(row, "PublishDate"),
                ReportCode = ReviseReportCode(DataAccessHelper.ConvertTo<string>(row, "ReportCode")),
                Subject = DataAccessHelper.ConvertTo<string>(row, "Subject"),
                PONumber = DataAccessHelper.ConvertTo<string>(row, "POLineItemNumber"),
                Quantity = DataAccessHelper.ConvertTo<int>(row, "Quantity"),
                BTShippedQuantity = DataAccessHelper.ConvertTo<int>(row, "ShippedQuantity"),
                BTBackorderQuantity = DataAccessHelper.ConvertTo<int>(row, "BackOrderQuantity"),
                BTCancelQuantity = DataAccessHelper.ConvertTo<int>(row, "CancelledQuantity"),
                BTLineItemNote = DataAccessHelper.ConvertTo<string>(row, "LineItemNote"),
                LCClass = DataAccessHelper.ConvertTo<string>(row, "LCClass"),
                Upc = DataAccessHelper.ConvertTo<string>(row, "UPC"),
                SubTitle = DataAccessHelper.ConvertTo<string>(row, "SubTitle"),
                ISBN = DataAccessHelper.ConvertTo<string>(row, "ISBN"),
                ProductLine = DataAccessHelper.ConvertTo<string>(row, "ProductLine"),
                ProductType = row.Table.Columns.Contains("ProductType") ? DataAccessHelper.ConvertToString(row["ProductType"]) : string.Empty,
                StreetDate = DataAccessHelper.ConvertTo<DateTime>(row, "StreetDate"),
                VolumeNumber = DataAccessHelper.ConvertTo<string>(row, "VolumeNumber"),
                PromotionCode = DataAccessHelper.ConvertTo<string>(row, "PromotionCode"),
                ESupplier = DataAccessHelper.ConvertTo<string>(row, "ESupplier"),
                Bib = DataAccessHelper.ConvertTo<string>(row, "BIBNumber"),
                IlsBib = DataAccessHelper.ConvertTo<string>(row, "IlsBIBNumber"),
                IlsOrderNumber = DataAccessHelper.ConvertTo<string>(row, "IlsOrderNumber"),
                BasketOriginalEntryId = DataAccessHelper.ConvertTo<string>(row, "BasketOriginalEntryID"),
                HasGridError = row.Table.Columns.Contains("HasGridError") && DataAccessHelper.ConvertToBool(row["HasGridError"]),
                HasFamilyKey = row.Table.Columns.Contains("HasFamilyKey") && DataAccessHelper.ConvertToBool(row["HasFamilyKey"]),
                PriceKey = row.Table.Columns.Contains("PriceKey") ? DataAccessHelper.ConvertToString(row["PriceKey"]) : string.Empty,
                ContributedBy = row.Table.Columns.Contains("ContributedBy") ? DataAccessHelper.ConvertToString(row["ContributedBy"]) : string.Empty,
                SupplierCode = DataConverter.ConvertTo<string>(row, "PubCodeD"),
                PubStatusCode = DataConverter.ConvertTo<string>(row, "PubStatusCode"),
                AVAttributes = DataConverter.ConvertTo<string>(row, "AVAttributes"),
                BisacSubject1Code = DataConverter.ConvertTo<string>(row, "BisacSubject1Code"),
                Attributes = DataConverter.ConvertTo<string>(row, "Attributes"),
                FormatCode = DataConverter.ConvertTo<string>(row, "FormatCode"),
                EditionNumber = DataConverter.ConvertTo<string>(row, "EditionNumber"),
                Oclc = DataConverter.ConvertTo<string>(row, "OCLCControlNumber"),
                Genre = DataConverter.ConvertTo<string>(row, "Genre"),
                HasReview = DataConverter.ConvertTo<bool>(row, "HasReview"),
                HasAnnotations = DataConverter.ConvertTo<bool>(row, "HasAnnotations"),
                HasExcerpt = DataConverter.ConvertTo<bool>(row, "HasExcerpt"),
                HasReturn = DataConverter.ConvertTo<bool>(row, "HasReturn"),
                HasMuze = DataConverter.ConvertTo<bool>(row, "HasMuze"),
                HasTOC = DataConverter.ConvertTo<bool>(row, "HasTOC"),
                //NumOfDiscs = DataConverter.ConvertTo<int>(row, "NumOfDiscs")
                Version = row.Table.Columns.Contains("Version") ? DataAccessHelper.ConvertTo<string>(row, "Version") : "",
            };
            return res;
        }

        private static string ReviseReportCode(string dbValue)
        {
            return (!string.IsNullOrEmpty(dbValue) && dbValue.Equals("PERMANENTLY OUT OF STOCK", StringComparison.OrdinalIgnoreCase)) ?
                            "Publisher Out of Stock Indefinitely" : dbValue;
        }

        private static SearchResultInventoryStatusArg GetLineItemInventoryArgFromDataRow(DataRow row)
        {
            var res = new SearchResultInventoryStatusArg
            {
                BTKey = DataAccessHelper.ConvertTo<string>(row, "BTKey")
            };
            return res;
        }
        private static ESPRankDetailInfo GetESPRankDetail(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }

            ESPRankDetailInfo espRankDetailInfo = new ESPRankDetailInfo();
            ArrayList lsRankDetail = new ArrayList();

            var firstRow = ds.Tables[0].Rows[0];
            espRankDetailInfo.OverallRank = DataConverter.ConvertTo<decimal?>(firstRow, "ESPOverallRanking");
            espRankDetailInfo.BisacRank = DataConverter.ConvertTo<decimal?>(firstRow, "ESPBisacRanking");
            espRankDetailInfo.DetailUrl = DataConverter.ConvertTo<string>(firstRow, "ESPDetailUrl");

            /*foreach (DataRow row in ds.Tables[0].Rows)
            {
                int espRankTypeID = DataAccessHelper.ConvertToInt(row["ESPRankingTypeID"]);
                string espRankDescription = DataAccessHelper.ConvertToString(row["ESPRankingDescription"]);
                decimal value = DataAccessHelper.ConvertTodecimal(row["Value"]);

                ESPRankDetailInfo.RankDetail rankDetail = new ESPRankDetailInfo.RankDetail();
                rankDetail.Description = espRankDescription;
                rankDetail.Value = value;
                lsRankDetail.Add(rankDetail);
            }*/

            if (lsRankDetail.Count > 0)
                espRankDetailInfo.RankDetails = (ESPRankDetailInfo.RankDetail[])lsRankDetail.ToArray(typeof(ESPRankDetailInfo.RankDetail));

            return espRankDetailInfo;
        }

        //private static TransferredCartInfo GetTransferDetailFromDataSet(DataSet ds)
        private static List<TransferredCartInfo> GetTransferDetailFromDataSet(DataSet ds)
        {
            var results = new List<TransferredCartInfo>();

            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
            {
                //return null;
                return results;
            }

            foreach (DataRow InfoRow in ds.Tables[0].Rows)
            {
                //var InfoRow = ds.Tables[0].Rows[0];

                TransferredCartInfo result = new TransferredCartInfo()
                {
                    BasketSummaryID = InfoRow.Table.Columns.Contains("BasketSummaryID") ? DataAccessHelper.ConvertToString(InfoRow["BasketSummaryID"]) : "",
                    TransferredFrom = InfoRow.Table.Columns.Contains("TransferFrom") ? DataAccessHelper.ConvertToString(InfoRow["TransferFrom"]) : "",
                    TransferredTo = InfoRow.Table.Columns.Contains("TransferTo") ? DataAccessHelper.ConvertToString(InfoRow["TransferTo"]) : "",
                    TransferredFromDate = DataAccessHelper.ConvertToDateTime(InfoRow["TransferFromDate"]),
                    TransferredToDate = DataAccessHelper.ConvertToDateTime(InfoRow["TransferToDate"])
                };

                results.Add(result);
            }

            return results;
        }

        private static List<List<string>> GetESPInvalidCodesFromDataSet(DataSet ds)
        {
            var retList = new List<List<string>>();

            if (ds != null)
            {
                if (ds.Tables.Count > 0)
                {
                    var tableInvalidBranchCodes = ds.Tables[0];
                    var InvalidBranchCodesList =
                        (from DataRow row in tableInvalidBranchCodes.Rows
                         select DataConverter.ConvertTo<string>(row, "literal")).ToList();
                    retList.Add(InvalidBranchCodesList);
                }
                if (ds.Tables.Count > 1)
                {
                    var tableInvalidFundCodes = ds.Tables[1];
                    var InvalidFundCodesList =
                        (from DataRow row in tableInvalidFundCodes.Rows
                         select DataConverter.ConvertTo<string>(row, "literal")).ToList();
                    retList.Add(InvalidFundCodesList);
                }
            }

            return retList;
        }
        private static CartFacet GetCartFacetFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
            {
                Logger.Write("CartFramework", "GetCartFacetFromDataSet => There is no data in CartFacet", false);
                return null;
            }
            DataRowCollection rows = ds.Tables[0].Rows;
            var root = new CartFacet();
            foreach (DataRow row in rows)
            {
                string text = DataAccessHelper.ConvertToString(row["Facet"]);
                CartFacet node = null;
                node = (CartFacet)root.FindNode(text);
                bool isNewNode = false;
                if (node == null)
                {
                    node = new CartFacet();
                    isNewNode = true;
                }
                node.Text = text;
                node.Level = DataAccessHelper.ConvertToInt(row["Level"]);
                node.Value = DataAccessHelper.ConvertToString(row["ItemCount"]);
                string parentText = DataAccessHelper.ConvertToString(row["ParentFacet"]);

                if (!string.IsNullOrEmpty(parentText))
                {
                    var parent = (CartFacet)root.FindNode(parentText);
                    if (parent == null)
                    {
                        parent = new CartFacet();
                        parent.Text = parentText;
                        node.Parent = parent;
                        parent.Nodes.Add(node);
                        root.Add(parent);
                    }
                    else
                    {
                        parent.Add(node);
                    }
                }
                else if (node.Level == 0 && isNewNode)
                {
                    root.Add(node);
                }
            }
            return root;
        }

        private static CartLineFacet GetCartLineFacetFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            DataRowCollection rows = ds.Tables[0].Rows;
            var root = new CartLineFacet();
            foreach (DataRow row in rows)
            {
                string text = DataAccessHelper.ConvertToString(row["Facet"]);
                CartLineFacet node = null;
                node = (CartLineFacet)root.FindNode(text);
                bool isNewNode = false;
                if (node == null)
                {
                    node = new CartLineFacet();
                    isNewNode = true;
                }

                node.Text = text;
                node.Level = DataAccessHelper.ConvertToInt(row["Level"]);
                node.Value = DataAccessHelper.ConvertToString(row["ItemCount"]);
                string parentText = DataAccessHelper.ConvertToString(row["ParentFacet"]);

                if (!string.IsNullOrEmpty(parentText))
                {
                    var parent = (CartLineFacet)root.FindNode(parentText);
                    if (parent == null)
                    {
                        parent = new CartLineFacet();
                        parent.Text = parentText;
                        node.Parent = parent;
                        parent.Add(node);
                        root.Add(parent);
                    }
                    else
                    {
                        parent.Add(node);
                    }
                }
                else if (node.Level == 0 && isNewNode)
                {
                    root.Add(node);
                }
            }
            return root;
        }

        private static List<AccountSummary> GetAccountsSummaryFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var list = new List<AccountSummary>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var account = new AccountSummary();
                account.BasketOrderFormId = DataAccessHelper.ConvertToString(row["BasketOrderFormId"]);
                account.AccountID = DataAccessHelper.ConvertToString(row["AccountID"]);
                account.AccountAlias = DataAccessHelper.ConvertToString(row["AccountAlias"]);
                account.AccountType = DataConverter.GetOldAccountTypeID(DataAccessHelper.ConvertToInt(row["BasketAccountTypeID"]));
                account.ESupplierID = DataAccessHelper.ConvertToString(row["ESupplierID"]);
                account.AccountERPNumber = DataAccessHelper.ConvertToString(row["AccountERPNumber"]);
                account.ERPAccountGUID = DataAccessHelper.ConvertToString(row["ERPAccountGUID"]);
                account.PONumber = DataAccessHelper.ConvertToString(row["PONumber"]);
                account.TotalLines = DataAccessHelper.ConvertToInt(row["TotalOrderLineCount"]);
                account.TotalItems = DataAccessHelper.ConvertToInt(row["TotalOrderQuantity"]);
                account.TotalListPrice = DataAccessHelper.ConvertTodecimal(row["TotalListPrice"]);
                account.TotalNetPrice = DataAccessHelper.ConvertTodecimal(row["TotalNetPrice"]);
                account.EstimateProcessingChange = DataAccessHelper.ConvertTodecimal(row["EstimatedProcessingCharges"]);
                account.EstimateTotalCartPrice = DataAccessHelper.ConvertTodecimal(row["EstimatedTotalCartPrice"]);
                list.Add(account);
            }
            return list;
        }

        private static List<LineItem> GetCartLinesFromDataSet(DataSet ds)
        {
            if (ds == null ||
                ds.Tables.Count < 1 ||
                ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            var result = new List<LineItem>();
            foreach (DataRow dataRow in ds.Tables[0].Rows)
            {
                var item = GetLineItemFromDataRow(dataRow);
                item.PublishDate = DataAccessHelper.ConvertTo<DateTime>(dataRow, "PublishReleaseDate");
                item.Acknowledgements = GetLineItemAckFromDataSet(ds, item.Id);
                item.Upc = DataConverter.ConvertTo<string>(dataRow, "UPC");

                item.ESupplier = DataConverter.ConvertTo<string>(dataRow, "eSupplier");
                item.CatalogName = DataConverter.ConvertTo<string>(dataRow, "ProductCatalog");
                item.MerchCategory = DataConverter.ConvertTo<string>(dataRow, "MerchandiseCategoryLiteral");
                item.HasCPSIAWarning = DataConverter.ConvertTo<bool>(dataRow, "HasCPSIAWarning");
                item.HasAnnotations = DataConverter.ConvertTo<bool>(dataRow, "HasAnnotations");
                item.HasExcerpt = DataConverter.ConvertTo<bool>(dataRow, "HasExcerpt");
                item.HasReturn = DataConverter.ConvertTo<bool>(dataRow, "HasReturn");
                item.HasMuze = DataConverter.ConvertTo<bool>(dataRow, "HasMuze");
                item.HasReview = DataConverter.ConvertTo<bool>(dataRow, "HasReview");
                item.HasTOC = DataConverter.ConvertTo<bool>(dataRow, "HasTOC");
                item.HasJacket = DataConverter.ConvertTo<bool>(dataRow, "HasJacket");
                item.HasIncludedFormat = DataConverter.ConvertTo<bool>(dataRow, "HasIncludedFormat");
                item.FormDetails = DataConverter.ConvertTo<string>(dataRow, "FormDetails");
                item.PurchaseOption = DataConverter.ConvertTo<string>(dataRow, "PurchaseOption");
                item.ProductCode = DataConverter.ConvertTo<string>(dataRow, "ProductCode");
                item.BTEKey = DataConverter.ConvertTo<string>(dataRow, "BTEKey");
                item.SupplierCode = DataConverter.ConvertTo<string>(dataRow, "PubCodeD");
                item.ReplacementBTKey = DataConverter.ConvertTo<string>(dataRow, "ReplacementBTKey");
                item.ESPOverallRanking = DataAccessHelper.ConvertTo<decimal?>(dataRow, "ESPOverallRanking");
                item.ESPBisacRanking = DataAccessHelper.ConvertTo<decimal?>(dataRow, "ESPBisacRanking");
                item.ESPDetailUrl = DataConverter.ConvertTo<string>(dataRow, "ESPDetailUrl");
                item.ESPDetailWidth = DataConverter.ConvertTo<int>(dataRow, "ESPDetailWidth");
                item.ESPDetailHeight = DataConverter.ConvertTo<int>(dataRow, "ESPDetailHeight");
                item.ESPCategoryType = DataConverter.ConvertTo<string>(dataRow, "ESPCategory");
                item.Rating = dataRow.Table.Columns.Contains("RatingLiteral") ? DataAccessHelper.ConvertTo<string>(dataRow, "RatingLiteral") : "";
                item.LanguageLiteral = dataRow.Table.Columns.Contains("LanguageLiteral") ? DataAccessHelper.ConvertTo<string>(dataRow, "LanguageLiteral") : "";
                item.Lexile = dataRow.Table.Columns.Contains("LexileLiteral") ? DataAccessHelper.ConvertTo<string>(dataRow, "LexileLiteral") : "";
                item.Version = dataRow.Table.Columns.Contains("Version") ? DataAccessHelper.ConvertTo<string>(dataRow, "Version") : "";

                DateTime preOrderDate = dataRow.Table.Columns.Contains("PreOrderDate") ? DataAccessHelper.ConvertTo<DateTime>(dataRow, "PreOrderDate") : DateTime.MinValue;
                if (preOrderDate != null && preOrderDate != DateTime.MinValue)
                {
                    item.PreOrderDate = string.Format("{0:MM/dd/yyyy}", preOrderDate);
                }
                if (!string.IsNullOrEmpty(item.ISBN))
                {
                    item.ISBN = item.ISBN.Trim();
                }

                if (!string.IsNullOrEmpty(item.Upc))
                {
                    item.Upc = item.Upc.Trim();
                }

                result.Add(item);
            }
            return result;
        }

        private static List<LineItemAcknowledgement> GetLineItemAckFromDataSet(DataSet ds, string lineItemID)
        {
            var acks = new List<LineItemAcknowledgement>();
            if (ds == null ||
                 ds.Tables.Count < 2 ||
                 ds.Tables[1].Rows.Count == 0)
                return null;
            //DataRow row = ds.Tables[1].Rows.Find(lineItemID);
            foreach (DataRow row in ds.Tables[1].Rows)
            {
                if (DataAccessHelper.ConvertToString(row["BasketLineItemId"]) == lineItemID)
                {
                    var ack = new LineItemAcknowledgement();
                    ack.OrderNumber = DataAccessHelper.ConvertToInt(row["OrderNumber"]);
                    ack.OrderDate = DateTime.Parse(DataAccessHelper.ConvertToString(row["OrderDate"]));
                    ack.Warehouse = DataAccessHelper.ConvertToString(row["Warehouse"]);
                    ack.ShippedQuantity = DataAccessHelper.ConvertToInt(row["ShippedQuantity"]);
                    ack.CancelledQuantity = DataAccessHelper.ConvertToInt(row["CancelledQuantity"]);
                    ack.InProcessQuantity = DataAccessHelper.ConvertToInt(row["InProcessQuantity"]);
                    ack.BackOrderedQuantity = DataAccessHelper.ConvertToInt(row["BackOrderedQuantity"]);
                    ack.RevervedAwaitingReleaseQuantity = DataAccessHelper.ConvertToInt(row["ReservedQuantity"]);
                    acks.Add(ack);
                }
            }

            return acks;
        }
        #endregion

        public static bool SplitCart(string cartId, SplitCartOptions splitCartOption, string userId, out Dictionary<string, string> separatedCarts)
        {
            if (cartId == null) throw new ArgumentNullException("cartId");
            if (userId == null) throw new ArgumentNullException("userId");

            if (splitCartOption == SplitCartOptions.ByGrid)
            {
                var results = CartGridContext.Current.CartGridManager.SplitCartToGridAndNonGrid(cartId);
                separatedCarts = RefineSeparatedCartsForSplitCart(results);
            }
            else
            {
                var results = CartDAO.Instance.SplitCartByAccountType(cartId, userId);
                if (results == null || results.Tables.Count == 0)
                    separatedCarts = new Dictionary<string, string>();

                separatedCarts = GetSplittedCartNameFromDataSet(results);
            }
            return true;
        }

        public static CartSplitResult SplitCartToGridAndNonGrid(string cartId, SplitCartMode splitCartOption, string userId,
            out Dictionary<string, string> separatedCarts)
        {
            if (cartId == null) throw new ArgumentNullException("cartId");
            if (userId == null) throw new ArgumentNullException("userId");
            var result = new CartSplitResult();
            separatedCarts = new Dictionary<string, string>();
            try
            {
                result = CartDAO.Instance.SplitCartGridAndNonGrid(cartId, splitCartOption, userId,
                    out separatedCarts);

            }
            catch (CartManagerException cartException)
            {
                switch (cartException.Message)
                {
                    case CartManagerException.BASKET_STATE_NOT_OPEN:
                        result = CartSplitResult.HasNotOpen;
                        break;
                    case CartManagerException.BASKET_IS_SHARED:
                        result = CartSplitResult.IsSharedCart;
                        break;
                    case CartManagerException.CART_HAS_NO_ITEMS:
                        result = CartSplitResult.HasNoItems;
                        break;
                    case CartManagerException.INVALID_USER_ID:
                        result = CartSplitResult.InvalidUser;
                        break;
                    case CartManagerException.CART_ITEMS_EXCEED_THRESHOLD:
                        result = CartSplitResult.CompletedWithRunBackground;
                        break;
                    default:
                        result = CartSplitResult.Failed;
                        break;
                }
            }

            return result;
        }

        private static Dictionary<string, string> RefineSeparatedCartsForSplitCart(IEnumerable<string> separatedCarts)
        {
            var result = new Dictionary<string, string>();
            foreach (var separatedCart in separatedCarts)
            {
                if (separatedCart.IndexOf(';') != -1)
                {
                    var cartId = separatedCart.Split(';')[0];
                    var cartName = separatedCart.Split(';')[1];
                    result.Add(cartId, cartName);
                }
                else
                {
                    result.Add(separatedCart, separatedCart);
                }
            }
            return result;
        }

        private static Dictionary<string, string> GetSplittedCartNameFromDataSet(DataSet results)
        {
            if (results == null) throw new ArgumentNullException("results");
            var baskets = new Dictionary<string, string>();
            foreach (DataRow row in results.Tables[0].Rows)
            {
                var basketId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
                var basketName = DataAccessHelper.ConvertToString(row["BasketName"]);

                baskets.Add(basketId, basketName);
            }
            return baskets;
        }

        internal static void ReleaseCartQuote(string cartID, string userID)
        {
            try
            {
                CartDAO.Instance.ReleaseCartQuote(cartID, userID);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

        }

        public static List<Cart> GetCartsForQuickManageCarts(string sortBy, string sortDirection, int pageIndex, int pageSize, string userId, out int totalCarts)
        {
            List<Cart> carts = null;
            totalCarts = 0;

            try
            {
                var cartsDs = CartDAO.Instance.GetCartsForQuickManageCarts(sortBy, sortDirection, pageIndex, pageSize,
                                                                           userId, out totalCarts);

                carts = GetCartsForQuickManageCartFromDataSet(cartsDs, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return carts;
        }

        private static List<Cart> GetCartsForQuickManageCartFromDataSet(DataSet cartsDs, string userId)
        {
            if (cartsDs == null ||
                cartsDs.Tables.Count < 1 ||
                cartsDs.Tables[0].Rows.Count == 0)
                return null;

            var cartList = new List<Cart>();
            foreach (DataRow cartRow in cartsDs.Tables[0].Rows)
            {
                var cart = GetCartForQuickManageCartsFromDataRow(cartRow, userId);

                if (cart != null)
                {
                    cartList.Add(cart);
                }
            }
            return cartList;
        }

        private static Dictionary<string, List<CartAccount>> GetCartAccountsForQuickPages(DataTable cartDataTable)
        {
            var dictCartAccount = new Dictionary<string, List<CartAccount>>(StringComparer.OrdinalIgnoreCase);
            foreach (DataRow dataRow in cartDataTable.Rows)
            {
                var basketSummaryId = dataRow["BasketSummaryId"].ToString();
                var cartAccount = GetCartAccountFromDataRowForQuickPages(dataRow);
                if (dictCartAccount.ContainsKey(basketSummaryId))
                {
                    dictCartAccount[basketSummaryId].Add(cartAccount);
                }
                else
                {
                    dictCartAccount.Add(basketSummaryId, new List<CartAccount> { cartAccount });
                }
            }
            return dictCartAccount;
        }

        private static CartAccount GetCartAccountFromDataRowForQuickPages(DataRow dataRow)
        {
            var result = new CartAccount
            {
                BasketSummaryID = dataRow["BasketSummaryID"].ToString(),
                AccountERPNumber = dataRow["AccountId"].ToString(),
                PONumber = dataRow["PONumber"].ToString()
            };
            return result;
        }

        private static Cart GetCartForQuickManageCartsFromDataRow(DataRow row, string userId)
        {
            var strCartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);

            if (String.IsNullOrEmpty(strCartId) || String.IsNullOrEmpty(userId))
                return null;

            var cartStatus = DataAccessHelper.ConvertCartStatus(row["BasketStateID"]);

            var cart = new Cart(strCartId, userId)
            {
                CartName = DataConverter.ConvertTo<string>(row, "CartName"),
                BTStatus = cartStatus,
                LineItemCount = DataAccessHelper.ConvertToInt(row["TitleCount"]),
                CartTotalListPrice = DataAccessHelper.ConvertTodecimal(row["ListPrice"]),
                CartTotalNetPrice = DataAccessHelper.ConvertTodecimal(row["NetPrice"]),
                TotalOrderQuantity = DataAccessHelper.ConvertToInt(row["TotalQuantity"]),
                UpdatedDateTime = DataAccessHelper.ConvertToDateTime(row["LastUpdate"]),
                IsShared = DataAccessHelper.ConvertToBool(row["IsShared"]),
                OneClickMARCIndicator = DataAccessHelper.ConvertToBool(row["OneClickMARCIndicator"]),
                FTPErrorMessage = row["FTPErrorMessage"].ToString(),
                ESPRankStateTypeId = row.Table.Columns.Contains("ESPRankStateTypeId") ? DataAccessHelper.ConvertToInt(row["ESPRankStateTypeId"]) : (int)ESPStateType.None,
                ESPDistStateTypeID = row.Table.Columns.Contains("ESPDistStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPDistStateTypeID"]) : (int)ESPStateType.None,
                ESPFundStateTypeID = row.Table.Columns.Contains("ESPFundStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPFundStateTypeID"]) : (int)ESPStateType.None,
                LastESPStateTypeLiteral = row.Table.Columns.Contains("LastESPStateType") ? DataAccessHelper.ConvertToString(row["LastESPStateType"]) : string.Empty,
                ESPJobText = row.Table.Columns.Contains("ESPJobText") ? DataAccessHelper.ConvertToString(row["ESPJobText"]) : string.Empty,
                ESPJobURL = row.Table.Columns.Contains("ESPJobURL") ? DataAccessHelper.ConvertToString(row["ESPJobURL"]) : string.Empty,
                FreezeLevel = row.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(row["BasketFrozenLevelIndicator"]) : 0,
                IsActive = row.Table.Columns.Contains("IsBasketActive") && DataAccessHelper.ConvertToBool(row["IsBasketActive"])
            };

            return cart;
        }

        public static List<LineItem> GetLineItemForQuickView(List<string> lineItemIds, string userId)
        {
            var results = CartDAO.Instance.GetLineItemForQuickView(lineItemIds, userId);

            if (results == null || results.Tables.Count == 0) return null;

            List<LineItem> lines = GetLineItemForQuickViewFromDataSet(results);
            return lines;
        }

        private static List<LineItem> GetLineItemForQuickViewFromDataSet(DataSet ds)
        {
            var lines = new List<LineItem>();

            foreach (DataRow dataRow in ds.Tables[0].Rows)
            {
                var line = new LineItem();
                line.Id = DataAccessHelper.ConvertToString(dataRow["BasketLineItemId"]);
                line.BasketOriginalEntryId = DataAccessHelper.ConvertToString(dataRow["BasketOriginalEntryId"]);
                line.BTKey = DataAccessHelper.ConvertToString(dataRow["BTKey"]);
                line.PONumber = DataAccessHelper.ConvertToString(dataRow["POLineItemNumber"]);
                line.Bib = DataAccessHelper.ConvertToString(dataRow["BIBNumber"]);
                line.Quantity = DataAccessHelper.ConvertToInt(dataRow["Quantity"]);
                line.BTLineItemNote = DataAccessHelper.ConvertToString(dataRow["Notes"]);
                line.ListPrice = DataAccessHelper.ConvertTodecimal(dataRow["ListPrice"]);
                line.SalePrice = DataAccessHelper.ConvertTodecimal(dataRow["NetPrice"]);
                line.IsShared = DataAccessHelper.ConvertToBool(dataRow["IsShared"]);
                line.IsGridded = DataAccessHelper.ConvertToBool(dataRow["IsGridded"]);
                line.FreezeLevel = dataRow.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(dataRow["BasketFrozenLevelIndicator"]) : 0;

                if (!string.IsNullOrEmpty(line.BasketOriginalEntryId))
                {
                    line.Publisher = DataAccessHelper.ConvertToString(dataRow["PublisherSupplier"]);
                    line.ISBN = DataAccessHelper.ConvertToString(dataRow["ISBN"]);
                    line.Upc = DataAccessHelper.ConvertToString(dataRow["UPC"]);
                    line.FormatLiteral = DataAccessHelper.ConvertToString(dataRow["PhysicalFormat"]);
                    var publishYear = DataAccessHelper.ConvertToString(dataRow["PublishedReleaseYear"]);
                    int year;
                    if (int.TryParse(publishYear, out year))
                    {
                        line.PublishDate = new DateTime(year, 1, 1);
                    }
                    line.Author = DataAccessHelper.ConvertToString(dataRow["ResponsibleParty"]);
                }

                lines.Add(line);
            }

            return lines;
        }
        public static List<Quotation> SearchQuotations(string keyword, string searchBy, int pageIndex, int pageSize, string sortBy, int sortDirection, out int totalCarts)
        {
            List<Quotation> result = new List<Quotation>();
            totalCarts = 0;
            try
            {
                var ds = CartDAO.Instance.SearchQuotations(keyword, searchBy, pageIndex, pageSize, sortBy, sortDirection, out totalCarts);
                if (ds == null ||
               ds.Tables[0].Rows.Count == 0)
                    return null;


                var quotationRows = ds.Tables[0].Rows;

                foreach (DataRow quotationRow in quotationRows)
                {

                    var quotation = new Quotation
                    {
                        CartName = DataConverter.ConvertTo<string>(quotationRow, "CartName"),
                        QuoteID = quotationRow["QuoteID"].ToString(),
                        Expiration = DataConverter.ConvertTo<string>(quotationRow, "Expiration"),
                        CartStatus = DataConverter.ConvertTo<string>(quotationRow, "CartStatus"),
                        UserLoginID = DataConverter.ConvertTo<string>(quotationRow, "UserLoginID"),
                        UserAlias = DataConverter.ConvertTo<string>(quotationRow, "UserAlias"),
                        OrganizationName = DataConverter.ConvertTo<string>(quotationRow, "OrganizationName"),
                        CartID = DataConverter.ConvertTo<string>(quotationRow, "CartID"),
                    };

                    result.Add(quotation);
                }
                return result;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            if (result != null && result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public static List<CartInfoForAjax> GetPermissionForSubmitOrderButtons(string userId, List<string> cartIds)
        {
            var result = new List<CartInfoForAjax>();
            try
            {
                var cartsDs = CartDAO.Instance.GetCartsForQuickManageCarts_Ajax(cartIds, userId);

                result = GetCartInfoForAjax(cartsDs);
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360GetCartManagementQuickView_AJAX:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }

            return result;
        }

        private static List<CartInfoForAjax> GetCartInfoForAjax(DataSet ds)
        {
            var result = new List<CartInfoForAjax>();
            if (ds.Tables.Count == 0) return result;

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var cartInfoAjax = new CartInfoForAjax();
                cartInfoAjax.CartId = row["BasketSummaryID"].ToString();
                cartInfoAjax.IsMixGridCart = DataAccessHelper.ConvertToBool(row["IsMixGridCart"]);
                cartInfoAjax.CanSubmitOrder = DataAccessHelper.ConvertToBool(row["CanSubmitOrder"]);
                cartInfoAjax.IsGrid = DataAccessHelper.ConvertToBool(row["IsGrid"]);

                result.Add(cartInfoAjax);
            }

            if (ds.Tables.Count == 2)
            {
                var dicAccount = GetCartAccountsForQuickPages(ds.Tables[1]);
                if (dicAccount != null && dicAccount.Count > 0)
                {
                    foreach (var cartInfoForAjax in result)
                    {
                        if (dicAccount.ContainsKey(cartInfoForAjax.CartId))
                        {
                            cartInfoForAjax.CartAccounts = dicAccount[cartInfoForAjax.CartId];
                        }
                    }
                }
            }

            return result;
        }

        public static List<CartLineActionPermission> GetLineActionsForQuickManageCarts(string userId, List<string> cartIds)
        {
            var result = new List<CartLineActionPermission>();
            try
            {
                var cartsDs = CartDAO.Instance.GetLineActionsForQuickManageCarts(userId, cartIds);

                if (cartsDs.Tables.Count == 0) return result;

                foreach (DataRow row in cartsDs.Tables[0].Rows)
                {
                    var lineActionPermission = new CartLineActionPermission();
                    lineActionPermission.CartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]); ;
                    lineActionPermission.IsArchived = DataAccessHelper.ConvertToBool(row["IsArchived"]);
                    lineActionPermission.HasReviewAndAcquisition = DataAccessHelper.ConvertToBool(row["HasReviewAcquisitionPermission"]);
                    lineActionPermission.IsShared = DataAccessHelper.ConvertToBool(row["IsShared"]);
                    lineActionPermission.IsPrimary = DataAccessHelper.ConvertToBool(row["IsPrimary"]);
                    lineActionPermission.HasProfile = DataAccessHelper.ConvertToBool(row["HasProfile"]);
                    lineActionPermission.IsGrid = DataAccessHelper.ConvertToBool(row["IsGridCart"]);
                    lineActionPermission.HasOwner = DataAccessHelper.ConvertToBool(row["HasOwner"]);
                    lineActionPermission.HasContribution = DataAccessHelper.ConvertToBool(row["HasContribution"]);
                    lineActionPermission.IsMixedGridNonGrid = DataAccessHelper.ConvertToBool(row["IsMixedGridNonGrid"]);
                    lineActionPermission.IsMixedProduct = DataAccessHelper.ConvertToBool(row["IsMixedProduct"]);
                    lineActionPermission.ESPRankStateTypeId = row.Table.Columns.Contains("ESPRankStateTypeId") ? DataAccessHelper.ConvertToInt(row["ESPRankStateTypeId"]) : (int)ESPStateType.None;
                    lineActionPermission.ESPDistStateTypeID = row.Table.Columns.Contains("ESPDistStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPDistStateTypeID"]) : (int)ESPStateType.None;
                    lineActionPermission.ESPFundStateTypeID = row.Table.Columns.Contains("ESPFundStateTypeID") ? DataAccessHelper.ConvertToInt(row["ESPFundStateTypeID"]) : (int)ESPStateType.None;
                    lineActionPermission.LastESPStateTypeLiteral = row.Table.Columns.Contains("LastESPStateType") ? DataAccessHelper.ConvertToString(row["LastESPStateType"]) : string.Empty;
                    lineActionPermission.FreezeLevel = row.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(row["BasketFrozenLevelIndicator"]) : 0;
                    lineActionPermission.IsBasketActive = row.Table.Columns.Contains("IsBasketActive") ? DataAccessHelper.ConvertToBool(row["IsBasketActive"]) : false;
                    lineActionPermission.HasPermission = DataAccessHelper.ConvertToBool(row["HasPermission"]);
                    result.Add(lineActionPermission);
                }
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360GetCartManagementQuickViewSelectActions:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }

            return result;
        }

        public static SelectedCartsInfo GetSelectedCartsInfoForQuickManageCarts(string userId, List<string> cartIds)
        {
            var result = new SelectedCartsInfo();
            try
            {
                var cartsDs = CartDAO.Instance.GetSelectedCartsInfoForQuickManageCarts(userId, cartIds);

                if (cartsDs.Tables.Count == 0) return result;

                foreach (DataRow row in cartsDs.Tables[0].Rows)
                {
                    result.ContainsOpenCart = DataAccessHelper.ConvertToBool(row["ContainsOpenCart"]);
                    result.ContainsArchivedCart = DataAccessHelper.ConvertToBool(row["ContainsArchivedCart"]);
                    result.ContainsDeletedCart = DataAccessHelper.ConvertToBool(row["ContainsDeletedCart"]);
                    result.ContainsSubmittedCart = DataAccessHelper.ConvertToBool(row["ContainsSubmittedCart"]);
                    result.ContainsOrderedCart = DataAccessHelper.ConvertToBool(row["ContainsOrderedCart"]);
                    result.ContainsPrivateCart = DataAccessHelper.ConvertToBool(row["ContainsPrivateCart"]);
                }
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360GetCartManagementQuickViewSelectedCartActions:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }

            return result;
        }

        //public static bool SetRequisitionType(string cartId, string userID, string requisitionType)
        //{
        //    var result = false;

        //    try
        //    {
        //        result = CartDAO.Instance.SetRequisitionType(cartId, userID, requisitionType);
        //    }
        //    catch (SqlException sqlEx)
        //    {
        //        HandleSqlException(sqlEx);
        //        return false;
        //    }
        //    return result;
        //}

        public static void DesignateAsGrid(string cartId)
        {
            CartGridContext.Current.CartGridManager.SetBlankGridLineToCart(cartId);
        }

        public static void DesignateAsNonGrid(string cartId)
        {
            CartGridContext.Current.CartGridManager.RemoveGridFromCart(cartId, true);
        }

        public static List<Cart> GetCartsByIDs(List<string> cartIds, string userId)
        {
            try
            {
                var ds = CartDAO.Instance.GetCartsByIDs(cartIds);
                if (ds != null && ds.Tables.Count > 0)
                {
                    var cartInfoList = new List<Cart>();
                    var rows = ds.Tables[0].Rows;
                    foreach (DataRow row in rows)
                    {
                        var cartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]);
                        var cart = new Cart(cartId, userId);

                        cart.CartTotalListPrice = DataAccessHelper.ConvertTodecimal(row["TotalListPrice"]);
                        cart.CartTotalNetPrice = DataAccessHelper.ConvertTodecimal(row["TotalNetPrice"]);
                        cart.LineItemCount = DataAccessHelper.ConvertToInt(row["TotalLineCount"]);
                        cart.TotalQuantity = DataAccessHelper.ConvertToInt(row["TotalQuantity"]);

                        cartInfoList.Add(cart);
                    }
                    return cartInfoList;
                }
            }
            catch (SqlException sqlEx)
            {
                sqlEx.Source = "procTS360GetBasketsByIDs:" + sqlEx.Source;
                HandleSqlException(sqlEx);
            }
            return null;
        }


        public static List<ESPQueue> ViewESPQueue(string displayStatus, string cartStatus, int pageIndex, int pageSize, out int totalLines)
        {
            try
            {
                string basketStatus = cartStatus = string.IsNullOrEmpty(cartStatus) ? null : cartStatus;
                var ds = CartDAO.Instance.ViewESPQueue(displayStatus, basketStatus, pageIndex, pageSize, out totalLines);
                var result = GetFromDataSetForESPQueue(ds);

                return result;
            }
            catch (SqlException sqlEx)
            {
                Logger.LogException(sqlEx);
                throw;
            }
        }

        private static List<ESPQueue> GetFromDataSetForESPQueue(DataSet ds)
        {
            if (ds == null ||
                ds.Tables[0].Rows.Count == 0)
                return null;

            var results = new List<ESPQueue>();
            var espRows = ds.Tables[0].Rows;

            foreach (DataRow espRow in espRows)
            {
                results.Add(GetFromDataRowForViewESPQueue(espRow));
            }
            return results;
        }

        private static ESPQueue GetFromDataRowForViewESPQueue(DataRow espRow)
        {
            var strCartId = DataAccessHelper.ConvertToString(espRow["BasketSummaryID"]);

            if (String.IsNullOrEmpty(strCartId))
                return null;

            var submittedDateTime = new DateTime();
            if (espRow.Table.Columns.Contains("SubmittedDate"))
            {
                var temp = DataAccessHelper.ConvertToDateTime(espRow["SubmittedDate"]);
                submittedDateTime = temp.HasValue ? temp.Value : new DateTime();
            }

            var espQueue = new ESPQueue
            {
                CartName = DataConverter.ConvertTo<string>(espRow, "BasketName"),
                ESPJobType = DataConverter.ConvertTo<string>(espRow, "ESPJobType"),
                BasketSummaryID = DataConverter.ConvertTo<string>(espRow, "BasketSummaryID"),
                ESPJobId = DataConverter.ConvertTo<string>(espRow, "ESPJobId"),
                OrganizationName = DataConverter.ConvertTo<string>(espRow, "u_Name"),
                ESPLibraryID = DataConverter.ConvertTo<string>(espRow, "u_esp_library_id"),
                UserName = DataConverter.ConvertTo<string>(espRow, "u_user_name"),
                CartStatus = DataConverter.ConvertTo<string>(espRow, "CartStatus"),
                SubmittedDate = submittedDateTime,
                UserId = DataConverter.ConvertTo<string>(espRow, "ESPSumittedUser"),
                IsResetVisible = Convert.ToBoolean(DataConverter.ConvertTo<int>(espRow, "IsResetVisible"))
            };

            return espQueue;
        }

        internal static int ApplyDuplicates(List<string> cartIDs, string userID, int maxLineLimit, out string desCartId, out string cartname, out int numberOfItemApplied,
            string cartCheckType, string orderCheckType, string orgId, string downloadCheckType, bool moveToNewCart)
        {
            var retCode = -1;
            numberOfItemApplied = 0;
            desCartId = string.Empty;
            cartname = string.Empty;

            try
            {
                var dataset = CartDAO.Instance.ApplyDuplicates(cartIDs, userID, maxLineLimit,
                                                           cartCheckType, orderCheckType, orgId, out retCode, downloadCheckType, moveToNewCart);
                if (dataset != null && dataset.Tables.Count > 0)
                {
                    var row = dataset.Tables[0].Rows[0];
                    cartname = row["DestinationBasketName"].ToString();
                    desCartId = row["DestinationBasketSummaryID"].ToString();
                    numberOfItemApplied = DataAccessHelper.ConvertToInt(row["DuplicatesNr"]);
                }
                //ConvertDataFromDataset(dataset);
                return retCode;
            }
            catch (SqlException ex)
            {
                HandleSqlException(ex);
                return -1;
            }
        }

        public static void SetCartAsActiveOrInActive(string cartId, string userId, bool isActive, int maxActiveCarts)
        {
            try
            {
                var ds = CartDAO.Instance.SetCartAsActiveOrInActive(cartId, userId, isActive, maxActiveCarts);
                //var result = GetFromDataSetForESPQueue(ds);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        public static List<Cart> GetActiveRecentCarts(string userId, int numberOfCartsToGet)
        {
            try
            {
                var cartsDs = CartDAO.Instance.GetActiveRecentCarts(numberOfCartsToGet, userId);

                //var carts = GetCartsFromDataSet(cartsDs);
                return GetCartsFromDataSetLite(cartsDs);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return null;
        }
        public static void SetILSBasketState(string basketSummaryID, string userId, BT.TS360Constants.CartStatus basketState, BT.TS360Constants.ILSState ilsStatusId, string ILSMarcProfileId, string vendorCode, string locationCode, string orderedDownloadedUserId)
        {
            CartDAO.Instance.SetILSBasketState(basketSummaryID, userId, basketState, ilsStatusId, ILSMarcProfileId, vendorCode, locationCode, orderedDownloadedUserId);
        }

        /// <summary>
        /// Gets ILS Log for Sierra only.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        public static ILSAPIRequestResponse GetILSLog(string cartId)
        {
            string ilsAPILogUrl = GlobalConfiguration.ReadAppSetting(BT.TS360Constants.GlobalConfigurationKey.ILSGetLogApiUrl).Value; //ILSGlobalSettings.Get(GlobalConfigurationKey.ILSGetLogApiUrl);
            string ilsAPIReqUrl = String.Format("{0}/{1}", ilsAPILogUrl, cartId);
            BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSAPIRequestResponse> cartILSAPILog = new BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSAPIRequestResponse>();

            using (WebClient client = new WebClient())
            {
                var jss = new JavaScriptSerializer();
                client.Headers["Content-type"] = "application/json";
                string responseJson = client.DownloadString(ilsAPIReqUrl);
                cartILSAPILog = jss.Deserialize<BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSAPIRequestResponse>>(responseJson);
            }

            return cartILSAPILog.Data;
        }

        /// <summary>
        /// Gets ILS Ordering ResponseS tatus From APILog from NoSQL API.
        /// </summary>
        /// <param name="cartId"></param>
        /// <returns></returns>
        public static ILSOrderValidationResponseStatus GetILSOrderingResponseStatusFromAPILog(string cartId)
        {
            var ilsAPILogUrl = GlobalConfiguration.ReadAppSetting(BT.TS360Constants.GlobalConfigurationKey.ILSGetLogApiUrl).Value; //ILSGlobalSettings.Get(GlobalConfigurationKey.ILSGetLogApiUrl);
            var ilsAPIReqUrl = String.Format("{0}/response/{1}", ilsAPILogUrl, cartId);
            var cartILSAPILog = new BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSOrderValidationResponseStatus>();

            using (WebClient client = new WebClient())
            {
                var jss = new JavaScriptSerializer();
                client.Headers["Content-type"] = "application/json";
                string responseJson = client.DownloadString(ilsAPIReqUrl);
                cartILSAPILog = jss.Deserialize<BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSOrderValidationResponseStatus>>(responseJson);
            }

            return cartILSAPILog.Data;
        }

        public static ILSValidationRequestResponse GetILSValidationRequestResponseFromAPILog(string cartId)
        {
            var ilsAPILogUrl = GlobalConfiguration.ReadAppSetting(BT.TS360Constants.GlobalConfigurationKey.ILSGetLogApiUrl).Value; //ILSGlobalSettings.Get(GlobalConfigurationKey.ILSGetLogApiUrl);
            var ilsAPIReqUrl = String.Format("{0}/validation/response/{1}", ilsAPILogUrl, cartId);
            var cartILSAPILog = new BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSValidationRequestResponse>();

            using (WebClient client = new WebClient())
            {
                var jss = new JavaScriptSerializer();
                client.Headers["Content-type"] = "application/json";
                string responseJson = client.DownloadString(ilsAPIReqUrl);
                cartILSAPILog = jss.Deserialize<BT.TS360API.ServiceContracts.NoSqlServiceResult<ILSValidationRequestResponse>>(responseJson);
            }

            return cartILSAPILog.Data;
        }

        public static void SetIlsSystemStatus(string basketSummaryId, string userId, BT.TS360Constants.ILSSystemStatus ilsSystemStatusId)
        {
            CartDAO.Instance.SetIlsSystemStatus(basketSummaryId, userId, ilsSystemStatusId);
        }

        public static void ResetIlsCart(string basketSummaryId, string userId)
        {
            CartDAO.Instance.ResetIlsCart(basketSummaryId, userId);
        }

    }
}
