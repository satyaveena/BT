﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.CartFramework
{
    public class CartFacet : BaseFacetNode
    {
        #region Implement BaseFacetNode
        internal override void Add(BaseFacetNode node)
        {
            if(node != null)
            {
                Nodes.Add(node);
            }
        }
        internal override BaseFacetNode FindNode(string value)
        {
            BaseFacetNode result = null;
            if(Text == value)
            {
                return this;
            }
            foreach (var child in Nodes)
            {
                result = child.FindNode(value);
                if(result != null)
                {
                    return result;
                }
            }
            return result;
        }
        #endregion
    }
}
