﻿namespace BTNextGen.CartFramework
{
    public interface ICartContext
    {

    }
}
