﻿namespace BTNextGen.CartFramework
{
    public abstract class BaseCartFolder
    {
        internal abstract void NotifyCartFolderChanged();
        internal abstract void NotifyCartsChanged();
        internal abstract void NotifyPrimaryCartChanged();
        internal abstract void NotifyTopNewestCartsChanged();
    }
}
