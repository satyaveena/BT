﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.CartFramework
{
    public abstract class BaseFacetNode
    {
        public string Text { get; set; }
        public string Value { get; set; }
        public string IsShowCheckbox { get; set; }
        public int Level { get; set; }
        public BaseFacetNode Parent { get; set; }
        public List<BaseFacetNode> Nodes { get; set; }

        internal BaseFacetNode()
        {
            Nodes=new List<BaseFacetNode>();
        }

        internal abstract void Add(BaseFacetNode node);
        internal abstract BaseFacetNode FindNode(string value);
    }
}
