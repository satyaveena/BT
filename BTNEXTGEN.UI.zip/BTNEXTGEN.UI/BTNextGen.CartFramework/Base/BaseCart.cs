﻿using System;
using System.Collections.Generic;
using BTNextGen.CartFramework.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;

namespace BTNextGen.CartFramework
{
    public abstract class BaseCart
    {
        public virtual string UserId { get; set; }

        internal virtual void NotifyCartsChanged()
        {
            NotifyPrimaryCartChanged();
            NotifyTopNewestCartsChanged();
        }

        internal virtual void NotifyCartsChanged(List<string> cartIDs)
        {
            NotifyCartsChanged();
            foreach (var cartID in cartIDs)
            {
                NotifyCartChanged(cartID);
            }
        }

        internal virtual void NotifyPrimaryCartChanged()
        {
            CartFarmCacheHelper.SetExpiredPrimaryCart(this.UserId);
        }

        internal virtual void NotifyTopNewestCartsChanged()
        {
            CartCacheManager.SetTopNewestCartCacheExpired(this.UserId);
        }

        internal virtual void NotifyCartChanged(string cartId)
        {
            CartCacheManager.SetCartCacheExpired(cartId);
            if (IsPrimaryCart(cartId, this.UserId))
            {
                NotifyPrimaryCartChanged();
            }
            CartCacheManager.SetTopNewestCartCacheExpired(this.UserId);
        }

        internal virtual void NotifyCartLineChanged(string cartId)
        {
            this.NotifyCartChanged(cartId);
        }
        
        internal bool IsPrimaryCart(string cartId, string userId)
        {
            return CartFarmCacheHelper.IsPrimaryCart(cartId, userId);
        }

        internal void WcfServiceCalculatePrice(string cartId)
        {
            try
            {
                var serviceClient = new PricingServiceClient();
                serviceClient.CalculatePriceForBasket(cartId);
            }
            catch (Exception exception)
            {
                Logger.LogException(exception);
            }            
        }
    }
}
