﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace BTNextGen.CartFramework
{
    using Commerce.Portal.Common.Constants;
    using Helpers;
    using Order;
    using Commerce.Portal.Common;
    using Commerce.Portal.Common.Contracts;
    using Commerce.Portal.Common.Helpers;
    using Commerce.Portal.Common.Logging;
    using LineItem = Order.LineItem;
    using BT.TS360Constants;
    static internal partial class CartDAOManager
    {
        #region Cart Folder Methods

        /// <summary>
        /// Create Cart Folder
        /// </summary>
        /// <param name="name"></param>
        /// <param name="parentId"></param>
        /// <param name="cartFolderType"></param>
        /// <param name="sequenceNo"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static CartFolder CreateCartFolder(string name, string parentId, CartFolderType cartFolderType, float sequenceNo, string userId)
        {
            try
            {
                string folderId;
                CartDAO.Instance.CreateCartFolder(name, parentId, (int)cartFolderType, sequenceNo, userId, out folderId);
                if (!string.IsNullOrEmpty(folderId))
                {
                    return GetCartFolderById(folderId);
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return null;
        }

        /// <summary>
        /// Creates default system folders for new user.
        /// </summary>
        /// <param name="userId">A new user Id to create.</param>
        /// <returns></returns>
        internal static Dictionary<string, CartFolderType> CreateSystemCartFolders(string userId)
        {
            var result = new Dictionary<string, CartFolderType>();

            try
            {
                var dataSet = CartDAO.Instance.CreateSystemCartFolders(userId);
                if (dataSet != null && dataSet.Tables.Count > 0)
                {
                    var folderDt = dataSet.Tables[0];
                    if (folderDt != null && folderDt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in folderDt.Rows)
                        {
                            var userFolderId = DataAccessHelper.ConvertToString(dr["UserFolderID"]);
                            var folderTypeId = DataAccessHelper.ConvertToInt(dr["FolderTypeID"]);

                            result.Add(userFolderId, (CartFolderType)folderTypeId);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        /// <summary>
        /// Get Cart Folders
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static CartFolders GetCartFolders(string userId)
        {
            try
            {
                //// App Fabric
                //var cartFoldersDs = CartCacheManager.GetCartFolderDataSetFromCache(userId);
                //if (cartFoldersDs == null)
                //{
                //    cartFoldersDs = CartDAO.Instance.GetCartFolders(userId);
                //    CartCacheManager.AddCartFolderDataSetToCache(cartFoldersDs, userId);
                //}

                var cartFoldersDs = CartDAO.Instance.GetCartFolders(userId);
                var result = new CartFolders();
                if (cartFoldersDs.Tables.Count > 0)
                {
                    var basketFolderDt = cartFoldersDs.Tables[0];
                    if (basketFolderDt != null && basketFolderDt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in basketFolderDt.Rows)
                        {
                            var cartFolder = CartFolder.CreateCartFolderFromDataRow(dr);
                            result.Add(cartFolder);
                        }
                        return result;
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return null;
        }

        internal static CartFolder GetCartFolderById(string folderId)
        {
            try
            {
                if (string.IsNullOrEmpty(folderId))
                    return null;

                var cartFolderDs = CartDAO.Instance.GetCartFolder(folderId);
                if (cartFolderDs != null && cartFolderDs.Tables.Count > 0)
                {
                    var folderDt = cartFolderDs.Tables[0];
                    if (folderDt != null && folderDt.Rows.Count > 0)
                    {
                        var dr = folderDt.Rows[0];
                        var cartFolder = CartFolder.CreateCartFolderFromDataRow(dr);
                        return cartFolder;
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return null;
        }

        /// <summary>
        /// Delete Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="userId"></param>
        internal static void DeleteCartFolder(string cartFolderId, string userId)
        {
            try
            {
                CartDAO.Instance.DeleteCartFolder(cartFolderId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        /// <summary>
        /// Move Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="parentCartFolderId"></param>
        /// <param name="userId"></param>
        internal static void MoveCartFolder(string cartFolderId, string parentCartFolderId, string userId)
        {
            try
            {
                CartDAO.Instance.MoveCartFolder(cartFolderId, parentCartFolderId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        ///// <summary>
        ///// Archive Cart Folder
        ///// </summary>
        ///// <param name="cartFolderId"></param>
        ///// <param name="userId"></param>
        //internal static void ArchiveCartFolder(string cartFolderId, string userId)
        //{
        //    try
        //    {
        //        CartDAO.Instance.ArchiveCartFolder(cartFolderId, userId);
        //    }
        //    catch (SqlException sqlEx)
        //    {
        //        HandleSqlException(sqlEx);
        //    }

        //}

        /// <summary>
        /// Rename
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="newCartFolderName"></param>
        /// <param name="userId"></param>
        internal static void Rename(string cartFolderId, string newCartFolderName, string userId)
        {
            try
            {
                CartDAO.Instance.Rename(cartFolderId, newCartFolderName, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

        }

        /// <summary>
        /// Update Sequence Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        /// <param name="sequenceNo"></param>
        /// <param name="userId"></param>
        internal static void UpdateSequenceCartFolder(string cartFolderId, float sequenceNo, string userId)
        {
            try
            {
                CartDAO.Instance.UpdateSequenceCartFolder(cartFolderId, sequenceNo, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

        }

        internal static float GetUserFolderSequence(string parentFolderId, string userId, int positionType)
        {
            float sequence = 0;
            try
            {
                object result = CartDAO.Instance.GetUserFolderSequence(parentFolderId, userId, positionType);
                float.TryParse(result.ToString(), out sequence);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return sequence;
        }

        #endregion

        #region Cart Line Methods

        /// <summary>
        /// Add line items to cart
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="cartId"></param>
        /// <param name="userId"></param>
        internal static void AddLineItemsToCart(List<LineItem> lineItems, string cartId, string userId, out string PermissionViolationMessage,
            out int totalAddingQtyForGridDistribution)
        {
            PermissionViolationMessage = "";
            totalAddingQtyForGridDistribution = 0;
            if (lineItems == null || lineItems.Count == 0) return;
            try
            {
                CartDAO.Instance.AddLineItemsToCart(DataConverter.ConvertCartLineItemsToDataset(lineItems), cartId, userId,
                    CartFrameworkHelper.MaxLinesPerCart, out PermissionViolationMessage, out totalAddingQtyForGridDistribution);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }
        internal static void AddExceed500LineItemsToCart(List<LineItem> lineItems, string cartId, string userId)
        {
            
            if (lineItems == null || lineItems.Count == 0) return;
            try
            {
                CartDAO.Instance.AddExceed500LineItemsToCart(DataConverter.ConvertCartLineItemsToDataset(lineItems), cartId, userId,
                    CartFrameworkHelper.MaxBatchSizeAddingCart);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }
        internal static void CopyLineItems(List<LineItem> lineItems, string destinationId, string userId, string sourceCartId,
            int maxLinesPerCart, string whatToCopy, out string PermissionViolationMessage)
        {
            PermissionViolationMessage = string.Empty;
            try
            {
                var lineItemsDict = BuildLineItemDictionary(lineItems);
                CartDAO.Instance.CopyLineItems(lineItemsDict, destinationId, userId, sourceCartId, maxLinesPerCart, whatToCopy, out PermissionViolationMessage);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void CopyCancelledLineItems(string sourceId, string destinationId)
        {
            try
            {
                CartDAO.Instance.CopyCancelledLineItems(sourceId, destinationId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        private static Dictionary<string, Dictionary<string, string>> BuildLineItemDictionary(IEnumerable<LineItem> lineItems)
        {
            var dictLineItems = new Dictionary<string, Dictionary<string, string>>();

            foreach (var lineItem in lineItems)
            {
                var dicValues = new Dictionary<string, string>
                                    {
                                        {"BasketLineItemID", lineItem.Id},
                                        {"BTKey", lineItem.BTKey},
                                        {"quantity", lineItem.Quantity.ToString()},
                                        {"POLineItemNumber", lineItem.PONumber},
                                        {"Note", lineItem.IsOriginalEntryItem ? lineItem.BTLineItemNote : string.Empty},
                                        {"BibNumber", lineItem.Bib},
                                        {"PrimaryResponsiblePartyRedundant", lineItem.Author},
                                        {"ShortTitleRedundant", lineItem.Title}
                                    };

                dictLineItems.Add(lineItem.Id, dicValues);
            }

            return dictLineItems;
        }

        internal static void CopyCartTitle(LineItem lineItem, string destinationCartId, string userId)
        {
            try
            {
                var lineItemsDict = BuildLineItemDictionary(new List<LineItem>() { lineItem });
                CartDAO.Instance.CopyTitle(lineItemsDict, destinationCartId, userId, CartFrameworkHelper.MaxLinesPerCart);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void MoveCartTitle(LineItem lineItem, string sourceCartId, string destinationCartId, string userId)
        {
            try
            {
                var lineItemsDict = BuildLineItemDictionary(new List<LineItem>() { lineItem });
                CartDAO.Instance.MoveTitle(lineItemsDict, sourceCartId, destinationCartId, userId, CartFrameworkHelper.MaxLinesPerCart);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void MoveLineItems(List<LineItem> lineItems, string sourceCartId, string destinationCartId, string userId, out string PermissionViolationMessage)
        {
            PermissionViolationMessage = string.Empty;
            try
            {
                var lineItemsDict = BuildLineItemDictionary(lineItems);
                CartDAO.Instance.MoveLineItems(lineItemsDict, sourceCartId, destinationCartId, userId, CartFrameworkHelper.MaxLinesPerCart, out PermissionViolationMessage);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        /// <summary>
        /// Remove a list of line items
        /// </summary>
        /// <param name="lineItemId"></param>
        /// <param name="userId"></param>
        /// <param name="cartId"></param>
        /// <returns>Dictionary with BasketLineItemId as key and ErrorCode as value</returns>
        internal static Dictionary<string, string> RemoveLineItems(List<string> lineItemId, string userId, string cartId)
        {
            try
            {
                var resultSet = CartDAO.Instance.RemoveLineItems(lineItemId, userId, cartId);
                if (resultSet == null ||
                    resultSet.Tables.Count < 1 ||
                    resultSet.Tables[0].Rows.Count == 0)
                {
                    return null;
                }

                var errorTable = new Dictionary<string, string>();
                foreach (DataRow row in resultSet.Tables[0].Rows)
                {
                    var errorLineItemId = DataConverter.ConvertTo<string>(row, "BasketLineItemId");
                    var errorCode = DataConverter.ConvertTo<string>(row, "ErrorCode");
                    if (errorLineItemId != null && !errorTable.ContainsKey(errorLineItemId))
                    {
                        errorTable.Add(errorLineItemId, errorCode);
                    }
                }

                return errorTable;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
                return null;
            }
        }

        /// <summary>
        /// Update line item note
        /// </summary>
        /// <param name="note"></param>
        /// <param name="lineItemId"></param>
        /// <param name="userId"></param>
        internal static void UpdateLineItemNote(string note, string lineItemId, string userId)
        {
            try
            {
                CartDAO.Instance.UpdateLineItemNote(note, lineItemId, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        /// <summary>
        /// Update line item quantity
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="userId"></param>
        internal static void UpdateLineItemsQuantity(Dictionary<string, Dictionary<string, string>> lineItems, string userId)
        {
            CartDAO.Instance.UpdateLineItemsQuantity(lineItems, userId);
        }

        /// <summary>
        /// Update line item PO and BIB number
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="userId"></param>
        internal static void UpdateLineItemsInfo(Dictionary<string, Dictionary<string, string>> lineItems, string userId)
        {
            CartDAO.Instance.UpdateLineItemsInfo(lineItems, userId);
        }

        /// <summary>
        /// Update line item Notes
        /// </summary>
        /// <param name="lineItems"></param>
        /// <param name="userId"></param>
        internal static void UpdateLineItemsNotes(Dictionary<string, Dictionary<string, string>> lineItems, string userId, string cartId)
        {
            try
            {
                CartDAO.Instance.UpdateLineItemsNotes(lineItems, userId, cartId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void UpdateItemOrderingInfo(string userId, string lineItemId, int quantity, string poLinenumber, string bibNumber,
            bool needToUpdatePONumber, bool needToUpdateBIBNumber, string note, string basketSummaryId)
        {
            try
            {
                CartDAO.Instance.UpdateItemOrderingInfo(userId, lineItemId, quantity, poLinenumber, bibNumber, needToUpdatePONumber, needToUpdateBIBNumber, note, basketSummaryId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static void ReflagPricingBasketLineItems(string cartId)
        {
            try
            {
                CartDAO.Instance.ReflagPricingBasketLineItems(cartId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static bool IsCartPricing(string cartId, string userId)
        {
            try
            {
                return CartDAO.Instance.IsCartPricing(cartId, userId);
            }
            catch (CartManagerException ex)
            {
                if (ex.isBusinessError)
                    return false;
                else
                    throw ex;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
                return false;
            }
        }

        internal static bool CheckBasketforCalMerch(string cartId)
        {
            try
            {
                return CartDAO.Instance.CheckBasketforCalMerch(cartId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
                return false;
            }
        }

        internal static QuickCart GetCartDetailsQuickView(string cartId, string userId, string sortBy, byte sortDirection,
            short pageSize, int pageNumber, bool recalculateHeader)
        {
            try
            {
                var quickCart = new QuickCart(cartId, userId);
                int nonRankedCount = 0;
                var ds = CartDAO.Instance.GetCartDetailsQuickView(cartId, userId, sortBy, sortDirection, pageSize, pageNumber, recalculateHeader, out nonRankedCount);
                quickCart.NonRankedCount = nonRankedCount;
                if (ds != null && ds.Tables.Count > 0)
                {
                    quickCart.LineItems = new List<QuickLineItem>();
                    var lineItemTable = ds.Tables[0];
                    foreach (DataRow row in lineItemTable.Rows)
                    {
                        var lineItem = new QuickLineItem();
                        lineItem.LineItemID = DataAccessHelper.ConvertToString(row["BasketLineItemID"]);
                        lineItem.BTKey = DataAccessHelper.ConvertToString(row["BTKey"]);
                        lineItem.ListPrice = DataAccessHelper.ConvertTodecimal(row["ListPrice"]);
                        lineItem.NetPrice = DataAccessHelper.ConvertTodecimal(row["NetPrice"]);
                        lineItem.IsGridded = DataAccessHelper.ConvertToBool(row["IsGridded"]);
                        lineItem.Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]);
                        lineItem.Discount = DataAccessHelper.ConvertTodecimal(row["Discount"]);
                        lineItem.BasketOriginalEntryID = DataAccessHelper.ConvertToString(row["BasketOriginalEntryID"]);
                        lineItem.ProductType = string.Empty;
                        if (!string.IsNullOrEmpty(lineItem.BasketOriginalEntryID))
                        {
                            lineItem.Title = DataAccessHelper.ConvertToString(row["Title"]);
                            lineItem.Author = DataAccessHelper.ConvertToString(row["ResponsibleParty"]);
                            lineItem.ISBN = DataAccessHelper.ConvertToString(row["ISBN"]);
                            lineItem.UPC = DataAccessHelper.ConvertToString(row["UPC"]);
                            lineItem.Format = DataAccessHelper.ConvertToString(row["FormatLiteral"]);
                            lineItem.PublishedDate = DataAccessHelper.ConvertToDateTime(row["PublicationDate"]);
                        }
                        quickCart.LineItems.Add(lineItem);
                    }
                    if (ds.Tables.Count > 1)
                    {
                        var cartHeaderTable = ds.Tables[1];
                        if (cartHeaderTable.Rows.Count > 0)
                        {
                            quickCart.CartInfo = new QuickCartInfo();
                            var liRow = cartHeaderTable.Rows[0];
                            quickCart.CartInfo.CartStatus = DataAccessHelper.ConvertToString(liRow["CartStatus"]);
                            quickCart.CartInfo.CartOwnerID = DataAccessHelper.ConvertToString(liRow["CartOwner"]);
                            quickCart.CartInfo.CartName = DataAccessHelper.ConvertToString(liRow["CartName"]);
                            quickCart.CartInfo.TotalLines = DataAccessHelper.ConvertToInt(liRow["TotalLines"]);
                            quickCart.CartInfo.TotalQuantity = DataAccessHelper.ConvertToLong(liRow["TotalQuantity"]);
                            quickCart.CartInfo.TotalListPrice = DataAccessHelper.ConvertTodecimal(liRow["TotalListPrice"]);
                            quickCart.CartInfo.TotalNetPrice = DataAccessHelper.ConvertTodecimal(liRow["TotalNetPrice"]);
                            quickCart.CartInfo.IsShared = DataAccessHelper.ConvertToBool(liRow["IsShared"]);
                            quickCart.CartInfo.IsPricingComplete = DataAccessHelper.ConvertToBool(liRow["IsPricingComplete"]);
                            quickCart.CartInfo.OneClickMARCIndicator = DataAccessHelper.ConvertToBool(liRow["OneClickMARCIndicator"]);
                            quickCart.CartInfo.FTPErrorMessage = DataAccessHelper.ConvertToString(liRow["FTPErrorMessage"]);
                            quickCart.CartInfo.ESPRankStateTypeId = liRow.Table.Columns.Contains("ESPRankStateTypeId") ? DataAccessHelper.ConvertToInt(liRow["ESPRankStateTypeId"]) : (int)ESPStateType.None;
                            quickCart.CartInfo.ESPDistStateTypeID = liRow.Table.Columns.Contains("ESPDistStateTypeID") ? DataAccessHelper.ConvertToInt(liRow["ESPDistStateTypeID"]) : (int)ESPStateType.None;
                            quickCart.CartInfo.ESPFundStateTypeID = liRow.Table.Columns.Contains("ESPFundStateTypeID") ? DataAccessHelper.ConvertToInt(liRow["ESPFundStateTypeID"]) : (int)ESPStateType.None;
                            quickCart.CartInfo.LastESPStateTypeLiteral = liRow.Table.Columns.Contains("LastESPStateType") ? DataAccessHelper.ConvertToString(liRow["LastESPStateType"]) : string.Empty;
                            quickCart.CartInfo.ESPJobText = liRow.Table.Columns.Contains("ESPJobText") ? DataAccessHelper.ConvertToString(liRow["ESPJobText"]) : string.Empty;
                            quickCart.CartInfo.ESPJobURL = liRow.Table.Columns.Contains("ESPJobURL") ? DataAccessHelper.ConvertToString(liRow["ESPJobURL"]) : string.Empty;
                            quickCart.CartInfo.FreezeLevel = liRow.Table.Columns.Contains("BasketFrozenLevelIndicator") ? DataAccessHelper.ConvertToInt(liRow["BasketFrozenLevelIndicator"]) : 0;
                            quickCart.CartInfo.IsMixedProduct = liRow.Table.Columns.Contains("IsMixedProduct") ? DataAccessHelper.ConvertToBool(liRow["IsMixedProduct"]) : false;
                            quickCart.CartInfo.IsBasketActive = liRow.Table.Columns.Contains("IsBasketActive") ? DataAccessHelper.ConvertToBool(liRow["IsBasketActive"]) : false;
                            quickCart.CartInfo.CartFolderId = DataAccessHelper.ConvertToString(liRow["CartFolderID"]);
                            quickCart.CartInfo.IsArchived = liRow.Table.Columns.Contains("IsArchived") ? DataAccessHelper.ConvertToBool(liRow["IsArchived"]) : false;
                        }
                    }
                }
                return quickCart;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
                return null;
            }
        }

        #endregion

        #region Submit order methods

        internal static bool CheckForDuplicates(string listItemKeys, string listBTEkeys, string cartCheckType,
            string orderCheckType, string orgId, string soldToId, out string itemsCheckOrder, out string itemsCheckCart, string cartId,
            out Dictionary<string, bool> itemsCheckHoldings, string holdingsFlag, string downloadCheckType)
        {
            itemsCheckOrder = string.Empty;
            itemsCheckCart = string.Empty;
            itemsCheckHoldings = null;

            bool checkForDuplicates;

            try
            {
                checkForDuplicates = CartDAO.Instance.CheckForDuplicates(listItemKeys, listBTEkeys, cartCheckType, orderCheckType, orgId, soldToId,

                                                        out itemsCheckOrder, out itemsCheckCart, cartId, downloadCheckType);

                
                if (holdingsFlag.ToLower() != "none")
                {
                    var duplicateHoldings = CartDAO.Instance.CheckHoldingsDuplicates(soldToId, SiteContext.Current.OrganizationId, holdingsFlag, listItemKeys);
                    itemsCheckHoldings = duplicateHoldings;

                }
                return checkForDuplicates;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return false;
        }

        internal static DuplicateCartTitle GetDuplicateCartReferences(string cartId, string itemKey,
            string orgId, string soldToId, string downloadCheckType)
        {
            DuplicateCartTitle result = null;
            try
            {
                var ds = CartDAO.Instance.GetDuplicateCartReferences(itemKey, orgId, soldToId, cartId, downloadCheckType);

                if (ds != null && ds.Tables.Count > 0)
                {
                    result = new DuplicateCartTitle();

                    //Get Title Information data.
                    result.Title = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Title"]);
                    result.Author = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Author"]);
                    result.ISBN = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["ISBN"]);
                    result.Format = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Format"]);
                    result.Publisher = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Publisher"]);
                    result.PublishDate = DataAccessHelper.ConvertToDateTime(ds.Tables[0].Rows[0]["PublicationDate"]);
                    //result.NetPrice = DataAccessHelper.ConvertTodecimal(ds.Tables[0].Rows[0]["NetPrice"]);
                    result.HasJacket = DataAccessHelper.ConvertToBool(ds.Tables[0].Rows[0]["HasJacket"]);

                    //Get Cart List, include grid data if any.
                    var duplicateCarts = new List<DuplicateCartRef>();

                    foreach (DataRow row in ds.Tables[1].Rows)
                    {
                        //var cartStatus = DataAccessHelper.ConvertCartStatus(row["BasketStateId"]);
                        //// in case get primary cart, there is no DeletedDateTime column returned
                        //if (row["DeletedDateTime"] != DBNull.Value)
                        //    cartStatus = CartStatus.Deleted.ToString();

                        var cart = new DuplicateCartRef
                        {
                            CartId = DataAccessHelper.ConvertToString(row["BasketSummaryID"]),
                            LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemId"]),
                            CartName = DataAccessHelper.ConvertToString(row["CartName"]),
                            Quantity = DataAccessHelper.ConvertToInt(row["TitleQty"]),
                            OwnerName = DataAccessHelper.ConvertToString(row["Owner"]),
                            ERPAccountNumber = DataAccessHelper.ConvertToString(row["Account"]),
                            CartStatus = DataAccessHelper.ConvertToString(row["CartStatus"]),
                            LastUpdated = DataAccessHelper.ConvertToDateTime(row["LastUpdated"]),
                            PurchaseOrderNumber = DataAccessHelper.ConvertToString(row["PONumber"])
                        };
                        //cart.GridData = CreateDummyDataForGrid();

                        if (ds.Tables.Count == 4)
                        {
                            cart.GridData = ds.Tables[2].Clone();
                            //
                            GatherGridData(ds, cart);
                        }

                        // get user note rows
                        var userNoteRows = ds.Tables[ds.Tables.Count - 1].Select(string.Format("BasketSummaryID='{0}'", cart.CartId));
                        cart.UserNotes = new List<CartUserNote>();
                        foreach (var userNoteRow in userNoteRows)
                        {
                            var userNote = new CartUserNote();
                            userNote.UserId = DataAccessHelper.ConvertToString(userNoteRow["User_Id"]);
                            userNote.UserNote = DataAccessHelper.ConvertToString(userNoteRow["Note"]);
                            var dateModified = DataAccessHelper.ConvertToDateTime(userNoteRow["UpdatedDateTime"]);
                            if (dateModified != null)
                                userNote.DateModified = dateModified.Value;

                            cart.UserNotes.Add(userNote);
                        }

                        //for (int i = 0; i < 10; i++)
                        //{
                        //    var userNote = new CartUserNote();
                        //    userNote.UserId = string.Format("UserIdDummy{0}", i);
                        //    userNote.UserNote = string.Format("UserNoteDummy{0}", i);
                        //    userNote.DateModified = DateTime.Now.AddDays(i);

                        //    cart.UserNotes.Add(userNote);
                        //}

                        duplicateCarts.Add(cart);
                    }

                    result.DuplicateCarts = duplicateCarts.OrderBy(r => r.CartName).ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        private static void GatherGridData(DataSet ds, DuplicateCartRef cart)
        {
            var gridDataTableForCart =
                ds.Tables[2].Select(string.Format("BasketSummaryID='{0}'", cart.CartId));
            for (int i = gridDataTableForCart.Length - 1; i >= 0; i--)
            {
                var gridRow = gridDataTableForCart[i];
                cart.GridData.ImportRow((gridRow));
            }

            // remove redundant columns
            cart.GridData.Columns.Remove("BasketSummaryID");
            var removableCols = new List<string>();

            var dictRemoveCols = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            for (var i = 0; i < cart.GridData.Rows.Count; i++)
            {
                for (var j = 0; j < cart.GridData.Columns.Count; j++)
                {
                    var itemData = cart.GridData.Rows[i][j];

                    if (itemData != null && itemData != DBNull.Value) continue;

                    var colName = cart.GridData.Columns[j].ColumnName;

                    if (dictRemoveCols.ContainsKey(colName))
                    {
                        dictRemoveCols[colName] += 1;
                    }
                    else
                    {
                        dictRemoveCols.Add(colName, 1);
                    }
                }
            }

            var totalRowCount = cart.GridData.Rows.Count;
            foreach (var dictRemoveCol in dictRemoveCols)
            {
                if (dictRemoveCol.Value != totalRowCount) continue;
                if (!removableCols.Contains(dictRemoveCol.Key))
                {
                    removableCols.Add(dictRemoveCol.Key);
                }
            }
            foreach (var removableCol in removableCols)
            {
                cart.GridData.Columns.Remove(removableCol);
            }
        }

        private static DataTable CreateDummyDataForGrid()
        {
            var gridData = new DataTable();

            for (int i = 0; i < 3; i++)
            {
                var col = new DataColumn();
                col.ColumnName = string.Format("Column Name {0}", i);
                col.DataType = typeof(string);
                gridData.Columns.Add(col);
            }

            for (int i = 0; i < 5; i++)
            {
                var newRow = gridData.NewRow();
                newRow[0] = "Col 0 Value";
                newRow[1] = "Col 1 Value";
                newRow[2] = "Col 2 Value";
                gridData.Rows.Add(newRow);
            }

            return gridData;
        }

        internal static DuplicateCartTitle GetDuplicateOrderReferences(string cartId, string itemKey, string orgId,
    string downloadCheckType, string userId, string cartCheckType, string orderCheckType)
        {
            var result = new DuplicateCartTitle();
            try
            {
                var ds = CartDAO.Instance.GetDuplicateOrderReferences(itemKey, orgId, cartId, downloadCheckType, userId, cartCheckType, orderCheckType);
                if (ds != null && ds.Tables.Count > 1)
                {
                    //Get Title Information data.
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        result.Title = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Title"]);
                        result.Author = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Author"]);
                        result.ISBN = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["ISBN"]);
                        result.Format = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Format"]);
                        result.Publisher = DataAccessHelper.ConvertToString(ds.Tables[0].Rows[0]["Publisher"]);
                        result.PublishDate = DataAccessHelper.ConvertToDateTime(ds.Tables[0].Rows[0]["PublicationDate"]);
                        result.HasJacket = DataAccessHelper.ConvertToBool(ds.Tables[0].Rows[0]["HasJacket"]);
                    }

                    var duplicateOrders = new List<DuplicateOrderRef>();
                    foreach (DataRow row in ds.Tables[2].Rows)
                    {
                        DateTime? orderDate = null;
                        if (!string.IsNullOrEmpty(row["OrderDate"].ToString()))
                        {
                            orderDate = DataAccessHelper.ConvertToDateTime(row["OrderDate"]);
                        }

                        var cart = new DuplicateOrderRef
                                   {
                                       CartId = DataAccessHelper.ConvertToString(row["BasketSummaryId"]),
                                       OrderDate = orderDate,
                                       PurchaseOrderNumber = DataAccessHelper.ConvertToString(row["PONumber"]),
                                       ERPAccountNumber = DataAccessHelper.ConvertToString(row["Account"]),
                                       TotalOrdered = DataAccessHelper.ConvertToInt(row["TotalOrdered"]),
                                       ShippedQuantity = DataAccessHelper.ConvertToInt(row["Shipped"]),
                                       //#37351: Adding Invoice and ATS numbers
                                       InvoiceNumber = DataAccessHelper.ConvertToString(row["Invoice"]),
                                       ATSNumber = DataAccessHelper.ConvertToString(row["ATS"]),
                                       CancelledQuantity = DataAccessHelper.ConvertToInt(row["Cancelled"]),
                                       BackOrderedQuantity = DataAccessHelper.ConvertToInt(row["BackOrdered"]),
                                       InProcessQuantity = DataAccessHelper.ConvertToInt(row["InProcess"]),
                                       OnSaleDateHoldQuantity = 0,
                                       RevervedAwaitingReleaseQuantity = DataAccessHelper.ConvertToInt(row["RevervedAwaitingRelease"]),
                                       BinAndHoldDays = DataAccessHelper.ConvertToIntNullable(row["BinAndHoldDays"])
                                   };
                        duplicateOrders.Add(cart);
                    }

                    result.DuplicateOrders = duplicateOrders.OrderBy(r => r.OrderDate).ToList();

                    //var resultSetCartId = result.DuplicateOrders[0].CartId;

                    // Populate Ordered Cart Info
                    result.OrderedCartInfos = new List<OrderedCartInfo>();

                    var listBasketId = new List<string>();
                    foreach (DataRow dataRow in ds.Tables[1].Rows)
                    {
                        var basketId = dataRow["BasketSummaryId"].ToString();
                        if (!listBasketId.Contains(basketId))
                        {
                            listBasketId.Add(basketId);
                        }
                    }

                    foreach (var basketId in listBasketId)
                    {
                        var orderedCartInfoRows = ds.Tables[1].Select(string.Format("BasketSummaryId='{0}'", basketId));
                        foreach (var orderedCartInfoRow in orderedCartInfoRows)
                        {
                            var orderedInfo = new OrderedCartInfo();
                            orderedInfo.CartId = basketId;
                            orderedInfo.CartName = DataAccessHelper.ConvertToString(orderedCartInfoRow["CartName"]);
                            orderedInfo.Quantity = DataAccessHelper.ConvertToInt(orderedCartInfoRow["TitleQty"]);
                            orderedInfo.OwnerUserName = DataAccessHelper.ConvertToString(orderedCartInfoRow["OwnerName"]);
                            orderedInfo.OwnerUserId = DataAccessHelper.ConvertToString(orderedCartInfoRow["BasketOwnerID"]);
                            orderedInfo.IsShared = DataAccessHelper.ConvertToBool(orderedCartInfoRow["IsShared"]);
                            orderedInfo.PurchaseOrderNumber = DataAccessHelper.ConvertToString(orderedCartInfoRow["PurchaseOrder"]);
                            orderedInfo.AccountNumber = DataAccessHelper.ConvertToString(orderedCartInfoRow["Account"]);
                            orderedInfo.CartStatus = DataAccessHelper.ConvertToString(orderedCartInfoRow["CartStatus"]);
                            var lastUpdated = DataAccessHelper.ConvertToDateTime(orderedCartInfoRow["LastUpdated"]);
                            if (lastUpdated != null)
                                orderedInfo.LastUpdated = lastUpdated.Value;
                            //
                            GetOrderInfoFromDataSet(orderedInfo, ds, basketId);
                            // 
                            GetUserNotesFromDataSet(orderedInfo, ds, basketId);

                            GetGridDataFromDataSet(orderedInfo, ds, basketId);

                            result.OrderedCartInfos.Add(orderedInfo);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        private static void GetOrderInfoFromDataSet(OrderedCartInfo orderedInfo, DataSet ds, string cartId)
        {
            orderedInfo.OrderInfos = new List<OrderInfo>();

            var orderInfoRows = ds.Tables[3].Select(string.Format("BasketSummaryID='{0}'", cartId));
            foreach (var orderInfo in orderInfoRows)
            {
                var of = new OrderInfo();
                of.OrderNumber = DataAccessHelper.ConvertToString(orderInfo["OrderNumber"]);
                of.WarehouseCode = DataAccessHelper.ConvertToString(orderInfo["Warehouse"]);
                of.ShippedQuantity = DataAccessHelper.ConvertToInt(orderInfo["Shipped"]);
                of.InProcessQuantity = DataAccessHelper.ConvertToInt(orderInfo["InProcess"]);
                of.CancelledQuantity = DataAccessHelper.ConvertToInt(orderInfo["Cancelled"]);
                of.BackOrderedQuantity = DataAccessHelper.ConvertToInt(orderInfo["BackOrdered"]);
                of.RevervedAwaitingReleaseQuantity = DataAccessHelper.ConvertToInt(orderInfo["RevervedAwaitingRelease"]);

                orderedInfo.OrderInfos.Add(of);
            }
        }

        private static void GetUserNotesFromDataSet(OrderedCartInfo orderedInfo, DataSet ds, string cartId)
        {
            orderedInfo.UserNotes = new List<CartUserNote>();

            var userNoteRows = ds.Tables[ds.Tables.Count - 1].Select(string.Format("BasketSummaryID='{0}'", cartId));
            foreach (var userNoteRow in userNoteRows)
            {
                var userNote = new CartUserNote();
                userNote.UserId = DataAccessHelper.ConvertToString(userNoteRow["user_id"]);
                userNote.UserNote = DataAccessHelper.ConvertToString(userNoteRow["Note"]);
                var dateModified = DataAccessHelper.ConvertToDateTime(userNoteRow["UpdatedDateTime"]);
                if (dateModified != null)
                    userNote.DateModified = dateModified.Value;

                orderedInfo.UserNotes.Add(userNote);
            }
        }

        private static void GetGridDataFromDataSet(OrderedCartInfo orderedInfo, DataSet ds, string cartId)
        {
            if (ds.Tables.Count < 6) return;

            orderedInfo.GridData = ds.Tables[4].Clone();
            var gridDataTableForCart = ds.Tables[4].Select(string.Format("BasketSummaryID='{0}'", cartId));

            for (int i = gridDataTableForCart.Length - 1; i >= 0; i--)
            {
                var gridRow = gridDataTableForCart[i];
                orderedInfo.GridData.ImportRow((gridRow));
            }

            // remove redundant columns
            orderedInfo.GridData.Columns.Remove("BasketSummaryID");
            var removableCols = new List<string>();

            var dictRemoveCols = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < orderedInfo.GridData.Rows.Count; i++)
            {
                for (var j = 0; j < orderedInfo.GridData.Columns.Count; j++)
                {
                    var itemData = orderedInfo.GridData.Rows[i][j];

                    if (itemData != null && itemData != DBNull.Value) continue;

                    var colName = orderedInfo.GridData.Columns[j].ColumnName;

                    if (dictRemoveCols.ContainsKey(colName))
                    {
                        dictRemoveCols[colName] += 1;
                    }
                    else
                    {
                        dictRemoveCols.Add(colName, 1);
                    }
                }
            }
            var totalRowCount = orderedInfo.GridData.Rows.Count;
            foreach (var dictRemoveCol in dictRemoveCols)
            {
                if (dictRemoveCol.Value != totalRowCount) continue;
                if (!removableCols.Contains(dictRemoveCol.Key))
                {
                    removableCols.Add(dictRemoveCol.Key);
                }
            }
            foreach (var removableCol in removableCols)
            {
                orderedInfo.GridData.Columns.Remove(removableCol);
            }
        }

        internal static Dictionary<string, List<OrderedLineItems>> GetOrderedLineItems(string basketId)
        {
            var result = new Dictionary<string, List<OrderedLineItems>>();
            try
            {
                var ds = CartDAO.Instance.GetOrderedLineItems(basketId);

                if (ds != null && ds.Tables.Count > 0)
                {
                    var rows = ds.Tables[0].Rows;
                    foreach (DataRow row in rows)
                    {
                        var orderLine = CreateOrderedLineItemFromDataRow(row);
                        if (result.ContainsKey(orderLine.LineItemId))
                        {
                            result[orderLine.LineItemId].Add(orderLine);
                        }
                        else
                        {
                            result.Add(orderLine.LineItemId, new List<OrderedLineItems> { orderLine });
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        internal static Dictionary<string, List<OrderedLineItems>> GetBasketLineItemOrderStatus(List<string> lineItemIds)
        {
            var result = new Dictionary<string, List<OrderedLineItems>>();
            try
            {
                var ds = CartDAO.Instance.GetBasketLineItemOrderStatus(lineItemIds);

                if (ds != null && ds.Tables.Count > 0)
                {
                    var rows = ds.Tables[0].Rows;
                    foreach (DataRow row in rows)
                    {
                        var orderLine = CreateBasketLineItemOrderStatusFromDataRow(row);
                        if (result.ContainsKey(orderLine.LineItemId))
                        {
                            result[orderLine.LineItemId].Add(orderLine);
                        }
                        else
                        {
                            result.Add(orderLine.LineItemId, new List<OrderedLineItems> { orderLine });
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        internal static List<OrderedLineItems> GetOrderedLineItems(string basketId, string btKey)
        {
            var result = new List<OrderedLineItems>();
            try
            {
                var ds = CartDAO.Instance.GetOrderedLineItems(basketId);

                if (ds != null && ds.Tables.Count > 0)
                {
                    var rows = ds.Tables[0].Rows;
                    result.AddRange(
                        rows.Cast<DataRow>().Select(CreateOrderedLineItemFromDataRow).Where(
                            orderLine => orderLine.BTKey == btKey));
                }
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }

        internal static DuplicateCartReference CreateDupCartRefFromDataRow(DataRow row)
        {
            var cartStatus = DataAccessHelper.ConvertCartStatus(row["BasketStateID"]);
            // in case get primary cart, there is no DeletedDateTime column returned
            if (row["DeletedDateTime"] != DBNull.Value)
                cartStatus = CartStatus.Deleted.ToString();
            var cart = new DuplicateCartReference
            {
                CartId = DataAccessHelper.ConvertToString(row["BasketSummaryId"]),
                CartName = DataAccessHelper.ConvertToString(row["BasketName"]),
                SoldToId = DataAccessHelper.ConvertToString(row["BasketOwnerID"]),
                //TFS #7299 get SoldToName from db
                SoldToName = DataAccessHelper.ConvertToString(row["BasketOwnerName"]),
                // END #7299
                CartStatus = cartStatus,
                LastUpdated = DataAccessHelper.ConvertToDateTime(row["UpdatedDateTime"]),
                ERPAccountNumber = DataAccessHelper.ConvertToString(row["AccountId"]),
                AccountType = DataConverter.GetOldAccountTypeID(DataAccessHelper.ConvertToInt(row["BasketAccountTypeID"])),
                Quantity = DataAccessHelper.ConvertToInt(row["Quantity"]),
                LineItemId = DataAccessHelper.ConvertToString(row["BasketLineItemId"]),
                SalePrice = DataAccessHelper.ConvertTodecimal(row["SalePrice"])
            };

            return cart;
        }

        internal static OrderedLineItems CreateOrderedLineItemFromDataRow(DataRow reader)
        {
            return new OrderedLineItems
            {
                BasketId = DataAccessHelper.ConvertToString(reader["BasketSummaryID"]),
                BTKey = DataAccessHelper.ConvertToString(reader["BTKey"]),
                ProductType = DataAccessHelper.ConvertToString(reader["ProductType"]),
                LineItemId = DataAccessHelper.ConvertToString(reader["BasketLineItemId"]),
                OrderNumber = DataAccessHelper.ConvertToString(reader["OrderNumber"]),
                ShippedQuantity = DataAccessHelper.ConvertToInt(reader["BTShippedQuantity"]),
                CancelledQuantity = DataAccessHelper.ConvertToInt(reader["BTCancelledQuantity"]),
                InProcessQuantity = DataAccessHelper.ConvertToInt(reader["BTInProcessQuantity"]),
                BackOrderedQuantity = DataAccessHelper.ConvertToInt(reader["BTBackOrderedQuantity"]),
                ReversedAwaitingReleaseQuantity = DataAccessHelper.ConvertToInt(reader["BTRevervedAwaitingReleaseQuantity"]),
                TotalOrderedQuantity = DataAccessHelper.ConvertToInt(reader["TotalOrderedQuantity"]),
                OnSaleDateHoldQuantity = 0,//Not support in R1
                WareHouse = DataAccessHelper.ConvertToString(reader["BTWarehouse"]),
                PONumber = DataAccessHelper.ConvertToString(reader["PONumber"]),
                BTOrderDate = DataAccessHelper.ConvertToString(reader["BTOrderDate"])
            };
        }

        internal static OrderedLineItems CreateBasketLineItemOrderStatusFromDataRow(DataRow reader)
        {
            return new OrderedLineItems
            {
                LineItemId = DataAccessHelper.ConvertToString(reader["BasketLineItemId"]),
                OrderNumber = DataAccessHelper.ConvertToString(reader["OrderNumber"]),
                ShippedQuantity = DataAccessHelper.ConvertToInt(reader["ShippedQuantity"]),
                CancelledQuantity = DataAccessHelper.ConvertToInt(reader["CancelledQuantity"]),
                InProcessQuantity = DataAccessHelper.ConvertToInt(reader["InProcessQuantity"]),
                BackOrderedQuantity = DataAccessHelper.ConvertToInt(reader["BackOrderedQuantity"]),
                ReversedAwaitingReleaseQuantity = DataAccessHelper.ConvertToInt(reader["ReservedQuantity"]),
                WareHouse = DataAccessHelper.ConvertToString(reader["Warehouse"]),
                BTOrderDate = DataAccessHelper.ConvertToString(reader["OrderDate"])
            };
        }

        internal static void SubmitCart(Cart cart, string userId, string loggedInUserId, out string newBasketName, out string newBasketId, out string newOEBasketName, out string newOEBasketID, bool isVIP, bool isOrderAndHold, string orderedDownloadedUserId)
        {
            newBasketName = string.Empty;
            newBasketId = string.Empty;
            newOEBasketName = string.Empty;
            newOEBasketID = string.Empty;
            try
            {
                var accountDict = GetCartAccountDictionary(cart.CartAccounts);

                var orderForm = cart.OrderForm;
                var orderFormInfo = new Dictionary<string, string>();

                if (orderForm.HandlingTotal.HasValue) orderFormInfo.Add("HandlingTotal", orderForm.HandlingTotal.ToString());
                if (orderForm.ShippingTotal.HasValue) orderFormInfo.Add("ShippingTotal", orderForm.ShippingTotal.ToString());
                if (orderForm.SubTotal.HasValue) orderFormInfo.Add("SubTotal", orderForm.SubTotal.ToString());
                if (orderForm.TaxTotal.HasValue) orderFormInfo.Add("TaxTotal", orderForm.TaxTotal.ToString());
                if (orderForm.Total.HasValue) orderFormInfo.Add("Total", orderForm.Total.ToString());

                orderFormInfo.Add("IsHomeDelivery", orderForm.IsHomeDelivery.ToString());

                //orderFormInfo.Add("AddressID", orderForm.AddressID);
                orderFormInfo.Add("AddressLine1", orderForm.AddressLine1 ?? string.Empty);
                orderFormInfo.Add("AddressLine2", orderForm.AddressLine2 ?? string.Empty);
                orderFormInfo.Add("AddressLine3", orderForm.AddressLine3 ?? string.Empty);
                orderFormInfo.Add("AddressLine4", orderForm.AddressLine4 ?? string.Empty);
                orderFormInfo.Add("IsPoBox", orderForm.IsPoBox.ToString());
                orderFormInfo.Add("City", orderForm.City ?? string.Empty);
                orderFormInfo.Add("RegionCode", orderForm.RegionCode ?? string.Empty);
                orderFormInfo.Add("PostalCode", orderForm.PostalCode ?? string.Empty);
                orderFormInfo.Add("CountryCode", orderForm.CountryCode ?? string.Empty);
                orderFormInfo.Add("TelNumber", orderForm.TelNumber ?? string.Empty);
                orderFormInfo.Add("EmailAddress", orderForm.EmailAddress ?? string.Empty);

                orderFormInfo.Add("BTGiftWrapCode", orderForm.BTGiftWrapCode ?? string.Empty);
                orderFormInfo.Add("BTGiftWrapString", orderForm.BTGiftWrapString ?? string.Empty);

                orderFormInfo.Add("HasStoreShippingFee", orderForm.HasStoreShippingFee.ToString());
                orderFormInfo.Add("HasStoreGiftWrapFee", orderForm.HasStoreGiftWrapFee.ToString());
                orderFormInfo.Add("HasStoreProccessingFee", orderForm.HasStoreProccessingFee.ToString());
                orderFormInfo.Add("HasStoreOrderFee", orderForm.HasStoreOrderFee.ToString());

                orderFormInfo.Add("ShippingMethodExtID", orderForm.ShippingMethodExtID ?? string.Empty);
                orderFormInfo.Add("BTCarrierCode", orderForm.BTCarrierCode ?? string.Empty);
                orderFormInfo.Add("BTShippingMethodGuid", orderForm.BTShippingMethodGuid ?? string.Empty);
                orderFormInfo.Add("BackOrderIndicator", orderForm.IsBackOrder.ToString());
                orderFormInfo.Add("Name", orderForm.Name ?? string.Empty);
                orderFormInfo.Add("CostSummaryByExtAdmin", orderForm.CostSummaryByExtAdmin ?? string.Empty);
                orderFormInfo.Add("CostSummaryByIntAdmin", orderForm.CostSummaryByIntAdmin ?? string.Empty);

                CartDAO.Instance.SubmitCart(cart.CartId, userId, loggedInUserId, orderFormInfo, accountDict, cart.SpecialInstruction,
                                            out newBasketName, out newBasketId, out newOEBasketName, out newOEBasketID, isVIP, isOrderAndHold, orderedDownloadedUserId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        internal static OrderForm GetStoreAndCustomerView(string cartId)
        {
            try
            {
                var orderFormDs = CartDAO.Instance.GetStoreAndCustomerView(cartId);

                return GetStoreAndCustomerViewFromDataSet(orderFormDs);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
            return null;
        }

        private static OrderForm GetStoreAndCustomerViewFromDataSet(DataSet ds)
        {
            if (ds == null) return null;
            if (ds.Tables.Count < 4) return null;

            var totalTable = ds.Tables[0];
            var addressTable = ds.Tables[1];
            var accountTable = ds.Tables[2];
            var creditCartTable = ds.Tables[3];

            OrderForm orderform = null;
            if (totalTable.Rows.Count > 0)
            {
                var row = totalTable.Rows[0];

                orderform = new OrderForm()
                {
                    HandlingTotal = DataAccessHelper.ConvertTodecimal(row["HandlingTotal"]),
                    ShippingTotal = DataAccessHelper.ConvertTodecimal(row["ShippingTotal"]),
                    SubTotal = DataAccessHelper.ConvertTodecimal(row["SubTotal"]),
                    TaxTotal = DataAccessHelper.ConvertTodecimal(row["TaxTotal"]),
                    Total = DataAccessHelper.ConvertTodecimal(row["Total"]),
                    IsHomeDelivery = DataAccessHelper.ConvertToBool(row["IsHomeDelivery"]),
                };

                if (addressTable.Rows.Count > 0)
                {
                    row = addressTable.Rows[0];
                    orderform.AddressID = DataAccessHelper.ConvertToString(row["Address_ID"]);
                    orderform.AddressLine1 = DataAccessHelper.ConvertToString(row["Line1"]);
                    orderform.AddressLine2 = DataAccessHelper.ConvertToString(row["Line2"]);
                    orderform.AddressLine3 = DataAccessHelper.ConvertToString(row["Line3"]);
                    orderform.AddressLine4 = DataAccessHelper.ConvertToString(row["Line4"]);
                    orderform.IsPoBox = DataAccessHelper.ConvertToBool(row["IsPOBox"]);
                    orderform.City = DataAccessHelper.ConvertToString(row["City"]);
                    orderform.RegionCode = DataAccessHelper.ConvertToString(row["Region_Code"]);
                    orderform.PostalCode = DataAccessHelper.ConvertToString(row["Postal_Code"]);
                    orderform.CountryCode = DataAccessHelper.ConvertToString(row["Country_Code"]);
                    orderform.TelNumber = DataAccessHelper.ConvertToString(row["tel_number"]);
                    orderform.EmailAddress = DataAccessHelper.ConvertToString(row["email_address"]);

                    orderform.ShippingMethodExtID = DataAccessHelper.ConvertToString(row["ShippingMethodExtID"]);
                    orderform.BTCarrierCode = DataAccessHelper.ConvertToString(row["BTCarrierCode"]);
                    orderform.BTShippingMethodGuid = DataAccessHelper.ConvertToString(row["BTShippingMethodGuid"]);

                    orderform.HasStoreShippingFee = DataAccessHelper.ConvertToBool(row["HasStoreShippingFee"]);
                    orderform.HasStoreGiftWrapFee = DataAccessHelper.ConvertToBool(row["HasStoreGiftWrapFee"]);
                    orderform.HasStoreProccessingFee = DataAccessHelper.ConvertToBool(row["HasStoreProccessingFee"]);
                    orderform.HasStoreOrderFee = DataAccessHelper.ConvertToBool(row["HasStoreOrderFee"]);

                    orderform.BTGiftWrapCode = DataAccessHelper.ConvertToString(row["BTGiftWrapCode"]);
                    orderform.BTGiftWrapString = DataAccessHelper.ConvertToString(row["BTGiftWrapMessage"]);
                }

                if (accountTable.Rows.Count > 0)
                {
                    row = accountTable.Rows[0];
                    orderform.CartAccount.AccountERPNumber = DataAccessHelper.ConvertToString(row["AccountERPNumber"]);
                    orderform.CartAccount.AccountAlias = DataAccessHelper.ConvertToString(row["AccountAlias"]);
                    orderform.CartAccount.AccountType = DataAccessHelper.ConvertToInt(row["AccountType"]);
                    orderform.CartAccount.AccountID = DataAccessHelper.ConvertToString(row["AccountId"]);
                }

                if (creditCartTable.Rows.Count > 0)
                {
                    row = creditCartTable.Rows[0];
                    orderform.CreditCard.CreditCardId = DataAccessHelper.ConvertToString(row["CreditCardId"]);
                    orderform.CreditCard.ExpirationYear = DataAccessHelper.ConvertToInt(row["ExpirationYear"]);
                    orderform.CreditCard.ExpirationMonth = DataAccessHelper.ConvertToInt(row["ExpirationMonth"]);
                    orderform.CreditCard.CreditCardNumber = DataAccessHelper.ConvertToString(row["CreditCardNumber"]);
                    orderform.CreditCard.CreditCardIdentifier = DataAccessHelper.ConvertToString(row["CreditCardIdentifier"]);
                    orderform.CreditCard.BTCreditCardToken = DataAccessHelper.ConvertToString(row["BTCreditCardToken"]);
                    orderform.CreditCard.Alias = DataAccessHelper.ConvertToString(row["Alias"]);
                    orderform.CreditCard.CreditCardType = DataAccessHelper.ConvertToString(row["CreditCardType"]);
                    orderform.CreditCard.BillingAddressId = DataAccessHelper.ConvertToString(row["BillingAddressId"]);
                }
            }

            return orderform;
        }


        #endregion

        #region Exception Handlers
        private static void HandleSqlException(SqlException exception)
        {
            Logger.LogException(exception);
            throw exception;
        }
        #endregion

        #region Helper Methods
        internal static string GenerateNewBasketName(string basketName, string userId)
        {
            var result = string.Empty;
            try
            {
                return result = CartDAO.Instance.GenerateNewBasketName(basketName, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }
        internal static string GenerateNewBasketNameForUser(string basketName, string userId)
        {
            var result = string.Empty;
            try
            {
                return result = CartDAO.Instance.GenerateNewBasketNameForUser(basketName, userId);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return result;
        }
        #endregion

        internal static bool SaveOriginalEntry(string cartId, OriginalEntry originalEntry, string pOLine, string bib, string userId, string note, out int addedQuantity)
        {
            try
            {
                var result = CartDAO.Instance.SaveOriginalEntry(cartId, originalEntry, null, pOLine,
                                                                         bib, note, userId, false, out addedQuantity);
                return result;
            }
            catch (SqlException sqlEx)
            {
                addedQuantity = -1;
                HandleSqlException(sqlEx);
            }

            return false;
        }

        internal static bool SaveOriginalEntryWithGrid(string cartId, OriginalEntry originalEntry, List<CommonCartGridLine> cartGridLines, string pOLine, string bib, string note, string userId, out int addedQuantity)
        {
            try
            {
                bool result = CartDAO.Instance.SaveOriginalEntry(cartId, originalEntry, cartGridLines, pOLine,
                                                                         bib, note, userId, true, out addedQuantity);
                return result;
            }
            catch (SqlException sqlEx)
            {
                addedQuantity = -1;
                HandleSqlException(sqlEx);
            }

            return false;
        }

        internal static bool DragAndDropCartFolder(string sourceFolderId, string destinationFolderId, string position)
        {
            try
            {
                var result = CartDAO.Instance.DragAndDropCartFolder(sourceFolderId, destinationFolderId, position);
                return result;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return false;
        }

        internal static void RequestCartQuote(string cartID, string userID)
        {
            try
            {
                CartDAO.Instance.RequestCartQuote(cartID, userID);
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }
        }

        public static Cart GetCartByIdForSubmitting(string cartId, string userId)
        {
            Cart cart = null;

            if (string.IsNullOrEmpty(cartId)) return null;

            try
            {
                int nonRankedCount = 0;
                var cartDs = CartDAO.Instance.GetCartForSubmitting(cartId, userId, out nonRankedCount);
                cart = GetCartSummaryFromDataSet(cartDs);
                cart.NonRankedCount = nonRankedCount;
            }
            catch (SqlException sqlEx)
            {
                HandleSqlException(sqlEx);
            }

            return cart;
        }
    }
}
