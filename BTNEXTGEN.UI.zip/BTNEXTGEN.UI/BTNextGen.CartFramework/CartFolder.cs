﻿using System;
using System.Collections.Generic;
using System.Data;
using BTNextGen.Commerce.Portal.Common.DataAccessObject;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BT.TS360Constants;

namespace BTNextGen.CartFramework
{
    public class CartFolder: BaseCartFolder
    {
        #region Constructor

        /// <summary>
        /// Cart Folder
        /// </summary>
        /// <param name="cartFolderId"></param>
        public CartFolder(string cartFolderId)
        {
            this.CartFolderId = cartFolderId;
        }

        public CartFolder(string cartFolderId, string userId, string orgId)
            :this(cartFolderId)
        {
            this.UserId = userId;
            this.OrgId = orgId;
        }

        public static CartFolder CreateCartFolderFromDataRow(DataRow dr)
        {
            try
            {
                var cartFolder = new CartFolder(dr["UserFolderID"] as string)
                {
                    CartFolderName = dr["Literal"] as string,
                    ParentFolderId = dr["ParentUserFolderID"] as string,
                    UserId = dr["u_user_id"] as string,
                    FolderType = CartDAO.ConvertToFolderType(dr["UserFolderTypeID"]),
                    Sequence = (float)DataAccessHelper.ConvertTodouble(dr["Sequence"]),
                    TotalCarts = DataAccessHelper.ConvertToInt(dr["BasketCount"])
                };
                return cartFolder;
            }
            catch (Exception exception)
            {
                Logger.LogException(exception);
                throw;
            }
            return null;
        }
        #endregion

        #region Internal Methods
        /// <summary>
        /// Create Cart Folder
        /// </summary>
        /// <param name="name"></param>
        /// <param name="parentId"></param>
        /// <param name="cartFolderType"></param>
        /// <param name="sequenceNo"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        internal static CartFolder CreateCartFolder(string name, string parentId, CartFolderType cartFolderType, float sequenceNo, string userId)
        {
            var cartFolder = CartDAOManager.CreateCartFolder(name, parentId, cartFolderType, sequenceNo, userId);

            cartFolder.NotifyCartFolderChanged();

            return cartFolder;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Delete
        /// Should provider user id when constructoring CartFolder instance before using this function.
        /// </summary>
        public void Delete()
        {
            CartDAOManager.DeleteCartFolder(this.CartFolderId, this.UserId);

            this.NotifyCartFolderChanged();

            this.NotifyCartsChanged();
        }

        /// <summary>
        /// Move To
        /// </summary>
        /// <param name="parentCartFolderId"></param>
        public void MoveTo(string parentCartFolderId)
        {
            CartDAOManager.MoveCartFolder(this.CartFolderId, parentCartFolderId, this.UserId);

            this.NotifyCartFolderChanged();
        }

        ///// <summary>
        ///// Archive
        ///// </summary>
        //public void Archive()
        //{
        //    CartDAOManager.ArchiveCartFolder(this.CartFolderId, this.UserId);

        //    this.NotifyCartFolderChanged();
        //}

        /// <summary>
        /// Rename
        /// </summary>
        /// <param name="newCartFolderName"></param>
        public void Rename(string newCartFolderName)
        {
            CartDAOManager.Rename(this.CartFolderId, newCartFolderName, this.UserId);

            this.NotifyCartFolderChanged();
        }

        /// <summary>
        /// Update Sequence
        /// </summary>
        /// <param name="sequenceNo"></param>
        public void UpdateSequence(float sequenceNo)
        {
            CartDAOManager.UpdateSequenceCartFolder(this.CartFolderId, sequenceNo, this.UserId);

            this.NotifyCartFolderChanged();
        }

        /// <summary>
        /// Get carts in folder
        /// </summary>
        /// <returns></returns>
        public Carts GetCarts()
        {
            return CartDAOManager.GetCarts(this.CartFolderId);
        }

        public List<Cart> GetCartsLite(out int totalCarts)
        {
            return CartDAOManager.GetCartsLite(this.CartFolderId, out totalCarts);            
        }
        
        #endregion

        #region Public Properties

        /// <summary>
        /// Cart Folder Id
        /// </summary>
        public string CartFolderId { get; set;}

        public string CartFolderName { get; set; }

        public string ParentFolderId { get; set; }

        public CartFolderType? FolderType { get; set; }

        public string UserId { get; set; }

        public string OrgId { get; set; }

        public float Sequence { get; set; }

        public int TotalCarts { get; set; }
        
        #endregion

        #region Public Constants

        public const string DataTextFieldOfTree = "CartFolderName";
        /// <summary>
        /// The Data Value Field of RadTreeView
        /// </summary>
        public const string DataValueFieldOfTree = "CartFolderId";
        /// <summary>
        /// The Data Value Field of parent node RadTreeView
        /// </summary>
        public const string DataParentIdValueFieldOfTree = "ParentFolderId";

        #endregion
        internal override void NotifyCartFolderChanged()
        {
            CartCacheManager.SetCartFolderDistributedCacheExpired(new List<string>() { this.UserId });
        }

        internal override void NotifyCartsChanged()
        {
            NotifyPrimaryCartChanged();
            NotifyTopNewestCartsChanged();
        }

        internal override void NotifyPrimaryCartChanged()
        {
            CartCacheManager.SetPrimaryCartCacheExpired(this.UserId);
        }

        internal override void NotifyTopNewestCartsChanged()
        {
            CartCacheManager.SetTopNewestCartCacheExpired(this.UserId);
        }
        #region BTNextGen Custom

        #region System Defined Folder Name
        /// <summary>
        /// The name of the Root Folder
        /// </summary>
        /// <value>Default Folder</value>
        public static string DefaultFolderName = "Default Folder";

        /// <summary>
        /// Ordered Folder Name
        /// </summary>
        //public static string OrderedFolderName = "Ordered & Submitted Carts";
        public static string OrderedFolderName
        {
            get
            {
                return ResourceHelper.GetLocalizedString("OrderResources", "CartFolder_OrderAndSummitedFolder");
            }
        }
        /// <summary>
        /// BTCart Folder Name
        /// </summary>
        //public static string BtcartFolderName = "B&T Carts/First Look Carts";
        public static string BtcartFolderName
        {
            get
            {
                return ResourceHelper.GetLocalizedString("OrderResources", "CartFolder_BTFirstLookFolder");
            }
        }
        /// <summary>
        /// Archived Folder Name
        /// </summary>
        //public static string ArchivedFolderName = "Archived";
        public static string ArchivedFolderName
        {
            get
            {
                return ResourceHelper.GetLocalizedString("OrderResources", "CartFolder_ArchivedFolder");
            }
        }
        /// <summary>
        /// Deleted Folder Name
        /// </summary>
        //public static string DeletedFolderName = "Deleted";
        public static string DeletedFolderName
        {
            get
            {
                return ResourceHelper.GetLocalizedString("OrderResources", "CartFolder_DeletedFolder");
            }
        }

        public static string SharedReceivedFolderName
        {
            get
            {
                return ResourceHelper.GetLocalizedString("OrderResources", "CartFolder_SharedReceived");
            }
        }

        public static string ReceivedFolderName
        {
            get
            {
                return "Received";                
            }
        }

        public static string ESPFolderName
        {
            get
            {
                return ResourceHelper.GetLocalizedString("OrderResources", "CartFolder_ESPFolder");
            }
        }

        #endregion

        #region System Defined Folder Description

        /// <summary>
        /// Ordered Folder Description
        /// </summary>
        public static string OrderedFolderDesc = "Ordered Folder";
        /// <summary>
        /// BTCart Folder Description
        /// </summary>
        public static string BtcartFolderDesc = "BT Cart Folder";
        /// <summary>
        /// Archived Folder Description
        /// </summary>
        public static string ArchivedFolderDesc = "Archived Folder";
        /// <summary>
        /// Deleted Folder Description
        /// </summary>
        public static string DeletedFolderDesc = "Deleted Folder";
        /// <summary>
        /// Normal Folder Description
        /// </summary>
        public static string NormalFolderDesc = "Normal Folder";
        /// <summary>
        /// Normal Folder Description
        /// </summary>
        public static string RootFolderDesc = "Root Folder";
        #endregion

        #region Sytem Defined Images
        public static string SpriteImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/ts360-sprite.png?v=346";
        /// <summary>
        /// Image of Ordered Folder
        /// </summary>
        public static string OrderedFolderImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/icons/ico-order-cart.png";
        /// <summary>
        /// Image of Deleted Folder
        /// </summary>
        public static string DeletedFolderImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/icons/ico-delete-cart.png";
        /// <summary>
        /// Image of Archived Folder
        /// </summary>
        public static string ArchivedFolderImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/icons/ico-archived-cart.png";
        /// <summary>
        /// Image of BTCart folder
        /// </summary>
        public static string BtcartFolderImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/icons/ico-bt-cart.png";
        /// <summary>
        /// Image of ESP folder
        /// </summary>
        public static string ESPFolderImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/icons/ico-esp-cart.png";
        // TODO: need to have a real ico for shared/received folder
        public static string SharedReceivedFolderImageurl = "/_layouts/IMAGES/CSDefaultSite/assets/images/icons/ico-closed-folder.png";

        #endregion
        #endregion

        #region Old Properties
        /// <summary>
        /// Gets or sets the date created.
        /// </summary>
        /// <value>The date created.</value>
        public DateTime? DateCreated { get; set; }

        /// <summary>
        /// Gets or sets the date modified.
        /// </summary>
        /// <value>The date modified.</value>
        public DateTime? DateModified { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the ordering.
        /// </summary>
        /// <value>The ordering.</value>
        public int? Ordering { get; set; }

        /// <summary>
        /// Gets the ordering value.
        /// </summary>
        /// <value>The ordering value.</value>
        public int OrderingValue
        {
            get
            {
                return Ordering == null ? 0 : Ordering.Value;
            }
        }

        /// <summary>
        /// Gets or sets the deep level.
        /// </summary>
        /// <value>The deep level.</value>
        public int DeepLevel { get; set; }

        /// <summary>
        /// Gets or sets the type name of this object instance
        /// <remarks>Required so that the Builders can convert to the Multi-channel Commerce Foundation CommerceEntity base type</remarks>
        /// </summary>
        /// <value></value>
        public string ModelName { get; set; }
        #endregion
    }
}

