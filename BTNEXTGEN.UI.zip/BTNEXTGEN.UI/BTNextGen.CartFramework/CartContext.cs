﻿using System.Web;

namespace BTNextGen.CartFramework
{
    public class CartContext : ICartContext
    {
        #region Fields

        /// <summary>
        /// Cart Context Cache Key
        /// </summary>
        private const string CartContextCacheKey = "__CartContext";

        #endregion

        #region Constructor

        /// <summary>
        /// CartContext
        /// </summary>
        protected CartContext()
        {

        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets the CartContext for the current request.
        /// </summary>
        public static CartContext Current
        {
            get
            {
                var context = HttpContext.Current.Items[CartContextCacheKey] as CartContext;
                if (context == null)
                {
                    context = new CartContext();
                    HttpContext.Current.Items[CartContextCacheKey] = context;
                }
                return context;
            }
            set
            {
                HttpContext.Current.Items[CartContextCacheKey] = value;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get CartManager For User
        /// </summary>
        /// <returns></returns>
        public CartManager GetCartManagerForUser(string userId)
        {

            if (string.IsNullOrEmpty(userId))
                return null;

            return new CartManager(userId, null, true);

        }

        /// <summary>
        /// Get CartManager For Org
        /// </summary>
        /// <returns></returns>
        public CartManager GetCartManagerForOrganization(string orgId)
        {

            if (string.IsNullOrEmpty(orgId))
                return null;

            return new CartManager(null, orgId, false);

        }

        #endregion

    }
}
