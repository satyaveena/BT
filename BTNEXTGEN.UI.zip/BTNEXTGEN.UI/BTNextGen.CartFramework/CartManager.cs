﻿using System;
using System.Collections.Generic;
using BT.TS360Constants;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextgen.Grid.Cart;
using BTNextGen.VelocityCaching;
using CartSplitResult = BT.TS360Constants.CartSplitResult;
using DefaultDuplicateCarts = BT.TS360Constants.DefaultDuplicateCarts;
using OrderStatus = BT.TS360Constants.OrderStatus;
using SessionVariableName = BT.TS360Constants.SessionVariableName;
using SplitCartMode = BT.TS360Constants.SplitCartMode;

namespace BTNextGen.CartFramework
{
    using Helpers;
    using Order;
    using Commerce.Portal.Common;
    using Commerce.Portal.Common.Cart;
    using Commerce.Portal.Common.DataItems;
    using LineItem = Order.LineItem;
    using BTNextGen.Commerce.Portal.Common.Contracts;
    using BTNextGen.Commerce.Portal.Common.DataAccessObject;
    public class CartManager
    {
        #region Constructor

        /// <summary>
        /// Cart Manager
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="organizationId"></param>
        /// <param name="isCartManagerForUser"></param>
        public CartManager(string userId, string organizationId, bool isCartManagerForUser)
        {
            if (isCartManagerForUser)
            {
                if (string.IsNullOrEmpty(userId))
                {
                    //throw exception code
                }
                this.UserId = userId;
                this.IsCartManagerForUser = true;
            }
            else
            {
                if (string.IsNullOrEmpty(organizationId))
                {
                    //throw exception code
                }
                this.OrganizationId = organizationId;
                this.IsCartManagerForUser = false;
            }

            //Initial Class
            this.CartFolders = new CartFolders();
            this.Carts = new Carts(this.UserId);
        }
        public CartManager(string userId)
        {
            this.UserId = userId;
        }
        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the User id.
        /// </summary>
        /// <value>UserId.</value>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the Organization id.
        /// </summary>
        /// <value>OrganizationId.</value>
        public string OrganizationId { get; set; }

        /// <summary>
        /// Gets or sets the Organization id.
        /// </summary>
        /// <value>OrganizationId.</value>
        public bool IsCartManagerForUser { get; set; }

        #endregion

        #region Cart Folder Functional Methods

        /// <summary>
        /// Create Cart Folder
        /// </summary>
        /// <param name="name"></param>
        /// <param name="parentId"></param>
        /// <param name="cartFolderType"></param>
        /// <param name="sequenceNo"></param>
        /// <returns></returns>
        public CartFolder CreateCartFolder(string name, string parentId, CartFolderType cartFolderType, float sequenceNo)
        {
            if (string.IsNullOrEmpty(name)) throw new CartManagerException(CartManagerException.CART_FOLDER_NAME_NULL);
            return CartFolder.CreateCartFolder(name, parentId, cartFolderType, sequenceNo, this.UserId);
        }

        /// <summary>
        /// Creates default system folders for new user.
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, CartFolderType> CreateSystemCartFolders()
        {
            return CartFolders.CreateSystemCartFolders(this.UserId);
        }

        /// <summary>
        /// Get Cart Folders
        /// </summary>
        /// <returns></returns>
        public CartFolders GetCartFolders()
        {
            if (string.IsNullOrEmpty(this.UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            return this.CartFolders.GetCartFolders(this.UserId);
        }

        /// <summary>
        /// Get Cart Folder By Id
        /// </summary>
        /// <param name="folderId"></param>
        /// <returns></returns>
        public CartFolder GetCartFolderById(string folderId)
        {
            if (string.IsNullOrEmpty(folderId)) throw new CartManagerException(CartManagerException.CART_FOLDER_ID_NULL);
            if (string.IsNullOrEmpty(this.UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            return this.CartFolders.GetCartFolderById(folderId, this.UserId);
        }

        public float GetUserFolderSequence(string parentFolderId, int positionType)
        {
            if (string.IsNullOrEmpty(this.UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            return this.CartFolders.GetUserFolderSequence(parentFolderId, this.UserId, positionType);
        }

        public List<Cart> GetCartsByFolderIdLite(string folderId, out int totalCarts)
        {
            var cartFolder = new CartFolder(folderId);
            return cartFolder.GetCartsLite(out totalCarts);
        }

        #endregion

        #region Cart Functional Methods

        /// <summary>
        /// Get Primary Cart
        /// </summary>
        /// <returns></returns>
        public Cart GetPrimaryCart()
        {
            var cart = CartFarmCacheHelper.GetPrimaryCart(this.UserId);
            if (cart == null) return null;
            var cartdeletedinProcessing = VelocityCacheManager.Read(string.Format(SessionVariableName.CartIdProcessingToBeDeleted, this.UserId), VelocityCacheLevel.Session);
            if (cartdeletedinProcessing != null && cartdeletedinProcessing.ToString().Equals(cart.CartId, StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }
            return cart;
        }

        public string GetPrimaryCartId()
        {
            return CartFarmCacheHelper.GetPrimaryCartId(this.UserId);
        }

        public Cart CreateCart(string name, bool isPrimary, string folderID, List<CartAccount> cartAccounts, 
            string gridTemplateId = "", int gridOptionId = 0,
            List<CommonGridTemplateLine> gridLines = null)
        {
            #region Validation
            if (string.IsNullOrEmpty(name)) throw new CartManagerException(CartManagerException.CART_NAME_NULL);
            if (string.IsNullOrEmpty(folderID)) throw new CartManagerException(CartManagerException.CART_FOLDER_ID_NULL);
            if (string.IsNullOrEmpty(this.UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            return Cart.CreateCart(name, isPrimary, folderID, cartAccounts, this.UserId, gridTemplateId, gridOptionId, gridLines);
        }

        public Cart GetCartById(string cartId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            return this.Carts.GetCartById(cartId);
        }

        public Cart GetCartByIdFromDB(string cartId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            return this.Carts.GetCartByIdFromDB(cartId);
        }
        public void ResetCacheCartById(string cartId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            this.Carts.ResetCacheCartById(cartId);
        }
        public Cart GetOriginalCart(string cartId)
        {
            return this.Carts.GetOriginalCart(cartId);
        }

        public Cart GetCartById(string cartId, bool needToRepice)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            return this.Carts.GetCartById(cartId, needToRepice);
        }

        public LineItem GetCartLineById(string cartId, string lineItemId)
        {
            var cart = Cart.GetBlankCart(cartId, this.UserId);
            return cart.GetCartLineById(lineItemId);
        }

        public List<LineItem> GetCartLineByIds(string cartId, List<string> lineItemIds)
        {
            var cart = Cart.GetBlankCart(cartId, this.UserId);
            return cart.GetCartLineByIds(lineItemIds);
        }

        public Cart SetCartAsPrimary(string cartId)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var blankCart = Cart.GetBlankCart(cartId, UserId);
            return blankCart.SetAsPrimary();
        }

        public void SetPrimaryCartChanged()
        {
            this.Carts.NotifyPrimaryCartChanged();
        }

        public void SetCartChanged(string cartId)
        {
            this.Carts.NotifyCartChanged(cartId);
            this.Carts.ResetCacheCartById(cartId);
        }

        public void DeleteCart(string cartId)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var blankCart = Cart.GetBlankCart(cartId, UserId);
            blankCart.Delete();
        }

        //public void ArchiveCart(string cartId)
        //{
        //    #region Validation
        //    if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
        //    if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
        //    #endregion

        //    var blankCart = Cart.GetBlankCart(cartId, UserId);
        //    blankCart.Archive();
        //}

        public void RestoreCart(string cartId, string toFolder)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var blankCart = Cart.GetBlankCart(cartId, UserId);
            blankCart.Restore(toFolder);
        }

        public void MoveCartToFolder(string cartId, string destinationFolderId)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(destinationFolderId)) throw new CartManagerException(CartManagerException.DESTINATION_FOLDER_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var blankCart = Cart.GetBlankCart(cartId, UserId);
            blankCart.MoveToFolder(destinationFolderId);
        }

        public void RenameCart(string cartId, string newCartName)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);

            #endregion

            Cart cart = Cart.GetBlankCart(cartId, this.UserId);
            cart.Rename(newCartName);
        }

        public void UpdateCartNote(string cartId, string note)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var cart = Cart.GetBlankCart(cartId, UserId);
            cart.UpdateCartNote(note);
        }

        public void UpdateCartInstruction(string cartId, string instruction)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            var cart = Cart.GetBlankCart(cartId, UserId);
            cart.UpdateCartSpecialInstructions(instruction);
        }

        public Cart GetCartByIdWithOCSData(string cartId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            return this.Carts.GetCartByIdWithOCSData(cartId);
        }

        #endregion

        #region Carts functional methods
        public Carts GetTopNewestCarts(int topCartNum)
        {
            return Carts.GetTopNewestCarts(topCartNum);
        }

        public void DeleteCarts(List<string> cartIDs, string userId = "")
        {
            #region Validation
            if (cartIDs == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            Carts.DeleteCarts(cartIDs, userId);
        }

        public void ArchiveCarts(List<string> cartIDs)
        {
            #region Validation
            if (cartIDs == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            Carts.ArchiveCarts(cartIDs);
        }

        public void RestoreCarts(List<string> cartIDs, string toFolder)
        {
            #region Validation
            if (cartIDs == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            Carts.RestoreCarts(cartIDs, toFolder);
        }

        public void CreateCopyOfCarts(List<string> cartIDs, string folderId, CartCopyType cartCopyType, bool copyESP)
        {
            #region Validation
            if (cartIDs == null) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(folderId)) throw new CartManagerException(CartManagerException.CART_FOLDER_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            Carts.CopyCarts(cartIDs, folderId, cartCopyType, copyESP);
        }

        public int MergeCarts(string cartIdMerged, List<string> cartIdSelected, List<string> cartIdDeleted, List<CartAccount> targetCartAccounts, out string PermissionViolationMessage, out string ErrorMessage)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartIdMerged)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (cartIdSelected == null || cartIdSelected.Count == 0) throw new CartManagerException(CartManagerException.SELECTED_CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            return Carts.MergeCarts(cartIdMerged, cartIdSelected, cartIdDeleted, targetCartAccounts, out PermissionViolationMessage, out ErrorMessage);
        }

        public void MoveCartsToFolder(List<string> cartIDs, string destinationFolderId)
        {
            #region Validation
            if (cartIDs == null) throw new CartManagerException(CartManagerException.CART_ID_NULL, true);
            if (string.IsNullOrEmpty(destinationFolderId)) throw new CartManagerException(CartManagerException.DESTINATION_FOLDER_ID_NULL, true);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL, true);
            #endregion

            Carts.MoveCartsToFolder(cartIDs, destinationFolderId);
        }

        public CartFacet GetCartFacet(string facetPath, string folderId, string keyword, string keywordType)
        {
            return Carts.GetCartFacet(facetPath, UserId, OrganizationId, folderId, keyword, keywordType);
        }

        public CartFacet GetCartFacetForAdmin(string facetPath, string folderId, string keyword, string keywordType)
        {
            return Carts.GetCartFacetForAdmin(facetPath, UserId, OrganizationId, folderId, keyword, keywordType);
        }

        public Carts GetCartsBySearchForAdmin(string facetPath, string keyword, string keywordType, int pageNumber, int pageSize,
            int sortBy, int sortDirection, string folderId, out int totalCarts, out int totalCartsInOrg, bool applyPricing = false,
            bool calculateOcsData = true)
        {
            return Carts.GetCartsForAdmin(facetPath, keyword, keywordType, pageNumber, pageSize, sortBy, sortDirection, folderId,
                        UserId ?? string.Empty, OrganizationId ?? string.Empty, out totalCarts, out totalCartsInOrg, applyPricing, calculateOcsData);
        }

        public Carts GetCartsBySearch(string facetPath, string keyword, int pageNumber, int pageSize,
            int sortBy, int sortDirection, string folderId, string keywordType, out int totalCarts, bool applyPricing = false,
            bool calculateOcsData = true)
        {
            return Carts.GetCartsBySearch(facetPath, keyword, pageNumber, pageSize, sortBy, sortDirection, folderId,
                                          UserId ?? string.Empty, OrganizationId, keywordType, out totalCarts, applyPricing,
                                          calculateOcsData);
        }

        public Carts GetAllCarts()
        {
            int remainingCarts = 0;
            var retCarts = new Carts(this.UserId);
            byte pageIndex = 1;
            do
            {
                int totalCarts;

                var carts = GetCartsBySearch(string.Empty, string.Empty, pageIndex,
                                             CartFrameworkConstants.LARGE_PAGE_SIZE, 0, 0, string.Empty, string.Empty,
                                             out totalCarts);
                if (carts != null && carts.Count > 0)
                {
                    retCarts.AddRange(carts);
                    remainingCarts = totalCarts - retCarts.Count;
                    pageIndex++;
                }
            } while (remainingCarts > 0);
            return retCarts;
        }

        public Cart GetCartByName(string cartName)
        {
            return this.Carts.GetCartByName(cartName, UserId);
        }

        public void SetCartToDownloaded(string cartId, string orderedDownloadedUserId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            CartDAOManager.SetCartStatusDownloaded(cartId, this.UserId, orderedDownloadedUserId);
            Carts.NotifyCartChanged(cartId);
        }

        public int SetQuantities(List<string> cartIDs, List<string> lineItemIDs, int massQuantity, string userID,
            int maxLineLimit, out int numberOfCarts, out int numberOfLineItems, out string errorMessage)
        {
            if (cartIDs == null || cartIDs.Count < 1)
            {
                throw new CartManagerException(CartManagerException.CART_ID_NULL);
            }

            var result = CartDAOManager.SetQuantities(cartIDs, lineItemIDs, massQuantity, userID, maxLineLimit, out numberOfCarts, out numberOfLineItems, out errorMessage);

            foreach (var cartID in cartIDs)
            {
                Carts.NotifyCartChanged(cartID);
            }
            return result;
        }

        public void SetQuantitiesBackGround(List<string> cartIDs, List<string> lineItemIDs, int massQuantity, string userID)
        {
            //if (cartIDs == null || cartIDs.Count < 1)
            //{
            //    throw new CartManagerException(CartManagerException.CART_ID_NULL);
            //}

            //var numberOfCarts = 0;
            //var numberOfLineItems = 0;

            //CartDAOManager.SetQuantities(cartIDs, lineItemIDs, massQuantity, userID, out numberOfCarts, out numberOfLineItems);

            //foreach (var cartID in cartIDs)
            //{
            //    Carts.NotifyCartChanged(cartID);
            //}
        }

        #endregion

        #region Cart Line Items Methods
        public Dictionary<string, string> RemoveCartLineItems(string cartId, List<string> lineItemIds, bool isCallPricingService = true)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            var cart = Cart.GetBlankCart(cartId, this.UserId);
            var errorTable = cart.RemoveLineItems(lineItemIds, isCallPricingService);
            return errorTable;
        }

        public bool IsCartPricing(string cartId, bool needToReprice = false)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            var cart = Cart.GetBlankCart(cartId, this.UserId);
            return cart.IsPricing(needToReprice);
        }

        public bool CheckBasketforCalMerch(string cartId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            return CartDAOManager.CheckBasketforCalMerch(cartId);
        }

        #endregion

        #region Submit orders methods

        public bool CheckForDuplicates(string listItemKeys, string listBTEkeys, string cartCheckType,
            string orderCheckType, string orgId, string soldToId, out string itemsCheckOrder, out string itemsCheckCart, string cartId,
            out Dictionary<string, bool> itemsCheckHoldings, string holdingsFlag, string downloadCheckType)
        {
            string orgIdValue = orgId;
            if (string.Compare(cartCheckType, DefaultDuplicateCarts.MyCarts.ToString(), true) == 0)
                orgId = null;
            if (string.Compare(orderCheckType, BT.TS360Constants.DefaultDuplicateOrders.AllAccounts.ToString(), true) == 0)
                orgId = orgIdValue;
            return CartDAOManager.CheckForDuplicates(listItemKeys, listBTEkeys, cartCheckType,
                                                     orderCheckType, orgId, soldToId, out itemsCheckOrder,
                                                     out itemsCheckCart, cartId, out itemsCheckHoldings, holdingsFlag, downloadCheckType);
        }

        public DuplicateCartTitle GetDuplicateCartReferences(string cartId, string itemKey, string orgId, string soldToId, string downloadCheckType)
        {
            #region Validation
            if (string.IsNullOrEmpty(itemKey)) throw new CartManagerException(CartManagerException.ITEM_KEY_NULL);
            if (string.IsNullOrEmpty(soldToId)) throw new CartManagerException(CartManagerException.SOLD_TO_ID_NULL);

            #endregion

            return CartDAOManager.GetDuplicateCartReferences(cartId, itemKey, orgId, soldToId, downloadCheckType);
        }

        public DuplicateCartTitle GetDuplicateOrderReferences(string cartId, string itemKey, string orgId, string downloadCheckType, string cartCheckType,
            string orderCheckType)
        {
            #region Validation
            if (string.IsNullOrEmpty(itemKey)) throw new CartManagerException(CartManagerException.ITEM_KEY_NULL);
            #endregion

            return CartDAOManager.GetDuplicateOrderReferences(cartId, itemKey, orgId, downloadCheckType, UserId, cartCheckType, orderCheckType);
        }

        public Dictionary<string, List<OrderedLineItems>> GetOrderedLineItems(string cartId)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            #endregion

            return CartDAOManager.GetOrderedLineItems(cartId);
        }

        public List<OrderedLineItems> GetOrderedLineItems(string cartId, string btKey)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(btKey)) throw new CartManagerException(CartManagerException.ITEM_KEY_NULL);
            #endregion
            return CartDAOManager.GetOrderedLineItems(cartId, btKey);
        }

        public Dictionary<string, List<OrderedLineItems>> GetBasketLineItemOrderStatus(List<string> lineItemIds)
        {
            if (lineItemIds == null || lineItemIds.Count == 0) return null;
            return CartDAOManager.GetBasketLineItemOrderStatus(lineItemIds);
        }

        #endregion

        #region Private Properties

        /// <summary>
        /// Cart Folders
        /// </summary>
        private CartFolders CartFolders { get; set; }

        /// <summary>
        /// Carts
        /// </summary>
        private Carts Carts { get; set; }

        #endregion

        #region Helper Methods
        public string GenerateNewBasketName(string basketName)
        {
            if (string.IsNullOrEmpty(basketName))
            {
                throw new CartManagerException(CartManagerException.CART_NAME_NULL);
            }
            if (string.IsNullOrEmpty(this.UserId))
            {
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            }

            return CartDAOManager.GenerateNewBasketName(basketName, this.UserId);
        }

        public string GenerateNewBasketNameForUser(string basketName)
        {
            if (string.IsNullOrEmpty(basketName))
            {
                throw new CartManagerException(CartManagerException.CART_NAME_NULL);
            }
            if (string.IsNullOrEmpty(this.UserId))
            {
                throw new CartManagerException(CartManagerException.USER_ID_NULL);
            }

            return CartDAOManager.GenerateNewBasketNameForUser(basketName, this.UserId);
        }

        public Dictionary<string, int> GetQuantitiesByBtKeys(string cartId, List<string> btkeys)
        {
            return CartDAOManager.GetQuantitiesByBtKeys(cartId, this.UserId, btkeys);
        }

        public List<List<string>> CheckBasketForTitles(string cartId, List<string> btkeys, List<string> lineItemIds,
            out int newLineCount, out int existingLineCount)
        {
            return CartDAOManager.CheckBasketForTitles(cartId, btkeys, lineItemIds, out newLineCount, out existingLineCount);
        }
        #endregion

        public List<OrderForm> SearchOrders(string keyword, string sortBy, string sortDirection, int pageIndex, int pageSize,
            OrderStatus orderStatus, char searchType, out int totalOrderCount, out int totalCarts)
        {
            var dbSortOrder = "asc";
            if (string.Compare(sortDirection, "descending", StringComparison.OrdinalIgnoreCase) == 0)
            {
                dbSortOrder = "desc";
            }
            if (searchType == 'D')//Date time
            {
                DateTime dt;
                if (!DateTime.TryParse(keyword, out dt))
                {
                    totalOrderCount = totalCarts = 0;
                    return new List<OrderForm>();
                }
            }
            return CartDAOManager.SearchOrders(keyword, sortBy, dbSortOrder, pageIndex, pageSize, orderStatus, searchType,
                out totalOrderCount, out totalCarts);
        }

        public List<OrderForm> SearchOrderQueue(string cartId, out int totalOrderCount, out int totalCarts)
        {
            //return SearchOrderDummyData(out totalOrderCount, out totalCarts);
            return CartDAOManager.ViewOrderQueue(cartId, out totalOrderCount, out totalCarts);
        }

        private List<OrderForm> SearchOrderDummyData(out int totalOrderCount, out int totalCarts)
        {
            var results = new List<OrderForm>();
            string orderType;

            for (int i = 0; i < 50; i++)
            {
                orderType = i % 2 == 0 ? "Book" : "Entertainment";

                var of = GenerateOrderFormForDummy(OrderStatus.Submitted, "Org " + i, "DC " + i, "Cart " + i, orderType, "Order for Dummy");
                results.Add(of);
            }

            totalOrderCount = 750;
            totalCarts = 20;
            return results;
        }

        private OrderForm GenerateOrderFormForDummy(OrderStatus orderStatus, string cartOrg, string cartOwner, string cartName, string orderType,
            string orderNUmber)
        {
            var rand = new Random();
            return new OrderForm()
            {
                CartId = rand.Next(100000000).ToString(),
                CartName = cartName,
                TransmisisonNumber = rand.Next(100000000),
                OrderStatus = orderStatus,
                PoNumber = "Dummy POKey",
                ErpAccount = "Dummy ERP Account",
                CartOwnersUserName = cartOwner,
                CartOrganization = cartOrg,
                LastUpdated = DateTime.Now.AddDays(-2),
                OrderType = orderType,
                BasketOrderFormStateId = "1",
                OrderNumber = orderNUmber,
                CartStatus = "Status dummy",
                SubmittedDatetime = DateTime.Now.AddDays(-2),
                OrderStatusStringForUi = "Process"
            };
        }

        public int ApplyDuplicates(List<string> cartIDs, string userID, int maxLineLimit, out string newcartId, out string newcartname, out int numberOfItemApplied,
                                 string cartCheckType, string orderCheckType, string orgId, string downloadCheckType, bool moveToNewCart)
        {
            if (string.Compare(cartCheckType, DefaultDuplicateCarts.MyCarts.ToString(), true) == 0)
                orgId = null;

            return CartDAOManager.ApplyDuplicates(cartIDs, userID, maxLineLimit, out newcartId, out newcartname, out numberOfItemApplied, cartCheckType,
                                                     orderCheckType, orgId, downloadCheckType, moveToNewCart);
        }

        public Carts GetAllCartsForUser(int pageNumber, int pageSize, int sortBy, string sortDirection)
        {
            return CartDAOManager.GetAllCartsForUser(pageNumber, pageSize, sortBy, sortDirection, UserId);
        }

        public bool SplitCart(string cartId, SplitCartOptions splitCartOption, out Dictionary<string, string> separatedCarts)
        {
            return CartDAOManager.SplitCart(cartId, splitCartOption, UserId, out separatedCarts);
        }

        public CartSplitResult SplitCartToGridAndNonGrid(string cartId, SplitCartMode splitCartMode, out Dictionary<string, string> separatedCarts)
        {
            return CartDAOManager.SplitCartToGridAndNonGrid(cartId, splitCartMode, UserId, out separatedCarts);
        }

        /*public ESPRankDetailInfo GetESPankDetail(string lineItemID)
        {
            return CartDAOManager.GetESPRankItemDetailsByID(lineItemID);
        }*/

        public List<Cart> GetCartsForQuickManageCarts(string sortBy, string sortDirection, int pageIndex, int pageSize, out int totalCarts)
        {
            return Carts.GetCartsForQuickManageCarts(sortBy, sortDirection, pageIndex, pageSize, UserId, out totalCarts);
        }

        public Dictionary<string, bool> GetAppropriateActionsForSelectedCartsQuickManageCarts(List<string> basketIds)
        {
            var resultFromDb = CartDAOManager.GetSelectedCartsInfoForQuickManageCarts(UserId, basketIds);
            var result = new Dictionary<string, bool>();

            result.Add("IsContainOpenCart", resultFromDb.ContainsOpenCart);
            result.Add("IsContainPrivateCart", resultFromDb.ContainsPrivateCart);
            result.Add("IsContainArchivedCart", resultFromDb.ContainsArchivedCart);
            result.Add("IsContainDeletedCart", resultFromDb.ContainsDeletedCart);
            result.Add("IsContainSubmittedCart", resultFromDb.ContainsSubmittedCart);
            result.Add("IsContainOrderedCart", resultFromDb.ContainsOrderedCart);

            return result;
        }

        public List<CartInfoForAjax> GetPermissionForSubmitOrderButtons(List<string> cartIds)
        {
            return CartDAOManager.GetPermissionForSubmitOrderButtons(UserId, cartIds);
        }

        public List<CartLineActionPermission> GetLineActionsForQuickManageCarts(List<string> basketIds)
        {
            return CartDAOManager.GetLineActionsForQuickManageCarts(UserId, basketIds);
        }

        public LineItem GetLineItemForQuickView(string lineItemId)
        {
            var lineItem = CartDAOManager.GetLineItemForQuickView(new List<string>() { lineItemId }, UserId);

            if (lineItem == null || lineItem.Count == 0) return null;

            return lineItem[0];
        }

        public List<Quotation> SearchQuotations(string keyword, string searchBy, int pageIndex, int pageSize, string sortBy, int sortDirection, out int totalCarts)
        {


            return CartDAOManager.SearchQuotations(keyword, searchBy, pageIndex, pageSize, sortBy, sortDirection, out totalCarts);
        }

        public List<AccountSummary> GetCartAccountSummary(string cartId)
        {
            return CartDAOManager.GetAccountsSummary(cartId);
        }

        public void SaveCartAccountSummary(string cartId, string userId, List<CartAccountSummary> accounts)
        {
            CartDAOManager.UpdateAccounts(accounts, cartId, userId);
            this.Carts.NotifyCartChanged(cartId);
        }
        //public bool SetRequisitionType(string cartId, string userID, string requisitionType)
        //{
        //    return CartDAOManager.SetRequisitionType(cartId, userID, requisitionType);
        //}

        public void DesignateAsNonGrid(string cartId)
        {
            CartDAOManager.DesignateAsNonGrid(cartId);
        }

        public void DesignateAsGrid(string cartId)
        {
            CartDAOManager.DesignateAsGrid(cartId);
        }

        public TransferredCartInfo GetTransferredCartDetail(string cartId)
        {
            return CartDAOManager.GetTransferredCartDetailByID(cartId);
        }

        public List<TransferredCartInfo> GetTransferredCartDetail(List<string> cartIDs)
        {
            return CartDAOManager.GetTransferredCartDetailByID(cartIDs);
        }

        public List<List<string>> GetESPInvalidCodesForPopup(string cartId)
        {
            return CartDAOManager.GetESPInvalidCodesForPopup(cartId);
        }

        public void SetUserFolderChanged(List<string> userIdsList)
        {
            CartCacheManager.SetCartFolderDistributedCacheExpired(userIdsList);
        }

        public List<Cart> GetCartsByIDs(List<string> cartIds)
        {
            return CartDAOManager.GetCartsByIDs(cartIds, this.UserId);
        }
        public void UpdateLineItemsNotes(Dictionary<string, Dictionary<string, string>> lineItems, string cartId)
        {

            #region Validation
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            if (lineItems.Count == 0) return;
            #endregion

            CartDAOManager.UpdateLineItemsNotes(lineItems, this.UserId, cartId);
        }

        public List<ESPQueue> SearchESPQueue(string displayStatus, string cartStatus, int pageIndex, int pageSize, out int totalLines)
        {
            return CartDAOManager.ViewESPQueue(displayStatus, cartStatus, pageIndex, pageSize, out totalLines);
        }

        public void SetCartAsActiveOrInActive(string cartId, bool isActive, int maxActiveCarts)
        {
            #region Validation
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            CartDAOManager.SetCartAsActiveOrInActive(cartId, this.UserId, isActive, maxActiveCarts);
        }

        public List<Cart> GetActiveRecentCarts(int numberOfCartsToGet)
        {
            #region Validation
            if (string.IsNullOrEmpty(UserId)) throw new CartManagerException(CartManagerException.USER_ID_NULL);
            #endregion

            return CartDAOManager.GetActiveRecentCarts(this.UserId, numberOfCartsToGet);
        }

        public Cart GetCartByIdForSubmitting(string cartId)
        {
            if (string.IsNullOrEmpty(cartId)) throw new CartManagerException(CartManagerException.CART_ID_NULL);

            return this.Carts.GetCartByIdForSubmitting(cartId);
        }
        public void SetILSBasketState(string basketSummaryID, string userId, BT.TS360Constants.CartStatus basketState, BT.TS360Constants.ILSState ilsStatusId, string ILSMarcProfileId, string vendorCode, string locationCode, string orderedDownloadedUserId)
        {
            CartDAOManager.SetILSBasketState(basketSummaryID, userId, basketState, ilsStatusId, ILSMarcProfileId, vendorCode, locationCode, orderedDownloadedUserId);
        }

        public void SetIlsSystemStatus(string basketSummaryId, string userId, ILSSystemStatus ilsSystemStatusId)
        {
            CartDAOManager.SetIlsSystemStatus(basketSummaryId, userId, ilsSystemStatusId);
        }

        public void ResetIlsCart(string basketSummaryId, string userId)
        {
            CartDAOManager.ResetIlsCart(basketSummaryId, userId);
        }

    }
}
