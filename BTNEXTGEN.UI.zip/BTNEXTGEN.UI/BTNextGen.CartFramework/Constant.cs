﻿using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.VelocityCaching;

namespace BTNextGen.CartFramework
{
    internal static class StoreProcedureName
    {
        internal const string SPLIT_BASKET_TO_GRID_AND_NON_GRID = "procTS360SplitBasketToGridAndNonGrid";
        //internal const string PROC_SET_SHARED_BASKET_GRID_ENABLED = "procTS360SetBasketIsSharedBasketGridEnabled";

        #region Cart Folder StoreProcedures
        internal const string PROC_BASKET_MANAGEMENT_CREATE_USER_FOLDER = "procTS360CreateUserFolder";
        internal const string PROC_BASKET_MANAGEMENT_CREATE_USER_SYSTEM_FOLDERS = "procTS360CreateUserFolders";
        internal const string PROC_BASKET_MANAGEMENT_GET_FOLDER_BY_USER_ID = "procTS360GetUserFolders";
        internal const string PROC_BASKET_MANAGEMENT_GET_FOLDER_BYID = "procTS360GetUserFolder";
        internal const string PROC_BASKET_MANAGEMENT_DELETE_USER_FOLDER = "procTS360DeleteUserFolder";
        internal const string PROC_BASKET_MANAGEMENT_MOVE_USER_FOLDER = "procTS360MoveUserFolder";
        //internal const string PROC_BASKET_MANAGEMENT_ARCHIVE_USER_FOLDER = "procTS360ArchiveUserFolder";
        internal const string PROC_BASKET_MANAGEMENT_RENAME_USER_FOLDER = "procTS360RenameUserFolder";
        internal const string PROC_BASKET_MANAGEMENT_UPDATE_USER_FOLDER_SEQUENCE = "procTS360ResequenceUserFolder";

        #endregion

        #region Cart StoreProcedures
        internal const string PROC_BASKET_MANAGEMENT_CREATE_BASKET = "procTS360CreateBasket";

        internal const string PROC_BASKET_MANAGEMENT_GET_PRIMARY_BASKET = "procTS360GetPrimaryBasket";
        internal const string PROC_BASKET_MANAGEMENT_GET_BASKET_BY_TOP_NEWEST = "procTS360GetBasketTopNewest";
        internal const string PROC_BASKET_MANAGEMENT_GET_BASKET_BY_FOLDER = "procTS360GetBasketByFolder";
        internal const string PROC_BASKET_MANAGEMENT_GET_BASKET_BY_FOLDER_LITE = "procTS360GetBasketByFolderLite";
        internal const string PROC_BASKET_MANAGEMENT_GET_BASKET_SEARCH = "procTS360GetBasketsSearch";
        internal const string PROC_BASKET_SEARCH_MANAGE_CART_PAGE = "procTS360GetBasketsSearchManageCarts";
        internal const string PROC_BASKET_SEARCH_CART_LIST_PAGE = "procTS360GetBasketsSearchCartList";
        internal const string ProcTs360GetBasketSummaryFlat = "procTS360GetBasketSummaryFlat";
        internal const string ProcTs360GetBasketSummaryFlatAjax = "procTS360GetBasketSummaryFlat_AJAX";
        internal const string ProcTs360GetBasketSummaryFlatCartView = "procTS360GetBasketSummaryFlatCartView";

        internal const string PROC_BASKET_MANAGEMENT_SET_PRIMARY_BASKET = "procTS360SetPrimaryBasket";
        internal const string PROC_BASKET_MANAGEMENT_SET_ONECLICKMARC_STATUS = "procTS360SetBasketOneClickMARC";

        internal const string PROC_BASKET_MANAGEMENT_DELETE_BASKETS = "procTS360DeleteBaskets";
        internal const string PROC_BASKET_MANAGEMENT_ARCHIVE_BASKETS = "procTS360ArchiveBaskets";
        internal const string PROC_BASKET_MANAGEMENT_RESTORE_BASKETS = "procTS360RestoreBaskets";
        internal const string PROC_BASKET_MANAGEMENT_COPY_BASKETS = "procTS360CopyBaskets";
        internal const string PROC_BASKET_MANAGEMENT_MERGE_BASKETS = "procTS360MergeBaskets";
        internal const string PROC_BASKET_MANAGEMENT_MOVE_BASKETS = "procTS360MoveBaskets";

        internal const string PROC_BASKET_MANAGEMENT_DOWNLOAD_EXPORT_BASKET = "procTS360SetBasketStatusDownloaded";
        internal const string PROC_BASKET_MANAGEMENT_GET_LINE_ITEMS_WITH_TITLE = "procTS360GetBasketLineItemsWithTitle";
        internal const string PROC_BASKET_MANAGEMENT_GET_LINE_ITEMS_ID = "procTS360GetBasketLineItemIDByBasketSummary";
        internal const string PROC_BASKET_MANAGEMENT_RENAME_BASKET = "procTS360RenameBasket";
        internal const string PROC_BASKET_MANAGEMENT_GET_CART_FACET = "procTS360GetBasketFacets";
        internal const string PROC_BASKET_MANAGEMENT_GET_CART_FACET_FOR_ADMIN = "procTS360GetBasketFacetsForAdmin";
        internal const string ProcTs360GetBasketSummaryFlatFacets = "procTS360GetBasketSummaryFlatFacets";

        internal const string PROC_BASKET_MANAGEMENT_GET_BASKET_BY_NAME = "procTS360GetBasketByName";
        internal const string PROC_BASKET_MANAGEMENT_GET_USER_FOLDER_SEQUENCE = "procTS360GetUserFolderSequence";
        internal const string PROC_BASKET_MANAGEMENT_UPDATE_BASKET_NOTE_ONLY = "procTS360UpdateBasketNote";

        internal const string PROC_BASKET_MANAGEMENT_UPDATE_BASKET_INSTRUCTION = "procTS360UpdateBasketSpecialInstructions";
        internal const string PROC_BASKET_MANAGEMENT_IS_PRICING = "procBasketPricingIsBeingProcessed";
        internal const string PROC_BASKET_MANAGEMENT_IS_ZERO_QUANTITY_ITEM = "procTS360BasketContainsZeroQuantityItem";
        internal const string PROC_BASKET_MANAGEMENT_GET_QUANTITY_BY_BTKEYS = "procTS360GetQuantitesByBtkeys";
        internal const string PROC_BASKET_MANAGEMENT_CHECK_BASKET_FOR_TITLES = "procTS360CheckBasketForTitles";
        internal const string PROC_BASKET_MANAGEMENT_CHECK_BASKET_FOR_CAL_MERCH = "procTS360CheckBasketforCalMerch";

        internal const string PROC_TS360_ADD_ORIGINAL_ENTRY_TO_CART = "procTS360SaveOriginalEntry";

        internal const string PROC_TS360_SET_MASS_QUANTITIES = "procTS360SetMassQuantities";

        internal const string ProcTs360DragDropFolder = "procTS360DragDropFolder";

        internal const string PROC_BASKET_MANAGEMENT_REQUEST_QUOTE = "procTS360SetBasketRequestQuotation";
        internal const string PROC_BASKET_MANAGEMENT_RELEASE_QUOTE = "procTS360SetBasketReleaseQuotation";

        internal const string PROC_GET_BASKET_BY_ID_WITH_OCS_DATA = "procTS360GetBasketByID_WithOCSData";
        internal const string PROC_SET_ACTIVE_OR_INACTIVE_BASKET = "procTS360SetActiveOrInactiveBasket";

        #endregion

        #region Cart Line Store Procedures

        internal const string PROC_BASKET_MANAGEMENT_BASKET_ADD_LINEITEMS = "procTS360BasketAddLineItems";
        internal const string PROC_BASKET_MANAGEMENT_BASKET_COPY_LINEITEMS = "procTS360BasketCopyLines";
        internal const string PROC_BASKET_MANAGEMENT_BASKET_COPY_TITLE = "procTS360CopyTitle";
        internal const string PROC_BASKET_MANAGEMENT_BASKET_MOVE_TITLE = "procTS360MoveTitle";

        internal const string PROC_TS360_BASKET_MOVE_LINES = "procTS360BasketMoveLines";
        internal const string PROC_TS360_BASKET_REMOVE_LINES = "procTS360DeleteBasketLineItems";
        internal const string PROC_TS360_BASKET_UPDATE_LINE_ITEM_NOTE = "procTS360UpdateBasketLineItemNotes";
        internal const string PROC_TS360_BASKET_UPDATE_LINE_QUANTITIES = "procTS360MergeBasketLineItemQuantities";
        internal const string PROC_TS360_BASKET_UPDATE_LINE_INFO = "procTS360UpdateBasketLineItemInfo";
        internal const string PROC_TS360_BASKET_UPDATE_LINE_NOTES = "procTS360UpdateBasketUserLineItemNotes";

        internal const string PROC_TS360_BASKET_UPDATE_BASKET_ACCOUNTS = "procTS360MergeBasketOrderForm";
        internal const string PROC_TS360_BASKET_GET_ACCOUNT_SUMMARIES = "procTS360GetBasketOrderForm";
        internal const string PROC_TS360_BASKET_GET_CART_LINE_ITEMS = "procTS360GetBasketLineItems";
        internal const string PROC_TS360_BASKET_GET_BT_KEYS = "procTS360GetBasketBTKeys";
        internal const string PROC_TS360_BASKET_GET_CART_LINE_FACET = "procTS360GetBasketLineItemFacet";

        internal const string PROC_TS360_BASKET_MERGE_LINE_ITEMS = "procTS360AddMoveCopyLineItems";
        internal const string PROC_TS360_BASKET_MERGE_EXCEED500_LINE_ITEMS = "procTS360AddItemsToCartTrackingList";

        internal const string PROC_TS360_BASKET_GET_LINE_ITEM_BY_ID = "procTS360GetBasketLineItemByID";
        internal const string PROC_TS360_BASKET_GET_LINE_ITEM_BY_BTKEY = "procTS360GetBasketLineItemByBTKey";
        internal const string PROC_TS360_BASKET_GET_LINE_ITEM_BY_ID_LIST = "procTS360GetBasketLineItemByIDs";
        internal const string PROC_TS360_GENERATE_NEW_BASKETNAME = "procTS360GenerateNewBasketName";
        internal const string PROC_TS360_GENERATE_NEW_BASKETNAME_FOR_USER = "procTS360GenerateNewBasketNameForUser";
        internal const string PROC_TS360_COPY_CANCELLED_LINE_ITEMS = "procTS360CopyCancelledBasketLineItems";

        internal const string PROC_TS360_UPDATE_ITEM_ORDERING_INFO = "procTS360UpdateItemOrderingInfo";
        internal const string PROC_TS360_BASKET_GET_CART_LINE_ITEMS_BY_NOTE = "procTS360SearchWithinBasketByNote";
        internal const string PROC_TS360_BASKET_GET_CART_LINE_ITEMS_BY_GRID_FIELD_CODE = "procTS360GetBasketLineItemsByGridFieldCode";

        internal const string ProcTs360CopyLineItemsToNewCart = "procTS360AddMoveCopyLineItems";
        internal const string ProcTs360MoveLineItemsToNewCart = "procTS360AddMoveCopyLineItems";
        internal const string PROC_TS360_GET_BASKETS_WITH_DUPLICATED_TITLES = "procTS360GetBasketsWithDuplicatedTitles";

        //internal const string PROC_TS360_GET_BASKETS_LINE_ITEMS_ESP_RANKING = "procTS360GetBasketLineItemESPRanking";
        internal const string PROC_TS360_GET_ESP_INVALID_CODES = "procTS360GetESPInvalidCodes";
        internal const string PROC_TS360_GET_CART_DETAILS_QUICK_VIEW = "procTS360GetCartDetailsQuickView";
        internal const string PROC_TS360_GET_BASKET_TRANSFER_DETAILS = "procTS360GetBasketTransferDetails";
        internal const string PROC_TS360_GET_BASKETS_BY_IDS = "procTS360GetBasketsByIDs";
        #endregion

        #region Submit Order Store Procedures
        internal const string PROC_TS360_SUBMIT_BASKET = "procTS360SubmitBasket";
        internal const string PROC_TS360_GET_BASKET_STORE_CUSTOMER_VIEW = "procTS360GetBasketStoreAndCustomerView";
        #endregion

        #region Check For Duplicates Procedures

        internal const string PROC_TS360_CHECK_FOR_DUPLICATES = "procTS360CheckForDuplicates";
        internal const string PROC_TS360_DUPLICATE_BASKET_REFERENCES = "procTS360DuplicateBasketReferences";
        internal const string PROC_TS360_DUPLICATE_ORDER_REFERENCES = "procTS360DuplicateOrderReferences";
        internal const string PROC_TS360_GET_ORDERED_LINE_ITEMS = "procTS360GetOrderedLineItems";
        internal const string ProcTs360GetBasketLineItemOrderStatus = "procTS360GetBasketLineItemOrderStatus";
        internal const string PROC_TS360_HOLDINGS_DUP_CHECK = "procTS360HoldingsDupCheck";

        #endregion

        internal const string ProcTs360Searchorders = "ProcTs360Searchorders";
        internal const string ProcTs360ViewOrderQueue = "procTS360ViewOrderQueue";
        internal const string ProcTs360SplitBasketByAccountType = "procTS360SplitBasketByAcctType";
        internal const string ProcTs360GetCartManagementQuickView = "procTS360GetCartManagementQuickView";
        internal const string ProcTs360GetCartManagementQuickView_Ajax = "procTS360GetCartManagementQuickView_AJAX";
        internal const string ProcTS360GetItemDetailsQuickView = "procTS360GetItemDetailsQuickView";
        internal const string ProcTS360SearchQuotations = "procTS360QuotationSearchHome";
        internal const string ProcTS360GetCartManagementQuickViewSelectActions = "procTS360GetCartManagementQuickViewSelectActions";
        internal const string ProcTS360GetCartManagementQuickViewSelectedCartActions = "procTS360GetCartManagementQuickViewSelectedCartActions";
        internal const string ProcTs360ViewESPQueue = "procTS360GetESPQueue";
    }

    /// <summary>
    /// To contain all cache key, session key, cache per request key
    /// </summary>
    internal sealed class CacheKeyConstant
    {
        public const string CART_MANAGEMENT_CACHE_KEY_PREFIX = "CART_MANAGEMENT_CACHE_KEY";
    }

    internal sealed class SpParameterName
    {
        public const string ParentFolderID = "@ParentUserFolderID";
        public const string Name = "@Name";
        public const string UserFolderID = "@UserFolderID";
        public const string Literal = "@Literal";
        public const string SequenceNo = "@Sequence";
        public const string UserID = "@UserID";
        public const string PositionType = "@PositionType";
    }

    

    public class CartCacheConstants
    {
        public static VelocityCacheLevel CommonCartCacheLevel
        {
            get { return VelocityCacheLevel.Request; }
        }

        public static VelocityCacheLevel PrimaryCartCacheLevel
        {
            get { return VelocityCacheLevel.Request; }
        }

        public static VelocityCacheLevel CartFolderCacheLevel
        {
            get
            {
                return VelocityCacheLevel.Request;
            }
        }

        public static VelocityCacheLevel FarmCacheLevel
        {
            get
            {
                VelocityCacheManager.DistributedCacheName = GlobalConfiguration.DistributedCacheName;
                VelocityCacheManager.DistributedCacheEnvRegion = GlobalConfiguration.DistributedCache_Env_Region;
                return VelocityCacheLevel.Farm;
            }
        }

        /// <summary>
        /// in minutes
        /// </summary>
        public static int PrimaryCartCacheDuration
        {
            get { return 30; }
        }

        public const string UiGridFieldsCacheForPe = "__GridHelper.GetUIGridFieldsCacheForPE_{0}_{1}";
    }
}
