﻿using System;
using System.Collections.Generic;
using System.Linq;
using BT.TS360Constants;

namespace BTNextGen.CartFramework
{
    using Commerce.Portal.Common;
    using Commerce.Portal.Common.Constants;
    using Commerce.Portal.Common.Controllers;
    using Commerce.Portal.Common.Helpers;
    using Commerce.Portal.Common.Search;
    using VelocityCaching;
    public class QuickCart
    {
        private const string QuickCartCacheKey = "_quickCartCacheKey{0}";

        private static string GetQuickCartCacheKey(string cartId)
        {
            return string.Format(QuickCartCacheKey, cartId);
        }

        private const string QuickCartLinesCacheKey = "_quickCartLinesCacheKey{0}{1}{2}{3}{4}{5}";

        private static string GetQuickCartLinesCacheKey(string cartId, string userId, int pageNumber, short pageSize, string sortBy, byte sortDirection)
        {
            return string.Format(QuickCartLinesCacheKey, cartId, userId, pageNumber, pageSize, sortBy, sortDirection);
        }

        public string CartId { get; set; }
        public string UserId { get; set; }
        public QuickCartInfo CartInfo { get; set; }
        public List<QuickLineItem> LineItems { get; set; }
        public int NonRankedCount { get; set; }

        public QuickCart(string cartId, string userId)
        {
            CartId = cartId;
            UserId = userId;
        }

        public QuickCart GetCartDetailsQuickView(int pageNumber, short pageSize, string sortBy, byte sortDirection, bool recalculateHeader = true, bool getFast = true)
        {
            if (string.IsNullOrEmpty(CartId) || string.IsNullOrEmpty(UserId))
            {
                return null;
            }

            sortBy = CommonHelper.SortByDict.ContainsKey(sortBy) ? CommonHelper.SortByDict[sortBy] : CommonHelper.QuickCartDetailsSortByDB.Title.ToString();

            var quickCart = CartDAOManager.GetCartDetailsQuickView(CartId, UserId, sortBy, sortDirection, pageSize, pageNumber, recalculateHeader);
            if (quickCart != null)
            {
                if (getFast && quickCart.LineItems != null && quickCart.LineItems.Count > 0)
                {
                    var btkeys = quickCart.LineItems.Where(x => !x.IsOEItem).Select(x => x.BTKey);
                    var searchProducts = ProductSearchController.SearchByIdWithoutAnyRules(btkeys.ToList());
                    if (searchProducts != null && searchProducts.Items != null)
                    {
                        foreach (var lineItem in quickCart.LineItems)
                        {
                            var product = searchProducts.Items.FirstOrDefault(x => x.BTKey == lineItem.BTKey);
                            if (product != null)
                            {
                                lineItem.Title = product.Title;
                                lineItem.Author = product.AuthorText;
                                lineItem.ISBN = product.ISBN;
                                lineItem.UPC = product.Upc;
                                lineItem.Format = product.FormatLiteral;
                                lineItem.FormatForUI = product.ProductFormatForUI;
                                lineItem.NumOfDiscs = product.NumOfDiscs;
                                lineItem.ESupplier = product.ESupplier;
                                lineItem.ProductType = product.ProductType;
                                lineItem.PublishedDate = product.PublishDate;
                                lineItem.PurchaseOption = product.PurchaseOption;
                                lineItem.HasJacket = product.HasJacket;
                                lineItem.Publisher = product.Publisher;
                                lineItem.HasFamilyKey = product.HasFamilyKey;
                                lineItem.Catalog = product.Catalog;
                                lineItem.HasAnnotations = product.HasAnnotations;
                                lineItem.HasReview = product.HasReview;
                                lineItem.HasReturn = product.HasReturn;
                                lineItem.HasMuze = product.HasMuze;
                                lineItem.HasExcerpt = product.HasExcerpt;
                                lineItem.HasToc = product.HasToc;
                                lineItem.MerchCategory = product.MerchCategory;
                                lineItem.Edition = product.Edition;
                                lineItem.ProductLine = product.ProductLine;
                                lineItem.SupplierCode = product.SupplierCode;
                                lineItem.IncludedFormatClass = product.IncludedFormatClass;
                            }
                        }
                    }
                }
                if (quickCart.CartInfo != null)
                {
                    var owner = ProfileController.Current.GetUserById(quickCart.CartInfo.CartOwnerID);
                    if (owner != null)
                    {
                        quickCart.CartInfo.CartOwnerName = owner.UserLoginName;
                    }
                    WriteCartHeaderToCache(quickCart.CartInfo, quickCart.CartId);
                }
                else
                {
                    quickCart.CartInfo = ReadCartHeaderFromCache(CartId, UserId);
                }
            }
            return quickCart;
        }

        public static QuickCartInfo ReadCartHeaderFromCache(string cartId, string userId)
        {
            var quickCartCache = VelocityCacheManager.Read(GetQuickCartCacheKey(cartId)) as QuickCartInfo;
            if (quickCartCache == null)
            {
                var quickCart = new QuickCart(cartId, userId);
                quickCart = quickCart.GetCartDetailsQuickView(1, 0, "Title", 1);
                if (quickCart != null)
                {
                    WriteCartHeaderToCache(quickCart.CartInfo, quickCart.CartId);
                    return quickCart.CartInfo;
                }
            }
            return quickCartCache;
        }

        public static void WriteCartHeaderToCache(QuickCartInfo cart, string cartId)
        {
            VelocityCacheManager.Write(GetQuickCartCacheKey(cartId), cart, VelocityCacheLevel.Session);
        }

        public static List<QuickLineItem> ReadCartLinesFromCache(string cartId, string userId, int pageNumber, short pageSize,
            string sortBy, byte sortDirection)
        {
            return VelocityCacheManager.Read(GetQuickCartLinesCacheKey(cartId, userId, pageNumber, pageSize, sortBy,
                                                                sortDirection)) as List<QuickLineItem>;

        }

        public static void WriteCartLinesToCache(string cartId, string userId, int pageNumber, short pageSize,
            string sortBy, byte sortDirection, List<QuickLineItem> cartLines)
        {
            VelocityCacheManager.Write(
                GetQuickCartLinesCacheKey(cartId, userId, pageNumber, pageSize, sortBy, sortDirection), cartLines,
                VelocityCacheLevel.Session);
        }

        public static CartLineActionPermission GetCartLineActionPermission(string cartId, string userId)
        {
            var cacheKey = string.Format("CART_LINE_PERMISSION_QUICK_CART_{0}_{1}", cartId, userId);
            var cartPermission = VelocityCacheManager.Read(cacheKey) as CartLineActionPermission;
            if (cartPermission != null) return cartPermission;

            var cartManager = CartContext.Current.GetCartManagerForUser(userId);
            var cartPermissionInfo = cartManager.GetLineActionsForQuickManageCarts(new List<string> { cartId });
            if (cartPermissionInfo != null && cartPermissionInfo.Count > 0)
            {
                VelocityCacheManager.Write(cacheKey, cartPermissionInfo[0], VelocityCacheLevel.Request);
                return cartPermissionInfo[0];
            }
            return null;
        }
    }

    public class QuickLineItem
    {
        private string _btKey;
        private bool _hasJacket = true;
        //From database
        public string   Title       { get; set; }
        public string   Author      { get; set; }
        public string LineItemID { get; set; }
        public string Publisher { get; set; }

        public string BTKey
        {
            get
            {
                if (!string.IsNullOrEmpty(_btKey)) return _btKey;
                return BasketOriginalEntryID;
            }
            set { _btKey = value; }
        }

        public bool HasJacket
        {
            get { return _hasJacket; }
            set { _hasJacket = value; }
        }

        public Decimal ListPrice { get; set; }
        public Decimal NetPrice { get; set; }
        public bool IsGridded { get; set; }
        public int Quantity { get; set; }
        public Decimal Discount { get; set; }
        public string BasketOriginalEntryID { get; set; }

        public bool IsOEItem
        {
            get { return !string.IsNullOrEmpty(BasketOriginalEntryID); }
        }

        //From FAST
        public string ISBN { get; set; }
        public string UPC { get; set; }
        public string Format { get; set; }
        public string FormatForUI { get; set; }
        public string ESupplier { get; set; }
        public string ProductType { get; set; }
        public DateTime? PublishedDate { get; set; }
        public string PurchaseOption { get; set; }
        public bool HasFamilyKey { get; set; }
        public string Catalog { get; set; }

        public bool HasCpsiaWarning { get; set; }
        public bool HasAnnotations { get; set; }
        public bool HasExcerpt { get; set; }
        public bool HasReturn { get; set; }
        public bool HasMuze { get; set; }
        public bool HasReview { get; set; }
        public bool HasToc { get; set; }

        private FlagObject _flagObject;

        public ProductContent ProductContent
        {
            get
            {
                if (this._flagObject == null)
                    this._flagObject = ProductSearchController.GetFlagObject(SiteContext.Current.UserId);

                var hasMuze = false;
                var hasToc = false;
                if (_flagObject != null)
                {
                    hasMuze = _flagObject.ShowMuze;
                    hasToc = _flagObject.ShowToc;
                }

                var prodContent = new ProductContent
                {
                    HasAnnotation = this.HasAnnotations,
                    HasExcerpts = this.HasExcerpt,
                    HasReturnKey = this.HasReturn
                };
                if (hasMuze && this.ProductType != ProductTypeConstants.Book)
                    prodContent.HasMuze = this.HasMuze;
                //
                prodContent.HasReviews = this.HasReview;
                //
                if (hasToc)
                    prodContent.HasTOC = this.HasToc;

                return prodContent;
            }
        }
        public string MerchCategory { get; set; }
        public string Edition { get; set; }
        public string ProductLine { get; set; }
        public string SupplierCode { get; set; }
        public string IncludedFormatClass { get; set; }
        public int NumOfDiscs { get; set; }
    }

    public class QuickCartInfo
    {
        public string CartStatus { get; set; }
        public string CartOwnerID { get; set; }
        public string CartName { get; set; }
        public string CartOwnerName { get; set; }
        public int TotalLines { get; set; }
        public long TotalQuantity { get; set; }
        public decimal TotalListPrice { get; set; }
        public decimal TotalNetPrice { get; set; }
        public bool IsShared { get; set; }
        public bool IsPricingComplete { get; set; }
        public int ESPStateTypeId { get; set; }
        public bool OneClickMARCIndicator { get; set; }
        public string FTPErrorMessage { get; set; }
        public int ESPFundStateTypeID { get; set; }
        public int ESPDistStateTypeID { get; set; }
        public int ESPRankStateTypeId { get; set; }
        public string LastESPStateTypeLiteral { get; set; }
        public string ESPJobURL { get; set; }
        public string ESPJobText { get; set; }
        public int FreezeLevel { get; set; }
        public bool IsMixedProduct { get; set; }
        public bool IsBasketActive { get; set; }
        public string CartFolderId { get; set; }
        public bool IsArchived { get; set; }
    }

    public class CartInfoForAjax
    {
        public string CartId { get; set; }
        public bool IsMixGridCart { get; set; }
        public bool CanSubmitOrder { get; set; }

        public List<CartAccount> CartAccounts { get; set; }
        public bool IsGrid { get; set; }
    }

    public class CartLineActionPermission
    {
        public string CartId { get; set; }
        public bool IsArchived { get; set; }
        public bool HasReviewAndAcquisition { get; set; }
        public bool IsShared { get; set; }
        public bool IsPrimary { get; set; }
        public bool HasProfile { get; set; }
        public bool IsGrid { get; set; }
        public bool HasOwner { get; set; }
        public bool HasContribution { get; set; }
        public bool IsMixedGridNonGrid { get; set; }
        public bool IsMixedProduct { get; set; }
        public string CartStatus { get; set; }
        public int LineItemCount { get; set; }
        public int ESPFundStateTypeID { get; set; }
        public int ESPDistStateTypeID { get; set; }
        public int ESPRankStateTypeId { get; set; }
        public string LastESPStateTypeLiteral { get; set; }
        public int FreezeLevel { get; set; }
        public bool IsBasketActive { get; set; }
        public bool HasPermission { get; set; }
    }

    public class SelectedCartsInfo
    {
        public bool ContainsOpenCart { get; set; }
        public bool ContainsPrivateCart { get; set; }
        public bool ContainsArchivedCart { get; set; }
        public bool ContainsDeletedCart { get; set; }
        public bool ContainsSubmittedCart { get; set; }
        public bool ContainsOrderedCart { get; set; }
    }
}
