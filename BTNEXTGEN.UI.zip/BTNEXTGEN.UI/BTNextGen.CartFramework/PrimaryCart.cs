﻿using System;
using System.Collections.Generic;
using BTNextGen.Commerce.Portal.Common;
using cartframework = BTNextGen.CartFramework.Order;

namespace BTNextGen.CartFramework
{
    public class PrimaryCart
    {
        public Cart Cart { get; set; }

        public Dictionary<string, int> GetQuantitiesByBtkeys(List<string> btkeys)
        {
            var cartManager = CartContext.Current.GetCartManagerForUser(SiteContext.Current.UserId);
            if (cartManager!= null)
            {
                return cartManager.GetQuantitiesByBtKeys(Cart.CartId, btkeys);
            }
            return null;
        }

        public Dictionary<string, string> GetLineItemBtKeys()
        {
            //var lineitems = Cart.GetLineItemsForPrint(); // dancao: comment while merge code
            var lineitems = Cart.GetLineItemIDs();
            if(lineitems == null) return new Dictionary<string, string>();
            var ret = new Dictionary<string, string>();
            foreach (var lineItem in lineitems)
            {
                try
                {
                    if (!string.IsNullOrEmpty(lineItem.BTKey))
                        ret.Add(lineItem.BTKey, lineItem.Id);
                }
                catch
                {
                    continue;
                }
                
            }
            return ret;
        }
    }
}
