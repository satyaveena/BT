﻿using System;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BT.TS360Constants;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Pricing;

namespace BTNextGen.CartFramework.Helpers
{
    public class PricingServiceClient
    {
        public void CalculatePriceForBasket(string basketId)
        {
            //var endPointAddress = new EndpointAddress(GetPricingServiceUrl());
            //var binding = new BasicHttpBinding();
            //binding.OpenTimeout = binding.CloseTimeout = binding.SendTimeout = new TimeSpan(0, 15, 0);
            //binding.MaxReceivedMessageSize = Int32.MaxValue;
            //var ps = new PromotionServiceClient(binding, endPointAddress);
            try
            {
                //parsing configured data
                int batchWaitingTime = GetBatchWaitingTimeConfig();
                var pricingController = new PricingController();
                //calculating basket price
                pricingController.CalculatePrice(basketId, batchWaitingTime);

                //ps.Open();
                ////Logger.Write("CartFramwork.Pricing", "Calculate Price for Basket Async => BEGIN", false);
                //ps.CalculatePriceAsync(new CalculatePriceRequest(basketId));
                ////Logger.Write("CartFramwork.Pricing", "Calculate Price for Basket Async <= END", false);
            }
            catch (Exception ex)
            {
                Logger.RaiseException(ex, ExceptionCategory.Pricing);
            }
            //finally
            //{
            //    //if (ps.State == CommunicationState.Opened)
            //    //{
            //    //    ps.Close();
            //    //}
            //}
        }

        private int GetBatchWaitingTimeConfig()
        {
            var batchWaitingTime = 100;
            try
            {
                var sbatchWaitingTime = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.PricingBatchWaitingTime).Value;
                int.TryParse(sbatchWaitingTime, out batchWaitingTime);
            }
            catch
            {
            }

            return batchWaitingTime;
        }
    }
}
