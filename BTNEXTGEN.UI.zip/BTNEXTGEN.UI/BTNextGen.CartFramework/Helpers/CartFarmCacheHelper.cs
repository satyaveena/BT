﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.VelocityCaching;
using System.Data;
using BT.TS360Constants;

namespace BTNextGen.CartFramework.Helpers
{
    public static class CartFarmCacheHelper
    {
        public static Cart GetPrimaryCart(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                return null;

            Cart primaryCart;
            DataSet primaryCartDS;

            // get cartId from cache
            string primaryCartId = GetPrimaryCartId(userId);

            if (primaryCartId != null)  // allow empty
            {
                // get cart DS from cache
                primaryCartDS = GetPrimaryCartDataSet(primaryCartId);

                // convert DS to Cart object
                primaryCart = CartDAOManager.GetCartFromDataSet(primaryCartDS);
            }
            else
            {
                // get cart DS from DB
                primaryCartDS = CartDAO.Instance.GetPrimaryCart(userId);

                // convert DS to Cart object
                primaryCart = CartDAOManager.GetCartFromDataSet(primaryCartDS);
                if (primaryCart != null)
                {
                    if (primaryCart.BTStatus == CartStatus.Deleted.ToString()
                        || primaryCart.BTStatus == CartStatus.Submitted.ToString()
                        || primaryCart.BTStatus == CartStatus.Ordered.ToString())
                    {
                        primaryCart = null;
                    }
                    else
                    {
                        // write cartId and dataset into cache
                        WritePrimaryCartToCache(userId, primaryCart.CartId, primaryCartDS);
                    }
                }
                else
                {
                    // write empty cartId and null dataset into cache to prevent multiple calls to DB.
                    WritePrimaryCartToCache(userId, string.Empty, new DataSet());
                }
            }

            return primaryCart;
        }

        /// <summary>
        /// Get Primary Cart, not for mini cart.
        /// This will return the cart even it's status is Deleted or Submitted.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="cartId"></param>
        /// <returns></returns>
        public static Cart GetPrimaryCartNotForMinicart(string userId, string cartId)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(cartId))
                return null;

            // get cart DS from cache by cartId
            var primaryCartDS = GetPrimaryCartDataSet(cartId);

            // convert DS to Cart object
            var primaryCart = CartDAOManager.GetCartFromDataSet(primaryCartDS);

            if (primaryCart == null)
            {
                // get cart DS from DB
                primaryCartDS = CartDAO.Instance.GetPrimaryCart(userId);

                // convert DS to Cart object
                primaryCart = CartDAOManager.GetCartFromDataSet(primaryCartDS);

                if (primaryCart != null)
                {
                    // write cartId and dataset into cache
                    WritePrimaryCartToCache(userId, primaryCart.CartId, primaryCartDS);
                }
            }

            return primaryCart;
        }

        public static bool IsPrimaryCart(string cartId, string userId)
        {
            // get primary cart id from Farm cache
            string primaryCartId = GetPrimaryCartId(userId);

            if (VelocityCacheManager.IsFarmCacheAvailable == false)
            {
                // get primary cart from DB
                var primaryCart = CartDAOManager.GetPrimaryCart(userId);

                if (primaryCart == null) return false;

                return String.Compare(primaryCart.CartId, cartId, true) == 0;
            }

            return String.Compare(primaryCartId, cartId, true) == 0;
        }

        public static void SetExpiredPrimaryCart(string userId, string cartId = null)
        {
            if (string.IsNullOrEmpty(userId))
                return;

            if (string.IsNullOrEmpty(cartId))
                cartId = GetPrimaryCartId(userId);

            // Set expired cartId from cache by userId
            var cacheKey = GetUserPrimaryCartCacheKey(userId);
            VelocityCacheManager.SetExpired(cacheKey, CommonCacheContant.Ts360FarmCacheName);

            // Set expired dataset from cache by userId
            cacheKey = GetCartCacheKey(cartId);
            VelocityCacheManager.SetExpired(cacheKey, CommonCacheContant.Ts360FarmCacheName);
        }

        private static void WritePrimaryCartToCache(string userId, string primaryCartId, DataSet primaryCartDS)
        {
            // make sure cache expired
            SetExpiredPrimaryCart(userId, primaryCartId);

            // write primary cartID into cache by userId
            var cacheKey = GetUserPrimaryCartCacheKey(userId);
            VelocityCacheManager.Write(cacheKey, primaryCartId, CommonCacheContant.Ts360FarmCacheName);

            // write primary cart dataset into cache by primaryCartId
            cacheKey = GetCartCacheKey(primaryCartId);
            VelocityCacheManager.Write(cacheKey, primaryCartDS, CommonCacheContant.Ts360FarmCacheName);
        }

        public static string GetPrimaryCartId(string userId)
        {
            // get cartId from cache
            var cacheKey = GetUserPrimaryCartCacheKey(userId);
            return VelocityCacheManager.Read(cacheKey, CommonCacheContant.Ts360FarmCacheName) as string;
        }

        private static DataSet GetPrimaryCartDataSet(string primaryCartId)
        {
            // get cart DS from cache by cartId
            var cacheKey = GetCartCacheKey(primaryCartId);
            return VelocityCacheManager.Read(cacheKey, CommonCacheContant.Ts360FarmCacheName) as DataSet;
        }

        private static string GetCartCacheKey(string cartId)
        {
            return string.Format("{0}_CartId_{1}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX, cartId);
        }

        private static string GetUserPrimaryCartCacheKey(string userId)
        {
            return string.Format("{0}_PrimaryCartUserId_{1}", CacheKeyConstant.CART_MANAGEMENT_CACHE_KEY_PREFIX, userId);
        }
    }
}
