﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.Reflection;
using Microsoft.SqlServer.Server;

namespace BTNextGen.CartFramework.Helpers
{
    public static class SqlHelper
    {

        #region Member Variables

        private const String ARGUMENT_EXCEPTION_STRING =
            "Extract of property: \"{0}\" failed with the following message: {1}";

        private const String COLUMN_NAME = "ColumnName";
        private const String COLUMN_SIZE = "ColumnSize";
        private const String DATA_TYPE = "DataType";

        private const String DEBUG_WARNING_MESSAGE =
            "***Turn off debug before trying to select into a table to avoid conversion exceptions***";

        private const String OBJECT_TYPE_DIFFERENT_EXCEPTION =
            "All objects in objectsToRender[] must be of the same type.";

        private const String TO_STRING = "ToString()";

        #endregion

        #region Internal Methods

        /// <summary>  
        ///<para>This method takes a column name, type and maximum length, returning the column definition as SqlMetaData.</para>  
        /// </summary>
        /// <param name="System.String">A column name to be used in the returned Microsoft.SqlServer.Server.SqlMetaData.</param>
        /// <param name="System.Type">A column data type to be used in the returned Microsoft.SqlServer.Server.SqlMetaData.</param>
        /// <param name="System.Int32">The maximum length of the column to be used in the returned Microsoft.SqlServer.Server.SqlMetaData.</param>
        ///<param name="columnName"></param>
        ///<param name="type"></param>
        ///<param name="maxLength"></param>
        private static SqlMetaData ParseSqlMetaData(String columnName, Type type, Int64 maxLength)
        {
            SqlParameter sqlParameter = new SqlParameter();
            sqlParameter.DbType = (DbType) TypeDescriptor.GetConverter(sqlParameter.DbType).ConvertFrom(type.Name);
            if (sqlParameter.SqlDbType == SqlDbType.Char || sqlParameter.SqlDbType == SqlDbType.NChar ||
                sqlParameter.SqlDbType == SqlDbType.NVarChar || sqlParameter.SqlDbType == SqlDbType.VarChar)
            {
                if (maxLength > 8000)
                {
                    maxLength = -1;
                }
                return new SqlMetaData(columnName, sqlParameter.SqlDbType, maxLength);
            }
            else if (sqlParameter.SqlDbType == SqlDbType.Text || sqlParameter.SqlDbType == SqlDbType.NText)
            {
                return new SqlMetaData(columnName, sqlParameter.SqlDbType, -1);
            }
            else
            {
                return new SqlMetaData(columnName, sqlParameter.SqlDbType);
            }
        }

        /// <summary>  
        ///<para>This method takes a single object and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="<T>">A populated object.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private static void RenderResults<T>(T objectToRender)
        {
            RenderResults(objectToRender, false);
        }

        /// <summary>  
        ///<para>This method takes the SqlMetaData created to render an object and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Collections.Generic.List<Microsoft.SqlServer.Server>">A reference to a populated SqlMetaData List.</param>
        private static void WriteRecordStructure(List<SqlMetaData> sqlMetaDataList)
        {
            RenderResults(sqlMetaDataList.ToArray(), false);
        }

        #endregion

        #region Public Methods

        #region RenderResults Overloads

        #region Pass-Through Overloads

        /// <summary>  
        ///<para>This method takes a DataSet and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Data.DataSet">A reference to a populated DataSet.</param>  
        public static void RenderResults(DataSet dataSet)
        {
            RenderResults(dataSet);
        }

        /// <summary>  
        ///<para>This method takes a DataSet and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Data.DataSet">A reference to a populated DataSet.</param>
        /// <param name="System.Boolean">A boolean value indicating whether or not to return information
        /// about the record structure to the client.</param>  
        public static void RenderResults(DataSet dataSet, Boolean isDebugOn)
        {
            foreach (DataTable dataTable in dataSet.Tables)
            {
                RenderResults(dataTable, isDebugOn);
            }
        }

        /// <summary>  
        ///<para>This method takes a DataTable and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Data.DataTable">A reference to a populated DataTable.</param>  
        public static void RenderResults(DataTable dataTable)
        {
            RenderResults(dataTable, false);
        }

        /// <summary>  
        ///<para>This method takes an OleDbDataReader and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Data.OleDb.OleDbDataReader">A reference to a populated OleDbDataReader.</param>
        public static void RenderResults(OleDbDataReader dataReader)
        {
            RenderResults(dataReader, false);
        }

        /// <summary>  
        ///<para>This method takes a single object and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="<T>">A reference to a populated object.</param>
        /// <param name="System.Boolean">A boolean value indicating whether or not to return information
        /// about failed argument exceptions and record structure to the client.</param>
        public static void RenderResults<T>(T objectToRender, Boolean isDebugOn)
        {
            T[] objectsToRender = new T[1];
            objectsToRender[0] = objectToRender;
            RenderResults(objectsToRender, isDebugOn);
        }

        /// <summary>  
        ///<para>This method takes an array of objects and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Object[]">A reference to a populated object.</param>
        public static void RenderResults<T>(T[] objectsToRender)
        {
            RenderResults(objectsToRender, false);
        }

        #endregion

        /// <summary>  
        ///<para>This method takes a DataTable and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Data.DataTable">A reference to a populated DataTable.</param>  
        /// <param name="System.Boolean">A boolean value indicating whether or not to return information
        /// about the record structure to the client.</param>  
        public static void RenderResults(DataTable dataTable, Boolean isDebugOn)
        {
            List<SqlMetaData> sqlMetaDataList = new List<SqlMetaData>();
            for (int i = 0; i < dataTable.Rows[0].ItemArray.Length; i++)
            {
                sqlMetaDataList.Add(ParseSqlMetaData(dataTable.Columns[i].ColumnName, dataTable.Columns[i].DataType,
                                                     dataTable.Columns[i].MaxLength));
            }
            SqlDataRecord sqlDataRecord = new SqlDataRecord(sqlMetaDataList.ToArray());
            SqlContext.Pipe.SendResultsStart(sqlDataRecord);
            if (SqlContext.Pipe.IsSendingResults)
            {
                foreach (DataRow dataRow in dataTable.Rows)
                {
                    sqlDataRecord.SetValues(dataRow.ItemArray);
                    SqlContext.Pipe.SendResultsRow(sqlDataRecord);
                }
                SqlContext.Pipe.SendResultsEnd();
            }
            if (isDebugOn)
            {
                WriteRecordStructure(sqlMetaDataList);
            }
        }

        /// <summary>  
        ///<para>This method takes an OleDbDataReader and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="System.Data.OleDb.OleDbDataReader">A reference to a populated OleDbDataReader.</param>
        /// <param name="System.Boolean">A boolean value indicating whether or not to return information
        /// about the record structure to the client.</param>  
        public static void RenderResults(OleDbDataReader oleDBDataReader, Boolean isDebugOn)
        {
            Int64 columnSize = 0;
            List<SqlMetaData> sqlMetaDataList = new List<SqlMetaData>();
            foreach (DataRow dataRow in oleDBDataReader.GetSchemaTable().Rows)
            {
                if (Int64.TryParse(((Int32) dataRow[COLUMN_SIZE]).ToString(CultureInfo.CurrentCulture), out columnSize))
                {
                    sqlMetaDataList.Add(ParseSqlMetaData((String) dataRow[COLUMN_NAME], (Type) dataRow[DATA_TYPE],
                                                         columnSize));
                }
                else
                {
                    sqlMetaDataList.Add(ParseSqlMetaData((String) dataRow[COLUMN_NAME], (Type) dataRow[DATA_TYPE], -1));
                }
            }
            SqlDataRecord sqlDataRecord = new SqlDataRecord(sqlMetaDataList.ToArray());
            Object[] objects = new Object[sqlMetaDataList.Count];
            SqlContext.Pipe.SendResultsStart(sqlDataRecord);
            if (SqlContext.Pipe.IsSendingResults)
            {
                while (oleDBDataReader.Read())
                {
                    oleDBDataReader.GetValues(objects);
                    sqlDataRecord.SetValues(objects);
                    SqlContext.Pipe.SendResultsRow(sqlDataRecord);
                }
                SqlContext.Pipe.SendResultsEnd();
            }
            if (isDebugOn)
            {
                WriteRecordStructure(sqlMetaDataList);
            }
            if (oleDBDataReader.NextResult())
            {
                RenderResults(oleDBDataReader, isDebugOn);
            }
        }

        /// <summary>  
        ///<para>This method takes an array of objects and renders it back to the client.</para>  
        /// </summary>  
        /// <param name="<T>[]">A reference to an array of populated objects.</param>
        /// <param name="System.Boolean">A boolean value indicating whether or not to return information
        /// about failed argument exceptions and record structure to the client.</param>
        public static void RenderResults<T>(T[] objectsToRender, Boolean isDebugOn)
        {
            List<SqlMetaData> sqlMetaDataList = new List<SqlMetaData>();
            List<List<Object>> sqlMetaDataValues = new List<List<Object>>();
            SqlDataRecord sqlDataRecord = null;
            Type objectType = null;
            for (int i = 0; i < objectsToRender.Length; i++)
            {
                if (objectsToRender[i] == null)
                {
                    continue;
                }
                T objectToRender = objectsToRender[i];
                if (objectType == null)
                {
                    objectType = objectToRender.GetType();
                }
                if (objectToRender.GetType() != objectType)
                {
                    throw (new InvalidCastException(OBJECT_TYPE_DIFFERENT_EXCEPTION));
                }
                foreach (PropertyInfo property in objectToRender.GetType().GetProperties())
                {
                    SqlMetaData sqlMetaData = null;
                    if (property.CanRead && property.GetIndexParameters().Length == 0)
                    {
                        try
                        {
                            sqlMetaData = SqlMetaData.InferFromValue(property.GetValue(objectToRender, null),
                                                                     property.Name.ToString());
                            for (int j = 0; j < sqlMetaDataList.Count; j++)
                            {
                                if (sqlMetaDataList[j].Name == sqlMetaData.Name)
                                {
                                    if (sqlMetaDataList[j].MaxLength < sqlMetaData.MaxLength)
                                    {
                                        sqlMetaDataList[j] = sqlMetaData;
                                    }
                                    sqlMetaData = null;
                                    break;
                                }
                            }
                            if (sqlMetaData != null)
                            {
                                sqlMetaDataList.Add(sqlMetaData);
                            }
                            if (sqlMetaDataValues.Count == i)
                            {
                                sqlMetaDataValues.Add(new List<Object>());
                            }
                            sqlMetaDataValues[i].Add(property.GetValue(objectToRender, null));
                        }
                        catch (ArgumentException ex)
                        {
                            if (isDebugOn)
                            {
                                SqlContext.Pipe.Send(String.Format(CultureInfo.CurrentCulture, ARGUMENT_EXCEPTION_STRING,
                                                                   property.Name.ToString(), ex.Message.ToString()));
                            }
                        }
                    }
                }
                if (i == 0)
                {
                    sqlMetaDataList.Add(SqlMetaData.InferFromValue(objectToRender.ToString(), TO_STRING));
                }
                sqlMetaDataValues[i].Add(objectToRender.ToString());
            }
            sqlDataRecord = new SqlDataRecord(sqlMetaDataList.ToArray());
            SqlContext.Pipe.SendResultsStart(sqlDataRecord);
            if (SqlContext.Pipe.IsSendingResults)
            {
                sqlMetaDataValues.ForEach(sqlMetaDataValue =>
                                              {
                                                  sqlDataRecord.SetValues(sqlMetaDataValue.ToArray());
                                                  SqlContext.Pipe.SendResultsRow(sqlDataRecord);
                                              });
                SqlContext.Pipe.SendResultsEnd();
            }
            if (isDebugOn)
            {
                WriteRecordStructure(sqlMetaDataList);
            }

        }

        #endregion

        #endregion

    }
}