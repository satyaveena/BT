﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.CommerceServer.Runtime;
using Microsoft.CommerceServer.Internal;
using IDictionary = Microsoft.CommerceServer.Runtime.IDictionary;
using IPipelineComponent = Microsoft.CommerceServer.Interop.IPipelineComponent;
using IPipelineComponentDescription = Microsoft.CommerceServer.Interop.IPipelineComponentDescription;
using BTNextGen.Commerce.Portal.Common.Helpers;


namespace BTNextGen.Pipeline.Pricing
{
    [Description("BTNextGen Commerce Item Pricing"),
        ComVisible(true),
        Guid("42C028ED-F9AA-473E-8CEB-1CC03E50E66A"),
        ProgId("BTNextGen.Pipeline.Pricing.ItemPricing")]
    public class ItemPricing : RegisterCOMComponentFriendlyName, IPipelineComponent, IPipelineComponentDescription
    {
        // Status codes for pipeline components
        private const Int32 StatusSuccess = 1;	// success
        private const Int32 StatusWarning = 2;	// warning
        private const Int32 StatusError = 3;	// error

        private const string ItemKey = "items";
        private const string QuantityKey = "quantity";
        private const string ListPriceKey = "_cy_iadjust_regularprice";
        private const string PlacePriceKey = "cy_placed_price";
        private const string ItemLevelDiscountTotalKey = "_cy_itemlevel_discounts_subtotal";
        private const string ContractPriceKey = "contractPrice";
        private const string ExtendedPriceKey = "cy_oadjust_adjustedprice";


        public void EnableDesign(int fEnable)
        {
            //Do nothing here. This method is obsolete and shouldn't be used.
        }

        /// <summary>
        /// This method is used to implement the logic for this pipeline component.
        /// </summary>
        /// <param name="pdispOrder"></param>
        /// <param name="pdispContext"></param>
        /// <param name="lFlags"></param>
        /// <returns></returns>
        public int Execute(object pdispOrder, object pdispContext, int lFlags)
        {
            IDictionary order = (IDictionary)pdispOrder;
            IDictionary context = (IDictionary)pdispContext;
            SimpleList items = (SimpleList)order[ItemKey];
            decimal orderTotal = 0;
            foreach (IDictionary lineItem in items)
            {
                //Get the quantity from line item.
                int itemQuantity = string.IsNullOrEmpty(lineItem[QuantityKey].ToString())
                                               ? 1
                                               : int.Parse(lineItem[QuantityKey].ToString());

                //Get the Contract Price that assigned to the line item before executing pipeline.
                var contractPrice = !string.IsNullOrEmpty(lineItem["contractPrice"].ToString())
                                        ? decimal.Parse(lineItem["contractPrice"].ToString())
                                        : 0;

                var extendedPrice = decimal.Parse(lineItem["_cy_oadjust_adjustedprice"].ToString());

                var totalDiscountAmount = decimal.Parse(lineItem["_cy_itemlevel_discounts_subtotal"].ToString());


                decimal? quantity = !string.IsNullOrEmpty(lineItem["Quantity"].ToString())
                                        ? decimal.Parse(lineItem["Quantity"].ToString())
                                        : 0;

                //Compare the contract price with the extended price. The lower is the sale price.
                if ((totalDiscountAmount == 0) || (contractPrice > 0 && contractPrice < extendedPrice))
                {
                    //Set BTSalePrice to ContractPrice.
                    lineItem["btSalePrice"] = contractPrice;

                    //lineItem["btSalePrice"] = (decimal)CommonHelper.DecimalPlaceNoRounding( (decimal)(((quantity == 0) || (quantity == null)) ? contractPrice : contractPrice / quantity), 4); 
                    //lineItem["btSalePrice"] = Math.Round( (double)(((quantity == 0) || (quantity == null)) ? contractPrice : contractPrice / quantity), 4);
                    //lineItem["btSalePrice"] = (((quantity == 0) || (quantity == null)) ? contractPrice : contractPrice / quantity);

                    //Set BTUsingPromotion to zero.
                    lineItem["btUsingPromotion"] = false;
                    orderTotal += contractPrice;
                }
                else
                {
                    //Set BTSalePrice to Extended Price.
                    lineItem["btSalePrice"] = extendedPrice;
                    //var price = Math.Round((double)(((quantity == 0) || (quantity == null)) ? contractPrice : contractPrice / quantity), 4);
                    //lineItem["btSalePrice"] = (decimal) CommonHelper.DecimalPlaceNoRounding((decimal)(((quantity == 0) || (quantity == null)) ? extendedPrice : extendedPrice / quantity), 4); ;
                    //lineItem["btSalePrice"] = Math.Round((double)(((quantity == 0) || (quantity == null)) ? extendedPrice : extendedPrice / quantity), 4);
                    //lineItem["btSalePrice"] = (((quantity == 0) || (quantity == null)) ? extendedPrice : extendedPrice / quantity);

                    //Set BTUsingPromotion to 1.
                    lineItem["btUsingPromotion"] = true;
                    orderTotal += extendedPrice;
                }


                // Reset Virtual Catalog Info
                string productId = string.IsNullOrEmpty(lineItem["product_id"].ToString())
                               ? string.Empty
                               : lineItem["product_id"].ToString();
                int i = productId.IndexOf("(");
                if (i > -1)
                {
                    string catalogName = productId.Substring(i + 1);
                    catalogName = catalogName.Substring(0, catalogName.Length - 1);
                    string productId2 = productId.Substring(0, i);
                    if (!string.IsNullOrEmpty(productId2) && !string.IsNullOrEmpty(catalogName))
                    {
                        lineItem["product_id"] = productId2;
                        lineItem["product_catalog"] = catalogName;
                    }
                }

            }
            order["_cy_oadjust_subtotal"] = orderTotal;

            return StatusSuccess;
        }

        public object ContextValuesRead()
        {
            throw new NotImplementedException();
        }

        public object ValuesRead()
        {
            throw new NotImplementedException();
        }

        public object ValuesWritten()
        {
            return new object[] { ListPriceKey };
        }
    }
}
