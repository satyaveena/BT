﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using System.Xml;
using System.Xml.Serialization;

namespace BTNextGen.NoCoreLoad
{
    public class RegisterCoreWhenAuthenticatedControl : WebControl
    {
        protected override void OnInit(EventArgs e)
        {
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                Microsoft.SharePoint.WebControls.ScriptLink.RegisterCore(this.Page, true);
            }
            base.OnInit(e);
        }
    }
}
