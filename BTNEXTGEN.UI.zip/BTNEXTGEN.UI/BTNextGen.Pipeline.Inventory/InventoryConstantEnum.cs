﻿namespace BTNextGen.Pipeline.Internal
{

    // General Constants
    public static class GeneralConstants
    {
        public static string StoreProcCheckInventory = @"dbo.inv_CheckInventoryByWarehouse";
        public static string StoreProcUpdateInventory = @"dbo.inv_UpdateInventoryByWarehouse";
        public static string StoreProcOnHandInventory = @"dbo.inv_GetOnhandInventory";
        public static string DatabaseInventory = @"connstr_db_inventory";
        public static string PersistSecurity = @";Persist Security Info=true;";
        public static string ProviderName = @"provider";
        public static char Semicolon = ';';
        public static string ProductCatalog = @"Product Catalog";
        public static string DatabaseCatalog = @"connstr_db_Catalog";
        public static string CatalogCacheKey = @"BTNextGenCatalogConnectionStringCacheKey";
        public static string DefaultQuantity = "0";
        public static string PrimaryMark = "*";
        public static string SecondaryMark = "**";
        public static string VipMark = "***";
    }

    /// <summary>
    /// Property Name
    /// </summary>
    public static class PropertyName
    {
        public const string Items = "Items";
        public const string WarehouseList = "WarehouseList";
        public const string IsTolas = "IsTolas";
        public const string AccountType = "AccountType";
        public const string AccountInventoryType = "AccountInventoryType";
        public const string InventoryReserveNumber = "InventoryReserveNumber";
        public const string CheckReserveFlag = "CheckReserveFlag";
        public const string Inventory = "Inventory";
        public const string ProductCatalog = "product_catalog";
        public const string ProductId = "product_id";
        public const string Quantity = "quantity";
        public const string CommerceResources = "CommerceResources";
        public const string ColumnName = "ColumnName";
        public const string DataType = "DataType";
        public const string RowsAffected = "RowsAffected";
        public const string InStockForRequest = "InStockForRequest";
        public const string WarehouseId = "WarehouseId";
        public const string LineItem = "LineItem";
        public const string StockCondition = "StockCondition";
        public const string OnOrderQuantity = "OnOrderQuantity";
        public const string Last30DayDemand = "Last30DayDemand";
        public const string BTKey = "BTKey";
    }

    /// <summary>
    /// Exception Category
    /// </summary>
    internal static class InventoryException
    {
        public const string DispatchOrder = "BTNextGen.Pipeline.Inventory.UpdateInventoryByWarehouse.pdispOrder";
        public const string DispatchContext = "BTNextGen.Pipeline.Inventory.UpdateInventoryByWarehouse.pdispContext";
        public const string RunPipeline = "BTNextGen.Pipeline.Inventory.UpdateInventoryByWarehouse.RunPipeline";
        public const string HelperRunPipeline = @"BTNextGen.Pipeline.Inventory.InventoryPipelineHelper.RunPipeline";
        public const string ExecuteStore = @"BTNextGen.Pipeline.Inventory.InventoryPipelineHelper.ExecuteStore";
        public const string WareHousesAssigned = @"BTNextGen.Pipeline.Inventory.DetermineInventory.WareHousesAssigned";
        public const string DetermineInventory = @"BTNextGen.Pipeline.Inventory.DetermineInventory";

    }

    // Result Status
    internal enum ResultStatus
    {
        Success = 1,
        Fail = 0
    }

    // Inventory Types
    internal enum PipelineComponentType
    {
        CheckInventory,
        UpdateInventory
    }

    public static class InventoryWareHouseCode
    {
        public const string Ren = "REN";
        public const string Com = "COM";
        public const string Mom = "MOM";
        public const string Som = "SOM";
        public const string Rno = "RNO";
        public const string VIM = "VIM";
        public const string VIE = "VIE";
        public const string SUP = "VIP";
    }
}

