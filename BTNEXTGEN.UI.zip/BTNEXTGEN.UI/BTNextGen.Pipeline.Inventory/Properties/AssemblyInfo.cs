﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("BTNextGen.Pileline")]
[assembly: AssemblyDescription("BTNextGen.Pileline")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BTNG")]
[assembly: AssemblyProduct("BTNextGen.Pileline")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("22bf3ce4-94ad-4439-89b0-5b6999bdc9d8")]

