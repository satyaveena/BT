﻿using System.Data;
using System.Linq;
using BT.TS360API.ServiceContracts.Search;
using BT.TS360Constants;
using BTNextGen.Commerce.Inventory;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Caching;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common.DataItems;
using BTNextGen.Commerce.Portal.Common.DataAccessObject;
using System;
using System.Collections.Generic;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Search;
using BTNextGen.CartMapper;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.VelocityCaching;
using GeneralConstants = BTNextGen.Pipeline.Internal.GeneralConstants;
using InventoryWareHouseCode = BTNextGen.Pipeline.Internal.InventoryWareHouseCode;
using PropertyName = BTNextGen.Pipeline.Internal.PropertyName;

namespace BTNextGen.Pipeline.Inventory
{
    public class InventoryHelper
    {
        private static readonly string[] DefaultWhList = new string[] { InventoryWareHouseCode.Com, 
                                                InventoryWareHouseCode.Mom, 
                                                InventoryWareHouseCode.Ren, 
                                                InventoryWareHouseCode.Som };

        public static List<InventoryStockStatus> GetInventoryResultsForSearchPage(ProductSearchResultItem product, string userId,
            MarketType? market, bool isHorizontalMode, out bool displayInventoryForAllWareHouse,
            Account account, List<Warehouse> listWarehouse, List<DataRow> dataRows)
        {
            try
            {
                displayInventoryForAllWareHouse = false;

                var productType = product.ProductType;
                var reportCode = product.ReportCode;
                var publishDate = product.PublishDate;
                var eSupplier = product.ESupplier;
                var supplierCode = product.SupplierCode;
                var publisherCode = product.Publisher;

                var determineInventory = new DetermineInventory();
                var listInventoryStockStatus = determineInventory.GetOnhandInventoryForSearchResultPage(account, listWarehouse,
                    dataRows, productType, reportCode, publishDate, eSupplier, reportCode);

                //Get primary and secondary ware house
                string primaryWareHouse = String.Empty;
                string secondWareHouse = String.Empty;

                if (account != null && account.PrimaryWarehouse != null)
                {
                    primaryWareHouse = ((Warehouse)account.PrimaryWarehouse.Target).Code;
                }
                if (account != null && account.SecondaryWarehouse != null)
                {
                    secondWareHouse = ((Warehouse)account.SecondaryWarehouse.Target).Code;
                }
                if (isHorizontalMode)
                {
                    AddWareHouseIfNeed(listInventoryStockStatus, primaryWareHouse, secondWareHouse);
                }

                //TFS 1624:Inventory Display for Paw Print Titles//
                InventoryStockStatus additionalWarehouse = null;
                if (!String.IsNullOrEmpty(publisherCode))
                {
                    if (publisherCode.Contains(SearchFieldValue.PawPrintsPublisherName))
                    {
                        additionalWarehouse = ShowInventoryIfPawPrints(listInventoryStockStatus, primaryWareHouse,
                                                                       secondWareHouse, supplierCode, market);
                    }
                }

                listInventoryStockStatus = SortInventoryList(listInventoryStockStatus, primaryWareHouse, secondWareHouse,
                                                             additionalWarehouse, userId, account,
                                                             out displayInventoryForAllWareHouse);

                return listInventoryStockStatus;
            }
            catch (Exception e)
            {
                Logger.RaiseException(e, ExceptionCategory.Search);
                throw;
            }
        }

        public static Account GetUserDefaultAccountFromCartDetail(SearchResultInventoryStatusArg searchArg, string userId, string cartId)
        {
            var cacheProductType = searchArg.ProductType;
            if (string.Compare(cacheProductType, ProductType.Movie.ToString(), StringComparison.OrdinalIgnoreCase) == 0)
            {
                cacheProductType = ProductType.Music.ToString();
            }

            var cacheKey = String.Format("UserDefaultAcct_{0}_{1}_{2}_{3}", cacheProductType, searchArg.ESupplier,
                                         userId, cartId);

            var account = VelocityCacheManager.Read(cacheKey) as Account;

            if (account == null)
            {
                var productType = searchArg.ProductType;
                var eSupplier = searchArg.ESupplier;
                var defaultESupplierAccountIds = VelocityCacheManager.Read("InventoryBinding_DefaultESuppliersAccountIds")
                    as Dictionary<string, string>;
                var bookAccountId = VelocityCacheManager.Read("InventoryBinding_DefaultBookAccountId") as string;
                var entAccountId = VelocityCacheManager.Read("InventoryBinding_DefaultEntAccountId") as string;
                string vipAccountId = string.Empty;
                if (bookAccountId == null || entAccountId == null || defaultESupplierAccountIds == null)
                {
                    CartAccountHelper.GetDefaulAccountId(eSupplier, cartId, userId, out entAccountId, out bookAccountId,
                                                     out defaultESupplierAccountIds, out vipAccountId);
                }

                bool isVIPAccount;
                string accountId = ProductSearchController.SelectTheAccount(productType, eSupplier, entAccountId,
                                                                            bookAccountId, defaultESupplierAccountIds, vipAccountId, out isVIPAccount);

                if (!String.IsNullOrEmpty(accountId))
                {
                    var administrationProfileController = AdministrationProfileController.Current;
                    administrationProfileController.AccountRelated.PrimaryWarehouseNeeded = true;
                    administrationProfileController.AccountRelated.SecondaryWarehouseNeeded = true;
                    account = administrationProfileController.GetAccountById(accountId);
                    VelocityCacheManager.Write(cacheKey, account, VelocityCacheLevel.Request);
                    return account;
                }

                account = ProductSearchController.GetUserDefaultAccount(searchArg, userId);
                VelocityCacheManager.Write(cacheKey, account, VelocityCacheLevel.Request);
                return account;
            }

            return account;

        }

        //public static AccountDaoObject GetUserDefaultAccountDaoFromCartDetail(SearchResultInventoryStatusArg searchArg, string userId, string cartId)
        //{
        //    var cacheProductType = searchArg.ProductType;
        //    if (string.Compare(cacheProductType, ProductType.Movie.ToString(), StringComparison.OrdinalIgnoreCase) == 0)
        //    {
        //        cacheProductType = ProductType.Music.ToString();
        //    }

        //    var cacheKey = String.Format("UserDefaultAcctDao_{0}_{1}_{2}_{3}", cacheProductType, searchArg.ESupplier,
        //                                 userId, cartId);

        //    var account = VelocityCacheManager.Read(cacheKey) as AccountDaoObject;

        //    if (account == null)
        //    {
        //        var productType = searchArg.ProductType;
        //        var eSupplier = searchArg.ESupplier;
        //        var defaultESupplierAccountIds = VelocityCacheManager.Read("InventoryBinding_DefaultESuppliersAccountDaoIds")
        //            as Dictionary<string, string>;
        //        string bookAccountId = "";
        //        var entAccountId = "";
        //        string vipAccountId = string.Empty;
        //        if (bookAccountId == null || entAccountId == null || defaultESupplierAccountIds == null)
        //        {
        //            CartAccountHelper.GetDefaulAccountId(eSupplier, cartId, userId, out entAccountId, out bookAccountId,
        //                                             out defaultESupplierAccountIds, out vipAccountId);
        //        }

        //        bool isVIPAccount;
        //        string accountId = ProductSearchController.SelectTheAccount(productType, eSupplier, entAccountId,
        //                                                                    bookAccountId, defaultESupplierAccountIds, vipAccountId, out isVIPAccount);

        //        if (!String.IsNullOrEmpty(accountId))
        //        {
        //            account = ProfileController.Current.GetAccountDaoByIdForAdditionalInfo(accountId);
        //            VelocityCacheManager.Write(cacheKey, account, VelocityCacheLevel.Request);
        //            return account;
        //        }

        //        account = ProductSearchController.GetUserDefaultAccountDaoObject(searchArg, userId);
        //        VelocityCacheManager.Write(cacheKey, account, VelocityCacheLevel.Request);
        //        return account;
        //    }

        //    return account;
        //}

        public static InventoryStockStatus ShowInventoryIfPawPrints(IEnumerable<InventoryStockStatus> listInventoryStockStatus,
            string primaryWareHouse, string secondWareHouse, string supplierCode, MarketType? marketType)
        {
            InventoryStockStatus additionalWarehouse = null;
            var pubCode = String.Empty;
            
            if (marketType == MarketType.Retail)
            {
                foreach (InventoryStockStatus iss in listInventoryStockStatus)
                    iss.OnHandInventory = GeneralConstants.DefaultQuantity;
            }
            else
            {
                if (!String.IsNullOrEmpty(supplierCode))
                {
                    pubCode = supplierCode.Trim();
                    if (pubCode.Equals(SearchFieldValue.SupplierCodePPBTB, StringComparison.InvariantCultureIgnoreCase))
                    {
                        //PPBTB - add the inventory from the Bridgewater warehouse to the customer's primary warehouse
                        additionalWarehouse = RecalculateInventoryIfPawnPrints(listInventoryStockStatus, primaryWareHouse,
                                                                               secondWareHouse, InventoryWareHouseCode.Som);
                    }

                    else if (pubCode.Equals(SearchFieldValue.SupplierCodePPBTM, StringComparison.InvariantCultureIgnoreCase))
                    {
                        //PPBTM - add the inventory from the Momence warehouse to the customer's primary warehouse.
                        additionalWarehouse = RecalculateInventoryIfPawnPrints(listInventoryStockStatus, primaryWareHouse,
                                                                               secondWareHouse, InventoryWareHouseCode.Mom);
                    }
                }
            }
            return additionalWarehouse;
        }

        private static InventoryStockStatus RecalculateInventoryIfPawnPrints(IEnumerable<InventoryStockStatus> listInventoryStockStatus,
            string primaryWareHouse, string secondWareHouse, string warehouseCode)
        {
            InventoryStockStatus additionalWarehouse = null;
            if (IsEqual(warehouseCode, primaryWareHouse) || IsEqual(warehouseCode, secondWareHouse))
                return null;
            InventoryStockStatus primaryInvStockStatus = null;
            InventoryStockStatus invStockStatus = null;
            foreach (InventoryStockStatus st in listInventoryStockStatus)
                if (IsEqual(st.WareHouseCode, primaryWareHouse))
                    primaryInvStockStatus = st;
                else if (IsEqual(st.WareHouseCode, warehouseCode))
                    invStockStatus = st;

            if (invStockStatus != null && !String.IsNullOrEmpty(invStockStatus.OnHandInventory))
            {
                int iquantityAdditional = 0;
                Int32.TryParse(invStockStatus.OnHandInventory, out iquantityAdditional);
                if (iquantityAdditional != 0)
                {
                    if (primaryInvStockStatus == null)
                        return null;
                    int quantity = 0;
                    Int32.TryParse(primaryInvStockStatus.OnHandInventory, out quantity);
                    quantity += iquantityAdditional;
                    additionalWarehouse = invStockStatus;
                    invStockStatus.OnHandInventory = GeneralConstants.DefaultQuantity;
                    primaryInvStockStatus.OnHandInventory = quantity.ToString();
                }
            }
            return additionalWarehouse;
        }

        private static bool CheckIfWareHouseCodeIsExisted(IEnumerable<InventoryStockStatus> listInventoryStockStatus, string wareHouseCode)
        {
            return listInventoryStockStatus.Any(inventoryStockStatus => IsEqual(inventoryStockStatus.WareHouseCode, wareHouseCode));
        }

        public static void AddWareHouseIfNeed(List<InventoryStockStatus> listInventoryStockStatus, string primaryWareHouse, string secondWareHouse)
        {
            if (listInventoryStockStatus != null)
            {
                if (listInventoryStockStatus.Count < 1)
                {
                    AddPrimaryAndSecondaryWareHouse(listInventoryStockStatus, primaryWareHouse, secondWareHouse);
                }
                else
                {
                    if (!String.IsNullOrEmpty(primaryWareHouse) &&
                        !CheckIfWareHouseCodeIsExisted(listInventoryStockStatus, primaryWareHouse))
                    {
                        AddPrimaryWareHouse(listInventoryStockStatus, primaryWareHouse);
                    }
                    if (!String.IsNullOrEmpty(secondWareHouse) &&
                        !CheckIfWareHouseCodeIsExisted(listInventoryStockStatus, secondWareHouse))
                    {
                        AddSecondaryWareHouse(listInventoryStockStatus, secondWareHouse);
                    }
                }
            }
        }

        private static void AddPrimaryAndSecondaryWareHouse(List<InventoryStockStatus> listInventoryStockStatus, string primaryWareHouse,
                                                            string secondWareHouse)
        {
            if (!String.IsNullOrEmpty(primaryWareHouse))
            {
                AddPrimaryWareHouse(listInventoryStockStatus, primaryWareHouse);
            }
            if (!String.IsNullOrEmpty(secondWareHouse))
            {
                AddSecondaryWareHouse(listInventoryStockStatus, secondWareHouse);
            }
        }

        private static void AddSecondaryWareHouse(List<InventoryStockStatus> listInventoryStockStatus, string secondWareHouse)
        {
            //var secondaryWareHouseName = secondWareHouse + GeneralConstants.SecondaryMark;

            var inventoryHelper = InventoryHelper4MongoDb.GetInstance();
            var secondaryWareHouseName = inventoryHelper.WarehouseDesc.ContainsKey(secondWareHouse) ? inventoryHelper.WarehouseDesc[secondWareHouse] : secondWareHouse
                + GeneralConstants.SecondaryMark;

            var secondaryInventoryStockStatus = new InventoryStockStatus
                                                    {
                                                        WareHouseCode = secondWareHouse,
                                                        WareHouse = secondaryWareHouseName
                                                    };
            listInventoryStockStatus.Add(secondaryInventoryStockStatus);
        }

        private static void AddPrimaryWareHouse(List<InventoryStockStatus> listInventoryStockStatus, string primaryWareHouse)
        {
            var inventoryHelper = InventoryHelper4MongoDb.GetInstance();
            var primaryWareHouseName = inventoryHelper.WarehouseDesc.ContainsKey(primaryWareHouse) ? inventoryHelper.WarehouseDesc[primaryWareHouse] : primaryWareHouse
                + GeneralConstants.PrimaryMark;
            
            //var primaryWareHouseName = primaryWareHouse + GeneralConstants.PrimaryMark;
            var primaryInventoryStockStatus = new InventoryStockStatus
                                                  {
                                                      WareHouseCode = primaryWareHouse,
                                                      WareHouse = primaryWareHouseName
                                                  };
            listInventoryStockStatus.Add(primaryInventoryStockStatus);
        }

        public static List<InventoryStockStatus> SortInventoryList(List<InventoryStockStatus> listInventoryStockStatus,
                                                                    string primaryWareHouse,
                                                                    string secondWareHouse,
                                                                    InventoryStockStatus additionalWarehouse,
                                                                    string userId,
                                                                    Account account,
                                                                    out bool displayInventoryForAllWareHouse)
        {
            try
            {
                displayInventoryForAllWareHouse = IsDisplayAllWarehouse(account, userId);
                if (listInventoryStockStatus != null && listInventoryStockStatus.Count > 0)
                {
                    var sortedList = new List<InventoryStockStatus>();
                    var remainList = new List<InventoryStockStatus>();
                    var vipList = new List<InventoryStockStatus>();

                    //sort and mark primary/secondary
                    foreach (InventoryStockStatus st in listInventoryStockStatus)
                    {
                        st.FormalWareHouseCode = st.WareHouseCode = ChangeRno2RenIfAny(st.WareHouseCode);
                        st.WareHouse = ChangeRno2RenIfAny(st.WareHouse);
                        if (IsEqual(st.WareHouseCode, primaryWareHouse))
                        {
                            st.WareHouse += GeneralConstants.PrimaryMark;
                            st.WareHouseCode += GeneralConstants.PrimaryMark;
                            sortedList.Insert(0, st);
                        }
                        else if (IsEqual(st.WareHouseCode, secondWareHouse))
                        {
                            st.WareHouse += GeneralConstants.SecondaryMark;
                            st.WareHouseCode += GeneralConstants.SecondaryMark;
                            sortedList.Add(st);
                        }
                        else if (IsVIPWarehouse(st.WareHouseCode))
                        {
                            st.WareHouse += GeneralConstants.VipMark;
                            st.WareHouseCode += GeneralConstants.VipMark;
                            vipList.Add(st);
                        }
                        else
                            remainList.Add(st);
                    }

                    if (displayInventoryForAllWareHouse)
                    {
                        sortedList.AddRange(remainList);
                    }

                    if (vipList.Count > 0)
                    {
                        var marketType = SiteContext.Current.MarketType;
                        if (marketType != null && (marketType == MarketType.AcademicLibrary
                        || marketType == MarketType.PublicLibrary
                        || marketType == MarketType.SchoolLibrary))
                        {
                            sortedList.InsertRange(0, vipList);
                        }
                        else
                            sortedList.AddRange(vipList);
                    }

                    return sortedList;
                }
                return null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static List<InventoryStockStatus> SortInventoryList(List<InventoryStockStatus> listInventoryStockStatus,
                                                                    string primaryWareHouse,
                                                                    string secondWareHouse,
                                                                    InventoryStockStatus additionalWarehouse,
                                                                    bool displayInventoryForAllWareHouse)
        {
            try
            {
                if (listInventoryStockStatus != null && listInventoryStockStatus.Count > 0)
                {
                    var sortedList = new List<InventoryStockStatus>();
                    var remainList = new List<InventoryStockStatus>();
                    var vipList = new List<InventoryStockStatus>();

                    //sort and mark primary/secondary
                    foreach (InventoryStockStatus st in listInventoryStockStatus)
                    {
                        st.FormalWareHouseCode = st.WareHouseCode = ChangeRno2RenIfAny(st.WareHouseCode);
                        st.WareHouse = ChangeRno2RenIfAny(st.WareHouse);
                        if (IsEqual(st.WareHouseCode, primaryWareHouse))
                        {
                            st.WareHouse += GeneralConstants.PrimaryMark;
                            st.WareHouseCode += GeneralConstants.PrimaryMark;
                            sortedList.Insert(0, st);
                        }
                        else if (IsEqual(st.WareHouseCode, secondWareHouse))
                        {
                            st.WareHouse += GeneralConstants.SecondaryMark;
                            st.WareHouseCode += GeneralConstants.SecondaryMark;
                            sortedList.Add(st);
                        }
                        else if (IsVIPWarehouse(st.WareHouseCode))
                        {
                            st.WareHouse += GeneralConstants.VipMark;
                            st.WareHouseCode += GeneralConstants.VipMark;
                            vipList.Add(st);
                        }
                        else
                            remainList.Add(st);
                    }

                    if (displayInventoryForAllWareHouse)
                    {
                        sortedList.AddRange(remainList);
                    }

                    if (vipList.Count > 0)
                    {
                        var marketType = SiteContext.Current.MarketType;
                        if (marketType != null && (marketType == MarketType.AcademicLibrary
                        || marketType == MarketType.PublicLibrary
                        || marketType == MarketType.SchoolLibrary))
                        {
                            sortedList.InsertRange(0, vipList);
                        }
                        else
                            sortedList.AddRange(vipList);
                    }

                    return sortedList;
                }
                return null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static bool IsDisplayAllWarehouse(Account account, string userId)
        {
            //var profileController = ProfileController.Current;
            //profileController.UserProfilePropertiesToReturn.Add(UserProfile.PropertyName.OrganizationId);
            //var user = profileController.GetUserById(userId);

            var user = CSObjectProxy.GetUserProfileForSearchResult();

            if (user == null)
            {
                Logger.Write("Inventory", "User not found", false);
                return false;
            }

            var organizationId = user.Organization.Target.Id;

            var profileControllerForAdmin = AdministrationProfileController.Current;
            profileControllerForAdmin.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AllWarehouse);
            //var organization = profileControllerForAdmin.GetOrganization(user.OrganizationId);
            var organization = profileControllerForAdmin.GetOrganization(organizationId);

            if ((account == null) || (organization != null && organization.AllWarehouse.HasValue && organization.AllWarehouse.Value))
            {
                return true;
            }
            return false;
        }
        /// <summary>        
        /// Remove invalid warehouse code: empty or not included in {COM, MOM, REN, SOM}
        /// Correct the quantity
        /// Only apply for horizontal display
        /// </summary>
        /// <param name="listInventoryStockStatus"></param>
        public static List<InventoryStockStatus> CorrectAndFilterInventory(List<InventoryStockStatus> listInventoryStockStatus)
        {
            try
            {
                var refinedList = new List<InventoryStockStatus>();
                var vipList = new List<InventoryStockStatus>();

                if (listInventoryStockStatus != null && listInventoryStockStatus.Count > 0)
                {
                    foreach (InventoryStockStatus st in listInventoryStockStatus)
                    {
                        if (InventoryHelper.IsVIPWarehouse(st.FormalWareHouseCode))
                        {
                            vipList.Add(st);
                        }
                        else if (ValidateInventoryStockStatus(st))
                        {
                            st.OnHandInventory = CorrectQuantity(st.OnHandInventory);
                            refinedList.Add(st);
                        }
                    }
                }
                if (refinedList.Count == 0)
                {
                    AddDefaultFourItems(refinedList);
                }
                if (refinedList.Count == 1)
                {
                    AddMoreThreeItems(refinedList);
                }
                else if (refinedList.Count == 2)
                {
                    AddMoreTwoItems(refinedList);
                }
                else if (refinedList.Count == 3)
                {
                    AddMoreOneItem(refinedList);
                }

                if (vipList.Count > 0)
                {
                    if (SiteContext.Current.MarketType != null && (SiteContext.Current.MarketType == MarketType.AcademicLibrary
                        || SiteContext.Current.MarketType == MarketType.PublicLibrary
                        || SiteContext.Current.MarketType == MarketType.SchoolLibrary))
                    {
                        refinedList.InsertRange(0, vipList);
                    }
                    else
                        refinedList.AddRange(vipList);
                }

                return refinedList;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private static void AddDefaultFourItems(List<InventoryStockStatus> listInventoryStockStatus)
        {
            try
            {
                listInventoryStockStatus.AddRange(
                       from s in DefaultWhList
                       select new InventoryStockStatus()
                       {
                           WareHouseCode = s,
                           OnHandInventory = GeneralConstants.DefaultQuantity
                       });
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private static void AddMoreThreeItems(List<InventoryStockStatus> listInventoryStockStatus)
        {
            try
            {
                var inventoryHelper = InventoryHelper4MongoDb.GetInstance();
                
                var warehouseFirstItem = listInventoryStockStatus[0].FormalWareHouseCode;
                listInventoryStockStatus.AddRange(
                    from s in DefaultWhList
                    where String.Compare(s, warehouseFirstItem, StringComparison.OrdinalIgnoreCase) != 0
                    select new InventoryStockStatus()
                                {
                                    WareHouseCode = s,
                                    OnHandInventory = GeneralConstants.DefaultQuantity,
                                    WareHouse = inventoryHelper.WarehouseDesc.ContainsKey(s) ? inventoryHelper.WarehouseDesc[s] : s
                                });
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private static void AddMoreTwoItems(List<InventoryStockStatus> listInventoryStockStatus)
        {
            try
            {
                var warehouseFirstItem = listInventoryStockStatus[0].FormalWareHouseCode;
                var warehouseSecItem = listInventoryStockStatus[1].FormalWareHouseCode;
                listInventoryStockStatus.AddRange(
                    from s in DefaultWhList
                    where String.Compare(s, warehouseFirstItem, StringComparison.OrdinalIgnoreCase) != 0 &&
                    String.Compare(s, warehouseSecItem, StringComparison.OrdinalIgnoreCase) != 0
                    select new InventoryStockStatus()
                                {
                                    WareHouseCode = s,
                                    OnHandInventory = GeneralConstants.DefaultQuantity
                                });
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private static void AddMoreOneItem(List<InventoryStockStatus> listInventoryStockStatus)
        {
            try
            {
                var warehouseFirstItem = listInventoryStockStatus[0].FormalWareHouseCode;
                var warehouseSecItem = listInventoryStockStatus[1].FormalWareHouseCode;
                var warehouseThirdItem = listInventoryStockStatus[2].FormalWareHouseCode;
                listInventoryStockStatus.AddRange(
                    from s in DefaultWhList
                    where String.Compare(s, warehouseFirstItem, StringComparison.OrdinalIgnoreCase) != 0
                    && String.Compare(s, warehouseSecItem, StringComparison.OrdinalIgnoreCase) != 0
                    && String.Compare(s, warehouseThirdItem, StringComparison.OrdinalIgnoreCase) != 0
                    select new InventoryStockStatus()
                                {
                                    WareHouseCode = s,
                                    OnHandInventory = GeneralConstants.DefaultQuantity
                                });
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private static bool ValidateInventoryStockStatus(InventoryStockStatus item)
        {
            try
            {
                return !String.IsNullOrEmpty(item.WareHouse) &&
                        (String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.Com, StringComparison.OrdinalIgnoreCase) == 0 ||
                         String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.Mom, StringComparison.OrdinalIgnoreCase) == 0 ||
                         String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.Ren, StringComparison.OrdinalIgnoreCase) == 0 ||
                         String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.Som, StringComparison.OrdinalIgnoreCase) == 0 ||
                         String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.VIM, StringComparison.OrdinalIgnoreCase) == 0 ||
                         String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.VIE, StringComparison.OrdinalIgnoreCase) == 0 ||
                         String.Compare(item.FormalWareHouseCode, InventoryWareHouseCode.SUP, StringComparison.OrdinalIgnoreCase) == 0);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private static string CorrectQuantity(string quantity)
        {
            try
            {
                int iQuantity;
                if (Int32.TryParse(quantity, out iQuantity))
                {
                    return quantity;
                }
                return GeneralConstants.DefaultQuantity;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        /// <summary>
        /// Compare Warehouse
        /// </summary>
        /// <param name="warehouseA"></param>
        /// <param name="warehouseB"></param>
        /// <returns></returns>
        private static bool IsEqual(string warehouseA, string warehouseB)
        {
            try
            {
                warehouseA = ChangeRno2RenIfAny(warehouseA);
                warehouseB = ChangeRno2RenIfAny(warehouseB);
                return String.Compare(warehouseA, warehouseB, StringComparison.OrdinalIgnoreCase) == 0;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private static string ChangeRno2RenIfAny(string warehouse)
        {
            try
            {
                if (String.Compare(warehouse, InventoryWareHouseCode.Rno, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    return InventoryWareHouseCode.Ren;
                }
                return warehouse;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static List<InventoryStockStatus> SortRealTimeInventoryList(List<InventoryStockStatus> listInventoryStockStatus,
                                                                            string userId,
                                                                            Account account)
        {
            try
            {
                if (listInventoryStockStatus != null && listInventoryStockStatus.Count > 0)
                {
                    var sortedList = new List<InventoryStockStatus>();
                    var remainList = new List<InventoryStockStatus>();
                    var vipList = new List<InventoryStockStatus>();

                    string primaryWareHouse = String.Empty;
                    string secondaryWareHouse = String.Empty;
                    if (account != null)
                    {
                        if (account.PrimaryWarehouse != null)
                            primaryWareHouse = ((Warehouse)account.PrimaryWarehouse.Target).Code;

                        if (account.SecondaryWarehouse != null)
                            secondaryWareHouse = ((Warehouse)account.SecondaryWarehouse.Target).Code;
                    }

                    //sort and mark primary/secondary
                    foreach (InventoryStockStatus st in listInventoryStockStatus)
                    {
                        if (IsEqual(st.WareHouseCode, primaryWareHouse))
                        {
                            st.WareHouse += GeneralConstants.PrimaryMark;
                            st.WareHouseCode += GeneralConstants.PrimaryMark;
                            sortedList.Insert(0, st);
                        }
                        else if (IsEqual(st.WareHouseCode, secondaryWareHouse))
                        {
                            st.WareHouse += GeneralConstants.SecondaryMark;
                            st.WareHouseCode += GeneralConstants.SecondaryMark;
                            sortedList.Add(st);
                        }
                        else if (IsVIPWarehouse(st.WareHouseCode))
                        {
                            st.WareHouse += GeneralConstants.VipMark;
                            st.WareHouseCode += GeneralConstants.VipMark;
                            vipList.Add(st);
                        }
                        else
                        {
                            remainList.Add(st);
                        }
                    }

                    sortedList.AddRange(remainList);

                    if (vipList.Count > 0)
                    {
                        var marketType = SiteContext.Current.MarketType;
                        if (marketType != null && (marketType == MarketType.AcademicLibrary
                        || marketType == MarketType.PublicLibrary
                        || marketType == MarketType.SchoolLibrary))
                        {
                            sortedList.InsertRange(0, vipList);
                        }
                        else
                            sortedList.AddRange(vipList);
                    }

                    return sortedList;
                }
                return null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static List<string> GetSkusList(IList<ProductSearchResultItem> productInfos,
                                                IDictionary<string, Account> dictAccounts, bool fromReviewAndSubmitOrderPage = true)
        {
            if (productInfos == null || productInfos.Count == 0) return null;

            const string FALSE = "0";
            const string TRUE = "1";

            var results = new List<string>();
            foreach (var product in productInfos)
            {
                var productType = RefineProductTypeToMusicIfMovie(product.ProductType);

                if (fromReviewAndSubmitOrderPage)
                {
                    if (string.Compare(productType, ProductType.Book.ToString(), StringComparison.OrdinalIgnoreCase) == 0
                    && !string.IsNullOrEmpty(product.ESupplier))
                        continue;
                }

                var checkLeReserve = FALSE;
                var accountInventoryType = String.Empty;
                var inventoryReserveNumber = String.Empty;

                if (dictAccounts == null || dictAccounts.Count == 0)
                {
                    results.Add(String.Format("{0}@{1}@{2}@{3}", product.BTKey, checkLeReserve, accountInventoryType, inventoryReserveNumber));
                    continue;
                }

                if (dictAccounts.ContainsKey(productType))
                {
                    var account = dictAccounts[productType];
                    if (account != null)
                    {
                        if (account.CheckLEReserve != null && account.CheckLEReserve.Value)
                        {
                            checkLeReserve = TRUE;
                        }
                        if (account.AccountInventoryType != null)
                        {
                            accountInventoryType = account.AccountInventoryType;
                        }
                        if (account.InventoryReserveNumber != null)
                        {
                            inventoryReserveNumber = account.InventoryReserveNumber;
                        }
                    }
                }
                results.Add(String.Format("{0}@{1}@{2}@{3}", product.BTKey, checkLeReserve, accountInventoryType, inventoryReserveNumber));
            }

            return results;
        }

        public static string RefineProductTypeToMusicIfMovie(string productType)
        {
            if (string.Compare(productType, ProductType.Movie.ToString()) == 0)
            {
                productType = ProductType.Music.ToString();
            }
            return productType;
        }

        public static bool IsVIPWarehouse(string warehouse)
        {
            return (warehouse == "VIE" || warehouse == "VIM" || warehouse == "VIP");
        }

        public static bool IsDisplaySuperWarehouse(MarketType marketType)
        {
            if (IsVIPEnabled())
            {

                return
                    (marketType == MarketType.AcademicLibrary ||
                        marketType == MarketType.PublicLibrary ||
                        marketType == MarketType.SchoolLibrary ||
                        (marketType == MarketType.Retail && !IsUSCountry(SiteContext.Current.CountryCode))
                );
            }

            return false;
        }

        public static bool IsDisplayVIPWarehouse(MarketType marketType)
        {
            return (marketType == MarketType.Retail && IsUSCountry(SiteContext.Current.CountryCode) && IsVIPEnabled());
        }

        private static bool IsUSCountry(string countryCode)
        {
            bool isUS = false;

            if (!string.IsNullOrEmpty(countryCode))
            {
                isUS = (countryCode == "US" || countryCode == "USA");
            }
            return isUS;
        }

        public static bool IsVIPEnabled()
        {
            bool retVal = false;
            if (!string.IsNullOrEmpty(SiteContext.Current.OrganizationId))
            {
                var orgPremiumServicesStatus = OrganizationDAO.Instance.GetOrganizationPremiumServices(SiteContext.Current.OrganizationId);

                if (orgPremiumServicesStatus != null && orgPremiumServicesStatus.vipEnabled)
                {
                    retVal = true;
                }

            }
            return retVal;
        }

        public static void AddSuperWarehouse(ref DataSet dsInventory)
        {
            var dictBTKey = new Dictionary<string, List<DataRow>>();

            var rows = dsInventory.Tables[0].Rows;
            for (int i = 0; i < rows.Count; i++)
            {
                var row = rows[i];

                var btKey = row[PropertyName.BTKey].ToString();

                var wareHouse = row[PropertyName.WarehouseId].ToString();
                if (InventoryHelper.IsVIPWarehouse(wareHouse))
                {
                    if (!dictBTKey.ContainsKey(btKey))
                    {
                        dictBTKey[btKey] = new List<DataRow> { row };
                    }
                    else
                    {
                        dictBTKey[btKey].Add(row);
                    }
                }
            }


            foreach (KeyValuePair<string, List<DataRow>> kvpVIPInventory in dictBTKey)
            {
                int stockCondition = 0;
                int inStockForRequest = 0;
                int onOrderQuantity = 0;
                int invDemandNumber = 0;
                int lineItem = 0;

                string btKey = kvpVIPInventory.Key;

                foreach (DataRow datarow in kvpVIPInventory.Value)
                {
                    stockCondition += int.Parse(datarow[PropertyName.StockCondition].ToString());
                    inStockForRequest += int.Parse(datarow[PropertyName.InStockForRequest].ToString());
                    onOrderQuantity += int.Parse(datarow[PropertyName.OnOrderQuantity].ToString());
                    invDemandNumber += datarow[PropertyName.Last30DayDemand] == null ? 0 : int.Parse(datarow[PropertyName.Last30DayDemand].ToString());
                    lineItem += int.Parse(datarow[PropertyName.LineItem].ToString());
                }

                if (inStockForRequest >= GetSuperWarehouseInventoryThreshold())
                {
                    DataRow drSuperWarehouse = dsInventory.Tables[0].NewRow();
                    drSuperWarehouse[PropertyName.WarehouseId] = InventoryWareHouseCode.SUP;
                    drSuperWarehouse[PropertyName.LineItem] = lineItem;
                    drSuperWarehouse[PropertyName.StockCondition] = stockCondition;
                    drSuperWarehouse[PropertyName.InStockForRequest] = inStockForRequest;
                    drSuperWarehouse[PropertyName.OnOrderQuantity] = onOrderQuantity;
                    drSuperWarehouse[PropertyName.Last30DayDemand] = invDemandNumber;
                    drSuperWarehouse[PropertyName.BTKey] = btKey;

                    dsInventory.Tables[0].Rows.Add(drSuperWarehouse);
                }
            }

        }


        public static InventoryResults FilterVIPWarehousesInventory(InventoryResults inventoryResults, MarketType marketType)
        {
            InventoryResults vipInventoryResults = new InventoryResults();
            List<InventoryStockStatus> listVIPInventoryStockStatus = new List<InventoryStockStatus>();

            foreach (InventoryStockStatus inventoryStockStatus in inventoryResults.InventoryStock)
            {
                if (IsDisplayVIPWarehouse(marketType) &&
                    (inventoryStockStatus.FormalWareHouseCode == InventoryWareHouseCode.VIM || inventoryStockStatus.FormalWareHouseCode == InventoryWareHouseCode.VIE))
                {
                    listVIPInventoryStockStatus.Add(inventoryStockStatus);
                }
                else if (IsDisplaySuperWarehouse(marketType) && inventoryStockStatus.FormalWareHouseCode == InventoryWareHouseCode.SUP)
                {
                    listVIPInventoryStockStatus.Add(inventoryStockStatus);
                }
            }

            vipInventoryResults.BTKey = inventoryResults.BTKey;
            vipInventoryResults.InventoryStock = listVIPInventoryStockStatus;
            vipInventoryResults.DisplayInventoryForAllWareHouse = inventoryResults.DisplayInventoryForAllWareHouse;
            vipInventoryResults.IsStockCheckInventory = inventoryResults.IsStockCheckInventory;
            
            return vipInventoryResults;

        }

        public static List<InventoryResults> FilterVIPWarehousesInventory(List<InventoryResults> inventoryResults, MarketType marketType)
        {
            List<InventoryResults> vipInventoryResults = new List<InventoryResults>();

            foreach (InventoryResults inventoryResult in inventoryResults)
            {
                InventoryResults vipInventoryResult = FilterVIPWarehousesInventory(inventoryResult, marketType);
                if (vipInventoryResult.InventoryStock.Count > 0)
                    vipInventoryResults.Add(vipInventoryResult);
            }

            return vipInventoryResults;
        }

        private static int GetSuperWarehouseInventoryThreshold()
        {
            var inventoryThreshold = GlobalConfiguration.ReadAppSetting(GlobalConfigurationKey.SuperWarehouseInventoryThreshold);
            if (inventoryThreshold != null)
            {
                if (!string.IsNullOrEmpty(inventoryThreshold.Value))
                    return Convert.ToInt32(inventoryThreshold.Value);
            }
            return 0;
        }
    }

}
