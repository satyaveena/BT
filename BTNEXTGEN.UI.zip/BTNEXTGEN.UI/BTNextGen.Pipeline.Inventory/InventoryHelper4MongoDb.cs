﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using BTNextGen.CartFramework;
using BTNextGen.Commerce.Inventory;
using BTNextGen.Commerce.Portal.Common;
using BTNextGen.Commerce.Portal.Common.Caching;
using BTNextGen.Commerce.Portal.Common.Configuration;
using BTNextGen.Commerce.Portal.Common.Constants;
using BTNextGen.Commerce.Portal.Common.Controllers;
using BTNextGen.Commerce.Portal.Common.DataAccessObject;
using BTNextGen.Commerce.Portal.Common.DataItems;
using BTNextGen.Commerce.Portal.Common.Helpers;
using BTNextGen.Commerce.Portal.Common.Logging;
using BTNextGen.Commerce.Portal.Common.Search;
using BTNextGen.Pipeline.Inventory.Contract;
using BTNextGen.VelocityCaching;
using BasketLineItemFacet = BT.TS360Constants.BasketLineItemFacet;
using CacheKeyConstant = BT.TS360Constants.CacheKeyConstant;
using ExceptionCategory = BT.TS360Constants.ExceptionCategory;
using InventoryWareHouseCode = BTNextGen.Pipeline.Internal.InventoryWareHouseCode;
using MarketType = BT.TS360Constants.MarketType;
using ProductType = BT.TS360Constants.ProductType;
using SearchFieldValue = BT.TS360Constants.SearchFieldValue;
using Newtonsoft.Json;

namespace BTNextGen.Pipeline.Inventory
{
    public class InventoryHelper4MongoDb
    {
        const string FALSE = "0";
        const string TRUE = "1";
        private const string LogCategory = "MONGODB";
        public const string Not_Available_for_Shipping = "Not_Available_for_Shipping";
        public const string Available_in_Primary_Warehouse = "Available_in_Primary_Warehouse";
        public const string Available_in_Secondary_Warehouse = "Available_in_Secondary_Warehouse";
        public const string Available_in_Other_Warehouses = "Available_in_Other_Warehouses";
        public const string Available_in_VIP_warehouses = "Available_in_VIP_warehouses";

        #region Members
        private Dictionary<string, Account> _defaultAccountsDict;
        //private Dictionary<string, AccountDaoObject> _defaultAccountsDaoDict;
        private Dictionary<string, BTKeyInventoryResult> _inventoryResultsDict;
        private List<SiteTermObject> _inventoryStatusList;
        private static InventoryHelper4MongoDb _instance;
        private string _userId;
        private MarketType? _marketType;
        private List<string> _warehouseIdsList;
        private Account _homeDeliveryAccount;
        //private AccountDaoObject _homeDeliveryAccountDao;
        #endregion

        #region Properties
        private string _inventoryDemandUrl;
        private Uri InventoryDemandUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_inventoryDemandUrl))
                {
                    _inventoryDemandUrl = GlobalConfiguration.ReadAppSetting("NoSQLApiUrl_InventoryDemand").Value;
                }
                return new Uri(_inventoryDemandUrl);
            }
        }

        private string _demandHistoryUrl;
        private Uri DemandHistoryUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_demandHistoryUrl))
                {
                    _demandHistoryUrl = GlobalConfiguration.ReadAppSetting("NoSQLApiUrl_DemandHistory").Value;
                }
                return new Uri(_demandHistoryUrl);
            }
        }

        private string _inventoryFacetUrl;
        private Uri CartInventoryFacetUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_inventoryFacetUrl))
                {
                    _inventoryFacetUrl = GlobalConfiguration.ReadAppSetting("NoSQLApiUrl_CartFacets").Value;
                }
                return new Uri(_inventoryFacetUrl);
            }
        }

        private List<Warehouse> _warehousesList;
        private List<Warehouse> Warehouses
        {
            get { return _warehousesList ?? (_warehousesList = CSProfileDAO.Instance.GetWareHouses()); }
        }

        // Code: Desc
        private Dictionary<string, string> _warehouseDesc;
        public Dictionary<string, string> WarehouseDesc
        {
            get
            {
                if (_warehouseDesc != null) return _warehouseDesc;
                _warehouseDesc = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var warehouse in Warehouses)
                {
                    if (string.IsNullOrEmpty(warehouse.Code)) continue;

                    if (_warehouseDesc.ContainsKey(warehouse.Code))
                    {
                        _warehouseDesc[warehouse.Code] = warehouse.Description;
                    }
                    else
                    {
                        _warehouseDesc.Add(warehouse.Code, warehouse.Description);
                    }
                }
                return _warehouseDesc;
            }
        }

        #endregion

        #region Public Methods

        public string CartId { get; set; }

        public string UserId
        {
            get
            {
                if (!string.IsNullOrEmpty(_userId))
                    return _userId;
                _userId = SiteContext.Current.UserId;
                return _userId;
            }
            set { _userId = value; }
        }

        public MarketType? MarketType
        {
            get
            {
                if (_marketType != null) return _marketType;
                _marketType = SiteContext.Current.MarketType;
                return _marketType;
            }
            set { _marketType = value; }
        }

        public List<SiteTermObject> InventoryStatusList
        {
            get { return _inventoryStatusList; }
        }

        public List<string> WarehouseIDsList
        {
            get
            {
                if (_warehouseIdsList != null && _warehouseIdsList.Any())
                    return _warehouseIdsList;
                _warehouseIdsList = GetWarehouseIDs();
                return _warehouseIdsList;
            }
            set { _warehouseIdsList = value; }
        }

        public static InventoryHelper4MongoDb GetInstance(string cartId = "")
        {
            if (_instance == null)
                return new InventoryHelper4MongoDb() { CartId = cartId };
            _instance.CartId = cartId;
            return _instance;
        }

        public List<InventoryResults> GetInventoryResultsForMultipleItems(IList<SearchResultInventoryStatusArg> args)
        {
            var results = new List<InventoryResults>();
            if (args == null || !args.Any()) return results;
            //Call to WebApi to get inventory result for all items from MongoDb
            //Dictionary [BTKEY, InventoryResults]
            GetInventoryResultsDict(args);

            //Set values for individual product item based on result above
            var displayInventoryForAllWareHouse = IsDisplayAllWarehouse();

            foreach (var item in args)
            {
                var productType = InventoryHelper.RefineProductTypeToMusicIfMovie(item.ProductType);

                //ignore ebooks
                if (string.Compare(productType, ProductType.Book.ToString(), StringComparison.OrdinalIgnoreCase) == 0
                    && !string.IsNullOrEmpty(item.ESupplier))
                    continue;

                var account = GetAccountByProductType(productType);
                var showAllWhs = displayInventoryForAllWareHouse || (account == null);

                int last30Demand;
                bool hasDemand;
                var inventoryItems = GetInventoryResultsForSingleItemInternal(item, true, account,
                    showAllWhs, out last30Demand, out hasDemand);

                inventoryItems = InventoryHelper.CorrectAndFilterInventory(inventoryItems);

                var inventoryResults = new InventoryResults
                {
                    DisplayInventoryForAllWareHouse = showAllWhs,
                    InventoryStock = inventoryItems,
                    BTKey = item.BTKey,
                    ProductType = item.ProductType,
                    TotalLast30Demand = last30Demand
                };

                results.Add(inventoryResults);
            }

            return results;
        }

        public List<SiteTermObject> GetInventoryStatus(IList<SearchResultInventoryStatusArg> args)
        {
            if (args == null || !args.Any()) return _inventoryStatusList;
            GetInventoryResultsDict(args);

            return _inventoryStatusList;
        }

        public List<InventoryStockStatus> GetInventoryResultsForSingleItem(SearchResultInventoryStatusArg searchArg,
            bool isHorizontalMode, out bool displayInventoryForAllWareHouse, out int last30DaysDemand, out bool hasDemand)
        {
            //
            var args = new List<SearchResultInventoryStatusArg>() { searchArg };
            //Call to WebApi to get inventory result for all items from MongoDb
            //Dictionary [BTKEY, InventoryResults]
            GetInventoryResultsDict(args);

            displayInventoryForAllWareHouse = IsDisplayAllWarehouse();

            var productType = InventoryHelper.RefineProductTypeToMusicIfMovie(searchArg.ProductType);
            var account = GetAccountByProductType(productType);
            displayInventoryForAllWareHouse = displayInventoryForAllWareHouse || (account == null);

            var inventoryItems = GetInventoryResultsForSingleItemInternal(searchArg, isHorizontalMode, account,
                displayInventoryForAllWareHouse, out last30DaysDemand, out hasDemand);

            return inventoryItems;
        }

        public Dictionary<string, BTKeyInventoryResult> GetInventoryWarehouseData(
            IList<SearchResultInventoryStatusArg> args)
        {
            var result = new Dictionary<string, BTKeyInventoryResult>();
            if (args == null || !args.Any()) return result;

            GetInventoryResultsDict(args);
            //[BTKEY: [WarehouseId: demand]]

            foreach (var arg in args)
            {
                if (string.IsNullOrEmpty(arg.BTKey)) continue;

                if (!result.ContainsKey(arg.BTKey) && _inventoryResultsDict.ContainsKey(arg.BTKey))
                {
                    var invRes = _inventoryResultsDict[arg.BTKey];
                    result.Add(arg.BTKey, invRes);
                }
            }
            return result;
        }

        public DemandHistoryResponse GetDemandHistory(string btkey, int pageIndex, string primaryWarehouse,
            string secondaryWarehouse)
        {
            var request = new DemandHistoryRequest()
                          {
                              BTKey = btkey,
                              PageIndex = pageIndex,
                              PrimaryWareHouseCode = primaryWarehouse,
                              SecondaryWareHouseCode = secondaryWarehouse
                          };

            var response = GetDemandHistory(request, DemandHistoryUrl);
            if (response != null)
            {
                if (response.Status == NoSqlServiceStatus.Success)
                    return response.Data;
                Logger.Write(LogCategory,
                        string.Format("MongoDb WebAPI Call For DemandHistory {0}, Error Code: {1}, Error Message {2}", response.Status,
                            response.ErrorCode, response.ErrorMessage), false);
            }
            return null;
        }

        public Dictionary<string, BTKeyInventoryResult> GetRawInventoryResults(
            IList<SearchResultInventoryStatusArg> args)
        {
            if (args == null || !args.Any()) return null;
            //Call to WebApi to get inventory result for all items from MongoDb
            //Dictionary [BTKEY, InventoryResults]
            GetInventoryResultsDict(args);

            return _inventoryResultsDict;
        }

        public List<InventoryStockStatus> GetInventoryForHomeDelivery(IList<SearchResultInventoryStatusArg> args,
            Account hdAccount, string userId)
        {
            UserId = userId;
            _homeDeliveryAccount = hdAccount;
            if (args == null || !args.Any()) return null;

            string primaryWh, secondaryWh;
            ProductSearchController.GetPrimarySecondaryWareHouse(out primaryWh, out secondaryWh, hdAccount);
            _warehouseIdsList = new List<string>() { primaryWh, secondaryWh };

            //Call to WebApi to get inventory result for all items from MongoDb
            //Dictionary [BTKEY, InventoryResults]
            GetInventoryResultsDict(args);
            if (_inventoryResultsDict == null) return null;

            var result = new List<InventoryStockStatus>();
            foreach (var arg in args)
            {
                var item = new InventoryStockStatus();
                if (!string.IsNullOrEmpty(arg.BTKey) && _inventoryResultsDict.ContainsKey(arg.BTKey))
                {
                    var warehouses = _inventoryResultsDict[arg.BTKey].Warehouses;
                    var sumOnOrderQty = 0;
                    var sumQuantityAvailable = 0;
                    foreach (var wh in warehouses)
                    {
                        sumOnOrderQty += wh.OnOrderQuantity;
                        sumQuantityAvailable += wh.InStockForRequest;
                    }
                    item.OnOrderQuantity = sumOnOrderQty;
                    item.QuantityAvailable = sumQuantityAvailable;
                }
                result.Add(item);
            }
            return result;
        }

        /*
        public CartLineFacet GetInventoryFacetForCartDetails(IList<SearchResultInventoryStatusArg> args, string facetPath = "",
            int nonInventoryTitleCount = 0)
        {
            string matchingBtkeys;
            return GetInventoryFacetForCartDetails(args, out matchingBtkeys, facetPath, nonInventoryTitleCount);
        }
        */

        public List<CartFacetsGroup> GetInventoryFacetForCartDetails(IList<SearchResultInventoryStatusArg> args, out string matchingBtkeys, string facetPath = "")
        {
            var results = new List<CartFacetsGroup>();
            matchingBtkeys = "";

            var request = PrepareInventoryFacetRequest(args, facetPath);
            if (request != null)
            {
                var noSqlResponse = GetInventoryFacetResults(request, CartInventoryFacetUrl);
                if (noSqlResponse != null)
                {
                    if (noSqlResponse.Status == NoSqlServiceStatus.Success)
                    {
                        if (noSqlResponse.Data != null)
                        {
                            matchingBtkeys = noSqlResponse.Data.MatchingBTKeys;
                            results = noSqlResponse.Data.CartFacetsGroupResults;
                        }
                    }
                    else
                    {
                        var errorMessage = string.Format("MongoDb WebAPI Call For CartFacets {0}, Error Code: {1}, Error Message {2}",
                                                          noSqlResponse.Status, noSqlResponse.ErrorCode, noSqlResponse.ErrorMessage);
                        Logger.Write(LogCategory, errorMessage, false);
                    }
                }
            }

            return results;
        }
        
        public NoSqlCartFacetsResponse GetInventoryFacetForCartDetails(InventoryFacetRequest request, Uri apiUrl)
        {
            //matchingBtkeys = "";
            var cartLineFacets = new NoSqlCartFacetsResponse();

            if (request != null)
            {
                //
                var response = GetInventoryFacetResults(request, apiUrl);
                if (response != null)
                {
                    if (response.Status == NoSqlServiceStatus.Success)
                    {
                        cartLineFacets = response.Data;
                    }
                    else
                    {
                        Logger.Write(LogCategory,
                            string.Format("MongoDb WebAPI Call For CartFacets {0}, Error Code: {1}, Error Message {2}", response.Status,
                                response.ErrorCode, response.ErrorMessage), false);
                    }
                }
            }

            return cartLineFacets;
        }

        #endregion

        #region Private Methods

        private List<InventoryStockStatus> GetInventoryResultsForSingleItemInternal(SearchResultInventoryStatusArg product,
            bool isHorizontalMode, Account account, bool displayInventoryForAllWareHouse, out int last30Demand, out bool hasDemand)
        {
            try
            {
                last30Demand = 0;
                //Get primary and secondary ware house
                string primaryWareHouse, secondWareHouse;
                GetPrimarySecondaryWarehouses(account, out primaryWareHouse, out secondWareHouse);

                WriteWhsInfoToSessionForLoadFacetUsing(primaryWareHouse, secondWareHouse);

                //Get Inventory Results list for each warehouse
                var listInventoryStockStatus = ConvertToInventoryStockStatuses(product.BTKey, out last30Demand, out hasDemand);

                if (isHorizontalMode)
                {
                    InventoryHelper.AddWareHouseIfNeed(listInventoryStockStatus, primaryWareHouse, secondWareHouse);
                }

                //TFS 1624:Inventory Display for Paw Print Titles//
                InventoryStockStatus additionalWarehouse = null;
                if (!String.IsNullOrEmpty(product.PubCodeD))
                {
                    if (product.PubCodeD.Contains(SearchFieldValue.PawPrintsPublisherName))
                    {
                        additionalWarehouse = InventoryHelper.ShowInventoryIfPawPrints(listInventoryStockStatus, primaryWareHouse,
                                                                       secondWareHouse, product.SupplierCode, MarketType);
                    }
                }

                listInventoryStockStatus = InventoryHelper.SortInventoryList(listInventoryStockStatus, primaryWareHouse, secondWareHouse,
                                                             additionalWarehouse, displayInventoryForAllWareHouse);

                return listInventoryStockStatus;
            }
            catch (Exception e)
            {
                Logger.RaiseException(e, ExceptionCategory.Search);
                throw;
            }
        }

        private void WriteWhsInfoToSessionForLoadFacetUsing(string primaryWareHouse, string secondWareHouse)
        {
            var whsCacheKey = string.Format(CacheKeyConstant.WhsInfoUserIdCacheKey, SiteContext.Current.UserId);
            var currentWhs = VelocityCacheManager.Read(whsCacheKey, VelocityCacheLevel.Farm) as List<string> ??
                             new List<string>();

            var availableWhs = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            availableWhs.Add("COM", "South");
            availableWhs.Add("MOM", "Central");
            availableWhs.Add("REN", "West");
            availableWhs.Add("RNO", "West");
            availableWhs.Add("SOM", "East");

            var needToUpdate = false;
            if (!string.IsNullOrEmpty(primaryWareHouse) && !currentWhs.Contains(primaryWareHouse))
            {
                needToUpdate = true;
                SettingAvailableWhs(primaryWareHouse, currentWhs, availableWhs);
            }

            if (!string.IsNullOrEmpty(secondWareHouse) && !currentWhs.Contains(secondWareHouse))
            {
                needToUpdate = true;
                SettingAvailableWhs(secondWareHouse, currentWhs, availableWhs);
            }

            if (needToUpdate)
            {
                VelocityCacheManager.Write(whsCacheKey, currentWhs, VelocityCacheLevel.Farm);
            }
        }

        private static void SettingAvailableWhs(string whsCode, List<string> currentWhs, Dictionary<string, string> availableWhs)
        {
            currentWhs.Add(whsCode);
            if (availableWhs.ContainsKey(whsCode) && !currentWhs.Contains(availableWhs[whsCode]))
            {
                currentWhs.Add(availableWhs[whsCode]);
            }

            if (whsCode.ToUpper() == "SOM" && !currentWhs.Contains("Bridgewater"))
            {
                currentWhs.Add("Bridgewater");
            }
        }

        private List<InventoryStockStatus> ConvertToInventoryStockStatuses(string btKey, out int last30Demand, out bool hasDemand)
        {
            last30Demand = 0;
            hasDemand = false;
            var inventoryResult = GetInventoryResultByBTkey(btKey);
            var inventoryStockStatuses = new List<InventoryStockStatus>();

            if (inventoryResult != null && inventoryResult.Warehouses != null && inventoryResult.Warehouses.Any())
            {
                foreach (var wh in inventoryResult.Warehouses)
                {
                    var inventoryStockStatus = new InventoryStockStatus();
                    var wareHouse = wh.WarehouseId;
                    //these 2 fields seem not used in UI
                    //inventoryStockStatus.LineItem = inventoryResult.LineItem;
                    //inventoryStockStatus.StockCondition = inventoryResult.StockCondition;
                    inventoryStockStatus.InStockForRequest = wh.InStockForRequest;
                    inventoryStockStatus.QuantityAvailable = wh.InStockForRequest;
                    inventoryStockStatus.OnOrderQuantity = wh.OnOrderQuantity;
                    inventoryStockStatus.WareHouseCode = wareHouse;
                    inventoryStockStatus.WareHouse = WarehouseDesc.ContainsKey(wareHouse) ? WarehouseDesc[wareHouse] : wareHouse;
                    inventoryStockStatus.InvDemandNumber = wh.Last30DayDemand;
                    inventoryStockStatus.OnHandInventory = wh.InStockForRequest.ToString();

                    inventoryStockStatuses.Add(inventoryStockStatus);
                }
                last30Demand = inventoryResult.TotalLast30Demand;
                hasDemand = inventoryResult.HasDemand;
            }

            return inventoryStockStatuses;
        }

        public bool IsDisplayAllWarehouse()
        {
            var user = CSObjectProxy.GetUserProfileForSearchResult();

            if (user == null)
            {
                Logger.Write("Inventory", "User not found", false);
                return false;
            }

            var organizationId = user.Organization.Target.Id;

            var profileControllerForAdmin = AdministrationProfileController.Current;
            profileControllerForAdmin.OrganizationPropertiesToReturn.Add(Organization.PropertyName.AllWarehouse);
            var organization = profileControllerForAdmin.GetOrganization(organizationId);

            if (organization != null && organization.AllWarehouse.HasValue && organization.AllWarehouse.Value)
            {
                return true;
            }
            return false;
        }

        //private Dictionary<string, AccountDaoObject> GetDefaultAccountDaoObject(IEnumerable<SearchResultInventoryStatusArg> args)
        //{
        //    var result = new Dictionary<string, AccountDaoObject>(StringComparer.OrdinalIgnoreCase);
        //    foreach (var searchArg in args)
        //    {
        //        var keyProductType = InventoryHelper.RefineProductTypeToMusicIfMovie(searchArg.ProductType);
        //        if (keyProductType == null || result.ContainsKey(keyProductType)) continue;

        //        var account = InventoryHelper.GetUserDefaultAccountDaoFromCartDetail(searchArg, UserId, CartId);

        //        result.Add(keyProductType, account);
        //    }
        //    return result;
        //}

        private Dictionary<string, Account> GetDefaultAccounts(IEnumerable<SearchResultInventoryStatusArg> args)
        {
            var result = new Dictionary<string, Account>(StringComparer.OrdinalIgnoreCase);
            foreach (var searchArg in args)
            {
                var keyProductType = InventoryHelper.RefineProductTypeToMusicIfMovie(searchArg.ProductType);
                if (keyProductType == null || result.ContainsKey(keyProductType)) continue;

                var account = _homeDeliveryAccount ?? InventoryHelper.GetUserDefaultAccountFromCartDetail(searchArg, UserId, CartId);

                result.Add(keyProductType, account);
            }
            return result;
        }

        private InventoryDemandRequest PrepareInventoryRequest(IList<SearchResultInventoryStatusArg> args)
        {
            var request = new InventoryDemandRequest();
            if (args == null || args.Count == 0) return null;

            request.OnItemDetail = args.Count == 1 && args[0].ForSingleItem;

            //get default account
            _defaultAccountsDict = GetDefaultAccounts(args);

            // get user reserved type
            string userReservedType = DistributedCacheHelper.GetCurrentUserReservedType();
            bool isLeUserReservedType = (userReservedType == "le");

            string bookPrimaryWareHouse = string.Empty;
            string bookSecondWareHouse = string.Empty;
            string entPrimaryWareHouse = string.Empty;
            string entSecondWareHouse = string.Empty;
            var btkeys = new List<BTKeys>();
            var pagePosition = 1;
            foreach (var product in args)
            {
                if (string.IsNullOrEmpty(product.BTKey)) continue;//TFS 17944 - ELMAH

                var productType = InventoryHelper.RefineProductTypeToMusicIfMovie(product.ProductType);
                //var checkLeReserve = isLeUserReservedType ? TRUE : FALSE;
                var checkLeReserve = isLeUserReservedType && productType.ToLower() == "book" ? TRUE : FALSE;
                var accountInventoryType = String.Empty;
                var inventoryReserveNumber = String.Empty;
                //no account presented
                if (_defaultAccountsDict == null || _defaultAccountsDict.Count == 0)
                {
                    btkeys.Add(new BTKeys(pagePosition, product.BTKey, checkLeReserve, accountInventoryType, inventoryReserveNumber));
                    continue;
                }

                //there's at least an account
                if (!string.IsNullOrEmpty(productType) && _defaultAccountsDict.ContainsKey(productType))
                {
                    var account = _defaultAccountsDict[productType];
                    if (account != null)
                    {
                        if (account.CheckLEReserve != null && account.CheckLEReserve.Value && productType.ToLower() == "book") //if (account.CheckLEReserve != null && account.CheckLEReserve.Value)
                        {
                            checkLeReserve = TRUE;
                        }
                        if (account.AccountInventoryType != null)
                        {
                            accountInventoryType = account.AccountInventoryType;
                        }
                        if (account.InventoryReserveNumber != null)
                        {
                            inventoryReserveNumber = account.InventoryReserveNumber;
                        }

                        if (productType.ToLower() == "book")
                        {
                            //get primary/secondary warehouse code
                            GetPrimarySecondaryWarehouses(account, out bookPrimaryWareHouse, out bookSecondWareHouse);
                        }
                        else
                        {
                            GetPrimarySecondaryWarehouses(account, out entPrimaryWareHouse, out entSecondWareHouse);
                        }
                    }
                }
                btkeys.Add(new BTKeys(pagePosition, product.BTKey, checkLeReserve, accountInventoryType, inventoryReserveNumber));

                //increase page position by 1
                pagePosition++;
            }

            //BtKeys
            request.BTKeys = btkeys.ToArray();

            //Warehouses
            List<string> listWhsIds = WarehouseIDsList;
            request.Warehouses = listWhsIds.Select(wh => new WareHouses() { WarehouseID = wh }).ToArray();

            //VIPEnabled
            request.VIPEnabled = InventoryHelper.IsVIPEnabled() ? TRUE : FALSE;

            //MarketType
            int marketType = MarketType.HasValue
                ? (int)MarketType.Value
                : (int)BTNextGen.Commerce.Portal.Common.Constants.MarketType.Any;

            request.MarketType = marketType.ToString();
            //Country Code
            request.CountryCode = SiteContext.Current.CountryCode;

            //primary warehouse
            request.BookPrimaryWarehouseCode = bookPrimaryWareHouse;

            //secondary warehouse
            request.BookSecondaryWarehouseCode = bookSecondWareHouse;

            //primary warehouse
            request.EntertainmentPrimaryWarehouseCode = entPrimaryWareHouse;

            //secondary warehouse
            request.EntertainmentSecondaryWarehouseCode = entSecondWareHouse;

            return request;
        }

        private List<string> GetWarehouseIDs()
        {
            var warehouseIds = new List<string>();
            var warehousesList = Warehouses;
            foreach (var wareHouse in warehousesList)
            {
                if (!warehouseIds.Contains(wareHouse.Id) && wareHouse.Id != InventoryWareHouseCode.Ren)
                {
                    warehouseIds.Add(wareHouse.Id);
                }
            }
            return warehouseIds;
        }

        private static NoSqlServiceResult<InventoryDemandResponse> GetInventoryResults(InventoryDemandRequest data,
            Uri webApiUri)
        {
            try
            {
                // Create a WebClient to POST the request
                using (WebClient client = new WebClient())
                {
                    // Set the header so it knows we are sending JSON
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";

                    var jss = new JavaScriptSerializer();
                    // Serialise the data we are sending in to JSON
                    string serialisedData = jss.Serialize(data);

                    // Make the request
                    var response = client.UploadString(webApiUri, serialisedData);

                    var logMessge = string.Format("Calling WebApi at: {0}{3}.InventoryDemandRequest: {1}{3}.InventoryDemandResponse: {2}",
                                                    webApiUri, serialisedData, response, Environment.NewLine);

                    Logger.Write(LogCategory, logMessge, false);
                    // Deserialise the response into a GUID
                    return jss.Deserialize<NoSqlServiceResult<InventoryDemandResponse>>(response);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return null;
        }

        private void GetInventoryResultsDict(IList<SearchResultInventoryStatusArg> args)
        {
            //if the set of args already fetched inventory data, just return
            if (!string.IsNullOrEmpty(args[0].BTKey) //TFS 17944 - ELMAH
                && _inventoryResultsDict != null && _inventoryResultsDict.ContainsKey(args[0].BTKey))
                return;

            var inventoryRequest = PrepareInventoryRequest(args);

            var response = GetInventoryResults(inventoryRequest, InventoryDemandUrl);

            if (response != null)
            {
                if (response.Status == NoSqlServiceStatus.Success)
                {
                    if (response.Data != null && response.Data.InventoryResults != null &&
                        response.Data.InventoryResults.Any())
                    {
                        _inventoryResultsDict = new Dictionary<string, BTKeyInventoryResult>();
                        _inventoryStatusList = new List<SiteTermObject>();
                        var notAvailableSaleInYourCountryText = SiteContext.GetLocalizedString(ResourceName.SearchResources, "NotAvailableSaleInYourCountry");
                        var userCountryCode = SiteContext.Current.CountryCode;

                        foreach (var res in response.Data.InventoryResults)
                        {
                            if (!string.IsNullOrEmpty(res.BTKey) && !_inventoryResultsDict.ContainsKey(res.BTKey))
                            {
                                // TFS19551: if blocked-export CountryCodes contain user's country code, show new inventory status
                                var isExportBlocked = args.Any(r => r.BTKey == res.BTKey &&
                                                               r.BlockedExportCountryCodes != null &&
                                                               r.BlockedExportCountryCodes.Contains(userCountryCode, StringComparer.CurrentCultureIgnoreCase));
                                if (isExportBlocked)
                                    res.InventoryStatus = notAvailableSaleInYourCountryText;

                                _inventoryResultsDict.Add(res.BTKey, res);

                                var itemData = new SiteTermObject(res.BTKey, res.InventoryStatus);
                                _inventoryStatusList.Add(itemData);
                            }
                        }
                    }
                }
                else
                {
                    Logger.Write(LogCategory,
                        string.Format(
                            "MongoDb WebAPI Call For InventoryDemand {0}, Error Code: {1}, Error Message {2}",
                            response.Status,
                            response.ErrorCode, response.ErrorMessage), false);
                }
            }
        }

        private Account GetAccountByProductType(string productType)
        {
            if (string.IsNullOrEmpty(productType)) return null;

            if (_defaultAccountsDict != null && _defaultAccountsDict.ContainsKey(productType))
            {
                return _defaultAccountsDict[productType];
            }
            return null;
        }

        //private AccountDaoObject GetAccountDaoByProductType(string productType)
        //{
        //    if (string.IsNullOrEmpty(productType)) return null;

        //    if (_defaultAccountsDaoDict != null && _defaultAccountsDaoDict.ContainsKey(productType))
        //    {
        //        return _defaultAccountsDaoDict[productType];
        //    }
        //    return null;
        //}

        private BTKeyInventoryResult GetInventoryResultByBTkey(string btKey)
        {
            if (_inventoryResultsDict != null && !string.IsNullOrEmpty(btKey) && _inventoryResultsDict.ContainsKey(btKey))
            {
                return _inventoryResultsDict[btKey];
            }
            return null;
        }

        private void GetPrimarySecondaryWarehouses(Account account, out string primaryWareHouse, out string secondWareHouse)
        {
            //Get primary and secondary ware house
            primaryWareHouse = String.Empty;
            secondWareHouse = String.Empty;

            if (account != null && account.PrimaryWarehouse != null)
            {
                primaryWareHouse = ((Warehouse)account.PrimaryWarehouse.Target).Code;
            }
            if (account != null && account.SecondaryWarehouse != null)
            {
                secondWareHouse = ((Warehouse)account.SecondaryWarehouse.Target).Code;
            }
        }

        private static NoSqlServiceResult<DemandHistoryResponse> GetDemandHistory(DemandHistoryRequest data,
           Uri webApiUri)
        {
            try
            {
                // Create a WebClient to POST the request
                using (WebClient client = new WebClient())
                {
                    Logger.Write(LogCategory, string.Format("Calling WebApi at: {0}", webApiUri), false);
                    // Set the header so it knows we are sending JSON
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    var jss = new JavaScriptSerializer();
                    // Serialise the data we are sending in to JSON
                    string serialisedData = jss.Serialize(data);

                    Logger.Write(LogCategory, string.Format("DemandHistoryRequest: {0}", serialisedData), false);
                    // Make the request
                    var response = client.UploadString(webApiUri, serialisedData);
                    Logger.Write(LogCategory, string.Format("DemandHistoryResponse: {0}", response), false);

                    // Deserialise the response into a GUID
                    return jss.Deserialize<NoSqlServiceResult<DemandHistoryResponse>>(response);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return null;
        }


        private static NoSqlServiceResult<NoSqlCartFacetsResponse> GetInventoryFacetResults(InventoryFacetRequest data,
           Uri webApiUri)
        {
            try
            {
                // Create a WebClient to POST the request
                using (WebClient client = new WebClient())
                {
                    // Set the header so it knows we are sending JSON
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    
                    // Serialise the data we are sending in to JSON
                    var jsonSettings = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                    string serialisedData = JsonConvert.SerializeObject(data, Formatting.None, jsonSettings);

                    Logger.Write(LogCategory, string.Format("Calling WebApi at: {0}. FacetRequest: {1}", webApiUri, serialisedData), false);
                    // Make the request
                    var response = client.UploadString(webApiUri, serialisedData);
                    Logger.Write(LogCategory, string.Format("NoSqlCartFacetsResponse: {0}", response), false);

                    // Deserialise the response into a GUID
                    return JsonConvert.DeserializeObject<NoSqlServiceResult<NoSqlCartFacetsResponse>>(response);
                }
            }
            catch (Exception ex)
            {
                if (System.Web.HttpContext.Current != null)
                    Logger.LogException(ex);
                else
                    throw;
            }

            return null;
        }

        public InventoryFacetRequest PrepareInventoryFacetRequest(IList<SearchResultInventoryStatusArg> args, string facetPath)
        {
            var request = new InventoryFacetRequest() { FacetPath = facetPath };
            if (args == null || args.Count == 0) return null;
            //get default account
            _defaultAccountsDict = GetDefaultAccounts(args);

            var btkeys = new List<BTKeys>();
            var pagePosition = 1;
            foreach (var product in args)
            {
                var productType = InventoryHelper.RefineProductTypeToMusicIfMovie(product.ProductType);
                string checkLeReserve = null;
                var accountInventoryType = String.Empty;
                string inventoryReserveNumber = null;
                //no account presented
                if (_defaultAccountsDict == null || _defaultAccountsDict.Count == 0)
                {
                    btkeys.Add(new BTKeys(pagePosition, product.BTKey, checkLeReserve, accountInventoryType, inventoryReserveNumber));
                    continue;
                }

                //there's at least an account
                if (!string.IsNullOrEmpty(productType) && _defaultAccountsDict.ContainsKey(productType))
                {
                    var account = _defaultAccountsDict[productType];
                    if (account != null)
                    {
                        if (account.CheckLEReserve != null && account.CheckLEReserve.Value)
                        {
                            checkLeReserve = TRUE;
                        }
                        if (account.AccountInventoryType != null)
                        {
                            accountInventoryType = account.AccountInventoryType;
                        }
                        if (account.InventoryReserveNumber != null)
                        {
                            inventoryReserveNumber = account.InventoryReserveNumber;
                        }
                    }
                }
                btkeys.Add(new BTKeys(pagePosition, product.BTKey, checkLeReserve, accountInventoryType, inventoryReserveNumber));

                //increase page position by 1
                pagePosition++;
            }

            //BtKeys
            request.BTKeys = btkeys.ToArray();

            var siteContext = SiteContext.Current;
            request.CountryCode = siteContext.CountryCode;

            var orgPremiumServicesStatus = OrganizationDAO.Instance.GetOrganizationPremiumServices(siteContext.OrganizationId);
            //VIPEnabled & DEIEnabled
            if (orgPremiumServicesStatus != null)
            {
                request.VIPEnabled = orgPremiumServicesStatus.vipEnabled;
                request.DEIEnabled = orgPremiumServicesStatus.DEIEnabled;
            }

            //MarketType
            int marketType = MarketType.HasValue
                ? (int)MarketType.Value
                : (int)BTNextGen.Commerce.Portal.Common.Constants.MarketType.Any;

            request.MarketType = marketType.ToString();

            if (_defaultAccountsDict != null)
            {
                if (_defaultAccountsDict.ContainsKey(ProductType.Book.ToString()))
                {
                    string bookprimaryWareHouse, booksecondWareHouse;
                    GetPrimarySecondaryWarehouses(_defaultAccountsDict[ProductType.Book.ToString()],
                        out bookprimaryWareHouse, out booksecondWareHouse);
                    request.BookPrimaryWareHouseCode = bookprimaryWareHouse;
                    request.BookSecondaryWareHouseCode = booksecondWareHouse;
                }
                if (_defaultAccountsDict.ContainsKey(ProductType.Music.ToString()))
                {
                    string entprimaryWareHouse, entsecondWareHouse;
                    GetPrimarySecondaryWarehouses(_defaultAccountsDict[ProductType.Music.ToString()],
                        out entprimaryWareHouse, out entsecondWareHouse);
                    request.EntertainmentPrimaryWareHouseCode = entprimaryWareHouse;
                    request.EntertainmentSecondaryWareHouseCode = entsecondWareHouse;
                }
            }
            return request;
        }

        #endregion
    }
}
