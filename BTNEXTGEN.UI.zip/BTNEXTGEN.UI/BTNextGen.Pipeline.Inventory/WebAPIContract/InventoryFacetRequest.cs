﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.Pipeline.Inventory.Contract
{    
    public class InventoryFacetRequest
    {
        public BTKeys[] BTKeys { get; set; }

        public bool DEIEnabled { get; set; }

        public bool VIPEnabled { get; set; }

        public string MarketType { get; set; }

        public string CountryCode { get; set; }

        public string BookPrimaryWareHouseCode { get; set; }

        public string BookSecondaryWareHouseCode { get; set; }

        public string EntertainmentPrimaryWareHouseCode { get; set; }

        public string EntertainmentSecondaryWareHouseCode { get; set; }

        public string FacetPath { get; set; }
    }
}
