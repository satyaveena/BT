﻿namespace BTNextGen.Pipeline.Inventory
{

    using System;
    using System.Text;
    using Microsoft.CommerceServer.Runtime.Configuration;
    using Microsoft.CommerceServer.Runtime;
    using System.Data.SqlClient;
    using System.Data;
    using BTNextGen.Pipeline.Internal;
    using System.Globalization;
    using BTNextGen.Pipeline.Inventory.DataAccessObject;

    internal class InventoryPipelineHelper : InventoryDAO
    {

        /// <summary>
        /// Inventory Pipeline Helper Construction
        /// </summary>
        public InventoryPipelineHelper()
        {

        }

        /// <summary>
        /// Execute Inventory Pipleine
        /// </summary>
        /// <param name="inventoryConnectionString"></param>
        /// <param name="pipelineComponentType"></param>
        /// <param name="skusList"></param>
        /// <param name="indexPositions"></param>
        /// <param name="warehouseList"></param>
        /// <param name="isTolas"></param>
        /// <param name="accountType"></param>
        /// <param name="accountInventoryType"></param>
        /// <param name="inventoryReserveNumber"></param>
        /// <param name="checkReserveFlag"></param>
        /// <returns></returns>
        private static int ExecuteInventoryPipleine(string inventoryConnectionString,
                PipelineComponentType pipelineComponentType,
                string skusList, string indexPositions, string warehouseList,
                bool isTolas, string accountType, string accountInventoryType,
                string inventoryReserveNumber, bool checkReserveFlag)
        {

            //var resultStatus = (int) ResultStatus.Fail;

            string spName = null;
            switch (pipelineComponentType)
            {
                case PipelineComponentType.CheckInventory:
                    spName = GeneralConstants.StoreProcCheckInventory;
                    break;

                case PipelineComponentType.UpdateInventory:
                    spName = GeneralConstants.StoreProcUpdateInventory;
                    break;
            }

            ConnectionString = inventoryConnectionString + GeneralConstants.PersistSecurity;

            //try
            //{

            using (var dbConnection = CreateSqlConnection())
            {
                var command = CreateSqlSpCommand(spName, dbConnection);

                //<Parameter>            
                var sqlParamaters = CreateSqlParamaters(10);
                sqlParamaters[0] = new SqlParameter("@skus", skusList);
                sqlParamaters[1] = new SqlParameter("@IndexPositions", indexPositions);
                sqlParamaters[2] = new SqlParameter("@CatalogServerName", DBNull.Value);
                sqlParamaters[3] = new SqlParameter("@CatalogDatabaseName", DBNull.Value);
                sqlParamaters[4] = new SqlParameter("@WarehouseList", warehouseList);
                sqlParamaters[5] = new SqlParameter("@IsTolas", isTolas);
                sqlParamaters[6] = new SqlParameter("@AccountType", accountType);
                sqlParamaters[7] = new SqlParameter("@AccountInventoryType", accountInventoryType);
                sqlParamaters[8] = new SqlParameter("@InventoryReserveNumber", inventoryReserveNumber);
                sqlParamaters[9] = new SqlParameter("@CheckReserveFlag", checkReserveFlag);

                command.Parameters.AddRange(sqlParamaters);
                dbConnection.Open();

                command.ExecuteNonQuery();
            }

            return (int) ResultStatus.Success;

            //}
            //catch (Exception exception)
            //{
            //    throw new Exception(InventoryException.ExecuteStore, exception);
            //}
        }


        /// <summary>
        /// Run Pipeline for inventory
        /// </summary>
        /// <param name="pipelineComponentType"></param>
        /// <param name="pOrder"></param>
        /// <param name="pContext"></param>
        /// <returns></returns>
        internal static int RunPipeline(PipelineComponentType pipelineComponentType, object pOrder, object pContext)
        {

            var orderForm = (IDictionary) pOrder;
            var lineItems = (ISimpleList) orderForm[PropertyName.Items];

            if (lineItems.Count <= 0)
                return (int) ResultStatus.Success;

            var warehouseList = string.Empty;
            var isTolas = false;
            var accountType = string.Empty;
            var accountInventoryType = string.Empty;
            var inventoryReserveNumber = string.Empty;
            var checkReserveFlag = false;
            string skusList = null;
            string indexPositions = null;

            if (pipelineComponentType == PipelineComponentType.UpdateInventory)
            {
                // Get data for store
                warehouseList = (orderForm[PropertyName.WarehouseList] != null &&
                                        orderForm[PropertyName.WarehouseList] != System.DBNull.Value)
                                    ? (string) orderForm[PropertyName.WarehouseList]
                                    : string.Empty;
                isTolas = orderForm[PropertyName.IsTolas] != null &&
                                orderForm[PropertyName.IsTolas] != System.DBNull.Value && 
                                (bool) orderForm[PropertyName.IsTolas];
                accountType = (orderForm[PropertyName.AccountType] != null &&
                                    orderForm[PropertyName.AccountType] != System.DBNull.Value)
                                  ? (string) orderForm[PropertyName.AccountType]
                                  : string.Empty;
                accountInventoryType = (orderForm[PropertyName.AccountInventoryType] != null &&
                                                orderForm[PropertyName.AccountInventoryType] != System.DBNull.Value)
                                           ? (string) orderForm[PropertyName.AccountInventoryType]
                                           : string.Empty;
                inventoryReserveNumber = (orderForm[PropertyName.InventoryReserveNumber] != null &&
                                                orderForm[PropertyName.InventoryReserveNumber] != System.DBNull.Value)
                                             ? (string) orderForm[PropertyName.InventoryReserveNumber]
                                             : string.Empty;
                checkReserveFlag = orderForm[PropertyName.CheckReserveFlag] != null &&
                                    orderForm[PropertyName.CheckReserveFlag] != System.DBNull.Value &&
                                   (bool) orderForm[PropertyName.CheckReserveFlag];
            }

            var commerceResource = GetCommerceResources(pContext, PropertyName.Inventory);

            GetSkusList(pipelineComponentType, lineItems, out skusList, out indexPositions);

            var inventoryConnectionString = (string) commerceResource[GeneralConstants.DatabaseInventory];

            //try
            //{
            return ExecuteInventoryPipleine(inventoryConnectionString, pipelineComponentType,
                                            skusList, indexPositions, warehouseList, isTolas, accountType,
                                            accountInventoryType, inventoryReserveNumber, checkReserveFlag);
            //}
            //catch (Exception exception)
            //{
            //    throw new Exception(InventoryException.HelperRunPipeline, exception);
            //}

            //return (int)ResultStatus.Fail;
        }

        /// <summary>
        /// Get Skus List
        /// </summary>
        /// <param name="pipelineComponentType"></param>
        /// <param name="lineItems"></param>
        /// <param name="skusList"></param>
        /// <param name="indexPositions"></param>
        public static void GetSkusList(PipelineComponentType pipelineComponentType, ISimpleList lineItems, out string skusList, out string indexPositions)
        {
            var builderSku = new StringBuilder();
            var builderIndex = new StringBuilder();

            foreach (IDictionary lineItem in lineItems)
            {
                var productCatalog = (string)lineItem[PropertyName.ProductCatalog];
                var productId = (string)lineItem[PropertyName.ProductId];
                var productVariant = string.Empty;
                decimal quantity = Convert.ToDecimal(lineItem[PropertyName.Quantity], CultureInfo.CurrentCulture);
                var quantityString = Math.Round(quantity).ToString(CultureInfo.InvariantCulture);

                builderSku.AppendFormat(CultureInfo.InvariantCulture, "{0},{1},{2},{3},", new object[] { productCatalog, productId, productVariant, quantityString });
                builderIndex.AppendFormat(CultureInfo.InvariantCulture, "{0},{1},{2},{3},", new object[] { productCatalog.Length, productId.Length, productVariant.Length, quantityString.Length });
            }
            skusList = builderSku.ToString();
            indexPositions = builderIndex.ToString();
        }

        /// <summary>
        /// Get Commerce Resource
        /// </summary>
        /// <param name="context"></param>
        /// <param name="resourceName"></param>
        /// <returns></returns>
        private static CommerceResource GetCommerceResources(object context, string resourceName)
        {
            var dictionary = (IDictionary)context;
            var resCollection = (CommerceResourceCollection)dictionary[PropertyName.CommerceResources];
            var resource = resCollection[resourceName];

            return resource;
        }

    }

}
