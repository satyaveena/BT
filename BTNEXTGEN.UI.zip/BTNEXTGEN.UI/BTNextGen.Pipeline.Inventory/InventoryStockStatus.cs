﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTNextGen.Pipeline.Inventory
{
    public class InventoryStockStatus
    {
        public int LineItem { get; set; }

        public int StockCondition { get; set; }

        public int InStockForRequest { get; set; }

        public int PreorderForRequest { get; set; }

        public int BackorderForRequest { get; set; }

        public int QuantityAvailable { get; set; }

        public int OnOrderQuantity { get; set; }

        public string OnHandInventory { get; set; }

        public string WareHouse { get; set; }

        public string WareHouseCode { get; set; }

        public string FormalWareHouseCode { get; set; }

        public InventoryStockStatus(int lineItem, int stockCondition, int inStockForRequest, int preorderForRequest, int backorderForRequest, int quantityAvailable, int quantityOnOrder, string onHandInventory, string wareHouse, string wareHouseCode)
        {
            LineItem = lineItem;
            StockCondition = stockCondition;
            InStockForRequest = inStockForRequest;
            PreorderForRequest = preorderForRequest;
            BackorderForRequest = backorderForRequest;
            QuantityAvailable = quantityAvailable;
            OnOrderQuantity = quantityOnOrder;
            OnHandInventory = onHandInventory;
            WareHouse = wareHouse;
            WareHouseCode = wareHouseCode;
        }

        public InventoryStockStatus()
        {
            LineItem = 0;
            StockCondition = 0;
            InStockForRequest = 0;
            PreorderForRequest = 0;
            BackorderForRequest = 0;
            QuantityAvailable = 0;
            OnOrderQuantity = 0;
            OnHandInventory = string.Empty;
            WareHouse = string.Empty;
            WareHouseCode = string.Empty;
        }
    }
}
