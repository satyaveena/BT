﻿namespace BTNextGen.Pipeline.Inventory
{

    using System.Runtime.InteropServices;
    using Microsoft.CommerceServer.Runtime;
    using Microsoft.CommerceServer.Interop;
    using System;
    using Microsoft.CommerceServer.Internal;
    using System.ComponentModel;
    using BTNextGen.Pipeline.Internal;
    using BTNextGen.Commerce.Portal.Common;

    [Description("BTNextGen Commerce Update Inventory By Warehouse"),
        ComVisible(true),
        Guid("4DBD5233-AA6C-4346-B241-765EFE0954B6"),
        ProgId("BTNextGen.Pipeline.Inventory.UpdateInventoryByWarehouse")]
    public class UpdateInventoryByWarehouse : RegisterCOMComponentFriendlyName, IPipelineComponent, IPipelineComponentDescription
    {

        /// <summary>
        /// Update Inventory By Warehouse Construction
        /// </summary>
        public UpdateInventoryByWarehouse()
        {

        }

        /// <summary>
        /// Enable Design
        /// </summary>
        /// <param name="fEnable"></param>
        public void EnableDesign(Int32 fEnable)
        {
            
        }

        /// <summary>
        /// Values Read
        /// </summary>
        /// <returns></returns>
        public object ValuesRead()
        {
            return new object[] { PropertyName.ProductCatalog, PropertyName.ProductId, PropertyName.Quantity};
        }

        /// <summary>
        /// Values Written
        /// </summary>
        /// <returns></returns>
        public object ValuesWritten()
        {
            return new object[0];
        }

        /// <summary>
        /// Context Values Read
        /// </summary>
        /// <returns></returns>
        public object ContextValuesRead()
        {
            return new object[] { PropertyName.CommerceResources};
        }

        /// <summary>
        /// Execute
        /// </summary>
        /// <param name="pdispOrder"></param>
        /// <param name="pdispContext"></param>
        /// <param name="lFlags"></param>
        /// <returns></returns>
        public int Execute(object pdispOrder, object pdispContext, int lFlags)
        {

            var returnValue = (int) ResultStatus.Fail;
            
            IDictionary pOrder = null;
            IDictionary pContext = null;

            // Check object null
            if (pdispOrder == null)
            {
                throw new ArgumentNullException(InventoryException.DispatchOrder);
            }

            if (pdispContext == null)
            {
                throw new ArgumentNullException(InventoryException.DispatchContext);
            }

            pOrder = pdispOrder as IDictionary;
            if (pOrder == null)
            {
                throw new ArgumentNullException(InventoryException.DispatchOrder);
            }

            pContext = pdispContext as IDictionary;
            if (pContext == null)
            {
                throw new ArgumentNullException(InventoryException.DispatchContext);
            }

            // Execute pipeline            
            returnValue = InventoryPipelineHelper.RunPipeline(PipelineComponentType.UpdateInventory, pOrder, pContext);                        
            return returnValue;
        }

    }

}
