﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using BTNextGen.Commerce.Portal.Common.Controllers;
using Microsoft.CommerceServer.Runtime;
using Microsoft.CommerceServer.Internal;
using IDictionary = Microsoft.CommerceServer.Runtime.IDictionary;
using IPipelineComponent = Microsoft.CommerceServer.Interop.IPipelineComponent;
using IPipelineComponentDescription = Microsoft.CommerceServer.Interop.IPipelineComponentDescription;
using System.Collections.Generic;
using BTNextGen.Commerce.Portal.Common;
using Microsoft.CommerceServer.Runtime.Marketing;

namespace BTNextGen.Pipeline.VirtualCatalogDiscount
{


    [Description("BTNextGen Commerce Virtual Catalog Discount"),
        ComVisible(true),
        Guid("B5CBDC5E-5760-49B5-AAE9-0AF027F2FC07"),
        ProgId("BTNextGen.Pipeline.VirtualCatalogDiscount.SetDiscountInfo")]
    public class SetDiscountInfo : RegisterCOMComponentFriendlyName, IPipelineComponent, IPipelineComponentDescription
    {
        // Status codes for pipeline components
        private const Int32 StatusSuccess = 1;	// success
        private const Int32 StatusWarning = 2;	// warning
        private const Int32 StatusError = 3;	// error

        private const string ItemKey = "items";
        private const string QuantityKey = "quantity";
        private const string ListPriceKey = "_cy_iadjust_regularprice";
        private const string PlacePriceKey = "cy_placed_price";
        private const string ItemLevelDiscountTotalKey = "_cy_itemlevel_discounts_subtotal";
        private const string ContractPriceKey = "contractPrice";
        private const string ExtendedPriceKey = "cy_oadjust_adjustedprice";


        public void EnableDesign(int fEnable)
        {
            //Do nothing here. This method is obsolete and shouldn't be used.
        }

        public int Execute2(object pdispOrder, object pdispContext, int lFlags)
        {
            IDictionary order = (IDictionary)pdispOrder;
            IDictionary context = (IDictionary)pdispContext;
            SimpleList items = (SimpleList)order[ItemKey];
            decimal orderTotal = 0;

            DiscountItemCollection discountsFromCache = DiscountItemCollection.CreateFromCache("Discounts");
            DiscountCriteriaFilter filter = new DiscountCriteriaFilter();
            filter.FilterOnAward = true;
            filter.FilterOnCondition = false;
            filter.IncludeDiscountsWithEligibilityRequirements = true;
            filter.IncludeDiscountsWithPromoCodes = true;
            filter.IncludeInactiveDiscounts = false;

            DiscountItemCollection discounts;

            foreach (IDictionary lineItem in items)
            {
                string productId = string.IsNullOrEmpty(lineItem["product_id"].ToString())
                                       ? string.Empty
                                       : lineItem["product_id"].ToString();
                string variant = string.IsNullOrEmpty(lineItem["product_variant_id"].ToString())
                                     ? string.Empty
                                     : lineItem["product_variant_id"].ToString();

                string catalogName = string.IsNullOrEmpty(lineItem["product_catalog"].ToString())
                                         ? string.Empty
                                         : lineItem["product_catalog"].ToString();

                const string refineCatalog = "MarketingCatalog";

                string productId2 = string.Format("{0}({1})", productId, catalogName);
                string variant2 = string.Format("{0}({1})", variant, catalogName);

                lineItem["product_id"] = productId2;
                lineItem["product_catalog"] = refineCatalog;
                lineItem["product_variant_id"] = variant2;

                /*
                List<string> vcatsName = CatalogController.GetParentCategories(refineCatalog, productId2);
                if (vcatsName != null && vcatsName.Count > 0)
                {
                    foreach (var catName in vcatsName)
                    {
                         Get the discount by category of product
                        discounts = discountsFromCache.ApplyCategoryFilter(filter, refineCatalog, catName);
                        if (discounts != null && discounts.Count > 0)
                        {
                            lineItem["product_id"] = productId2;
                            lineItem["product_catalog"] = refineCatalog;
                            break;
                        }
                    }
                }
                */
            }

            return StatusSuccess;
        }

        /// <summary>
        /// This method is used to implement the logic for this pipeline component.
        /// </summary>
        /// <param name="pdispOrder"></param>
        /// <param name="pdispContext"></param>
        /// <param name="lFlags"></param>
        /// <returns></returns>
        public int Execute(object pdispOrder, object pdispContext, int lFlags)
        {
            
            IDictionary order = (IDictionary)pdispOrder;
            IDictionary context = (IDictionary)pdispContext;
            SimpleList items = (SimpleList)order[ItemKey];
            decimal orderTotal = 0;

            DiscountItemCollection discountsFromCache = DiscountItemCollection.CreateFromCache("Discounts");
            DiscountCriteriaFilter filter = new DiscountCriteriaFilter();
            filter.FilterOnAward = true;
            filter.FilterOnCondition = false;
            filter.IncludeDiscountsWithEligibilityRequirements = true;
            filter.IncludeDiscountsWithPromoCodes = true;
            filter.IncludeInactiveDiscounts = false;

            DiscountItemCollection discounts;

            foreach (IDictionary lineItem in items)
            {
                string productId = string.IsNullOrEmpty(lineItem["product_id"].ToString())
                               ? string.Empty
                               : lineItem["product_id"].ToString();
                string catalogName = string.IsNullOrEmpty(lineItem["product_catalog"].ToString())
                               ? string.Empty
                               : lineItem["product_catalog"].ToString();
                
                const string refineCatalog = "MarketingCatalog";

                string productId2 = string.Format("{0}({1})", productId, catalogName);

                List<string> vcatsName = CatalogController.GetParentCategories(refineCatalog, productId2);
                if (vcatsName != null && vcatsName.Count > 0)
                {
                    foreach (var catName in vcatsName)
                    {
                        // Get the discount by category of product
                        discounts = discountsFromCache.ApplyCategoryFilter(filter, refineCatalog, catName);
                        if (discounts != null && discounts.Count > 0)
                        {
                            lineItem["product_id"] = productId2;
                            lineItem["product_catalog"] = refineCatalog;
                            break;
                        }
                    }
                }

            }
            
                 
            return StatusSuccess;
        }

        public object ContextValuesRead()
        {
            throw new NotImplementedException();
        }

        public object ValuesRead()
        {
            throw new NotImplementedException();
        }

        public object ValuesWritten()
        {
            return new object[] { ListPriceKey };
        }

    }
}
