//------------------------------------------------------------------------
// <copyright file="ChannelConfigurationFeatureReceiver.cs" company="Microsoft">
//     Copyright � Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>SharePoint feature receiver for Channel Configuration</summary>
//------------------------------------------------------------------------

namespace BTNextGen.Commerce.Portal.ChannelConfiguration
{
    using System;
    using System.Security;
    using System.Security.Permissions;
    using BTNextGen.Commerce.Portal.Common;
    using Microsoft.SharePoint;
    using Microsoft.SharePoint.Security;

    /// <summary>    
    /// The ChannelConfigFeatureReceiver is called upon feature activation and deactivation.
    /// It creates a list for channel configuration, associates a content type to it,
    /// associates an event handler to the list and populates it with default values.
    /// </summary>
    [PermissionSet(SecurityAction.Demand)]
    public sealed class ChannelConfigurationFeatureReceiver : SPFeatureReceiver
    {
        /// <summary>
        /// The name of the custom type that holds values
        /// </summary>
        private const string CustomStringContentTypename = "ChannelStringContentType";

        /// <summary>
        /// The fully qualified name of the event handler class
        /// </summary>
        private string eventHandlerClassName = typeof(ChannelConfigurationListEventReceiver).FullName;

        /// <summary>
        /// Handles the Feature Deactivation
        /// </summary>
        /// <param name="properties">SPFeatureReceiverProperties passes in the "context" 
        /// including the web application reference</param>
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            this.AddOrRemoveHandler(properties, true);
        }

        /// <summary>
        /// Handles the Feature Activation
        /// </summary>
        /// <param name="properties">SPFeatureReceiverProperties passes in the context
        /// including the web application reference</param>        
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            this.AddOrRemoveHandler(properties, false);
        }

        /// <summary>
        /// No action upon feature installation
        /// </summary>
        /// <param name="properties">SPFeatureReceiverProperties passes in the context
        /// including the web application reference</param>  
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
        }

        /// <summary>
        /// No action upon uninstalling feature 
        /// </summary>
        /// <param name="properties">SPFeatureReceiverProperties passes in the context
        /// including the web application reference</param>  
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
        }

        /// <summary>
        ///  Remove the configuration list and content type from the web site.
        /// </summary>
        /// <param name="web">The web site</param>
        private static void DeleteListIfItExists(SPWeb web)
        {
            string configurationListName = GetListName();

            try
            {
                SPList list = web.Lists[configurationListName];
                if (list != null)
                {
                    web.Lists.Delete(list.ID);
                }
            }
            catch (System.ArgumentException)
            {
            }

            SPContentType contentType = null;
            contentType = web.ContentTypes[CustomStringContentTypename];
            if (contentType != null)
            {
                SPWeb w = contentType.ParentWeb;
                SPList l = contentType.ParentList;
                if (w != null && l != null)
                {
                    w.Lists.Delete(l.ID);
                }

                try
                {
                    web.ContentTypes.Delete(contentType.Id);
                }
                catch (SPException)
                {
                }
            }
        }

        /// <summary>
        /// Returns the name of the Channel Configuration SharePoint list 
        /// </summary>
        /// <returns>The name of the SharePoint list</returns>
        private static string GetListName()
        {
            return ChannelConfigurationConstants.ChannelConfigurationListName;
        }

        /// <summary>
        /// Returns the name of the Channel Configuration SharePoint view
        /// </summary>
        /// <returns>The name of the SharePoint view</returns>
        private static string GetViewName()
        {
            return ChannelConfigurationConstants.ChannelConfigurationViewName;
        }

        /// <summary>
        ///  Remove the configuration list and content type from the web site.
        /// </summary>
        /// <param name="web">The web site</param>
        private static void DeleteList(SPWeb web)
        {
            string configurationListName = GetListName();

            try
            {
                SPList list = web.Lists[configurationListName];
                if (list != null)
                {                    
                    web.Lists.Delete(list.ID);
                }

                SPWebPropertiesHashtable hash = new SPWebPropertiesHashtable(web);
                hash.Clear();                    
            }
            catch (System.ArgumentException)
            {
            }

            SPContentType contentType = null;
            contentType = web.ContentTypes[CustomStringContentTypename];
            if (contentType != null)
            {
                SPWeb w = contentType.ParentWeb;
                SPList l = contentType.ParentList;
                if ((w != null) && (l != null))
                {
                    w.Lists.Delete(l.ID);
                }

                try
                {
                    web.ContentTypes.Delete(contentType.Id);
                }
                catch (SPException)
                {
                }
            }
        }
       
        /// <summary>
        ///    Add a field to the field collection.
        /// </summary>
        /// <param name="collection">The field collection</param>
        /// <param name="displayName">The display name of the field</param>
        /// <param name="fieldType">The field type</param>
        /// <param name="required">Is the field required?</param>
        /// <param name="contentType">The content type</param>
        /// <returns>The internal name of the field created</returns>
        private static string AddField(
            SPFieldCollection collection,
            string displayName,
            SPFieldType fieldType,
            bool required,
            SPContentType contentType)
        {
            // adding field                        
            string internalName = collection.Add(displayName, fieldType, required);
            SPField field = collection.GetFieldByInternalName(internalName);

            contentType.FieldLinks.Add(new SPFieldLink(field));
            return internalName;
        }

        /// <summary>
        /// Perform main logic
        /// </summary>
        /// <param name="properties">The event properties</param>
        /// <param name="removeModification">Boolean indicating removal if true</param>
        private void AddOrRemoveHandler(SPFeatureReceiverProperties properties, bool removeModification)
        {
            if (properties == null)
            {
                throw new ArgumentNullException("properties");
            }

            SPWeb web = properties.Feature.Parent as SPWeb;

            if (removeModification)
            {
                ChannelConfigurationFeatureReceiver.DeleteList(web);
            }
            else
            {
                this.CreateList(web);
            }

            web.Update();
        }

        /// <summary>
        ///  Create the main configuration list
        /// </summary>
        /// <param name="web">The web site</param>
        private void CreateList(SPWeb web)
        {
            ChannelConfigurationFeatureReceiver.DeleteListIfItExists(web);

            // Create the content type
            SPContentType baseType = web.AvailableContentTypes[SPContentTypeId.Empty];
            SPContentType customStringContentType = null;

            // Add content to the web site, initializing the content type
            if (web.AvailableContentTypes[CustomStringContentTypename] == null)
            {
                customStringContentType = new SPContentType(baseType, web.ContentTypes, CustomStringContentTypename);
                web.ContentTypes.Add(customStringContentType);
                customStringContentType = web.ContentTypes[customStringContentType.Id];
                AddField(web.Fields, ChannelConfigurationConstants.ChannelConfigurationValue, SPFieldType.Text, false, customStringContentType);
                customStringContentType.Update(true);
            }
            else
            {
                customStringContentType = web.AvailableContentTypes[CustomStringContentTypename];
            }

            // Create the list
            string configurationListName = GetListName();

            Guid ret = web.Lists.Add(configurationListName, String.Empty, SPListTemplateType.GenericList);
            SPList list = web.Lists[ret];

            list.ContentTypesEnabled = true;
            list.ContentTypes.Add(customStringContentType);
            if (list.ContentTypes[ChannelConfigurationConstants.SharePointItem] != null)
            {
                list.ContentTypes.Delete(list.ContentTypes[ChannelConfigurationConstants.SharePointItem].Id);
            }

            list.EnableAttachments = false;
            list.Update();

            this.AddHandlers(list);

            // Add the default values
            foreach (string item in ChannelConfigurationConstants.ReservedChannelConfigurationParameters)
            {
                SPListItem spliCatalog = list.Items.Add();

                spliCatalog[ChannelConfigurationConstants.ChannelConfigurationTitle] = item;

                switch (item)
                {
                    case ChannelConfigurationConstants.ListEntryChannel:
                        spliCatalog[ChannelConfigurationConstants.ChannelConfigurationValue] = "Default";
                        break;
                    case ChannelConfigurationConstants.ListEntryDefaultCatalog:
                        spliCatalog[ChannelConfigurationConstants.ChannelConfigurationValue] = "Adventure Works Catalog";
                        break;
                    default:
                        spliCatalog[ChannelConfigurationConstants.ChannelConfigurationValue] = String.Empty;
                        break;
                }
                
                spliCatalog.Update();
            }

            ////Update Value
            //SPListItem spitem = list.GetItemById(1);
            //spitem[ChannelConfigurationConstants.ChannelConfigurationValue] = "Default";
            //spitem.Update();
            //spitem = list.GetItemById(2);
            //spitem[ChannelConfigurationConstants.ChannelConfigurationValue] = "Adventure Works Catalog";
            //spitem.Update();

            // Create the view
            System.Collections.Specialized.StringCollection strCol = new System.Collections.Specialized.StringCollection();
            strCol.Add(ChannelConfigurationConstants.SharePointLinkTitle);
            strCol.Add(ChannelConfigurationConstants.ChannelConfigurationValue);
            string query = string.Empty;
            SPView view = null;
            view = list.Views.Add(GetViewName(), strCol, query, 1000, true, true);
            view.ContentTypeId = customStringContentType.Id;
            list.OnQuickLaunch = true;
            list.Update();
        }

        /// <summary>
        ///  Add event handlers to the configuration list
        /// </summary>
        /// <param name="list">The target list</param>
        private void AddHandlers(SPList list)
        {
            string fullName = typeof(ChannelConfigurationListEventReceiver).Assembly.FullName;
            list.EventReceivers.Add(
                SPEventReceiverType.ItemAdding,
                fullName,
                this.eventHandlerClassName);
            list.EventReceivers.Add(
                SPEventReceiverType.ItemUpdating,
                fullName,
                this.eventHandlerClassName);
            list.EventReceivers.Add(
                SPEventReceiverType.ItemDeleting,
                fullName,
                this.eventHandlerClassName);
        }
    }
}
