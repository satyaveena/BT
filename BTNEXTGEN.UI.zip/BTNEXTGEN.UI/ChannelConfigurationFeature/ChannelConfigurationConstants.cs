﻿//------------------------------------------------------------------------
// <copyright file="ChannelConfigurationConstants.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>Contains constants used by Channel Configuration.</summary>
//-----------------------------------------------------------------------

namespace BTNextGen.Commerce.Portal.ChannelConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Static class used to store non-localized constants for channel configuration
    /// </summary>
    internal static class ChannelConfigurationConstants
    {
        /// <summary>
        /// Name of the Channel Configuration SharePoint List
        /// </summary>
        public const string ChannelConfigurationListName = "Channel Configuration";

        /// <summary>
        /// Name of the Channel Configuration SharePoint View
        /// </summary>
        public const string ChannelConfigurationViewName = "Configuration View";

        /// <summary>
        /// Non-localized column name in the SharePoint list
        /// </summary>
        public const string ChannelConfigurationTitle = "Title";

        /// <summary>
        /// Non-localized column name in the SharePoint list
        /// </summary>
        public const string ChannelConfigurationValue = "Value";

        /// <summary>
        /// Non-Localized Channel Confiuration list entry for the default catalog
        /// </summary>
        public const string ListEntryDefaultCatalog = "DefaultCatalog";

        /// <summary>
        /// Non-Localized Channel Confiuration list entry for the channel name
        /// </summary>
        public const string ListEntryChannel = "Channel";

        /// <summary>
        /// Non-Localized Channel Confiuration list entry for the Windows Live Application Id
        /// </summary>
        public const string ListEntryLiveApplicationID = "LiveApplicationID";

        /// <summary>
        /// Non-Localized Channel Confiuration list entry for the Windows Live Id Application Secret code
        /// </summary>
        public const string ListEntryLiveApplicationSecret = "LiveApplicationSecret";

        /// <summary>
        /// Non-locallized SharePoint content type identifier
        /// </summary>
        public const string SharePointContentType = "ContentType";

        /// <summary>
        /// Non-locallized SharePoint item identifier
        /// </summary>
        public const string SharePointItem = "Item";

        /// <summary>
        /// Non-locallized SharePoint folder identifier
        /// </summary>
        public const string SharePointFolder = "Folder";

        /// <summary>
        /// Non-locallized SharePoint link title identifier
        /// </summary>
        public const string SharePointLinkTitle = "LinkTitle";

        // Resource Ids for localized content

        /// <summary>
        /// Channel Configuration Resource ID
        /// </summary>
        public const string ChannelConfiguration = "ChannelConfiguration";

        /// <summary>
        /// Configuration View Resource ID
        /// </summary>
        public const string ConfigurationView = "ConfigurationView";

        /// <summary>
        /// Resource identifier for when the content type cannot be found
        /// </summary>
        public const string ContentTypeNotFound = "ContentTypeNotFound";

        /// <summary>
        /// Resource identifier for when the field or content type cannot be found
        /// </summary>
        public const string FieldOrContentTypeNotFound = "FieldOrContentTypeNotFound";

        /// <summary>
        /// Resource identifier for when a duplicate entry is added to the list
        /// </summary>
        public const string ListEntryAlreadyExists = "ListEntryAlreadyExists";

        /// <summary>
        /// Resource identifier for error when user attempts to delete a "system" property
        /// </summary>
        public const string PropertyCannotBeDeleted = "PropertyCannotBeDeleted";

        /// <summary>
        /// Resource identifier for error when user attempts to rename a "system" property
        /// </summary>
        public const string PropertyCannotBeRenamed = "PropertyCannotBeRenamed";

        /// <summary>
        /// Resource identifier for error when user attempts to create a list entry with no title
        /// </summary>
        public const string TitleNotEntered = "TitleNotEntered";

        /// <summary>
        /// Array of reserved channel configuration parameters that get created upon 
        /// feature activation, and that cannot be renamed or deleted
        /// </summary>
        private static string[] reservedChannelConfigurationParameters = new string[]
        { 
            ChannelConfigurationConstants.ListEntryChannel,
            ChannelConfigurationConstants.ListEntryDefaultCatalog,
            ChannelConfigurationConstants.ListEntryLiveApplicationID,
            ChannelConfigurationConstants.ListEntryLiveApplicationSecret
        };

        /// <summary>
        /// Gets the array of channel configuration parameters that are reserved
        /// for use by the web parts.
        /// </summary>
        public static string[] ReservedChannelConfigurationParameters
        {
            get
            {
                return reservedChannelConfigurationParameters;
            }
        }
    }
}
