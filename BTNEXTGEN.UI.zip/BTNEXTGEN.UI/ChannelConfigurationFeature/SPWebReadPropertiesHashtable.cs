﻿//------------------------------------------------------------------------
// <copyright file="SPWebReadPropertiesHashtable.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>Hash table for SharePoint list properties</summary>
//------------------------------------------------------------------------

namespace BTNextGen.Commerce.Portal.ChannelConfiguration
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.SharePoint;

    /// <summary>
    /// A hastable that has support for reading properties from SPWeb
    /// </summary>
    internal class SPWebReadPropertiesHashtable
    {
        /// <summary>
        /// The key prefix for a field
        /// </summary>
        private const string KEYPREFIX = "microsoft.commerce.settings";

        /// <summary>
        /// The separator for identifying the field
        /// </summary>
        private const char SEPARATOR = '.';

        /// <summary>
        /// The SharePoint web object
        /// </summary>
        private SPWeb currentWeb;

        /// <summary>
        /// Initializes a new instance of the <see cref="SPWebReadPropertiesHashtable"/> class.
        /// </summary>
        /// <param name="web">The SharePoint web instance</param>
        public SPWebReadPropertiesHashtable(SPWeb web)
        {
            this.currentWeb = web;
        }

        /// <summary>
        /// Gets the value which is the current SPWeb instance
        /// </summary>
        public SPWeb CurrentWeb
        {
            get
            {
                return this.currentWeb;
            }
        }

        /// <summary>
        /// Gets the value which is a collection of keys
        /// </summary>
        public ICollection Keys
        {
            get
            {
                var allKeys = from string key in this.currentWeb.AllProperties.Keys
                              where key.StartsWith(KEYPREFIX, StringComparison.OrdinalIgnoreCase)
                              select key;
                var someKeys = from string key in this.currentWeb.Properties.Keys
                               where key.StartsWith(KEYPREFIX, StringComparison.OrdinalIgnoreCase)
                               select key;
                var uniqueKeys = allKeys.Union(someKeys).Distinct();

                return uniqueKeys.ToList<string>();
            }
        }

        /// <summary>
        /// Gets the value which is a count of unique keys
        /// </summary>
        public int Count
        {
            get
            {
                var allKeys = from string key in this.currentWeb.AllProperties.Keys
                              where key.StartsWith(KEYPREFIX, StringComparison.OrdinalIgnoreCase)
                              select key;
                var someKeys = from string key in this.currentWeb.Properties.Keys
                               where key.StartsWith(KEYPREFIX, StringComparison.OrdinalIgnoreCase)
                               select key;
                var uniqueKeys = allKeys.Union(someKeys).Distinct();
                return uniqueKeys.Count<string>();
            }
        }

        /// <summary>
        /// Gets or sets a value which is the object within the hash table
        /// </summary>
        /// <param name="key">The key used to look up the value</param>
        /// <returns>The object returned</returns>
        public virtual object this[object key]
        {
            get
            {
                string newKey = KEYPREFIX + SEPARATOR + key;

                if (this.currentWeb.AllProperties.ContainsKey(newKey))
                {
                    return this.currentWeb.AllProperties[newKey];
                }

                return null;
            }

            set
            {
            }
        }

        /// <summary>
        /// Retrieves the enumerator for the hash table
        /// </summary>
        /// <returns>A dictionary enumerator</returns>
        public IDictionaryEnumerator GetEnumerator()
        {
            return this.currentWeb.AllProperties.GetEnumerator();
        }

        /// <summary>
        /// Used to determine whether an item is in the hashtable
        /// </summary>
        /// <param name="key">The key to lookup in the hash table</param>
        /// <returns>True if the item exists, otherwise false</returns>
        public bool Contains(object key)
        {
            return this.currentWeb.AllProperties.Contains(KEYPREFIX + SEPARATOR + key) || this.currentWeb.Properties.ContainsKey(KEYPREFIX + SEPARATOR + (string)key);
        }
    }
}
