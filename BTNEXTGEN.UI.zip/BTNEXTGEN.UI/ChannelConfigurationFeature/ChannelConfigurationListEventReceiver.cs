//------------------------------------------------------------------------
// <copyright file="ChannelConfigurationListEventReceiver.cs" company="Microsoft">
//     Copyright � Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>SharePoint list event receiver for channel configuration</summary>
//------------------------------------------------------------------------

namespace BTNextGen.Commerce.Portal.ChannelConfiguration
{
    using System;
    using System.Collections;
    using System.Globalization;
    using System.Linq;
    using System.Security.Permissions;
    using BTNextGen.Commerce.Portal.Common;
    using Microsoft.SharePoint;
    using Microsoft.SharePoint.Security;

    /// <summary>
    /// This class implements a SharePoint item event receiver which is used to intercept the modification
    /// of list items in the Channel Configuration SharePoint list
    /// </summary>
    //[CLSCompliant(false)]
    public class ChannelConfigurationListEventReceiver : SPItemEventReceiver
    {
        /// <summary>
        /// Overrides the event that's triggered when a new item is being added to the list
        /// </summary>
        /// <param name="properties">The properties for the item being added</param>
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void ItemAdding(SPItemEventProperties properties)
        {
            SPContentType ct = ContentTypeFromList(properties.OpenWeb().Lists[properties.ListId]);
            if (ct == null)
            {
                return;
            }

            // when adding from feature activation, there is nothing in afterproperties
            // when adding from list, CT from list may not be the user-defined one
            string contentName = FindAddingContentType((string)properties.AfterProperties[ChannelConfigurationConstants.SharePointContentType], ct.Name);
            FieldOp fo = FindField(properties, contentName);

            if (fo.Cancel || fo.FieldName == null)
            {
                properties.ErrorMessage = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.FieldOrContentTypeNotFound);
                properties.Cancel = true;
                return;
            }

            // Ensure that the title field isn't null, as it's required
            if (string.IsNullOrEmpty(properties.AfterProperties[ChannelConfigurationConstants.ChannelConfigurationTitle].ToString()))
            {
                properties.ErrorMessage = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.TitleNotEntered);
                properties.Cancel = true;
                return;
            }

            string key2 = (string)properties.AfterProperties[ChannelConfigurationConstants.ChannelConfigurationTitle];
            object value = properties.AfterProperties[InternalFieldName(fo.FieldName)];

            SPWeb web = properties.OpenWeb();
            SPWebPropertiesHashtable hash = new SPWebPropertiesHashtable(web);

            // Disallow duplicates within the list.  Since this feature could be in the process
            // of being activated, we need to check the list to see whether it currently contains the
            // system items as well.  If so, this is an error, otherwise we will add the item to the list
            if (hash.Contains(key2))
            {
                if (ItemsExistsInList(web, properties.ListId, key2))
                {
                    string message = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.ListEntryAlreadyExists);
                    properties.ErrorMessage = string.Format(CultureInfo.InvariantCulture, message, key2);
                    properties.Cancel = true;
                    return;
                }
            }

            hash[key2] = value;
            base.ItemAdding(properties);
        }

        /// <summary>
        /// Overrides the event that's triggered when an item is updated in the list
        /// </summary>
        /// <param name="properties">The properties for the item being updated</param>
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
        }

        /// <summary>
        /// Overrides the event that's triggered when an item is being updated in the list
        /// </summary>
        /// <param name="properties">The properties for the item being updated</param>
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            FieldOp fo = FindField(properties, (string)properties.AfterProperties[ChannelConfigurationConstants.SharePointContentType]);
            if (fo.Cancel || fo.FieldName == null)
            {
                return;
            }

            // Ensure that the title field isn't null, as it's required
            if (properties.AfterProperties[ChannelConfigurationConstants.ChannelConfigurationTitle] == null ||
                string.IsNullOrEmpty(properties.AfterProperties[ChannelConfigurationConstants.ChannelConfigurationTitle].ToString()))
            {
                properties.ErrorMessage = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.TitleNotEntered);
                properties.Cancel = true;
                return;
            }

            string titleName = properties.ListItem[ChannelConfigurationConstants.ChannelConfigurationTitle] == null ? String.Empty : properties.ListItem[ChannelConfigurationConstants.ChannelConfigurationTitle].ToString();
            string afterTitleName = properties.AfterProperties[ChannelConfigurationConstants.ChannelConfigurationTitle].ToString();

            // Disallow editing of any system properties
            if (ChannelConfigurationListEventReceiver.IsItemReserved(titleName) &&
                !titleName.Equals(afterTitleName, StringComparison.OrdinalIgnoreCase))
            {
                string message = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.PropertyCannotBeRenamed);
                properties.ErrorMessage = string.Format(CultureInfo.InvariantCulture, message, titleName);
                properties.Cancel = true;
            }
            else
            {
                SPWeb web = properties.OpenWeb();
                SPWebPropertiesHashtable hash = new SPWebPropertiesHashtable(web);

                // Are we attempting to rename the title? If so, does an item with that name already exist
                // in the list? If so, disallow this.
                if (titleName != afterTitleName && ItemsExistsInList(web, properties.ListId, afterTitleName))
                {
                    string message = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.ListEntryAlreadyExists);
                    properties.ErrorMessage = string.Format(CultureInfo.InvariantCulture, message, afterTitleName);
                    properties.Cancel = true;
                }
                else
                {
                    hash.Remove(properties.ListItem[ChannelConfigurationConstants.ChannelConfigurationTitle]);
                    hash[properties.AfterProperties[ChannelConfigurationConstants.ChannelConfigurationTitle]] = properties.AfterProperties[InternalFieldName(fo.FieldName)];

                    base.ItemUpdating(properties);
                }
            }
        }

        /// <summary>
        /// Overrides the event that's triggered when an item is being deleted from the list
        /// </summary>
        /// <param name="properties">The properties for the item being deleted</param>
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            if (properties.ListItem == null)
            {
                return;
            }

            string key = (string)properties.ListItem[ChannelConfigurationConstants.ChannelConfigurationTitle];

            if (ChannelConfigurationListEventReceiver.IsItemReserved(key))
            {
                string message = SiteContext.GetLocalizedString(ResourceName.ChannelConfigurationResources, ChannelConfigurationConstants.PropertyCannotBeDeleted);
                properties.ErrorMessage = string.Format(CultureInfo.InvariantCulture, message, key);
                properties.Cancel = true;
                return;
            }

            SPWeb currentWeb = properties.OpenWeb();
            SPWebPropertiesHashtable hash = new SPWebPropertiesHashtable(currentWeb);

            hash.Remove(key);
            base.ItemDeleting(properties);
        }

        /// <summary>
        /// Retrieves the field from the content type.
        /// </summary>
        /// <param name="properties">The properties of the item</param>
        /// <param name="contentTypeName">The name of the content type</param>
        /// <returns>The field information</returns>
        private static FieldOp FindField(SPItemEventProperties properties, string contentTypeName)
        {
            FieldOp fo = new FieldOp();

            if (contentTypeName != null)
            {
                fo = FieldFromCT(properties, contentTypeName);
                if (fo.Cancel)
                {
                    return fo;
                }
            }

            return fo;
        }

        /// <summary>
        /// Retrieves the field from the content type.
        /// </summary>
        /// <param name="properties">The SharePoint properties</param>
        /// <param name="contentTypeName">The name of the content type</param>
        /// <returns>The field information</returns>
        private static FieldOp FieldFromCT(SPItemEventProperties properties, string contentTypeName)
        {
            SPContentType ct = properties.OpenWeb().AvailableContentTypes[contentTypeName];
            return FieldFromFieldCollection(ct.Fields);
        }

        /// <summary>
        /// Returns a field from a field collection
        /// </summary>
        /// <param name="fieldCollection">The collection of fields</param>
        /// <returns>The field within the collection that matches our content type</returns>
        private static FieldOp FieldFromFieldCollection(SPFieldCollection fieldCollection)
        {
            var fields = from SPField f in fieldCollection
                         where f.InternalName != ChannelConfigurationConstants.ChannelConfigurationTitle && f.InternalName != ChannelConfigurationConstants.SharePointContentType && !f.Hidden
                         select f;
            FieldOp fo = new FieldOp();
            fo.FieldName = null;
            fo.Cancel = false;

            if (fields.Count<SPField>() == 0)
            {
                return fo;
            }

            if (fields.Count<SPField>() > 1)
            {
                fo.Cancel = true;
                fo.FieldName = null;
                return fo;
            }

            fo.FieldName = fields.ElementAt<SPField>(0).InternalName;

            return fo;
        }

        /// <summary>
        /// Returns the content type from a SharePoint list
        /// </summary>
        /// <param name="list">The SharePoint list</param>
        /// <returns>The content type</returns>
        private static SPContentType ContentTypeFromList(SPList list)
        {
            var contentTypes = from SPContentType ct in list.ContentTypes
                               where ct.Name == "ChannelStringContentType"
                               select ct;

            if (contentTypes.Count<SPContentType>() == 0)
            {
                return null;
            }

            return contentTypes.ElementAt<SPContentType>(0);
        }

        /// <summary>
        /// Helper method that surrounds a string in parenthesis
        /// </summary>
        /// <param name="x">The parameter to surround in parrenthesis</param>
        /// <returns>The modified string</returns>
        private static string SurroundInBrackets(string x)
        {
            return "{" + x + "}";
        }

        /// <summary>
        /// Checks to see if a particular item is a reserved system item.
        /// </summary>
        /// <param name="itemName">The name of the item</param>
        /// <returns>True if reserved, otherwise false</returns>
        private static bool IsItemReserved(string itemName)
        {
            IList listItems = ChannelConfigurationConstants.ReservedChannelConfigurationParameters as IList;
            return listItems.Contains(itemName);
        }

        /// <summary>
        /// Checks to see if the item exists in the SharePoint list
        /// </summary>
        /// <param name="sharePointWeb">The SharePoint web object</param>
        /// <param name="listId">The Id of the list</param>
        /// <param name="itemName">The name of the item within the list</param>
        /// <returns>True if the item already exists in the list, otherwise false</returns>
        private static bool ItemsExistsInList(SPWeb sharePointWeb, Guid listId, string itemName)
        {
            SPListItemCollection listItems = sharePointWeb.Lists[listId].Items;

            if (listItems != null && listItems.Count > 1)
            {
                foreach (SPListItem item in listItems)
                {
                    if (item.Name.Equals(itemName, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Returns the content type from the properties
        /// </summary>
        /// <param name="afterPropertiesCT">The modified content type</param>
        /// <param name="listCT">The list content type</param>
        /// <returns>The original or modified content type name</returns>
        private static string FindAddingContentType(string afterPropertiesCT, string listCT)
        {
            return afterPropertiesCT == null ? listCT : afterPropertiesCT;
        }

        /// <summary>
        /// Retrieves the internal field name from the field.
        /// </summary>
        /// <param name="internalFieldName">The field name</param>
        /// <returns>The internal portion of the field</returns>
        private static string InternalFieldName(string internalFieldName)
        {
            return internalFieldName.Substring(0, Math.Min(internalFieldName.Length, 32));
        }

        /// <summary>
        /// A structure that encapsulates a SharePoint field.
        /// </summary>
        private struct FieldOp
        {
            /// <summary>
            /// The name of the field
            /// </summary>
            public string FieldName;

            /// <summary>
            /// The cancel attribute of the field
            /// </summary>
            public bool Cancel;
        }
    }
}
