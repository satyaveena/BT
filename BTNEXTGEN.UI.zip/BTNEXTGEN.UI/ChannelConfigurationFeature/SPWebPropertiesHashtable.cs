﻿//------------------------------------------------------------------------
// <copyright file="SPWebPropertiesHashtable.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>Hash table for SharePoint list properties</summary>
//------------------------------------------------------------------------

namespace BTNextGen.Commerce.Portal.ChannelConfiguration
{
    using System;
    using System.Collections;
    using System.Linq;
    using Microsoft.SharePoint;

    /// <summary>
    /// This class acts as a hash table to store the properties within Channel Configuration
    /// </summary>
    internal class SPWebPropertiesHashtable : SPWebReadPropertiesHashtable, IDictionary
    {
        /// <summary>
        /// The key prefix for a field
        /// </summary>
        private const string KEYPREFIX = "microsoft.commerce.settings";

        /// <summary>
        /// The separator for identifying the field
        /// </summary>
        private const char SEPARATOR = '.';

        /// <summary>
        /// Initializes a new instance of the <see cref="SPWebPropertiesHashtable"/> class.
        /// </summary>
        /// <param name="web">The SharePoint web instance</param>
        public SPWebPropertiesHashtable(SPWeb web)
            : base(web)
        {
        }

        /// <summary>
        /// Gets a value indicating whether the fixed size attribute of the hash table
        /// </summary>
        public bool IsFixedSize
        {
            get { return CurrentWeb.AllProperties.IsFixedSize; }
        }

        /// <summary>
        /// Gets a value indicating whether the properties are read only
        /// </summary>
        public bool IsReadOnly
        {
            get { return CurrentWeb.AllProperties.IsReadOnly; }
        }

        /// <summary>
        /// Gets a value for the collection - not supported
        /// </summary>
        public ICollection Values
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Gets a value indicating whether the hashtable is syncronized
        /// </summary>
        public bool IsSynchronized
        {
            get { return CurrentWeb.AllProperties.IsSynchronized; }
        }

        /// <summary>
        /// Gets the syncronization root
        /// </summary>
        public object SyncRoot
        {
            get { return CurrentWeb.AllProperties.SyncRoot; }
        }

        /// <summary>
        /// Gets or sets the key for the item in the hash table
        /// </summary>
        /// <param name="key">The key used to find the object in the hash table</param>
        /// <returns>The item from the hash table</returns>
        public override object this[object key]
        {
            get
            {
                string newKey = KEYPREFIX + SEPARATOR + key;

                if (CurrentWeb.AllProperties.ContainsKey(newKey))
                {
                    return CurrentWeb.AllProperties[newKey];
                }

                return null;
            }

            set
            {
                string newKey = KEYPREFIX + SEPARATOR + key;

                CurrentWeb.AllowUnsafeUpdates = true;

                if (!CurrentWeb.Properties.ContainsKey(newKey))
                {
                    CurrentWeb.Properties.Add(newKey, value == null ? null : value.ToString());
                }
                else
                {
                    CurrentWeb.Properties[newKey] = value == null ? null : value.ToString();
                }

                CurrentWeb.Properties.Update();
                CurrentWeb.AllowUnsafeUpdates = false;
                CurrentWeb.AllowUnsafeUpdates = true;
                CurrentWeb.AllProperties[newKey] = value;
                CurrentWeb.Update();
                CurrentWeb.AllowUnsafeUpdates = false;
            }
        }

        #region IDictionary Members

        /// <summary>
        /// Adds a new item to the hash table
        /// </summary>
        /// <param name="key">The key for the item</param>
        /// <param name="value">The value of the item</param>
        public void Add(object key, object value)
        {
            CurrentWeb.AllowUnsafeUpdates = true;
            string newKey = KEYPREFIX + SEPARATOR + key;
            if (!CurrentWeb.AllProperties.ContainsKey(newKey))
            {
                if (!CurrentWeb.Properties.ContainsKey(newKey))
                {
                    CurrentWeb.Properties.Add(newKey, value.ToString());
                }
                else
                {
                    CurrentWeb.Properties[newKey] = value.ToString();
                }
            }
            else
            {
                CurrentWeb.AllProperties[newKey] = value;
            }

            CurrentWeb.Properties.Update();
            CurrentWeb.AllowUnsafeUpdates = false;
        }

        /// <summary>
        /// Clears the hashed keys
        /// </summary>
        public void Clear()
        {
            var allKeys = from string key in CurrentWeb.AllProperties.Keys
                          where key.StartsWith(KEYPREFIX, StringComparison.OrdinalIgnoreCase)
                          select key;
            var someKeys = from string key in CurrentWeb.Properties.Keys
                           where key.StartsWith(KEYPREFIX, StringComparison.OrdinalIgnoreCase)
                           select key;
            var uniqueKeys = allKeys.Union(someKeys).Distinct();
            string[] uniqueKeysCopy = uniqueKeys.ToArray();
            foreach (string key in uniqueKeysCopy)
            {
                CurrentWeb.AllProperties.Remove(key);
                CurrentWeb.Properties.Remove(key);
            }
        }

        /// <summary>
        /// Removes an item from the hash table
        /// </summary>
        /// <param name="key">The key of the item to remove</param>
        public void Remove(object key)
        {
            string newKey = KEYPREFIX + SEPARATOR + (string)key;

            if (CurrentWeb.Properties.ContainsKey(newKey))
            {
                CurrentWeb.AllowUnsafeUpdates = true;

                CurrentWeb.Properties.Remove(newKey);
                CurrentWeb.Properties.Update();

                CurrentWeb.AllProperties.Remove(newKey);
                CurrentWeb.AllowUnsafeUpdates = false;

                CurrentWeb.AllowUnsafeUpdates = true;
                CurrentWeb.Update();
                CurrentWeb.AllowUnsafeUpdates = false;
            }
        }

        #endregion

        /// <summary>
        /// Copies an array at a specified index.  Not implemented
        /// </summary>
        /// <param name="array">The target array for the data</param>
        /// <param name="index">The index to copy the data from</param>
        public void CopyTo(Array array, int index)
        {
            throw new NotImplementedException();
        }

        /// <summary>    
        /// The enumerator for the hash table.  Not implemented
        /// </summary>
        /// <returns>Throws an exception since it's not used</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
