﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.XPath;

namespace BTCustomTagging
{
    public class XMLHelper
    {
        protected XPathDocument docNav;
        protected XPathNavigator nav;
        protected XPathNodeIterator xit;
        protected bool initpath = true;
        public XMLHelper() { }

        public XMLHelper(String path)
        {
            try
            {
                docNav = new XPathDocument(path);
                nav = docNav.CreateNavigator();
            }
            catch
            {
                docNav = null;
                nav = null;
            }
        }
        public bool Init(String path)
        {
            try
            {
                docNav = new XPathDocument(path);
                nav = docNav.CreateNavigator();
            }
            catch
            {
                docNav = null;
                nav = null;
                return false;
            }
            return true;
        }

        public List<string> ValuesOf(String Item)
        {
            List<string> list = new List<string>();
            if (nav == null) return null;
            String tmp = "descendant::" + Item;
            try
            {
                xit = nav.Select(tmp);
                while (xit.MoveNext())
                {
                    list.Add(xit.Current.Value);
                }
            }
            catch
            {
                list = null;
            }
            return list;
        }

        public String ValueOf(String Item)
        {
            if (nav == null) return "Error; Navigator is null";
            String tmp = "descendant::" + Item;
            try
            {
                xit = nav.Select(tmp);
                if (xit.MoveNext()) tmp = xit.Current.Value;
                else tmp = "null";
            }
            catch
            {
                tmp = "null";
            }
            return tmp;
        }

        public String GetAttributeValue(String Item, String Attribute)
        {
            if (nav == null) return "Error; Navigator is null";
            String tmp = "descendant::" + Item;
            String attr = string.Empty;
            try
            {
                xit = nav.Select(tmp);
                if (xit.MoveNext())
                    attr = xit.Current.GetAttribute(Attribute, "");
            }
            catch
            {
                attr = "null";
            }
            return attr;
        }
    }
}