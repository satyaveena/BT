using System;
using System.Collections.Generic;
using System.Xml;
using System.Text;
using System.Web;
using System.Globalization;
using BTNextGen.Commerce.Portal.Common.Logging;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace BTCustomTagging.EventHandlers.Features
{
    public class TagCustomPagesReceiver : SPFeatureReceiver
    {
        XMLHelper helper = new XMLHelper();
        private const string XML_DOC = "NextGenTagDefinition.xml";
                
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            base.FeatureActivated(properties);
            string[] directoryTable = GetDirectoryTable(properties);

            try
            {
                String completePath = directoryTable[0];
                
                helper.Init(completePath);

                String server = helper.ValueOf("MetaTag/Server");
                List<string> pages = helper.ValuesOf("MetaTag/Page/name");
                foreach (string sPageName in pages)
                {
                    StringBuilder objMetaTag = new StringBuilder();
                    String page = string.Empty;
                    String metaTag = string.Empty;

                    page = sPageName;

                    List<string> tag = helper.ValuesOf(string.Format("MetaTag/Page[name='{0}']/tag", page));
                    for(int k = 1; k <= tag.Count; k++)
                    {
                        string metaName = helper.GetAttributeValue(string.Format("MetaTag/Page[name='{0}']/tag[{1}]", page, k), "name");
                        string metaID = helper.GetAttributeValue(string.Format("MetaTag/Page[name='{0}']/tag[{1}]", page, k), "id");

                        objMetaTag.AppendFormat("<meta name=\"{0}\" id=\"{1}\" />", metaName, metaID);
                    }

                    metaTag = objMetaTag.ToString();

                    //create web part
                    TagFile(server, page, metaTag);
                }
            }
            catch (Exception exception)
            {
                Logger.Write("BTCustomTagging:TagCustomPagesReceiver:FeatureActivated", exception.Message);
            }
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            base.FeatureDeactivating(properties);
            string[] directoryTable = GetDirectoryTable(properties);

            try
            {
                String completePath = directoryTable[0];

                helper.Init(completePath);

                String server = helper.ValueOf("MetaTag/Server");
                List<string> pages = helper.ValuesOf("MetaTag/Page/name");
                foreach (string sPageName in pages)
                {
                    StringBuilder objMetaTag = new StringBuilder();
                    String page = string.Empty;
                    String metaTag = string.Empty;

                    page = sPageName;

                    //delete web part
                    DeleteMetaTags(properties,server, page);
                }
            }
            catch (Exception)
            {

            }

        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
            base.FeatureInstalled(properties);
        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
            base.FeatureUninstalling(properties);
        }

        public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, IDictionary<string, string> parameters)
        {
            base.FeatureUpgrading(properties, upgradeActionName, parameters);

        }

        #region [ Private Methods ]

        private void TagFile(string server, string pageName, string content)
        {
            using (SPSite site = new SPSite(server))
            {
                SPWeb web = site.RootWeb;
                SPFile page = web.GetFile(pageName);
                if (!page.Exists)
                    return;

                page.CheckOut();

                using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                {
                    XmlElement p = new XmlDocument().CreateElement("p");
                    p.InnerText = content;
                    ContentEditorWebPart cewp = new ContentEditorWebPart
                    {
                        Content = p
                    };
                    cewp.Visible = false;
                    cewp.ChromeType = PartChromeType.None;
                    cewp.Title = "CustomMetaTagWebPart";
                    wpmgr.AddWebPart(cewp, "Header", 0);

                }

                page.CheckIn(String.Empty);
            }


        }

        private void DeleteMetaTags(SPFeatureReceiverProperties properties, string server, string pageName)
        {
            string[] directoryTable = GetDirectoryTable(properties);
            String completePath = directoryTable[0];

            helper.Init(completePath);
            try
            {
                using (SPSite site = new SPSite(server))
                {
                    SPWeb web = site.RootWeb;
                    SPFile page = web.GetFile(pageName);
                    if (!page.Exists)
                        return;

                    using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                    {
                        for (int k = 0; k < wpmgr.WebParts.Count; k++)
                        {
                            System.Web.UI.WebControls.WebParts.WebPart wp = wpmgr.WebParts[k];

                            //check webpart Title to find webpart which is to be removed
                            if (wp.Title == "CustomMetaTagWebPart")
                            {
                                //delete webpart
                                wpmgr.DeleteWebPart(wp);

                                //update spWeb object
                                web.Update();
                            }
                        }
                    }
                }
            }
            catch(Exception)
            {
                
            }
        }

        private string[] GetDirectoryTable(SPFeatureReceiverProperties properties)
        {
            string[] dirFiles = System.IO.Directory.GetFiles(properties.Definition.RootDirectory + @"\Xmlfile\", XML_DOC);

            return dirFiles;
        }

        #endregion


    }
}
