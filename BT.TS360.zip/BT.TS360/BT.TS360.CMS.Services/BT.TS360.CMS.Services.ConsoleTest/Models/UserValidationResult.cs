﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.CMS.Services.ConsoleTest.Models
{
    public class UserValidationResult
    {
        public ValidationStatus ValidationStatus { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }

        public LoginUserInfo UserInfo { get; set; }
    }
}