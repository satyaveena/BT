﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.CMS.Services.ConsoleTest.Models
{
    public enum APIServiceStatus
    {
        Success = 0,
        Fail = 1,
        LimitationFail = 2
    }

    public enum ValidationStatus
    {
        Success = 0,
        Fail = 1,
    }

    public enum MarketType
    {
        Any = -1,
        Retail = 0,
        PublicLibrary = 1,
        AcademicLibrary = 2,
        SchoolLibrary = 3,
    }
}