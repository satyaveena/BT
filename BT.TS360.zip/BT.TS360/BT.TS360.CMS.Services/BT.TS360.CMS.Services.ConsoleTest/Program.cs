﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.CMS.Services.ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var response = CMSUserTest.ValidateAndGetTS360UserInfo("btadmin", "P@ssword123");
            Console.WriteLine("response status: {0}", response.Data.ValidationStatus);
            Console.Read();
        }
    }
}
