﻿using BT.TS360.CMS.Services.ConsoleTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace BT.TS360.CMS.Services.ConsoleTest
{
    public class CMSUserTest
    {
        public static APIServiceResult<ValidateAndGetUserInfoResponse> ValidateAndGetTS360UserInfo(string userName, string password)
        {
            string jsonString = String.Empty;

            var request = new ValidateAndGetUserInfoRequest
            {
                UserName = userName,
                Password = password
            };

            // Create a WebClient to POST the request
            using (WebClient client = new WebClient())
            {
                var webApiUrl = "http://localhost:6600/User/ValidateAndGetUserInfo";

                // Set the header so it knows we are sending JSON
                client.Headers[HttpRequestHeader.ContentType] = "application/json";
                // PassPhrase
                var passPhrase = "LKDJG7DK084K73GGD";
                client.Headers[HttpRequestHeader.Authorization] = "Bearer " + passPhrase;

                var jss = new JavaScriptSerializer();
                // Serialise the data we are sending in to JSON
                string serialisedData = jss.Serialize(request);
                // Make the request
                var response = client.UploadString(webApiUrl, serialisedData);

                return jss.Deserialize<APIServiceResult<ValidateAndGetUserInfoResponse>>(response);
            }
        }
    }
}
