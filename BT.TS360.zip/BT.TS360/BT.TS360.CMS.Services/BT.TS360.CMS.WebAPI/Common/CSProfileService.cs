﻿using BT.TS360.CMS.WebAPI.CSProfileServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace BT.TS360.CMS.WebAPI.Common
{
    public class CSProfileService
    {
        private static ProfilesWebServiceSoapClient _serviceClient;

        private static volatile CSProfileService _instance;
        private static readonly object SyncRoot = new Object();

        private CSProfileService()
        {
        }

        public static CSProfileService Instance
        {
            get
            {
                if (_instance != null) return _instance;

                lock (SyncRoot)
                {
                    if (_instance == null)
                    {
                        _serviceClient = new ProfilesWebServiceSoapClient();
                        _instance = new CSProfileService();
                    }
                        
                }

                return _instance;
            }
        }

        public string GetPasswordByUserName(string userName)
        {
            var profilePassword = string.Empty;
            try
            {
                var xmlString = "<CLAUSE OPER=\"equal\" xmlns=\"http://schemas.microsoft.com/CommerceServer/2004/02/Expressions\">";
                xmlString += "<PROPERTY ID=\"user_name\" MULTIVAL=\"false\" TYPE=\"String\" />";
                xmlString += "<IMMED-VAL TYPE=\"String\"><VALUE>" + userName + "</VALUE></IMMED-VAL>";
                xmlString += "</CLAUSE>";
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(xmlString);

                var searchClause = xmlDoc.DocumentElement;
                SearchOptions searchOptions = new SearchOptions();
                searchOptions.StartRecord = 1;
                searchOptions.NumberOfRecordsToReturn = 1;
                searchOptions.PropertiesToReturn = "user_security_password";

                var dataSet = _serviceClient.ExecuteSearch("UserObject", searchClause, searchOptions);
                if (dataSet != null && dataSet.Tables.Count > 0)
                {
                    var table = dataSet.Tables[0];
                    if (table.Rows.Count > 0)
                    {
                        profilePassword = table.Rows[0][0].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogException("GetPasswordByUserName error", ex);
            }

            return profilePassword;
        }
    }
}