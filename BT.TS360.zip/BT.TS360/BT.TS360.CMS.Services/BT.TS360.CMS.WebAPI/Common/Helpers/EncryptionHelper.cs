﻿//-----------------------------------------------------------------------
// <copyright file="EncryptionHelper.cs" company="Microsoft">
//     Copyright © Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>EncryptionHelper class</summary>
//-----------------------------------------------------------------------

using System.Globalization;
using System;
using System.Configuration;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BT.TS360.CMS.WebAPI.Common.Helpers
{
    /// <summary>
    /// Encryption Helper class.
    /// </summary>
    public static class EncryptionHelper
    {        
        private const int SaltValueSize = 4;
        private static readonly string[] HashingAlgorithms = new[] { "SHA256", "MD5" };

        /// <summary>
        /// Encrypts Password.
        /// </summary>
        /// <param name="password"></param>
        /// <param name="profilePassword"></param>
        /// <returns></returns>
        public static string EncryptPassword(string password, string profilePassword)
        {
            if (String.IsNullOrEmpty(password))
            {
                return string.Empty;
            }

            int saltLength = SaltValueSize * UnicodeEncoding.CharSize;
            // Strip the salt value off the front of the stored password.
            string saltValue = profilePassword.Substring(0, saltLength);

            HashAlgorithm hash = HashAlgorithm.Create("SHA256");
            string hashedPassword = HashPassword(password, saltValue, hash);

            return hashedPassword;
        }

        private static string HashPassword(string clearData, string saltValue, HashAlgorithm hash)
        {
            var encoding = new UnicodeEncoding();
            if (clearData != null && hash != null)
            {
                // Convert the salt string and the password string to a single
                // array of bytes. Note that the password string is Unicode and
                // therefore may or may not have a zero in every other byte.
                var binarySaltValue = new byte[SaltValueSize];
                binarySaltValue[0] = Byte.Parse(saltValue.Substring(0, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture.NumberFormat);
                binarySaltValue[1] = Byte.Parse(saltValue.Substring(2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture.NumberFormat);
                binarySaltValue[2] = Byte.Parse(saltValue.Substring(4, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture.NumberFormat);
                binarySaltValue[3] = Byte.Parse(saltValue.Substring(6, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture.NumberFormat);
                var valueToHash = new byte[SaltValueSize + encoding.GetByteCount(clearData)];
                var binaryPassword = encoding.GetBytes(clearData);
                // Copy the salt value and the password to the hash buffer.
                binarySaltValue.CopyTo(valueToHash, 0);
                binaryPassword.CopyTo(valueToHash, SaltValueSize);
                byte[] hashValue = hash.ComputeHash(valueToHash);
                // The hashed password is the salt plus the hash value (as a string).
                var hashedPassword = saltValue;
                foreach (var hexdigit in hashValue)
                {
                    hashedPassword += hexdigit.ToString("X2", CultureInfo.InvariantCulture.NumberFormat);
                }
                // Return the hashed password as a string.
                return hashedPassword;
            }
            return null;
        }

        private static string GenerateSaltValue()
        {
            var utf16 = new UnicodeEncoding();
            // Create a random number object seeded from the value
            // of the last random seed value. This is done
            // interlocked because it is a static value and we want
            // it to roll forward safely.
            var random = new Random(unchecked((int) DateTime.Now.Ticks));
            // Create an array of random values.
            var saltValue = new byte[SaltValueSize];
            random.NextBytes(saltValue);
            // Convert the salt value to a string. Note that the resulting string
            // will still be an array of binary values and not a printable string. 
            // Also it does not convert each byte to a double byte.
            string saltValueString = utf16.GetString(saltValue);
            // Return the salt value as a string.
            return saltValueString;
        }
    }
}
