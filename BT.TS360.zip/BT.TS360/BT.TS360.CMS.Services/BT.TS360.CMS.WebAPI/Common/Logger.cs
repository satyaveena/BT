﻿using System;
using log4net;

namespace BT.TS360.CMS.WebAPI.Common
{
    public class Logger
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(Logger));

        public static void LogException(string message, Exception exception)
        {
            Log.Error(message, exception);
        }

        public static void LogDebug(string message, Exception exception = null)
        {
            Log.Debug(message, exception);
        }

        public static void LogInfo(string message, Exception exception = null)
        {
            Log.Info(message, exception);
        }
    }
}
