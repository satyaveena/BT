﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.CMS.WebAPI.Common
{
    public class Constants
    {

    }

    public class DBStores
    {
        public const string PROC_VALIDATE_AND_GET_USER_INFO = "procValidateAndGetUserInfo";
    }

    public static class CommonErrorMessage
    {
        public static readonly string UnexpectedErrorMessage = "Unexpected error! Please contact administrator.";
    }

    public static class UserValidateErrorCode
    {
        public const int UserNameOrPasswordIsBlank = 1;
        public const int InvalidUserNameOrPassword = 2;
    }
}