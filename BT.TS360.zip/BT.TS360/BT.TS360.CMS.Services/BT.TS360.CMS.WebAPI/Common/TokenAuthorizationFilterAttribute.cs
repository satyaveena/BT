﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Http.Filters;
using System.Web.Http.Results;
using System.Net.Http;
using Newtonsoft.Json;
using System.Configuration;

namespace BT.TS360.CMS.WebAPI.Common
{
    public class TokenAuthorizationFilterAttribute : AuthorizationFilterAttribute 
    {
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            try
            {
                var authorization = actionContext.Request.Headers.Authorization;
                if (authorization == null)
                {
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
                else
                {
                    // Gets header parameters  
                    string authenticationString = authorization.Parameter;

                    var passPhrase = ConfigurationManager.AppSettings["APIPassPhrase"].ToString();

                    if (!string.Equals(passPhrase, authenticationString))
                    {
                        // returns unauthorized error  
                        actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
                    }
                }

                base.OnAuthorization(actionContext);
            }
            catch (Exception ex)
            {
                Logger.LogException("WebAPI PassPhrase Exception", ex);
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
        }
    }
}