﻿using BT.TS360.CMS.WebAPI.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.CMS.WebAPI.Models
{
    public class LoginUserInfo
    {
        public string UserID { get; set; }
        public string Alias { get; set; }
        public MarketType MarketType { get; set; }
        public string[] AudienceTypes { get; set; }
        public string[] ProductTypes { get; set; }
    }
}