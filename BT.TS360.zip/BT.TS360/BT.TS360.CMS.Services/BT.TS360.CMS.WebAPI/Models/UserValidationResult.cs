﻿using BT.TS360.CMS.WebAPI.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.CMS.WebAPI.Models
{
    public class UserValidationResult
    {
        public ValidationStatus ValidationStatus { get; set; }
        public int ErrorCode { get; set; }
        public string ErrorDescription { get; set; }

        public LoginUserInfo UserInfo { get; set; }
    }
}