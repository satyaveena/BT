﻿using BT.TS360.CMS.WebAPI.Common;
using BT.TS360.CMS.WebAPI.Common.Helpers;
using BT.TS360.CMS.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace BT.TS360.CMS.WebAPI.DAL
{
    public class UserDAO : BaseDAO
    {
        //
        private static readonly UserDAO instance = new UserDAO();

        /// <summary>
        /// Accessed Object
        /// </summary>
        public static UserDAO Instance
        {
            get
            {
                return instance;
            }
        }

        /// <summary>
        /// Connection String for Nextgen_profiles database.
        /// </summary>
        public override string ConnectionString
        {
            get
            {
                var cnnString = WebConfigurationManager.ConnectionStrings["NextGenProfilesConnectionString"].ConnectionString;

                return cnnString;
            }
        }

        public UserValidationResult ValidateAndGetUserInfo(string userName, string password)
        {
            var result = new UserValidationResult();
            using (var dbConnection = CreateSqlConnection())
            {
                //var result = new List<Account>();
                using (var command = CreateSqlSpCommandWithErrorHandling(DBStores.PROC_VALIDATE_AND_GET_USER_INFO, dbConnection))
                {
                    var sqlParameters = CreateSqlParamaters(3);

                    sqlParameters[0] = new SqlParameter("@UserName", userName);
                    sqlParameters[1] = new SqlParameter("@Password", SqlDbType.NVarChar, 100) { Value = password };
                    sqlParameters[2] = new SqlParameter("@ValidationStatus", SqlDbType.Bit) { Direction = ParameterDirection.Output };

                    command.Parameters.AddRange(sqlParameters);

                    try
                    {
                        dbConnection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                if (reader.Read())
                                {
                                    var userInfo = new LoginUserInfo
                                    {
                                        UserID = DataAccessHelper.ConvertToString(reader["UserID"]),
                                        Alias = DataAccessHelper.ConvertToString(reader["UserAlias"]),
                                        MarketType = (MarketType)DataAccessHelper.ConvertToInt(reader["MarketType"]),
                                        AudienceTypes = DataAccessHelper.ConvertToStringArray(reader["AudienceTypes"].ToString()),
                                        ProductTypes = DataAccessHelper.ConvertToStringArray(reader["ProductTypes"].ToString()),
                                    };

                                    result.UserInfo = userInfo;
                                }

                                reader.Close();
                            }
                        }

                        // validation status
                        var isSuccess = DataAccessHelper.ConvertToBool(command.Parameters["@ValidationStatus"].Value);
                        result.ValidationStatus = isSuccess ? ValidationStatus.Success : ValidationStatus.Fail;

                        if (!isSuccess)
                            result.ErrorCode = UserValidateErrorCode.InvalidUserNameOrPassword;

                        // error message
                        result.ErrorDescription = DataAccessHelper.ConvertToString(command.Parameters["@ErrorMessage"].Value);
                    }
                    finally
                    {
                        dbConnection.Close();
                    }
                }
            }

            return result;
        }
    }
}