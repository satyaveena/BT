﻿using BT.TS360.CMS.WebAPI.Common;
using BT.TS360.CMS.WebAPI.Common.Helpers;
using BT.TS360.CMS.WebAPI.DAL;
using BT.TS360.CMS.WebAPI.Models;
using System;
using System.Web.Http;

namespace BT.TS360.CMS.WebAPI.Controllers
{
    [TokenAuthorizationFilter]
    public class UserController : ApiController
    {
        public UserController()
        {
        }

        [HttpPost]
        [Route("User/ValidateAndGetUserInfo")]
        public APIServiceResult<ValidateAndGetUserInfoResponse> ValidateAndGetUserInfo(ValidateAndGetUserInfoRequest request)
        {
            var serviceResult = new APIServiceResult<ValidateAndGetUserInfoResponse>();

            try
            {
                // validate request
                if (request == null || string.IsNullOrEmpty(request.UserName) || string.IsNullOrEmpty(request.Password))
                {
                    serviceResult.Data = new ValidateAndGetUserInfoResponse
                    {
                        ValidationStatus = Common.ValidationStatus.Fail,
                        ErrorCode = UserValidateErrorCode.UserNameOrPasswordIsBlank,
                        ErrorDescription = "User name or password is blank"
                    };
                }
                else
                {
                    var profilePassword = CSProfileService.Instance.GetPasswordByUserName(request.UserName);
                    if (string.IsNullOrEmpty(profilePassword))
                    {
                        serviceResult.Data = new ValidateAndGetUserInfoResponse
                        {
                            ValidationStatus = Common.ValidationStatus.Fail,
                            ErrorCode = UserValidateErrorCode.InvalidUserNameOrPassword,
                            ErrorDescription = "User name does not exist"
                        };
                    }

                    // encrypt password
                    var encryptedPassword = EncryptionHelper.EncryptPassword(request.Password, profilePassword);

                    // validate and get user information
                    var daoResult = UserDAO.Instance.ValidateAndGetUserInfo(request.UserName, encryptedPassword);
                    if (daoResult != null)
                    {
                        serviceResult.Data = new ValidateAndGetUserInfoResponse
                        {
                            ValidationStatus = daoResult.ValidationStatus,
                            ErrorCode = daoResult.ErrorCode,
                            ErrorDescription = daoResult.ErrorDescription,
                            UserInfo = daoResult.UserInfo
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                serviceResult.Status = APIServiceStatus.Fail;
                serviceResult.ErrorMessage = CommonErrorMessage.UnexpectedErrorMessage;

                Logger.LogException(ex.Message, ex);
            }

            return serviceResult;
        }
    }
}
