﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


namespace BT.TS360.NoSQL.Services.AzureSearchCrawlerMonitor
{
    class AppSettings
    {
        #region ServiceSettings
        //values pertain to  how the service will running and it's timing interval

        public static int IntervalMinutes
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]); }
        }


        public static String DateTimeLastRun
        {
            get { return ConfigurationManager.AppSettings["DateTimeLastRun"].ToString(); }
        }

        #endregion ServiceSettings


        #region LoggingSettings
        //values pertain to logging (3 types of logging: file, email and elmah)

        public static string CurrentEnvironment
        {
            get { return ConfigurationManager.AppSettings["CurrentEnvironment"].ToString(); }
        }

        public static string EmailTo
        {
            get { return ConfigurationManager.AppSettings["EmailTo"].ToString(); }
        }

        public static string EmailSMTPServer
        {
            get { return ConfigurationManager.AppSettings["EmailSMTPServer"].ToString(); }
        }


       
        public static string LogFolder
        {
            get { return ConfigurationManager.AppSettings["LogFolder"].ToString(); }
        }


        public static string LogFolderArchive
        {
            get { return ConfigurationManager.AppSettings["LogFolderArchive"].ToString(); }
        }

        public static string LogFilePrefix
        {
            get { return ConfigurationManager.AppSettings["LogFilePrefix"].ToString(); }
        }

        #endregion LoggingSettings
    }
}
