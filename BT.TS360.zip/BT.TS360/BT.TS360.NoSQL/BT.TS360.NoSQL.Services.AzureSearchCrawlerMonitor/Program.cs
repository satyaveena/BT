﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.AzureSearchCrawlerMonitor
{
    static class Program
    {


        static void Main(params string[] args)
        {

            AzureCrawlerMonitorService service = new AzureCrawlerMonitorService();

            if (!Environment.UserInteractive)
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
                { 
                    new AzureCrawlerMonitorService() 
                };
                ServiceBase.Run(ServicesToRun);

            }
            else
            {
                service.Start(args);

                Console.WriteLine("AzureCrawlerMonitorService service is running... Press any key to stop");
                Console.WriteLine("");
                Console.ReadKey();
                Console.WriteLine("Closing");

                service.Stop(args);

            }
        }
    }
}
