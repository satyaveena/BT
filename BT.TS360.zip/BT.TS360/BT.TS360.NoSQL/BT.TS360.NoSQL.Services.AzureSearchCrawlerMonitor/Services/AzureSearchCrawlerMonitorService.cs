﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data.Common.Helper;

namespace BT.TS360.NoSQL.Services.AzureSearchCrawlerMonitor.Services
{
    class AzureSearchCrawlerMonitorService
    {

        static Emailer _emailer;

        public async Task Main()
        {
            _emailer = new Emailer(AppSettings.EmailSMTPServer);

            var logFolder = new DirectoryInfo(AppSettings.LogFolder);
            var logFolderArchive = new DirectoryInfo(AppSettings.LogFolderArchive);
            var emailBody = "Errors Found in Azure Search Crawler. Please review the following file(s): \r\n\r\n";
            var files = logFolder.GetFiles();
            bool filesToSend = false;

            foreach (var file in files)
            {
                Console.WriteLine("fileName " + file.FullName);
                Console.WriteLine(logFolderArchive + file.Name);

                try
                {
                    using (Stream stream = new FileStream(file.FullName, FileMode.Open))
                    {
                        stream.Close();

                        if (File.Exists(logFolderArchive + file.Name))
                        {
                            File.Delete(logFolderArchive + file.Name);
                        }
                        File.Move(file.FullName, logFolderArchive + file.Name);
                       

                        emailBody += logFolderArchive + file.Name + "\r\n";
                        filesToSend = true;
                    }
                }
                catch
                {
                    Console.WriteLine("fileOpen error " + file.FullName);
                }
            }
            if (filesToSend == true)
            {
                _emailer.Send(AppSettings.EmailTo, string.Format("Azure Crawler Errors Found: " + AppSettings.CurrentEnvironment + " [" + Environment.MachineName + "]"), emailBody);
            }
            return;
        }



    }
}
