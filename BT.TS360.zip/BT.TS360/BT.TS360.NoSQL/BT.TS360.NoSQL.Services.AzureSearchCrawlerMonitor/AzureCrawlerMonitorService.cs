﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Timers;

namespace BT.TS360.NoSQL.Services.AzureSearchCrawlerMonitor
{
    public partial class AzureCrawlerMonitorService : ServiceBase
    {

        int _intervalMinutes;

        static Boolean _InProcess = false;

        private System.Timers.Timer _timer;
        
        static Emailer _emailer;
        static string _emailTo;
        static string _environment;


        public AzureCrawlerMonitorService()
        {
            InitializeComponent();
        }

        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args)
        {


            InitAppSettings();

            _timer = new System.Timers.Timer(1);
            _timer.AutoReset = false;
            _timer.Enabled = true;
            _timer.Elapsed += OnTimerElapsed;
            _timer.Start();

        //  _emailer.Send(_emailTo, string.Format("AzureCrawlerMonitorService: " + _environment + " [" + Environment.MachineName + "]"), "Service Started " + DateTime.Now.ToString());

        }

   
        public void Stop(string[] args) { OnStop(); }

        protected override void OnStop()
        {
         //   _emailer.Send(_emailTo, string.Format("AzureCrawlerMonitorService: " + _environment + " [" + Environment.MachineName + "]"), "Service Stopped " + DateTime.Now.ToString());
            _timer.Stop();
            this._timer.Dispose();
        }

        private void OnTimerElapsed(object source, ElapsedEventArgs e)
        {

            Services.AzureSearchCrawlerMonitorService azureSearchCrawlerMonitor = new Services.AzureSearchCrawlerMonitorService();

         
            if (!_timer.AutoReset)
            {
                _timer.Interval = _intervalMinutes * 60 * 1000;
                _timer.AutoReset = true;
            }

            if (!_InProcess)
            {
                _InProcess = true;

                azureSearchCrawlerMonitor.Main();

                _InProcess = false;

            }
          
        }

        private void InitAppSettings()
        {
         
            _emailer = new Emailer(AppSettings.EmailSMTPServer);
            _emailTo = AppSettings.EmailTo;
            _environment = AppSettings.CurrentEnvironment;
            _intervalMinutes = AppSettings.IntervalMinutes;

         
        }
    }
}
