﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using Microsoft.Spatial;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using BT.TS360.NoSQL.Services.AzureSearch;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Services.AzureSearch.Helper;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Services.AzureSearch.Constants;
using BT.TS360.NoSQL.Services.AzureSearch.Models;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Services.DateRangeCalculator.Helper;

namespace BT.TS360.NoSQL.Services.AzureSearch.Services
{
    class SeriesSearchLoad
    {

        static bool runAsRealTime = AppSettings.RunServiceAsRealTime;
        static ThreadedLogger _threadedLogger;
     

        static string seriesIndexName = AppSettings.SeriesIndexName;

        IndexHelper indexHelper = new IndexHelper();
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        StringBuilder logMessage = new StringBuilder();

        public async Task Main()
        {
            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix, AppSettings.LogFolderErrors);



            if (AppSettings.EnableCreateSeriesIndex && AppSettings.ServiceRunType == "Index")
            {
                await CreateIndex();
                _threadedLogger.Write("Index Created", FileLoggingLevel.INFO, seriesIndexName);
                return;
            }

            if (AppSettings.EnableSeriesDataLoad && AppSettings.ServiceRunType == "Crawler")
            {
                await SyncIndexData();
                if (logMessage.Length > 0)
                    _threadedLogger.Write(logMessage.ToString(), FileLoggingLevel.INFO, seriesIndexName);

                return;
            }
        }


        public async Task CreateIndex()
        {
            try
            {

                var definition = indexHelper.GetSeriesIndex();
                await indexHelper.CreateIndexes(definition, seriesIndexName);
            }

            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, seriesIndexName);
            }
        }


        private async Task SyncIndexData()
        {
            //Documents to be Updated or Inserted into Azure Search 
            await UpdateIndexData();

            //Documents to be removed from Azure Search
            await DeleteIndexData();

        }

        private async Task UpdateIndexData()
        {
            try
            {
                //Get ids from SearchQueue
                var azureSearchQueueItem = await mongoDBHelper.GetQueueIds(AppSettings.SeriesCollectionName, AppSettings.ChangeTypeMergeAction, AppSettings.SeriesLoadBatchSize, logMessage);

                if (azureSearchQueueItem != null && azureSearchQueueItem.AzureSearchQueueIdList != null && azureSearchQueueItem.AzureSearchQueueIdList.Any())
                {
                    var searchQueueIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueId).ToList();
                    var searchQueueObjectIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueObjectId).ToList();

                    //set Queue items State as InProcess
                    await mongoDBHelper.UpdateSearchQueueInProcess(searchQueueIdList, (int)QueueProcessState.New, (int)QueueProcessState.InProcess);

                    //Get Mongo data from list of ids
                    var actions = new List<IndexAction<SeriesSearchResultItem>>();
                    var seriesDocumentList = new List<BsonDocument>();
                    seriesDocumentList = await mongoDBHelper.GetSeriesDataForSearchLoad(AppSettings.SeriesObjectIdName, searchQueueObjectIdList, searchQueueIdList);

                    List<SeriesSearchResultItem> seriesSearchItemList = new List<SeriesSearchResultItem>();

                    foreach (var bsdoc in seriesDocumentList)
                    {
                        SeriesSearchResultItem seriesSearchResultItem = BindSeriesSearchResult(bsdoc, azureSearchQueueItem.AzureSearchQueueIdList);
                        seriesSearchItemList.Add(seriesSearchResultItem);
                        actions.Add(IndexAction.MergeOrUpload<SeriesSearchResultItem>(seriesSearchResultItem));
                    }


                    if (!runAsRealTime)
                    {
                        var profiledSeriesDocumentList = new List<BsonDocument>();
                        var seriesIDList = seriesSearchItemList.Select(x => x.SeriesID).ToList();
                        profiledSeriesDocumentList = await mongoDBHelper.GetProfiledSeriesDataForSeriesLoad(seriesIDList, searchQueueIdList, logMessage);

                        List<SeriesSearchResultItem> profiledSeriesSearchItemList = new List<SeriesSearchResultItem>();
                        foreach (var bsdoc in profiledSeriesDocumentList)
                        {
                            SeriesSearchResultItem profiledSeriesSearchResultItem = BindProfiledSeriesSearchResult(bsdoc, azureSearchQueueItem.AzureSearchQueueIdList, seriesSearchItemList);
                            profiledSeriesSearchItemList.Add(profiledSeriesSearchResultItem);
                            actions.Add(IndexAction.MergeOrUpload<SeriesSearchResultItem>(profiledSeriesSearchResultItem));
                        }
                    }


                    var batch = IndexBatch.New(actions);
                    //Load Data into Azure
                    await indexHelper.UploadDocuments(seriesIndexName, batch, azureSearchQueueItem.AzureSearchQueueIdList, logMessage);
                    //set lastcrawl date
                    await mongoDBHelper.UpdateSearchQueueLastCrawlDate(searchQueueIdList);
                }

            }
            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, seriesIndexName);
            }
        }

        private async Task DeleteIndexData()
        {
            try
            {
                //Get ids from SearchQueue
                var azureSearchQueueItem = await mongoDBHelper.GetQueueIds(AppSettings.SeriesCollectionName, AppSettings.ChangeTypeDeleteAction, AppSettings.SeriesLoadBatchSize, logMessage);

                if (azureSearchQueueItem != null && azureSearchQueueItem.AzureSearchQueueIdList != null && azureSearchQueueItem.AzureSearchQueueIdList.Any())
                {

                    var searchQueueIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueId).ToList();
                    var searchQueueObjectIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueObjectId).ToList();
                    //set Queue items as InProcess
                    await mongoDBHelper.UpdateSearchQueueInProcess(searchQueueIdList, (int)QueueProcessState.New, (int)QueueProcessState.InProcess);

                    //Create IndexAction Items
                    var actions = new List<IndexAction<SeriesSearchResultItem>>();
                    foreach (var i in searchQueueObjectIdList)
                    {
                        SeriesSearchResultItem seriesSearchResultItem = new SeriesSearchResultItem();
                        seriesSearchResultItem.ObjectId = i.ToString();
                        actions.Add(IndexAction.Delete<SeriesSearchResultItem>(seriesSearchResultItem));
                    }

                    var batch = IndexBatch.New(actions);

                    //Load Data into Azure
                    await indexHelper.UploadDocuments(seriesIndexName, batch, azureSearchQueueItem.AzureSearchQueueIdList, logMessage);

                    //set lastcrawl date
                    await mongoDBHelper.UpdateSearchQueueLastCrawlDate(searchQueueIdList);

                }
            }
            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, seriesIndexName);

            }
        }


     
        private SeriesSearchResultItem BindSeriesSearchResult(BsonDocument bsdoc, List<AzureSearchQueueIdItem> azureSearchQueueIdList)
        {

            SeriesSearchResultItem seriesSearchResultItem = new SeriesSearchResultItem();

            try
            {
                if (bsdoc.Contains("_id"))
                    seriesSearchResultItem.ObjectId = bsdoc["_id"].AsObjectId.ToString();

                if (bsdoc.Contains("SeriesID") && bsdoc["SeriesID"] != BsonNull.Value)
                    seriesSearchResultItem.SeriesID = bsdoc["SeriesID"].AsString;

                if (bsdoc.Contains("Name") && bsdoc["Name"] != BsonNull.Value)
                {
                    seriesSearchResultItem.Name = bsdoc["Name"].AsString;
                    seriesSearchResultItem.NameKeyword = CommonHelper.RemoveSpecialCharacters(bsdoc["Name"].AsString);  
                }

                if (bsdoc.Contains("Programs") && bsdoc["Programs"] != BsonNull.Value)
                {
                    seriesSearchResultItem.Programs = BsonSerializer.Deserialize<List<string>>(bsdoc["Programs"].ToJson());
                    seriesSearchResultItem.Programs.Sort();
                    seriesSearchResultItem.ProgramsForSort = string.Join(",", seriesSearchResultItem.Programs);
                }
                else
                {
                    seriesSearchResultItem.ProgramsForSort = String.Empty;
                }

                if (bsdoc.Contains("Publisher") && bsdoc["Publisher"] != BsonNull.Value)
                {
                    seriesSearchResultItem.Publisher = bsdoc["Publisher"].AsString;
                    seriesSearchResultItem.PublisherKeyword = CommonHelper.RemoveSpecialCharacters(bsdoc["Publisher"].AsString);  
                }

                if (bsdoc.Contains("Distributor") && bsdoc["Distributor"] != BsonNull.Value)
                {
                    seriesSearchResultItem.Distributor = bsdoc["Distributor"].AsString;
                    seriesSearchResultItem.DistributorNoPunctuation = CommonHelper.RemoveSpecialCharacters(bsdoc["Distributor"].AsString); 
                }

                if (bsdoc.Contains("Format") && bsdoc["Format"] != BsonNull.Value)
                    seriesSearchResultItem.Format = bsdoc["Format"].AsString;

                if (bsdoc.Contains("Frequency") && bsdoc["Frequency"] != BsonNull.Value)
                    seriesSearchResultItem.Frequency = bsdoc["Frequency"].AsString;

                if (bsdoc.Contains("AreasOfInterest") && bsdoc["AreasOfInterest"] != BsonNull.Value)
                    seriesSearchResultItem.AreasOfInterest = BsonSerializer.Deserialize<List<string>>(bsdoc["AreasOfInterest"].ToJson());

                if (bsdoc.Contains("Audience") && bsdoc["Audience"] != BsonNull.Value)
                    seriesSearchResultItem.Audience = bsdoc["Audience"].AsString;

                if (bsdoc.Contains("Annotations") && bsdoc["Annotations"] != BsonNull.Value)
                    seriesSearchResultItem.Annotations = bsdoc["Annotations"].AsString;

                if (bsdoc.Contains("Author") && bsdoc["Author"] != BsonNull.Value)
                    seriesSearchResultItem.Author = bsdoc["Author"].AsString;

                if (bsdoc.Contains("RelatedSeriesIDs") && bsdoc["RelatedSeriesIDs"] != BsonNull.Value)
                    seriesSearchResultItem.RelatedSeriesIDs = BsonSerializer.Deserialize<List<string>>(bsdoc["RelatedSeriesIDs"].ToJson());

                if (bsdoc.Contains("HasRelatedSeries") && bsdoc["HasRelatedSeries"] != BsonNull.Value)
                    seriesSearchResultItem.HasRelatedSeries = bsdoc["HasRelatedSeries"].AsBoolean;

                if (bsdoc.Contains("HasBindingPreferences") && bsdoc["HasBindingPreferences"] != BsonNull.Value)
                    seriesSearchResultItem.HasBindingPreferences = bsdoc["HasBindingPreferences"].AsBoolean;

                if (bsdoc.Contains("StartDataType") && bsdoc["StartDataType"] != BsonNull.Value)
                    seriesSearchResultItem.StartDataType = bsdoc["StartDataType"].AsString;

                if (bsdoc.Contains("Status") && bsdoc["Status"] != BsonNull.Value)
                    seriesSearchResultItem.Status = bsdoc["Status"].AsString;

                if (bsdoc.Contains("SeriesLists") && bsdoc["SeriesLists"] != BsonNull.Value)
                    seriesSearchResultItem.SeriesLists = BsonSerializer.Deserialize<List<string>>(bsdoc["SeriesLists"].ToJson());

                if (bsdoc.Contains("LoadDateTime") && bsdoc["LoadDateTime"] != BsonNull.Value)
                    seriesSearchResultItem.LoadDateTime = Convert.ToDateTime(bsdoc["LoadDateTime"].AsBsonDateTime);

                if (bsdoc.Contains("ISBNList") && bsdoc["ISBNList"] != BsonNull.Value)
                    seriesSearchResultItem.ISBNList = BsonSerializer.Deserialize<List<string>>(bsdoc["ISBNList"].ToJson());

                if (bsdoc.Contains("ISBN10List") && bsdoc["ISBN10List"] != BsonNull.Value)
                    seriesSearchResultItem.ISBN10List = BsonSerializer.Deserialize<List<string>>(bsdoc["ISBN10List"].ToJson());
                
                if (bsdoc.Contains("ProductType") && bsdoc["ProductType"] != BsonNull.Value)
                    seriesSearchResultItem.ProductType = BsonSerializer.Deserialize<List<string>>(bsdoc["ProductType"].ToJson()); 

                if (bsdoc.Contains("LatestIssueInformation") && bsdoc["LatestIssueInformation"] != BsonNull.Value)
                {
                    var latestIssueInformation = BsonSerializer.Deserialize<LatestIssueInformation>(bsdoc["LatestIssueInformation"].ToJson());

                    if (latestIssueInformation != null)
                    {
                        seriesSearchResultItem.BTKey = latestIssueInformation.BTKey;
                        seriesSearchResultItem.ISBN = latestIssueInformation.ISBN;
                        seriesSearchResultItem.ListPrice = latestIssueInformation.ListPrice;

                        if (latestIssueInformation.PublicationDate != DateTime.MinValue && latestIssueInformation.PublicationDate != null)
                        {
                            seriesSearchResultItem.PublicationDate = latestIssueInformation.PublicationDate;

                            seriesSearchResultItem.PublicationDateRange = DateRangeCalculations.CalculatePublicationDateRange(latestIssueInformation.PublicationDate.Value);
                        }

                        seriesSearchResultItem.Edition = latestIssueInformation.Edition;
                        seriesSearchResultItem.Title = latestIssueInformation.Title;
                        seriesSearchResultItem.LatestIssueAuthor = latestIssueInformation.Author;
                    }
                }

                if (bsdoc.Contains("FootprintInformation") && bsdoc["FootprintInformation"] != BsonNull.Value)
                {
                    var footprintInformation = BsonSerializer.Deserialize<FootprintInformation>(bsdoc["FootprintInformation"].ToJson());

                    if (footprintInformation != null)
                    {
                        seriesSearchResultItem.CreatedBy = footprintInformation.CreatedBy;
                        seriesSearchResultItem.UpdatedBy = footprintInformation.UpdatedBy;

                        if (footprintInformation.CreatedDate != DateTime.MinValue)
                            seriesSearchResultItem.CreatedDate = footprintInformation.CreatedDate;

                        if (footprintInformation.CreatedDate != DateTime.MinValue)
                            seriesSearchResultItem.UpdatedDate = footprintInformation.UpdatedDate;

                        seriesSearchResultItem.CreatedByUserID = footprintInformation.CreatedByUserID;
                        seriesSearchResultItem.UpdatedByUserID = footprintInformation.UpdatedByUserID;
                    }
                }

                if (bsdoc.Contains("BindingPreferences") && bsdoc["BindingPreferences"] != BsonNull.Value)
                {
                    var seriesBindingPreferencesList = BsonSerializer.Deserialize<List<BindingPreference>>(bsdoc["BindingPreferences"].ToJson());

                    if (seriesBindingPreferencesList != null)
                    {
                        int count = 0;
                        foreach (var seriesBindingPreference in seriesBindingPreferencesList)
                        {
                            count++;

                            if (count == 1) {
                            seriesSearchResultItem.BindingPreferenceLiteral1 = seriesBindingPreference.Literal;
                            seriesSearchResultItem.BindingPreferencePrimaryPreference1 = seriesBindingPreference.PrimaryPreference;
                            seriesSearchResultItem.BindingPreferenceSecondaryPreference1 = seriesBindingPreference.SecondaryPreference;
                            seriesSearchResultItem.BindingPreferenceHasMultiplePreference1 = seriesBindingPreference.HasMultiplePreference;
                            }

                            if (count == 2)
                            {
                                seriesSearchResultItem.BindingPreferenceLiteral2 = seriesBindingPreference.Literal;
                                seriesSearchResultItem.BindingPreferencePrimaryPreference2 = seriesBindingPreference.PrimaryPreference;
                                seriesSearchResultItem.BindingPreferenceSecondaryPreference2 = seriesBindingPreference.SecondaryPreference;
                                seriesSearchResultItem.BindingPreferenceHasMultiplePreference2 = seriesBindingPreference.HasMultiplePreference;
                            }

                            if (count == 3)
                            {
                                seriesSearchResultItem.BindingPreferenceLiteral3 = seriesBindingPreference.Literal;
                                seriesSearchResultItem.BindingPreferencePrimaryPreference3 = seriesBindingPreference.PrimaryPreference;
                                seriesSearchResultItem.BindingPreferenceSecondaryPreference3 = seriesBindingPreference.SecondaryPreference;
                                seriesSearchResultItem.BindingPreferenceHasMultiplePreference3 = seriesBindingPreference.HasMultiplePreference;
                            }

                            if (count == 4)
                            {
                                seriesSearchResultItem.BindingPreferenceLiteral4 = seriesBindingPreference.Literal;
                                seriesSearchResultItem.BindingPreferencePrimaryPreference4 = seriesBindingPreference.PrimaryPreference;
                                seriesSearchResultItem.BindingPreferenceSecondaryPreference4 = seriesBindingPreference.SecondaryPreference;
                                seriesSearchResultItem.BindingPreferenceHasMultiplePreference4 = seriesBindingPreference.HasMultiplePreference;
                            }
                        }
                    }
                }


                if (bsdoc.Contains("ContentListIDList") && bsdoc["ContentListIDList"] != BsonNull.Value)
                    seriesSearchResultItem.ContentListIDList = BsonSerializer.Deserialize<List<string>>(bsdoc["ContentListIDList"].ToJson());
                
                return seriesSearchResultItem;
            }
            catch (Exception ex)
            {
                var failedResult = azureSearchQueueIdList.Where(s => s.searchQueueObjectId.ToString() == seriesSearchResultItem.ObjectId).Select(x => x.searchQueueId).ToList();

                if (failedResult != null)
                    mongoDBHelper.UpdateSearchQueueInProcess(failedResult, (int)QueueProcessState.InProcess, (int)QueueProcessState.Failed);

                logMessage.AppendLine("Failure on BindSeriesSearchResult " + seriesSearchResultItem.ObjectId);


                return null;

            }
        }

      

        private SeriesSearchResultItem BindProfiledSeriesSearchResult(BsonDocument bsdoc, List<AzureSearchQueueIdItem> azureSearchQueueIdList,  List<SeriesSearchResultItem> seriesIDsList)
        {

            SeriesSearchResultItem seriesSearchResultItem = new SeriesSearchResultItem();

            try
            {

                if (bsdoc.Contains("SeriesID") && bsdoc["SeriesID"] != BsonNull.Value)
                {
                    var seriesID =  bsdoc["SeriesID"].AsString;
                    seriesSearchResultItem.ObjectId = seriesIDsList.Where(i => i.SeriesID == seriesID).Select(j => j.ObjectId).FirstOrDefault().ToString();
                }

                if (bsdoc.Contains("ProfileOrgInformation") && bsdoc["ProfileOrgInformation"] != BsonNull.Value)
                {
                    var profileOrgInformationList = BsonSerializer.Deserialize<List<ProfileOrgInformation>>(bsdoc["ProfileOrgInformation"].ToJson());

                    seriesSearchResultItem.ProfileOrgIDList = new List<string>();
                    seriesSearchResultItem.ProfileIDList = new List<string>();
                    //  seriesSearchResultItem.POQuantityList = new List<string>();
                    if (profileOrgInformationList != null)
                    {
                        foreach (var profileOrgInformation in profileOrgInformationList)
                        {

                            seriesSearchResultItem.ProfileOrgIDList.Add(profileOrgInformation.OrganizationID + "|" + profileOrgInformation.ProfileID + "|" + profileOrgInformation.RequestStatus + "|" + profileOrgInformation.ProfileName);
                            seriesSearchResultItem.ProfileIDList.Add(profileOrgInformation.ProfileID.ToString());


                        }
                    }
                }

                return seriesSearchResultItem;
            }
            catch (Exception ex)
            {
                var failedResult = azureSearchQueueIdList.Where(s => s.searchQueueObjectId.ToString() == seriesSearchResultItem.ObjectId).Select(x => x.searchQueueId).ToList();

                if (failedResult != null)
                    mongoDBHelper.UpdateSearchQueueInProcess(failedResult, (int)QueueProcessState.InProcess, (int)QueueProcessState.Failed);

                logMessage.AppendLine("Failure on BindSeriesSearchResult " + seriesSearchResultItem.ObjectId);

                return null;

            }
        }

    
    }
}
