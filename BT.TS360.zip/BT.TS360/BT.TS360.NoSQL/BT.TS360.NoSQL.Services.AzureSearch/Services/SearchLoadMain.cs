﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.Azure.Search;
using Microsoft.Spatial;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using BT.TS360.NoSQL.Services.AzureSearch.Helper;


namespace BT.TS360.NoSQL.Services.AzureSearch.Services
{
    class SearchLoadMain
    {

        public async Task OnLoad()
        {

            ProfilesSearchLoad profilesSearchLoad = new ProfilesSearchLoad();
            Task t1 = profilesSearchLoad.Main();

            //await Task.Delay(250);

            ProfiledSeriesSearchLoad profiledSeriesSearchLoad = new ProfiledSeriesSearchLoad();
            Task t2 = profiledSeriesSearchLoad.Main();

            //await Task.Delay(250);

            SeriesSearchLoad seriesSearchLoad = new SeriesSearchLoad();
            Task t3 = seriesSearchLoad.Main();

           // await Task.Delay(250);

            await Task.WhenAll(t1, t2, t3);


            if (AppSettings.EnableSearchQueueDeletions)
            {
                MongoDBHelper mongoDBHelper = new MongoDBHelper();
                await mongoDBHelper.DeleteFromSearchQueue();
            }

        }

    }

}
