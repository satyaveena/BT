﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using Microsoft.Spatial;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using BT.TS360.NoSQL.Services.AzureSearch;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Services.AzureSearch.Helper;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Services.AzureSearch.Constants;
using BT.TS360.NoSQL.Services.AzureSearch.Models;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Services.DateRangeCalculator.Helper;

namespace BT.TS360.NoSQL.Services.AzureSearch.Services
{
    class ProfilesSearchLoad
    {

        static bool runAsRealTime = AppSettings.RunServiceAsRealTime;
        static ThreadedLogger _threadedLogger;
      
        static string profilesIndexName = AppSettings.ProfilesIndexName;

        IndexHelper indexHelper = new IndexHelper();
        MongoDBHelper mongoDBHelper = new MongoDBHelper();
    

        StringBuilder logMessage = new StringBuilder();

        public async Task Main()
        {
            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix, AppSettings.LogFolderErrors);

   

            if (AppSettings.EnableCreateProfilesIndex && AppSettings.ServiceRunType == "Index")
            {
                await CreateIndex();
                _threadedLogger.Write("Index Created", FileLoggingLevel.INFO, profilesIndexName);
                return;
            }

            if (AppSettings.EnableProfilesDataLoad && AppSettings.ServiceRunType == "Crawler")
            {
                await SyncIndexData();
                if (logMessage.Length > 0)
                    _threadedLogger.Write(logMessage.ToString(), FileLoggingLevel.INFO, profilesIndexName);

                return;
            }
        }



        private async Task CreateIndex()
        {
            try
            {
                var definition = indexHelper.GetProfilesIndex();
                await indexHelper.CreateIndexes(definition, profilesIndexName);
            }

            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, profilesIndexName);
            }
        }


        private async Task SyncIndexData()
        {
            //Documents to be Updated or Inserted into Azure Search 
            await UpdateIndexData();

            //Documents to be removed from Azure Search
            await DeleteIndexData();

        }

        private async Task UpdateIndexData()
        {
            try
            {
                //Get ids from SearchQueue
                var azureSearchQueueItem = await mongoDBHelper.GetQueueIds(AppSettings.ProfilesCollectionName, AppSettings.ChangeTypeMergeAction, AppSettings.ProfilesLoadBatchSize, logMessage);

                if (azureSearchQueueItem != null && azureSearchQueueItem.AzureSearchQueueIdList != null && azureSearchQueueItem.AzureSearchQueueIdList.Any())
                {
                    var searchQueueIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueId).ToList();
                    var searchQueueObjectIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueObjectId).ToList();
                    //set Queue items as InProcess
                    await mongoDBHelper.UpdateSearchQueueInProcess(searchQueueIdList, (int)QueueProcessState.New, (int)QueueProcessState.InProcess);

                    //Get Mongo docs from list of ids
                    var actions = new List<IndexAction<ProfilesSearchResultItem>>();
                    var profilesDocumentList = new List<BsonDocument>();

                    profilesDocumentList = await mongoDBHelper.GetProfilesDataForSearchLoad(AppSettings.ProfilesObjectIdName, searchQueueObjectIdList, searchQueueIdList);


                    List<ProfilesSearchResultItem> profilesSearchItemList = new List<ProfilesSearchResultItem>();

                    foreach (var bsdoc in profilesDocumentList)
                    {
                        ProfilesSearchResultItem profilesSearchResultItem = BindProfilesSearchResult(bsdoc, azureSearchQueueItem.AzureSearchQueueIdList);
                        profilesSearchItemList.Add(profilesSearchResultItem);
                        actions.Add(IndexAction.MergeOrUpload<ProfilesSearchResultItem>(profilesSearchResultItem));
                    }

                    if (!runAsRealTime)
                    {
                        var profiledSeriesDocumentList = new List<BsonDocument>();

                        profiledSeriesDocumentList = await mongoDBHelper.GetProfiledSeriesDataForProfilesLoad("ProfileID", searchQueueObjectIdList, searchQueueIdList, logMessage);
                        List<ProfilesSearchResultItem> profiledSeriesSearchItemList = new List<ProfilesSearchResultItem>();
                        foreach (var bsdoc in profiledSeriesDocumentList)
                        {
                            ProfilesSearchResultItem profiledSeriesSearchResultItem = BindProfiledSeriesSearchResult(bsdoc, azureSearchQueueItem.AzureSearchQueueIdList);
                            profiledSeriesSearchItemList.Add(profiledSeriesSearchResultItem);
                            actions.Add(IndexAction.MergeOrUpload<ProfilesSearchResultItem>(profiledSeriesSearchResultItem));
                        }

                    }

                    var batch = IndexBatch.New(actions);
                    //Load Data into Azure
                    await indexHelper.UploadDocuments(profilesIndexName, batch, azureSearchQueueItem.AzureSearchQueueIdList, logMessage);
                    //set lastcrawl date
                    await mongoDBHelper.UpdateSearchQueueLastCrawlDate(searchQueueIdList);
                }
            }
            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, profilesIndexName);

            }

        }
    

        private IndexAction<ProfilesSearchResultItem> GetProfilesIndexAction(ProfilesSearchResultItem profilesSearchResultItem)
        {
            return runAsRealTime ? IndexAction.MergeOrUpload<ProfilesSearchResultItem>(profilesSearchResultItem) : IndexAction.Upload<ProfilesSearchResultItem>(profilesSearchResultItem);
        }

        private async Task DeleteIndexData()
        {
            try
            {
                //Get ids from SearchQueue
                var azureSearchQueueItem = await mongoDBHelper.GetQueueIds(AppSettings.ProfilesCollectionName, AppSettings.ChangeTypeDeleteAction, AppSettings.ProfilesLoadBatchSize, logMessage);

                if (azureSearchQueueItem != null && azureSearchQueueItem.AzureSearchQueueIdList != null && azureSearchQueueItem.AzureSearchQueueIdList.Any())
                {

                    var searchQueueIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueId).ToList();
                    var searchQueueObjectIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueObjectId).ToList();
                    //set Queue items as InProcess
                    await mongoDBHelper.UpdateSearchQueueInProcess(searchQueueIdList, (int)QueueProcessState.New, (int)QueueProcessState.InProcess);

                    //Create IndexAction Items
                    var actions = new List<IndexAction<ProfilesSearchResultItem>>();
                    foreach (var i in searchQueueObjectIdList)
                    {
                        ProfilesSearchResultItem profilesSearchResultItem = new ProfilesSearchResultItem();
                        profilesSearchResultItem.ObjectId = i.ToString();
                        actions.Add(IndexAction.Delete<ProfilesSearchResultItem>(profilesSearchResultItem));
                    }

                    var batch = IndexBatch.New(actions);

                    //Load Data into Azure
                    await indexHelper.UploadDocuments(profilesIndexName, batch, azureSearchQueueItem.AzureSearchQueueIdList, logMessage);

                    //set lastcrawl date
                    await mongoDBHelper.UpdateSearchQueueLastCrawlDate(searchQueueIdList);

                }
            }
            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, profilesIndexName);
            }
        }



        private ProfilesSearchResultItem BindProfilesSearchResult(BsonDocument bsdoc, List<AzureSearchQueueIdItem> azureSearchQueueIdList)
        {

            ProfilesSearchResultItem profilesSearchResultItem = new ProfilesSearchResultItem();
            try
            {
                if (bsdoc.Contains("_id"))
                    profilesSearchResultItem.ObjectId = bsdoc["_id"].AsObjectId.ToString();

                if (bsdoc.Contains("OrganizationID") && bsdoc["OrganizationID"] != BsonNull.Value) { 
                    profilesSearchResultItem.OrganizationID = bsdoc["OrganizationID"].AsString;
                }
                else
                {
                    profilesSearchResultItem.OrganizationID = string.Empty;
                }
                
                if (bsdoc.Contains("UserName") && bsdoc["UserName"] != BsonNull.Value)
                    profilesSearchResultItem.UserName = bsdoc["UserName"].AsString;

                if (bsdoc.Contains("Name") && bsdoc["Name"] != BsonNull.Value)
                {
                    profilesSearchResultItem.Name = bsdoc["Name"].AsString;
                    profilesSearchResultItem.NameNoPunctuation = CommonHelper.RemoveSpecialCharacters(bsdoc["Name"].AsString);
                    
                }

                if (bsdoc.Contains("CompassAccountNumber") && bsdoc["CompassAccountNumber"] != BsonNull.Value)
                    profilesSearchResultItem.CompassAccountNumber = bsdoc["CompassAccountNumber"].AsString;

                if (bsdoc.Contains("ShippingAccountID") && bsdoc["ShippingAccountID"] != BsonNull.Value)
                    profilesSearchResultItem.ShippingAccountID = bsdoc["ShippingAccountID"].AsString;

                if (bsdoc.Contains("ShippingAccountNumber") && bsdoc["ShippingAccountNumber"] != BsonNull.Value)
                    profilesSearchResultItem.ShippingAccountNumber = bsdoc["ShippingAccountNumber"].AsString;

                if (bsdoc.Contains("BillingAccountNumber") && bsdoc["BillingAccountNumber"] != BsonNull.Value)
                    profilesSearchResultItem.BillingAccountNumber = bsdoc["BillingAccountNumber"].AsString;

                if (bsdoc.Contains("SAN") && bsdoc["SAN"] != BsonNull.Value)
                    profilesSearchResultItem.SAN = bsdoc["SAN"].AsString;

                if (bsdoc.Contains("AccountType") && bsdoc["AccountType"] != BsonNull.Value)
                    profilesSearchResultItem.AccountType = bsdoc["AccountType"].AsString;

                if (bsdoc.Contains("ProfileType") && bsdoc["ProfileType"] != BsonNull.Value)
                    profilesSearchResultItem.ProfileType = bsdoc["ProfileType"].AsString;

                if (bsdoc.Contains("Notes") && bsdoc["Notes"] != BsonNull.Value)
                    profilesSearchResultItem.Notes = bsdoc["Notes"].AsString;

                if (bsdoc.Contains("RequestStatus") && bsdoc["RequestStatus"] != BsonNull.Value)
                {
                    profilesSearchResultItem.RequestStatus = bsdoc["RequestStatus"].AsString;
                }
                else
                {
                    profilesSearchResultItem.RequestStatus = string.Empty;
                }


                if (bsdoc.Contains("RequestType") && bsdoc["RequestType"] != BsonNull.Value)
                {
                    profilesSearchResultItem.RequestType = bsdoc["RequestType"].AsString;
                }
                else
                {
                    profilesSearchResultItem.RequestType = string.Empty;
                }



                if (bsdoc.Contains("Status") && bsdoc["Status"] != BsonNull.Value)
                    profilesSearchResultItem.Status = bsdoc["Status"].AsString;

                if (bsdoc.Contains("SalesTerritory") && bsdoc["SalesTerritory"] != BsonNull.Value)
                    profilesSearchResultItem.SalesTerritory = bsdoc["SalesTerritory"].AsString;

                if (bsdoc.Contains("AreasOfInterest") && bsdoc["AreasOfInterest"] != BsonNull.Value)
                    profilesSearchResultItem.AreasOfInterest = BsonSerializer.Deserialize<List<string>>(bsdoc["AreasOfInterest"].ToJson());

                if (bsdoc.Contains("Programs") && bsdoc["Programs"] != BsonNull.Value)
                {
                    profilesSearchResultItem.Programs = BsonSerializer.Deserialize<List<string>>(bsdoc["Programs"].ToJson());
                    profilesSearchResultItem.Programs.Sort();
                    profilesSearchResultItem.ProgramsForSort = string.Join(",", profilesSearchResultItem.Programs);
                }

                if (bsdoc.Contains("NotificationUsers") && bsdoc["NotificationUsers"] != BsonNull.Value)
                    profilesSearchResultItem.NotificationUsers = BsonSerializer.Deserialize<List<string>>(bsdoc["NotificationUsers"].ToJson());



                if (bsdoc.Contains("SummaryInformation") && bsdoc["SummaryInformation"] != BsonNull.Value)
                {
                    var summaryInformation = BsonSerializer.Deserialize<SummaryInformation>(bsdoc["SummaryInformation"].ToJson());

                    if (summaryInformation != null)
                    {
                        profilesSearchResultItem.TotalCopies = summaryInformation.TotalCopies ?? 0;
                        profilesSearchResultItem.TotalSeries = summaryInformation.TotalSeries ?? 0;
                    }
                }

                if (bsdoc.Contains("ContactInformation") && bsdoc["ContactInformation"] != BsonNull.Value)
                {
                    var contactInformation = BsonSerializer.Deserialize<ContactInformation>(bsdoc["ContactInformation"].ToJson());

                    if (contactInformation != null)
                    {
                        profilesSearchResultItem.PrimaryContact = contactInformation.PrimaryContact;
                        profilesSearchResultItem.Phone = contactInformation.Phone;
                        profilesSearchResultItem.Fax = contactInformation.Fax;
                        profilesSearchResultItem.eMail = contactInformation.eMail;
                    }
                }

                if (bsdoc.Contains("AddressInformation") && bsdoc["AddressInformation"] != BsonNull.Value)
                {
                    var addressInformation = BsonSerializer.Deserialize<AddressInformation>(bsdoc["AddressInformation"].ToJson());

                    if (addressInformation != null)
                    {
                        profilesSearchResultItem.Line1 = addressInformation.Line1;
                        profilesSearchResultItem.Line2 = addressInformation.Line2;
                        profilesSearchResultItem.Line3 = addressInformation.Line3;
                        profilesSearchResultItem.City = addressInformation.City;
                        profilesSearchResultItem.State = addressInformation.State;
                        profilesSearchResultItem.Zipcode = addressInformation.Zipcode;
                    }
                }

                if (bsdoc.Contains("FootprintInformation") && bsdoc["FootprintInformation"] != BsonNull.Value)
                {
                    var footprintInformation = BsonSerializer.Deserialize<FootprintInformation>(bsdoc["FootprintInformation"].ToJson());

                    if (footprintInformation != null)
                    {
                        profilesSearchResultItem.CreatedBy = footprintInformation.CreatedBy;
                        profilesSearchResultItem.UpdatedBy = footprintInformation.UpdatedBy;
                        profilesSearchResultItem.CreatedByUserID = footprintInformation.CreatedByUserID;
                        profilesSearchResultItem.UpdatedByUserID = footprintInformation.UpdatedByUserID;

                        if (footprintInformation.CreatedDate != DateTime.MinValue)
                            profilesSearchResultItem.CreatedDate = footprintInformation.CreatedDate;
                        if (footprintInformation.UpdatedDate != DateTime.MinValue && footprintInformation.UpdatedDate != null)
                        {
                            profilesSearchResultItem.UpdatedDate = footprintInformation.UpdatedDate;

                            profilesSearchResultItem.UpdatedDateRange = DateRangeCalculations.CalculateUpdatedDateRange(footprintInformation.UpdatedDate);
                        }
                    }
                }

               
                return profilesSearchResultItem;
            }
            catch (Exception ex)
            {
                var failedResult = azureSearchQueueIdList.Where(s => s.searchQueueObjectId.ToString() == profilesSearchResultItem.ObjectId).Select(x => x.searchQueueId).ToList();

                if (failedResult != null)
                    mongoDBHelper.UpdateSearchQueueInProcess(failedResult, (int)QueueProcessState.InProcess, (int)QueueProcessState.Failed);

                logMessage.AppendLine("Failure on BindProfilesSearchResult " + profilesSearchResultItem.ObjectId);
               

                return null;

            }


        }



        private ProfilesSearchResultItem BindProfiledSeriesSearchResult(BsonDocument bsdoc, List<AzureSearchQueueIdItem> azureSearchQueueIdList)
        {

            ProfilesSearchResultItem profilesSearchResultItem = new ProfilesSearchResultItem();
            try
            {
  

             
                 if (bsdoc.Contains("ProfileID") && bsdoc["ProfileID"] != BsonNull.Value)
                     profilesSearchResultItem.ObjectId = bsdoc["_id"].AsObjectId.ToString();

                 if (bsdoc.Contains("SeriesIDList") && bsdoc["SeriesIDList"] != BsonNull.Value)
                     profilesSearchResultItem.SeriesIDList = BsonSerializer.Deserialize<List<string>>(bsdoc["SeriesIDList"].ToJson());

                 if (bsdoc.Contains("SeriesNameList") && bsdoc["SeriesNameList"] != BsonNull.Value)
                 {
                     profilesSearchResultItem.SeriesNameList = new List<string>();
                     var seriesNameList = BsonSerializer.Deserialize<List<string>>(bsdoc["SeriesNameList"].ToJson());

                     if (seriesNameList != null)
                     {
                         foreach (var seriesName in seriesNameList)
                         {
                             profilesSearchResultItem.SeriesNameList.Add(CommonHelper.RemoveSpecialCharacters(seriesName));
                         }
                     }
                 }
                
                 if (bsdoc.Contains("PONumberList") && bsdoc["PONumberList"] != BsonNull.Value)
                 {
                     profilesSearchResultItem.PONumberList = new List<string>();
                     List<string> poNumberList = new List<string>();
                     if (bsdoc.Contains("PONumberList") && bsdoc["PONumberList"] != BsonNull.Value)
                     {
                         var POList = BsonSerializer.Deserialize<List<List<string>>>(bsdoc["PONumberList"].ToJson());

                         if (POList != null)
                         {
                             foreach (var po in POList)
                             {
                                 poNumberList.AddRange(po.Select(x => x.Trim()).ToList());
                             }
                         }
                     }
                     profilesSearchResultItem.PONumberList.AddRange(poNumberList.Distinct());
                     profilesSearchResultItem.PONumberList.Sort();
                 }
            

                return profilesSearchResultItem;
            }
            catch (Exception ex)
            {
                var failedResult = azureSearchQueueIdList.Where(s => s.searchQueueObjectId.ToString() == profilesSearchResultItem.ObjectId).Select(x => x.searchQueueId).ToList();

                if (failedResult != null)
                    mongoDBHelper.UpdateSearchQueueInProcess(failedResult, (int)QueueProcessState.InProcess, (int)QueueProcessState.Failed);

                logMessage.AppendLine("Failure on BindProfilesSearchResult " + profilesSearchResultItem.ObjectId);
              

                return null;

            }


        }



    }
}
