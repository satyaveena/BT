﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
//using Microsoft.Spatial;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using BT.TS360.NoSQL.Services.AzureSearch;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Services.AzureSearch.Helper;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Services.AzureSearch.Constants;
using BT.TS360.NoSQL.Services.AzureSearch.Models;
using BTNextGen.Elmah;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Collections.Concurrent;

namespace BT.TS360.NoSQL.Services.AzureSearch.Services
{
    class ProfiledSeriesSearchLoad
    {
        ThreadedLogger _threadedLogger;


        static string profiledSeriesIndexName = AppSettings.ProfiledSeriesIndexName;

        IndexHelper indexHelper = new IndexHelper();
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        StringBuilder logMessage = new StringBuilder();

        public async Task Main()
        {

            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix, AppSettings.LogFolderErrors);

            if (AppSettings.EnableCreateProfiledSeriesIndex && AppSettings.ServiceRunType == "Index")
            {
                await CreateIndex();
                _threadedLogger.Write("Index Created", FileLoggingLevel.INFO, profiledSeriesIndexName);
                return;
            }

            if (AppSettings.EnableProfiledSeriesDataLoad && AppSettings.ServiceRunType == "Crawler")
            {
                await SyncIndexData();
                if (logMessage.Length > 0)
                    _threadedLogger.Write(logMessage.ToString(), FileLoggingLevel.INFO, profiledSeriesIndexName);

                return;
            }
        }


        private async Task CreateIndex()
        {
            try
            {
                var definition = indexHelper.GetProfiledSeriesIndex();
                await indexHelper.CreateIndexes(definition, profiledSeriesIndexName);
            }

            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, profiledSeriesIndexName);
            }
        }


        private async Task SyncIndexData()
        {

            //Documents to be Updated or Inserted into Azure Search 
            await UpdateIndexData();

            //Documents to be removed from Azure Search
            await DeleteIndexData();

        }


        private async Task UpdateIndexData()
        {
            try
            {
                //Get ids from SearchQueue
                var azureSearchQueueItem = await mongoDBHelper.GetQueueIds(AppSettings.ProfiledSeriesCollectionName, AppSettings.ChangeTypeMergeAction, AppSettings.ProfiledSeriesLoadBatchSize, logMessage);

                if (azureSearchQueueItem != null && azureSearchQueueItem.AzureSearchQueueIdList != null && azureSearchQueueItem.AzureSearchQueueIdList.Any())
                {
                    var searchQueueIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueId).ToList();
                    var searchQueueObjectIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueObjectId).ToList();

                    //set Queue items as InProcess
                    await mongoDBHelper.UpdateSearchQueueInProcess(searchQueueIdList, (int)QueueProcessState.New, (int)QueueProcessState.InProcess);

                    //Get Mongo data from list of ids
                    var actions = new List<IndexAction<ProfiledSeriesSearchResultItem>>();

                    var profiledSeriesSearchItemDocumentList = await mongoDBHelper.GetProfiledSeriesDataForSearchLoad(AppSettings.ProfiledSeriesObjectIdName, searchQueueObjectIdList, searchQueueIdList);
                    foreach (var bsdoc in profiledSeriesSearchItemDocumentList)
                    {
                        ProfiledSeriesSearchResultItem profiledSeriesSearchResultItem = BindProfiledSeriesSearchResult(bsdoc, azureSearchQueueItem.AzureSearchQueueIdList);
                        //Create IndexAction Items
                        if (profiledSeriesSearchResultItem != null)
                            actions.Add(IndexAction.Upload<ProfiledSeriesSearchResultItem>(profiledSeriesSearchResultItem));
                    }

                    var batch = IndexBatch.New(actions);

                    //Load Data into Azure
                    await indexHelper.UploadDocuments(profiledSeriesIndexName, batch, azureSearchQueueItem.AzureSearchQueueIdList, logMessage);

                    //set lastcrawl date
                    await mongoDBHelper.UpdateSearchQueueLastCrawlDate(searchQueueIdList);

                }
            }
            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, profiledSeriesIndexName);
            }
        }


        private async Task DeleteIndexData()
        {
            try
            {

                //Get ids from SearchQueue
                var azureSearchQueueItem = await mongoDBHelper.GetQueueIds(AppSettings.ProfiledSeriesCollectionName, AppSettings.ChangeTypeDeleteAction, AppSettings.ProfiledSeriesLoadBatchSize, logMessage);

                if (azureSearchQueueItem != null && azureSearchQueueItem.AzureSearchQueueIdList != null && azureSearchQueueItem.AzureSearchQueueIdList.Any())
                {
                    var searchQueueIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueId).ToList();
                    var searchQueueObjectIdList = azureSearchQueueItem.AzureSearchQueueIdList.Select(x => x.searchQueueObjectId).ToList();

                    //set Queue items as InProcess
                    await mongoDBHelper.UpdateSearchQueueInProcess(searchQueueIdList, (int)QueueProcessState.New, (int)QueueProcessState.InProcess);

                    //Create IndexAction Items
                    var actions = new List<IndexAction<ProfiledSeriesSearchResultItem>>();
                    foreach (var i in searchQueueObjectIdList)
                    {
                        ProfiledSeriesSearchResultItem profiledSeriesSearchResultItem = new ProfiledSeriesSearchResultItem();
                        profiledSeriesSearchResultItem.ObjectId = i.ToString();
                        //Create IndexAction Items
                        actions.Add(IndexAction.Delete<ProfiledSeriesSearchResultItem>(profiledSeriesSearchResultItem));
                    }

                    var batch = IndexBatch.New(actions);

                    //Load Data into Azure
                    await indexHelper.UploadDocuments(profiledSeriesIndexName, batch, azureSearchQueueItem.AzureSearchQueueIdList, logMessage);

                    //set lastcrawl date
                    await mongoDBHelper.UpdateSearchQueueLastCrawlDate(searchQueueIdList);
                }
            }
            catch (Exception ex)
            {
                _threadedLogger.Write(ex.Message, FileLoggingLevel.ERROR, profiledSeriesIndexName);
            }
        }



        private ProfiledSeriesSearchResultItem BindProfiledSeriesSearchResult(BsonDocument bsdoc, List<AzureSearchQueueIdItem> azureSearchQueueIdList)
        {

            ProfiledSeriesSearchResultItem profiledSeriesSearchResultItem = new ProfiledSeriesSearchResultItem();
            try
            {
                if (bsdoc.Contains("_id"))
                    profiledSeriesSearchResultItem.ObjectId = bsdoc["_id"].AsObjectId.ToString();

                if (bsdoc.Contains("ProfileID") && bsdoc["ProfileID"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.ProfileID = bsdoc["ProfileID"].AsObjectId.ToString();

                if (bsdoc.Contains("SeriesID") && bsdoc["SeriesID"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.SeriesID = bsdoc["SeriesID"].AsString;

                if (bsdoc.Contains("Note") && bsdoc["Note"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.Note = bsdoc["Note"].AsString;

                if (bsdoc.Contains("RequestStatus") && bsdoc["RequestStatus"] != BsonNull.Value)
                {
                    profiledSeriesSearchResultItem.RequestStatus = bsdoc["RequestStatus"].ToString();
                }
                //else
                //{
                //    profiledSeriesSearchResultItem.RequestStatus = string.Empty;
                //}

                if (!string.IsNullOrEmpty(profiledSeriesSearchResultItem.RequestStatus))
                {
                    profiledSeriesSearchResultItem.RequestType = "Pending Modification";
                }
                //else
                //{
                //    profiledSeriesSearchResultItem.RequestType = string.Empty;
                //}

                if (bsdoc.Contains("ChangeRequestUserID") && bsdoc["ChangeRequestUserID"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.ChangeRequestUserID = bsdoc["ChangeRequestUserID"].AsString;

                if (bsdoc.Contains("TotalPrimaryQuantity") && bsdoc["TotalPrimaryQuantity"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.TotalPrimaryQuantity = Convert.ToInt32(bsdoc["TotalPrimaryQuantity"]);

                if (bsdoc.Contains("LoadDateTime") && bsdoc["LoadDateTime"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.LoadDateTime = Convert.ToDateTime(bsdoc["LoadDateTime"].AsBsonDateTime);

                if (bsdoc.Contains("FootprintInformation") && bsdoc["FootprintInformation"] != BsonNull.Value)
                {
                    var footprintInformation = BsonSerializer.Deserialize<FootprintInformation>(bsdoc["FootprintInformation"].ToJson());

                    if (footprintInformation != null)
                    {
                        profiledSeriesSearchResultItem.CreatedBy = footprintInformation.CreatedBy;
                        profiledSeriesSearchResultItem.UpdatedBy = footprintInformation.UpdatedBy;

                        if (footprintInformation.CreatedDate != DateTime.MinValue)
                            profiledSeriesSearchResultItem.CreatedDate = footprintInformation.CreatedDate;

                        if (footprintInformation.UpdatedDate != DateTime.MinValue)
                            profiledSeriesSearchResultItem.UpdatedDate = footprintInformation.UpdatedDate;

                        profiledSeriesSearchResultItem.CreatedByUserID = footprintInformation.CreatedByUserID;
                        profiledSeriesSearchResultItem.UpdatedByUserID = footprintInformation.UpdatedByUserID;
                    }
                }

                if (bsdoc.Contains("RedundantSeriesInformation") && bsdoc["RedundantSeriesInformation"] != BsonNull.Value)
                {
                    var redundantSeriesInformation = BsonSerializer.Deserialize<RedundantSeriesData>(bsdoc["RedundantSeriesInformation"].ToJson());

                    if (redundantSeriesInformation != null)
                    {
                        profiledSeriesSearchResultItem.SeriesName = redundantSeriesInformation.Name;
                        profiledSeriesSearchResultItem.SeriesNameNoPunctuation = CommonHelper.RemoveSpecialCharacters(redundantSeriesInformation.Name);
                        profiledSeriesSearchResultItem.AuthorNoPunctuation = CommonHelper.RemoveSpecialCharacters(redundantSeriesInformation.Author);   
                        profiledSeriesSearchResultItem.Author = redundantSeriesInformation.Author;
                        profiledSeriesSearchResultItem.Format = redundantSeriesInformation.Format;
                        profiledSeriesSearchResultItem.Audience = redundantSeriesInformation.Audience;
                        profiledSeriesSearchResultItem.Publisher = redundantSeriesInformation.Publisher;
                        profiledSeriesSearchResultItem.Distributor = redundantSeriesInformation.Distributor;
                        profiledSeriesSearchResultItem.Frequency = redundantSeriesInformation.Frequency;
                        profiledSeriesSearchResultItem.HasRelatedSeries = redundantSeriesInformation.HasRelatedSeries;
                        profiledSeriesSearchResultItem.RelatedSeriesIDs = redundantSeriesInformation.RelatedSeriesIDs;
                        profiledSeriesSearchResultItem.HasBindingPreferences = redundantSeriesInformation.HasBindingPreferences;
                        profiledSeriesSearchResultItem.AreasOfInterest = redundantSeriesInformation.AreasOfInterest;

                        profiledSeriesSearchResultItem.SeriesPrograms = redundantSeriesInformation.Programs;
                        if (redundantSeriesInformation.Programs != null)
                        {
                            profiledSeriesSearchResultItem.SeriesPrograms.Sort();
                            profiledSeriesSearchResultItem.SeriesProgramsForSort = string.Join(",", profiledSeriesSearchResultItem.SeriesPrograms);
                        }

                        profiledSeriesSearchResultItem.SeriesRequestStatus = redundantSeriesInformation.RequestStatus;
                        profiledSeriesSearchResultItem.SeriesStatus = redundantSeriesInformation.Status;
                        if (redundantSeriesInformation.LatestIssueInformation != null)
                        {
                            profiledSeriesSearchResultItem.BTKey = redundantSeriesInformation.LatestIssueInformation.BTKey;
                            profiledSeriesSearchResultItem.ISBN = redundantSeriesInformation.LatestIssueInformation.ISBN;
                            if (redundantSeriesInformation.LatestIssueInformation.ListPrice != null && redundantSeriesInformation.LatestIssueInformation.ListPrice.HasValue)
                                profiledSeriesSearchResultItem.ListPrice = redundantSeriesInformation.LatestIssueInformation.ListPrice.Value.ToString("N");
                            
                            if (redundantSeriesInformation.LatestIssueInformation.PublicationDate != DateTime.MinValue)
                                profiledSeriesSearchResultItem.PublicationDate = redundantSeriesInformation.LatestIssueInformation.PublicationDate.ToString(); //change

                            profiledSeriesSearchResultItem.Edition = redundantSeriesInformation.LatestIssueInformation.Edition;
                            profiledSeriesSearchResultItem.Title = redundantSeriesInformation.LatestIssueInformation.Title;
                            profiledSeriesSearchResultItem.LatestIssueAuthor = redundantSeriesInformation.LatestIssueInformation.Author;
                        }


                        if (redundantSeriesInformation.BindingPreferences != null)
                        {

                            int count = 0;
                            foreach (var seriesBindingPreference in redundantSeriesInformation.BindingPreferences)
                            {
                                count++;

                                if (count == 1)
                                {
                                    profiledSeriesSearchResultItem.BindingPreferenceLiteral1 = seriesBindingPreference.Literal;
                                    profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference1 = seriesBindingPreference.PrimaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference1 = seriesBindingPreference.SecondaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference1 = seriesBindingPreference.HasMultiplePreference;
                                }

                                if (count == 2)
                                {
                                    profiledSeriesSearchResultItem.BindingPreferenceLiteral2 = seriesBindingPreference.Literal;
                                    profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference2 = seriesBindingPreference.PrimaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference2 = seriesBindingPreference.SecondaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference2 = seriesBindingPreference.HasMultiplePreference;
                                }

                                if (count == 3)
                                {
                                    profiledSeriesSearchResultItem.BindingPreferenceLiteral3 = seriesBindingPreference.Literal;
                                    profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference3 = seriesBindingPreference.PrimaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference3 = seriesBindingPreference.SecondaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference3 = seriesBindingPreference.HasMultiplePreference;
                                }

                                if (count == 4)
                                {
                                    profiledSeriesSearchResultItem.BindingPreferenceLiteral4 = seriesBindingPreference.Literal;
                                    profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference4 = seriesBindingPreference.PrimaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference4 = seriesBindingPreference.SecondaryPreference;
                                    profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference4 = seriesBindingPreference.HasMultiplePreference;
                                }
                            }

                        }

                        if (redundantSeriesInformation.FootprintInformation != null)
                        {
                            profiledSeriesSearchResultItem.SeriesCreatedBy = redundantSeriesInformation.FootprintInformation.CreatedBy;
                            profiledSeriesSearchResultItem.SeriesUpdatedBy = redundantSeriesInformation.FootprintInformation.UpdatedBy;

                            if (redundantSeriesInformation.FootprintInformation.CreatedDate != DateTime.MinValue)
                                profiledSeriesSearchResultItem.SeriesCreatedDate = redundantSeriesInformation.FootprintInformation.CreatedDate;

                            if (redundantSeriesInformation.FootprintInformation.UpdatedDate != DateTime.MinValue)
                                profiledSeriesSearchResultItem.SeriesUpdatedDate = redundantSeriesInformation.FootprintInformation.UpdatedDate;

                            profiledSeriesSearchResultItem.SeriesCreatedByUserID = redundantSeriesInformation.FootprintInformation.CreatedByUserID;
                            profiledSeriesSearchResultItem.SeriesUpdatedByUserID = redundantSeriesInformation.FootprintInformation.UpdatedByUserID;

                        }


                    }
                }


                if (bsdoc.Contains("RedundantProfileInformation") && bsdoc["RedundantProfileInformation"] != BsonNull.Value)
                {
                    var redundantProfileInformation = BsonSerializer.Deserialize<RedundantProfileData>(bsdoc["RedundantProfileInformation"].ToJson());

                    if (redundantProfileInformation != null)
                    {
                        profiledSeriesSearchResultItem.CompassAccountNumber = redundantProfileInformation.CompassAccountNumber;
                        profiledSeriesSearchResultItem.ShippingAccountNumber = redundantProfileInformation.ShippingAccountNumber;
                        profiledSeriesSearchResultItem.ProfileName = redundantProfileInformation.Name;
                        profiledSeriesSearchResultItem.OrganizationID = redundantProfileInformation.OrganizationID;
                        profiledSeriesSearchResultItem.TotalSeries = redundantProfileInformation.TotalSeries ?? 0; ;
                        profiledSeriesSearchResultItem.TotalCopies = redundantProfileInformation.TotalCopies ?? 0; ;

                        profiledSeriesSearchResultItem.ProfileStatus = redundantProfileInformation.Status;
                        profiledSeriesSearchResultItem.ProfileType = redundantProfileInformation.ProfileType;
                        profiledSeriesSearchResultItem.ProfilePrograms = redundantProfileInformation.Programs;

                        profiledSeriesSearchResultItem.SalesTerritory = redundantProfileInformation.SalesTerritory;
                    }
                }

                if (bsdoc.Contains("PurchaseOrders") && bsdoc["PurchaseOrders"] != BsonNull.Value)
                {
                    List<string> poLineNumberList = new List<string>();
                    var purchaseOrders = BsonSerializer.Deserialize<List<PO>>(bsdoc["PurchaseOrders"].ToJson());
                    int poCount = 0;

                    if (purchaseOrders != null)
                    {
                        profiledSeriesSearchResultItem.POQuantityList = new List<string>();
                        profiledSeriesSearchResultItem.POLineNumberList = new List<string>();
                        foreach (var purchaseOrder in purchaseOrders)
                        {
                            poCount++;

                            profiledSeriesSearchResultItem.POQuantityList.Add(purchaseOrder.POLineNumber + '|' + purchaseOrder.FormatPreferencePrimaryQuantity);
                            poLineNumberList.Add(purchaseOrder.POLineNumber.Trim());
                            if (poCount == 1 && purchaseOrder.FormatPreferenceString != null)
                            {
                                profiledSeriesSearchResultItem.PO1FormatPreferenceLiteral = purchaseOrder.FormatPreferenceString;
                            }
                           
                        }
                        profiledSeriesSearchResultItem.POLineNumberList.AddRange(poLineNumberList.Distinct());

                        profiledSeriesSearchResultItem.POCount = poCount;
                    }
                  

                   
                }

                if (bsdoc.Contains("POCount") && bsdoc["POCount"] != BsonNull.Value)
                    profiledSeriesSearchResultItem.POCount = Convert.ToInt32(bsdoc["POCount"]);

                if (bsdoc.Contains("PO1FormatPreferenceLiteral ") && bsdoc["PO1FormatPreferenceLiteral "] != BsonNull.Value)
                    profiledSeriesSearchResultItem.PO1FormatPreferenceLiteral = Convert.ToString(bsdoc["PO1FormatPreferenceLiteral"]);

                return profiledSeriesSearchResultItem;

            }
            catch (Exception ex)
            {
                var failedResult = azureSearchQueueIdList.Where(s => s.searchQueueObjectId.ToString() == profiledSeriesSearchResultItem.ObjectId).Select(x => x.searchQueueId).ToList();

                if (failedResult != null)
                    mongoDBHelper.UpdateSearchQueueInProcess(failedResult, (int)QueueProcessState.InProcess, (int)QueueProcessState.Failed);

                logMessage.AppendLine("Failure on BindProfiledSeriesSearchResult " + profiledSeriesSearchResultItem.ObjectId);
               

                return null;
            }
        }


    }
}