﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BT.TS360.NoSQL.Services.AzureSearch
{
    public class AppSettings
    {

        #region ServiceSettings
        //values pertain to  how the service will running and it's timing interval

        public static int IntervalMilliseconds
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["Intervalms"]); }
        }

        public static string ServiceStartTime
        {
            get { return ConfigurationManager.AppSettings["ServiceStartTime"]; }
        }

        public static string ServiceEndTime
        {
            get { return ConfigurationManager.AppSettings["ServiceEndTime"]; }
        }

        //will the service run once to create index or on a timer to load data (ServiceRunType:Index//Crawler)
        public static string ServiceRunType
        {
            get { return ConfigurationManager.AppSettings["ServiceRunType"].ToString(); }
        }

        public static bool RunServiceAsRealTime
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["RunServiceAsRealTime"]); }
        }

        #endregion ServiceSettings

        #region AzureBatchSizes
        //values pertain to the number of documents queried from Mongo and uploaded into Azure Search, 1000 MAX (Azure limitation)

        public static int ProfilesLoadBatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["ProfilesLoadBatchSize"]); }
        }

        public static int SeriesLoadBatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["SeriesLoadBatchSize"]); }
        }

        public static int ProfiledSeriesLoadBatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["ProfiledSeriesLoadBatchSize"]); }
        }

        #endregion AzureBatchSizes

        #region LoggingSettings
        //values pertain to logging (3 types of logging: file, email and elmah)

        public static string CurrentEnvironment
        {
            get { return ConfigurationManager.AppSettings["CurrentEnvironment"].ToString(); }
        }

        public static string EmailTo
        {
            get { return ConfigurationManager.AppSettings["EmailTo"].ToString(); }
        }

        public static string EmailSMTPServer
        {
            get { return ConfigurationManager.AppSettings["EmailSMTPServer"].ToString(); }
        }


        public static string LogFolder
        {
            get { return ConfigurationManager.AppSettings["LogFolder"].ToString(); }
        }

        public static string LogFolderErrors
        {
            get { return ConfigurationManager.AppSettings["LogFolderErrors"].ToString(); }
        }

        public static string LogFilePrefix
        {
            get { return ConfigurationManager.AppSettings["LogFilePrefix"].ToString(); }
        }

        #endregion LoggingSettings

        #region AzureQueueSettings
        //values pertain to management and values in MongoDB Common.AzureSearchQueue

        public static bool EnableSearchQueueDeletions
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableSearchQueueDeletions"]); }
        }

        public static int SearchQueueDeleteTimeFrame
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["SearchQueueDeleteTimeFrame"]); }
        }

        public const string ChangeTypeMergeAction = "Upsert";
        public const string ChangeTypeDeleteAction = "Delete";

        #endregion AzureQueueSettings

        #region AzureSearchSettings
        //values pertain to management of Azure Search Portal settings including index names

        public static string SearchServiceName
        {
            get { return ConfigurationManager.AppSettings["SearchServiceName"].ToString(); }
        }

        public static string SearchServiceApiKey
        {
            get { return ConfigurationManager.AppSettings["SearchServiceApiKey"].ToString(); }
        }


        public static string ProfilesIndexName
        {
            get { return ConfigurationManager.AppSettings["ProfilesIndexName"].ToString(); }
        }

        public static string SeriesIndexName
        {
            get { return ConfigurationManager.AppSettings["SeriesIndexName"].ToString(); }
        }

        public static string ProfiledSeriesIndexName
        {
            get { return ConfigurationManager.AppSettings["ProfiledSeriesIndexName"].ToString(); }
        }

        public static int MaxAzureLoadRetries
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MaxAzureLoadRetries"]); }
        }

        public static int RetryAzureWaitTimeInterval
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RetryAzureWaitTimeInterval"]); }
        }

        #endregion AzureSearchSettings

        #region SearchTasksEnabled

        public static bool EnableCreateProfilesIndex
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableCreateProfilesIndex"]); }
        }

        public static bool EnableCreateSeriesIndex
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableCreateSeriesIndex"]); }
        }

        public static bool EnableCreateProfiledSeriesIndex
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableCreateProfiledSeriesIndex"]); }
        }

        public static bool EnableProfilesDataLoad
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableProfilesDataLoad"]); }
        }

        public static bool EnableSeriesDataLoad
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableSeriesDataLoad"]); }
        }

        public static bool EnableProfiledSeriesDataLoad
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableProfiledSeriesDataLoad"]); }
        }


        #endregion SearchTasks

        #region MongoSettings

        public static string MongoDBConnectionString
        {
            get { return ConfigurationManager.AppSettings["MongoDBConnectionString"].ToString(); }
        }

        public static int MaxConnectionRetries
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MaxConnectionRetries"]); }
        }

        public static int RetryWaitTime
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RetryWaitTime"]); }
        }

        public const string DatabaseNameTSSO = "StandingOrders";
        public const string ProfilesCollectionName = "Profiles";
        public const string SeriesCollectionName = "Series";
        public const string ProfiledSeriesCollectionName = "ProfiledSeries";

        public const string DatabaseNameCommon = "Common";
        public const string AzureSearchQueueCollectionName = "AzureSearchQueue";

        public const string ProfilesObjectIdName = "_id";
        public const string SeriesObjectIdName = "_id";
        public const string ProfiledSeriesObjectIdName = "_id";




        #endregion MongoSettings
    }
}
