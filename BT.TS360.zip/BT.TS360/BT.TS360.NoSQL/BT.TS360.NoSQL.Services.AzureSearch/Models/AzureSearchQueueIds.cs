﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace BT.TS360.NoSQL.Services.AzureSearch.Models
{
    class AzureSearchQueueIds
    {
        [BsonIgnoreIfNull]
        public List<AzureSearchQueueIdItem> AzureSearchQueueIdList { get; set; }

    }

    public class AzureSearchQueueIdItem
    {
        public ObjectId searchQueueObjectId { get; set; }
        public ObjectId searchQueueId { get; set; }
    }
    
}
