﻿
using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;


namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class SeriesProfileOrg
    {

        [BsonIgnoreIfNull]
        public List<ProfileOrgInformation> ProfileOrgInformation { get; set; }
       
    }

    [BsonIgnoreExtraElements]
    public class ProfileOrgInformation
    {
        [BsonIgnoreIfNull]
        public ObjectId ProfileID { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public string RequestStatus { get; set; }
        [BsonIgnoreIfNull]
        public string ProfileName { get; set; }

        [BsonIgnoreIfNull]
        public List<PurchaseOrder> PurchaseOrders { get; set; }
    }


    public class PurchaseOrder
    {
        [BsonIgnoreIfNull]
        public string POLineNumber { get; set; }
        
        [BsonIgnoreIfNull]
        public int FormatPreferencePrimaryQuantity { get; set; }

    }

}



