﻿using Microsoft.Azure.Search.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BT.TS360.NoSQL.Services.AzureSearch.Models
{
    class AzureIndex
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("fields")]
        public List<IndexField> IndexFields { get; set; }

        [JsonProperty("analyzers")]
        public List<IndexAnalyzer> IndexAnalyzers { get; set; }
    }


    public class IndexField
    {
        //public IndexField(string NameItem, DataType TypeItem, string AnalyzerItem, bool IsKeyItem, bool IsSearchableItem, bool IsFilterableItem, bool IsSortableItem, bool IsFacetableItem, bool IsRetrievableItem) {
        //    Name = NameItem;

        //}
        public IndexField(string NameItem, string TypeItem) {
            Name = NameItem;
            Type = TypeItem;
        }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("analyzer")]
        public string Analyzer { get; set; }

        [JsonProperty("key")]
        public bool IsKey { get; set; }

        [JsonProperty("searchable")]
        public bool IsSearchable { get; set; }

        [JsonProperty("filterable")]
        public bool IsFilterable { get; set; }

        [JsonProperty("sortable")]
        public bool IsSortable { get; set; }

        [JsonProperty("facetable")]
        public bool IsFacetable { get; set; }

        [JsonProperty("retrievable")]
        public bool IsRetrievable { get; set; }

    }


    public class IndexAnalyzer
    {
       
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("@odata.type")]
        public string Type { get; set; }

        [JsonProperty("tokenizer")]
        public string Tokenizer { get; set; }

        [JsonProperty("tokenFilters")]
        public string[] TokenFilters { get; set; }
    }

}
