﻿
using System.Configuration;

namespace BT.TS360.NoSQL.Services.AzureSearch
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.azureSearchProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.azureSearchInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // azureSearchProcessInstaller
            // 
            this.azureSearchProcessInstaller.Password = null;
            this.azureSearchProcessInstaller.Username = null;
            // 
            // azureSearchInstaller
            // 
            this.azureSearchInstaller.DisplayName = ServiceName;
            this.azureSearchInstaller.ServiceName = DisplayName;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.azureSearchProcessInstaller,
            this.azureSearchInstaller});
        }

        #endregion

        private string ServiceName
        {
            get
            {
                return (ConfigurationManager.AppSettings["ServiceName"] == null ? "AzureSearchCrawler" : ConfigurationManager.AppSettings["ServiceName"].ToString());
            }
        }

        private string DisplayName
        {
            get
            {
                return (ConfigurationManager.AppSettings["DisplayName"] == null ? "AzureSearchCrawler" : ConfigurationManager.AppSettings["DisplayName"].ToString());
            }
        }

        private System.ServiceProcess.ServiceProcessInstaller azureSearchProcessInstaller;
        private System.ServiceProcess.ServiceInstaller azureSearchInstaller;
    }
}