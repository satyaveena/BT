﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Services.AzureSearch.Constants;
using BT.TS360.NoSQL.Services.AzureSearch.Models;
using System.Threading;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.Services.AzureSearch.Helper
{
    class MongoDBHelper
    {
        IMongoClient _client;
        IMongoDatabase _databaseTSSO;
        IMongoDatabase _databaseCommon;

        IMongoCollection<BsonDocument> _series;
        IMongoCollection<BsonDocument> _profiledSeries;
        IMongoCollection<BsonDocument> _profiles;
        IMongoCollection<BsonDocument> _azureSearchQueue;

        int retryWaitTime = AppSettings.RetryWaitTime;

        static ThreadedLogger _threadedLogger;

        DateTime _today;

        public MongoDBHelper()
        {
            string connection = AppSettings.MongoDBConnectionString;
            _client = new MongoClient(connection);
            _databaseTSSO = _client.GetDatabase(AppSettings.DatabaseNameTSSO);
            _databaseCommon = _client.GetDatabase(AppSettings.DatabaseNameCommon);
            _profiles = _databaseTSSO.GetCollection<BsonDocument>(AppSettings.ProfilesCollectionName);
            _profiledSeries = _databaseTSSO.GetCollection<BsonDocument>(AppSettings.ProfiledSeriesCollectionName);
            _series = _databaseTSSO.GetCollection<BsonDocument>(AppSettings.SeriesCollectionName);
            _azureSearchQueue = _databaseCommon.GetCollection<BsonDocument>(AppSettings.AzureSearchQueueCollectionName);

            _today = DateTime.Today;

            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix, AppSettings.LogFolderErrors);
        }



        #region SearchQueueFunctions

        public async Task<AzureSearchQueueIds> GetQueueIds(string collectionName, string changeType, int batchSize, StringBuilder logMessage)
        {
            int retries = AppSettings.MaxConnectionRetries;
            var filter = Builders<BsonDocument>.Filter.Eq("CollectionName", collectionName)
                         & Builders<BsonDocument>.Filter.Eq("ChangeType", changeType)
                         & Builders<BsonDocument>.Filter.Eq("InProcessState", 0)
                         & (AppSettings.RunServiceAsRealTime ? Builders<BsonDocument>.Filter.Eq("IsRealTime", true) : Builders<BsonDocument>.Filter.Eq("IsRealTime", false));

            var sort = Builders<BsonDocument>.Sort.Descending("Priority").Descending("FootprintInformation.UpdatedDate");
            var queueIdBsonDoucmentList = new List<BsonDocument>();

            while (retries > 0)
            {
                try
                {
                    queueIdBsonDoucmentList = await _azureSearchQueue.Find<BsonDocument>(filter).Sort(sort).Limit(batchSize).Project(Builders<BsonDocument>.Projection.Include("ObjectId")).ToListAsync<BsonDocument>();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }



            AzureSearchQueueIds azureSearchQueueIds = new AzureSearchQueueIds();
            azureSearchQueueIds.AzureSearchQueueIdList = new List<AzureSearchQueueIdItem>();

            foreach (var doc in queueIdBsonDoucmentList)
            {
                if (doc.Contains("ObjectId"))
                {
                    var azureSearchQueueId = new AzureSearchQueueIdItem();
                    azureSearchQueueId.searchQueueId = doc["_id"].AsObjectId;
                    azureSearchQueueId.searchQueueObjectId = doc["ObjectId"].AsObjectId;

                    azureSearchQueueIds.AzureSearchQueueIdList.Add(azureSearchQueueId);
                }

            }


            if (azureSearchQueueIds != null && azureSearchQueueIds.AzureSearchQueueIdList != null && azureSearchQueueIds.AzureSearchQueueIdList.Any())
            {
                logMessage.AppendLine(string.Format("[{0}] GetQueueIds - Queue Count : {1} ", changeType, azureSearchQueueIds.AzureSearchQueueIdList.Count()));
            }
            //else
            //{
            //    _threadedLogger.Write(string.Format("[{0}] GetQueueIds - No items in queue ", changeType), FileLoggingLevel.INFO, collectionName);
            //}
            return azureSearchQueueIds;
        }


        public async Task UpdateSearchQueueLastCrawlDate(List<ObjectId> ids)
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BsonDocument>.Filter.In("_id", ids)
                                & Builders<BsonDocument>.Filter.Eq("InProcessState", (int)QueueProcessState.InProcess);
                    var update = Builders<BsonDocument>.Update.Set("LastCrawlDate", DateTime.Now).Set("FootprintInformation.UpdatedBy", "AzureService").Set("FootprintInformation.UpdatedDate", DateTime.Now).Set("InProcessState", (int)QueueProcessState.Success);

                    var updateOptions = new UpdateOptions();
                    updateOptions.IsUpsert = true;

                    var result = await _azureSearchQueue.UpdateManyAsync(filter, update, updateOptions);

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

        }


        public async Task UpdateSearchQueueInProcess(List<ObjectId> ids, int currentInProcessState, int newInProcessState)
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BsonDocument>.Filter.In("_id", ids)
                                & Builders<BsonDocument>.Filter.Eq("InProcessState", currentInProcessState);
                    var update = Builders<BsonDocument>.Update.Set("InProcessState", newInProcessState).Set("FootprintInformation.UpdatedBy", "AzureService").Set("FootprintInformation.UpdatedDate", DateTime.Now);

                    var result = await _azureSearchQueue.UpdateManyAsync(filter, update);

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }

        public async Task DeleteFromSearchQueue()
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var dateToDelete = DateTime.Now.Subtract(TimeSpan.FromDays(AppSettings.SearchQueueDeleteTimeFrame));
                    var filter = Builders<BsonDocument>.Filter.Lt("LastCrawlDate", dateToDelete);

                    var result = await _azureSearchQueue.DeleteManyAsync(filter);

                    if (result != null && result.DeletedCount > 0)
                        _threadedLogger.Write(string.Format("DeleteFromSearchQueue Date Deleted from : {0}, Count : {1}", dateToDelete, result.DeletedCount.ToString()), FileLoggingLevel.INFO);

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }

        #endregion SearchQueueFunctions


        #region GetCollectionData



        public async Task<List<BsonDocument>> GetProfilesDataForSearchLoad(string idField, List<ObjectId> ids, List<ObjectId> queueIds)
        {
            var response = new List<BsonDocument>();

            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BsonDocument>.Filter.In(idField, ids);
                    response = await _profiles.Find<BsonDocument>(filter).ToListAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        //reset queue items due to failure
                        UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

                        throw;
                    }
                }
            }

            return response;
        }



        public async Task<List<BsonDocument>> GetSeriesDataForSearchLoad(string idField, List<ObjectId> ids, List<ObjectId> queueIds)
        {
            var response = new List<BsonDocument>();


            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BsonDocument>.Filter.In(idField, ids);
                    response = await _series.Find<BsonDocument>(filter).ToListAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        //reset queue items due to failure
                        UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

                        throw;
                    }
                }
            }

            return response;
        }


        public async Task<List<BsonDocument>> GetProfiledSeriesDataForSearchLoad(string idField, List<ObjectId> ids, List<ObjectId> queueIds)
        {
            var response = new List<BsonDocument>();

            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BsonDocument>.Filter.In(idField, ids);
                    response = await _profiledSeries.Find<BsonDocument>(filter).ToListAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        //reset queue items due to failure
                        UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

                        throw;
                    }
                }
            }

            return response;
        }



        public async Task<List<BsonDocument>> GetProfiledSeriesDataForProfilesLoad(string idField, List<ObjectId> ids, List<ObjectId> queueIds, StringBuilder logMessage)
        {
            var response = new List<BsonDocument>();
            DateTime startTime = DateTime.Now;
            DateTime endTime;

            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                   var aggregateOptions = new AggregateOptions { AllowDiskUse = true };

                    var match = new BsonDocument { { idField, new BsonDocument { { "$in", BsonSerializer.Deserialize<BsonArray>(ids.ToJson()) } } } };

                    var projection = new BsonDocument {
                                       { "_id", 0},
                                       { "ProfileID",1},
                                       { "SeriesID", 1},
                                       { "RedundantSeriesInformation.Name", 1},
                                       { "PurchaseOrders.POLineNumber", 1},
                                       };


                    var group = new BsonDocument
                                  {
                                       { "_id", "$ProfileID"},
                                       {"ProfileID", new BsonDocument("$first", "$ProfileID")},
                                       {"SeriesIDList", new BsonDocument("$push" , "$SeriesID")},
                                       {"SeriesNameList", new BsonDocument("$push" , "$RedundantSeriesInformation.Name")},
                                       {"PONumberList", new BsonDocument("$push" , "$PurchaseOrders.POLineNumber")},
                                    
                                  };

                    var aggregate = _profiledSeries.Aggregate(aggregateOptions).Match(match).Project(projection).Group(group);

                    response = await aggregate.ToListAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        //reset queue items due to failure
                        UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

                        throw;
                    }
                }
            }
            endTime = DateTime.Now;
            TimeSpan diff = new TimeSpan(endTime.Ticks - startTime.Ticks);
            logMessage.AppendLine(string.Format("Profiles Aggregation Query Time Elapsed: {0}", diff));

            return response;
        }


        public async Task<List<BsonDocument>> GetProfiledSeriesDataForSeriesLoad(List<String> SeriesIDs, List<ObjectId> queueIds, StringBuilder logMessage)
        {
            var response = new List<BsonDocument>();
            DateTime startTime = DateTime.Now;
            DateTime endTime;

            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var aggregateOptions = new AggregateOptions { AllowDiskUse = true };

                    var match = new BsonDocument { { "SeriesID", new BsonDocument { { "$in", BsonSerializer.Deserialize<BsonArray>(SeriesIDs.ToJson()) } } } };

                    var projection = new BsonDocument {
                                        { "ProfileID" , 1},
                                        {"RedundantProfileInformation.OrganizationID" , 1},
                                        {"RequestStatus" , 1},
                                        {"RedundantProfileInformation.Name" , 1},
                                        { "_id", 0},
                                        { "SeriesID", 1},
                                       
                    };


                    var group = new BsonDocument
                                  {
                                    {"ProfileOrgInformation", new BsonDocument("$push", new BsonDocument("OrganizationID", "$RedundantProfileInformation.OrganizationID")
                                                                                        .Add("ProfileID", "$ProfileID")
                                                                                        .Add("RequestStatus", "$RequestStatus")
                                                                                        .Add("ProfileName", "$RedundantProfileInformation.Name"))},
                                    { "SeriesID",  new BsonDocument("$first","$SeriesID")},
                                    { "_id", "$SeriesID"},
                                  };

                    var aggregate = _profiledSeries.Aggregate(aggregateOptions).Match(match).Project(projection).Group(group);

                    response = await aggregate.ToListAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        //reset queue items due to failure
                        UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

                        throw;
                    }
                }
            }
            endTime = DateTime.Now;
            TimeSpan diff = new TimeSpan(endTime.Ticks - startTime.Ticks);
            logMessage.AppendLine(string.Format("Series Aggregation Query Time Elapsed: {0}", diff));

            return response;
        }


        #endregion GetCollectionData

        #region MongoLookUpAggregation
        //public async Task<List<BsonDocument>> GetSeriesDataForSearchLoad(string idField, List<ObjectId> ids, List<ObjectId> queueIds, StringBuilder logMessage)
        //{
        //    var response = new List<BsonDocument>();
        //    DateTime startTime = DateTime.Now;
        //    DateTime endTime;

        //    int retries = AppSettings.MaxConnectionRetries;
        //    while (retries > 0)
        //    {
        //        try
        //        {
        //            var match = new BsonDocument { { idField, new BsonDocument { { "$in", BsonSerializer.Deserialize<BsonArray>(ids.ToJson()) } } } };

        //            var unwindOptions = new AggregateUnwindOptions<BsonDocument>();
        //            unwindOptions.PreserveNullAndEmptyArrays = true;

        //            var projection = new BsonDocument {
        //                                    { "ProfiledSeriesInfo.ProfileID" , 1},
        //                                    {"ProfiledSeriesInfo.RedundantProfileInformation.OrganizationID" , 1},
        //                                    {"ProfiledSeriesInfo.RequestStatus" , 1},
        //                                    {"ProfiledSeriesInfo.RedundantProfileInformation.Name" , 1},
        //                                    { "_id", 1},
        //                                    { "SeriesID", 1},
        //                                    { "Name", 1},
        //                                    { "Publisher", 1},
        //                                    { "Distributor", 1},
        //                                    { "Format", 1},
        //                                    { "LatestIssueInformation", 1},
        //                                    { "Frequency", 1},
        //                                    { "Audience", 1},
        //                                    { "Annotations", 1},
        //                                    { "ReadingLevelFrom", 1},
        //                                    { "ReadingLevelTo", 1},
        //                                    { "Author", 1},
        //                                    { "StartDataType", 1},
        //                                    { "Status", 1},
        //                                    { "FootprintInformation", 1},
        //                                    { "LoadDateTime", 1},
        //                                    { "AreasOfInterest", 1},
        //                                    { "RelatedSeriesIDs", 1},
        //                                    { "HasRelatedSeries", 1},
        //                                    { "Programs", 1 },
        //                                    { "ISBNList", 1 },
        //                                    { "ISBN10List", 1 },
        //                                    { "BindingPreferences", 1 },
        //                                    { "HasBindingPreferences", 1 },
        //                                    };

        //            var group = new BsonDocument
        //                          {
        //                                { "_id" , "$_id" },
        //                                {"ProfileOrgInformation", new BsonDocument("$push", new BsonDocument("OrganizationID", "$ProfiledSeriesInfo.RedundantProfileInformation.OrganizationID")
        //                                                                                    .Add("ProfileID", "$ProfiledSeriesInfo.ProfileID")
        //                                                                                    .Add("RequestStatus", "$ProfiledSeriesInfo.RequestStatus")
        //                                                                                    .Add("ProfileName", "$ProfiledSeriesInfo.RedundantProfileInformation.Name"))},
        //                                { "SeriesID",  new BsonDocument("$first","$SeriesID")},
        //                                { "Name",  new BsonDocument("$first","$Name")},
        //                                { "Publisher",  new BsonDocument("$first","$Publisher")},
        //                                { "Distributor",  new BsonDocument("$first","$Distributor")},
        //                                { "Format",  new BsonDocument("$first","$Format")},
        //                                { "LatestIssueInformation",  new BsonDocument("$first","$LatestIssueInformation")},
        //                                { "Frequency",  new BsonDocument( "$first","$Frequency")},
        //                                { "Audience",  new BsonDocument("$first","$Audience")},
        //                                { "Annotations",  new BsonDocument("$first","$Annotations")},
        //                                { "ReadingLevelFrom",  new BsonDocument("$first","$ReadingLevelFrom")},
        //                                { "ReadingLevelTo",  new BsonDocument("$first","$ReadingLevelTo")},
        //                                { "Author",  new BsonDocument("$first","$Author")},
        //                                { "StartDataType",  new BsonDocument("$first","$StartDataType-")},
        //                                { "Status",  new BsonDocument("$first","$Status")},
        //                                { "FootprintInformation",  new BsonDocument("$first","$FootprintInformation")},
        //                                { "LoadDateTime",  new BsonDocument("$first","$LoadDateTime")},
        //                                { "AreasOfInterest",  new BsonDocument("$first","$AreasOfInterest")},
        //                                { "RelatedSeriesIDs",  new BsonDocument("$first","$RelatedSeriesIDs")},
        //                                { "HasRelatedSeries",  new BsonDocument("$first","$HasRelatedSeries")},
        //                                { "Programs", new BsonDocument("$first","$Programs")},
        //                                { "ISBNList", new BsonDocument("$first","$ISBNList")},
        //                                { "ISBN10List", new BsonDocument("$first","$ISBN10List")},
        //                                { "BindingPreferences", new BsonDocument("$first","$BindingPreferences")},
        //                                { "HasBindingPreferences", new BsonDocument("$first","$HasBindingPreferences")},
        //                          };

        //            var aggregate = _series.Aggregate().Match(match).Lookup("ProfiledSeries", "SeriesID", "SeriesID", "ProfiledSeriesInfo").Project(projection).Unwind("ProfiledSeriesInfo", unwindOptions).Group(group);

        //            response = await aggregate.ToListAsync();

        //            break;
        //        }
        //        catch (Exception)
        //        {
        //            retries--;
        //            Thread.Sleep(retryWaitTime);
        //            if (retries < 1)
        //            {
        //                //reset queue items due to failure
        //                UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

        //                throw;
        //            }
        //        }
        //    }
        //    endTime = DateTime.Now;
        //    TimeSpan diff = new TimeSpan(endTime.Ticks - startTime.Ticks);
        //    logMessage.AppendLine(string.Format("Series Aggregation Query Time Elapsed: {0}", diff));

        //    return response;
        //}

        //public async Task<List<BsonDocument>> GetProfilesDataForSearchLoad(string idField, List<ObjectId> ids, List<ObjectId> queueIds, StringBuilder logMessage)
        //{
        //    var response = new List<BsonDocument>();
        //    DateTime startTime = DateTime.Now;
        //    DateTime endTime;

        //    int retries = AppSettings.MaxConnectionRetries;
        //    while (retries > 0)
        //    {
        //        try
        //        {
        //            var match = new BsonDocument { { idField, new BsonDocument { { "$in", BsonSerializer.Deserialize<BsonArray>(ids.ToJson()) } } } };

        //            var unwindOptions = new AggregateUnwindOptions<BsonDocument>();
        //            unwindOptions.PreserveNullAndEmptyArrays = true;

        //            var projection = new BsonDocument {
        //                               { "_id", 1},
        //                               { "OrganizationID",1},
        //                               { "UserName", 1},
        //                               { "Name", 1},
        //                               { "ShippingAccountID", 1},
        //                               { "ShippingAccountNumber", 1},
        //                               { "BillingAccountNumber", 1},
        //                               { "SAN", 1},
        //                               { "AccountType", 1},
        //                               { "ProfileType", 1},
        //                               { "Notes", 1},
        //                               { "RequestStatus", 1},
        //                               { "RequestType", 1},
        //                               { "Status", 1},
        //                               { "SalesTerritory", 1},
        //                               { "AreasOfInterest", 1},
        //                               { "Programs", 1},
        //                               { "NotificationUsers", 1},
        //                               { "profiledSeries.SeriesID", 1},
        //                               { "profiledSeries.RedundantSeriesInformation.Name", 1},
        //                               { "profiledSeries.PurchaseOrders.POLineNumber", 1},
        //                               { "ContactInformation", 1},
        //                               { "AddressInformation", 1},
        //                               { "SummaryInformation", 1},
        //                               { "FootprintInformation", 1},
        //                               };

        //            var group = new BsonDocument
        //                          {
        //                               { "_id", "$_id"},
        //                               {"OrganizationID", new BsonDocument("$first", "$OrganizationID")},
        //                               {"UserName", new BsonDocument("$first", "$UserName")},
        //                               {"Name", new BsonDocument("$first", "$Name")},
        //                               {"ShippingAccountID", new BsonDocument("$first", "$ShippingAccountID")},
        //                               {"ShippingAccountNumber", new BsonDocument("$first", "$ShippingAccountNumber")},
        //                               {"BillingAccountNumber", new BsonDocument("$first", "$BillingAccountNumber")},
        //                               {"SAN", new BsonDocument("$first", "$SAN")},
        //                               {"AccountType", new BsonDocument("$first", "$AccountType")},
        //                               {"ProfileType", new BsonDocument("$first", "$ProfileType")},
        //                               {"Notes", new BsonDocument("$first", "$Notes")},
        //                               {"RequestStatus", new BsonDocument("$first", "$RequestStatus")},
        //                               {"RequestType", new BsonDocument("$first", "$RequestType")},
        //                               {"Status", new BsonDocument("$first", "$Status")},
        //                               {"SalesTerritory", new BsonDocument("$first", "$SalesTerritory")},
        //                               {"AreasOfInterest", new BsonDocument("$first", "$AreasOfInterest")},
        //                               {"Programs", new BsonDocument("$first", "$Programs")},
        //                               {"NotificationUsers", new BsonDocument("$first", "$NotificationUsers")},
        //                               {"SeriesIDList", new BsonDocument("$push" , "$profiledSeries.SeriesID")},
        //                               {"SeriesNameList", new BsonDocument("$push" , "$profiledSeries.RedundantSeriesInformation.Name")},
        //                               {"PONumberList", new BsonDocument("$push" , "$profiledSeries.PurchaseOrders.POLineNumber")},
        //                               {"ContactInformation", new BsonDocument("$first", "$ContactInformation")},
        //                               {"AddressInformation", new BsonDocument("$first", "$AddressInformation")},
        //                               {"SummaryInformation", new BsonDocument("$first", "$SummaryInformation")},
        //                               {"FootprintInformation", new BsonDocument("$first", "$FootprintInformation")},
        //                          };


        //            var aggregate = _profiles.Aggregate().Match(match).Lookup("ProfiledSeries", idField, "ProfileID", "profiledSeries").Project(projection).Unwind("profiledSeries", unwindOptions).Group(group);

        //            response = await aggregate.ToListAsync();
        //            break;
        //        }
        //        catch (Exception)
        //        {
        //            retries--;
        //            Thread.Sleep(retryWaitTime);
        //            if (retries < 1)
        //            {
        //                //reset queue items due to failure
        //                UpdateSearchQueueInProcess(queueIds, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);

        //                throw;
        //            }
        //        }
        //    }
        //    endTime = DateTime.Now;
        //    TimeSpan diff = new TimeSpan(endTime.Ticks - startTime.Ticks);
        //    logMessage.AppendLine(string.Format("Profiles Aggregation Query Time Elapsed: {0}", diff));

        //    return response;
        //}
        #endregion MongoLookUpAggregation
    }
}
