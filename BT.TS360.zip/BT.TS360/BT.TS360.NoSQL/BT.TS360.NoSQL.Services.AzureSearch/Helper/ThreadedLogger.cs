﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.Services.AzureSearch.Helper
{


    public class ThreadedLogger
    {

        private string _folder;
        private string _prefix;
        private string _fileName;
        private string _fileNameErrors;
        private string _folderErrors;

        private static object locker = new object();

        public ThreadedLogger(string folder, string prefix, string folderErrors)
        {
            _folder = folder;
            _folderErrors = folderErrors;
            _prefix = prefix;

            _fileName = string.Format("{0}_{1}.txt", _prefix, DateTime.Now.ToString("yyyy-MM-dd-HH0000"));
            _fileNameErrors = string.Format("{0}_{1}.txt", _prefix, DateTime.Now.ToString("yyyy-MM-dd-HHmm00"));
        }

        public void Write(string message, FileLoggingLevel level, string indexName = "None")
        {
            string logFilePath;
            if (level == FileLoggingLevel.ERROR)
            {
                logFilePath = string.Format("{0}\\{1}", _folderErrors, _fileNameErrors);
            }
            else
            {
                logFilePath = string.Format("{0}\\{1}", _folder, _fileName);
            }


            lock (locker)
            {

                using (FileStream file = new FileStream(logFilePath, FileMode.Append, FileAccess.Write, FileShare.None))
                {
                    DateTime now = DateTime.Now;
                    StreamWriter writer = new StreamWriter(file);
                    writer.Write(string.Format("{0}\t{1}\t{2}\t{3}", now, level.ToString(), " - Search Index [" + indexName + "] : ", message));
                    writer.WriteLine();
                    writer.Flush();
                }
            }
        }



    }

}
