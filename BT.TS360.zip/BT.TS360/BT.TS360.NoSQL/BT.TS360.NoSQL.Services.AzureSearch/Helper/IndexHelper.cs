﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using Microsoft.Spatial;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using BT.TS360.NoSQL.Services.AzureSearch;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Services.AzureSearch.Constants;
using BT.TS360.NoSQL.Services.AzureSearch.Models;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Net.Http;
using System.Web.Script.Serialization;
using Newtonsoft.Json;



namespace BT.TS360.NoSQL.Services.AzureSearch.Helper
{
    class IndexHelper
    {
        
        static ThreadedLogger _threadedLogger;

        static string SearchServiceName = AppSettings.SearchServiceName;
        static string SearchServiceApiKey = AppSettings.SearchServiceApiKey;
        static SearchServiceClient _serviceClient = new SearchServiceClient(SearchServiceName, new SearchCredentials(SearchServiceApiKey));


        static int retryAzureWaitTimeInterval = AppSettings.RetryAzureWaitTimeInterval;
        static int maxRetriesAzure = AppSettings.MaxAzureLoadRetries;

        public IndexHelper()
        {
            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix, AppSettings.LogFolderErrors);
        }


        public async Task CreateIndexes(Index definition, string indexName)
        {
            int retriesAzure = 0;

            while (retriesAzure <= maxRetriesAzure)
            {
                try
                {

                    DeleteSearchIndexIfExists(_serviceClient, indexName);
                    _serviceClient.Indexes.Create(definition);

                    break;
                }
                catch (Exception)
                {
                    retriesAzure++;
                    Thread.Sleep(retryAzureWaitTimeInterval);
                    if (retriesAzure == maxRetriesAzure)
                    {
                        throw;
                    }
                }
            }
        }


        private void DeleteSearchIndexIfExists(SearchServiceClient serviceClient, string indexName)
        {
            if (serviceClient.Indexes.Exists(indexName))
            {
                serviceClient.Indexes.Delete(indexName);
                _threadedLogger.Write("Index already existed, previous index deleted.", FileLoggingLevel.INFO, indexName);
            }
        }



        private ISearchIndexClient GetIndexClient(string indexName)
        {
            return _serviceClient.Indexes.GetClient(indexName);
        }



        public async Task UploadDocuments<T>(string indexName, IndexBatch<T> batch, List<AzureSearchQueueIdItem> azureSearchQueueIdList, StringBuilder logMessage) where T : SearchResultItem
        {
            DateTime startTime = DateTime.Now;
            DateTime endTime;

            ISearchIndexClient searchIndexClient = GetIndexClient(indexName);
            MongoDBHelper mongoDBHelper = new MongoDBHelper();

            int retriesAzure = 0;
            List<ObjectId> failedIndexIds = new List<ObjectId>();

            while (retriesAzure <= maxRetriesAzure)
            {
                try
                {

                    if (batch != null && batch.Actions != null && batch.Actions.Any())
                    {

                        await Task.Delay(retriesAzure * retryAzureWaitTimeInterval); //First load 0ms dealy, for each failure increment delay by intervals
                        var result = searchIndexClient.Documents.Index(batch);
                    }

                    endTime = DateTime.Now;
                    TimeSpan diff = new TimeSpan(endTime.Ticks - startTime.Ticks);
                    logMessage.AppendLine(string.Format("Index Load Time Elapsed: {0}, Batch Count Loaded : {1}", diff, batch.Actions.Count()));
                    break;
                }
                catch (IndexBatchException e)
                {
                    retriesAzure++;
                    //Get failed batches to retry
                    batch = e.FindFailedActionsToRetry<T>(batch, r => r.ObjectId);

                    if (retriesAzure == maxRetriesAzure)
                    {
                        failedIndexIds = e.IndexingResults.Where(r => !r.Succeeded).Select(r => ObjectId.Parse(r.Key)).ToList();
                        //LOG FAILED
                        var message = string.Format("Failed to index some of the documents: {0}", String.Join(", ", e.IndexingResults.Where(r => !r.Succeeded).Select(r => r.Key)));
                        _threadedLogger.Write(message, FileLoggingLevel.ERROR, indexName);
                       // logMessage.AppendLine(message);
                    }
                }
                catch (Exception ex)
                {
                    retriesAzure++;
                   
                    if (retriesAzure == maxRetriesAzure)
                    {
                        //reset all current queueids if failure
                        failedIndexIds = azureSearchQueueIdList.Select(x => x.searchQueueId).ToList();

                        var message = string.Format("Failed to UploadDocuments for [{0}]: {1}", indexName, ex.Message);

                        _threadedLogger.Write(message, FileLoggingLevel.ERROR, indexName);
                        //logMessage.AppendLine(message);
                        // mongoDBHelper.UpdateSearchQueueInProcess(azureSearchQueueIdList.Select(x => x.searchQueueId).ToList(), (int)QueueProcessState.InProcess, (int)QueueProcessState.New);
                    }
                }

                if (failedIndexIds != null && failedIndexIds.Any())
                {
                    var failedResult = azureSearchQueueIdList.Where(x => failedIndexIds.Any(y => y == x.searchQueueObjectId)).Select(x => x.searchQueueId).ToList();
                    await mongoDBHelper.UpdateSearchQueueInProcess(failedResult, (int)QueueProcessState.InProcess, (int)QueueProcessState.New);
                }

            }

        }





        #region IndexDefintions

        public Index GetProfilesIndex()
        {
            CustomAnalyzer customAnalyzer = GetKeywordAnalyzer();

            var definition = new Index()
            {
                Name = AppSettings.ProfilesIndexName,
                Fields = new[] 
                { 
                    new Field("id",                     DataType.String)    { IsKey = true,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("OrganizationID",         DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UserName",               DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Name",                   DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("NameNoPunctuation",      DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("CompassAccountNumber",   DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ShippingAccountID",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ShippingAccountNumber",  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BillingAccountNumber",   DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SAN",                    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("AccountType",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfileType",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Notes",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("RequestStatus",          DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("RequestType",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("Status",                 DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = true, IsFacetable = true, IsRetrievable = true},
                    new Field("SalesTerritory",         DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("AreasOfInterest",        DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Programs",               DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("ProgramsForSort",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("NotificationUsers",      DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesIDList",           DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesNameList",         DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("PrimaryContact",         DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Phone",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Fax",                    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("eMail",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Line1",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Line2",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Line3",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("City",                   DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("State",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Zipcode",                DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("TotalCopies",            DataType.Int32)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("TotalSeries",            DataType.Int32)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedBy",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedByUserID",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedDate",            DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedBy",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedByUserID",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedDate",            DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = true, IsFacetable = true, IsRetrievable = true},
                    new Field("UpdatedDateRange",       DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("PONumberList",           DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true}
                }
                ,
                Analyzers = new List<Analyzer> { customAnalyzer }
            };

            return definition;
        }



        public Index GetSeriesIndex()
        {

            CustomAnalyzer customAnalyzer = GetKeywordAnalyzer();

            var definition = new Index()
            {
                Name = AppSettings.SeriesIndexName,
                Fields = new[]
                {
                    new Field("id",                 DataType.String)    { IsKey = true,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesID",           DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Name",               DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("NameKeyword",        DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = true, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("Programs",           DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("ProgramsForSort",    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = true, IsFacetable = true, IsRetrievable = true},
                    new Field("Publisher",          DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("PublisherKeyword",   DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = true, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("Distributor",        DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("DistributorNoPunctuation", DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = true, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("Format",             DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("Frequency",          DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("AreasOfInterest",    DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Audience",           DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("Annotations",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Author",             DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("RelatedSeriesIDs",   DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("HasRelatedSeries",   DataType.Boolean)   { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferences", DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("StartDataType",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Status",             DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("SeriesLists",        DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("LoadDateTime",       DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ISBNList",           DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ISBN10List",           DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfileOrgIDList",   DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("ProfileIDList",      DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = false},
                    new Field("BTKey",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ISBN",               DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ListPrice",          DataType.Double)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("PublicationDate",    DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = true, IsFacetable = true, IsRetrievable = true},
                    new Field("PublicationDateRange", DataType.Collection(DataType.String))  { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("Edition",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Title",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("LatestIssueAuthor",  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProductType",        DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedBy",          DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedByUserID",    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedDate",        DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedBy",          DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedByUserID",    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedDate",        DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("HasBindingPreferences",   DataType.Boolean)   { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ContentListIDList",           DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceLiteral1",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference1",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference1",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference1",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},

                    new Field("BindingPreferenceLiteral2",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference2",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference2",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference2",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},

                    new Field("BindingPreferenceLiteral3",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference3",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference3",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference3",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},

                    new Field("BindingPreferenceLiteral4",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference4",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference4",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference4",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true}


                }
                ,Analyzers = new List<Analyzer> { customAnalyzer }

            };

            return definition;
        }



        public Index GetProfiledSeriesIndex()
        {
            CustomAnalyzer customAnalyzer = GetKeywordAnalyzer();

            var definition = new Index()
            {
                Name = AppSettings.ProfiledSeriesIndexName,
                Fields = new[]
                {
                    new Field("ProfiledSeriesID",       DataType.String)    { IsKey = true,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfileID",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesID",               DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("Note",                   DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("RequestStatus",          DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("RequestType",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("ChangeRequestUserID",    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("TotalPrimaryQuantity",   DataType.Int32)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("LoadDateTime",           DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedBy",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedByUserID",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CreatedDate",            DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedBy",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedByUserID",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("UpdatedDate",            DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesName",             DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesNameNoPunctuation",    DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("Author",                 DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("AuthorNoPunctuation",    DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("Format",                 DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("Audience",               DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("Publisher",              DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Distributor",            DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Frequency",              DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = true, IsFacetable = true, IsRetrievable = true},
                    new Field("SeriesPrograms",         DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesProgramsForSort",  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesRequestStatus",    DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesStatus",           DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = true, IsRetrievable = true},
                    new Field("BTKey",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ISBN",                   DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ListPrice",              DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true},
                    new Field("PublicationDate",        DataType.String)    { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = true, IsFacetable = false, IsRetrievable = true, IndexAnalyzer="myKeywordAnalyzer", SearchAnalyzer="myKeywordAnalyzer"},
                    new Field("Edition",                DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("Title",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("LatestIssueAuthor",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("HasRelatedSeries",       DataType.Boolean)   { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("RelatedSeriesIDs",       DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesCreatedBy",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesCreatedByUserID",  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesCreatedDate",      DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesUpdatedBy",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesUpdatedByUserID",  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SeriesUpdatedDate",      DataType.DateTimeOffset)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("CompassAccountNumber",   DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ShippingAccountNumber",  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfileName",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("OrganizationID",         DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("TotalSeries",            DataType.Int32)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("TotalCopies",            DataType.Int32)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfileStatus",          DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfileType",            DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("ProfilePrograms",        DataType.Collection(DataType.String))    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("SalesTerritory",         DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("POQuantityList",         DataType.Collection(DataType.String))   { IsKey = false,  IsSearchable = true, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("POLineNumberList",       DataType.Collection(DataType.String))   { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    
                    new Field("AreasOfInterest",       DataType.Collection(DataType.String))   { IsKey = false,  IsSearchable = true, IsFilterable = true, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("HasBindingPreferences",   DataType.Boolean)   { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                   
                    new Field("BindingPreferenceLiteral1",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference1",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference1",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference1",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},

                    new Field("BindingPreferenceLiteral2",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference2",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference2",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference2",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},

                    new Field("BindingPreferenceLiteral3",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference3",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference3",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference3",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},

                    new Field("BindingPreferenceLiteral4",                  DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferencePrimaryPreference4",        DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceSecondaryPreference4",      DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("BindingPreferenceHasMultiplePreference4",    DataType.Boolean)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("POCount",                                    DataType.Int32)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true},
                    new Field("PO1FormatPreferenceLiteral",                 DataType.String)    { IsKey = false,  IsSearchable = false, IsFilterable = false, IsSortable = false, IsFacetable = false, IsRetrievable = true}

                },
                Analyzers = new List<Analyzer> { customAnalyzer }
            };

            return definition;
        }
        public CustomAnalyzer GetKeywordAnalyzer() {
            return new CustomAnalyzer("myKeywordAnalyzer", TokenizerName.Keyword, new TokenFilterName[] { TokenFilterName.Lowercase });
        }



        #endregion IndexDefintions



    }
}
