﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.AzureSearch.Helper
{
    public static class CommonHelper
    {

        public static string RemoveSpecialCharacters(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                StringBuilder sb = new StringBuilder();
                foreach (char c in str)
                {
                    if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' ')
                    {
                        sb.Append(c);
                    }
                }

                return sb.ToString();
            }
            return string.Empty;
        }


    }
}

