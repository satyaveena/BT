﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.AzureSearch.Constants
{

    public enum QueueProcessState
    {
        New = 0,
        InProcess = 1,
        Success = 2,
        Failed = 3
    }

}
