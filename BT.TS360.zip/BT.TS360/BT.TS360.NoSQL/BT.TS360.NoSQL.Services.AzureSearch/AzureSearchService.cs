﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Timers;
using System.Configuration;
using System.Data.OleDb;
using System.Xml.Serialization;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Bson.Serialization;
using BTNextGen.Elmah;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Services.AzureSearch.Services;
using BT.TS360.NoSQL.Services.AzureSearch.Helper;

namespace BT.TS360.NoSQL.Services.AzureSearch
{
    public partial class AzureSearchService : ServiceBase
    {

        ThreadedLogger _threadedLogger;
        static Emailer _emailer;
        ExceptionLogger _exceptionLogger;


        int _intervalMilliseconds;
        string _serviceStartTime;
        string _serviceEndTime;

        static bool _runServiceAsRealTime = false;

        static string _emailTo;
        static string _currentEnvironment;
        static string _serviceRunType;

        static Boolean _InProcess = false;

        private System.Timers.Timer _timer;

        public AzureSearchService()
        {
            InitializeComponent();
        }


        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args)
        {


            InitAppSettings();

            _timer = new System.Timers.Timer(1);
            _timer.AutoReset = false;
            _timer.Enabled = true;
            _timer.Elapsed += new ElapsedEventHandler(OnTimerElapsed);
            _timer.Start();

            _threadedLogger.Write("Azure Search Data Load Service started", FileLoggingLevel.INFO);
            _emailer.Send(_emailTo, string.Format("Azure Search: " + _currentEnvironment + " [" + Environment.MachineName + "]"), "Service Started " + DateTime.Now.ToString());
        }

        public void Stop(string[] args) { OnStop(); }

        protected override void OnStop()
        {

            _threadedLogger.Write("Azure Search Data Load Service STOPPED", FileLoggingLevel.INFO);
             _emailer.Send(_emailTo, string.Format("Azure Search: " + _currentEnvironment + " [" + Environment.MachineName + "]"), "Service Stopped " + DateTime.Now.ToString());

            _timer.Stop();
            this._timer.Dispose();
        }


        private void InitAppSettings()
        {
            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix, AppSettings.LogFolderErrors);
            _emailer = new Emailer(AppSettings.EmailSMTPServer);
            _emailTo = AppSettings.EmailTo;
            _currentEnvironment = AppSettings.CurrentEnvironment;
         
            _intervalMilliseconds = AppSettings.IntervalMilliseconds;
            _serviceStartTime = AppSettings.ServiceStartTime;
            _serviceEndTime = AppSettings.ServiceEndTime;
            _serviceRunType = AppSettings.ServiceRunType;
            _runServiceAsRealTime = AppSettings.RunServiceAsRealTime;
        }


        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            SearchLoadMain searchLoadMain = new SearchLoadMain();

            if (_serviceRunType == "Crawler")
            {

                DateTime currentDateTime = DateTime.Now;
                DateTime serviceStartDateTime = DateTime.Parse(string.Format("{0} {1}", currentDateTime.ToString("MM/dd/yyyy"), _serviceStartTime));
                DateTime serviceEndDateTime = DateTime.Parse(string.Format("{0} {1}", currentDateTime.ToString("MM/dd/yyyy"), _serviceEndTime));

                if (!_timer.AutoReset)
                {
                    //Service is running as Data Crawler, set interval timer
                    _timer.Interval = _intervalMilliseconds;
                    _timer.AutoReset = true;
                }
                if (!_runServiceAsRealTime)
                {
                    if (!(currentDateTime >= serviceStartDateTime && currentDateTime <= serviceEndDateTime))
                    {
                        return;
                    }
                }

                if (!_InProcess)
                {
                    _InProcess = true;
                    //  Do Work
                    searchLoadMain.OnLoad();

                    _InProcess = false;

                }

            }
            else if (_serviceRunType == "Index")
            {
                //Service is running as Index creator, do not set timer for service
                //When Index is created, data is lost and will need to be reloaded.
                searchLoadMain.OnLoad();

                OnStop();
                Console.WriteLine("Service Stopped");
            }
            else
            {
                _threadedLogger.Write(string.Format("Invalid serviceRunType indicated: {0}", _serviceRunType), FileLoggingLevel.ERROR);
                string message = string.Format("Service cannot run, invalid ServiceRunType is set.  Please verify config. Current value = {0}", _serviceRunType) + DateTime.Now.ToString();
                _emailer.Send(_emailTo, string.Format("Azure Search cannot run: " + _currentEnvironment + " [" + Environment.MachineName + "]"), message);

                OnStop();
            }

        }
    }
}

