﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Services;
using BT.TS360.NoSQL.Services.Compass.Common;
using BTNextGen.Elmah;

namespace BT.TS360.NoSQL.Services.Compass
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {


            if (Environment.UserInteractive)
            {
                CompassLoadMain compassload = new CompassLoadMain();
                compassload.Main();

            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
                    { 
                        new Service1() 
                    };
                ServiceBase.Run(ServicesToRun);

            }



        }
    }
}
