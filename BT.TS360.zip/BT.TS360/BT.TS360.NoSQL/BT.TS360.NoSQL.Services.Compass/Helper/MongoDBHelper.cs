﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using System.Threading;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Configuration;

using BT.TS360.NoSQL.Services.Compass.Common.Configuration;

namespace BT.TS360.NoSQL.Services.Compass.Helper
{
    class MongoDBHelper
    {

        IMongoCollection<BsonDocument> _profiles;
        IMongoCollection<BsonDocument> _profiledSeries;
        IMongoCollection<BsonDocument> _series;
        IMongoCollection<BsonDocument> _azureSearchQueue;




        public MongoDBHelper()
        {
            Console.WriteLine("Establishing Mongo connection.");


            IMongoClient _client = new MongoClient(AppSetting.MongoDatabaseConnectionString);
            IMongoDatabase _databaseTSSO = _client.GetDatabase(AppSetting.MongoDatabase);
            _profiles = _databaseTSSO.GetCollection<BsonDocument>(AppSetting.MongoCollectionProfiles);
            _profiledSeries = _databaseTSSO.GetCollection<BsonDocument>(AppSetting.MongoCollectionProfiledSeries);
            _series = _databaseTSSO.GetCollection<BsonDocument>(AppSetting.MongoCollectionSeries);


            IMongoDatabase commonDatabase = _client.GetDatabase(AppSetting.CommonDatabase);
            _azureSearchQueue = commonDatabase.GetCollection<BsonDocument>(AppSetting.MongoCollectionAzureQueue);
        }




        public BulkWriteResult UpdateMongoBulk(List<WriteModel<BsonDocument>> bulkModels, string database)
        {
            try
            {
                BulkWriteResult bulkWriteResult = null;

                int MongoRetries = Convert.ToInt32(AppSetting.RetryTimes);
                while (true)
                {
                    try
                    {
                        if (database == AppSetting.MongoCollectionProfiles)
                        {
                            bulkWriteResult = _profiles.BulkWrite(bulkModels);
                        }
                        else if (database == AppSetting.MongoCollectionProfiledSeries)
                        {
                            bulkWriteResult = _profiledSeries.BulkWrite(bulkModels);
                        }
                        else if (database == AppSetting.MongoCollectionSeries)
                        {
                            bulkWriteResult = _series.BulkWrite(bulkModels);
                        }


                        return bulkWriteResult;

                    }


                    catch (Exception ex)
                    {

                        Console.WriteLine("Exception updating Mongo:  " + ex.Message);
                        MongoRetries--;
                        Thread.Sleep(100);

                        if (MongoRetries == 0)
                        {
                            throw;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:  UpdateProfilesMongoBulk:  [" + database + "] " + ex.Message);
                throw ex;
            }
        }



        public bool CreateFullAzureQueue(string currentCollection)
        {

            var response = new List<BsonDocument>();


            int MongoRetries = Convert.ToInt32(AppSetting.RetryTimes);
            while (MongoRetries > 0)
            {
                try
                {

                    var pipeline = new BsonDocument[] {

                                    new BsonDocument{{"$project", new BsonDocument {
                                        { "ObjectId" , "$_id"},
                                        {"_id" , 0},
                                        {"CollectionName" , new BsonDocument("$concat", currentCollection)},
                                        {"ChangeType" , new BsonDocument("$concat", "Upsert")},
                                        { "Priority", new BsonDocument("$literal", Convert.ToInt32("0"))},
                                        { "InProcessState", new BsonDocument("$literal", Convert.ToInt32("0"))},
                                       { "FootprintInformation", new BsonDocument{
                                                    {"UpdatedBy", new BsonDocument("$literal", "CompassLoader")}, 
                                                    {"UpdatedDate", new BsonDocument("$literal", DateTime.Now)}, 
                                                    { "CreatedBy" , new BsonDocument("$literal","CompassLoader")},
                                                    { "CreatedDate", new BsonDocument("$literal", DateTime.Now)}, 
                                       }},
                                        {"IsRealTime",new BsonDocument("$literal", Convert.ToBoolean("false")) }
                                       
                                        }
                                        }}
                                };

                    if (currentCollection == AppSetting.MongoCollectionProfiles)
                    {
                        response = _profiles.Aggregate<BsonDocument>(pipeline).ToList();
                    }
                    else if (currentCollection == AppSetting.MongoCollectionProfiledSeries)
                    {
                        response = _profiledSeries.Aggregate<BsonDocument>(pipeline).ToList();
                    }
                    else if (currentCollection == AppSetting.MongoCollectionSeries)
                    {
                        response = _series.Aggregate<BsonDocument>(pipeline).ToList();
                    }

                    _azureSearchQueue.InsertMany(response);
                    return true;
                }
                catch (Exception ex)
                {

                    Console.WriteLine("Exception updating AzureQueue:  " + ex.Message);
                    MongoRetries--;
                    Thread.Sleep(100);

                    if (MongoRetries == 0)
                    {
                        throw;

                    }
                }
            }
            return true;
        }



        public WriteModel<BsonDocument> CreateWriteModel(FilterDefinition<BsonDocument> query, UpdateDefinition<BsonDocument> values, bool isUpsert = false)
        {

            var model = new UpdateManyModel<BsonDocument>(query, values) { IsUpsert = isUpsert };


            return model;
        }

    }
}
