﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using BT.TS360.Services.Compass; 
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Services;
using BT.TS360.NoSQL.Services.Compass.Helper;
using BT.TS360.NoSQL.Data.Common.Helper;

namespace BT.TS360.NoSQL.Services.Compass
{
    public class CompassLoad11ProfiledSeriesRedundantSeries
    {
        MongoDBHelper mongoDBHelper = new MongoDBHelper();
        AzureSearchQueueHelper _azureSearchQueueHelper;

        public CompassLoad11ProfiledSeriesRedundantSeries()
        {
        }

        public void Load()
        {
            var models = new List<WriteModel<BsonDocument>>();

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            //FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            //FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);

            String loadCollection = "RedundantSeries";
            String loadCollectionLogging = "ProfiledSeries/RedundantSeries";

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

            int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
            int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
            int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
            int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries1Save = Convert.ToInt32(maxRetries1);
            int maxRetries2Save = Convert.ToInt32(maxRetries2);
            int maxRetries3Save = Convert.ToInt32(maxRetries3);
            Int64 updatecounter = 0;
            Int64 insertcounter = 0;
            Int64 totalSkipped = 0;
            int bulkWriteCount = 0;

            int daysBackToUpdate = Convert.ToInt32(AppSetting.RedundantSeriesUpdateParm);

            DateTime dtNow = DateTime.Today;
            DateTime dtnowUpdate = DateTime.Today.AddDays(daysBackToUpdate);

            try
            {

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection<Series> series = mongodatabase.GetCollection<Series>(AppSetting.MongoCollectionSeries);
                //MongoCollection<Serieszzzz> series = mongodatabase.GetCollection<Serieszzzz>("Series");

                MongoClient mongoClientX = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServerX = mongoClient.GetServer();
                MongoDatabase mongodatabaseX = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection<ProfiledSeries> profiledSeries = mongodatabase.GetCollection<ProfiledSeries>(AppSetting.MongoCollectionProfiledSeries);


                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");

                var seriesCursor = series.Find(Query.GTE("LoadDateTime", dtnowUpdate));




                foreach (Series p in seriesCursor)
                {


                    if (updatecounter % 10000 == 0)
                    {
                        Console.WriteLine(DateTime.Now.ToString() + " Total " + loadCollectionLogging + " Updated: " + updatecounter.ToString());
                        fileLogLoad.Write("Total " + loadCollectionLogging + " Updated: " + updatecounter.ToString(), FileLogRepository.Level.INFO);
                    }

                    String tempSeriesID = p.SeriesID;
                    RedundantSeriesData redundandseries = new RedundantSeriesData();
                    redundandseries.Name = p.Name;
                    redundandseries.Author = p.Author;
                    redundandseries.Format = p.Format;
                    redundandseries.Publisher = p.Publisher;
                    redundandseries.Distributor = p.Distributor;
                    redundandseries.Frequency = p.Frequency;
                    redundandseries.Programs = p.Programs;
                    redundandseries.AreasOfInterest = p.AreasOfInterest;
                    redundandseries.Audience = p.Audience;
                    redundandseries.Status = p.Status;
                    redundandseries.HasRelatedSeries = p.HasRelatedSeries;
                    redundandseries.RelatedSeriesIDs = p.RelatedSeriesIDs;
                    redundandseries.HasBindingPreferences = p.HasBindingPreferences;

                    redundandseries.BindingPreferences = p.BindingPreferences;
                    redundandseries.ForthcomingTitles = p.ForthcomingTitles;

                    //redundantseries.Audence fields don't match up type wise and don't think we need to load
                    //redundandseries.RequestStatus = p.Status;  fields don't match up. 
                    LatestIssueInformation latestissueinformation = new LatestIssueInformation();
                    latestissueinformation.BTKey = p.LatestIssueInformation.BTKey;
                    latestissueinformation.ISBN = p.LatestIssueInformation.ISBN;
                    latestissueinformation.ListPrice = p.LatestIssueInformation.ListPrice;
                    latestissueinformation.PublicationDate = p.LatestIssueInformation.PublicationDate;
                    latestissueinformation.Edition = p.LatestIssueInformation.Edition;
                    latestissueinformation.Title = p.LatestIssueInformation.Title;
                    latestissueinformation.Author = p.LatestIssueInformation.Author;
                    redundandseries.LatestIssueInformation = latestissueinformation;
                    
                    FootprintInformation footprintinformation = new FootprintInformation();
                    footprintinformation.CreatedBy = p.FootprintInformation.CreatedBy;
                    footprintinformation.CreatedDate = p.FootprintInformation.CreatedDate;
                    footprintinformation.UpdatedBy = p.FootprintInformation.UpdatedBy;
                    footprintinformation.UpdatedDate = p.FootprintInformation.UpdatedDate;
                    redundandseries.FootprintInformation = footprintinformation;

                    Int64 upsertCounterOut = 0;


                    if (AppSetting.RunDeltaorFullCompassLoad == "Full") {

                        var builder = Builders<BsonDocument>.Filter;
                        var builderUpdate = Builders<BsonDocument>.Update;

                        var query = builder.Eq("SeriesID", tempSeriesID);
                        var update = builderUpdate.Set("RedundantSeriesInformation", redundandseries.ToBsonDocument());

                        var model = mongoDBHelper.CreateWriteModel(query, update, true);
                        models.Add(model);

                        bulkWriteCount++;

                        if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                        {
                            var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiledSeries);
                            fileLogLoad.Write("\r\n" +
                                         "Bulk Batch Count: " +  bulkWriteResult.ModifiedCount,
                                 FileLogRepository.Level.INFO);

                            models = new List<WriteModel<BsonDocument>>();
                            bulkWriteCount = 0;

                        }
                    }
                    else
                    {
                        bool loadOK = LoadRedundantSeries(maxRetries2Save, RetryWait2, profiledSeries, redundandseries, fileLogLoad, tempSeriesID, out upsertCounterOut);
                        if (loadOK == true)
                        { insertcounter = insertcounter + upsertCounterOut; }
                        else
                        { totalSkipped++; }
                        updatecounter = insertcounter + totalSkipped;
                    }

                 
                }

                if (AppSetting.RunDeltaorFullCompassLoad == "Full") {
                    var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiledSeries);

                    fileLogLoad.Write("\r\n" + "Total Records Upserted: " + insertcounter, FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);
                
                }

                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Upserted: " + insertcounter);
                    Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Skipped: " + totalSkipped);
                    Console.WriteLine(DateTime.Now.ToString() + " End Update " + loadCollectionLogging);

                    fileLogLoad.Write("\r\n" + "Total Records Upserted: " + insertcounter + "\r\n"
                                                                         + "Total Records Skipped: " + totalSkipped + "\r\n"
                                                                         + "End Update " + loadCollectionLogging, FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                }


            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
        }


        public bool LoadRedundantSeries(int maxRetries2Save, int RetryWait2, MongoCollection<ProfiledSeries> profiledseries, RedundantSeriesData redundantseriesTEMP, FileLogRepository fileLogLoad, string tempSeriesID, out Int64 upsertCounterOut)
        {
            //*********************************************************************
            // INSERT / UPDATE Portion 
            //*********************************************************************
            _azureSearchQueueHelper = new AzureSearchQueueHelper(AppSetting.MongoDatabaseConnectionString, Convert.ToInt32(AppSetting.RetryWait), Convert.ToInt32(AppSetting.RetryTimes));
            int azurePriorityProfiledSeries = Convert.ToInt32(AppSetting.AzurePriorityProfiledSeries);
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int32 maxRetries2 = maxRetries2Save;
            Int64 upsertCounter = 0; 

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;
                    
                    Int64  resultUpdateProfiledSeriesCount = 0; 
                    Int64  resultCheckProfiledSeriesCount = 0;

                    // This part is to avoid creating an empty redundant set of data when the series does not exist... 
                    var resultCheckProfiledSeries = profiledseries.Find(Query.EQ("SeriesID", tempSeriesID)).ToList();
                    resultCheckProfiledSeriesCount = resultCheckProfiledSeries.Count();

                    if (resultCheckProfiledSeriesCount != 0)
                    {
                        var flags = UpdateFlags.Upsert | UpdateFlags.Multi;
                        var resultUpdateProfiledSeries = profiledseries.Update((Query.EQ("SeriesID", tempSeriesID)), Update.Set("RedundantSeriesInformation", redundantseriesTEMP.ToBsonDocument()), flags);
                        resultUpdateProfiledSeriesCount = resultUpdateProfiledSeries.DocumentsAffected;
                        fileLogLoad.Write("Series# Upserted: " + tempSeriesID + " / "  + resultUpdateProfiledSeriesCount, FileLogRepository.Level.INFO);
                        LoadOK = true;
                        upsertCounter = resultUpdateProfiledSeriesCount;


                        if (LoadOK == true)
                        {
                            _azureSearchQueueHelper.UpdateAzureSearchQueue(resultCheckProfiledSeries.Select(x => x.ProfiledSeriesID.ToString()).ToList(), AppSetting.MongoCollectionProfiledSeries, "Upsert", "CL", azurePriorityProfiledSeries);
                        }
                       
                    } 
                    else
                    {
                        fileLogLoad.Write("Series# Skipped: " + tempSeriesID, FileLogRepository.Level.INFO);
                    }
                    maxRetries2 = 0;
                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            upsertCounterOut = upsertCounter; 
            return LoadOK;
        }
    }
}
