﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Data.DAL;
using BT.TS360.NoSQL.Data.Common.Constants; 
using BT.TS360.NoSQL.Services.Compass.Services;
//using BT.TS360.NoSQL.Services.Compass.Services.Repository; 
using BT.TS360.NoSQL.Services.Compass.Helper;





namespace BT.TS360.NoSQL.Services.Compass.Services
{
    public class CompassLoad05SeriesBindingPreferences
    {
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        public CompassLoad05SeriesBindingPreferences()
        {
        }
        //old
        public void Load(string StoredProcedureName, string LoadType)
        {
            var models = new List<WriteModel<BsonDocument>>();

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);

            String loadCollection = "BindingPreferences";
            String loadCollectionLogging = "Series/BindingPreferences";

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);


            DateTime dtNow = DateTime.Now;
            DateTime dtnowDelete = DateTime.Today.AddDays(-30);

            Console.WriteLine(DateTime.Now.ToString() + " Open Connection and Extracting Compass Data-" + loadCollectionLogging);
            fileLogLoad.Write("Open Connection and Extracting Compass Data-" + loadCollectionLogging, FileLogRepository.Level.INFO);



            var dataConnect = ConfigurationManager.ConnectionStrings["Compass"].ConnectionString;
            SqlConnection CompassConnection = new SqlConnection(dataConnect);

            SqlDataReader dr = null;
            try
            {

                //old
                SqlCommand storedProc = new SqlCommand(StoredProcedureName, CompassConnection);
                storedProc.CommandType = CommandType.StoredProcedure;
                storedProc.CommandTimeout = Convert.ToInt32(AppSetting.CompassSQLCommandTimeout);

                CompassConnection.Open();
                dr = storedProc.ExecuteReader();

                Console.WriteLine(DateTime.Now.ToString() + " Done Extracting Compass Data");
                fileLogLoad.Write("Done Extracting Compass Data", FileLogRepository.Level.INFO);

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection series = mongodatabase.GetCollection(AppSetting.MongoCollectionSeries);

                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");


                Int64 totalcounter = 0;
                Int64 updatecounter = 0;
                Int64 insertcounter = 0;
                Int64 totalSkipped = 0;
                int bulkWriteCount = 0;

                if (dr.HasRows == true)
                {

                    Console.WriteLine(DateTime.Now.ToString() + " Looping through the Compass - " + loadCollectionLogging + " Results.");
                    fileLogLoad.Write("Looping through the Compass - " + loadCollectionLogging + " Results.", FileLogRepository.Level.INFO);


                    int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
                    int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries1Save = Convert.ToInt32(maxRetries1);
                    int maxRetries2Save = Convert.ToInt32(maxRetries2);
                    int maxRetries3Save = Convert.ToInt32(maxRetries3);



                    while (dr.Read())
                    {
                        Boolean bypassbaddataflag = false;
                        totalcounter = totalcounter + 1;

                        //define and assign fields from recordset here. 
                        String RowValueOut = null;
                        String tempSeriesID = null;

                        String ValidateFor = "SeriesBindingPreferences";
                        ValidateFor = "SeriesBindingPreferences";

                        //  Check for nulls. 
                        Repository poValidate = new Repository();
                        bool isValid = Repository.ValidateFields(dr, ValidateFor, out RowValueOut);

                        if (isValid == false)
                        {
                            bypassbaddataflag = true;
                            Console.WriteLine(DateTime.Now.ToString() + " Bad data returned from Compass(" + RowValueOut + ")");
                            fileLogLoad.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);
                            Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, AppSetting.MongoCollectionProfiledSeries, "ValidationError:" + RowValueOut, fileLogLoad);
                            //fileError1.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);  
                        }



                        if (totalcounter % 10000 == 0)
                        {
                            Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: " + totalcounter.ToString());
                            fileLogLoad.Write("Total Record Count: " + totalcounter.ToString(), FileLogRepository.Level.INFO);
                        }




                        if (bypassbaddataflag == false)
                        {  // Assign all fields from dr to class
                            //This is my workaround to get the id from Mongo. 
                            tempSeriesID = Convert.ToString(dr.GetInt32(0));
                            //var mycursor2 = profilesXXX.FindAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", tempERPAccountNumber));
                            //var mycursor2count = mycursor2.Count();
                            //if (mycursor2count != 0)
                            //{
                            //    foreach (ProfilesIDClass pp in mycursor2)
                            //    {




                            BindingPreference tempBindingPreference = new BindingPreference();

                            tempBindingPreference.Literal = Convert.ToString(dr.GetString(1));
                            tempBindingPreference.PrimaryPreference = Convert.ToString(dr.GetString(2));
                            if (!dr.IsDBNull(3)) { tempBindingPreference.SecondaryPreference = Convert.ToString(dr.GetString(3)); }
                            tempBindingPreference.HasMultiplePreference = dr.GetBoolean(4);

                            if (LoadType == "Full")
                            {
                                var builder = Builders<BsonDocument>.Filter;
                                var builderUpdate = Builders<BsonDocument>.Update;

                                var query = builder.And(builder.Eq("SeriesID", tempSeriesID), builder.Exists("SeriesID"));

                                var update = builderUpdate.AddToSet("BindingPreferences", tempBindingPreference.ToBsonDocument());

                                var model = mongoDBHelper.CreateWriteModel(query, update, false);
                                models.Add(model);

                                bulkWriteCount++;

                                if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                                {
                                    var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionSeries);
                                    fileLogLoad.Write("\r\n" +
                                                 "Bulk Batch Count: " +  bulkWriteResult.ModifiedCount,
                                         FileLogRepository.Level.INFO);

                                    models = new List<WriteModel<BsonDocument>>();
                                    bulkWriteCount = 0;

                                }
                            }
                            else
                            {
                                string loadOKTypeOut = "";

                                bool loadOK = LoadBindingPreferencesData(maxRetries2Save, RetryWait2, series, tempSeriesID, tempBindingPreference, fileLogLoad, out loadOKTypeOut);
                                if (loadOK == true)
                                {
                                    if (loadOKTypeOut == "Insert")
                                    { insertcounter++; }
                                    else { updatecounter++; }
                                }
                                else
                                {
                                    totalSkipped++;
                                    Console.WriteLine(DateTime.Now.ToString() + " Unable to load " + loadCollectionLogging + ", series skipped(" + tempSeriesID + ")");
                                    fileLogLoad.Write("Unable to load " + loadCollectionLogging + ", series skipped(" + tempSeriesID + ")", FileLogRepository.Level.INFO);

                                }
                            }

                            //}
                            //}
                            //    }
                            //}
                            //else
                            //{
                            //    bypassbaddataflag = false;
                            //    totalSkipped++;
                            //}


                        }
                        else
                        {
                            bypassbaddataflag = false;
                            totalSkipped++;
                        }

                    } //while dr.read
                }
                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: 0  --- No data returned from Compass");
                    fileLogLoad.Write("Total Record Count: 0  --- No data returned from Compass", FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

                }
                if (LoadType == "Full")
                {
                    var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionSeries);
                    fileLogLoad.Write("\r\n" +
                                     "Bulk Record Count: " +  bulkWriteResult.ModifiedCount,
                    FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);
                }
                else
                {

                    fileLogLoad.Write("\r\n" +
                        "Total Record Count: " + "\r\n" + totalcounter + "\r\n" +
                        "Total Insert Count: " + insertcounter + "\r\n" +
                        "Total Update Count: " + updatecounter + "\r\n" +
                        "Total Skips  Count: " + totalSkipped,
                          FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception(ex.Message);

            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }










        public static bool LoadBindingPreferencesData(int maxRetries2Save, int RetryWait2, MongoCollection series, String tempSeriesID, BindingPreference tempBindingPreference, FileLogRepository fileLogLoad, out string loadOKTypeOut)
        {
            //*********************************************************************
            // INSERT / UPDATE Portion 
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int64 resultInsertCount2 = 0;
            Int64 resultCheckProfiledSeriesPOCount = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;
                    //try updating first...  this update is flawed in that the footprint dates get overwrote 
                    var resultUpdateProfiles = series.Update(Query.And(Query.EQ("SeriesID", tempSeriesID),
                                                                               Query.ElemMatch("BindingPreferences",
                                                                                  (Query.EQ("Literal", tempBindingPreference.Literal)))
                                                                               ), Update.Set("BindingPreferences.$", tempBindingPreference.ToBsonDocument()), UpdateFlags.None);
                    resultUpdateCount2 = resultUpdateProfiles.DocumentsAffected;

                    if (resultUpdateCount2 == 0)
                    {   //try inserting second
                        var QueryInsertSQL = Query.And(Query.EQ("SeriesID", tempSeriesID), Query.Exists("SeriesID"));
                        //Query.EQ("ProfileID", tempProfileID);
                        var UpdateInsertSQL = Update.AddToSet("BindingPreferences", tempBindingPreference.ToBsonDocument());
                        var resultInsertPO = series.Update(QueryInsertSQL, UpdateInsertSQL, UpdateFlags.Upsert, null);
                        resultInsertCount2 = resultInsertPO.DocumentsAffected;
                        if (resultInsertCount2 != 0)
                        { loadOkayType = "Insert"; }
                    }
                    else { loadOkayType = "Update"; }


                    if (resultUpdateCount2 != 0 || resultInsertCount2 != 0)
                    { LoadOK = true; }

                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            loadOKTypeOut = loadOkayType;
            return LoadOK;

        }
  

        public static bool LoadBindingPreferencesDataOLD(int maxRetries2Save, int RetryWait2, MongoCollection series, string tempSeriesID, String tempBindingPreferences, FileLogRepository fileLogLoad, out string loadOKTypeOut)
        {
            //*********************************************************************
            // INSERT / UPDATE Portion 
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false; 
            Int64 resultUpdateCount2 = 0;
            //Int64 = maxRetries2Save; 
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = ""; 

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;


                    var resultUpdateSeries = series.Update(Query.And(Query.EQ("SeriesID", tempSeriesID), Query.NE("BindingPreferences", tempBindingPreferences)), Update.AddToSet("BindingPreferences", tempBindingPreferences), UpdateFlags.None);
                    resultUpdateCount2 = resultUpdateSeries.DocumentsAffected;


                    if (resultUpdateCount2 != 0)
                    {
                        if (resultUpdateSeries.UpdatedExisting == false)
                        { loadOkayType = "Insert"; }
                        else
                        { loadOkayType = "Update"; }
                        LoadOK = true;
                    }
            


                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            loadOKTypeOut = loadOkayType; 
            return LoadOK;

        }
    }
}
