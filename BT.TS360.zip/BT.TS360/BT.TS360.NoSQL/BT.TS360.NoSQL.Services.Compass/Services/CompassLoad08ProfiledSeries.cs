﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Data.DAL;
//using BT.TS360.Services.Compass; 
using BT.TS360.NoSQL.Data.Common.Constants; 
using BT.TS360.NoSQL.Services.Compass.Services;
//using BT.TS360.NoSQL.Services.Compass.Services.Repository; 
using BT.TS360.Services.Compass;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Services.Compass.Helper;




namespace BT.TS360.NoSQL.Services.Compass.Services
{
    public class CompassLoad08ProfiledSeries
    {
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        public CompassLoad08ProfiledSeries()
        {
        }
        //old
        public void Load(string StoredProcedureName, string LoadType)
        {
            var models = new List<WriteModel<BsonDocument>>();

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);

            String loadCollection = AppSetting.MongoCollectionProfiledSeries;
            String loadCollectionLogging = AppSetting.MongoCollectionProfiledSeries;
            String loadAction = null;
            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

            //GET ODS Data
            Console.WriteLine(DateTime.Now.ToString() + " Open Connection and Extracting Compass Data-" + loadCollectionLogging);
            fileLogLoad.Write("Open Connection and Extracting Compass Data-" + loadCollectionLogging, FileLogRepository.Level.INFO);

            int azurePriorityProfiledSeries = Convert.ToInt32(AppSetting.AzurePriorityProfiledSeries);

            var dataConnect = ConfigurationManager.ConnectionStrings["Compass"].ConnectionString;
            //old
            SqlConnection CompassConnection = new SqlConnection(dataConnect);
            //new
            //DBTransactionODSDAO dbTransactionODSDAO = new DBTransactionODSDAO(dataConnect);

            SqlDataReader dr = null;
            try
            {

                //old
                SqlCommand storedProc = new SqlCommand(StoredProcedureName, CompassConnection);
                storedProc.CommandType = CommandType.StoredProcedure;
                storedProc.CommandTimeout = Convert.ToInt32(AppSetting.CompassSQLCommandTimeout);

                if (LoadType == "Delta")
                {
                    int daysBackDelta = Convert.ToInt32(AppSetting.DeltaDaysBack);
                    DateTime dtnowDelta = DateTime.Today.AddDays(daysBackDelta);
                    SqlParameter DateTimeIn = storedProc.Parameters.Add("@fromdatetime", SqlDbType.DateTime);
                    DateTimeIn.Direction = ParameterDirection.Input;
                    DateTimeIn.Value = dtnowDelta;
                }

                CompassConnection.Open();
                dr = storedProc.ExecuteReader();



                Console.WriteLine(DateTime.Now.ToString() + " Done Extracting Compass Data for " + loadCollectionLogging);
                fileLogLoad.Write("Done Extracting Compass Data for " + loadCollectionLogging, FileLogRepository.Level.INFO);

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection profiledseries = mongodatabase.GetCollection(AppSetting.MongoCollectionProfiledSeries);
                MongoCollection changerequests = mongodatabase.GetCollection("ChangeRequests");

                //Source collection for _id
                MongoCollection profilesXXX = mongodatabase.GetCollection(AppSetting.MongoCollectionProfiles);  ////This is my workaround to get the id from Mongo. 

                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");
                MongoCollection azuresearch = commonDatabase.GetCollection(AppSetting.MongoCollectionAzureQueue);


                if (dr.HasRows == true)
                {

                    Console.WriteLine(DateTime.Now.ToString() + " Looping through the Compass - " + loadCollectionLogging + " Results.");
                    fileLogLoad.Write("Looping through the Compass - " + loadCollectionLogging + " Results.", FileLogRepository.Level.INFO);
                    Int64 totalcounter = 0;
                    Int64 updatecounter = 0;
                    Int64 insertcounter = 0;
                    Int64 totalSkipped = 0;
                    int bulkWriteCount = 0;

                    int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
                    int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries1Save = Convert.ToInt32(maxRetries1);
                    int maxRetries2Save = Convert.ToInt32(maxRetries2);
                    int maxRetries3Save = Convert.ToInt32(maxRetries3);

                    while (dr.Read())
                    {
                        Boolean bypassbaddataflag = false;
                        totalcounter = totalcounter + 1;


                        //define and assign fields from recordset here. 
                        String tempERPAccountNumber = null;
                        String RowValueOut = null;

                        //  Check for nulls. 
                        Repository poValidate = new Repository();
                        bool isValid = Repository.ValidateFields(dr, "ProfiledSeries", out RowValueOut);


                        if (isValid == false)
                        {
                            bypassbaddataflag = true;
                            Console.WriteLine(DateTime.Now.ToString() + " Bad data returned from Compass(" + RowValueOut + ")");
                            fileLogLoad.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);
                            Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, AppSetting.MongoCollectionProfiledSeries, "ValidationError:" + RowValueOut, fileLogLoad);
                        }

                        if (totalcounter % 10000 == 0)
                        {
                            Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: " + totalcounter.ToString());
                            fileLogLoad.Write("Total Record Count: " + totalcounter.ToString(), FileLogRepository.Level.INFO);
                        }



                        if (bypassbaddataflag == false)
                        {  // Assign all fields from dr to class

                            //This is my workaround to get the id from Mongo. 
                            ObjectId profilesid;
                            tempERPAccountNumber = dr.GetString(0);
                            var mycursor2 = profilesXXX.FindAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", tempERPAccountNumber));
                            var mycursor2count = mycursor2.Count();
                            if (mycursor2count != 0)
                            {
                                ProfiledSeries profiledseriesTEMP = new ProfiledSeries();
                                foreach (ProfilesIDClass pp in mycursor2)
                                {

                                    profiledseriesTEMP.SeriesID = Convert.ToString(dr.GetInt32(1));
                                    profiledseriesTEMP.ProfileID = pp._id;

                                    if (!dr.IsDBNull(2)) { profiledseriesTEMP.TotalPrimaryQuantity = dr.GetInt32(2); }
                                    if (!dr.IsDBNull(3))
                                    { loadAction = dr.GetString(3); }
                                    else
                                        throw new Exception("Missing Action Type, this is a required field");

                                    FootprintInformation footprintinformation = new FootprintInformation();
                                    footprintinformation.CreatedBy = "cl";
                                    footprintinformation.CreatedDate = DateTime.Now;
                                    footprintinformation.UpdatedBy = "cl";
                                    footprintinformation.UpdatedDate = DateTime.Now;

                                    profiledseriesTEMP.FootprintInformation = footprintinformation;
                                }
                                if (LoadType == "Delta")
                                {
                                    if (loadAction == "A" || loadAction == "M" || loadAction == "D")
                                    { // do nothing}}
                                    }
                                    else
                                    {
                                        throw new Exception("Invalid Action Type, this is a required field");
                                    }
                                }

                                if (LoadType == "Full" || LoadType == "Delta")
                                {
                                    //do nothing
                                }
                                else
                                {
                                    throw new Exception("Invalid Load Type, this must be either Delta or Full");
                                }
                                //
                                if ((LoadType == "Full") || (LoadType == "Delta" && (loadAction == "A" || loadAction == "M")))
                                {
                                    //**********************************************************************
                                    //INSERT / UPDATE PORTION - FOR PROFILE SERIES ONLY
                                    //**********************************************************************

                                    var update = new UpdateDocument { };
                                    update = new UpdateDocument { { "$set", profiledseriesTEMP.ToBsonDocument() } };

                                    if (LoadType == "Full")
                                    {

                                        var builder = Builders<BsonDocument>.Filter;
                                        var query = (builder.And(builder.Eq("ProfileID", profiledseriesTEMP.ProfileID),
                                                                builder.Eq("SeriesID", profiledseriesTEMP.SeriesID)));

                                        var model = mongoDBHelper.CreateWriteModel(query, update, true);
                                        models.Add(model);

                                        bulkWriteCount++;

                                        if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                                        {
                                            var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiledSeries);
                                            fileLogLoad.Write("\r\n" +
                                                         "Bulk Batch Count: " + bulkWriteResult.ModifiedCount,
                                                 FileLogRepository.Level.INFO);

                                            models = new List<WriteModel<BsonDocument>>();
                                            bulkWriteCount = 0;

                                        }
                                    }
                                    else
                                    {

                                        Boolean exceptionFlag2 = false;
                                        maxRetries2 = maxRetries2Save;
                                        while (maxRetries2 > 0)
                                        {
                                            try
                                            {


                                                exceptionFlag2 = false;
                                                var query = new QueryDocument { };
                                                var query2 = (Query.And(Query.EQ("ProfileID", profiledseriesTEMP.ProfileID),
                                                                        Query.EQ("SeriesID", profiledseriesTEMP.SeriesID)));

                                                var resultInsertSeries = profiledseries.Update(query2, update, UpdateFlags.Upsert, null);
                                                var resultInsertSeriesCount = resultInsertSeries.DocumentsAffected;
                                                maxRetries2 = 0;
                                                if (resultInsertSeriesCount != 0)
                                                {
                                                    if (resultInsertSeries.UpdatedExisting == false)
                                                    { insertcounter++; }
                                                    else
                                                    { updatecounter++; }

                                                    //call update to azure
                                                    var tempProfiledSeriesID = profiledseries.FindOneAs<ProfiledSeriesIDClass>(Query.And(Query.EQ("ProfileID", profiledseriesTEMP.ProfileID),
                                                                                                                                        Query.EQ("SeriesID", profiledseriesTEMP.SeriesID)));
                                                    ObjectId profiledseriesid = tempProfiledSeriesID._id;
                                                    bool loadOK = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, profiledseriesid, fileLogLoad, AppSetting.MongoCollectionProfiledSeries, "Upsert", azurePriorityProfiledSeries);

                                                }
                                                else
                                                { totalSkipped++; }



                                            }
                                            catch (Exception ex2)
                                            {
                                                exceptionFlag2 = true;
                                                maxRetries2--;
                                                Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex2.Message);
                                                fileLogLoad.Write("..CompassLoad Save Failure " + ex2.Message, FileLogRepository.Level.ERROR);
                                                System.Threading.Thread.Sleep(RetryWait2);
                                                continue;
                                            }
                                        }
                                        if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
                                    }
                                    if (LoadType == "Delta")
                                    {

                                        //**********************************************************************
                                        //UPDATE PORTION - FOR PROFILEDSERIES ONLY
                                        //ANY "A" OR "M" ACTION TYPES will mean  we need to clear the existing subdocuments.
                                        //**********************************************************************
                                        bool loadOK = RemoveProfiledSeriesSubDocument(maxRetries2Save, RetryWait2, profiledseries, profiledseriesTEMP.ProfileID, profiledseriesTEMP.SeriesID, fileLogLoad);

                                        ////***********************************************************************  
                                        ////ChangeRequest Logic // Moved to CompassLoad09ProfiledSeriesPO PBI:32452
                                        ////***********************************************************************
                                       


                                    }

                                }
                                else
                                {   //***********************************************************************
                                    //DELETE PORTION - FOR PROFILEDSERIES ONLY
                                    //This delete is for a delta load where the ACTION TYPE will equal "D"
                                    //***********************************************************************

                                    //***********************************************************************
                                    //Azure 
                                    //***********************************************************************
                                    var tempProfiledSeriesID = profiledseries.FindOneAs<ProfiledSeriesIDClass>(Query.And(Query.EQ("ProfileID", profiledseriesTEMP.ProfileID),
                                                                                                                        Query.EQ("SeriesID", profiledseriesTEMP.SeriesID)));

                                    if (tempProfiledSeriesID != null)
                                    {
                                        ObjectId profiledseriesid = tempProfiledSeriesID._id;
                                        bool loadOKAzure = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, profiledseriesid, fileLogLoad, AppSetting.MongoCollectionProfiledSeries, "Delete", azurePriorityProfiledSeries);


                                        bool loadOK = RemoveProfiledSeriesDocument(maxRetries2Save, RetryWait2, profiledseries, profiledseriesTEMP.ProfileID, profiledseriesTEMP.SeriesID, fileLogLoad);

                                        //***********************************************************************  
                                        //ChangeRequest Logic
                                        //***********************************************************************
                                        ChangeRequests changerequestsTEMP = new ChangeRequests();
                                        var queryUpdateChangeRequestDeletes = (Query.And(Query.EQ("ProfiledSeriesChangeRequest.SeriesID", profiledseriesTEMP.SeriesID),
                                                                                         Query.EQ("ProfileID", profiledseriesTEMP.ProfileID),
                                                                                         Query.EQ("RequestStatus", "Completed"),
                                                                                         Query.EQ("RequestType", "Delete")));
                                        var updateUpdateChangeRequestDeletes = Update.Set("RequestStatus", "Deleted")
                                                                                     .Set("FootprintInformation.UpdatedBy", "cl")
                                                                                     .Set("FootprintInformation.UpdatedDate", DateTime.Now);

                                        var resultUpdateChangeRequestDeletes = changerequests.Update(queryUpdateChangeRequestDeletes, updateUpdateChangeRequestDeletes, UpdateFlags.None, null);
                                    }
                                    else
                                    {
                                        Console.WriteLine(DateTime.Now.ToString() + "Unable to do delete for the following Profile and Series Combinations: " + profiledseriesTEMP.ProfileID.ToString() + " " + profiledseriesTEMP.SeriesID.ToString());
                                    }

                                }




                                //}
                            }
                            else
                            {
                                bypassbaddataflag = false;
                                totalSkipped++;

                            }
                        }
                        else
                        {
                            bypassbaddataflag = false;
                            totalSkipped++;

                        }

                    }

                    if (LoadType == "Full")
                    {
                        var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiledSeries);
                        fileLogLoad.Write("\r\n" +
                                         "Bulk Record Count: " + bulkWriteResult.ModifiedCount,
                        FileLogRepository.Level.INFO);

                        var createFullAzureQueue = mongoDBHelper.CreateFullAzureQueue(AppSetting.MongoCollectionProfiledSeries);

                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);
                    }
                    else
                    {
                        fileLogLoad.Write("\r\n" +
                                        "Total Record Count: " + "\r\n" + totalcounter + "\r\n" +
                                        "Total Insert Count: " + insertcounter + "\r\n" +
                                        "Total Update Count: " + updatecounter + "\r\n" +
                                        "Total Skips  Count: " + totalSkipped,
                            FileLogRepository.Level.INFO);
                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                    }


                }

                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: 0  --- No data returned from Compass");
                    fileLogLoad.Write("Total Record Count: 0  --- No data returned from Compass", FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception(ex.Message);

            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }


         public static bool RemoveProfiledSeriesDocument(int maxRetries2Save, int RetryWait2, MongoCollection profiledseries ,ObjectId  tempProfileID, string tempSeriesID, FileLogRepository fileLogLoad)

        {
            //*********************************************************************
            // Delete document
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;

                    //var querya = new QueryDocument { };
                    var update1 = new UpdateDocument { };
                    var query1 = (Query.And(Query.EQ("ProfileID", tempProfileID ),
                                            Query.EQ("SeriesID", tempSeriesID)));
                    //update1 = new UpdateDocument { { "$set", profiledseriesTEMP.ToBsonDocument() } };
                    //var resultInsertSeries1 = profiledseriesTEMP.Drop();

                    var resultOfDrop = profiledseries.Remove(query1); 


                    //var resultUpdateSeries = series.Update(Query.And(Query.EQ("SeriesID", tempSeriesID), Query.NE("BindingPreferences", tempBindingPreferences)), Update.AddToSet("BindingPreferences", tempBindingPreferences), UpdateFlags.None);
                    var resultOfDropCount = resultOfDrop.DocumentsAffected;


                    if (resultOfDropCount != 0)
                    {
                        LoadOK = true;
                    }

                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            //loadOKTypeOut = loadOkayType;
            return LoadOK;

        }


         public static bool RemoveProfiledSeriesSubDocument(int maxRetries2Save, int RetryWait2, MongoCollection profiledseries, ObjectId tempProfileID, string tempSeriesID, FileLogRepository fileLogLoad)
         {
             //*********************************************************************
             // Delete sub document
             //*********************************************************************
             Boolean exceptionFlag2 = false;
             Boolean LoadOK = false;
             Int64 resultUpdateCount2 = 0;
             Int32 maxRetries2 = maxRetries2Save;
             String loadOkayType = "";

             while (maxRetries2 > 0)
             {
                 try
                 {
                     exceptionFlag2 = false;


                     var querydelete = (Query.And(Query.EQ("ProfileID", tempProfileID),
                                                 Query.EQ("SeriesID", tempSeriesID)));

                     var updatedelete = Update.Unset("PurchaseOrders");
                     var resultDeletes = profiledseries.Update(querydelete, updatedelete, UpdateFlags.Multi);

                     //fileLogLoad.Write("Delete Result for ProfileID/SeriesID: " + "(" + tempProfileID.ToString() + "/" + tempSeriesID  + "): Documents affected --" + resultDeletes.DocumentsAffected.ToString(), FileLogRepository.Level.INFO );

                     LoadOK = true; 
                     maxRetries2 = 0;


                 }
                 catch (Exception ex1)
                 {
                     exceptionFlag2 = true;
                     maxRetries2--;
                     Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Delete Failure " + ex1.Message);
                     fileLogLoad.Write("..CompassLoad Delete Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                     System.Threading.Thread.Sleep(RetryWait2);
                     continue;
                 }
             }
             if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
             return LoadOK;

         }


         public static bool UpdateChangeRequests(int maxRetriesSave, int RetryWait, MongoCollection changerequests, ObjectId tempProfileID, string tempSeriesID, FileLogRepository fileLogLoad)
         {
             Boolean exceptionFlag2 = false;
             Boolean LoadOK = false;
             Int32 maxRetries = maxRetriesSave;

             ChangeRequests changerequestsTEMP = new ChangeRequests();
             var queryChangeRequest = (Query.And(Query.EQ("ProfiledSeriesChangeRequest.SeriesID", tempSeriesID),
                                        Query.EQ("ProfileID", tempProfileID),
                                        Query.EQ("RequestStatus", "Completed"),
                                        Query.NE("RequestType", "Delete")));
             var updateChangeRequest = Update.Set("RequestStatus", "Loaded")
                                        .Set("FootprintInformation.UpdatedBy", "cl")
                                        .Set("FootprintInformation.UpdatedDate", DateTime.Now);

             while (maxRetries > 0)
             {
                 try
                 {
                     exceptionFlag2 = false;

                     var resultUpdateChangeRequestDeletes = changerequests.Update(queryChangeRequest, updateChangeRequest, UpdateFlags.None, null);

                     var resultUpdateCount = resultUpdateChangeRequestDeletes.DocumentsAffected;

                     if (resultUpdateCount > 0) { LoadOK = true; }

                     maxRetries = 0;



                 }
                 catch (Exception ex1)
                 {
                     exceptionFlag2 = true;
                     maxRetries--;
                     Console.WriteLine(DateTime.Now.ToString() + " ..ChangeRequest Update Failure for ProfileID: " + tempProfileID + " and SeriesID:" + tempSeriesID + " -- " + ex1.Message);
                     fileLogLoad.Write(" ..ChangeRequest Update Failure for ProfileID: " + tempProfileID + " and SeriesID:" + tempSeriesID + " -- " + ex1.Message, FileLogRepository.Level.ERROR);
                     System.Threading.Thread.Sleep(RetryWait);
                     continue;
                 }
             }
             if (exceptionFlag2 == true && maxRetries == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
             return LoadOK;

         }


         public static bool UpdateRequestStatus(int maxRetriesSave, int RetryWait, MongoCollection profiledseries, ObjectId tempProfileID, string tempSeriesID, FileLogRepository fileLogLoad)
         {
             Boolean exceptionFlag2 = false;
             Boolean LoadOK = false;
             Int32 maxRetries = maxRetriesSave;

             var queryUpdateProfiledSeries2 = (Query.And(Query.EQ("ProfileID", tempProfileID),
                                              Query.EQ("SeriesID", tempSeriesID)));
             var updateUpdateProfiledSeries2 = Update.Unset("RequestStatus")
                                                     .Set("FootprintInformation.UpdatedBy", "cl")
                                                     .Set("FootprintInformation.UpdatedDate", DateTime.Now);

             while (maxRetries > 0)
             {
                 try
                 {
                     exceptionFlag2 = false;

                     var resultUpdateProfiledSeries2 = profiledseries.Update(queryUpdateProfiledSeries2, updateUpdateProfiledSeries2);

                     LoadOK = true;
                     maxRetries = 0;

                 }
                 catch (Exception ex1)
                 {
                     exceptionFlag2 = true;
                     maxRetries--;
                     Console.WriteLine(DateTime.Now.ToString() + " ..RequestStatus Update Failure for ProfileID: " + tempProfileID + " and SeriesID:" + tempSeriesID + " -- " + ex1.Message);
                     fileLogLoad.Write(" ..RequestStatus Update Failure for ProfileID: " + tempProfileID + " and SeriesID:" + tempSeriesID + " -- " + ex1.Message, FileLogRepository.Level.ERROR);
                     System.Threading.Thread.Sleep(RetryWait);
                     continue;
                 }
             }
             if (exceptionFlag2 == true && maxRetries == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
             return LoadOK;

         }



         public static bool UpdateAzureSearch(int maxRetries2Save, int RetryWait2, MongoCollection azuresearch, ObjectId tempobjectid, FileLogRepository fileLogLoad, String tempCollection, String tempChangetype, Int32 tempAzurePriority)
         {
             //*****************************************************************+++++****
             // Add to Azure Search Queue
             //*********************************************************************e
             Boolean exceptionFlag2 = false;
             Boolean LoadOK = false;
             Int64 resultUpdateCount2 = 0;
             Int32 maxRetries2 = maxRetries2Save;
             String loadOkayType = "";

             AzureSearchQueueItem azureTEMP = new AzureSearchQueueItem();
             azureTEMP.CollectionName = tempCollection;
             azureTEMP.ChangeType = tempChangetype;
             azureTEMP.ObjectId = tempobjectid;
             azureTEMP.Priority = tempAzurePriority;
             azureTEMP.InProcessState = 0;

             FootprintInformation footprintinformation = new FootprintInformation();
             footprintinformation.CreatedDate = DateTime.Now;
             footprintinformation.CreatedBy = "cl";
             footprintinformation.UpdatedDate = DateTime.Now;
             footprintinformation.UpdatedBy = "cl";

             azureTEMP.FootprintInformation = footprintinformation;



             while (maxRetries2 > 0)
             {
                 try
                 {
                     exceptionFlag2 = false;


                     //var query = new QueryDocument { { "ObjectId", tempobjectid } };
                     //var update = new UpdateDocument { { "$set", azureTEMP.ToBsonDocument() } };
                     //var resultUpsertAzure = azuresearch.Update(query, update, UpdateFlags.Upsert, null);
                     var resultUpsertAzure = azuresearch.Insert<AzureSearchQueueItem>(azureTEMP);
                     var resultUpsertAzureCount = resultUpsertAzure.DocumentsAffected;

                     //fileLogLoad.Write("Upsert Result for ObjectID: " + "(" + tempobjectid.ToString() + "/" + "): Documents affected --" + resultUpsertAzure.DocumentsAffected.ToString(), FileLogRepository.Level.INFO);

                     LoadOK = true;
                     maxRetries2 = 0;


                 }
                 catch (Exception ex1)
                 {
                     exceptionFlag2 = true;
                     maxRetries2--;
                     Console.WriteLine(DateTime.Now.ToString() + " ..AzureSearch Upsert Failure " + ex1.Message);
                     fileLogLoad.Write("..AzureSearch Upsert Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                     System.Threading.Thread.Sleep(RetryWait2);
                     continue;
                 }
             }
             if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
             return LoadOK;

         }

    }
}
