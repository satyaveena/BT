﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Services;
using BT.TS360.NoSQL.Services.Compass.Common;
using BTNextGen.Elmah;
using System.Timers;
using System.Configuration;
using System.IO; 
//using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Services.Common.Constants; 


namespace BT.TS360.NoSQL.Services.Compass.Services
{
    class CompassLoadMain
    {

       public CompassLoadMain()
        {
        }


       public void Main()
       {

           FileLogRepository fileLog = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);

           try
           {
               fileLog.Write("Starting Compass Main", FileLogRepository.Level.INFO);
               ConfigurationManager.RefreshSection("appSettings");
               string TimeToExecuteHour = AppSetting.TimeToExecuteHour;
               string TimeToExecuteHourCurrent = DateTime.Now.Hour.ToString();
               //CompassLoad09ProfiledSeriesPO compassloadPSPO = new CompassLoad09ProfiledSeriesPO();
               //compassloadPSPO.Load("usp_TS360_GetProfiledSeriesPO","Full"); 
               //CompassLoad08ProfiledSeries compassloadPS = new CompassLoad08ProfiledSeries();
               //compassloadPS.Load("usp_TS360_GetProfiledSeries","Full"); 

               //CompassLoad04SeriesAreaOfInterest compassloadprofilesareainterestx = new CompassLoad04SeriesAreaOfInterest();
               //compassloadprofilesareainterestx.Load(StoredProcedureName.TS360_GetSeriesAreaOfInterest, "Full");
               //CompassUpdateUpdateRedundantSeries compassupdateseries = new CompassUpdateUpdateRedundantSeries();
               //compassupdateseries.UpdateMe(); 
               //CompassUpdateUpdateRedundantProfiles compassupdateprofiles = new CompassUpdateUpdateRedundantProfiles();
               //compassupdateprofiles.UpdateMe(); 
           
               if (TimeToExecuteHour == TimeToExecuteHourCurrent)
               {
                   fileLog.Write("Execute hour equals current hour checking last date time", FileLogRepository.Level.INFO);
                   string TimeLastUpdated = AppSetting.TimeLastUpdated;
                   string TimeLastUpdatedCurrent = DateTime.Now.ToShortDateString();

                   if (TimeLastUpdated != TimeLastUpdatedCurrent)
                   {
                       System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                       config.AppSettings.Settings.Remove("TimeLastUpdated");
                       config.AppSettings.Settings.Add("TimeLastUpdated", TimeLastUpdatedCurrent);
                       config.Save(ConfigurationSaveMode.Modified);
                       ConfigurationManager.RefreshSection("appSettings");

                       string TimeLastUpdatedDBLCHK = AppSetting.TimeLastUpdated;

                       if (TimeLastUpdatedDBLCHK != TimeLastUpdatedCurrent)
                       { throw new Exception("Time Last Updated did not SAVE"); }



                       string x = DateTime.Now.Hour.ToString();


                       //Initialize Log File
                       //FileLogRepository fileLog = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
                       string logFileMessage = string.Empty;
                       Console.WriteLine(DateTime.Now.ToString() + " Begin Compass Load Main");
                       fileLog.Write("Begin Compass Load Main", FileLogRepository.Level.INFO);

                       string RunDeltaorFullCompassLoad = AppSetting.RunDeltaorFullCompassLoad;
                       if ((RunDeltaorFullCompassLoad.ToUpper() != "DELTA") && (RunDeltaorFullCompassLoad.ToUpper() != "FULL"))
                       {
                           { throw new Exception("Invalid Load Type passed: " + RunDeltaorFullCompassLoad); }
                       }

                       
                       //*****************************************************************************************************
                       // Profiles
                       //*****************************************************************************************************
                   
                       if (AppSetting.RunProfilesLoad == "true")
                       {

                           CompassLoad01Profiles compassloadprofiles = new CompassLoad01Profiles();
                           compassloadprofiles.Load(StoredProcedureName.TS360_GetProfiles, RunDeltaorFullCompassLoad);
                       }

                       if (AppSetting.RunProfilesProgramsLoad == "true")
                       {
                           CompassLoad02ProfilesPrograms compassloadprofilesprograms = new CompassLoad02ProfilesPrograms();
                           compassloadprofilesprograms.Load(StoredProcedureName.TS360_GetProfiledProgram, RunDeltaorFullCompassLoad);
                           
                       }
                       //*****************************************************************************************************
                       // Series
                       //*****************************************************************************************************

                       if (AppSetting.RunSeriesLoad == "true")
                       {

                           CompassLoad03Series compassloadseries = new CompassLoad03Series();
                           compassloadseries.Load(StoredProcedureName.TS360_GetSeries, RunDeltaorFullCompassLoad);
                       }

                       if (AppSetting.RunSeriesAreaOfInterestLoad == "true")
                       {

                           CompassLoad04SeriesAreaOfInterest compassloadprofilesareainterest = new CompassLoad04SeriesAreaOfInterest();
                           compassloadprofilesareainterest.Load(StoredProcedureName.TS360_GetSeriesAreaOfInterest, RunDeltaorFullCompassLoad);
                       }

                       if (AppSetting.RunSeriesForthcomingTitles == "true")
                       {
                           CompassLoadSeriesForthcomingTitles compassloadseriesforthingcomingtitles = new CompassLoadSeriesForthcomingTitles ();
                           compassloadseriesforthingcomingtitles.Load(StoredProcedureName.TS360_GetSeriesForthcomingTitles, RunDeltaorFullCompassLoad);
                       }		

                       //if (AppSetting.RunSeriesAudience == "true")
                       //{
                       //
                       //    CompassLoad04SeriesAudience compassloadseriesaudience = new CompassLoad04SeriesAudience();
                       //    compassloadseriesaudience.Load(StoredProcedureName.TS360_GetSeriesAudiences, RunDeltaorFullCompassLoad);
                       //}

                       if (AppSetting.RunSeriesBindingPreferenceLoad == "true")
                       {

                           CompassLoad05SeriesBindingPreferences compassloadseriesbindingprefer = new CompassLoad05SeriesBindingPreferences();
                           compassloadseriesbindingprefer.Load(StoredProcedureName.TS360GetSeriesBindingPreference, RunDeltaorFullCompassLoad);
                       }
                       if (AppSetting.RunSeriesRelatedSeriesLoad == "true")
                       {

                           CompassLoad06SeriesRelatedSeriesIDs compassloadseriesrelatedseries = new CompassLoad06SeriesRelatedSeriesIDs();
                           compassloadseriesrelatedseries.Load(StoredProcedureName.TS360GetSeriesRelatedSeries, RunDeltaorFullCompassLoad);
                       }

                       if (AppSetting.RunSeriesProgramTypeLoad == "true")
                       {
                           CompassLoad07SeriesPrograms compassloadseriesprograms = new CompassLoad07SeriesPrograms();
                           compassloadseriesprograms.Load(StoredProcedureName.TS360_GetSeriesPrograms, RunDeltaorFullCompassLoad);
                       }

                       //*****************************************************************************************************
                       // ProfiledSeries
                       //*****************************************************************************************************
                       if (AppSetting.RunProfilesSeriesLoad == "true")
                       {

                           CompassLoad08ProfiledSeries compassloadprofiledseries = new CompassLoad08ProfiledSeries();
                           compassloadprofiledseries.Load(StoredProcedureName.TS360_GetProfiledSeries, RunDeltaorFullCompassLoad);
                       }
                       if (AppSetting.RunProfiledSeriesPOLoad == "true")
                       {

                           CompassLoad09ProfiledSeriesPO compassloadprofiledseriespo = new CompassLoad09ProfiledSeriesPO();
                           compassloadprofiledseriespo.Load(StoredProcedureName.TS360_GetProfiledSeriesPO, RunDeltaorFullCompassLoad);
                       }
                       if (AppSetting.RunProfilesSeriesProfilesRedundantDataLoad == "true")
                       {
                           CompassLoad10ProfiledSeriesRedundantProfiles loadSeriesRedundantProfiles = new CompassLoad10ProfiledSeriesRedundantProfiles();
                           loadSeriesRedundantProfiles.Load();
                       }

                       if (AppSetting.RunProfilesSeriesSeriesRedundantDataLoad == "true")
                       {

                           CompassLoad11ProfiledSeriesRedundantSeries loadSeriesRedundantSeries = new CompassLoad11ProfiledSeriesRedundantSeries();
                           loadSeriesRedundantSeries.Load();

                       }
                       if (AppSetting.RunCompassLoadDelete == "true")
                       {
                           CompassLoad12Delete load12delete = new CompassLoad12Delete();
                           load12delete.Delete(StoredProcedureName.TS360_Delete);
                       }
                       //*****************************************************************************************************
                       //Send Success Email
                       //*****************************************************************************************************
                       Console.WriteLine(DateTime.Now.ToString() + " End Compass Load");
                       fileLog.Write("End Compass Load", FileLogRepository.Level.INFO);
   
                       if (AppSetting.EmailOnFailureErrors1 == "true") 
                       {
                           CompassLoadEmail compassloademail = new CompassLoadEmail();
                           compassloademail.ReadWrite();
                           string[] fileEntries = Directory.GetFiles(AppSetting.Errors1Folder);
                           if (fileEntries.Count() != 0 ) 
                           {EmailSomebody.SendEmailAttachments("CompassLoad Load Errors", "Main", "true", null, AppSetting.Errors1Folder, AppSetting.EmailToRecipientsErrors1, AppSetting.LogFolder);}
                       }
                   
                       if (AppSetting.EmailOnSuccess == "true") { EmailSomebody.SendEmail("CompassLoad Successful ", "Main", "true", null); }

                   }
                   else


                   { fileLog.Write("Execute date equal to current date, the process already ran today", FileLogRepository.Level.INFO); }


               }


               else { fileLog.Write("Execute hour NOT equal to current time, DO NOTHING", FileLogRepository.Level.INFO); }

               fileLog.Write("Ending Compass Main", FileLogRepository.Level.INFO);

           }


           catch (Exception ex)
           {
               if (AppSetting.EmailOnFailure == "true") { EmailSomebody.SendEmail("CompassLoad Failure " + ex.Message, "Main", "true", null); }
               Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Failure" + ex.Message);
               FileLogRepository fileLogexc = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
               fileLogexc.Write("..CompassLoad Failure " + ex.Message, FileLogRepository.Level.ERROR);

               if (AppSetting.EmailOnFailureErrors1 == "true")
               {
                   string[] fileEntries = Directory.GetFiles(AppSetting.Errors1Folder);
                   if (fileEntries.Count() != 0) 
                   { EmailSomebody.SendEmailAttachments("CompassLoad Load Errors", "Main", "true", null, AppSetting.Errors1Folder, AppSetting.EmailToRecipientsErrors1, AppSetting.LogFolder); }
               }

               //Elmah logging
               string Elmahconnection = AppSetting.ElmahConnectionString;
               var errorLog = new SqlErrorLog(Elmahconnection);
               errorLog.ApplicationName = "MongoDB-CompassLoad";
               var error = new Error(new Exception(ex.Message)); // please put the actual exception
               error.ApplicationName = errorLog.ApplicationName;
               error.Message = ex.Message;
               error.Source = "CompassLoadService"; //
               error.Type = "System.Exception"; // please put the actual exception type
               errorLog.Log(error);


           }

       }





  }
}
