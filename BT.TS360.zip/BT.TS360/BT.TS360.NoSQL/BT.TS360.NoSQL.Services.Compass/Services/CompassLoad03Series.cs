﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Data.DAL;
//using BT.TS360.Services.Compass; 
using BT.TS360.NoSQL.Data.Common.Constants; 
using BT.TS360.NoSQL.Services.Compass.Services;
//using BT.TS360.NoSQL.Services.Compass.Services.Repository; 
using BT.TS360.Services.Compass;
using BT.TS360.NoSQL.Data.AzureSearch;

using BT.TS360.NoSQL.Services.Compass.Helper;



namespace BT.TS360.NoSQL.Services.Compass.Services
{
    public class CompassLoad03Series
    {
        List<WriteModel<BsonDocument>> models = new List<WriteModel<BsonDocument>>();
        MongoDBHelper mongoDBHelper = new MongoDBHelper();
        const string ebook = "EBook";
        const string digital = "Digital";

        public CompassLoad03Series()
        {
        }
        //old
        public void Load(string StoredProcedureName, string LoadType)
        {

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);

            String loadCollection = AppSetting.MongoCollectionSeries;
            String loadCollectionLogging = AppSetting.MongoCollectionSeries;
            String loadAction = null;

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

            DateTime dtNow = DateTime.Now;
            DateTime dtnowDelete = DateTime.Today.AddDays(-30);
            //GET ODS Data
            Console.WriteLine(DateTime.Now.ToString() + " Open Connection and Extracting Compass Data-" + loadCollectionLogging);
            fileLogLoad.Write("Open Connection and Extracting Compass Data-" + loadCollectionLogging, FileLogRepository.Level.INFO);

            int azurePrioritySeries = Convert.ToInt32(AppSetting.AzurePrioritySeries);

            var dataConnect = ConfigurationManager.ConnectionStrings["Compass"].ConnectionString;
            //old
            SqlConnection CompassConnection = new SqlConnection(dataConnect);
            //new
            //DBTransactionODSDAO dbTransactionODSDAO = new DBTransactionODSDAO(dataConnect);

            SqlDataReader dr = null;
            try
            {

                //old
                SqlCommand storedProc = new SqlCommand(StoredProcedureName, CompassConnection);
                storedProc.CommandType = CommandType.StoredProcedure;
                storedProc.CommandTimeout = Convert.ToInt32(AppSetting.CompassSQLCommandTimeout); 
                if (LoadType == "Delta")
                {
                    int daysBackDelta = Convert.ToInt32(AppSetting.DeltaDaysBack);
                    DateTime dtnowDelta = DateTime.Today.AddDays(daysBackDelta);
                    SqlParameter DateTimeIn = storedProc.Parameters.Add("@fromdatetime", SqlDbType.DateTime);
                    DateTimeIn.Direction = ParameterDirection.Input;
                    DateTimeIn.Value = dtnowDelta;
                }

                CompassConnection.Open();
                dr = storedProc.ExecuteReader();

                Console.WriteLine(DateTime.Now.ToString() + " Done Extracting Compass Data");
                fileLogLoad.Write("Done Extracting Compass Data", FileLogRepository.Level.INFO);

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection series = mongodatabase.GetCollection(AppSetting.MongoCollectionSeries);
                MongoCollection changerequests = mongodatabase.GetCollection("ChangeRequests");

                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");
                MongoCollection azuresearch = commonDatabase.GetCollection(AppSetting.MongoCollectionAzureQueue);

                MongoDatabase mongodatabaseProducts = mongoServer.GetDatabase(AppSetting.MongoDatabaseProducts);
                MongoCollection<Product> products = mongodatabaseProducts.GetCollection<Product>(AppSetting.MongoCollectionProducts);
                var totalCount2 = azuresearch.Count();
                var totalCount = products.Count();

                if (dr.HasRows == true)
                {

                    Console.WriteLine(DateTime.Now.ToString() + " Looping through the Compass - Series Results.");
                    fileLogLoad.Write("Looping through the Compass - Series Results.", FileLogRepository.Level.INFO);
                    Int64 totalcounter = 0;
                    Int64 updatecounter = 0;
                    Int64 insertcounter = 0;
                    Int64 totalSkipped = 0;

                    Int64 mycounter = 0;
                    int bulkWriteCount = 0;

                    int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
                    int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries1Save = Convert.ToInt32(maxRetries1);
                    int maxRetries2Save = Convert.ToInt32(maxRetries2);
                    int maxRetries3Save = Convert.ToInt32(maxRetries3);



                    while (dr.Read())
                    {
                        Boolean bypassbaddataflag = false;
                        totalcounter = totalcounter + 1;
                        String RowValueOut = null;
                        String ValidateFor = "Series";

                        Repository poValidate = new Repository();
                        bool isValid = Repository.ValidateFields(dr, ValidateFor, out RowValueOut);


                        if (isValid == false)
                        {
                            bypassbaddataflag = true;
                            Console.WriteLine(DateTime.Now.ToString() + " Bad data returned from Compass(" + RowValueOut + ")");
                            fileLogLoad.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);
                            Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, AppSetting.MongoCollectionSeries, "ValidationError:" + RowValueOut, fileLogLoad);
                        }

                        if (totalcounter % 10000 == 0)
                        {
                            Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: " + totalcounter.ToString());
                            fileLogLoad.Write("Total Record Count: " + totalcounter.ToString(), FileLogRepository.Level.INFO);
                        }




                        if (bypassbaddataflag == false)
                        {
                            // Assign all fields from dr to class

                            Series seriesTEMP = new Series();
                            seriesTEMP.SeriesID = Convert.ToString(dr.GetInt32(0));
                           
                            seriesTEMP.LoadDateTime = DateTime.Now;

                            if (!dr.IsDBNull(21))
                            { loadAction = dr.GetString(21); }
                            else
                                throw new Exception("Missing Action Type, this is a required field");
                            //testing
                            //LoadType = "Delta";
                            //loadAction = "D"; 
                            if (LoadType.ToUpper() == "DELTA")
                            {
                                if (loadAction != "A" && loadAction != "M" && loadAction != "D")
                                { throw new Exception("Invalid Action Type, this is a required field"); }
                            }


                            if ((LoadType == "Full") || (LoadType == "Delta" && (loadAction == "A" || loadAction == "M")))
                            {
                                seriesTEMP.Name = dr.GetString(1);
                                if (!dr.IsDBNull(2)) { seriesTEMP.Publisher = dr.GetString(2); }
                                if (!dr.IsDBNull(23)) { seriesTEMP.Distributor = dr.GetString(23); }
                                if (!dr.IsDBNull(3)) { seriesTEMP.Format = dr.GetString(3); }
                                if (!dr.IsDBNull(10)) { seriesTEMP.Frequency = dr.GetString(10); }
                                if (!dr.IsDBNull(19)) { seriesTEMP.Audience = dr.GetString(19); }
                                if (!dr.IsDBNull(20)) { seriesTEMP.StartDataType = dr.GetString(20); }

                                if (!dr.IsDBNull(11)) { seriesTEMP.Annotations = dr.GetString(11); }
                                if (!dr.IsDBNull(12)) { seriesTEMP.Author = dr.GetString(12); }
                                if (!dr.IsDBNull(22)) { seriesTEMP.HasRelatedSeries = dr.GetBoolean(22); }
                                if (!dr.IsDBNull(24)) { seriesTEMP.HasBindingPreferences = dr.GetBoolean(24); }

                                if (!dr.IsDBNull(13))
                                {
                                    if (dr.GetString(13) == "A") { seriesTEMP.Status = "Active"; }
                                    else if (dr.GetString(13) == "I") { seriesTEMP.Status = "Inactive"; }
                                    else if (dr.GetString(13) == "N") { seriesTEMP.Status = "Inactive"; }
                                    else if (dr.GetString(13) == "P") { seriesTEMP.Status = "Prospect"; }
                                    else if (dr.GetString(13) == "H") { seriesTEMP.Status = "Waiting"; }
                                    else { seriesTEMP.Status = dr.GetString(13); }
                                }

                                LatestIssueInformation latestissueinformation = new LatestIssueInformation();
                                String listPriceNull = null;
                                if (!dr.IsDBNull(4)) { latestissueinformation.ISBN = dr.GetString(4); }
                                if (!dr.IsDBNull(5)) { latestissueinformation.ListPrice = dr.GetDecimal(5); }
                                if (!dr.IsDBNull(6)) { latestissueinformation.PublicationDate = dr.GetDateTime(6); }
                                if (!dr.IsDBNull(7)) { latestissueinformation.Edition = dr.GetString(7); }
                                if (!dr.IsDBNull(8)) { latestissueinformation.Title = dr.GetString(8); }
                                if (!dr.IsDBNull(9)) { latestissueinformation.Author = dr.GetString(9); }
                                if (!dr.IsDBNull(14))
                                {
                                    string tempBtkey = dr.GetString(14);
                                    tempBtkey = tempBtkey.PadLeft(10, '0');
                                    latestissueinformation.BTKey = tempBtkey;
                                }

                                seriesTEMP.LatestIssueInformation = latestissueinformation;
                                FootprintInformation footprintinformation = new FootprintInformation();
                                if (!dr.IsDBNull(16)) { footprintinformation.CreatedBy = dr.GetString(16); }
                                if (!dr.IsDBNull(15)) { footprintinformation.CreatedDate = dr.GetDateTime(15); }
                                if (!dr.IsDBNull(18)) { footprintinformation.UpdatedBy = dr.GetString(18); }
                                if (!dr.IsDBNull(17)) { footprintinformation.UpdatedDate = dr.GetDateTime(17); }

                                seriesTEMP.FootprintInformation = footprintinformation;


                                Boolean exceptionFlagPT = false;
                                maxRetries2 = maxRetries2Save;
                                while (maxRetries2 > 0)
                                {
                                    try
                                    {
                                        exceptionFlagPT = false;
                                      
                                        var ProductType = products.Distinct("ProductCode", Query.EQ("SeriesInformation.SeriesID", seriesTEMP.SeriesID)).Select(a => a.AsString).ToList();
                                      

                                        int[] indexes = Enumerable.Range(0, ProductType.Count).Where(i => ProductType[i] == ebook).ToArray();
                                        Array.ForEach(indexes, i => ProductType[i] = digital);

                                        maxRetries2 = 0;
                                        seriesTEMP.ProductType = ProductType;
                                    }
                                    catch (Exception ex2)
                                    {
                                        exceptionFlagPT = true;
                                        maxRetries2--;
                                        Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Get Failure " + ex2.Message);
                                        fileLogLoad.Write("..CompassLoad Get Failure " + ex2.Message, FileLogRepository.Level.ERROR);
                                        System.Threading.Thread.Sleep(RetryWait2);
                                        continue;
                                    }
                                }
                                if (exceptionFlagPT == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }


 
                                //**********************************************************************
                                //INSERT UPDATE PORTION
                                //**********************************************************************
                                var query = new QueryDocument { };
                                var update = new UpdateDocument { };

                                ////WRITE THE SERIES data TO MONGO
                                ////log.WriteLog("WRITE THE SERIES data TO MONGO.", false);
                                query = new QueryDocument { { "SeriesID", seriesTEMP.SeriesID } };
                                update = new UpdateDocument { { "$set", seriesTEMP.ToBsonDocument() } };

                                if (LoadType == "Full")
                                {
                                    var model = mongoDBHelper.CreateWriteModel(query, update, true);
                                    models.Add(model);

                                    bulkWriteCount++;

                                    if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                                    {
                                        var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionSeries);
                                        fileLogLoad.Write("\r\n" +
                                                     "Bulk Batch Count: " + bulkWriteResult.ModifiedCount,
                                             FileLogRepository.Level.INFO);

                                        models = new List<WriteModel<BsonDocument>>();
                                        bulkWriteCount = 0;

                                    }
                                }
                                else
                                {
                                    Boolean exceptionFlag2 = false;
                                    maxRetries2 = maxRetries2Save;
                                    while (maxRetries2 > 0)
                                    {
                                        try
                                        {
                                            exceptionFlag2 = false;




                                            var resultInsertSeries = series.Update(query, update, UpdateFlags.Upsert, null);
                                            var resultInsertSeriesCount = resultInsertSeries.DocumentsAffected;
                                            maxRetries2 = 0;
                                            if (resultInsertSeriesCount == 1)
                                            {
                                                if (resultInsertSeries.UpdatedExisting == false)
                                                { insertcounter++; }
                                                else
                                                { updatecounter++; }

                                                //call update to azure for updates
                                                var tempSeriesID = series.FindOneAs<SeriesIDClass>(Query.EQ("SeriesID", seriesTEMP.SeriesID));
                                                ObjectId seriesid = tempSeriesID._id;
                                                bool loadOK = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, seriesid, fileLogLoad, AppSetting.MongoCollectionSeries, "Upsert", azurePrioritySeries);
                                            }
                                            else { totalSkipped++; }


                                        }
                                        catch (Exception ex2)
                                        {
                                            exceptionFlag2 = true;
                                            maxRetries2--;
                                            Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex2.Message);
                                            fileLogLoad.Write("..CompassLoad Save Failure " + ex2.Message, FileLogRepository.Level.ERROR);
                                            System.Threading.Thread.Sleep(RetryWait2);
                                            continue;
                                        }
                                    }
                                    if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
                                }
                                if (LoadType == "Delta")
                                {

                                    //**********************************************************************
                                    //DELETE PORTION - FOR PROFILEDSERIES ONLY
                                    //ANY "A" OR "M" ACTION TYPES will mean  we need to clear the existing subdocuments.
                                    //**********************************************************************
                                    bool loadOK1 = RemoveSeriesSubDocument(maxRetries2Save, RetryWait2, series, seriesTEMP.SeriesID, "ForthcomingTitles", fileLogLoad);

                                    bool loadOK2 = RemoveSeriesSubDocument(maxRetries2Save, RetryWait2, series, seriesTEMP.SeriesID, "BindingPreferences", fileLogLoad);

                                    //bool loadOK3 = RemoveSeriesSubDocument(maxRetries2Save, RetryWait2, series, seriesTEMP.SeriesID, "RelatedSeriesIDs", fileLogLoad);

                                    //bool loadOK4 = RemoveSeriesSubDocument(maxRetries2Save, RetryWait2, series, seriesTEMP.SeriesID, "Programs", fileLogLoad);

                                    bool loadOK5 = RemoveSeriesSubDocument(maxRetries2Save, RetryWait2, series, seriesTEMP.SeriesID, "ISBNList", fileLogLoad);
                                    //***********************************************************************  
                                    //ChangeRequest Logic
                                    //***********************************************************************
                                    //ChangeRequests changerequestsTEMP = new ChangeRequests();
                                    //var queryUpdateChangeRequestDeletes = (Query.And(Query.EQ("SeriesID", changerequests. ),
                                    //                                                 Query.EQ("RequestStatus", "Completed"),
                                    //                                                 Query.NE("RequestType", "Delete Profile")));
                                    //var updateUpdateChangeRequestDeletes = Update.Set("RequestStatus", "Loaded");
                                    //var resultUpdateChangeRequestDeletes = changerequests.Update(queryUpdateChangeRequestDeletes, updateUpdateChangeRequestDeletes, UpdateFlags.None, null);



                                }

                                //**************************************************************************  
                                //Load ISBNLists 
                                //**************************************************************************
                                if (LoadType == "Full")
                                {
                                    var totalProductCount = products.Count();
                                    var mycursor = products.Find(Query.EQ("SeriesInformation.SeriesID", seriesTEMP.SeriesID)).ToList();
                                    var builder = Builders<BsonDocument>.Filter;
                                    var updateBuilder = Builders<BsonDocument>.Update;
                                    List<string> isbnList = new List<string>();
                                    List<string> isbnList10 = new List<string>();
                                    var queryISBN = builder.Eq("SeriesID", seriesTEMP.SeriesID);
                                    foreach (Product p in mycursor)
                                    {

                                        isbnList.Add(p.ISBN);

                                        if (p.ISBN10 != null)
                                        {
                                            isbnList10.Add(p.ISBN10);
                                        }
                                    }

                                    var updateISBN = updateBuilder.Set("ISBNList", isbnList);
                                    var modelISBN = mongoDBHelper.CreateWriteModel(queryISBN, updateISBN, false);
                                    models.Add(modelISBN);

                                    var updateISBN10 = updateBuilder.Set("ISBN10List", isbnList10);
                                    var modelISBN10 = mongoDBHelper.CreateWriteModel(queryISBN, updateISBN10, false);
                                    models.Add(modelISBN10);

                                    bulkWriteCount++;


                                    if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                                    {
                                        var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionSeries);
                                        fileLogLoad.Write("\r\n" +
                                                     "Bulk Batch Count: " + bulkWriteResult.ModifiedCount,
                                             FileLogRepository.Level.INFO);

                                        models = new List<WriteModel<BsonDocument>>();
                                        bulkWriteCount = 0;
                                    }
                                }
                                else
                                {
                                    bool loadisbns = LoadSeriesISBNList(maxRetries2Save, RetryWait2, products, series, seriesTEMP.SeriesID, fileLogLoad);
                                }

                            }

                            else
                            {
                                //**********************************************************************
                                //DELETE PORTION - FOR SERIES ONLY
                                //This delete is for a delta load where the ACTION TYPE will equal "D"
                                //**********************************************************************
                                //check to see if that item exists 
                                var tempSeriesID = series.FindOneAs<SeriesIDClass>(Query.EQ("SeriesID", seriesTEMP.SeriesID));

                                if (tempSeriesID != null)
                                {
                                    ObjectId seriesid = tempSeriesID._id;

                                    bool loadOK = RemoveSeriesDocument(maxRetries2Save, RetryWait2, series, seriesTEMP.SeriesID, fileLogLoad);

                                    bool loadOKSeries = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, seriesid, fileLogLoad, AppSetting.MongoCollectionSeries, "Delete", azurePrioritySeries);

                                    //***********************************************************************  
                                    //ChangeRequest Logic
                                    //***********************************************************************
                                    //ChangeRequests changerequestsTEMP = new ChangeRequests();
                                    //var queryUpdateChangeRequestDeletes = (Query.And(Query.EQ("SeriesID", seriesTEMP.SeriesID ),
                                    //                                                 Query.EQ("RequestStatus", "Completed"),
                                    //                                                 Query.EQ("RequestType", "Delete Series")));
                                    //var updateUpdateChangeRequestDeletes = Update.Set("RequestStatus", "Deleted");
                                    //var resultUpdateChangeRequestDeletes = changerequests.Update(queryUpdateChangeRequestDeletes, updateUpdateChangeRequestDeletes, UpdateFlags.None, null);
                                }
                                else
                                {
                                    Console.WriteLine(DateTime.Now.ToString() + "Unable to do delete for the following Series: " + seriesTEMP.SeriesID.ToString());
                                }

                            }


                        }
                        else
                        {
                            bypassbaddataflag = false;
                            totalSkipped++;

                        }


                    }

                    if (LoadType == "Full")
                    {
                        var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionSeries);
                        fileLogLoad.Write("\r\n" +
                                          "Bulk Record Count: " + bulkWriteResult.ModifiedCount,
                         FileLogRepository.Level.INFO);
                        var createFullAzureQueue = mongoDBHelper.CreateFullAzureQueue(AppSetting.MongoCollectionSeries);

                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);
                    }
                    else
                    {
                        fileLogLoad.Write("\r\n" +
                                          "Total Record Count: " + "\r\n" + totalcounter + "\r\n" +
                                          "Total Insert Count: " + insertcounter + "\r\n" +
                                          "Total Update Count: " + updatecounter + "\r\n" +
                                          "Total Skips  Count: " + totalSkipped,
                         FileLogRepository.Level.INFO);
                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                    }



                }

                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: 0  --- No data returned from Compass");
                    fileLogLoad.Write("Total Record Count: 0  --- No data returned from Compass", FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception(ex.Message);

            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }


        public static bool RemoveSeriesDocument(int maxRetries2Save, int RetryWait2, MongoCollection series, string tempSeriesID, FileLogRepository fileLogLoad)
        {
            //*********************************************************************
            // Delete document
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;

                    //var querya = new QueryDocument { };
                    var update1 = new UpdateDocument { };
                    var query1 = (Query.EQ("SeriesID", tempSeriesID));
                    //update1 = new UpdateDocument { { "$set", profiledseriesTEMP.ToBsonDocument() } };
                    //var resultInsertSeries1 = profiledseriesTEMP.Drop();

                    var resultOfDrop = series.Remove(query1);
                

                    //var resultUpdateSeries = series.Update(Query.And(Query.EQ("SeriesID", tempSeriesID), Query.NE("BindingPreferences", tempBindingPreferences)), Update.AddToSet("BindingPreferences", tempBindingPreferences), UpdateFlags.None);
                    var resultOfDropCount = resultOfDrop.DocumentsAffected;


                    if (resultOfDropCount != 0)
                    {
                        LoadOK = true;
                    }



                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            //loadOKTypeOut = loadOkayType;
            return LoadOK;

        }


        public static bool RemoveSeriesSubDocument(int maxRetries2Save, int RetryWait2, MongoCollection series, string tempSeriesID, string tempSubDocument, FileLogRepository fileLogLoad)
        {
            //*********************************************************************
            // Delete sub document
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;

                    var querydelete = (Query.EQ("SeriesID", tempSeriesID));

                    var updatedelete = Update.Unset(tempSubDocument);
                    var resultDeletes = series.Update(querydelete, updatedelete, UpdateFlags.Multi);

                    fileLogLoad.Write("Delete Result for SeriesID: " + "(" + tempSeriesID + "): Documents affected --" + resultDeletes.DocumentsAffected.ToString(), FileLogRepository.Level.INFO);

                    LoadOK = true;
                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Delete Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Delete Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            return LoadOK;

        }


        public static bool UpdateAzureSearch(int maxRetries2Save, int RetryWait2, MongoCollection azuresearch, ObjectId tempobjectid, FileLogRepository fileLogLoad, String tempCollection, String tempChangetype, Int32 tempAzurePriority)
        {
            //*****************************************************************+++++****
            // Add to Azure Search Queue
            //*********************************************************************e
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            AzureSearchQueueItem azureTEMP = new AzureSearchQueueItem();
            azureTEMP.CollectionName = tempCollection;
            azureTEMP.ChangeType = tempChangetype;
            azureTEMP.ObjectId = tempobjectid;
            azureTEMP.Priority = tempAzurePriority;
            azureTEMP.InProcessState = 0;

            FootprintInformation footprintinformation = new FootprintInformation();
            footprintinformation.CreatedDate = DateTime.Now;
            footprintinformation.CreatedBy = "cl";
            footprintinformation.UpdatedDate = DateTime.Now;
            footprintinformation.UpdatedBy = "cl";

            azureTEMP.FootprintInformation = footprintinformation;



            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;


                    //var query = new QueryDocument { { "ObjectId", tempobjectid } };
                    //var update = new UpdateDocument { { "$set", azureTEMP.ToBsonDocument() } };
                    //var resultUpsertAzure = azuresearch.Update(query, update, UpdateFlags.Upsert, null);
                    var resultUpsertAzure = azuresearch.Insert<AzureSearchQueueItem>(azureTEMP);
                    var resultUpsertAzureCount = resultUpsertAzure.DocumentsAffected;

                    //fileLogLoad.Write("Upsert Result for ObjectID: " + "(" + tempobjectid.ToString() + "/" + "): Documents affected --" + resultUpsertAzure.DocumentsAffected.ToString(), FileLogRepository.Level.INFO);

                    LoadOK = true;
                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..AzureSearch Upsert Failure " + ex1.Message);
                    fileLogLoad.Write("..AzureSearch Upsert Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            return LoadOK;

        }


        public static bool LoadSeriesISBNList(int maxRetries2Save, int RetryWait2, MongoCollection<Product> products, MongoCollection series, String tempSeriesID, FileLogRepository fileLogLoad)
        {
            //*****************************************************************+++++****
            // Get Series ISBN List
            //*********************************************************************e
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int64 resultUpdateCount3 = 0;
            //Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            //while (maxRetries2 > 0)
            //{
            try
            {
                exceptionFlag2 = false;
                var totalCount = products.Count();
                var mycursor = products.Find(Query.EQ("SeriesInformation.SeriesID", tempSeriesID));


                foreach (Product p in mycursor)
                {

                    string isbn = p.ISBN;
                    string isbn10 = p.ISBN10;
                    //Console.WriteLine(isbn);

                    var resultUpdateSeries = series.Update(Query.And(Query.EQ("SeriesID", tempSeriesID), Query.NE("ISBNList", isbn)), Update.AddToSet("ISBNList", isbn), UpdateFlags.None);
                    resultUpdateCount2 = resultUpdateSeries.DocumentsAffected;

                    if (p.ISBN10 != null)
                    {
                        var resultUpdateSeriesISBN10 = series.Update(Query.And(Query.EQ("SeriesID", tempSeriesID), Query.NE("ISBN10List", isbn10)), Update.AddToSet("ISBN10List", isbn10), UpdateFlags.None);
                        resultUpdateCount3 = resultUpdateSeriesISBN10.DocumentsAffected;
                    }




                    if (resultUpdateCount2 != 0)// && resultUpdateCount3 != 0)
                    {
                        if (resultUpdateSeries.UpdatedExisting == false)
                        { loadOkayType = "Insert"; }
                        else
                        { loadOkayType = "Update"; }


                        LoadOK = true;
                    }


                }

                LoadOK = true;
                //maxRetries2 = 0;


            }
            catch (Exception ex1)
            {
                exceptionFlag2 = true;
                //maxRetries2--;
                Console.WriteLine(DateTime.Now.ToString() + " ..AzureSearch Upsert Failure " + ex1.Message);
                fileLogLoad.Write("..AzureSearch Upsert Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                //System.Threading.Thread.Sleep(RetryWait2);
                //continue;
            }
            //}
            if (exceptionFlag2 == true) { throw new Exception("Exception inserting to Series / ISBNListLimit, aborting process"); }
            return LoadOK;

        }

      
        private List<string> GetListFromField(string data)
        {

            var fieldList = new List<string>();

            if (!string.IsNullOrEmpty(data))
            {

                fieldList = data.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToList();

            }



            return fieldList;

        }

    }
}
