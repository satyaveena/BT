﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 

using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using BT.TS360.Services.Compass; 
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Services;
using BT.TS360.NoSQL.Services.Compass.Helper;
using BT.TS360.NoSQL.Data.Common.Helper;

namespace BT.TS360.NoSQL.Services.Compass
{
    public class CompassLoad10ProfiledSeriesRedundantProfiles
    {
        MongoDBHelper mongoDBHelper = new MongoDBHelper();
        AzureSearchQueueHelper _azureSearchQueueHelper;
             

        public CompassLoad10ProfiledSeriesRedundantProfiles()
        {
        }

        public void Load()
        {
            var models = new List<WriteModel<BsonDocument>>();

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            //FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            //FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);

            String loadCollection = "RedundantProfiles";
            String loadCollectionLogging = "ProfiledSeries/RedundantProfiles";

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);


            int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
            int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
            int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
            int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries1Save = Convert.ToInt32(maxRetries1);
            int maxRetries2Save = Convert.ToInt32(maxRetries2);
            int maxRetries3Save = Convert.ToInt32(maxRetries3);
            Int64 totalcounter = 0;
            Int64 updatecounter = 0;
            Int64 insertcounter = 0;
            Int64 totalSkipped = 0;
            int bulkWriteCount = 0;

            int daysBackToUpdate = Convert.ToInt32(AppSetting.RedundantProfilesUpdateParm);

            DateTime dtNow = DateTime.Today;
            DateTime dtnowUpdate = DateTime.Today.AddDays(daysBackToUpdate);
            //Int64 updatecounter = 0; 


            try
            {


                //Source collection for cursor
                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection<Profile> profiles = mongodatabase.GetCollection<Profile>(AppSetting.MongoCollectionProfiles); // here we are using the class w/o id
                //MongoCollection profiles = mongodatabase.GetCollection("Profiles"); 

                //Source collection for _id
                MongoCollection profilesXXX = mongodatabase.GetCollection(AppSetting.MongoCollectionProfiles);  ////This is my workaround to get the id from Mongo. 

           

                //Target collection 
                MongoClient mongoClientX = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServerX = mongoClientX.GetServer();
                MongoDatabase mongodatabaseX = mongoServerX.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection<ProfiledSeries> profiledSeries = mongodatabaseX.GetCollection<ProfiledSeries>(AppSetting.MongoCollectionProfiledSeries);


                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");


                var mycursor = profiles.Find(Query.GTE("FootprintInformation.UpdatedDate", dtnowUpdate));

                var mycursorcount = mycursor.Count();



                foreach (Profile p in mycursor)
                {

                    //This is my workaround to get the id from Mongo. 
                    var mycursor2 = profilesXXX.FindAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", p.CompassAccountNumber));
                    var mycursor2count = mycursor2.Count();
                    //ObjectId profilesid;
                    foreach (ProfilesIDClass pp in mycursor2)
                    {
                        ObjectId profilesid = pp._id;

                        Console.WriteLine(pp._id);


                        if (updatecounter % 10000 == 0)
                        {
                            Console.WriteLine(DateTime.Now.ToString() + " Total " + loadCollectionLogging + " Updated: " + updatecounter.ToString());
                            fileLogLoad.Write("Total " + loadCollectionLogging + " Updated: " + updatecounter.ToString(), FileLogRepository.Level.INFO);
                        }

                        //var xxxTEMP = profilesXXX.FindAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", p.ProfilesLocal.CompassAccountNumber)); //This is my workaround to get the id from Mongo. 

                        RedundantProfileData redundandprofiles = new RedundantProfileData();
                        redundandprofiles.Name = p.Name;
                        redundandprofiles.OrganizationID = p.OrganizationID;
                        redundandprofiles.ShippingAccountNumber = p.CompassAccountNumber;
                        redundandprofiles.CompassAccountNumber = p.CompassAccountNumber;
                        redundandprofiles.SalesTerritory = p.SalesTerritory;
                        redundandprofiles.TotalCopies = p.SummaryInformation.TotalCopies;
                        redundandprofiles.TotalSeries = p.SummaryInformation.TotalSeries;
                        redundandprofiles.Status = p.Status;
                        redundandprofiles.ProfileType = p.ProfileType;
                        redundandprofiles.Programs = p.Programs;



                        FootprintInformation footprintinformation = new FootprintInformation();
                        footprintinformation.CreatedDate = p.FootprintInformation.CreatedDate;

                        //String tempProfiles = "xxx";
                        Int64 upsertCounterOut = 0;
                        if (AppSetting.RunDeltaorFullCompassLoad == "Full")
                        {

                            var builder = Builders<BsonDocument>.Filter;
                            var builderUpdate = Builders<BsonDocument>.Update;

                            var query = builder.Eq("ProfileID", pp._id);

                            var update = builderUpdate.Set("RedundantProfileInformation", redundandprofiles.ToBsonDocument());

                            var model = mongoDBHelper.CreateWriteModel(query, update, false);
                            models.Add(model);

                            bulkWriteCount++;

                            if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                            {
                                var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiledSeries);
                                fileLogLoad.Write("\r\n" +
                                             "Bulk Batch Count: " +  bulkWriteResult.ModifiedCount,
                                     FileLogRepository.Level.INFO);

                                models = new List<WriteModel<BsonDocument>>();
                                bulkWriteCount = 0;

                            }
                        }

                        else
                        {

                            bool loadOK = LoadRedundantProfiles(maxRetries2Save, RetryWait2, profiledSeries, redundandprofiles, fileLogLoad, pp._id, out upsertCounterOut);
                            if (loadOK == true)
                            { insertcounter = insertcounter + upsertCounterOut; }
                            else
                            {
                                totalSkipped++;
                                //Console.WriteLine(DateTime.Now.ToString() + " Unable to load " + loadCollectionLogging + ", series does not exist(" + p.CompassAccountNumber + ")");
                                //fileLogLoad.Write("Unable to load " + loadCollectionLogging + ", series does not exist(" + p.CompassAccountNumber + ")", FileLogRepository.Level.INFO);
                                //Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, "ProfiledSeries", "Series ID Missing for Account #:" + p.CompassAccountNumber, fileLogLoad);

                            }

                            updatecounter = insertcounter + totalSkipped;
                        }

                    }
                }

                if (AppSetting.RunDeltaorFullCompassLoad == "Full")
                {

                    var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiledSeries);

                    fileLogLoad.Write("\r\n" + "Bulk Records Upserted: " + bulkWriteResult.ModifiedCount, FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);

                }
                else
                {

                    Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Upserted: " + insertcounter);
                    Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Skipped: " + totalSkipped);
                    Console.WriteLine(DateTime.Now.ToString() + " End Update " + loadCollectionLogging);

                    fileLogLoad.Write("\r\n" + "Total Records Upserted: " + insertcounter + "\r\n"
                                                                         + "Total Records Skipped: " + totalSkipped + "\r\n"
                                                                         + "End Update " + loadCollectionLogging, FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                }

            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
        }


        public  bool LoadRedundantProfiles(int maxRetries2Save, int RetryWait2, MongoCollection profiledseries, RedundantProfileData redundantprofileTEMP, FileLogRepository fileLogLoad, ObjectId profileID, out Int64 upsertCounterOut)
        {
            //*********************************************************************
            // INSERT / UPDATE Portion 
            //*********************************************************************
            _azureSearchQueueHelper = new AzureSearchQueueHelper(AppSetting.MongoDatabaseConnectionString, Convert.ToInt32(AppSetting.RetryWait), Convert.ToInt32(AppSetting.RetryTimes));
            int azurePriorityProfiledSeries = Convert.ToInt32(AppSetting.AzurePriorityProfiledSeries);
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            //Int64 = maxRetries2Save; 
            Int32 maxRetries2 = maxRetries2Save;
            Int64 upsertCounter = 0; 
            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;

                    Int64 resultUpdateProfiledSeriesCount = 0;
                    Int64 resultCheckProfiledSeriesCount = 0;
                    // This part is to avoid creating an empty redundant set of data when the profiles does not exist... 
                    var resultCheckProfiledSeries = profiledseries.FindAs<ProfiledSeries>(Query.EQ("ProfileID", profileID)).ToList();
                    resultCheckProfiledSeriesCount = resultCheckProfiledSeries.Count();

                    if (resultCheckProfiledSeriesCount != 0)
                    {
                        var flags = UpdateFlags.Upsert | UpdateFlags.Multi;
                        var resultUpdateProfiledSeries = profiledseries.Update(Query.EQ("ProfileID", profileID), Update.Set("RedundantProfileInformation", redundantprofileTEMP.ToBsonDocument()), flags);
                        resultUpdateProfiledSeriesCount = resultUpdateProfiledSeries.DocumentsAffected;
                        
                        fileLogLoad.Write("Profiles# Upserted: " + profileID + " / " + resultUpdateProfiledSeriesCount, FileLogRepository.Level.INFO);
                        LoadOK = true;
                        upsertCounter = resultUpdateProfiledSeriesCount;

                        if (LoadOK == true)
                        {
                          _azureSearchQueueHelper.UpdateAzureSearchQueue(resultCheckProfiledSeries.Select(x => x.ProfiledSeriesID.ToString()).ToList(), AppSetting.MongoCollectionProfiledSeries, "Upsert", "CL", azurePriorityProfiledSeries);
                        }
                       
                    }
                    else
                    {
                        fileLogLoad.Write("Profiles# Skipped: " + profileID, FileLogRepository.Level.INFO);
                    }

                    maxRetries2 = 0;
                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            upsertCounterOut = upsertCounter; 
            return LoadOK;

        }







    }
}
