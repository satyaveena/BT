﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Data.DAL;
using BT.TS360.NoSQL.Data.Common.Constants; 
using BT.TS360.NoSQL.Services.Compass.Services;
//using BT.TS360.NoSQL.Services.Compass.Services.Repository; 
using BT.TS360.NoSQL.Services.Compass.Helper;





namespace BT.TS360.NoSQL.Services.Compass.Services
{
    public class CompassLoad02ProfilesPrograms
    {
        IMongoCollection<BsonDocument> _profiles;
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        public CompassLoad02ProfilesPrograms()
        {
        }
        //old
        public void Load(string StoredProcedureName, string LoadType)
        {

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);

            String loadCollection = "Programs";
            String loadCollectionLogging = "Profiles/Programs";

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);


            DateTime dtNow = DateTime.Now;
            DateTime dtnowDelete = DateTime.Today.AddDays(-30);
            //GET ODS Data
            Console.WriteLine(DateTime.Now.ToString() + " Open Connection and Extracting Compass Data-" + loadCollectionLogging);
            fileLogLoad.Write("Open Connection and Extracting Compass Data-" + loadCollectionLogging, FileLogRepository.Level.INFO);

            var dataConnect = ConfigurationManager.ConnectionStrings["Compass"].ConnectionString;
            //old
            SqlConnection CompassConnection = new SqlConnection(dataConnect);
            //new
            //DBTransactionODSDAO dbTransactionODSDAO = new DBTransactionODSDAO(dataConnect); 

            SqlDataReader dr = null;
            try
            {

                //old
                SqlCommand storedProc = new SqlCommand(StoredProcedureName, CompassConnection);
                storedProc.CommandType = CommandType.StoredProcedure;
                storedProc.CommandTimeout = Convert.ToInt32(AppSetting.CompassSQLCommandTimeout); 
                CompassConnection.Open();
                dr = storedProc.ExecuteReader();

                Console.WriteLine(DateTime.Now.ToString() + " Done Extracting Compass Data");
                fileLogLoad.Write("Done Extracting Compass Data", FileLogRepository.Level.INFO);

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                //MongoCollection<Profiles> profiles = mongodatabase.GetCollection<Profiles>("Profiles");
                MongoCollection profiles = mongodatabase.GetCollection(AppSetting.MongoCollectionProfiles);

                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");


                IMongoClient _client = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                IMongoDatabase _databaseTSSO = _client.GetDatabase(AppSetting.MongoDatabase);
                _profiles = _databaseTSSO.GetCollection<BsonDocument>(AppSetting.MongoCollectionProfiles);

                if (dr.HasRows == true)
                {

                    Console.WriteLine(DateTime.Now.ToString() + " Looping through the Compass - ProfilesProgramType Results.");
                    fileLogLoad.Write("Looping through the Compass - ProfilesProgramType Results.", FileLogRepository.Level.INFO);
                    Int64 totalcounter = 0;
                    Int64 updatecounter = 0;
                    Int64 insertcounter = 0;
                    Int64 totalSkipped = 0;
                    int bulkWriteCount = 0;
                    var models = new List<WriteModel<BsonDocument>>();

                    int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
                    int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries1Save = Convert.ToInt32(maxRetries1);
                    int maxRetries2Save = Convert.ToInt32(maxRetries2);
                    int maxRetries3Save = Convert.ToInt32(maxRetries3);

                    while (dr.Read())
                    {
                        string tempxxx = dr.GetString(0);

                        Boolean bypassbaddataflag = false;
                        //string LastBTKey = dr.GetString(0);
                        //string BTKey = LastBTKey;
                        totalcounter = totalcounter + 1;


                        //define and assign fields from recordset here. 
                        String RowValueOut = null;
                        String tempERPAccountNumber = null;
                        String tempProgram = null;
                        String ValidateFor = "ProfileProgram";
                        ValidateFor = "ProfileProgram";

                        //  Check for nulls. 
                        Repository poValidate = new Repository();
                        bool isValid = Repository.ValidateFields(dr, ValidateFor, out RowValueOut);

                        if (isValid == false)
                        {
                            bypassbaddataflag = true;
                            Console.WriteLine(DateTime.Now.ToString() + " Bad data returned from Compass(" + RowValueOut + ")");
                            fileLogLoad.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);
                            //fileError1.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);  
                            Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, AppSetting.MongoCollectionProfiles, "ValidationError:" + RowValueOut, fileLogLoad);

                        }



                        if (totalcounter % 10000 == 0)
                        {
                            Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: " + totalcounter.ToString());
                            fileLogLoad.Write("Total Record Count: " + totalcounter.ToString(), FileLogRepository.Level.INFO);
                        }




                        if (bypassbaddataflag == false)
                        {  // Assign all fields from dr to class
                            //if (bypassbaddataflag == true) // check to see if bypass data is in effect...
                            //{
                            Profile profilesTEMP = new Profile();

                            profilesTEMP.CompassAccountNumber = dr.GetString(0);

                            //profilesTEMP.CompassAccountNumber = "031422C6543213000000"; 
                            tempProgram = dr.GetString(1);
                            var programs =  tempProgram.Split(';');
                 
                           
                            //var arrayTemp = new BsonArray();
                            //foreach (var item in programs)
                            //{
                            //    arrayTemp.Add(item);
                            // }



                            //*********************************************************************
                            // INSERT / UPDATE Portion 
                            //*********************************************************************
                            Boolean exceptionFlag2 = false;
                            Int64 resultUpdateCount2 = 0;
                            maxRetries2 = maxRetries2Save;

                            while (maxRetries2 > 0)
                            {
                                try
                                {
                                    exceptionFlag2 = false;
                                    var builder = Builders<BsonDocument>.Filter;
                                    var builderUpdate = Builders<BsonDocument>.Update;
                                    var query = builder.Eq("CompassAccountNumber", profilesTEMP.CompassAccountNumber);
                                    var update = builderUpdate.Set("Programs", programs);

                                    if (LoadType == "Full")
                                    {

                                        var model = mongoDBHelper.CreateWriteModel(query, update, false);
                                        models.Add(model);

                                        bulkWriteCount++;

                                        if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                                        {
                                            var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiles);
                                            fileLogLoad.Write("\r\n" +
                                                         "Bulk Batch Count: " + bulkWriteResult.ModifiedCount,
                                                 FileLogRepository.Level.INFO);

                                            models = new List<WriteModel<BsonDocument>>();
                                            bulkWriteCount = 0;

                                        }
                                    }
                                    else
                                    {

                                        //**********************************************************************
                                        //Update PORTION - FOR PROFILEs ONLY
                                        //ANY "A" OR "M" ACTION TYPES will mean  we need to clear the existing subdocuments.
                                        //**********************************************************************
                                        var updateOptions = new UpdateOptions();
                                        updateOptions.IsUpsert = true;
                                        var resultUpdateProfiles = _profiles.UpdateOne(query, update);
                                            resultUpdateCount2 = resultUpdateProfiles.ModifiedCount;


                                            if (resultUpdateCount2 > 0)
                                            {
                                                 insertcounter++; 
                                            }
                                            else
                                            {
                                                totalSkipped++;
                                                Console.WriteLine(DateTime.Now.ToString() + " Unable to load ProfilesPrograms, profiles skipped(" + profilesTEMP.CompassAccountNumber + ")");
                                                fileLogLoad.Write("Unable to load ProfilePrograms, profiles skipped(" + profilesTEMP.CompassAccountNumber + ")", FileLogRepository.Level.INFO);
                                                RowValueOut = "Unable to load ProfilePrograms, profiles skipped(" + profilesTEMP.CompassAccountNumber + ")";
                                                //Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, "Profiles", "MissingProfiles:" + RowValueOut, fileLogLoad); 
                                            }
                                        }

                                        maxRetries2 = 0;
                                    }

                                catch (Exception ex1)
                                {
                                    exceptionFlag2 = true;
                                    maxRetries2--;
                                    Console.WriteLine(DateTime.Now.ToString() + " ..Compass Load Save Failure " + ex1.Message);
                                    fileLogLoad.Write("..Compass Load Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                                    System.Threading.Thread.Sleep(RetryWait2);
                                    continue;
                                }
                            }
                            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }


                            //}

                            //}
                        }
                        else
                        {
                            bypassbaddataflag = false;
                            totalSkipped++;

                        }


                    }
                    if (LoadType == "Full")
                    {
                        var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, AppSetting.MongoCollectionProfiles);
                        fileLogLoad.Write("\r\n" +
                                         "Bulk Record Count: " +  bulkWriteResult.ModifiedCount,
                        FileLogRepository.Level.INFO);
                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);
                    }
                    else
                    {
                        fileLogLoad.Write("\r\n" +
                                          "Total Record Count: " + "\r\n" + totalcounter + "\r\n" +
                                          "Total Insert Count: " + insertcounter + "\r\n" +
                                          "Total Update Count: " + updatecounter + "\r\n" +
                                          "Total Skips  Count: " + totalSkipped,
                         FileLogRepository.Level.INFO);
                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                    }
                }

                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: 0  --- No data returned from Compass");
                    fileLogLoad.Write("Total Record Count: 0  --- No data returned from Compass", FileLogRepository.Level.INFO);

                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception(ex.Message);

            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }


       
    }

   
}
