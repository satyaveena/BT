﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Data.DAL;
//using BT.TS360.Services.Compass; 
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data.AzureSearch; 
using BT.TS360.NoSQL.Services.Compass.Services;
using BT.TS360.Services.Compass; 
//using BT.TS360.NoSQL.Services.Compass.Services.Repository; 
using BT.TS360.Services.Compass;
using BT.TS360.NoSQL.Services.Compass.Helper; 




namespace BT.TS360.NoSQL.Services.Compass.Services
{
    public class CompassLoad01Profiles
    {
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        public CompassLoad01Profiles()
        {
        }
        //old
        public void Load(string StoredProcedureName, string LoadType)
        {
        
            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);
            String detailedLogging = AppSetting.DetailedLogging;

            String loadCollection = AppSetting.MongoCollectionProfiles;// "Profiles";
            String loadCollectionLogging = AppSetting.MongoCollectionProfiles;// "Profiles";
            String loadAction = null;
            //loadAction.c

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Load");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

            DateTime dtNow = DateTime.Now;
            DateTime dtnowDelete = DateTime.Today.AddDays(-30);
            //GET ODS Data
            Console.WriteLine(DateTime.Now.ToString() + " Open Connection and Extracting Compass Data-" + loadCollectionLogging);
            fileLogLoad.Write("Open Connection and Extracting Compass Data-" + loadCollectionLogging, FileLogRepository.Level.INFO);



            var dataConnect = ConfigurationManager.ConnectionStrings["Compass"].ConnectionString;
            SqlConnection CompassConnection = new SqlConnection(dataConnect);

            SqlDataReader dr = null;
            try
            {


                SqlCommand storedProc = new SqlCommand(StoredProcedureName, CompassConnection);
                storedProc.CommandType = CommandType.StoredProcedure;
                storedProc.CommandTimeout = Convert.ToInt32(AppSetting.CompassSQLCommandTimeout);
                CompassConnection.Open();

                int azurePriorityProfiles = Convert.ToInt32(AppSetting.AzurePriorityProfiles);

                if (LoadType == "Delta")
                {
                    int daysBackDelta = Convert.ToInt32(AppSetting.DeltaDaysBack);
                    DateTime dtnowDelta = DateTime.Today.AddDays(daysBackDelta);
                    SqlParameter DateTimeIn = storedProc.Parameters.Add("@fromdatetime", SqlDbType.DateTime);
                    DateTimeIn.Direction = ParameterDirection.Input;
                    DateTimeIn.Value = dtnowDelta;
                }
                dr = storedProc.ExecuteReader();


                Console.WriteLine(DateTime.Now.ToString() + " Done Extracting Compass Data");
                fileLogLoad.Write("Done Extracting Compass Data", FileLogRepository.Level.INFO);

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);
                MongoCollection profiles = mongodatabase.GetCollection(AppSetting.MongoCollectionProfiles);

                IMongoClient _client = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                IMongoDatabase _databaseTSSO = _client.GetDatabase(AppSetting.MongoDatabase);
                IMongoCollection<Profile> _profiles = _databaseTSSO.GetCollection<Profile>(AppSetting.MongoCollectionProfiles);


                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection loaderrorsCollect = commonDatabase.GetCollection("LoadErrors");
                MongoCollection azuresearch = commonDatabase.GetCollection(AppSetting.MongoCollectionAzureQueue);
                MongoCollection<ProfiledSeries> profiledSeries = mongodatabase.GetCollection<ProfiledSeries>(AppSetting.MongoCollectionProfiledSeries);


                if (dr.HasRows == true)
                {

                    Console.WriteLine(DateTime.Now.ToString() + " Looping through the Compass - " + loadCollectionLogging + "Results.");
                    fileLogLoad.Write("Looping through the Compass - " + loadCollectionLogging + "Results.", FileLogRepository.Level.INFO);
                    Int64 totalcounter = 0;
                    Int64 updatecounter = 0;
                    Int64 insertcounter = 0;
                    Int64 totalSkipped = 0;
                    var models = new List<WriteModel<BsonDocument>>();
                    int bulkWriteCount = 0;


                    int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
                    int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
                    int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
                    int maxRetries1Save = Convert.ToInt32(maxRetries1);
                    int maxRetries2Save = Convert.ToInt32(maxRetries2);
                    int maxRetries3Save = Convert.ToInt32(maxRetries3);

                    while (dr.Read())
                    {
                        string tempxxx = dr.GetString(0);

                        Boolean bypassbaddataflag = false;
                        //string LastBTKey = dr.GetString(0);
                        //string BTKey = LastBTKey;
                        totalcounter = totalcounter + 1;
                        string tempName = "";
                        if (!dr.IsDBNull(5))
                        { tempName = dr.GetString(5); }
                        else
                        { tempName = " "; }

                        if (detailedLogging == "true")
                        {
                            fileLogLoad.Write("Record:" + totalcounter.ToString() + "    " + dr.GetString(0) + dr.GetString(1) + dr.GetString(2) + dr.GetString(3) + "\r\n" +
                                              "      Profile Name: " + tempName, FileLogRepository.Level.INFO);
                        }


                        //define and assign fields from recordset here. 
                        String tempOrgid = null;
                        String tempERPAccountNumber = null;
                        String tempShipAccountNumber = null;
                        String tempBillAccountNumber = null;
                        String tempShipAccountID = null;
                        String tempSalesTerritory = null;
                        String tempAccountType = null;
                        String tempSAN = null;
                        Int32? tempTotalCopies = null;
                        Int32? tempTotalSeries = null;

                        String RowValueOut = null;
                        String RowValueOutSAN = null;
                        String ValidateFor = "Profiles";

                        //  Check for nulls. 
                        Repository poValidate = new Repository();
                        bool isValid = Repository.ValidateFields(dr, ValidateFor, out RowValueOut);


                        if (isValid == false)
                        {
                            bypassbaddataflag = true;
                            Console.WriteLine(DateTime.Now.ToString() + " Bad data returned from Compass(" + RowValueOut + ")");
                            fileLogLoad.Write("Bad data returned from Compass(" + RowValueOut + ")", FileLogRepository.Level.INFO);
                            Repository.insertErrors(maxRetries1Save, RetryWait1, loaderrorsCollect, AppSetting.MongoCollectionProfiles, "ValidationError:" + RowValueOut, fileLogLoad);
                        }


                        if (totalcounter % 10000 == 0)
                        {
                            Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: " + totalcounter.ToString());
                            fileLogLoad.Write("Total Record Count: " + totalcounter.ToString(), FileLogRepository.Level.INFO);
                        }





                        if (bypassbaddataflag == false)
                        { // Assign all fields from dr to class
                            //if (bypassbaddataflag == true) // check to see if bypass data is in effect...
                            //{
                            Profile profilesTEMP = new Profile();
                            string notificationUserId = string.Empty;

                            string tempxxx1 = dr.GetString(0);

                            if (!dr.IsDBNull(34)) { notificationUserId = dr.GetString(34); }


                            //db wants to grab from compass. 
                            //profilesTEMP.OrganizationID = tempOrgid;
                            //profilesTEMP.ShippingAccountNumber = tempShipAccountNumber;
                            //profilesTEMP.BillingAccountNumber = tempBillAccountNumber;
                            //profilesTEMP.ShippingAccountID = tempShipAccountID;
                            //profilesTEMP.SalesTerritory = tempSalesTerritory;
                            if (!dr.IsDBNull(28)) { profilesTEMP.OrganizationID = dr.GetString(28); }
                            if (!dr.IsDBNull(29)) { profilesTEMP.ShippingAccountID = dr.GetString(29); }
                            if (!dr.IsDBNull(30)) { profilesTEMP.SalesTerritory = dr.GetString(30); }
                            if (!dr.IsDBNull(31)) { profilesTEMP.BillingAccountNumber = dr.GetString(31); }
                            if (!dr.IsDBNull(32)) { profilesTEMP.ShippingAccountNumber = dr.GetString(32); }

                            if (!dr.IsDBNull(4)) { profilesTEMP.UserName = dr.GetString(4); }
                            if (!dr.IsDBNull(5)) { profilesTEMP.Name = dr.GetString(5); }
                            if (!dr.IsDBNull(6)) { profilesTEMP.CompassAccountNumber = dr.GetString(6); }
                            if (!dr.IsDBNull(33)) { profilesTEMP.AccountType = dr.GetString(33); }
                            if (!dr.IsDBNull(7)) { profilesTEMP.ProfileType = dr.GetString(7); }
                            if (!dr.IsDBNull(8)) { profilesTEMP.SAN = dr.GetString(8); }
                            if (!dr.IsDBNull(9)) { profilesTEMP.Notes = dr.GetString(9); }

                            if (!dr.IsDBNull(10))
                            {
                                if (dr.GetString(10) == "A") { profilesTEMP.Status = "Active"; }
                                else if (dr.GetString(10) == "I") { profilesTEMP.Status = "Inactive"; }
                                else if (dr.GetString(10) == "N") { profilesTEMP.Status = "Inactive"; }
                                else if (dr.GetString(10) == "P") { profilesTEMP.Status = "Prospect"; }
                                else if (dr.GetString(10) == "H") { profilesTEMP.Status = "Waiting"; }
                                else { profilesTEMP.Status = dr.GetString(10); }
                            }

                            //profilesTEMP.RequestStatus = "Loaded"; //confirm ????  

                            AddressInformation addressinformation = new AddressInformation();
                            if (!dr.IsDBNull(15)) { addressinformation.Line1 = dr.GetString(15); }
                            if (!dr.IsDBNull(16)) { addressinformation.Line2 = dr.GetString(16); }
                            if (!dr.IsDBNull(17)) { addressinformation.Line3 = dr.GetString(17); }
                            if (!dr.IsDBNull(18)) { addressinformation.City = dr.GetString(18); }
                            if (!dr.IsDBNull(19)) { addressinformation.State = dr.GetString(19); }
                            if (!dr.IsDBNull(20)) { addressinformation.Zipcode = dr.GetString(20); }
                            profilesTEMP.AddressInformation = addressinformation;


                            ContactInformation contactinformation = new ContactInformation();
                            if (!dr.IsDBNull(11)) { contactinformation.PrimaryContact = dr.GetString(11); }
                            if (!dr.IsDBNull(12)) { contactinformation.Phone = dr.GetString(12); }
                            if (!dr.IsDBNull(13)) { contactinformation.Fax = dr.GetString(13); }
                            if (!dr.IsDBNull(14)) { contactinformation.eMail = dr.GetString(14); }
                            profilesTEMP.ContactInformation = contactinformation;

                            FootprintInformation footprintinformation = new FootprintInformation();
                            if (!dr.IsDBNull(21)) { footprintinformation.CreatedBy = dr.GetString(21); }
                            if (!dr.IsDBNull(22)) { footprintinformation.CreatedDate = dr.GetDateTime(22); }
                            footprintinformation.UpdatedBy = "cl";
                            footprintinformation.UpdatedDate = DateTime.Now;

                            profilesTEMP.FootprintInformation = footprintinformation;

                            SummaryInformation summaryinformation = new SummaryInformation();
                            if (!dr.IsDBNull(26)) { tempTotalCopies = dr.GetInt32(26); } else { tempTotalCopies = 0; }
                            if (!dr.IsDBNull(25)) { tempTotalSeries = dr.GetInt32(25); } else { tempTotalSeries = 0; }
                            summaryinformation.TotalCopies = tempTotalCopies;
                            summaryinformation.TotalSeries = tempTotalSeries;
                            profilesTEMP.SummaryInformation = summaryinformation;

                            if (!dr.IsDBNull(27))
                            {
                                loadAction = dr.GetString(27);
                                //testing ONLY
                                //loadAction = "D";
                                //LoadType = "Delta"; 
                            }
                            else
                                throw new Exception("Missing Action Type, this is a required field");

                            if (LoadType == "Delta")
                            {
                                if (loadAction != "A" && loadAction != "M" && loadAction != "D")
                                { throw new Exception("Invalid Action Type, this is a required field"); }
                            }


                            if ((LoadType == "Full") || (LoadType == "Delta" && (loadAction == "A" || loadAction == "M")))
                            {

                                //**********************************************************************
                                //MAIN INSERT UPDATE
                                //**********************************************************************
                                Boolean exceptionFlag2 = false;
                                maxRetries2 = maxRetries2Save;
                                while (maxRetries2 > 0)
                                {
                                    try
                                    {
                                        exceptionFlag2 = false;


                                        var query = new QueryDocument { };
                                        var update = new UpdateDocument { };


                                        ////WRITE THE PRODUCT TO MONGO
                                        ////log.WriteLog("WRITE THE PRODUCT TO MONGO.", false);
                                        query = new QueryDocument { { "CompassAccountNumber", profilesTEMP.CompassAccountNumber } };

                                        
                                        if (string.IsNullOrEmpty(profilesTEMP.OrganizationID))
                                        {
                                            var bsonElements = new List<BsonElement> { new BsonElement("$set", profilesTEMP.ToBsonDocument()), new BsonElement("$unset", new BsonDocument("OrganizationID", "1")) };
                                            update = new UpdateDocument(bsonElements);
                                        }
                                        else
                                        {
                                            update = new UpdateDocument { { "$set", profilesTEMP.ToBsonDocument() } };
                                        }

                                     //   update = new UpdateDocument { { "$set", profilesTEMP.ToBsonDocument() } };

                                        if (LoadType == "Full")
                                        {

                                            var model = mongoDBHelper.CreateWriteModel(query, update, true);
                                            models.Add(model);
                                            bulkWriteCount++;

                                            if (bulkWriteCount >= AppSetting.MongoBulkBatchSize) {
                                                var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, loadCollectionLogging);
                                                fileLogLoad.Write("\r\n" +
                                                             "Bulk Batch Count: " +  bulkWriteResult.ModifiedCount,
                                                     FileLogRepository.Level.INFO);

                                                models = new List<WriteModel<BsonDocument>>();
                                                bulkWriteCount = 0;

                                            }
                                            
                                        }
                                        else
                                        {
                                            var resultInsertCompass = profiles.Update(query, update, UpdateFlags.Upsert, null);
                                            var resultInsertCompassCount = resultInsertCompass.DocumentsAffected;

                                            if (resultInsertCompass.DocumentsAffected == 1)
                                            {

                                                if (resultInsertCompass.UpdatedExisting == false)
                                                { insertcounter++; }
                                                else
                                                { updatecounter++; }

                                                //call update to azure for updates
                                                var tempProfilesID = profiles.FindOneAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", profilesTEMP.CompassAccountNumber));
                                                ObjectId profilesid = tempProfilesID._id;
                                                bool loadOK = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, profilesid, fileLogLoad, AppSetting.MongoCollectionProfiles, "Upsert", azurePriorityProfiles);

                                            }
                                            else
                                            {
                                                totalSkipped++;
                                            }
                                        }


                                        if (notificationUserId != null && notificationUserId != "")
                                        {
                                            var updateNotificationUser = new UpdateDocument { { "$addToSet", new BsonDocument()
                                                                                                       {
                                                                                                                      { "NotificationUsers", notificationUserId}
                                                                                                              
                                                                                                       }} };
                                            if (LoadType == "Full")
                                            {
                                                var model = mongoDBHelper.CreateWriteModel(query, updateNotificationUser, true);
                                                models.Add(model);

                                                bulkWriteCount++;

                                                if (bulkWriteCount >= AppSetting.MongoBulkBatchSize)
                                                {
                                                    var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, loadCollectionLogging);
                                                    fileLogLoad.Write("\r\n" +
                                                                 "Bulk Batch Count: " +  bulkWriteResult.ModifiedCount,
                                                         FileLogRepository.Level.INFO);

                                                    models = new List<WriteModel<BsonDocument>>();
                                                    bulkWriteCount = 0;

                                                }
                                            }
                                            else
                                            {
                                                var resultNotificationUser = profiles.Update(query, updateNotificationUser, UpdateFlags.Upsert, null);
                                            }


                                        }



                                        maxRetries2 = 0;
                                    }
                                    catch (Exception ex2)
                                    {
                                        exceptionFlag2 = true;
                                        maxRetries2--;
                                        Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex2.Message);
                                        fileLogLoad.Write("..CompassLoad Save Failure " + ex2.Message, FileLogRepository.Level.ERROR);
                                        System.Threading.Thread.Sleep(RetryWait2);
                                        continue;
                                    }
                                }
                                if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }


                            }
                            else
                            {


                                //**********************************************************************
                                //DELETE PORTION
                                //This delete is for a delta load where the ACTION TYPE will equal "D"
                                // when a delete we need to do many things
                                // 1.  delete the profiles
                                // 2. lookup the profilesseries, if exists delete the profildseries 
                                // 3. update azure for series id with "upsert"
                                // 4. update azure for profiels with "delete"
                                // 5. update azure for profiledseries with "delete"
                                // 6. do change request updates for profiles and profiledseries
                                //**********************************************************************

                                //**********************************************************************
                                //call update to azure for deletes, check to see if the profile exists 
                                //before calling delete, azure update and change request update
                                //**********************************************************************
                                var tempProfilesID = profiles.FindOneAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", profilesTEMP.CompassAccountNumber));

                                if (tempProfilesID != null)
                                {
                                    ObjectId profilesid = tempProfilesID._id;
                                    bool loadOKDeleteProfile = RemoveProfilesDocument(maxRetries2Save, RetryWait2, profiles, profilesTEMP.CompassAccountNumber, fileLogLoad);

                                    //lookup for profiledseries to grab the series id , use when updating azure
                                    var mycursor = profiledSeries.Find(Query.EQ("ProfileID", profilesid));
                                    var mycursorcount = mycursor.Count();
                                    if (mycursorcount > 0)
                                    {
                                        string tempSeriesID;
                                        foreach (ProfiledSeries p in mycursor)
                                        {
                                            tempSeriesID = p.SeriesID;

                                            //get the profilesseries id based on the profile id and series id 
                                            var tempProfiledSeriesID = profiledSeries.FindOneAs<ProfiledSeriesIDClass>(Query.And(Query.EQ("ProfileID", profilesid),
                                                                                        Query.EQ("SeriesID", tempSeriesID)));
                                            ObjectId profiledseriesid = tempProfiledSeriesID._id;

                                            // add azure update for profiled series with "DELETE"
                                            bool loadOK = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, profiledseriesid, fileLogLoad, AppSetting.MongoCollectionProfiledSeries, "Delete", azurePriorityProfiles);

                                            //delete all profiledseries based on the profileseriesid
                                            var querydelete = Query.EQ("_id", profiledseriesid);
                                            profiledSeries.Remove(querydelete);

                                           
                                        }

                                    }


                                    //***********************************************************************
                                    //Azure Search Logic
                                    //***********************************************************************

                                    bool loadOK2 = UpdateAzureSearch(maxRetries2Save, RetryWait2, azuresearch, profilesid, fileLogLoad, AppSetting.MongoCollectionProfiles, "Delete", azurePriorityProfiles);

                                    // add azure update for profiled series with "DELETE"
                                    // add azure update for series with "UPSERT"  
                                }
                                else
                                {
                                    Console.WriteLine(DateTime.Now.ToString() + "Unable to do delete for the following Profile: " + profilesTEMP.CompassAccountNumber);
                                }





                            }
                        }
                        else
                        {
                            bypassbaddataflag = false;
                            totalSkipped++;

                        }


                    }


                    if (LoadType == "Full")
                    {
                        var bulkWriteResult = mongoDBHelper.UpdateMongoBulk(models, loadCollectionLogging);
                        fileLogLoad.Write("\r\n" +
                                     "Bulk Record Count: " +  bulkWriteResult.ModifiedCount,
                    FileLogRepository.Level.INFO);

                        var createFullAzureQueue = mongoDBHelper.CreateFullAzureQueue(AppSetting.MongoCollectionProfiles);
                        Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + " Bulk Load");
                        fileLogLoad.Write(" End " + loadCollectionLogging + " Bulk Load", FileLogRepository.Level.INFO);
                    }
                    else
                    {

                    }
                    fileLogLoad.Write("\r\n" +
                                      "Total Record Count: " + "\r\n" + totalcounter + "\r\n" +
                                      "Total Insert Count: " + insertcounter + "\r\n" +
                                      "Total Update Count: " + updatecounter + "\r\n" +
                                      "Total Skips  Count: " + totalSkipped,
                     FileLogRepository.Level.INFO);

                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

                }

                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: 0  --- No data returned from Compass");
                    fileLogLoad.Write("Total Record Count: 0  --- No data returned from Compass", FileLogRepository.Level.INFO);

                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception(ex.Message);

            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }


        }



        public static bool RemoveProfilesDocument(int maxRetries2Save, int RetryWait2, MongoCollection profiles, string tempCompassAccountNumber, FileLogRepository fileLogLoad)
        {
            //*********************************************************************
            // Delete document
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;

                    var update1 = new UpdateDocument { };
                    var query1 = (Query.EQ("CompassAccountNumber", tempCompassAccountNumber));

                    var resultOfDrop = profiles.Remove(query1);


                    var resultOfDropCount = resultOfDrop.DocumentsAffected;


                    if (resultOfDropCount != 0)
                    {
                        LoadOK = true;
                    }



                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            //loadOKTypeOut = loadOkayType;
            return LoadOK;

        }



        public static bool UpdateAzureSearch(int maxRetries2Save, int RetryWait2, MongoCollection azuresearch, ObjectId tempobjectid, FileLogRepository fileLogLoad, String tempCollection, String tempChangetype, Int32 tempAzurePriority)
        {
            //*****************************************************************+++++****
            // Add to Azure Search Queue
            //*********************************************************************e
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;
            String loadOkayType = "";

            AzureSearchQueueItem azureTEMP = new AzureSearchQueueItem();
            azureTEMP.CollectionName = tempCollection;
            azureTEMP.ChangeType = tempChangetype;
            azureTEMP.ObjectId = tempobjectid;
            azureTEMP.Priority = tempAzurePriority;
            azureTEMP.InProcessState = 0;

            FootprintInformation footprintinformation = new FootprintInformation();
            footprintinformation.CreatedDate = DateTime.Now;
            footprintinformation.CreatedBy = "cl";
            footprintinformation.UpdatedDate = DateTime.Now;
            footprintinformation.UpdatedBy = "cl";

            azureTEMP.FootprintInformation = footprintinformation;



            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;


                    //var query = new QueryDocument { { "ObjectId",  tempobjectid } };
                    //var update = new UpdateDocument { { "$set", azureTEMP.ToBsonDocument() } };
                    //var resultUpsertAzure = azuresearch.Update(query, update, UpdateFlags.Upsert , null);
                    var resultUpsertAzure = azuresearch.Insert<AzureSearchQueueItem>(azureTEMP);
                    var resultUpsertAzureCount = resultUpsertAzure.DocumentsAffected;

                    //fileLogLoad.Write("Upsert Result for ObjectID: " + "(" + tempobjectid.ToString() + "/" + "): Documents affected --" + resultUpsertAzure.DocumentsAffected.ToString(), FileLogRepository.Level.INFO);

                    LoadOK = true;
                    maxRetries2 = 0;


                }
                catch (Exception ex1)   
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..AzureSearch Upsert Failure " + ex1.Message);
                    fileLogLoad.Write("..AzureSearch Upsert Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }
            return LoadOK;

        }

    }
}
