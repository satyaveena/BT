﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using BT.TS360.Services.Compass; 
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration; 
using BT.TS360.NoSQL.Services.Compass.Services;

namespace BT.TS360.NoSQL.Services.Compass
{
    public class CompassLoadEmail
    {

        public CompassLoadEmail()
        {
        }

        public void ReadWrite()
        {
            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
            FileLogRepository fileError1 = new FileLogRepository(AppSetting.Errors1Folder, AppSetting.Errors1FilePrefix);
            //FileLogRepository fileError2 = new FileLogRepository(AppSetting.Errors2Folder, AppSetting.Errors2FilePrefix);

            String loadCollection = "LoadErrors";
            String loadCollectionLogging = "LoadErrors";

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + " Email File Creation");
            fileLogLoad.Write("Begin " + loadCollectionLogging + " Email File Creation", FileLogRepository.Level.INFO);


            Int64 mycounter = 0;

            int daysBackToUpdate = Convert.ToInt32(AppSetting.ErrorLoggingParm);

            DateTime dtNow = DateTime.Today;
            DateTime dtnowUpdate = DateTime.Today.AddDays(daysBackToUpdate);
            
            try
            {

                MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                MongoServer mongoServer = mongoClient.GetServer();
                MongoDatabase commonDatabase = mongoServer.GetDatabase(AppSetting.CommonDatabase);
                MongoCollection<LoadErrors> loadErrors = commonDatabase.GetCollection<LoadErrors>("LoadErrors");

                var mycursor = loadErrors.Find(Query.And(Query.GTE("FootprintInformation.UpdatedDate", dtnowUpdate),
                                                        (Query.Matches("LoadProgram", "cl:")),
                                                        (Query.EQ("ReportedFlag",false))));

                String emailOutputHeader = string.Format("{0}\t{1}\t{2}", "LoadProgram", "ExceptionMessage", "CreatedDate") ;                                     

                foreach (LoadErrors p in mycursor)
                {


                    if (mycounter % 1000 == 0)
                    {
                        Console.WriteLine(DateTime.Now.ToString() + " Total " + loadCollectionLogging + " Reading/Writing: " + mycounter.ToString());
                        fileLogLoad.Write("Total "+ loadCollectionLogging + " Reading/Writing: " + mycounter.ToString(), FileLogRepository.Level.INFO);
                    }
                    if (mycounter == 0 ) { fileError1.WriteErrors(emailOutputHeader,FileLogRepository.Level.INFO ); }


                    String emailOutput = string.Format("{0}\t{1}\t{2}", p.LoadProgram, p.ExceptionMessage, p.FootprintInformation.CreatedDate.ToString("yyyy-MM-dd-HHmm")); 
                    mycounter++;
                    fileError1.WriteErrors(emailOutput, FileLogRepository.Level.INFO); 
                }


                var queryUpdate = (Query.And(Query.GTE("FootprintInformation.UpdatedDate", dtnowUpdate),
                                                        (Query.Matches("LoadProgram", "cl:")),
                                                        (Query.EQ("ReportedFlag", false)))); 

                var updateUpdate = Update.Set("ReportedFlag", true);
                var resultUpdates = loadErrors.Update(queryUpdate, updateUpdate, UpdateFlags.Multi, null);

                
                var updatecounter = resultUpdates.DocumentsAffected;

                Console.WriteLine(DateTime.Now.ToString() + "Emails Records " + updatecounter.ToString());
                fileLogLoad.Write(DateTime.Now.ToString() + "Emails Records " + updatecounter.ToString(), FileLogRepository.Level.INFO);

                Console.WriteLine(DateTime.Now.ToString() + "End " + loadCollectionLogging + " Email File Creation");
                fileLogLoad.Write("End " + loadCollectionLogging + " Email File Creation", FileLogRepository.Level.INFO);


            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
        }


        public static bool LoadRedundantSeries(int maxRetries2Save, int RetryWait2, MongoCollection profiledseries, RedundantSeriesData redundantseriesTEMP, FileLogRepository fileLogLoad, string tempSeriesID)
        {
            //*********************************************************************
            // INSERT / UPDATE Portion 
            //*********************************************************************
            Boolean exceptionFlag2 = false;
            Boolean LoadOK = false;
            Int64 resultUpdateCount2 = 0;
            Int32 maxRetries2 = maxRetries2Save;

            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag2 = false;


                    var resultUpdateProfiles = profiledseries.Update(Query.EQ("SeriesID", tempSeriesID), Update.AddToSet("RedundantSeriesInformation", redundantseriesTEMP.ToBsonDocument()), UpdateFlags.None);
                    resultUpdateCount2 = resultUpdateProfiles.DocumentsAffected; 
                    if (resultUpdateCount2 != 0)
                    { {  LoadOK = true; } }
                    //else  { }
                    maxRetries2 = 0;


                }
                catch (Exception ex1)
                {
                    exceptionFlag2 = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(RetryWait2);
                    continue;
                }
            }
            if (exceptionFlag2 == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }

            return LoadOK;

        }


    }
}
