﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using System.Data.Sql; 
using System.Data; 
using System.Data.SqlClient; 
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.Services.Compass; 
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging; 


namespace BT.TS360.NoSQL.Services.Compass.Services
{
    class Repository
   {


        public Repository()
        {
        }


        public static bool insertErrors(int maxRetriesSave, int retryWait, MongoCollection loadcollection, string loadProgram, string loadErrors, FileLogRepository fileLogLoad)
        {
            //*********************************************************************
            // INSERT Portion 
            //*********************************************************************
            Boolean exceptionFlag = false;
            Boolean LoadOK = false;
            Int32 maxRetries2 = maxRetriesSave;

            LoadErrors loaderrors = new LoadErrors();

            FootprintInformation footprintinformation = new FootprintInformation();
            footprintinformation.CreatedBy = "cl";
            footprintinformation.CreatedDate = DateTime.Now;
            footprintinformation.UpdatedBy = "cl";
            footprintinformation.UpdatedDate = DateTime.Now;
            loaderrors.FootprintInformation = footprintinformation;
            loaderrors.ExceptionMessage = loadErrors; 
            loaderrors.LoadProgram = "cl:" + loadProgram;
            loaderrors.ReportedFlag = false; 
            
            while (maxRetries2 > 0)
            {
                try
                {
                    exceptionFlag = false;
                    //var resultLoad = loadcollection.Save(loadErrors.ToBsonDocument());
                    var resultLoad = loadcollection.Insert<LoadErrors>(loaderrors); 
                    var resultLoadCount = resultLoad.DocumentsAffected; 

                    if (resultLoadCount != 0)
                    {
                        { 
                            LoadOK = true;
                        }

                    }maxRetries2 = 0;

                }
                catch (Exception ex1)
                {
                    exceptionFlag = true;
                    maxRetries2--;
                    Console.WriteLine(DateTime.Now.ToString() + " ..CompassLoad Save Failure " + ex1.Message);
                    fileLogLoad.Write("..CompassLoad Save Failure " + ex1.Message, FileLogRepository.Level.ERROR);
                    System.Threading.Thread.Sleep(retryWait);
                    continue;
                }
            }
            if (exceptionFlag == true && maxRetries2 == 0) { throw new Exception("Reached Max Retry Limit, aborting process"); }

            return LoadOK;

        }

        public static bool GetOrgAndERP(string SanSuffix, out string outERPAccountNumber, out string outShipToAccountNumber, out string outBillToAccountNumber, out string outORGid, out string outAccountType, out string RowValueOut, out string outShipToAccountID, out string outSalesTerritory)
        {
            //var erpAccountNum = string.Empty;
            //var orgID = string.Empty;
            bool ReturnSuccess = false; 
            int SQLCommandTimeout;
            outORGid = null;
            outERPAccountNumber = null;
            outShipToAccountNumber = null;
            outBillToAccountNumber = null;
            outSalesTerritory = null; 
            outShipToAccountID = null; 
            outAccountType = null; 
            RowValueOut = null; 
            SQLCommandTimeout = Convert.ToInt32(AppSetting.TS360SQLCommandTimeout);

            var dataConnect = ConfigurationManager.ConnectionStrings["NextGen_Profiles"].ConnectionString;

            SqlConnection NGProfilesDBConnection = new SqlConnection(dataConnect);

            SqlDataReader dataReader = null;

            try
            {
                SqlCommand storedProc = new SqlCommand("GetERPAccountWithSAN", NGProfilesDBConnection);

                storedProc.CommandType = CommandType.StoredProcedure;

                SqlParameter SANSuffixIn = storedProc.Parameters.Add("@SANSuffix", SqlDbType.VarChar, 50);
                SANSuffixIn.Direction = ParameterDirection.Input;

                SqlParameter erpAccountnumOutput = new SqlParameter("@ERPAccountnum", SqlDbType.NVarChar, 50);
                erpAccountnumOutput.Direction = ParameterDirection.Output;

                SqlParameter  shipToAccountnumOutput = new SqlParameter("@ShipToAccountnum", SqlDbType.NVarChar, 50);
                shipToAccountnumOutput.Direction = ParameterDirection.Output;


                SqlParameter billToAccountnumOutput = new SqlParameter("@BillToAccountnum", SqlDbType.NVarChar, 50);
                billToAccountnumOutput.Direction = ParameterDirection.Output;

                SqlParameter shipToAccountIDOutput = new SqlParameter("@ShipToAccountID", SqlDbType.NVarChar, 50);
                shipToAccountIDOutput.Direction = ParameterDirection.Output;

                SqlParameter salesTerritoryOutput = new SqlParameter("@SalesTerritory", SqlDbType.NVarChar, 50);
                salesTerritoryOutput.Direction = ParameterDirection.Output;

                SqlParameter accountTypeOutput = new SqlParameter("@AccountType", SqlDbType.NVarChar, 50);
                accountTypeOutput.Direction = ParameterDirection.Output;

                SqlParameter orgIDOutput = new SqlParameter("@ORGid", SqlDbType.NVarChar, 50);
                orgIDOutput.Direction = ParameterDirection.Output;
                      
                SqlParameter returnOutput = new SqlParameter("@Return", SqlDbType.Int);
                returnOutput.Direction = ParameterDirection.Output;
                
                SqlParameter messageOutput = new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, 8000);
                messageOutput.Direction = ParameterDirection.Output;
                
                SANSuffixIn.Value = SanSuffix;
                //erpAccountnumOutput = null;
                //accountTypeOutput = null;
                //orgIDOutput = null; 
         

                
                //storedProc.Parameters.Add(SANSuffixIn); 
                storedProc.Parameters.Add(erpAccountnumOutput);
                storedProc.Parameters.Add(shipToAccountnumOutput);
                storedProc.Parameters.Add(billToAccountnumOutput);
                storedProc.Parameters.Add(shipToAccountIDOutput);
                storedProc.Parameters.Add(orgIDOutput);
                storedProc.Parameters.Add(accountTypeOutput); 
                storedProc.Parameters.Add(returnOutput);
                storedProc.Parameters.Add(messageOutput);
                storedProc.Parameters.Add(salesTerritoryOutput); 
                storedProc.CommandTimeout = SQLCommandTimeout; 
                
                NGProfilesDBConnection.Open();

                storedProc.ExecuteNonQuery();

                string dbMessage; 
                Int64  returnValue;
                if (erpAccountnumOutput.Value != null )
                { outERPAccountNumber = erpAccountnumOutput.Value.ToString(); }
               
                if (orgIDOutput.Value != null )
                { outORGid = orgIDOutput.Value.ToString(); }

                if (accountTypeOutput.Value != null  )
                { outAccountType = accountTypeOutput.Value.ToString();  }

                if (shipToAccountnumOutput.Value != null)
                { outShipToAccountNumber = shipToAccountnumOutput.Value.ToString(); }

                if (shipToAccountIDOutput.Value != null)
                { outShipToAccountID = shipToAccountIDOutput.Value.ToString(); }

                if (billToAccountnumOutput.Value != null)
                { outBillToAccountNumber = billToAccountnumOutput.Value.ToString(); }

                //dbMessage = messageOutput.Value.ToString();
                if (outERPAccountNumber == null || outERPAccountNumber == "")
                {
                    RowValueOut = "Bad SAN Number -- " + SanSuffix + "," + "ERPAccount: " + outERPAccountNumber + "," + "OrgID: " + outORGid + "," + "AccountType: " + outAccountType; 
                    ReturnSuccess = false; }
                else if (outAccountType == null || outAccountType == "")
                {
                    RowValueOut = "Bad Account Type -- " + SanSuffix + "," + "ERPAccount: " + outERPAccountNumber + "," + "OrgID: " + outORGid + "," + "AccountType: " + outAccountType;
                    ReturnSuccess = false;
                }
                else 
                {
                ReturnSuccess = true; 
                }
                
            }
            catch (Exception ex)
            {
                // log exception and exit gracefully 
                LogAPIMessage("Compass.Repository", "", "", "", ex.Message);
                throw new Exception(ex.Message, ex.InnerException);
                
            }
            finally
            {
               // if (dataReader != null)
               // {
               //     dataReader.Close();
               // }
               
                NGProfilesDBConnection.Close();
            }

            return ReturnSuccess;
        }


        public static void LogAPIMessage(
            string webMethod, string requestMessage,
            string responseMessage, string vendorAPIKey,
            string exceptionMessage 
            )
        {
            var dataConnect = ConfigurationManager.ConnectionStrings["ExceptionLogging"].ConnectionString;

            SqlConnection DBConnection = new SqlConnection(dataConnect);

            try
            {
                SqlCommand storedProc = new SqlCommand("procTS360APILogRequests", DBConnection);

                storedProc.CommandType = CommandType.StoredProcedure;


                SqlParameter webMethodIn = storedProc.Parameters.Add("@webMethod", SqlDbType.NVarChar, 50);
                webMethodIn.Direction = ParameterDirection.Input;
                webMethodIn.Value = webMethod;

                SqlParameter requestMessageIn = storedProc.Parameters.Add("@requestMessage", SqlDbType.NVarChar, 8000);
                requestMessageIn.Direction = ParameterDirection.Input;
                requestMessageIn.Value = requestMessage;

                SqlParameter responseMessageIn = storedProc.Parameters.Add("@responseMessage", SqlDbType.NVarChar, 8000);
                responseMessageIn.Direction = ParameterDirection.Input;
                responseMessageIn.Value = responseMessage;

                SqlParameter vendorAPIKeyIn = storedProc.Parameters.Add("@vendorAPIKey", SqlDbType.NVarChar, 255);
                vendorAPIKeyIn.Direction = ParameterDirection.Input;
                vendorAPIKeyIn.Value = vendorAPIKey;

                SqlParameter exceptionMessageIn = storedProc.Parameters.Add("@exceptionMessage", SqlDbType.NVarChar, 8000);
                exceptionMessageIn.Direction = ParameterDirection.Input;
                exceptionMessageIn.Value = exceptionMessage;

                SqlParameter createdOnIn = storedProc.Parameters.Add("@createdOn", SqlDbType.DateTime2, 7);
                createdOnIn.Direction = ParameterDirection.Input;
                createdOnIn.Value = DateTime.Now;

                SqlParameter createdByIn = storedProc.Parameters.Add("@createdBy", SqlDbType.NVarChar, 50);
                createdByIn.Direction = ParameterDirection.Input;
                createdByIn.Value = "TS360 API Service";

                DBConnection.Open();

                var records = storedProc.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
            finally
            {
               
                DBConnection.Close();
            }

        }

        public static  bool ValidateFields(SqlDataReader sqldatareader, string ValidationFor, out string RowValueOut)
   
        //public static   ValidateFields(SqlDataReader sqldatareader)
        {
            bool noIssues = true;
            string RowValue = "";


            if (ValidationFor == "Profiles")
            {
                //if (!sqldatareader.IsDBNull(4)) 
                //     {
                //    RowValue = RowValue + "UserName: " + sqldatareader.GetString(4); 
                //     } 
                //else { 
                //    noIssues = false; 
                //    RowValue = RowValue + "UserName: null," ; 
                //     }

                if (!sqldatareader.IsDBNull(6))
                {
                    RowValue = RowValue + "ERPAccount: " + sqldatareader.GetString(6) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "ERPAccount: null,";
                }

                if (sqldatareader.GetString(27) != "D")
                {
                    if (!sqldatareader.IsDBNull(5))
                    {
                        RowValue = RowValue + "ProfilesName: " + sqldatareader.GetString(5) + ",";
                    }
                    else
                    {
                        noIssues = false;
                        RowValue = RowValue + "ProfileName: null,";
                    }
                }

                //if (!sqldatareader.IsDBNull(7))
                //{
                //    RowValue = RowValue + "ProfileType: " + sqldatareader.GetString(7) + ",";
               // }
               // else
               // {
               //     noIssues = false;
               //     RowValue = RowValue + "ProfileType: null,";
               // }
                // ONLY DO VALIDATION WHEN NOT A DELETE ACTION TYPE
                if (sqldatareader.GetString(27) != "D")
                {
                    if (sqldatareader.IsDBNull(8))
                    {
                        noIssues = false;
                        RowValue = RowValue + "SAN: null,";
                    }
                    else
                    {
                        String workSAN = null;
                        String workSAN2 = null;
                        workSAN = sqldatareader.GetString(8);
                        workSAN2 = workSAN.Trim();
                        if (workSAN2 == "")
                        {
                            noIssues = false;
                            RowValue = RowValue + "SAN: nothing,";
                        }
                        else
                        {
                            RowValue = RowValue + "SAN: " + workSAN2;
                        }

                    }
                }
            }

            if (ValidationFor == "Series/Programs")
            {

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(0)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }

                if (!sqldatareader.IsDBNull(1))
                {
                    RowValue = RowValue + "Program: " + sqldatareader.GetString(1) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "Program: null,";
                }



            }

            if (ValidationFor == "ProfileProgram")
            {

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "ERPAccount: " + sqldatareader.GetString(0) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "ERPAccount: null,";
                }

                if (!sqldatareader.IsDBNull(1))
                {
                    RowValue = RowValue + "Program: " + sqldatareader.GetString(1) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "Program: null,";
                }



            }
            if (ValidationFor == "Series")
            {

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(0)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }
                if (sqldatareader.GetString(21) != "D")
                {
                    if (!sqldatareader.IsDBNull(1))
                    {
                        RowValue = RowValue + "SeriesName: " + sqldatareader.GetString(1) + ",";
                    }
                    else
                    {
                        noIssues = false;
                        RowValue = RowValue + "SeriesName: null,";
                    }
                }

                //if (!sqldatareader.IsDBNull(5))
                //{ Console.Write(sqldatareader.GetOrdinal("ListPrice")); }


            }

            if (ValidationFor == "SeriesRelatedSeriesIDs")

                if (!sqldatareader.IsDBNull(0))
                {  
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(0)) + ",";
                    Int64 TestSeries = 0;
                    TestSeries = sqldatareader.GetInt32(1) + sqldatareader.GetInt32(2) + sqldatareader.GetInt32(3) + sqldatareader.GetInt32(4) + sqldatareader.GetInt32(5) + sqldatareader.GetInt32(6); 

                    if (TestSeries == 0)
                    { RowValue = RowValue + "SeriesID: all zeroes,"; }
                           
                }
                else
                {

                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }

               

            if (ValidationFor == "SeriesAreaOfInterest")
            {

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(0)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }

                if (!sqldatareader.IsDBNull(1))
                {
                    RowValue = RowValue + ": " + sqldatareader.GetString(1) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SubjectCode: null,";
                }
            }

            
            if (ValidationFor == "SeriesBindingPreferences")
            {

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(0)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }

                if (!sqldatareader.IsDBNull(1))
                {
                    RowValue = RowValue + "BindingPreference: " + sqldatareader.GetString(1) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "BindingPreference: null,";
                }
            }

            if (ValidationFor == "SeriesForthcomingTitles")
            {

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(0)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }
            }

            if (ValidationFor == "ProfiledSeries")
            {

                if (!sqldatareader.IsDBNull(1))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(1)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "ERPAccountNumber: " + sqldatareader.GetString(0) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "ERPAccountNumber: null,";
                }

            }



            if (ValidationFor == "ProfiledSeries/PO")
            {

                if (!sqldatareader.IsDBNull(1))
                {
                    RowValue = RowValue + "SeriesID: " + Convert.ToString(sqldatareader.GetInt32(1)) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "SeriesID: null,";
                }

                if (!sqldatareader.IsDBNull(0))
                {
                    RowValue = RowValue + "ERPAccountNumber: " + sqldatareader.GetString(0) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "ERPAccountNumber: null,";
                }

                if (!sqldatareader.IsDBNull(2))
                {
                    RowValue = RowValue + "Status: " + sqldatareader.GetString(2) + ",";
                }
                else
                {
                    noIssues = false;
                    RowValue = RowValue + "Status: null,";
                }

            }
            
            RowValueOut = RowValue; 

            return noIssues;

        }

    
    }
}






    

