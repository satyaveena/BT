﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 

using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using BT.TS360.NoSQL.Data;
using BT.TS360.Services.Compass; 
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Services;

namespace BT.TS360.NoSQL.Services.Compass
{
    public class CompassLoad12Delete
    {

        public CompassLoad12Delete()
        {
        }

        public void Delete(string StoredProcedureName)
        {

            FileLogRepository fileLogLoad = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);
           
            String loadCollection = "Delete SP";
            String loadCollectionLogging = "Delete SP";

            Console.WriteLine(DateTime.Now.ToString() + " Begin " + loadCollectionLogging + "Delete");
            fileLogLoad.Write("Begin " + loadCollectionLogging + "Delete", FileLogRepository.Level.INFO);


            int RetryWait1 = Convert.ToInt32(AppSetting.RetryWait);
            int RetryWait2 = Convert.ToInt32(AppSetting.RetryWait);
            int RetryWait3 = Convert.ToInt32(AppSetting.RetryWait);
            int maxRetries1 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries2 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries3 = Convert.ToInt32(AppSetting.RetryTimes);
            int maxRetries1Save = Convert.ToInt32(maxRetries1);
            int maxRetries2Save = Convert.ToInt32(maxRetries2);
            int maxRetries3Save = Convert.ToInt32(maxRetries3);
            Int64 totalcounter = 0;
            Int64 deletecounter = 0;
            Int64 deletecounterProfiles = 0;
            Int64 deletecounterProfiledSeries = 0;
            Int64 deletecounterSeries = 0; 

            
            int daysBackToUpdate = Convert.ToInt32(AppSetting.RedundantProfilesUpdateParm);
            
            DateTime dtNow = DateTime.Today;
            DateTime dtnowUpdate = DateTime.Today.AddDays(daysBackToUpdate);
            //Int64 updatecounter = 0; 
            
            

            var dataConnect = ConfigurationManager.ConnectionStrings["Compass"].ConnectionString;
            //old
            SqlConnection CompassConnection = new SqlConnection(dataConnect);
            //new
            //DBTransactionODSDAO dbTransactionODSDAO = new DBTransactionODSDAO(dataConnect);
            
            SqlDataReader dr = null;

            
            try
            {
  
                SqlCommand storedProc = new SqlCommand(StoredProcedureName, CompassConnection);
                storedProc.CommandType = CommandType.StoredProcedure;
                storedProc.CommandTimeout = Convert.ToInt32(AppSetting.CompassSQLCommandTimeout);

                int daysBackDelete = Convert.ToInt32(AppSetting.DeleteDaysBack);
                DateTime dtnowDelete = DateTime.Today.AddDays(daysBackDelete);
                SqlParameter DateTimeIn = storedProc.Parameters.Add("@fromdatetime", SqlDbType.DateTime);
                DateTimeIn.Direction = ParameterDirection.Input;
                DateTimeIn.Value = dtnowDelete;

                CompassConnection.Open();
                dr = storedProc.ExecuteReader();

                if (dr.HasRows == true)
                {

                    Console.WriteLine(DateTime.Now.ToString() + " Looping through the Compass - " + loadCollectionLogging + " Results.");
                    fileLogLoad.Write("Looping through the Compass - " + loadCollectionLogging + " Results.", FileLogRepository.Level.INFO);


                    while (dr.Read())
                    {


                        //Define three collections that we can delete from... 
                        MongoClient mongoClient = new MongoClient(AppSetting.MongoDatabaseConnectionString);
                        MongoServer mongoServer = mongoClient.GetServer();
                        MongoDatabase mongodatabase = mongoServer.GetDatabase(AppSetting.MongoDatabase);

                        MongoCollection<Profile> profiles = mongodatabase.GetCollection<Profile>(AppSetting.MongoCollectionProfiles); // here we are using the class w/o id
                        MongoCollection<ProfiledSeries> profiledSeries = mongodatabase.GetCollection<ProfiledSeries>(AppSetting.MongoCollectionProfiledSeries);
                        MongoCollection<Series> series = mongodatabase.GetCollection<Series>(AppSetting.MongoCollectionSeries);
                        MongoCollection profiles2 = mongodatabase.GetCollection(AppSetting.MongoCollectionProfiles);  ////This is my workaround to get the id from Mongo. 


                        String entityName = dr.GetString(0);
                        String entityValue = dr.GetString(1); 

                        if (entityName == "Profiles")
                        {
                           var mycursor2 = profiles2.FindAs<ProfilesIDClass>(Query.EQ("CompassAccountNumber", entityValue));
                           var mycursor2count = mycursor2.Count();
                           foreach (ProfilesIDClass pp in mycursor2)
                           {   //get the profile id for the account to delete
                               ObjectId profilesid = pp._id;
                               //Delete the Profiles
                               var querydeleteProfiles = Query.EQ("_id", profilesid);
                               var resultDeletes1 = profiles.Remove(querydeleteProfiles, RemoveFlags.None);
                               deletecounterProfiles = deletecounterProfiles + resultDeletes1.DocumentsAffected; 
                               deletecounter = deletecounter + resultDeletes1.DocumentsAffected;

                               //Delete any ProfiledSeries based on the profile id 
                               var querydeleteProfiledSeries = Query.EQ("ProfileID", profilesid );
                               var resultDeletes2 = profiledSeries.Remove(querydeleteProfiledSeries,RemoveFlags.None);
                               deletecounterProfiledSeries = deletecounterProfiledSeries + resultDeletes2.DocumentsAffected; 
                               deletecounter = deletecounter + resultDeletes2.DocumentsAffected;

                            }
                        }

                        if (entityName == "Series")
                        {

                            //Delete the Series based on the series id
                            var querydeleteSeries = Query.EQ("SeriesID", entityValue);
                            var resultDeletes3 = series.Remove(querydeleteSeries, RemoveFlags.None);
                            deletecounter = deletecounter + resultDeletes3.DocumentsAffected;
                            deletecounterSeries = deletecounterSeries + resultDeletes3.DocumentsAffected; 

                            //Delete any ProfiledSeries based on the series id 
                            var querydeleteProfiledSeries = Query.EQ("SeriesID", entityValue);
                            var resultDeletes4 = profiledSeries.Remove(querydeleteProfiledSeries, RemoveFlags.None);
                            deletecounter = deletecounter + resultDeletes4.DocumentsAffected;
                            deletecounterProfiledSeries = deletecounterProfiledSeries + resultDeletes4.DocumentsAffected; 
                        }
                    }
                }
                else
                {
                    Console.WriteLine(DateTime.Now.ToString() + " Total Record Count: 0  --- No data returned from Compass");
                    fileLogLoad.Write("Total Record Count: 0  --- No data returned from Compass", FileLogRepository.Level.INFO);
                    Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                    fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);
                }

                Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Deleted: " + deletecounter);
                Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Deleted:(series) " + deletecounterSeries);
                Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Deleted:(profiles) " + deletecounterProfiles);
                Console.WriteLine(DateTime.Now.ToString() + " " + "Total Records Deleted:(profiledseries) " + deletecounterProfiledSeries);

                Console.WriteLine(DateTime.Now.ToString() + " End Delete " + loadCollectionLogging );

                fileLogLoad.Write(                            "\r\n" + "Total Records Deleted: " + deletecounter + "\r\n"
                                                                     + "Total Records Deleted:(series) " + deletecounterSeries + "\r\n"
                                                                     + "Total Records Deleted:(profiles) " + deletecounterProfiles + "\r\n"
                                                                     + "Total Records Deleted:(profiledseries) " + deletecounterProfiledSeries + "\r\n"
                                                                     + "End Delete " + loadCollectionLogging  , FileLogRepository.Level.INFO);
                Console.WriteLine(DateTime.Now.ToString() + " End " + loadCollectionLogging + "Load");
                fileLogLoad.Write(" End " + loadCollectionLogging + "Load", FileLogRepository.Level.INFO);

            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
        }






    }
}
