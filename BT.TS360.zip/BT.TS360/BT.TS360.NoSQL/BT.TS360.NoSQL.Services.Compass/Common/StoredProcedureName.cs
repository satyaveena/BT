﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.Common.Constants

{
    public class StoredProcedureName
    {
        #region Compass

        public const string TS360_GetProfiles = "usp_TS360_GetProfiles";
        public const string TS360_GETProfiledSeriesRedundant = "usp_TS360_GetProfiledSeriesRedundantSeries";
        public const string TS360_Delete = "usp_TS360_Delete";
        public const string TS360GetSeriesBindingPreference = "usp_TS360_GetSeriesBindingPreference";
        public const string TS360GetSeriesRelatedSeries = "usp_TS360_GetSeriesRelatedSeries";
        public const string TS360_GetSeriesAreaOfInterest = "usp_TS360_GetSeriesAreaOfInterest";
        public const string TS360_GetSeriesAudiences = "usp_TS360_GetSeriesAudiences";
        public const string TS360_GetSeries = "usp_TS360_GetSeries";
        public const string TS360_GetSeriesPrograms = "usp_TS360_GetSeriesPrograms";
        public const string TS360_GetSeriesForthcomingTitles = "usp_TS360_GetSeriesForthcomingTitles";
        public const string TS360_GetProfiledSeriesFormatPreference = "usp_TS360_GetProfiledSeriesFormatPreference";
        public const string TS360_GetProfiledSeriesPO = "usp_TS360_GetProfiledSeriesPO";
        public const string TS360_GetProfiledSeries = "usp_TS360_GetProfiledSeries";
        public const string TS360_GetProfileStatus = "usp_TS360_GetProfileStatus";
        public const string TS360_GetProfiledProgram = "usp_TS360_GetProfiledProgram";


        #endregion

    }

}
