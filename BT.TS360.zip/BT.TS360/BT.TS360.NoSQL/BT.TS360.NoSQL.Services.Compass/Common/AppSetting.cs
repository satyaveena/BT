﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 

namespace BT.TS360.NoSQL.Services.Compass.Common.Configuration
{
    public class AppSetting
    {
        # region connection string
        public static string CompassDatabaseConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["Compass"].ToString(); }
        }

        public static string MongoDatabaseConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["MongoProducts"].ToString(); }
        }

        public static string ElmahConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["Elmah"].ToString(); }
        }

        # endregion connection string

        public static string LogFolder
        {
            get { return ConfigurationManager.AppSettings["LogFolder"].ToString(); }
        }

        public static string LogFilePrefix
        {
            get { return ConfigurationManager.AppSettings["LogFilePrefix"].ToString(); }
        }

        public static string Errors1Folder
        {
            get { return ConfigurationManager.AppSettings["Errors1Folder"].ToString(); }
        }

        public static string Errors1FilePrefix
        {
            get { return ConfigurationManager.AppSettings["Errors1FilePrefix"].ToString(); }
        }

        public static string Errors2Folder
        {
            get { return ConfigurationManager.AppSettings["Errors2Folder"].ToString(); }
        }

        public static string Errors2FilePrefix
        {
            get { return ConfigurationManager.AppSettings["Errors2FilePrefix"].ToString(); }
        }


        public static string Environment
        {
            get { return ConfigurationManager.AppSettings["Environment"].ToString(); }
        }


        public static string EmailOnFailure
        {
            get { return ConfigurationManager.AppSettings["EmailOnFailure"].ToString(); }
        }
        public static string EmailOnFailureErrors1
        {
            get { return ConfigurationManager.AppSettings["EmailOnFailureErrors1"].ToString(); }
        }

        public static string EmailOnFailureErrors2
        {
            get { return ConfigurationManager.AppSettings["EmailOnFailureErrors2"].ToString(); }
        }


        public static string EmailOnSuccess
        {
            get { return ConfigurationManager.AppSettings["EmailOnSuccess"].ToString(); }
        }

        public static string EmailToRecipients
        {
            get { return ConfigurationManager.AppSettings["EmailToRecipients"].ToString(); }
        }

        public static string EmailToRecipientsErrors1
        {
            get { return ConfigurationManager.AppSettings["EmailToRecipientsErrors1"].ToString(); }
        }

        public static string EmailToRecipientsErrors2
        {
            get { return ConfigurationManager.AppSettings["EmailToRecipientsErrors2"].ToString(); }
        }

        public static string EmailServer
        {
            get { return ConfigurationManager.AppSettings["EmailServer"].ToString(); }
        }

        public static string RunDeltaorFullCompassLoad
        {
            get { return ConfigurationManager.AppSettings["RunDeltaorFullCompassLoad"].ToString(); }
        }


        public static string RunProfilesLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfilesLoad"].ToString(); }
        }

        public static string RunProfilesProgramsLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfilesProgramsLoad"].ToString(); }
        }

        public static string RunCompassLoadDelete
        {
            get { return ConfigurationManager.AppSettings["RunCompassLoadDelete"].ToString(); }
        }


        public static string RunProfilesSeriesLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfiledSeriesLoad"].ToString(); }
        }

        public static string RunProfiledSeriesPOLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfiledSeriesPOLoad"].ToString(); }
        }

        public static string RunProfiledSeriesPOGridLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfiledSeriesPOGridLoad"].ToString(); }
        }

        public static string RunProfilesSeriesProfilesRedundantDataLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfilesSeriesProfilesRedundantDataLoad"].ToString(); }
        }

        public static string RunProfilesSeriesSeriesRedundantDataLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfilesSeriesSeriesRedundantDataLoad"].ToString(); }
        }

        public static string RunProfiledSeriesRedundantDataProgramTypeLoad
        {
            get { return ConfigurationManager.AppSettings["RunProfiledSeriesRedundantDataProgramTypeLoad"].ToString(); }
        }


        public static string RunSeriesLoad
        {
            get { return ConfigurationManager.AppSettings["RunSeriesLoad"].ToString(); }
        }

        public static string RunSeriesProgramTypeLoad
        {
            get { return ConfigurationManager.AppSettings["RunSeriesProgramsLoad"].ToString(); }
        }

        public static string RunSeriesAreaOfInterestLoad
        {
            get { return ConfigurationManager.AppSettings["RunSeriesAreaOfInterestLoad"].ToString(); }
        }

        public static string RunSeriesForthcomingTitles
        {
            get { return ConfigurationManager.AppSettings["RunSeriesForthcomingTitles"].ToString(); }
        }

        public static string RunSeriesAudienceLoad
        {
            get { return ConfigurationManager.AppSettings["RunSeriesAudienceLoad"].ToString(); }
        }

        public static string RunSeriesRelatedSeriesLoad
        {
            get { return ConfigurationManager.AppSettings["RunSeriesRelatedSeriesLoad"].ToString(); }
        }

        public static string RunSeriesBindingPreferenceLoad
        {
            get { return ConfigurationManager.AppSettings["RunSeriesBindingPreferenceLoad"].ToString(); }
        }

        public static string RunSeriesAudience
        {
            get { return ConfigurationManager.AppSettings["RunSeriesAudience"].ToString(); }
        }



        public static String DeltaDaysBack
        {
            get { return ConfigurationManager.AppSettings["DeltaDaysBack"].ToString(); }
        }

        public static String DeleteDaysBack
        {
            get { return ConfigurationManager.AppSettings["DeleteDaysBack"].ToString(); }
        }



        public static String RetryWait
        {
            get { return ConfigurationManager.AppSettings["RetryWait"].ToString(); }
        }
        public static String RetryTimes
        {
            get { return ConfigurationManager.AppSettings["RetryTimes"].ToString(); }
        }

        public static String MongoDatabase
        {
            get { return ConfigurationManager.AppSettings["MongoDatabase"].ToString(); }
        }

        public static String MongoDatabaseProducts
        {
            get { return ConfigurationManager.AppSettings["MongoDatabaseProducts"].ToString(); }
        }


        public static String MongoCollectionSeries
        {
            get { return ConfigurationManager.AppSettings["MongoCollectionSeries"].ToString(); }
        }


        public static String MongoCollectionProfiles
        {
            get { return ConfigurationManager.AppSettings["MongoCollectionProfiles"].ToString(); }
        }

        public static int MongoBulkBatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MongoBulkBatchSize"]); }
        }


        public static String MongoCollectionProfiledSeries
        {
            get { return ConfigurationManager.AppSettings["MongoCollectionProfiledSeries"].ToString(); }
        }

        public static String MongoCollectionAzureQueue
        {
            get { return ConfigurationManager.AppSettings["MongoCollectionAzureQueue"].ToString(); }
        }



        public static String MongoCollectionProducts
        {
            get { return ConfigurationManager.AppSettings["MongoCollectionProducts"].ToString(); }
        }

        public static String CommonDatabase
        {
            get { return ConfigurationManager.AppSettings["CommonDatabase"].ToString(); }
        }

        public static String TimeToExecuteHour
        {
            get { return ConfigurationManager.AppSettings["TimeToExecuteHour"].ToString(); }
        }

        public static String TimeIntervalToCheck
        {
            get { return ConfigurationManager.AppSettings["TimeIntervalToCheck"].ToString(); }
        }

        public static String TimeLastUpdated
        {
            get { return ConfigurationManager.AppSettings["TimeLastUpdated"].ToString(); }
        }



        public static String TS360SQLCommandTimeout
        {
            get { return ConfigurationManager.AppSettings["TS360SQLCommandTimeout"].ToString(); }
        }

        public static String CompassSQLCommandTimeout
        {
            get { return ConfigurationManager.AppSettings["CompassSQLCommandTimeout"].ToString(); }
        }


        public static String RedundantSeriesUpdateParm
        {
            get { return ConfigurationManager.AppSettings["RedundantSeriesUpdateParm"].ToString(); }
        }

        public static String RedundantProfilesUpdateParm
        {
            get { return ConfigurationManager.AppSettings["RedundantProfilesUpdateParm"].ToString(); }
        }

        public static String ErrorLoggingParm
        {
            get { return ConfigurationManager.AppSettings["ErrorLoggingParm"].ToString(); }
        }

        public static String DeltaDaysBackParm
        {
            get { return ConfigurationManager.AppSettings["DeltaDaysBackParm"].ToString(); }
        }

        public static String DetailedLogging
        {
            get { return ConfigurationManager.AppSettings["DetailedLogging"].ToString(); }
        }

        public static String AzurePriorityProfiles
        {
            get { return ConfigurationManager.AppSettings["AzurePriorityProfiles"].ToString(); }
        }
        public static String AzurePriorityProfiledSeries
        {
            get { return ConfigurationManager.AppSettings["AzurePriorityProfiledSeries"].ToString(); }
        }
        public static String AzurePrioritySeries
        {
            get { return ConfigurationManager.AppSettings["AzurePrioritySeries"].ToString(); }
        }

    }

    
}
