﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Services.Compass.Common.FileLogging;
using BT.TS360.NoSQL.Services.Compass.Common.Configuration;
using BT.TS360.NoSQL.Services.Compass.Services;
using BT.TS360.NoSQL.Services.Compass.Common;
using BTNextGen.Elmah;
using System.Timers;
using System.Configuration; 

namespace BT.TS360.NoSQL.Services.Compass
{
    public partial class Service1 : ServiceBase
    {

        private Timer timer1 = null;
        FileLogRepository fileLog = new FileLogRepository(AppSetting.LogFolder, AppSetting.LogFilePrefix);


        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {

            timer1 = new Timer();
            Int32 TimeIntervalToCheck = Convert.ToInt32(AppSetting.TimeIntervalToCheck);
            this.timer1.Interval = TimeIntervalToCheck;
            this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.CompassService);
            timer1.Enabled = true;
            fileLog.Write("Starting Compass Service", FileLogRepository.Level.INFO);
            fileLog.Write("Interval: " + TimeIntervalToCheck.ToString(), FileLogRepository.Level.INFO); 
        }

        protected override void OnStop()
        {
            timer1.Enabled = false;
            fileLog.Write("Stopping Compass Service", FileLogRepository.Level.INFO);
        }

        public void CompassService(object sender, ElapsedEventArgs e)
        {



            CompassLoadMain compassload = new CompassLoadMain();
            compassload.Main();




        }
    }
}
