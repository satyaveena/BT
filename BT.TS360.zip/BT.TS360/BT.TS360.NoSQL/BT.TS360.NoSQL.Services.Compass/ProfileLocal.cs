﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.Services.Compass
{
    [BsonIgnoreExtraElements]
    public class ProfilesIDClass
    {
        [BsonId]
        public ObjectId _id { get; set; }

        //public Profiles ProfilesLocal { get; set;  }  // This is a workaround to get around the fact that id wasn't included in the model 


    }

    [BsonIgnoreExtraElements]
    public class Profilesxxxx
    {
        //[BsonId]
        //public ObjectId ProfileID { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public string TS360UserName { get; set; }
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public string CompassAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string ERPAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string SAN { get; set; }
        [BsonIgnoreIfNull]
        public string AccountType { get; set; }
        [BsonIgnoreIfNull]
        public string ProfileType { get; set; }
        [BsonIgnoreIfNull]
        public string Notes { get; set; }
        [BsonIgnoreIfNull]
        public string RequestStatus { get; set; }
        [BsonIgnoreIfNull]
        public string Status { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }
        [BsonIgnoreIfNull]
        public ContactInformationxxxx ContactInformation { get; set; }
        [BsonIgnoreIfNull]
        public AddressInformationxxxx AddressInformation { get; set; }
        [BsonIgnoreIfNull]
        public SummaryInformationxxxx SummaryInformation { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformationxxxx FootprintInformation { get; set; }
    }

    public class ContactInformationxxxx  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string PrimaryContact { get; set; }
        [BsonIgnoreIfNull]
        public string Phone { get; set; }
        [BsonIgnoreIfNull]
        public string Fax { get; set; }
        [BsonIgnoreIfNull]
        public string eMail { get; set; }
    }

    public class AddressInformationxxxx //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string Line1 { get; set; }
        [BsonIgnoreIfNull]
        public string Line2 { get; set; }
        [BsonIgnoreIfNull]
        public string Line3 { get; set; }
        [BsonIgnoreIfNull]
        public string City { get; set; }
        [BsonIgnoreIfNull]
        public string State { get; set; }
        [BsonIgnoreIfNull]
        public string Zipcode { get; set; }
    }

    public class FootprintInformationxxxx  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string CreatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime CreatedDate { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDate { get; set; }
    }

    public class SummaryInformationxxxx  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public int? TotalCopies { get; set; }
        [BsonIgnoreIfNull]
        public int? TotalSeries { get; set; }
    }
}







