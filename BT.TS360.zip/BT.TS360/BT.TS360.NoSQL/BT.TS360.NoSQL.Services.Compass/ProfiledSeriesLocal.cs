﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.Services.Compass
{
    [BsonIgnoreExtraElements]
    public class ProfiledSeriesIDClass
    {
        [BsonId]
        public ObjectId _id { get; set; }

        //public Profiles ProfileSeriesLocal { get; set;  }  // This is a workaround to get around the fact that id wasn't included in the model 


    }

}







