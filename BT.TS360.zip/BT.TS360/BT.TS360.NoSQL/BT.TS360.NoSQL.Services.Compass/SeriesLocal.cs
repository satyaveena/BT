﻿
using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.Services.Compass
{
    [BsonIgnoreExtraElements]
    public class SeriesIDClass
    {
        [BsonId]
        public ObjectId _id { get; set; }

        //public Series SeriesLocal { get; set;  }  // This is a workaround to get around the fact that id wasn't included in the model 
    }


    [BsonIgnoreExtraElements]
    public class Serieszzzz
    {
        public string SeriesID { get; set; }
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }
        [BsonIgnoreIfNull]
        public string Publisher { get; set; }
        [BsonIgnoreIfNull]
        public string Format { get; set; }
        [BsonIgnoreIfNull]
        public LatestIssueInformationzzzz LatestIssueInformation { get; set; }
        [BsonIgnoreIfNull]
        public string Cycle { get; set; }
        [BsonIgnoreIfNull]
        public string[] AreasOfInterest { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Audiences { get; set; }
        [BsonIgnoreIfNull]
        public string Annotations { get; set; }
        [BsonIgnoreIfNull]
        public string ReadingLevel { get; set; }
        [BsonIgnoreIfNull]
        public string Author { get; set; }
        [BsonIgnoreIfNull]
        public List<string> RelatedSeriesIDs { get; set; }
        [BsonIgnoreIfNull]
        public List<string> BindingPreferences { get; set; }
        [BsonIgnoreIfNull]
        public Boolean? Status { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformationzzzz FootprintInformation { get; set; }
    }

    public class LatestIssueInformationzzzz //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string ISBN { get; set; }
        [BsonIgnoreIfNull]
        public decimal ListPrice { get; set; }
        [BsonIgnoreIfNull]
        public DateTime PublicationDate { get; set; }
        [BsonIgnoreIfNull]
        public string Edition { get; set; }
        [BsonIgnoreIfNull]
        public string Title { get; set; }
        [BsonIgnoreIfNull]
        public string Author { get; set; }
    }

    public class FootprintInformationzzzz  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string CreatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime CreatedDate { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDate { get; set; }
    }

    //public class AreasOfInterest
    //{
    //    [BsonIgnoreIfNull]
    //    public string AreaOfInterest { get; set; }
    //}

}


