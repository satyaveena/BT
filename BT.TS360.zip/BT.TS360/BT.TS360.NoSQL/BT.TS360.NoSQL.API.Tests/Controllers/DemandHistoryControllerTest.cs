﻿using System;
using System.Net;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BT.TS360.NoSQL.API;
using BT.TS360.NoSQL.API.Controllers;
using BT.TS360.NoSQL.API.Services;
using System.Web.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

using BT.TS360.NoSQL.API.Models;
using System.Diagnostics;
using Newtonsoft.Json;



namespace BT.TS360.NoSQL.API.Tests.Controllers
{

    [TestClass]
    public class DemandHistoryControllerTest
    {

        public static string DemandHistoryURI = ConfigurationManager.AppSettings["DemandHistoryAPIURI"].ToString();
        public static string BTKeyWithDemand = ConfigurationManager.AppSettings["DemandHistoryBTKeyWithDemand"].ToString();
        public static string BTKeyWithPublicationDate = ConfigurationManager.AppSettings["DemandHistoryBTKeyWithPublicationDate"].ToString();
        public static string BTKeyNoPulicationDate = ConfigurationManager.AppSettings["DemandHistoryBTKeyNoPulicationDate"].ToString();
        public static string BTKeyWithMOMDemand = ConfigurationManager.AppSettings["DemandHistoryBTKeyWithMOMDemand"].ToString();
        public static string BTKeyWithLargeDemand = ConfigurationManager.AppSettings["DemandHistoryBTKeyWithLargeDemand"].ToString();
        public static string BTKeyWithRENDemand = ConfigurationManager.AppSettings["DemandHistoryBTKeyWithRENDemand"].ToString();
        public static string BTKeyWithRNODemand = ConfigurationManager.AppSettings["DemandHistoryBTKeyWithRNODemand"].ToString();

        [TestMethod]
        public void DemandHistoryPost_NoBTKey_ErrorCode1Returned()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            var result = GetDemandHistory(request);

            Assert.AreEqual("1", result.ErrorCode);
        }

        [TestMethod]
        public void DemandHistoryPost_ProductNotFound_ErrorCode2Returned()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = "NOBTKEYTORETURN";
            var result = GetDemandHistory(request);

            Assert.AreEqual("2", result.ErrorCode);
        }

        [TestMethod]
        public void DemandHistoryPost_NegativePageIndex_NoErrorCodeReturned()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithDemand;
            request.PageIndex = -1;
            var result = GetDemandHistory(request);

            Assert.IsNull(result.ErrorCode);
        }
        
        [TestMethod]
        public void DemandHistoryPost_NoPublicationDate_PostPublicationDemandIsNull()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyNoPulicationDate;
            var result = GetDemandHistory(request);

            Assert.IsNull(result.Data.PostPublicationDemand);
        }

        [TestMethod]
        public void DemandHistoryPost_NoPublicationDate_PrePublicationDemandIsNull()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyNoPulicationDate;
            var result = GetDemandHistory(request);

            Assert.IsNull(result.Data.PrePublicationDemand);
        }

        [TestMethod]
        public void DemandHistoryPost_ExisitingPublicationDate_PrePublicationDemandHasValue()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithPublicationDate;
            var result = GetDemandHistory(request);

            Assert.IsTrue(result.Data.PrePublicationDemand.HasValue);
        }

        [TestMethod]
        public void DemandHistoryPost_ExisitingPublicationDate_PostPublicationDemandHasValue()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithPublicationDate;
            var result = GetDemandHistory(request);

            Assert.IsTrue(result.Data.PostPublicationDemand.HasValue);
        }
       
        [TestMethod]
        public void DemandHistoryPost_ExisitingDemand_DemandDataReturned()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithDemand;
            var result = GetDemandHistory(request);

            Assert.IsNotNull(result.Data.DemandHistoryResults);
        }

        [TestMethod]
        public void DemandHistoryPost_NoPrimarySecondaryWareHouse_NoIndicatorAddedToDemandResults()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithDemand;
            var result = GetDemandHistory(request);
            foreach (var warehouse in result.Data.DemandHistoryResults[0].WareHouses)
            {
                Assert.AreEqual(" ", warehouse.WarehouseType);
            }
        }

        [TestMethod]
        public void DemandHistoryPost_PrimaryWareHouse_PIndicatorAddedToDemandResults()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithMOMDemand;
            request.PrimaryWareHouseCode = "MOM";
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                    if (wareHouse.WarehouseID == request.PrimaryWareHouseCode)
                        Assert.AreEqual("P", wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_SecondaryWareHouse_SIndicatorAddedToDemandResults()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithMOMDemand;
            request.SecondaryWareHouseCode = "MOM";
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                    if (wareHouse.WarehouseID == request.SecondaryWareHouseCode)
                        Assert.AreEqual("S", wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_NoPrimarySecondaryWarehouse_WareHouseTypeNotNull()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithDemand;
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                        Assert.IsNotNull(wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_ExisitingDemand_DemandPeriodSequencedDescending()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithDemand;
            var result = GetDemandHistory(request);
            int previousDemandPeriod = 0;
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                if (previousDemandPeriod != 0)
                    Assert.IsTrue(previousDemandPeriod > int.Parse(demandHistoryResult.DemandPeriod));

                    previousDemandPeriod = int.Parse(demandHistoryResult.DemandPeriod);
            }
        }

        [TestMethod]
        public void DemandHistoryPost_PageIndex2_DemandResultsReturned()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithLargeDemand;
            request.PageIndex = 2;
            var result = GetDemandHistory(request);

            Assert.IsNotNull(result.Data.DemandHistoryResults);
        }

        [TestMethod]
        public void DemandHistoryPost_PageIndex2_DemandResultsReturnedAreOlderThanPage1()
        {

            DemandHistoryRequest request = new DemandHistoryRequest { BTKey = BTKeyWithLargeDemand, PageIndex = 1 };
            DemandHistoryRequest request2 = new DemandHistoryRequest { BTKey = BTKeyWithLargeDemand, PageIndex = 2 };

            var resultPage1 = GetDemandHistory(request);
            var resultPage2 = GetDemandHistory(request2);

            int lastDemandPeriodPage1 = int.Parse(resultPage1.Data.DemandHistoryResults[11].DemandPeriod);
            int firstDemandPeriodPage2 = int.Parse(resultPage2.Data.DemandHistoryResults[0].DemandPeriod);
            Assert.IsTrue(lastDemandPeriodPage1 > firstDemandPeriodPage2);
        }

        [TestMethod]
        public void DemandHistoryPost_PrimaryWareHouseRNO_PIndicatorAddedToDemandResultsForREN()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithRENDemand;
            request.PrimaryWareHouseCode = "RNO";
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                    if (wareHouse.WarehouseID == "REN")
                        Assert.AreEqual("P", wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_PrimaryWareHouseREN_PIndicatorAddedToDemandResultsForREN()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithRENDemand;
            request.PrimaryWareHouseCode = "REN";
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                    if (wareHouse.WarehouseID == "REN")
                        Assert.AreEqual("P", wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_SecondaryWareHouseRNO_SIndicatorAddedToDemandResultsForREN()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithRENDemand;
            request.SecondaryWareHouseCode = "RNO";
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                    if (wareHouse.WarehouseID == "REN")
                        Assert.AreEqual("S", wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_SecondaryWareHouseREN_SIndicatorAddedToDemandResultsForREN()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithRENDemand;
            request.SecondaryWareHouseCode = "REN";
            var result = GetDemandHistory(request);
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                foreach (var wareHouse in demandHistoryResult.WareHouses)
                {
                    if (wareHouse.WarehouseID == "REN")
                        Assert.AreEqual("S", wareHouse.WarehouseType);
                }
            }
        }

        [TestMethod]
        public void DemandHistoryPost_ExistingRNODemand_RENDemandIsreturnedNoRNODemandReturned()
        {

            DemandHistoryRequest request = new DemandHistoryRequest();
            request.BTKey = BTKeyWithRNODemand;
            var result = GetDemandHistory(request);
            bool containsRENWarehouse = false;
            bool containsRNOWarehouse = false;
            foreach (var demandHistoryResult in result.Data.DemandHistoryResults)
            {
                int indexREN = Array.FindIndex(demandHistoryResult.WareHouses, x => x.WarehouseID == "REN");
                int indexRNO = Array.FindIndex(demandHistoryResult.WareHouses, x => x.WarehouseID == "RNO");
                if (indexREN >= 0)
                    containsRENWarehouse = true;
                if (indexRNO >= 0)
                    containsRNOWarehouse = true;
            }
            Assert.IsTrue(containsRENWarehouse && !containsRNOWarehouse);
        }
        

        private static NoSqlServiceResult<DemandHistoryResponse> GetDemandHistory(DemandHistoryRequest data)
        {
            // Create a WebClient to POST the request
            using (WebClient client = new WebClient())
            {
                // Set the header so it knows we are sending JSON
                client.Headers[HttpRequestHeader.ContentType] = "application/json";

                // Serialise the data we are sending in to JSON
                string serialisedData = JsonConvert.SerializeObject(data);

                // Make the request
                var response = client.UploadString(DemandHistoryURI, serialisedData);

                // Deserialise the response into a GUID
                return JsonConvert.DeserializeObject<NoSqlServiceResult<DemandHistoryResponse>>(response);
            }
        }
    }
}
