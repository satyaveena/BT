﻿using System;
using System.Net;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BT.TS360.NoSQL.API;
using BT.TS360.NoSQL.API.Controllers;
using BT.TS360.NoSQL.API.Services;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;

using BT.TS360.NoSQL.API.Models;
using System.Diagnostics;
using Newtonsoft.Json;

namespace BT.TS360.NoSQL.API.Tests.Controllers
{

    [TestClass]
    public class InventoryDemandControllerTest
    {
        public static string InventoryDemandURI = ConfigurationManager.AppSettings["InventoryDemandAPIURI"].ToString();
        public static string BTKeyWithInventory = ConfigurationManager.AppSettings["InventoryDemandBTKeyWithInventory"].ToString();
        public static string BTKey2WithInventory = ConfigurationManager.AppSettings["InventoryDemandBTKey2WithInventory"].ToString();
        public static string BTKeyWithVIPInventory = ConfigurationManager.AppSettings["InventoryDemandBTKeyWithVIPInventory"].ToString();
        public static string BTKeyWithNoVIPInventory = ConfigurationManager.AppSettings["InventoryDemandBTKeyWithNoVIPInventory"].ToString();
        public static string BTKeyEBookRightToVendFalse = ConfigurationManager.AppSettings["InventoryDemandBTKeyEBookRightToVendFalse"].ToString();
        public static string BTKeyEBookRightToVendTrue = ConfigurationManager.AppSettings["InventoryDemandBTKeyEBookRightToVendTrue"].ToString();
        public static string BTKeyWithRENInventory = ConfigurationManager.AppSettings["InventoryDemandBTKeyWithRENInventory"].ToString();
        public static string BTKeyWithRNOInventory = ConfigurationManager.AppSettings["InventoryDemandBTKeyWithRNOInventory"].ToString();

        [TestMethod]
        public void InventoryDemandPost_NoBTKey_ErrorCode1Returned()
        {
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            request.Warehouses = warehouseList.ToArray();
            request.CountryCode = "US";
            request.VIPEnabled = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("1", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_EmptyBTKeyArray_ErrorCode1Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            request.Warehouses = warehouseList.ToArray();
            request.BTKeys = btKeyList.ToArray();
            request.CountryCode = "US";
            request.VIPEnabled = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("1", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_InvalidLEIndicator_ErrorCode2Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "Y" });
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            request.Warehouses = warehouseList.ToArray();
            request.BTKeys = btKeyList.ToArray();
            request.CountryCode = "US";
            request.VIPEnabled = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("2", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_NoLEIndicator_ErrorCode2Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1});
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            request.Warehouses = warehouseList.ToArray();
            request.BTKeys = btKeyList.ToArray();
            request.CountryCode = "US";
            request.VIPEnabled = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("2", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_NoWareHouses_ErrorCode3Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            request.BTKeys = btKeyList.ToArray();
            request.CountryCode = "US";
            request.VIPEnabled = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("3", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_EmptyWareHouseArray_ErrorCode3Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> wareHouseList = new List<InventoryDemandWareHouses>();
            var wareHouseArray = wareHouseList.ToArray();
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = wareHouseArray;
            request.CountryCode = "US";
            request.VIPEnabled = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("3", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_InvalidVIPEnabled_ErrorCode4Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "Y";
            request.CountryCode = "US";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("4", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_VIPEnabledMissingMarketType_ErrorCode5Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.CountryCode = "US";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("5", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_VIPEnabledInvalidMarketType_ErrorCode5Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "-1";
            request.CountryCode = "US";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("5", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_NoCountryCode_ErrorCode6Returned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "0";

            var result = GetInventoryResults(request);
            var errorCode = result.ErrorCode;


            Assert.AreEqual("6", errorCode);

        }

        [TestMethod]
        public void InventoryDemandPost_ProductNotFound_NoInventoryDataReturned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = "NOBTKEYTORETURN", PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(0, result.Data.InventoryResults[0].Warehouses[0].InStockForRequest);
        }

        [TestMethod]
        public void InventoryDemandPost_ProductFound_InventoryDataReturned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "MOM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreNotEqual(0, result.Data.InventoryResults[0].Warehouses[0].InStockForRequest);
        }

        [TestMethod]
        public void InventoryDemandPost_DomesticRetailVIPEnabled_VIEWareHouseReturned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("VIE", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
        }

        [TestMethod]
        public void InventoryDemandPost_DomesticLibraryVIPEnabled_SUPWareHouseReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "1";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("VIP", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
        }

        [TestMethod]
        public void InventoryDemandPost_InternationalRetailVIPEnabled_SUPWareHouseReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "0";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual("VIP", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
        }

        [TestMethod]
        public void InventoryDemandPost_InternationalLibraryVIPEnabled_SUPWareHouseReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "1";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual("VIP", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
        }

        [TestMethod]
        public void InventoryDemandPost_4WareHousesRequested_4WareHousesReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "SOM" });
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "MOM" });
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "REN" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual(4, result.Data.InventoryResults[0].Warehouses.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_SequencedBTKeys_BTKeySequenceIsMaintained()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKey2WithInventory, PagePosition = 2, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual(btKeyList[1].BTKey, result.Data.InventoryResults[0].BTKey);
        }

        [TestMethod]
        public void InventoryDemandPost_2BTKeysRequested_2BTKeysInventoryResultsReturned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = BTKey2WithInventory, PagePosition = 2, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual(2, result.Data.InventoryResults.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_30BTKeysRequested_30BTKeysInventoryResultsReturned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003820878", PagePosition = 2, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003820862", PagePosition = 3, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003876559", PagePosition = 4, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003874799", PagePosition = 5, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003877034", PagePosition = 6, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003866504", PagePosition = 7, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011779", PagePosition = 8, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000256", PagePosition = 9, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011781", PagePosition = 10, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011782", PagePosition = 11, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011790", PagePosition = 12, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003820839", PagePosition = 13, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003820842", PagePosition = 14, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000001", PagePosition = 15, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011369", PagePosition = 16, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011370", PagePosition = 17, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011371", PagePosition = 18, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000003", PagePosition = 19, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000386697", PagePosition = 20, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6006000056", PagePosition = 21, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011682", PagePosition = 22, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000228", PagePosition = 23, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000241", PagePosition = 24, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000242", PagePosition = 25, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000269", PagePosition = 26, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003834092", PagePosition = 27, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003834190", PagePosition = 28, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003827594", PagePosition = 29, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003867257", PagePosition = 30, LEIndicator = "0" });

            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual(30, result.Data.InventoryResults.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_9BTKeysRequested_9BTKeysInventoryResultsReturned()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003820878", PagePosition = 2, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003820862", PagePosition = 3, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003876559", PagePosition = 4, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003874799", PagePosition = 5, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003877034", PagePosition = 6, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6003866504", PagePosition = 7, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000011779", PagePosition = 8, LEIndicator = "0" });
            btKeyList.Add(new BTKeys { BTKey = "6000000256", PagePosition = 9, LEIndicator = "0" });
            
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "ALB";
            var result = GetInventoryResults(request);

            Assert.AreEqual(9, result.Data.InventoryResults.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_VIPInventoryOnTitleVIPDisabled_VIPTitleIndicatorIsEmpty()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithVIPInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(string.Empty, result.Data.InventoryResults[0].VIPTitle);
        }

        [TestMethod]
        public void InventoryDemandPost_VIPInventoryOnTitleVIPEnabled_VIPTitleIndicatorIs1()
        {
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithVIPInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("1", result.Data.InventoryResults[0].VIPTitle);
        }
        
        [TestMethod]
        public void InventoryDemandPost_NoVIPInventoryOnTitleVIPDisabled_VIPTitleIndicatorIsEmpty()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithNoVIPInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            List<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(string.Empty, result.Data.InventoryResults[0].VIPTitle);
        }

        [TestMethod]
        public void InventoryDemandPost_NoVIPInventoryOnTitleVIPEnabled_VIPTitleIndicatorIs0()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithNoVIPInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "1";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("0", result.Data.InventoryResults[0].VIPTitle);
        }

        [TestMethod]
        public void InventoryDemandPost_EBookRightToVendTrue_InventoryStatusAvailable()
        {
            
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyEBookRightToVendTrue, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("Available", result.Data.InventoryResults[0].InventoryStatus);
        }

        [TestMethod]
        public void InventoryDemandPost_EBookRightToVendFalse_InventoryStatusAvailableToBackorder()
        {
            
            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyEBookRightToVendFalse, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("Available to Backorder", result.Data.InventoryResults[0].InventoryStatus);
        }

        [TestMethod]
        public void InventoryDemandPost_EBookRightToVendTrue_InventoryAvailable9999()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyEBookRightToVendTrue, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("9999", result.Data.InventoryResults[0].Warehouses[0].InStockForRequest.Value.ToString());
        }

        [TestMethod]
        public void InventoryDemandPost_EBookRightToVendFalse_InventoryAvailable0()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyEBookRightToVendFalse, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "COM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("0", result.Data.InventoryResults[0].Warehouses[0].InStockForRequest.Value.ToString());
        }

        [TestMethod]
        public void InventoryDemandPost_RetailVIPDisabled_VIEWareHouseNotReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(0, result.Data.InventoryResults[0].Warehouses.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_RetailVIPDisabled_VIMWareHouseNotReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(0, result.Data.InventoryResults[0].Warehouses.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_LibraryVIPDisabled_VIEWareHouseNotReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIE" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "1";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(0, result.Data.InventoryResults[0].Warehouses.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_LibraryVIPDisabled_VIMWareHouseNotReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "VIM" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "1";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual(0, result.Data.InventoryResults[0].Warehouses.Count());
        }

        [TestMethod]
        public void InventoryDemandPost_RNOWarehousePassedBTKeyHasExistingRENInventory_RENInventoryResultsReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithRENInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "RNO" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("REN", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
            Assert.IsTrue(0 < result.Data.InventoryResults[0].Warehouses[0].InStockForRequest.Value);
        }

        [TestMethod]
        public void InventoryDemandPost_RENWarehousePassedBTKeyHasExistingRENInventory_RENInventoryResultsReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithRENInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "REN" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("REN", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
            Assert.IsTrue(0 < result.Data.InventoryResults[0].Warehouses[0].InStockForRequest.Value);
        }

        [TestMethod]
        public void InventoryDemandPost_RNOWarehousePassedBTKeyHasExistingRNOInventory_RENInventoryResultsReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithRNOInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "RNO" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("REN", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
            Assert.IsTrue(0 < result.Data.InventoryResults[0].Warehouses[0].InStockForRequest.Value);
        }

        [TestMethod]
        public void InventoryDemandPost_RENWarehousePassedBTKeyHasExistingRNOInventory_RENInventoryResultsReturned()
        {

            List<BTKeys> btKeyList = new List<BTKeys>();
            btKeyList.Add(new BTKeys { BTKey = BTKeyWithRNOInventory, PagePosition = 1, LEIndicator = "0" });
            InventoryDemandRequest request = new InventoryDemandRequest();
            IList<InventoryDemandWareHouses> warehouseList = new List<InventoryDemandWareHouses>();
            warehouseList.Add(new InventoryDemandWareHouses { WarehouseID = "REN" });
            request.BTKeys = btKeyList.ToArray();
            request.Warehouses = warehouseList.ToArray();
            request.VIPEnabled = "0";
            request.MarketType = "0";
            request.CountryCode = "US";
            var result = GetInventoryResults(request);

            Assert.AreEqual("REN", result.Data.InventoryResults[0].Warehouses[0].WarehouseId);
            Assert.IsTrue(0 < result.Data.InventoryResults[0].Warehouses[0].InStockForRequest.Value);
        }

        private static NoSqlServiceResult<InventoryDemandResponse> GetInventoryResults(InventoryDemandRequest data)
        {
            // Create a WebClient to POST the request
            using (WebClient client = new WebClient())
            {
                // Set the header so it knows we are sending JSON
                client.Headers[HttpRequestHeader.ContentType] = "application/json";

                // Serialise the data we are sending in to JSON
                string serialisedData = JsonConvert.SerializeObject(data);

                // Make the request
                var response = client.UploadString(InventoryDemandURI, serialisedData);

                // Deserialise the response into a GUID
                return JsonConvert.DeserializeObject<NoSqlServiceResult<InventoryDemandResponse>>(response);
            }
        }

    }
}
