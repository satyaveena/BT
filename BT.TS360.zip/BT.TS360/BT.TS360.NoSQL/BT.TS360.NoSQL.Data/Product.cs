﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.NoSQL.Data
{
 [BsonIgnoreExtraElements]
    public class Product
    {
        [BsonId]
        public string BTKEY { get; set; }
        [BsonIgnoreIfNull]
        public Int64 ProductID { get; set; }
        [BsonIgnoreIfNull]
        public string ISBN { get; set; }
        [BsonIgnoreIfNull]
        public string ISBN10 { get; set; }
        [BsonIgnoreIfNull]
        public string UPC { get; set; }
        [BsonIgnoreIfNull]
        public Boolean ReturnIndicator { get; set; }
        [BsonIgnoreIfNull]
        public Boolean? SearchEngineRecrawl { get; set; }
        [BsonIgnoreIfNull]
	    public DateTime? SearchEngineReflagDateTime { get; set; }
        [BsonIgnoreIfNull]
	    public DateTime? SearchEngineRecrawlDateTime { get; set; }
       
        [BsonIgnoreIfNull]
        public Boolean? ThirtyDayDemandRollupFlag{ get; set; }
        [BsonIgnoreIfNull]
        public int? ThirtyDayDemandBucket{ get; set; }
        [BsonIgnoreIfNull]
        public int? ThirtyDayDemandTotalQty{ get; set; }
        [BsonIgnoreIfNull]
        public List<ThirtyDayDemand> ThirtyDayDemandData { get; set; }
        //[BsonIgnoreIfNull]	
        //public string OperationalGroup { get; set; }
        [BsonIgnoreIfNull]
        public string ReportCode { get; set; }
        [BsonIgnoreIfNull]
        public Boolean? RightToVend { get; set; }
        [BsonIgnoreIfNull]
        public DateTime? PublicationDate { get; set; }
        [BsonIgnoreIfNull]
        public DateTime? PreOrderDate { get; set; }
        [BsonIgnoreIfNull]
        public string ProductCode { get; set; }
        [BsonIgnoreIfNull]
        public string ProductType { get; set; }

        [BsonIgnoreIfNull]
        public string Audience { get; set; }
        [BsonIgnoreIfNull]
        public string AudienceLevel { get; set; }
        [BsonIgnoreIfNull]
        public string BookTypeClassificationCode { get; set; }
        [BsonIgnoreIfNull]
        public string BookClassificationLiteral { get; set; }
        [BsonIgnoreIfNull]
        public List<DiversityClassification> DiversityClassification { get; set; }

        [BsonIgnoreIfNull]
        public Boolean? HasDemandHistory { get; set; }
        [BsonIgnoreIfNull]
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDateTime { get; set; }
        [BsonIgnoreIfNull]
        public List<Inventory> InventoryData { get; set; }
        [BsonIgnoreIfNull]
        public List<InventoryBucket> InventoryBucketData { get; set; }
        [BsonIgnoreIfNull]
        public List<Demand> DemandData { get; set; }

        //STANDING ORDER ADDITIONAL COLUMNS
        [BsonIgnoreIfNull]     
        public string Title { get; set; }
        [BsonIgnoreIfNull]
        public string  Publisher { get; set; }
        [BsonIgnoreIfNull]
        public string Edition { get; set; }
        [BsonIgnoreIfNull]
        public decimal? ListPrice { get; set; }   
        [BsonIgnoreIfNull]
        public string PrimaryResponsibleParty { get; set; }
        [BsonIgnoreIfNull]
        public string PhysicalFormat { get; set; }
        [BsonIgnoreIfNull]
        public List<SeriesProducts> SeriesInformation { get; set; }
        //[BsonIgnoreIfNull]
        //public string AcademicSubjects { get; set; }
        //[BsonIgnoreIfNull]
        //public string AcceleratedReader { get; set; }
        //[BsonIgnoreIfNull]
        //public double AcceptableDiscount { get; set; }
        //[BsonIgnoreIfNull]
        //public string Actor { get; set; }
        //[BsonIgnoreIfNull]
        //public string Annotations { get; set; }
        //[BsonIgnoreIfNull]
        //public string ProductArtifacts { get; set; }
        //[BsonIgnoreIfNull]
        //public string Audience { get; set; }
        //[BsonIgnoreIfNull]
        //public string Awards { get; set; }
        //[BsonIgnoreIfNull]
        //public string AYProgramAuxCodes { get; set; }
        //[BsonIgnoreIfNull]
        //public string Bibliographies { get; set; }
        //[BsonIgnoreIfNull]
        //public string CountryCodeBlockedExports { get; set; }
        //[BsonIgnoreIfNull]
        //public string BookTypeLiteral { get; set; }
        //[BsonIgnoreIfNull]
        //public string BTEKey { get; set; }
        //[BsonIgnoreIfNull]
        //public string BTProgramAuxCodes { get; set; }
        //[BsonIgnoreIfNull]
        //public string BTPublicationLiterals { get; set; }
        //[BsonIgnoreIfNull]
        //public string ProductCatalog { get; set; }
        //[BsonIgnoreIfNull]
        //public string ChildrensFormat { get; set; }
        //[BsonIgnoreIfNull]
        //public string ContinuationsSeries { get; set; }
        //[BsonIgnoreIfNull]
        //public int DemandBucket { get; set; }
        //[BsonIgnoreIfNull]
        //public string DemandFacet { get; set; }
        //[BsonIgnoreIfNull]
        //public string DeweyNative { get; set; }
        //[BsonIgnoreIfNull]
        //public string DeweyNormalized { get; set; }
        //[BsonIgnoreIfNull]
        //public double DeweyNormalizedDecimal { get; set; }
        //[BsonIgnoreIfNull]
        //public int DeweyPrefix { get; set; }
        //[BsonIgnoreIfNull]
        //public string DeweyRange { get; set; }
        //[BsonIgnoreIfNull]
        //public string PriceKey { get; set; }
        //[BsonIgnoreIfNull]
        //public string eContentPlatform { get; set; }
        //[BsonIgnoreIfNull]
        //public string eSupplier { get; set; }
        //[BsonIgnoreIfNull]
        //public string FormatCode { get; set; }
        //[BsonIgnoreIfNull]
        //public string FormDetail { get; set; }
        //[BsonIgnoreIfNull]
        //public string GeneralSubjects { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasAcceleratedReader { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasAnnotation { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasArtifacts { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasAward { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasCitiation { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasCPSIAWarning { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasExcerpt { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasFamilyKeys { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasFlap { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasJacket { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean HasMuze { get; set; }
        //[BsonIgnoreIfNull]
        //public string HasReadingCounts { get; set; }
        //[BsonIgnoreIfNull]
        //public string HasReview { get; set; }
        //[BsonIgnoreIfNull]
        //public string HasTOC { get; set; }
        //[BsonIgnoreIfNull]
        //public string Illustrator { get; set; }
        //[BsonIgnoreIfNull]
        //public string IncludedFormats { get; set; }
        //[BsonIgnoreIfNull]
        //public string InventoryFacet { get; set; }
        //[BsonIgnoreIfNull]
        //public string DInventoryFacet { get; set; }
        //[BsonIgnoreIfNull]
        //public string LEInventoryFacet { get; set; }
        //[BsonIgnoreIfNull]
        //public string Label { get; set; }
        //[BsonIgnoreIfNull]
        //public string LanguageCode { get; set; }
        //[BsonIgnoreIfNull]
        //public string LanguageLiteral { get; set; }
        //[BsonIgnoreIfNull]
        //public string LCClassLiteral { get; set; }
        //[BsonIgnoreIfNull]
        //public string LCClassPrefix { get; set; }
        //[BsonIgnoreIfNull]
        //public string LCCN { get; set; }
        //[BsonIgnoreIfNull]
        //public string LeadingArticle { get; set; }
        //[BsonIgnoreIfNull]
        //public string LexileLiteral { get; set; }
        //[BsonIgnoreIfNull]
        //public string LexilePrefix { get; set; }
        //[BsonIgnoreIfNull]
        //public int LexileValue { get; set; }
        //[BsonIgnoreIfNull]
        //public string LibrarySubjects { get; set; }
        //[BsonIgnoreIfNull]
        //public string MarketRestrictionCode { get; set; }
        //[BsonIgnoreIfNull]
        //public string MerchandiseCategory { get; set; }
        //[BsonIgnoreIfNull]
        //public string MovieGenre { get; set; }
        //[BsonIgnoreIfNull]
        //public string MusicGenre { get; set; }
        //[BsonIgnoreIfNull]
        //public string Narrator { get; set; }
        //[BsonIgnoreIfNull]
        //public string Versions { get; set; }
        //[BsonIgnoreIfNull]
        //public int NumOfDiscs { get; set; }
        //[BsonIgnoreIfNull]
        //public string OCLCControlNumber { get; set; }
        //[BsonIgnoreIfNull]
        //public DateTime? ODSCreatedDateTime { get; set; }
        //[BsonIgnoreIfNull]
        //public string PartNumber { get; set; }
        //[BsonIgnoreIfNull]
        //public string DemandWeight { get; set; }
        //[BsonIgnoreIfNull]
        //public string PositiveAuxCodes { get; set; }
        //[BsonIgnoreIfNull]
        //public List<string> PrimaryAttributes { get; set; }
        //[BsonIgnoreIfNull]
        //public List<string> ProductFeatures { get; set; }
        //[BsonIgnoreIfNull]
        //public string ProductLine { get; set; }
        //[BsonIgnoreIfNull]
        //public string ProductStatus { get; set; }
        //[BsonIgnoreIfNull]
        //public string PublicationRange { get; set; }
        //[BsonIgnoreIfNull]
        //public string PurchaseOption { get; set; }
        //[BsonIgnoreIfNull]
        //public string Rating { get; set; }
        //[BsonIgnoreIfNull]
        //public string ReadingCount { get; set; }
        //[BsonIgnoreIfNull]
        //public string ReplacementBTKey { get; set; }
        //[BsonIgnoreIfNull]
        //public string ResponsiblePartys { get; set; }
        //[BsonIgnoreIfNull]
        //public string ReviewAuxCodes { get; set; }
        //[BsonIgnoreIfNull]
        //public int ReviewIssueCount { get; set; }
        //[BsonIgnoreIfNull]
        //public string NonIssueAuxCodes { get; set; }
        //[BsonIgnoreIfNull]
        //public string ReviewPublicationLiterals { get; set; }
        //[BsonIgnoreIfNull]
        //public string Reviews { get; set; }
        //[BsonIgnoreIfNull]
        //public string Series { get; set; }
        //[BsonIgnoreIfNull]
        //public string ShortTitle { get; set; }
        //[BsonIgnoreIfNull]
        //public string StarredAuxCodes { get; set; }
        //[BsonIgnoreIfNull]
        //public DateTime? StreetDate { get; set; }
        //[BsonIgnoreIfNull]
        //public string Studio { get; set; }
        //[BsonIgnoreIfNull]
        //public string BisacSubjects { get; set; }
        //[BsonIgnoreIfNull]
        //public string BisacSubject1 { get; set; }
        //[BsonIgnoreIfNull]
        //public string SubTitle { get; set; }
        //[BsonIgnoreIfNull]
        //public string Supplier { get; set; }
        //[BsonIgnoreIfNull]
        //public string SupplierCode { get; set; }
        //[BsonIgnoreIfNull]
        //public string TOCs { get; set; }
        //[BsonIgnoreIfNull]
        //public string VolumeNumber { get; set; }
        //[BsonIgnoreIfNull]
        //public Boolean isBlocked { get; set; }
        //[BsonIgnoreIfNull]
        //public List<string> Tags { get; set; }
        //[BsonIgnoreIfNull]
        //public int Score { get; set; }

    }

    public class SeriesProducts
    {
        [BsonIgnoreIfNull]
        public string SeriesID { get; set; } 
        [BsonIgnoreIfNull]
        public string StartData { get; set; }
        [BsonIgnoreIfNull]
        public string AutoShipIndicator { get; set; }

        public class SeriesProductsRecords
        {
            public SeriesProductsRecords()
            {
                SeriesProductsData = new List<SeriesProducts>();
            }
            public List<SeriesProducts> SeriesProductsData { get; set; }
        }
    }
}


