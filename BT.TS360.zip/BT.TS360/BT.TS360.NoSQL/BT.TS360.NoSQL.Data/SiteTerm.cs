﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class SiteTerm
    {
        [BsonId]
        public ObjectId SiteTermID { get; set; }

        [BsonIgnoreIfNull]
        public string Category { get; set; }
        [BsonIgnoreIfNull]
        public List<string> SiteTermType { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public List<SiteTermObject> SiteTermAttributes { get; set; }
    }

    public class SiteTermObject
    {
        [BsonIgnoreIfNull]
        public string Value { get; set; }
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public string SearchValue { get; set; }
        [BsonIgnoreIfNull]
        public string Description { get; set; }
        [BsonIgnoreIfNull]
        public int Sequence { get; set; } //position
        [BsonIgnoreIfNull]
        public List<SiteTermObject> Children { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }


}


