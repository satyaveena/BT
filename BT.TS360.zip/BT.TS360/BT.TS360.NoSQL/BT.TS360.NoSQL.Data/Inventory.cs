﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

using System.Data.OleDb;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class Inventory
    {
        public Inventory()
        {
        }

        public string WarehouseCode { get; set; }
        [BsonIgnoreIfNull]
        public string CustomerNumber { get; set; }
        [BsonIgnoreIfNull]
        public string InventoryType { get; set; }
        [BsonIgnoreIfNull]
        public int? AvailableQTY { get; set; }
        [BsonIgnoreIfNull]
        public int? OnOrderQTY { get; set; }
        [BsonIgnoreIfNull]
        public int? LEAQTY { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDateTime { get; set; }


        public class InventoryRecords
        {
            public InventoryRecords()
            {
                InventoryData = new List<Inventory>();
            }
            public List<Inventory> InventoryData { get; set; }
        }
    }

    [BsonIgnoreExtraElements]
    public class InventoryBucket
    {
        public InventoryBucket()
        {
        }

        public string WarehouseCode { get; set; }
        [BsonIgnoreIfNull]
        public int? LEReserveBucket { get; set; }
        [BsonIgnoreIfNull]
        public int? DReserveBucket { get; set; }
        [BsonIgnoreIfNull]
        public int? AvailableBucket { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDateTime { get; set; }


        public class InventoryBucketRecords
        {
            public InventoryBucketRecords()
            {
                InventoryBucketData = new List<InventoryBucket>();
            }
            public List<InventoryBucket> InventoryBucketData { get; set; }
        }
    }
}

