﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BT.TS360.NoSQL.Data.AzureSearch
{
    public abstract class SearchResultItem
    {
       public abstract string ObjectId { get; set; }
    }
}
