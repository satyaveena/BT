﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.AzureSearch
{
    public class ProfiledSeriesSearchResultItem : SearchResultItem
    {
        [JsonProperty(PropertyName = "ProfiledSeriesID")]
        public override string ObjectId { get; set; }

        public string ProfileID { get; set; }
        public string SeriesID { get; set; }
        public string Note { get; set; }
        public string RequestStatus { get; set; }
        public string RequestType { get; set; }
        public string ChangeRequestUserID { get; set; }
        public int? TotalPrimaryQuantity { get; set; }
        public DateTimeOffset? LoadDateTime { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedByUserID { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByUserID { get; set; }
        public DateTimeOffset? UpdatedDate { get; set; }

        public string SeriesName { get; set; }
        public string SeriesNameNoPunctuation { get; set; }
        public string Author { get; set; }
        public string AuthorNoPunctuation { get; set; }
        public string Format { get; set; }
        public string Audience { get; set; }
        public string Publisher { get; set; }
        public string Distributor { get; set; }                 
        public string Frequency { get; set; }
        public List<string> SeriesPrograms { get; set; }
        public List<string> AreasOfInterest { get; set; }
        public string SeriesProgramsForSort { get; set; }  //SORTABLE, Concatenated Alpha list of Series Programs 
        public string SeriesRequestStatus { get; set; }
        public string SeriesStatus { get; set; }
      
        public string BTKey { get; set; }
        public string ISBN { get; set; }
        public string ListPrice { get; set; }            //SEARCHABLE, Must be string
        public string PublicationDate { get; set; }     //SEARCHABLE, Must be string
        public string Edition { get; set; }
        public string Title { get; set; }
        public string LatestIssueAuthor { get; set; }
       
        public string SeriesCreatedBy { get; set; }
        public string SeriesCreatedByUserID { get; set; }
        public DateTimeOffset? SeriesCreatedDate { get; set; }
        public string SeriesUpdatedBy { get; set; }
        public string SeriesUpdatedByUserID { get; set; }
        public DateTimeOffset? SeriesUpdatedDate { get; set; }
        public bool HasRelatedSeries { get; set; }
        public List<string> RelatedSeriesIDs { get; set; }      
        public string CompassAccountNumber { get; set; }
        public string ShippingAccountNumber { get; set; }
        public string ProfileName { get; set; }
        public string OrganizationID { get; set; }
        public int? TotalSeries { get; set; }
        public int? TotalCopies { get; set; }
        public string ProfileStatus { get; set; }
        public string ProfileType { get; set; }
        public List<string> ProfilePrograms { get; set; }
        public string SalesTerritory { get; set; }

        public List<string> POQuantityList { get; set; }

        public List<string> POLineNumberList { get; set; }

        public bool HasBindingPreferences { get; set; }

        public string BindingPreferenceLiteral1 { get; set; }
        public string BindingPreferencePrimaryPreference1 { get; set; }
        public string BindingPreferenceSecondaryPreference1 { get; set; }
        public bool BindingPreferenceHasMultiplePreference1 { get; set; }

        public string BindingPreferenceLiteral2 { get; set; }
        public string BindingPreferencePrimaryPreference2 { get; set; }
        public string BindingPreferenceSecondaryPreference2 { get; set; }
        public bool BindingPreferenceHasMultiplePreference2 { get; set; }

        public string BindingPreferenceLiteral3 { get; set; }
        public string BindingPreferencePrimaryPreference3 { get; set; }
        public string BindingPreferenceSecondaryPreference3 { get; set; }
        public bool BindingPreferenceHasMultiplePreference3 { get; set; }

        public string BindingPreferenceLiteral4 { get; set; }
        public string BindingPreferencePrimaryPreference4 { get; set; }
        public string BindingPreferenceSecondaryPreference4 { get; set; }
        public bool BindingPreferenceHasMultiplePreference4 { get; set; }
        public string PO1FormatPreferenceLiteral { get; set; }
        public int POCount { get; set; }

        
    }
}
