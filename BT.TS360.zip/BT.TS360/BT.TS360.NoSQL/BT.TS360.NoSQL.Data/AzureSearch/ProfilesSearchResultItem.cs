﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.AzureSearch
{
    public class ProfilesSearchResultItem : SearchResultItem
    {

        [JsonProperty(PropertyName = "id")]
        public override string ObjectId { get; set; }

      //  public string id { get; set; }
        public string OrganizationID { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
        public string NameNoPunctuation { get; set; }
        public string CompassAccountNumber { get; set; }
        public string ShippingAccountID { get; set; }
        public string ShippingAccountNumber { get; set; }
        public string BillingAccountNumber { get; set; }
        public string SAN { get; set; }
        public string AccountType { get; set; }
        public string ProfileType { get; set; }
        public string Notes { get; set; }
        public string RequestStatus { get; set; }
        public string RequestType { get; set; }
        public string Status { get; set; }
        public string SalesTerritory { get; set; }
        public List<string> AreasOfInterest { get; set; }
        public List<string> Programs { get; set; }
        public string ProgramsForSort { get; set; }           //SORTABLE, Concatenated Alpha list of Programs 
        public List<string> NotificationUsers { get; set; }
        public List<string> SeriesIDList { get; set; }
        public List<string> SeriesNameList { get; set; }
        public string PrimaryContact { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string eMail { get; set; }
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Line3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public int? TotalCopies { get; set; }
        public int? TotalSeries { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByUserID { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByUserID { get; set; }
        public DateTimeOffset? UpdatedDate { get; set; }
        public List<string> UpdatedDateRange { get; set; }

        public List<string> PONumberList { get; set; }

    }
}