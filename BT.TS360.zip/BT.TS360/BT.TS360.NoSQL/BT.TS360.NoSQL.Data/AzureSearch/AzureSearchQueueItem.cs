﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson.Serialization.Attributes;

namespace BT.TS360.NoSQL.Data.AzureSearch
{
    [BsonIgnoreExtraElements]
    public class AzureSearchQueueItem
    {

        [BsonIgnoreIfDefault]
        public ObjectId ObjectId { get; set; }

        [BsonIgnoreIfNull]
        public string CollectionName { get; set; }

        [BsonIgnoreIfNull]
        public string ChangeType { get; set; }

        [BsonIgnoreIfNull]
        public int? Priority { get; set; }

        [BsonIgnoreIfNull]
        public int InProcessState { get; set; }

        [BsonIgnoreIfDefault]
        public DateTime LastCrawlDate { get; set; }

        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }

        [BsonIgnoreIfNull]
        public bool IsRealTime { get; set; }
    }
}
