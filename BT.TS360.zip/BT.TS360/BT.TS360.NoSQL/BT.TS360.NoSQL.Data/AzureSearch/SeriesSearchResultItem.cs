﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.AzureSearch
{
    public class SeriesSearchResultItem : SearchResultItem
    {

        [JsonProperty(PropertyName = "id")]
        public override string ObjectId { get; set; }

        //    public string id { get; set; }
        public string SeriesID { get; set; }
        public string Name { get; set; }
        public string NameKeyword { get; set; }
        public List<string> Programs { get; set; }
        public string ProgramsForSort { get; set; }
        public string Publisher { get; set; }
        public string PublisherKeyword { get; set; }
        public string Distributor { get; set; }                 //2017-09-20 CDM TFS 26484
        public string DistributorNoPunctuation { get; set; }                
        public string Format { get; set; }
        public string Frequency { get; set; }
        public List<string> AreasOfInterest { get; set; }
        public string Audience { get; set; }
        public string Annotations { get; set; }
        public string Author { get; set; }
        public List<string> RelatedSeriesIDs { get; set; }
        public List<string> BindingPreferences { get; set; }
        public string StartDataType { get; set; }
        public string Status { get; set; }
        public List<string> SeriesLists { get; set; }
        public DateTimeOffset? LoadDateTime { get; set; }
        public List<string> ISBNList { get; set; }
        public List<string> ISBN10List { get; set; }
        public List<string> ProfileOrgIDList { get; set; }  //ProfiledSeries.OrganizationID|ProfiledSeries.ProfileID|ProfiledSeries.RequestStatus
        public List<string> ProfileIDList { get; set; }
        public string BTKey { get; set; }
        public string ISBN { get; set; }
        public decimal? ListPrice { get; set; }
        public DateTimeOffset? PublicationDate { get; set; }
        public List<string> PublicationDateRange { get; set; }
        public string Edition { get; set; }
        public string Title { get; set; }
        public string LatestIssueAuthor { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByUserID { get; set; }
        public DateTimeOffset CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByUserID { get; set; }
        public DateTimeOffset UpdatedDate { get; set; }
        public bool? HasRelatedSeries { get; set; } //2017-05-10 CDM TFS 25131

        public bool? HasBindingPreferences { get; set; }
        public List<string> ContentListIDList { get; set; }

        public string BindingPreferenceLiteral1 { get; set; }
        public string BindingPreferencePrimaryPreference1 { get; set; }
        public string BindingPreferenceSecondaryPreference1 { get; set; }
        public bool? BindingPreferenceHasMultiplePreference1 { get; set; }

        public string BindingPreferenceLiteral2 { get; set; }
        public string BindingPreferencePrimaryPreference2 { get; set; }
        public string BindingPreferenceSecondaryPreference2 { get; set; }
        public bool? BindingPreferenceHasMultiplePreference2 { get; set; }

        public string BindingPreferenceLiteral3 { get; set; }
        public string BindingPreferencePrimaryPreference3 { get; set; }
        public string BindingPreferenceSecondaryPreference3 { get; set; }
        public bool? BindingPreferenceHasMultiplePreference3 { get; set; }

        public string BindingPreferenceLiteral4 { get; set; }
        public string BindingPreferencePrimaryPreference4 { get; set; }
        public string BindingPreferenceSecondaryPreference4 { get; set; }
        public bool? BindingPreferenceHasMultiplePreference4 { get; set; }
        public List<string> ProductType { get; set; }
    }
}
