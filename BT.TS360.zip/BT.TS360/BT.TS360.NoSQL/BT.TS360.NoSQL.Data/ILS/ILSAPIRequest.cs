﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.ILS
{
    [BsonIgnoreExtraElements]
    public class ILSAPIRequest
    {
        [BsonId]
        public ObjectId Id { get; set; }
        [BsonIgnoreIfNull]
        public string BasketSummaryId { get; set; }
        [BsonIgnoreIfNull]
        public DateTime RequestDateTime { get; set; }
        [BsonIgnoreIfNull]
        public DateTime ResponseDateTime { get; set; }
        [BsonIgnoreIfNull]
        public string ErrorType { get; set; }
        [BsonIgnoreIfNull]
        public string ErrorDescription { get; set; }
        [BsonIgnoreIfNull]
        public string ILSStatus { get; set; }
        [BsonIgnoreIfNull]
        public string NewCartId { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public List<LineItemAPILogDetails> ILSLineItemLogs { get; set; }

    }

    public class LineItemAPILogDetails
    {
        [BsonIgnoreIfNull]
        public string LineItemId { get; set; }
        [BsonIgnoreIfNull]
        public string ILSAPIRequest { get; set; }
        [BsonIgnoreIfNull]
        public string ILSAPIResponse { get; set; }
        [BsonIgnoreIfNull]
        public string BTKey { get; set; }
        [BsonIgnoreIfNull]
        public string ErrorType { get; set; }
    }

    /// <summary>
    /// "ValidationRequest" object in Common.ILSAPIRequestLog collection.
    /// </summary>
    [BsonIgnoreExtraElements]
    public class ILSValidationRequest
    {
        [BsonIgnoreIfNull]
        public List<ILSRequestLineItem> LineItems { get; set; }
    }

    public class ILSRequestLineItem
    {
        [BsonIgnoreIfNull]
        public string ExternalLineItemID { get; set; }
        [BsonIgnoreIfNull]
        public int Copies { get; set; }
        [BsonIgnoreIfNull]
        public string BTKey { get; set; }
        [BsonIgnoreIfNull]
        public List<ILSLineItemSegment> LineItemSegments { get; set; }
    }

    public class ILSLineItemSegment
    {
        [BsonIgnoreIfNull]
        public string Location { get; set; }
        [BsonIgnoreIfNull]
        public string Fund { get; set; }
        [BsonIgnoreIfNull]
        public string Collection { get; set; }
        [BsonIgnoreIfNull]
        public int Copies { get; set; }
    }
}
