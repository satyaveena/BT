﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.ILS
{
    public class ILSValidationRequestResponse
    {
        public ILSValidationRequest ValidationRequest { get; set; }
        public ILSOrderValidationResponseStatus ValidationResponse { get; set; }
    }

    /// <summary>
    /// "ValidatoinResponse" or "OrderResponse" object in Common.ILSAPIRequestLog collection.
    /// </summary>
    [BsonIgnoreExtraElements]
    public class ILSOrderValidationResponseStatus
    {
        [BsonIgnoreIfNull]
        public string PAPIErrorCode { get; set; }
        [BsonIgnoreIfNull]
        public string ErrorMessage { get; set; }
        [BsonIgnoreIfNull]
        public string JobGuid { get; set; }
        [BsonIgnoreIfNull]
        public string JobStatusID { get; set; }
        [BsonIgnoreIfNull]
        public string JobStatusDescription { get; set; }

        /// <summary>
        /// BasketSummaryID.
        /// </summary>
        [BsonIgnoreIfNull]
        public string ExternalID { get; set; }

        [BsonIgnoreIfNull]
        public List<LineItemValidationError> LineItemValidationErrors { get; set; }
    }

    public class LineItemValidationError
    {
        [BsonIgnoreIfNull]
        public string ExternalLineItemID { get; set; }
        [BsonIgnoreIfNull]
        public List<PAPIError> Errors { get; set; }
    }

    public class PAPIError
    {
        [BsonIgnoreIfNull]
        public string PAPIErrorCode { get; set; }
        [BsonIgnoreIfNull]
        public string ErrorMessage { get; set; }
    }
}
