﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class Demand
    {
        //public Demand()
        //{
        //}

        public string WarehouseCode { get; set; }
        public string Period { get; set; }
        [BsonIgnoreIfNull]
        public int? Quantity { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDateTime { get; set; }

        //public class DemandRecords
        //{
        //    public DemandRecords()
        //    {
        //        DemandData = new List<Demand>();
        //    }
        //    public List<Demand> DemandData { get; set; }
        //}

    }

    public class ThirtyDayDemand
    {
        public string WarehouseCode { get; set; }
        [BsonIgnoreIfNull]
        public int? Quantity { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        [BsonIgnoreIfNull]
        public string UpdatedBy { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdatedDateTime { get; set; }

        //public class ThirtyDayDemandRecords
        //{
        //    public ThirtyDayDemandRecords()
        //    {
        //        ThirtyDayDemandData = new List<ThirtyDayDemand>();
        //    }
        //    public List<ThirtyDayDemand> ThirtyDayDemandData { get; set; }
        //}
    }

}


