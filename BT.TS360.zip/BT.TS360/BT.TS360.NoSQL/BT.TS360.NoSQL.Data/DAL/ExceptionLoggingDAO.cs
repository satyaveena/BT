﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BTNextGen.Elmah;

namespace BT.TS360.NoSQL.Data.DAL
{
    public class ExceptionLoggingDAO : BaseDAO
    {
        private string _sqlConnectionString;

        public ExceptionLoggingDAO(string connectionString) 
        {
            _sqlConnectionString = connectionString;
        }
        public override string ConnectionString
        {
            get
            {
                return _sqlConnectionString;
            }
        }

        /*
         * Generic logging, which include Exception, Application and Source
         */
        public void LogError(Exception exception, string applicationName, string source)
        {
            var errorLog = new SqlErrorLog(_sqlConnectionString);
            errorLog.ApplicationName = applicationName;

            var error = new Error(exception);
            error.ApplicationName = errorLog.ApplicationName;
            error.Source = source;
            error.Type = exception.GetBaseException().GetType().ToString();

            errorLog.Log(error);
        }

        /*
         * Logging includes the JSON
         */
        public void LogError(Exception exception, string applicationName, string source, string requestInJson)
        {
            var errorLog = new SqlErrorLog(_sqlConnectionString);
            errorLog.ApplicationName = applicationName;

            var error = new Error(exception);
            error.ApplicationName = errorLog.ApplicationName;
            error.Source = source;
            error.Type = exception.GetBaseException().GetType().ToString();

            // when logging replace double quote with single quote, as we have encoding issue when logging JSON in AllXML column
            // if we need to debug, simply get the details from WebHostHtmlMessage within AllXML, then use notepad or other text editor, replace two single quotes with one double quotes
            error.WebHostHtmlMessage = requestInJson.Replace("\"", "''");

            errorLog.Log(error);
        }
    }
}
