﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.Data.DAL
{
    public class DBTransactionODSDAO: BaseDAO
    {
        private string _sqlConnectionString;
        private string _ODSEnvironmentStoredProcedureSuffix = string.Empty;

        public DBTransactionODSDAO(string connectionString) 
        {
            _sqlConnectionString = connectionString;

        }

        public DBTransactionODSDAO(string connectionString, string ODSEnvironmentStoredProcedureSuffix)
        {
            _sqlConnectionString = connectionString;
            _ODSEnvironmentStoredProcedureSuffix = ODSEnvironmentStoredProcedureSuffix;

        }
        public override string ConnectionString
        {
            get
            {
                return _sqlConnectionString;
            }
        }

        public SqlDataReader GetProductSourceData(int batchSize)
        {
            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@BatchSize", batchSize));

            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));
            return DatabaseHelper.ExecuteReader(StoredProcedureName.USP_SEL_EXTRACT_TS360_PRODUCTS + _ODSEnvironmentStoredProcedureSuffix, arr, CreateSqlConnection());

        }

        public DataSet GetProductSourceDataTable(int batchSize)
        {
            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@BatchSize", batchSize));

            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));

            return DatabaseHelper.ExecuteProcedure(StoredProcedureName.USP_SEL_EXTRACT_TS360_PRODUCTS + _ODSEnvironmentStoredProcedureSuffix, arr, CreateSqlConnection());
        }

        public void GetProductAcknowledgeSourceData(DataTable BatchConfirmation)
        {
            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@BatchConfirmation", BatchConfirmation));

            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));
            DatabaseHelper.ExecuteNonQuery(StoredProcedureName.USP_UPD_TS360_PRODUCTS_QUEUE + _ODSEnvironmentStoredProcedureSuffix, arr, CreateSqlConnection());

            return;
        }

        public SqlDataReader GetDemandLoad(DemandLoadType demandLoadType, int daysback)
        {
            string procedureName = string.Empty;

            switch (demandLoadType)
            {
                case DemandLoadType.BTBDelta:
                    procedureName = StoredProcedureName.USP_SEL_EXTRACT_NEXTGEN_DEMANDBTB_MONGO_DELTA;
                    break;
                case DemandLoadType.BTEDelta:
                    procedureName = StoredProcedureName.USP_SEL_EXTRACT_NEXTGEN_DEMANDBTE_MONGO_DELTA;
                    break;
                case DemandLoadType.BTBFull:
                    procedureName = StoredProcedureName.USP_SEL_EXTRACT_NEXTGEN_DEMANDBTB_MONGO_FULL;
                    break;
                case DemandLoadType.BTEFull:
                    procedureName = StoredProcedureName.USP_SEL_EXTRACT_NEXTGEN_DEMANDBTE_MONGO_FULL;
                    break;

            }

            if (DemandLoadType.BTBFull == demandLoadType || DemandLoadType.BTEFull == demandLoadType)
            {
                return DatabaseHelper.ExecuteReader(procedureName, CreateSqlConnection());
            }
            else 
            {
                ArrayList alParams = new ArrayList();
                alParams.Add(new SqlParameter("@DaysBack", daysback));

                SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));
                return DatabaseHelper.ExecuteReader(procedureName, arr, CreateSqlConnection()); 
            }

        }
    }
}
