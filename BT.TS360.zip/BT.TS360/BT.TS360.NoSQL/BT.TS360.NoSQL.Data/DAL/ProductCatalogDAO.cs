﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.SqlServer.Server;

using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.Data.DAL
{
    public class ProductCatalogDAO : BaseDAO
    {
        private string _sqlConnectionString;

        public ProductCatalogDAO(string connectionString) 
        {
            _sqlConnectionString = connectionString;
        }
        public override string ConnectionString
        {
            get
            {
                return _sqlConnectionString;
            }
        }

        public void SetMongoInventoryDemandBuckets(List<Product> products)
        {
            List<SqlDataRecord> batchFASTViewProducts = ConvertFastProductsToDataSet(products);

            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@Products", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = batchFASTViewProducts });
            alParams.Add(new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, -1) { Direction = ParameterDirection.Output });

            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));
            DatabaseHelper.ExecuteNonQuery(StoredProcedureName.USP_SET_INVENTORY_DEMAND_BUCKETS, arr, CreateSqlConnection());

            return;
        }

        public static List<SqlDataRecord> ConvertFastProductsToDataSet(List<Product> mongoFastProducts)
        {
            if (mongoFastProducts == null || mongoFastProducts.Count == 0)
                return null;

            var dataRecords = new List<SqlDataRecord>();
            SqlMetaData[] sqlMetaDatas =
            {
                /*0*/   new SqlMetaData("ProductID", SqlDbType.BigInt),                 
                /*1*/   new SqlMetaData("DemandBucket", SqlDbType.Int),                 
                /*2*/   new SqlMetaData("SOMLEReserveInventoryBucket", SqlDbType.Int),
                /*3*/   new SqlMetaData("MOMLEReserveInventoryBucket", SqlDbType.Int), 
                /*4*/   new SqlMetaData("COMLEReserveInventoryBucket", SqlDbType.Int),
                /*5*/   new SqlMetaData("RNOLEReserveInventoryBucket", SqlDbType.Int),
                /*6*/   new SqlMetaData("SOMDReserveInventoryBucket", SqlDbType.Int), 
                /*7*/   new SqlMetaData("MOMDReserveInventoryBucket", SqlDbType.Int),
                /*8*/   new SqlMetaData("COMDReserveInventoryBucket", SqlDbType.Int),
                /*9*/   new SqlMetaData("RNODReserveInventoryBucket", SqlDbType.Int), 
                /*10*/  new SqlMetaData("SOMAvailableInventoryBucket", SqlDbType.Int),
                /*11*/  new SqlMetaData("MOMAvailableInventoryBucket", SqlDbType.Int),
                /*12*/  new SqlMetaData("COMAvailableInventoryBucket", SqlDbType.Int), 
                /*13*/  new SqlMetaData("RNOAvailableInventoryBucket", SqlDbType.Int)
            };

            foreach (var mongoFastProduct in mongoFastProducts)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);

                dataRecord.SetInt64(0, mongoFastProduct.ProductID);

                // initialization of the FAST bucket value
                for (int i = 1; i <= 13; i++)
                {
                    dataRecord.SetDBNull(i);
                }

                if (mongoFastProduct.ThirtyDayDemandBucket.HasValue)
                {
                    dataRecord.SetInt32(1, mongoFastProduct.ThirtyDayDemandBucket.Value);
                }

                if (mongoFastProduct.InventoryBucketData == null || mongoFastProduct.InventoryBucketData.Count == 0)
                {
                    dataRecords.Add(dataRecord);
                    continue;
                }

                // start loop of InventoryBucketData
                foreach (InventoryBucket ib in mongoFastProduct.InventoryBucketData)
                {
                    #region SOM
                    if (ib.WarehouseCode == CommonConstants.WarehouseConstants.SOM)
                    {
                        if (ib.LEReserveBucket.HasValue)
                            dataRecord.SetInt32(2, ib.LEReserveBucket.Value);

                        if (ib.DReserveBucket.HasValue)
                            dataRecord.SetInt32(6, ib.DReserveBucket.Value);

                        if (ib.AvailableBucket.HasValue)
                        { 
                            dataRecord.SetInt32(10, ib.AvailableBucket.Value);

                            // Entertainment product, populate the LEReserve and DReserve with available bucket
                            if (mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MOVIE || mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MUSIC)
                            {
                                if (!ib.LEReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(2, ib.AvailableBucket.Value);
                                }

                                if (!ib.DReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(6, ib.AvailableBucket.Value);
                                }
                            }
                        }

                    }
                    #endregion SOM

                    #region MOM
                    else if (ib.WarehouseCode == CommonConstants.WarehouseConstants.MOM)
                    {
                        if (ib.LEReserveBucket.HasValue)
                            dataRecord.SetInt32(3, ib.LEReserveBucket.Value);

                        if (ib.DReserveBucket.HasValue)
                            dataRecord.SetInt32(7, ib.DReserveBucket.Value);

                        if (ib.AvailableBucket.HasValue)
                        {
                            dataRecord.SetInt32(11, ib.AvailableBucket.Value);

                            // Entertainment product, populate the LEReserve and DReserve with available bucket
                            if (mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MOVIE || mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MUSIC)
                            {
                                if (!ib.LEReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(3, ib.AvailableBucket.Value);
                                }

                                if (!ib.DReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(7, ib.AvailableBucket.Value);
                                }
                            }
                        }
                    }
                    #endregion MOM

                    #region COM
                    else if (ib.WarehouseCode == CommonConstants.WarehouseConstants.COM)
                    {
                        if (ib.LEReserveBucket.HasValue)
                            dataRecord.SetInt32(4, ib.LEReserveBucket.Value);

                        if (ib.DReserveBucket.HasValue)
                            dataRecord.SetInt32(8, ib.DReserveBucket.Value);

                        if (ib.AvailableBucket.HasValue)
                        {
                            dataRecord.SetInt32(12, ib.AvailableBucket.Value);

                            // Entertainment product, populate the LEReserve and DReserve with available bucket
                            if (mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MOVIE || mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MUSIC)
                            {
                                if (!ib.LEReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(4, ib.AvailableBucket.Value);
                                }

                                if (!ib.DReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(8, ib.AvailableBucket.Value);
                                }
                            }
                         
                        }
                    }
                    #endregion COM

                    #region RNO / REN
                    else if (ib.WarehouseCode == CommonConstants.WarehouseConstants.REN || ib.WarehouseCode == CommonConstants.WarehouseConstants.RNO)
                    {
                        if (ib.LEReserveBucket.HasValue)
                            dataRecord.SetInt32(5, ib.LEReserveBucket.Value);

                        if (ib.DReserveBucket.HasValue)
                            dataRecord.SetInt32(9, ib.DReserveBucket.Value);

                        if (ib.AvailableBucket.HasValue)
                        {
                            dataRecord.SetInt32(13, ib.AvailableBucket.Value);

                            // Entertainment product, populate the LEReserve and DReserve with available bucket
                            if (mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MOVIE || mongoFastProduct.ProductCode == CommonConstants.ProductCodeConstants.MUSIC)
                            {
                                if (!ib.LEReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(5, ib.AvailableBucket.Value);
                                }

                                if (!ib.DReserveBucket.HasValue)
                                {
                                    dataRecord.SetInt32(9, ib.AvailableBucket.Value);
                                }
                            }
                        }

                    }
                    #endregion RNO / REN
                }
                // end loop of InventoryBucketData

                dataRecords.Add(dataRecord);
            }

            return dataRecords;

        }

     
    }
}
