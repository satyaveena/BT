﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.DAL
{
    public abstract class BaseDAO
    {
        public abstract string ConnectionString
        {
            get;
        }

        protected virtual SqlConnection CreateSqlConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        protected virtual SqlCommand CreateSqlCommand(string commandName, SqlConnection sqlConnection)
        {
            return new SqlCommand(commandName, sqlConnection);
        }

        protected virtual SqlCommand CreateSqlSpCommand(string spName, SqlConnection sqlConnection)
        {
            return new SqlCommand(spName, sqlConnection) { CommandType = CommandType.StoredProcedure };
        }

        protected virtual SqlParameter[] CreateSqlParamaters(int numberOfParams)
        {
            return new SqlParameter[numberOfParams];
        }

        /// <summary>
        /// Convert an object to string
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public virtual string ConvertToString(object obj)
        {
            if (null != obj && DBNull.Value != obj)
            {
                return obj.ToString();
            }
            return string.Empty;
        }

        public virtual char ConvertToChar(object obj)
        {
            char returnValue = ' ';
            if (null != obj && DBNull.Value != obj)
            {
                char.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to Int
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public virtual int ConvertToInt(object obj)
        {
            int returnValue = 0;
            if (null != obj)
            {
                int.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

        /// <summary>
        /// Convert an object to bool
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public virtual bool ConvertToBoolean(object obj)
        {
            bool returnValue = false;
            if (null != obj && obj != DBNull.Value)
            {
                bool.TryParse(obj.ToString(), out returnValue);
            }
            return returnValue;
        }

    }
}
