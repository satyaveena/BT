﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.SqlServer.Server;

using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.Data.DAL
{
    public class ProfilesDAO : BaseDAO
    {
        private string _sqlConnectionString;

        public ProfilesDAO(string connectionString) 
        {
            _sqlConnectionString = connectionString;
        }
        public override string ConnectionString
        {
            get
            {
                return _sqlConnectionString;
            }
        }

        public void SetMongoInventoryDemandBuckets(List<Data.Axis360.Axis360Inventory> inventory)
        {
            List<SqlDataRecord> inventoryDataRecords = ConvertAxis360InventoryToDataSet(inventory);

            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@Axis360InventoryCustomers", SqlDbType.Structured) { Direction = ParameterDirection.Input, Value = inventoryDataRecords });
            alParams.Add(new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, -1) { Direction = ParameterDirection.Output });

            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));
            DatabaseHelper.ExecuteNonQuery(StoredProcedureName.USP_Mongo_Set_Axis_Circulation_Data, arr, CreateSqlConnection());

            return;
        }

        public static List<SqlDataRecord> ConvertAxis360InventoryToDataSet(List<Data.Axis360.Axis360Inventory> inventory)
        {

            var dataRecords = new List<SqlDataRecord>();
            SqlMetaData[] sqlMetaDatas =
            {
                /*0*/   new SqlMetaData("eSupplierAccountNumber", SqlDbType.NVarChar, 12),                 
                /*1*/   new SqlMetaData("ISBN", SqlDbType.VarChar, 13),                 
                /*2*/   new SqlMetaData("HasInventory", SqlDbType.Bit)
            };
            foreach (var inventoryRecord in inventory)
            {
                var dataRecord = new SqlDataRecord(sqlMetaDatas);
                dataRecord.SetValue(0, inventoryRecord.CustomerID);
                dataRecord.SetValue(1, inventoryRecord.ISBN);

                var hasInventory = string.Equals(inventoryRecord.State, "A", StringComparison.OrdinalIgnoreCase);
                dataRecord.SetBoolean(2, hasInventory);

                dataRecords.Add(dataRecord);
            }

            return dataRecords;

        }

     
    }
}
