﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    class fsfiles
    { 
        public ObjectId _id { get; set; }
        [BsonIgnoreIfNull]
        public string filename { get; set; }
        [BsonIgnoreIfNull]
        public string aliases { get; set; }
        [BsonIgnoreIfNull]
        public long chunkSize { get; set; }
        [BsonIgnoreIfNull]
        public DateTime uploadDate { get; set; }
        [BsonIgnoreIfNull]
        public long length { get; set; }
        [BsonIgnoreIfNull]
        public string contentType { get; set; }
        [BsonIgnoreIfNull]
        public string md5 { get; set; }
   }

    class fschunks
    { 
        public ObjectId _id { get; set; }
        [BsonIgnoreIfNull]
        public ObjectId files_id { get; set; }
        [BsonIgnoreIfNull]
        public int n { get; set; }
        [BsonIgnoreIfNull]
        public BsonBinaryData data{ get; set; }
    }
}
