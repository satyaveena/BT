﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class Profile  //Renamed from Profiles to Profile UI Team complained, spearheaded by Ralph.
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        public ObjectId ProfileID { get; set; }  //2016-12-23 CDM needed for DateRangeCalculator use in AzureSearch for Facets


        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public string UserName { get; set; }
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public string CompassAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string ShippingAccountID { get; set; }  //2016-04-21 Ralph
        [BsonIgnoreIfNull]
        public string ShippingAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string BillingAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string SAN { get; set; }
        [BsonIgnoreIfNull]
        public string AccountType { get; set; }
        [BsonIgnoreIfNull]
        public string ProfileType { get; set; }
        [BsonIgnoreIfNull]
        public string Notes { get; set; }
        [BsonIgnoreIfNull]
        public string RequestStatus { get; set; }  //Updated by TS360 UI
        [BsonIgnoreIfNull]
        public string RequestType { get; set; }  //2016-11-25 CDM needed for change request
        [BsonIgnoreIfNull]
        public string Status { get; set; }
        [BsonIgnoreIfNull]
        public string SalesTerritory { get; set; }  //2016-07-26  Ralph indicates that this should be populated by profile load from TS360
        [BsonIgnoreIfNull]
        public List<string> AreasOfInterest { get; set; }  //2016-02-12 Tung Pointed out model was missing areas of interest.
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }
        [BsonIgnoreIfNull]
        public ContactInformation ContactInformation { get; set; }
        [BsonIgnoreIfNull]
        public AddressInformation AddressInformation { get; set; }
        [BsonIgnoreIfNull]
        public SummaryInformation SummaryInformation { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public List<string> NotificationUsers { get; set; } //2016-07-15 Ralph needed for TFS 22430
        [BsonIgnoreIfNull]
        public List<string> UpdatedDateRange { get; set; } //2016-12-19 CDM needed for DateRangeCalculator use in AzureSearch for Facets
        [BsonIgnoreIfNull]
        public List<string> PONumberList { get; set; }
    }
    [BsonIgnoreExtraElements]
    public class ContactInformation  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string PrimaryContact { get; set; }
        [BsonIgnoreIfNull]
        public string Phone { get; set; }
        [BsonIgnoreIfNull]
        public string Fax { get; set; }
        [BsonIgnoreIfNull]
        public string eMail { get; set; }
    }
    [BsonIgnoreExtraElements]
    public class AddressInformation  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string Line1 { get; set; }
        [BsonIgnoreIfNull]
        public string Line2 { get; set; }
        [BsonIgnoreIfNull]
        public string Line3 { get; set; }
        [BsonIgnoreIfNull]
        public string City { get; set; }
        [BsonIgnoreIfNull]
        public string State { get; set; }
        [BsonIgnoreIfNull]
        public string Zipcode { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class SummaryInformation  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public int? TotalCopies { get; set; }
        [BsonIgnoreIfNull]
        public int? TotalSeries { get; set; }
    }
}







