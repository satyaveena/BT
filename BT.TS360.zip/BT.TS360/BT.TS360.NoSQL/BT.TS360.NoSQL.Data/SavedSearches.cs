﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class SavedSearches
    {
        [BsonIgnoreIfNull]
        public string SearchName { get; set; }
        [BsonIgnoreIfNull]
        public string UserID { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ProgramTypes { get; set; }
        [BsonIgnoreIfNull]
        public List<string> FormatTypes { get; set; }
        [BsonIgnoreIfNull]
        public List<string> SeriesStatus { get; set; }
        [BsonIgnoreIfNull]
        public List<string> AreasOfInterest { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Audience { get; set; }
        [BsonIgnoreIfNull]
        public List<SearchTerms> SearchTerms { get; set; }
        [BsonIgnoreIfNull]
        public DateTime? LastIssuePublishDate { get; set; }
        [BsonIgnoreIfNull]
        public decimal? LastIssueListPriceMinimum { get; set; }
        [BsonIgnoreIfNull]
        public decimal? LastIssueListPriceMaximum { get; set; }  
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }

    public class SearchTerms
    {
        [BsonIgnoreIfNull]
        public string SearchJoin { get; set; }      //And, Or, Not
        [BsonIgnoreIfNull]
        public string SearchTerm { get; set; }      //SeriesAuthorName,SeriesID,ISBN,PublisherDistributor ...
        [BsonIgnoreIfNull]
        public string SearchType { get; set; }      //BeginsWith, Contains, EndsWith, Exact
        [BsonIgnoreIfNull]
        public string SearchCriteria { get; set; }  //Search Criteria

    }

    public class SearchTermRecords
    {
        public SearchTermRecords()
        {
            SearchTermData = new List<SearchTerms>();
        }
        public List<SearchTerms> SearchTermData { get; set; }
    }
}
