﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class LoadErrors
    {
        [BsonIgnoreIfNull]
        public string LoadProgram { get; set; }
        [BsonIgnoreIfNull]
        public List<string> LoadIDs { get; set; }
        [BsonIgnoreIfNull]
        public string ExceptionMessage { get; set; }
        [BsonIgnoreIfNull]
        public Boolean? ReportedFlag { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }
}
