﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    class OrganizationTitles
    {
        public ObjectId _id { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        public ObjectId ProfileID { get; set; }
        public string SeriesID { get; set; }
        public string BTKey { get; set; }
        public List<ObjectId> ProfiledSeriesIDs { get; set; }
        public FootprintInformation FootprintInformation { get; set; }
    }
}