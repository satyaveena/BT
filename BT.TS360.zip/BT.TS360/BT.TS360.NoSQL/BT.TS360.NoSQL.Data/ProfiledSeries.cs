﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.Runtime.Serialization;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class ProfiledSeries
    {
        [BsonId]
        [BsonIgnoreIfDefault]  //2016-08-24 Jamie/Ralph
        public ObjectId ProfiledSeriesID { get; set; }
        [BsonIgnoreIfNull]
        public ObjectId ProfileID { get; set; }
        [BsonIgnoreIfNull]
        public string SeriesID { get; set; }
        [BsonIgnoreIfNull]                    
        public string Note { get; set; }  //This is populated from TS360
        [BsonIgnoreIfNull]
        public string RequestStatus { get; set; }
        [BsonIgnoreIfNull]
        public string ChangeRequestUserID { get; set; }  //PENDING
        //[BsonIgnoreIfNull]
        //public string Status { get; set; }   //2016-07-22  DHB There is no ProfiledSeries Status
        [BsonIgnoreIfNull]
        public int TotalPrimaryQuantity { get; set; }  //2016-07-22 Ralph requires for Dup Check Results
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public List<PO> PurchaseOrders { get; set; }
        [BsonIgnoreIfNull]
        public RedundantSeriesData RedundantSeriesInformation { get; set; }
        [BsonIgnoreIfNull]
        public RedundantProfileData RedundantProfileInformation { get; set; } //2016-02-11 Cerisa Required for report
    }

    [BsonIgnoreExtraElements]
    [DataContract]
    public class PO
    {
        [DataMember]
        public ObjectId PurchaseOrderID { get; set; }
        [DataMember]
        public string POLineNumber { get; set; }
        [DataMember]                            //PENDING
        public string POLineNumberProposed { get; set; }//PENDING
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public int? NonGridQuantity { get; set; }  //2016-07-22 DHB  There ain't no such thing.
        [BsonIgnoreIfNull]
        [DataMember]
        public string StartDate { get; set; }  //2016-07-25 DHB  StartData is now known as StartDate
        [BsonIgnoreIfNull]
        [DataMember]
        public string ShippingPreference { get; set; }  //2016-07-25 DHB  Cycle is now known as shipping preference
        [BsonIgnoreIfNull]
        [DataMember]
        public string Status { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferencePrimary { get; set; }  //2016-02-18  Systems requirement
        [BsonIgnoreIfNull]
        [DataMember]
        public int FormatPreferencePrimaryQuantity { get; set; }  //2016-03-03  New Business Requirement
        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferenceSecondary { get; set; } //2016-02-18  Systems requirement
        [BsonIgnoreIfNull]
        [DataMember]
        public int FormatPreferenceSecondaryQuantity { get; set; } //2016-03-03  New Business Requirement
        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferenceString { get; set; } //2016-07-25 DHB Corrected the name
        [DataMember]
        [BsonIgnoreIfNull]
        public List<POGrid> PurchaseOrderGrids { get; set; }  //2016-07-26  Re-evaluated the requirements
        [BsonIgnoreIfNull]
        [DataMember]
        public FootprintInformation FootprintInformation { get; set; }

        [BsonIgnoreIfNull]
        [DataMember]
        public bool StartNextAvailableTitle { get; set; }


        public class PORecords
        {
            public PORecords()
            {
                POData = new List<PO>();
            }
            public List<PO> POData { get; set; }
        }

    }

    [DataContract]
    [BsonIgnoreExtraElements]
    public class POGrid
    {
        [DataMember]
        [BsonId]
        public ObjectId PurchaseOrderGridID { get; set; }
        //[DataMember]
        //public string POLineNumber { get; set; }
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public string StartData { get; set; }
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public string Cycle { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string AgencyCodeID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string ItemTypeID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string CollectionID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string UserCode1ID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string UserCode2ID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string UserCode3ID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string UserCode4ID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string UserCode5ID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string UserCode6ID { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string CallNumberText { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public int Sequence { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public int? Quantity { get; set; }
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public string FormatPreferencePrimary { get; set; }  //2016-02-18  Systems requirement
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public int FormatPreferencePrimaryQuantity { get; set; }  //2016-03-03  New Business Requirement
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public string FormatPreferenceSecondary { get; set; } //2016-02-18  Systems requirement
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public int FormatPreferenceSecondaryQuantity { get; set; } //2016-03-03  New Business Requirement
        //[BsonIgnoreIfNull]
        //[DataMember]
        //public string FormatPreferences { get; set; } //2016-02-18  Systems requirement
        [BsonIgnoreIfNull]
        [DataMember]
        public FootprintInformation FootprintInformation { get; set; }


        [BsonIgnoreExtraElements]
        public class POGridRecords
        {
            public POGridRecords()
            {
                POGridData = new List<POGrid>();
            }
            public List<POGrid> POGridData { get; set; }
        }
    }
    [BsonIgnoreExtraElements]
    public class RedundantSeriesData  //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public string Author { get; set; }  //2016-02-11 Cerisa Required for report
        [BsonIgnoreIfNull]
        public string Format { get; set; }
        [BsonIgnoreIfNull]
        public string Audience { get; set; }
        [BsonIgnoreIfNull]
        public string Publisher { get; set; }
        [BsonIgnoreIfNull]
        public string Distributor { get; set; }                 //2017-09-20 CDM TFS 26484
        [BsonIgnoreIfNull]
        public string Frequency { get; set; }  //2016-02-18 Clarified by Nicole
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }
        [BsonIgnoreIfNull]
        public List<string> AreasOfInterest { get; set; }
        [BsonIgnoreIfNull]
        public string RequestStatus { get; set; }
        [BsonIgnoreIfNull]
        public string Status { get; set; }  //2016-03-03 Cerisa required for report
        [BsonIgnoreIfNull]
        public LatestIssueInformation LatestIssueInformation { get; set; } //2016-02-11 A better name
        [BsonIgnoreIfNull]
        public List<LatestIssueInformation> ForthcomingTitles { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }

        [BsonIgnoreIfNull]
        public bool HasRelatedSeries { get; set; } //2017-05-10 CDM TFS 25131
        [BsonIgnoreIfNull]
        public List<string> RelatedSeriesIDs { get; set; }          //2017-11-14 CDM TFS 27466
        [BsonIgnoreIfNull]
        public List<BindingPreference> BindingPreferences { get; set; }
        [BsonIgnoreIfNull]
        public bool HasBindingPreferences { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class RedundantProfileData  //2016-02-11 Cerisa Required for report
    {
        [BsonIgnoreIfNull]
        public string CompassAccountNumber { get; set; }  //2016-02-18  Jamie 
        [BsonIgnoreIfNull]
        public string ShippingAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public int? TotalSeries { get; set; } //2016-03-10 Cerisa required for report 
        [BsonIgnoreIfNull]
        public int? TotalCopies { get; set; }  //2016-03-03 Cerisa required for report
        [BsonIgnoreIfNull]
        public string Status { get; set; }  //2016-03-04  Ralph request
        [BsonIgnoreIfNull]
        public string ProfileType { get; set; } //2016-03-04  Ralph request
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }    //2016-04-08  Ralph 
        [BsonIgnoreIfNull]
        public string SalesTerritory { get; set; }  //2016-07-26  Ralph 
    }
}






