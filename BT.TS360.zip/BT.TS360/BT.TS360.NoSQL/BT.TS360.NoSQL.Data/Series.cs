﻿
using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class Series
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        public ObjectId SeriesObjectId { get; set; }  //2016-12-23 CDM needed for DateRangeCalculator use in AzureSearch for Facets
        public string SeriesID { get; set; }
        [BsonIgnoreIfNull]
        public string Name { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }
        [BsonIgnoreIfNull]
        public string Publisher { get; set; }
        [BsonIgnoreIfNull]
        public string Distributor { get; set; }                 //2017-09-20 CDM TFS 26484
        [BsonIgnoreIfNull]
        public string Format { get; set; }
        [BsonIgnoreIfNull]
        public LatestIssueInformation LatestIssueInformation { get; set; }
        [BsonIgnoreIfNull]
        public List<LatestIssueInformation> ForthcomingTitles { get; set; }
        [BsonIgnoreIfNull]
        public string Frequency { get; set; }  //2016-02-18 Clarified by Nicole
        [BsonIgnoreIfNull]
        public List<string> AreasOfInterest { get; set; }
        [BsonIgnoreIfNull]
        public string Audience { get; set; }  //2016-06-06 Changed from Audiences to Audience per Nicole
        [BsonIgnoreIfNull]
        public string Annotations { get; set; }
        //[BsonIgnoreIfNull]
        //public string ReadingLevelFrom { get; set; }  //2016-07-22 Nicole indicated not required
        //[BsonIgnoreIfNull]
        //public string ReadingLevelTo { get; set; }  //2016-07-22 Nicole indicated not required
        [BsonIgnoreIfNull]
        public string Author { get; set; }
        [BsonIgnoreIfNull]
        public List<string> RelatedSeriesIDs { get; set; }
        [BsonIgnoreIfNull]
        public List<BindingPreference> BindingPreferences { get; set; }
        [BsonIgnoreIfNull]
        public string StartDataType { get; set; } //2016-08-12 Requirement for the display of shipping preference
        [BsonIgnoreIfNull]
        public string Status { get; set; } //2016-02-18 Picked up by Tung
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public DateTime? LoadDateTime { get; set; }  //2016-06-06  Added for Follet Extract
        [BsonIgnoreIfNull]
        public List<ObjectId> SeriesLists { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ISBNList { get; set; }  //2016-11-25  CDM Added for Azure Search for Series
        [BsonIgnoreIfNull]
        public List<string> ISBN10List { get; set; }
        [BsonIgnoreIfNull]
        public List<string> PublicationDateRange { get; set; } //2016-12-19 CDM needed for DateRangeCalculator use in AzureSearch for Facets
        [BsonIgnoreIfNull]
        public bool HasRelatedSeries { get; set; } //2017-05-10 CDM TFS 25131
        [BsonIgnoreIfNull]
        public bool HasBindingPreferences { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ContentListIDList { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ProductType { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class LatestIssueInformation //1:1 Relationship
    {
        [BsonIgnoreIfNull]
        public string BTKey { get; set; }  //2016-02-23 Ralph required for UI
        [BsonIgnoreIfNull]
        public string ISBN { get; set; }
        [BsonIgnoreIfNull]
        public decimal? ListPrice { get; set; }
        [BsonIgnoreIfNull]
        public DateTime? PublicationDate { get; set; }
        [BsonIgnoreIfNull]
        public string Edition { get; set; }
        [BsonIgnoreIfNull]
        public string Title { get; set; }
        [BsonIgnoreIfNull]
        public string Author { get; set; }
        [BsonIgnoreIfNull]
        public string Format { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class BindingPreference
    {
        [BsonIgnoreIfNull]
        public string Literal { get; set; }
        [BsonIgnoreIfNull]
        public string PrimaryPreference { get; set; }
        [BsonIgnoreIfNull]
        public string SecondaryPreference { get; set; }
        [BsonIgnoreIfNull]
        public bool HasMultiplePreference { get; set; }
    }

}



