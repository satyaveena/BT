﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
        [BsonIgnoreExtraElements]
        public class FootprintInformation  //1:1 Relationship
        {
            [BsonIgnoreIfNull]
            public string CreatedBy { get; set; }
            [BsonIgnoreIfNull]
            public string CreatedByUserID { get; set; }  //2016-07-27 Ralph requested 
            [BsonIgnoreIfNull]
            public DateTime CreatedDate { get; set; }
            [BsonIgnoreIfNull]
            public string UpdatedBy { get; set; }
            [BsonIgnoreIfNull]
            public string UpdatedByUserID { get; set; }  //2016-07-27 Ralph requested 
            [BsonIgnoreIfNull]
            public DateTime UpdatedDate { get; set; }
        }
}
