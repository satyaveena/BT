﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Interfaces
{
    interface INoSQLService
    {
        // initialize the connection
        void Initialize();

        // retrieve the source
        void Get();

        // Load into Collection by batch size
        void Load(int batchSize);
    }
}
