﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MongoDB.Bson;

namespace BT.TS360.NoSQL.Data.Interfaces
{
    interface INoSQLAPI
    {
        // initialize the connection
        void Initialize();

        // Validate the request
        void Validate();

        // Bind Product
        Product BindProduct(BsonDocument bsonDocument);
    }
}
