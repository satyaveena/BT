﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.Runtime.Serialization;

namespace BT.TS360.NoSQL.Data
{

    [BsonIgnoreExtraElements]
    public class BasketLineItem
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        public ObjectId BasketLineID { get; set; }
        [BsonIgnoreIfNull]
        public string BasketSummaryID { get; set; }
        [BsonIgnoreIfNull]
        public string BasketOwnerID { get; set; }
        [BsonIgnoreIfNull]
        public string BasketStateID { get; set; }
        [BsonIgnoreIfNull]
        public string BTKey { get; set; }
        [BsonIgnoreIfNull]
        public string BasketName { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public bool NeedsDupeCheckUpdate { get; set; }
        [BsonIgnoreIfNull]
        public int LoadPriority { get; set; }
        [BsonIgnoreIfNull]
        public DateTime DownloadedDateTime { get; set; }
    }
}






