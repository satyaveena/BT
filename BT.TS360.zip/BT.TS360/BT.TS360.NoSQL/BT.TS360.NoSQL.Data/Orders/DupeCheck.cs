﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.Runtime.Serialization;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class DupeCheck
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        public ObjectId DupeCheckID { get; set; }
        [BsonIgnoreIfNull]
        public string BTKey { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public List<DupeCheckBasketSummary> BasketSummary { get; set; }
        [BsonIgnoreIfNull]
        public List<DupeCheckAccounts> Accounts { get; set; }
        [BsonIgnoreIfNull]
        public List<DupeCheckBasketSummary> DownloadedBasketSummary { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }

    }

    [BsonIgnoreExtraElements]
    public class DupeCheckBasketSummary
    {
        [BsonIgnoreIfNull]
        public string BasketSummaryID { get; set; }
        [BsonIgnoreIfNull]
        public string BasketOwnerID { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class DupeCheckAccounts
    {
        [BsonIgnoreIfNull]
        public string ShipToAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string ShipToAccount8Number { get; set; }
        [BsonIgnoreIfNull]
        public List<DupeCheckOrderSummary> OrderSummaries { get; set; } 
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class DupeCheckOrderSummary
    {
        [BsonIgnoreIfNull]
        public string BasketSummaryID { get; set; }
        [BsonIgnoreIfNull]
        public string OrderNumber { get; set; }

    } 
}






