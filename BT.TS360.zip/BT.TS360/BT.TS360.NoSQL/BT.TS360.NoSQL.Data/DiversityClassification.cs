﻿using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class DiversityClassification
    {
        public DiversityClassification()
        {
        }

        public string ClassificationCode { get; set; }
        [BsonIgnoreIfNull]
        public string ClassificationName { get; set; }
        [BsonIgnoreIfNull]
        public string RegionCode { get; set; }
    }
}

