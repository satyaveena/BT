﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class ChangeRequests
    {
        [BsonId]
        public ObjectId ChangeRequestID { get; set; }
        [BsonIgnoreIfNull]
        public ObjectId ProfiledSeriesID { get; set; }
        [BsonIgnoreIfNull]
        public ObjectId ProfileID { get; set; }
        [BsonIgnoreIfNull]
        public string ChangeType { get; set; }
        [BsonIgnoreIfNull]
        public string RequestType { get; set; }
        [BsonIgnoreIfNull]
        public string RequestStatus { get; set; }
        [BsonIgnoreIfNull]
        public string RequestedBy { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationName { get; set; }
        [BsonIgnoreIfNull]
        public string ProfileName { get; set; }
        [BsonIgnoreIfNull]
        public string ERPAccountNumber { get; set; }
        [BsonIgnoreIfNull]
        public string NotesChangeType { get; set; }  //TFS 22535  (replace, append or remove)
        [BsonIgnoreIfNull]
        public int? TotalQuantity { get; set; }
        [BsonIgnoreIfNull]
        public string SalesTerritory { get; set; }  //2016-07-22 Ralph requested to move this value from sub document ProfileChangeRequest

        [BsonIgnoreIfNull]
        public string AccountRepName { get; set; } //2019-01-15 : 32291 : TSSO request queue

        [BsonIgnoreIfNull]
        public ProfileChangeRequest ProfileChangeRequest { get; set; }

        [BsonIgnoreIfNull]
        public ProfileChangeRequest ProfileOriginalState { get; set; }

       [BsonIgnoreIfNull]
        public ProfiledSeriesChangeRequest ProfiledSeriesChangeRequest { get; set; }
        [BsonIgnoreIfNull]
        public ProfiledSeriesChangeRequest ProfiledSeriesOriginalState { get; set; } //2016-07-26 Ralph 
        //[BsonIgnoreIfNull]
        //public List<PO> PurchaseOrders { get; set; }        //2016-07-26 Ralph
        //[BsonIgnoreIfNull]
        //public List<POGrid> PurchaseOrderGrids { get; set; }  //2016-07-26 Ralph
        [BsonIgnoreIfNull]
        public RedundantSeriesData RedundantSeriesInformation { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        //[BsonIgnoreIfNull]
        //public string CreatedByUserName { get; set; }       //2016-07-27  Moved to footprint class
    }
    [BsonIgnoreExtraElements]
    public class ProfileChangeRequest
    {
        [BsonIgnoreIfNull]
        public string SAN { get; set; }
        [BsonIgnoreIfNull]
        public string ProfileType { get; set; }
        [BsonIgnoreIfNull]
        public string CatalogingAndProcessing { get; set; }
        [BsonIgnoreIfNull]
        public DateTime SubmissionDateTime { get; set; }
        [BsonIgnoreIfNull]
        public DateTime DisabledDateTime { get; set; }
        [BsonIgnoreIfNull]
        public List<string> AreasOfInterest { get; set; }
        [BsonIgnoreIfNull]
        public ContactInformation ContactInformation { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Programs { get; set; }
        [BsonIgnoreIfNull]
        public string Instructions { get; set; }
        [BsonIgnoreIfNull]
        public int? TotalCopies { get; set; }
        [BsonIgnoreIfNull]
        public int? TotalSeries { get; set; }
        [BsonIgnoreIfNull]
        public string NewProfileName { get; set; }
        [BsonIgnoreIfNull]
        public List<NotificationUser> NotificationUsers { get; set; }
    }

     [BsonIgnoreExtraElements]
    public class NotificationUser
    {
        public string UserID { get; set; }
        public string UserAlias { get; set; }
        public string UserName { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class ProfiledSeriesChangeRequest
    {
        [BsonIgnoreIfNull]
        public string SeriesID { get; set; }
        [BsonIgnoreIfNull]
        public string DisabledReason { get; set; }  //TFS 22535

        [BsonIgnoreIfNull]
        public string DeleteReason { get; set; }  //TFS 23712

        [BsonIgnoreIfNull]
        public string Notes { get; set; }           //2016-07-26 Ralph

        [BsonIgnoreIfNull]
        public string SpecialInstruction { get; set; }           //2019-01-15 Karine - #32291

        [BsonIgnoreIfNull]
        public List<PO> PurchaseOrders { get; set; } //2016-07-26 Ralph
    }

}

