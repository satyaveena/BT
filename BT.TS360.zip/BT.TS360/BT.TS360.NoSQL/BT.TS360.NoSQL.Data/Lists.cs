﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class Lists
    {
        [BsonId]
        public ObjectId _id { get; set; }
        [BsonIgnoreIfNull]
        public string Literal { get; set; }
        [BsonIgnoreIfNull]
        public ObjectId ParentID { get; set; }//THE _id OF THE IMMEDIATE PARENT
        [BsonIgnoreIfNull]
        public string ParentLiteral { get; set; }
        [BsonIgnoreIfNull]
        public List<ObjectId> AncestorIDs { get; set; }     //A LIST OF ANCESTOR ID'S
        [BsonIgnoreIfNull]
        public int? Sequence { get; set; }                  //THE ORDER IN WHICH THE NODE WILL APPEAR IN RELATION TO IT'S SIBLINGS
        [BsonIgnoreIfNull]
        public int? ChildCount { get; set; }                //THE NUMBER OF LEAF NODES BELOW THIS PARENT NODE              
        [BsonIgnoreIfNull]
        public Boolean? LeafIndicator { get; set; }         //INDICATES TO THE CALLING PROGRAM THAT THIS IS THE BOTTOM LEVEL NODE
        [BsonIgnoreIfNull]
        public Boolean HideLink { get; set; } 
        [BsonIgnoreIfNull]
        public ObjectId Attachment { get; set; }            //THE _id of the GridFS document in gridfs.fs.files
        [BsonIgnoreIfNull]
        public List<string> ListItems { get; set; }
        [BsonIgnoreIfNull]
        public string ItemType { get; set; }
        [BsonIgnoreIfNull]
        public string FeaturedListType { get; set; }
        [BsonIgnoreIfNull]
        public string FeaturedListLiteral { get; set; }
        [BsonIgnoreIfNull]
        public int? FeaturedListSequence { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public FileInformation FileInformation { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class FileInformation
    {
        [BsonIgnoreIfNull]
        public string ColumnStart { get; set; }
        [BsonIgnoreIfNull]
        public string ColumnName { get; set; }
        [BsonIgnoreIfNull]
        public DateTime? LastUpdated { get; set; }
        [BsonIgnoreIfNull]
        public int? RowStart { get; set; }
        [BsonIgnoreIfNull]
        public string FileName { get; set; }
        [BsonIgnoreIfNull]
        public string FilePathURL { get; set; }
        [BsonIgnoreIfNull]
        public bool? NeedsUpdate { get; set; }

    }

    //public class HitHistory
    //{
    //    public DateTime HitDate { get; set; }
    //    public int HitCount { get; set; }

    //    public class HitRecords
    //    {
    //        public HitRecords()
    //        {
    //            HitHistoryData = new List<HitHistory>();
    //        }
    //        public List<HitHistory> HitHistoryData { get; set; }
    //    }
    //}

}

////First Level
//db.Lists.insert( { _id: 1, Literal: "Standing Orders Lists" } )
//Featured Lists
//db.Lists.insert( { _id: "11", Literal: "Featured Lists", ParentID: "1" } )
//db.Lists.insert( { _id: "111", Literal: "Most Recent Lists", ParentID: "11" } )
//db.Lists.insert( { _id: "112", Literal: "Most Popular Lists", ParentID: "11" } )
//db.Lists.insert( { _id: "1111", Literal: "Most Recent List 1", ParentID: "111" } )
//db.Lists.insert( { _id: "1112", Literal: "Most Recent List 2", ParentID: "111" } )
//db.Lists.insert( { _id: "1113", Literal: "Most Recent List 3", ParentID: "111" } )


//db.Lists.insert( { Literal: "Most Popular Lists", Parent: "1" } )
//db.Lists.insert( { _id: "Basic Lists", Parent: "Continuations Lists" } )

//db.Lists.insert( { _id: "Basic Lists", Parent: "Continuations Lists" } )
//db.Lists.insert( { _id: "Business & Finance", Parent: "Continuations Lists" } )
//db.Lists.insert( { _id: "eBooks", Parent: "Continuations Lists" } )
//db.Lists.insert( { _id: "Education & Careers", Parent: "Continuations Lists" } )
//db.Lists.insert( { _id: "Hobby & Leisure", Parent: "Continuations Lists" } )
//db.Lists.insert( { _id: "Travel & Tourism", Parent: "Continuations Lists" } )

////Second Level
//db.Lists.insert( { _id: "Exclusive eBook Selection Lists", Parent: "Basic Lists" } )
//db.Lists.insert( { _id: "Exclusive Print Selection Lists", Parent: "Basic Lists" } )

//db.Lists.insert( { _id: "Adult E-Series", Parent: "eBooks" } )
//db.Lists.insert( { _id: "Childrens and Teen E-Series", Parent: "eBooks" } )
//db.Lists.insert( { _id: "Adult Popular E-Authors", Parent: "eBooks" } )
//db.Lists.insert( { _id: "Spoken Word Digital Audiobook Authors", Parent: "eBooks" } )
//db.Lists.insert( { _id: "Gale Reference E-Series", Parent: "eBooks" } )