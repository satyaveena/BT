﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.Runtime.Serialization;


namespace BT.TS360.NoSQL.Data.Axis360
{
    [DataContract]
    public class Axis360InventoryResponse
    {
        [DataMember(Name = "libraryInventoryList")]
        public List<Axis360Inventory> LibraryInventoryList { get; set; }
        [DataMember(Name = "status")]
        public Axis360Status Status { get; set; }
        [DataMember(Name = "pageToken")]
        public string PageToken { get; set; }
    }
 }

    [DataContract]
    public class Axis360Status
    {
        [DataMember(Name = "Code")]
        public string Code { get; set; }
        [DataMember(Name = "Message")]
        public string Message { get; set; }
    }