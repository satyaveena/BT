﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace BT.TS360.NoSQL.Data.Axis360
{
    [BsonIgnoreExtraElements]
    public class Axis360Inventory
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        [BsonIgnoreIfNull]
        public ObjectId ID { get; set; }
        [BsonIgnoreIfNull]
        public string ISBN { get; set; }
        [BsonIgnoreIfNull]
        public string LibraryID { get; set; }
        [BsonIgnoreIfNull]
        public string CustomerID { get; set; }
        [BsonIgnoreIfNull]
        public string LibraryPrefix { get; set; }
        [BsonIgnoreIfNull]
        public int TotalQuantity { get; set; }
        [BsonIgnoreIfNull]
        public int MyQuantity { get; set; }
        [BsonIgnoreIfNull]
        public int ParentQuantity { get; set; }
        [BsonIgnoreIfNull]
        public string State { get; set; }
        [BsonIgnoreIfNull]
        public DateTime AddedDate { get; set; }
        [BsonIgnoreIfNull]
        public DateTime UpdateDate { get; set; }
        [BsonIgnoreIfNull]
        public bool NeedsCrawl { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }
}