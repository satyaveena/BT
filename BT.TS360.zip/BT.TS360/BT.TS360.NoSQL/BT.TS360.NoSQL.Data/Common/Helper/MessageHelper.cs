﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using BTNextGen.Elmah;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.IO;
using System.Net.Mail;

namespace BT.TS360.NoSQL.Data.Common.Helper
{
    public class MessageHelper
    {
        private string _exceptionLogConnection;
        private string _folder;
        private string _prefix;
        private string _fileName;
        private static object locker = new object();
        private string _smtpSever;
        private string _emailLists;
        private string _serviceName;
        private string _environment;
        private bool _verboseLogging;
        private int _currentLogHour;

        public MessageHelper(string exceptionLogConnection, string folder, string prefix, string smtpServer, string emailLists, string serviceName, string environment, bool verboseLogging)
        {
            _exceptionLogConnection = exceptionLogConnection;
            _smtpSever = smtpServer;
            _emailLists = emailLists;
            _folder = folder;
            _prefix = prefix;
            _serviceName = serviceName;
            _environment = environment;
            _verboseLogging = verboseLogging;
            _fileName = string.Format("{0}_{1}.txt", _prefix, DateTime.Now.ToString("yyyy-MM-dd-HH0000"));
            _currentLogHour = DateTime.Now.Hour;
        }

        public void HandleMessage(Exception exception, string source, string message, FileLoggingLevel level)
        {
            if (level == FileLoggingLevel.ERROR)
            {
                if (exception != null)
                {
                    LogErrorToELMAH(exception, _serviceName + " " + source);
                }
                WriteToFile(message, level);
            }
            else if (level == FileLoggingLevel.STATE)
            {
                WriteToFile(message, level);
                SendEmail(message);
            }
            else if (level == FileLoggingLevel.INFO && _verboseLogging)
            {
                WriteToFile(message, level);
            }
        }

        /*
         * Generic logging, which include Exception, Application and Source
         */
        private void LogErrorToELMAH(Exception exception, string source)
        {
            LogErrorToELMAH(exception, source, "");
        }

        /*
         * Logging includes the JSON
         */
        private void LogErrorToELMAH(Exception exception, string source, string requestInJson)
        {
            var errorLog = new ELMAHMongoLogger(_exceptionLogConnection);
            errorLog.ApplicationName = _serviceName;

            var error = new Error(exception);
            error.ApplicationName = errorLog.ApplicationName;
            error.Source = source;
            error.Type = exception.GetBaseException().GetType().ToString();


            // when logging replace double quote with single quote, as we have encoding issue when logging JSON in AllXML column
            // if we need to debug, simply get the details from WebHostHtmlMessage within AllXML, then use notepad or other text editor, replace two single quotes with one double quotes
            error.WebHostHtmlMessage = requestInJson.Replace("\"", "''");

            errorLog.Log(error);
        }

        private void WriteToFile(string message, FileLoggingLevel level)
        {
            if(_currentLogHour != DateTime.Now.Hour)
            {
                _fileName = string.Format("{0}_{1}.txt", _prefix, DateTime.Now.ToString("yyyy-MM-dd-HH0000"));
            }
            lock (locker)
            {
                string logFilePath = string.Format("{0}\\{1}", _folder, _fileName);
                using (FileStream file = new FileStream(logFilePath, FileMode.Append, FileAccess.Write, FileShare.None))
                {
                    DateTime now = DateTime.Now;
                    StreamWriter writer = new StreamWriter(file);
                    writer.Write(string.Format("{0}\t{1}\t{2}", now, level.ToString(), message));
                    writer.WriteLine();
                    writer.Flush();
                }
            }
        }

        public void SendEmail(string messageBody)
        {
            try
            {
                SmtpClient client = new SmtpClient(_smtpSever);
                MailAddress from = new MailAddress("no-reply@btol.com", "Mongo Support Team");

                MailMessage message = new MailMessage();

                message.From = from;
                message.IsBodyHtml = true;

                message.To.Clear();

                //   MailAddress to = new MailAddress(emailLists);

                var emailToList = _emailLists.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        message.To.Add(emailTo);
                }


                messageBody = messageBody.Replace(Environment.NewLine, "<br>");

                message.Body = messageBody;
                message.Subject = _serviceName + " " + _environment;

                client.Send(message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Can not send email: " + ex.Message);
            }
        }
    }
}
