﻿using System;
using System.Collections.Generic;
using MongoDB.Driver;
using MongoDB.Bson;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Data;
using System.Threading;

namespace BT.TS360.NoSQL.Data.Common.Helper
{
    public class AzureSearchQueueHelper
    {
        IMongoClient _client;
        IMongoDatabase _databaseCommon;
        IMongoCollection<AzureSearchQueueItem> _azureSearchQueue;

        int _retryWaitTime;
        int _retries;
       

        public AzureSearchQueueHelper(string connection, int retryWaitTime, int retries)
        {
            _retryWaitTime = retryWaitTime;
            _retries = retries;
 
            _client = new MongoClient(connection);
            _databaseCommon = _client.GetDatabase(CommonConstants.CommonDatabaseName);
            _azureSearchQueue = _databaseCommon.GetCollection<AzureSearchQueueItem>(CommonConstants.AzureSearchQueueCollectionName);
        }

        public  async Task UpdateAzureSearchQueue(string azureSearchQueueItem, string collectionName, string changeType, string requestedBy, int queuePriority)
        {
            await UpdateAzureSearchQueue(new List<string> { azureSearchQueueItem }, collectionName, changeType, requestedBy, queuePriority);
        }

        public  async Task UpdateAzureSearchQueue(List<string> azureSearchQueueItemList, string collectionName, string changeType, string requestedBy, int queuePriority)
        {
            await InsertAzureSearchQueueItems(GetAzureSearchQueueItemFromList(azureSearchQueueItemList, collectionName, changeType, requestedBy, queuePriority));
        }

        private  async Task InsertAzureSearchQueueItems(List<AzureSearchQueueItem> azureSearchQueueItemList)
        {
            var retries = _retries;
            while (retries > 0)
            {
                try
                {
                    await _azureSearchQueue.InsertManyAsync(azureSearchQueueItemList);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(_retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

        }

        private List<AzureSearchQueueItem> GetAzureSearchQueueItemFromList(List<string> objectIds, string collectionName, string changeType, string requestedBy, int queuePriority)
        {
            var azureSearchQueueItemList = new List<AzureSearchQueueItem>();
            var footprintInformation = new FootprintInformation();
            var now = DateTime.Now;
            footprintInformation.CreatedBy = requestedBy;
            footprintInformation.CreatedDate = now;
            footprintInformation.UpdatedBy = requestedBy;
            footprintInformation.UpdatedDate = now;
            foreach (var objectId in objectIds)
            {
                var azureSearchQueueItem = new AzureSearchQueueItem();

                azureSearchQueueItem.ObjectId = ObjectId.Parse(objectId);
                azureSearchQueueItem.ChangeType = changeType;
                azureSearchQueueItem.CollectionName = collectionName;
                azureSearchQueueItem.Priority = queuePriority;
                azureSearchQueueItem.InProcessState = 0;
                azureSearchQueueItem.IsRealTime = true;
                azureSearchQueueItem.FootprintInformation = footprintInformation;
                azureSearchQueueItemList.Add(azureSearchQueueItem);
            }
            return azureSearchQueueItemList;
        }
    }
}