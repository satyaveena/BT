﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Helper
{
    public class SecurityHandler
    {
        public SecurityHandler() { }

        public bool ValidateAPIKey(HttpRequestMessage request, string apiKeyValue)
        {
            bool isValid = false;
            string apiKeyHeaderValue = string.Empty;

            HttpRequestHeaders headers = request.Headers;

            IEnumerable<string> apiKeyHeaderValues = null;

            if (headers.TryGetValues("X-ApiKey", out apiKeyHeaderValues))
            {
                apiKeyHeaderValue = apiKeyHeaderValues.First();
                isValid = (apiKeyHeaderValue == apiKeyValue) ? true : false;
            }

            return isValid;
        }

    }
}
