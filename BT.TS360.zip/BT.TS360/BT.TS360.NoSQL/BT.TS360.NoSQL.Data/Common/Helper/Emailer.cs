﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Helper
{
    public class Emailer
    {
        private string _smtpSever;
        
        public Emailer(string smtpServer)
        {
            _smtpSever = smtpServer;
        }

        public void Send(string emailLists, string messageSubject, string messageBody)
        {
            try
            {
                SmtpClient client = new SmtpClient(_smtpSever);
                MailAddress from = new MailAddress("no-reply@btol.com", "Mongo Support Team");

                MailMessage message = new MailMessage();

                message.From = from;
                message.IsBodyHtml = true;

                message.To.Clear();

                //   MailAddress to = new MailAddress(emailLists);

                var emailToList = emailLists.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        message.To.Add(emailTo);
                }


                messageBody = messageBody.Replace(Environment.NewLine, "<br>");

                message.Body = messageBody;
                message.Subject = messageSubject;

                client.Send(message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Can not send email: " + ex.Message);
            }
        }

    }
}
