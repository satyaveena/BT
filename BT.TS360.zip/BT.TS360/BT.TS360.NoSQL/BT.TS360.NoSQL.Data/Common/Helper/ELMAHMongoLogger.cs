﻿using BT.TS360.NoSQL.Data.Common.Constants;
using BTNextGen.Elmah;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.Data.Common.Helper
{
    /// <summary>
    /// ELMAHMongoLogger
    /// </summary>
    public class ELMAHMongoLogger
    {
        #region Private Member
        private readonly String _connectionString;
        private readonly String _collectionName;
        private IMongoCollection<BsonDocument> _collection;
        public string ApplicationName { get; set; }
        #endregion

        #region Constructor
        public ELMAHMongoLogger(string connectionString)
        {
            _connectionString = connectionString;
            _collectionName = CommonConstants.ExceptionLogCollectionName;

            Initialize();

        }
        #endregion

        #region Method
        #region Public

        /// <summary>
        /// Log
        /// </summary>
        /// <param name="error"></param>
        /// <returns>String</returns>
        public String Log(Error error)
        {
            if (error == null)
                throw new ArgumentNullException("error");

            error.ApplicationName = ApplicationName;

            BsonDocument document = error.ToBsonDocument();

            ObjectId id = ObjectId.GenerateNewId();
            document.Add("_id", id);

            String errorXml = ErrorXml.EncodeString(error);
            document.Add("AllXml", errorXml);
            
            _collection.InsertOne(document);

            return id.ToString();
        }

        #endregion
        #region Private

        /// <summary>
        /// Initialize
        /// </summary>
        private void Initialize()
        {
            MongoUrl mongoUrl = MongoUrl.Create(_connectionString);
            IMongoDatabase database = new MongoClient(mongoUrl).GetDatabase(CommonConstants.ApplicationLogDatabaseName);
            _collection = database.GetCollection<BsonDocument>(_collectionName);
        }
        #endregion
        #endregion

    }
}
