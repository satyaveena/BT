﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Models;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;


namespace BT.TS360.NoSQL.Data.Common.DAM
{
    public class ChangeRequestManager
    {

        #region Batch Export
        public async Task<BatchExportResponse> RequestStatusBatchExport(IMongoCollection<ChangeRequests> _changeRequests, 
                                                                        string organizationID, 
                                                                        ObjectId profileObjectId, string submittedByUserName, string submittedByUserId, 
                                                                                int retryWaitTime, int retries)
        {
            var batchExportResponse = new BatchExportResponse();

            // Get the ChangeRequest 
            // per profile ID, request type = 'Add' and reuest Status = 'new'
            var filter = GetRequestStatusBatchExportFilter(profileObjectId, organizationID);

            var response = await GetProfiledSeriesChangeRequests(_changeRequests, filter, retryWaitTime, retries);

            // store the changerequest result sets
            batchExportResponse.ChangeRequestList = response.ItemList;
            batchExportResponse.TotalItems = response.TotalItems;

            // update the changerequest per _id from 'New' to 'completed'
            List<ObjectId> updateListIds = new List<ObjectId>(batchExportResponse.ChangeRequestList.Select(s => s.ChangeRequestID).ToList());

            var changeRequestFilter = Builders<ChangeRequests>.Filter.In("_id", updateListIds);

            var changeReqestUpdate =
                    Builders<ChangeRequests>.Update.Set("RequestStatus", CommonConstants.ChangeRequestStatus.Completed)
                                                   .Set("FootprintInformation.UpdatedDate", DateTime.Now)
                                                   .Set("FootprintInformation.UpdatedBy", submittedByUserName)
                                                   .Set("FootprintInformation.UpdatedByUserID", submittedByUserId);

            await _changeRequests.UpdateManyAsync(changeRequestFilter, changeReqestUpdate);

            // return change request
            return batchExportResponse;
        }

        private async Task<NoSqlDataResponse<ChangeRequests>> GetProfiledSeriesChangeRequests(IMongoCollection<ChangeRequests> _changeRequests, FilterDefinition<ChangeRequests> filter, int retryWaitTime, int retries)
        {
            var response = new NoSqlDataResponse<ChangeRequests>();

            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    response.TotalItems = await cursor.CountAsync();
                    response.ItemList = await cursor.ToListAsync<ChangeRequests>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }

        private FilterDefinition<ChangeRequests> GetRequestStatusBatchExportFilter(ObjectId profileObjectId, string organizationID)
        {
            FilterDefinition<ChangeRequests> filter =  Builders<ChangeRequests>.Filter.Eq("ChangeType", CommonConstants.ChangeRequestChangeType.ProfiledSeries) // Profiled Series
                 & Builders<ChangeRequests>.Filter.Eq("RequestType", CommonConstants.ChangeRequestRequestType.AddSeries) // Add
                 & Builders<ChangeRequests>.Filter.Eq("RequestStatus", CommonConstants.ChangeRequestStatus.Open); // New

            if (!profileObjectId.Equals(ObjectId.Empty))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("ProfileID", profileObjectId);
            }

            if (!string.IsNullOrEmpty(organizationID))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("OrganizationID", organizationID);
            }

            return filter;
        }

        public BatchExportRealtimeResponse GenerateBatchExportRealtimeFile(string orgLevelId, BatchExportResponse ber, string userName) 
        {
            StringBuilder filecontent = new StringBuilder("OrganId,TechnicalCenterId,RegionId,BranchId,SeriesID,Series Name,Quantity,CustOrderNo,Start_code,StartDate,Cycle,Binding #1,Preference #1,PB_Qty #1,Binding #2,Preference #2,PB_Qty #2,Special Instructions");
            filecontent.AppendLine();

            var accountNumber = "";
            var profileName = "";
            List<ChangeRequests> crList = ber.ChangeRequestList;
            foreach (var cr in crList)
            {
                if (accountNumber == "")
                    accountNumber = cr.ERPAccountNumber;

                if (profileName == "")
                    profileName = cr.ProfileName;

                if (cr.ProfiledSeriesChangeRequest != null && cr.ProfiledSeriesChangeRequest.PurchaseOrders != null)
                {
                    foreach (var po in cr.ProfiledSeriesChangeRequest.PurchaseOrders)
                    {
                        var organId = cr.ERPAccountNumber.Substring(0, 6);
                        var technicalCenterId = cr.ERPAccountNumber.Substring(6, 7);
                        var regionId = cr.ERPAccountNumber.Substring(13, 1);
                        var branchId = cr.ERPAccountNumber.Substring(14, 6);



                        var seriesName = string.IsNullOrEmpty(cr.RedundantSeriesInformation.Name) ? "" : cr.RedundantSeriesInformation.Name;
                        seriesName = seriesName.Replace(",", " ");

                        var quantity = "";
                        var formatPreferencePrimary = "";
                        var formatPreferencePrimary2 = "";
                        var formatPreferencePrimaryQty = "";
                        var formatPreferenceSecondary = "";
                        var formatPreferenceSecondary2 = "";
                        var formatPreferenceSecondaryQty = "";
                        if (string.IsNullOrEmpty(po.FormatPreferencePrimary))
                        {
                            quantity = po.FormatPreferencePrimaryQuantity.ToString();
                        }
                        else
                        {
                            formatPreferencePrimary = po.FormatPreferencePrimary;
                            formatPreferencePrimary2 = "1st";
                            formatPreferencePrimaryQty = po.FormatPreferencePrimaryQuantity.ToString();
                            if (!string.IsNullOrEmpty(po.FormatPreferenceSecondary))
                            {
                                formatPreferenceSecondary = po.FormatPreferenceSecondary;
                                formatPreferenceSecondary2 = "2nd";
                                formatPreferenceSecondaryQty = po.FormatPreferenceSecondaryQuantity.ToString();
                            }
                        }
                        var start_date = "";
                        if (po.StartNextAvailableTitle && string.IsNullOrEmpty(po.StartDate))
                        {
                            start_date = "Next";
                        }
                        else
                        {
                            DateTime dt;
                            if (DateTime.TryParseExact(po.StartDate, "MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt))
                            {
                                start_date = dt.ToString("yyyy/MM");
                            }
                            else
                            {
                                start_date = po.StartDate;
                            }
                        }

                        var specialInstruct = string.IsNullOrEmpty(cr.ProfiledSeriesChangeRequest.SpecialInstruction) ? "" : cr.ProfiledSeriesChangeRequest.SpecialInstruction;
                        specialInstruct = specialInstruct.Replace(",", " ");

                        filecontent.Append(organId + ",");
                        filecontent.Append(technicalCenterId + ",");
                        filecontent.Append(regionId + ",");
                        filecontent.Append(branchId + ",");
                        filecontent.Append(cr.ProfiledSeriesChangeRequest.SeriesID + ",");
                        filecontent.Append(seriesName + ",");
                        filecontent.Append(quantity + ",");
                        filecontent.Append(po.POLineNumber + ",");
                        filecontent.Append("D,");
                        filecontent.Append(start_date + ",");
                        filecontent.Append(po.ShippingPreference + ",");
                        filecontent.Append(formatPreferencePrimary + "," + formatPreferencePrimary2 + "," + formatPreferencePrimaryQty + ",");
                        filecontent.Append(formatPreferenceSecondary + "," + formatPreferenceSecondary2 + "," + formatPreferenceSecondaryQty + ",");
                        filecontent.Append(specialInstruct + ",");
                        filecontent.AppendLine();
                    }
                }
            }

            string filename ="";
            if (!string.IsNullOrEmpty(orgLevelId) && accountNumber.Length > 6)
            {
                filename = string.Format("{0}_{1}_{2:MMddyyyy}.csv", RetrieveInitalName(userName), accountNumber.Substring(0, 6), DateTime.Now);
            }
            else
            {
                var profilePart = string.IsNullOrEmpty(profileName) ? "" : profileName.Split(' ')[0];
                filename = string.Format("{0}_{1}_{2:MMddyyyy}_{3}.csv", RetrieveInitalName(userName), accountNumber, DateTime.Now, profilePart);
            }
            return new BatchExportRealtimeResponse { FileContent = filecontent.ToString(), FileName = filename };
        }

        private string RetrieveInitalName(string givenName)
        {
            var arrParts = givenName.Split(' ');

            var result = "";
            foreach (var part in arrParts)
            {
                if (!string.IsNullOrEmpty(part))
                {
                    result += part.Substring(0, 1);
                }
            }
            return result.ToUpper();
        }

        #endregion

        public string GetAccountRepName(IMongoCollection<BsonDocument> _iCustomerAccountRepCollection, string salesTerritory)
        {
            string accountRepName = string.Empty;

            var salesfilter = Builders<BsonDocument>.Filter.Eq("SalesTerritory", salesTerritory.Trim());
            var salesResult = _iCustomerAccountRepCollection.Find(salesfilter).Limit(1).ToListAsync().Result;
            
            if (salesResult.Count > 0)
            {
                var customerAccountRep = new CustomerAccountRep
                {
                    SalesName = salesResult[0]["SalesName"].ToString(),
                };

                accountRepName = customerAccountRep.SalesName;
            }

            return accountRepName;
        }


    }
}
