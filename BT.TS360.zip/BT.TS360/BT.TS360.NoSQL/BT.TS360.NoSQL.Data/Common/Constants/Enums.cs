﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Constants
{
    public enum DatabaseResultCode { Succeed, Warning, Error };

    public enum FileLoggingLevel { INFO, ERROR, STATE };

    public enum MarketType
    {
        Retail = 0,
        PublicLibrary = 1,
        AcademicLibrary = 2,
        SchoolLibrary = 3
    }

    public enum NoSqlServiceStatus
    {
        Success = 0,
        Fail = 1
    }

    public enum DemandLoadType
    {
        BTBDelta = 0,
        BTEDelta = 1,
        BTBFull = 2, 
        BTEFull = 3
    }

    public enum ProductTypes 
    { 
        Book = 0, 
        Music = 2, 
        Movie = 3, 
        Digital = 4 
    }
}
