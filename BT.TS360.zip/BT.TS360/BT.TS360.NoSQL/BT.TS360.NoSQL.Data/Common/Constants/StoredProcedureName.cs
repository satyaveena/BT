﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Constants
{
    public class StoredProcedureName
    {
        #region ODS
        
        public const string USP_SEL_EXTRACT_TS360_PRODUCTS = "usp_sel_extract_TS360_Products";

        public const string USP_UPD_TS360_PRODUCTS_QUEUE = "usp_upd_TS360_products_queue";

        public const string USP_SEL_EXTRACT_NEXTGEN_DEMANDBTB_MONGO_DELTA = "usp_sel_extract_NextGen_DemandBTB_Mongo_Delta";

        public const string USP_SEL_EXTRACT_NEXTGEN_DEMANDBTE_MONGO_DELTA = "usp_sel_extract_NextGen_DemandBTE_Mongo_Delta";

        public const string USP_SEL_EXTRACT_NEXTGEN_DEMANDBTB_MONGO_FULL = "usp_sel_extract_NextGen_DemandBTB_Mongo_Full";

        public const string USP_SEL_EXTRACT_NEXTGEN_DEMANDBTE_MONGO_FULL = "usp_sel_extract_NextGen_DemandBTE_Mongo_Full";

        #endregion

        #region TS360 Repository

        public const string USP_SET_INVENTORY_DEMAND_BUCKETS = "procMongoSetInventoryDemandBuckets";
        public const string USP_Mongo_Set_Axis_Circulation_Data = "procMongoSetAxisCirculationData";
        #endregion
    }

}
