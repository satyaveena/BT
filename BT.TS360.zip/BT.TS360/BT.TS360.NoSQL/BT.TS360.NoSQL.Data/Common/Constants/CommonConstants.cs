﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Constants
{
    public class CommonConstants
    {
        public class ReportCodeConstants
        {
            public const string NOT_YET_PUBLISHED = "NOT YET PUBLISHED";

            public const string OUT_OF_STOCK = "PUBLISHER OUT OF STOCK";

            public const string SUPPLIER_OUT_OF_STOCK = "SUPPLIER OUT OF STOCK";

            public const string PRODUCT_CANCELLED = "PRODUCT CANCELLED";

            public const string APPLY_DIRECT = "APPLY DIRECT";

            public const string OUT_OF_PRINT = "OUT OF PRINT";

            public const string PERMANENTLY_OUT_OF_STOCK = "PERMANENTLY OUT OF STOCK";

            public const string PUBLICATION_CANCELLED = "PUBLICATION CANCELLED";

            public const string PUBLISHER_OUT_OF_STOCK_INDEFINITELY = "PUBLISHER OUT OF STOCK INDEFINITELY";

            public const string PUBLISHER_OUT_OF_BUSINESS = "PUBLISHER OUT OF BUSINESS";

            public const string UNABLE_TO_LOCATE_PUBLISHER = "UNABLE TO LOCATE PUBLISHER";
        }

        public class WarehouseConstants
        {
            public const string REN = "REN";
            public const string COM = "COM";
            public const string MOM = "MOM";
            public const string SOM = "SOM";
            public const string RNO = "RNO";
            public const string VIM = "VIM";
            public const string VIE = "VIE";
            public const string SUP = "VIP";
            public const string VII = "VII"; // Ingram
        }

        public class ProductCodeConstants
        {
            public const string BOOK = "Book";

            public const string EBOOK = "EBook";

            public const string MUSIC = "Music";

            public const string MOVIE = "Movie";
        }

        public class ChangeRequestStatus
        {
            public const string Open = "New";

            public const string InProgress = "In Process";

            public const string Deleted = "Deleted";

            public const string Loaded = "Loaded";

            public const string Removed = "Removed";

            public const string Completed = "Completed";
        }

        public class ChangeRequestChangeType
        {
            public const string ProfiledSeries = "ProfiledSeries";

            public const string Profile = "Profile";
        }

        public class ChangeRequestRequestType
        {

            public const string DeleteSeries = "Delete"; // "Delete Series"
            public const string ModifySeries = "Modify"; // "Modify Series"
            public const string DisableProfile = "Disable Profile";
            public const string CopyProfile = "Copy Profile";
            public const string DeleteProfile = "Delete Profile";
            public const string NewProfile = "New Profile";
            public const string ModifyUsers = "Modify Users";
            public const string AddSeries = "Add"; //"Add Series";
        }

        public const string DefaultDateTimeFormat = "MM/dd/yyyy";
        public const string DefaultTimeFormat = "hh:mm:ss tt";
        public const string StandingOrdersDatabaseName = "StandingOrders";
        public const string ProfilesCollectionName = "Profiles";
        public const string SeriesCollectionName = "Series";
        public const string ProfiledSeriesCollectionName = "ProfiledSeries";
        public const string ChangeRequestsCollectionName = "ChangeRequests";
        public const string AzureSearchQueueCollectionName = "AzureSearchQueue";
        public const string BackgroundQueueCollectionName = "BackgroundQueue";
        public const string CustomerAccountRepCollectionName = "CustomerAccountRep";

        public const string ProductsDatabaseName = "Products";
        public const string ProductsCollectionName = "Products";

        public const string CommonDatabaseName = "Common";
        public const string ListsCollectionName="Lists";

        public const string CmsDatabaseName = "ListsMgtPortal";
        public const string CategoryCollectionName = "Category";

        public const string ProfilesDatabaseName = "Profiles";
        public const string SiteTermCollectionName = "SiteTerms";

        public const string SavedSearchesCollectionName = "SavedSearches";
        public const string ILSAPIRequestCollectionName = "ILSAPIRequestLog";

        public const string Axis360DatabaseName = "Axis360";
        public const string Axis360InventoryCollectionName = "Inventory";

        public const string ApplicationLogDatabaseName = "ApplicationLog";
        public const string ExceptionLogCollectionName = "ExceptionLog";

        public const string OrdersDatabaseName = "Orders";
        public const string OrderLinesCollectionName = "OrderLines";
    }
}
