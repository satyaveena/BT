﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Models
{
    public class LineItemInput
    {
        public string BTKey { get; set; }
        public int Quantity { get; set; }
        public string Note { get; set; }
        public List<GridInput> Grids { get; set; }
        public RankingInput Ranking { get; set; }
    }

    public class GridInput
    {
        public int Quantity { get; set; }
        public string AgencyCode { get; set; }
        public string AgencyId { get; set; }
        public string ItemTypeCode { get; set; }
        public string ItemTypeId { get; set; }
        public string CollectionCode { get; set; }
        public string CollectionId { get; set; }
        public string CallNumberText { get; set; }
        public string UserCode1Code { get; set; }
        public string UserCode1Id { get; set; }
        public string UserCode2Code { get; set; }
        public string UserCode2Id { get; set; }
        public string UserCode3Code { get; set; }
        public string UserCode3Id { get; set; }
        public string UserCode4Code { get; set; }
        public string UserCode4Id { get; set; }
        public string UserCode5Code { get; set; }
        public string UserCode5Id { get; set; }
        public string UserCode6Code { get; set; }
        public string UserCode6Id { get; set; }
    } 

    public class RankingInput
    {
        public string Overall { get; set; }
        public string Genre_Score { get; set; }
        public string Genre_Score_Description { get; set; }
        public string Detail_URL { get; set; }
        public int DetailHeight { get; set; }
        public int DetailWidth { get; set; }
        public string OveralScoreType { get; set; }

    }
}
