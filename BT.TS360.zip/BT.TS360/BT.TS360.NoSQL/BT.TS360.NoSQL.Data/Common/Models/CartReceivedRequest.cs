﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.Data.Common.Models
{
    public class CartReceivedRequest
    {
        public string ESPLibraryId { get; set; }
        public string ETSCartId { get; set; }
        public string CartName { get; set; }
        public string CartNote { get; set; }
        public string UserId { get; set; }
        public List<LineItemInput> Items { get; set; }
    }
}