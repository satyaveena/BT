﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Models
{
    public class InsertedCartResult
    {
        public List<CartResult> Carts { get; set; }
        public List<ErrorItem> ErrorItems { get; set; }
    }

    public class CartResult
    {
        public string CartName { get; set; }
        public string CartUrl { get; set; }
    }

    public class ErrorItem
    {
        public string BTKey { get; set; }
        public string Message { get; set; }
    }
}
