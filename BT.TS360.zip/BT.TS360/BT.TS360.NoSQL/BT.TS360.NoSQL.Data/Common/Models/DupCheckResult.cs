﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Models
{
    public class DupCheckResult
    {
        public List<ProductDupCheckStatus> Items { get; set; }
        public List<ErrorItem> ErrorItems { get; set; }
    }
    public class ProductDupCheckStatus
    {
        public string BTKey { get; set; }
        public string DupCheckStatus { get; set; }
    }

    public class DupCheckDataResult
    {
        public DataSet Data { get; set; }
        public string OrgId { get; set; }
        public string SeriesDupeCheckType { get; set; }
        public DupCheckResult DupCheckResult { get; set; }
    }

}
