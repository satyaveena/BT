﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.Data.Common.Models
{
    [DataContract]
    public class BatchExportResponse
    {
        [DataMember]
        public List<ChangeRequests> ChangeRequestList { get; set; }


        [DataMember]
        public long TotalItems { get; set; }
    }

    [DataContract]
    public class BatchExportRealtimeResponse
    {
        [DataMember]
        public string FileContent { get; set; }

        [DataMember]
        public string FileName { get; set; }
    }
}
