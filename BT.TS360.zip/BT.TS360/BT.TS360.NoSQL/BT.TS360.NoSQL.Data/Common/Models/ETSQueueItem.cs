﻿
using MongoDB.Bson.Serialization.Attributes;
namespace BT.TS360.NoSQL.Data.Common.Models
{
    [BsonIgnoreExtraElements]

    public class ETSQueueItem : QueueItem
    {
        [BsonIgnoreIfNull]
        public DupCheckRequest DupCheckRequest { get; set; }
        [BsonIgnoreIfNull]
        public DupCheckResult DupCheckResponse { get; set; }
        [BsonIgnoreIfNull]
        public PricingRequest PricingRequest { get; set; }
        [BsonIgnoreIfNull]
        public ProductPricingResult PricingResponse { get; set; }
        [BsonIgnoreIfNull]
        public CartReceivedRequest CartReceivedRequest { get; set; }
        [BsonIgnoreIfNull]
        public InsertedCartResult CartReceivedResponse { get; set; }
        [BsonIgnoreIfNull]
        public string StatusMessage { get; set; }
        [BsonIgnoreIfNull]
        public string StatusCode { get; set; }
    }
}