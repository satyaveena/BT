﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Data.Common.Models
{
    public class NoSqlDataResponse<T>
    {
        public long TotalItems { get; set; }

        public List<T> ItemList { get; set; }
    }
}
