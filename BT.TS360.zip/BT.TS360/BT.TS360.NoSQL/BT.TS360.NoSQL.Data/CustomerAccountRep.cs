﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.Data
{
     [BsonIgnoreExtraElements]
    public class CustomerAccountRep
    {
        [BsonId]
        public ObjectId SalesID { get; set; }

        [BsonIgnoreIfNull]
        public string SalesName { get; set; }

        [BsonIgnoreIfNull]
        public string SalesPhone { get; set; }

        [BsonIgnoreIfNull]
        public string SalesEmail { get; set; }

        [BsonIgnoreIfNull]
        public string SalesTerritory { get; set; }

        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
    }
}
