﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace BT.TS360.NoSQL.Data
{
    [BsonIgnoreExtraElements]
    public class BackgroundQueue
    {
        [BsonId]
        [BsonIgnoreIfDefault]
        public ObjectId BackgroundQueueID { get; set; }
        [BsonIgnoreIfNull]
        public int Priority { get; set; }
        [BsonIgnoreIfNull]
        public string InProcessState { get; set; }
        [BsonIgnoreIfNull]
        public string JobType { get; set; }
        [BsonIgnoreIfNull]
        public FootprintInformation FootprintInformation { get; set; }
        [BsonIgnoreIfNull]
        public EmailSettings EmailSettings { get; set; }
        [BsonIgnoreIfNull]
        public ReportSettings ReportSettings { get; set; }

    }


    [BsonIgnoreExtraElements]
    public class EmailSettings  
    {
        [BsonIgnoreIfNull]
        public string To { get; set; }
        [BsonIgnoreIfNull]
        public string Subject { get; set; } 
        [BsonIgnoreIfNull]
        public string Note { get; set; }
        [BsonIgnoreIfNull]
        public bool CompressFile { get; set; }

        [BsonIgnoreIfNull]
        public EmailElements EmailElements { get; set; }

    }

    [BsonIgnoreExtraElements]
    public class EmailElements
    {
        
        [BsonIgnoreIfDefault]
        [BsonIgnoreIfNull]
        public ObjectId ProfileID { get; set; }
        [BsonIgnoreIfNull]
        public string OrganizationID { get; set; }
        [BsonIgnoreIfNull]
        public string ProfileName { get; set; }
        [BsonIgnoreIfNull]
        public string AccountNumber { get; set; }

        [BsonIgnoreIfNull]
        public string OrganizationName { get; set; }

    }


    [BsonIgnoreExtraElements]
    public class ReportSettings
    {
        [BsonIgnoreIfNull]
        public string OrgName { get; set; }

        [BsonIgnoreIfNull]
        public string OrgID { get; set; }
        [BsonIgnoreIfNull]
        public string UserID { get; set; }
        [BsonIgnoreIfNull]
        public string UserName { get; set; }
        [BsonIgnoreIfDefault]
        public ObjectId ProfileID { get; set; }
        [BsonIgnoreIfNull]
        public string ReportType { get; set; }

        [BsonIgnoreIfNull]
        public OrderSearchLinesRequest OrderSearchLinesRequestDetails { get; set; }
    }
    
    [BsonIgnoreExtraElements]
    public class OrderLineRequest
    {
        [BsonIgnoreIfNull]
        public List<string> AccountNumbers { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ArtistAuthors { get; set; }
        [BsonIgnoreIfNull]
        public List<string> BTOrderNumbers { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ISBNs { get; set; }
        [BsonIgnoreIfNull]
        public List<string> ISBNsOrUPCs { get; set; }
        [BsonIgnoreIfNull]
        public DateRange OrderDateRange { get; set; }
        [BsonIgnoreIfNull]
        public string POOrder { get; set; }//CustomerPONumber
        [BsonIgnoreIfNull]
        public DateRange PubDateRanges { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Titles { get; set; }
        [BsonIgnoreIfNull]
        public List<string> CustomerItemNumbers { get; set; }
        [BsonIgnoreIfNull]
        public List<string> UPC { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Formats { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Warehouses { get; set; }
        [BsonIgnoreIfNull]
        public string POLine { get; set; } //?
        [BsonIgnoreIfNull]
        public List<string> CustomerPONumber { get; set; }
        [BsonIgnoreIfNull]
        public List<string> Statuses { get; set; }
        [BsonIgnoreIfNull]
        public int ViewPoOption { get; set; }

    }
    
    [BsonIgnoreExtraElements]
    public class DateRange
    {
        [BsonIgnoreIfNull]
        public string FromDate { get; set; }
        [BsonIgnoreIfNull]
        public string ToDate { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class OrderSearchLinesRequest : OrderLineRequest
    {
        public string SortBy { get; set; }
        public string SortByDirection { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
    }


}




