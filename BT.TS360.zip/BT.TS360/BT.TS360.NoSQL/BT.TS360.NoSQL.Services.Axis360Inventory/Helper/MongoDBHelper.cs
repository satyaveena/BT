﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using System.Threading;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Axis360;

namespace BT.TS360.NoSQL.Services.Axis360Inventory.Helper
{
    class MongoDBHelper
    {
        IMongoClient _client;
        IMongoDatabase _databaseAxis360;
        IMongoCollection<Data.Axis360.Axis360Inventory> _axis360Inventory;

        int retryWaitTime = AppSettings.RetryWaitTime;
        int inventoryBatchSize = AppSettings.InventoryBatchSize;

        public MongoDBHelper()
        {
            string connection = AppSettings.MongoDBConnectionString;
            _client = new MongoClient(connection);
            _databaseAxis360 = _client.GetDatabase(AppSettings.DatabaseNameAxis360);
            _axis360Inventory = _databaseAxis360.GetCollection<Data.Axis360.Axis360Inventory>(AppSettings.Axis360InventoryCollectionName);
        }

        public async Task<List<Data.Axis360.Axis360Inventory>> GetAxis360InventoryNeedsCrawl()
        {
            int retries = AppSettings.MaxConnectionRetries;
            var response = new List<Data.Axis360.Axis360Inventory>();
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<Data.Axis360.Axis360Inventory>.Filter.Eq("NeedsCrawl", true);
                    response = await _axis360Inventory.Find<Data.Axis360.Axis360Inventory>(filter).Limit(inventoryBatchSize).ToListAsync();

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
            return response;
        }

        internal async Task UpdateAxis360InventoryCrawlFlag(List<Data.Axis360.Axis360Inventory> inventory)
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<Data.Axis360.Axis360Inventory>.Filter.In("_id", inventory.Select(x => x.ID).ToList());
                    var update = Builders<Data.Axis360.Axis360Inventory>.Update.Unset("NeedsCrawl");
                    var response = await _axis360Inventory.UpdateManyAsync(filter, update);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }

        internal async Task SetInventory(List<Data.Axis360.Axis360Inventory> addedInventory)
        {
            var updateModelsList = new List<UpdateOneModel<Data.Axis360.Axis360Inventory>>();
            var now = DateTime.Now;
            foreach (var inventory in addedInventory)
            {
                var updateOneModel = new UpdateOneModel<Data.Axis360.Axis360Inventory>(
                    Builders<Data.Axis360.Axis360Inventory>.Filter.Eq("ISBN", inventory.ISBN) & Builders<Data.Axis360.Axis360Inventory>.Filter.Eq("CustomerID", inventory.CustomerID),
                    Builders<Data.Axis360.Axis360Inventory>.Update.Set("LibraryPrefix", inventory.LibraryPrefix)
                           .Set("MyQuantity", inventory.MyQuantity)
                           .Set("ParentQuantity", inventory.ParentQuantity)
                           .Set("State", inventory.State)
                           .Set("TotalQuantity", inventory.TotalQuantity)
                           .Set("UpdateDate", inventory.UpdateDate)
                           .Set("AddedDate", inventory.AddedDate)
                           .Set("LibraryID", inventory.LibraryID)
                           .Set("FootprintInformation.UpdatedBy", "Axis360InventoryService")
                           .Set("FootprintInformation.UpdatedDate", now)
                           .SetOnInsert("FootprintInformation.CreatedBy", "Axis360InventoryService")
                           .SetOnInsert("FootprintInformation.CreatedDate", now)
                           .SetOnInsert("ISBN", inventory.ISBN)
                           .SetOnInsert("CustomerID", inventory.CustomerID));
                updateOneModel.IsUpsert = true;
                updateModelsList.Add(updateOneModel);

            }
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {

                    var response = await _axis360Inventory.BulkWriteAsync(updateModelsList);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }
    }

    
}
