﻿
using System.Configuration;

namespace BT.TS360.NoSQL.Services.Lists
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Axis360InventoryServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.Axis360InventoryServiceInstaller = new System.ServiceProcess.ServiceInstaller();

            this.Axis360InventoryServiceProcessInstaller.Password = null;
            this.Axis360InventoryServiceProcessInstaller.Username = null;

            this.Axis360InventoryServiceInstaller.DisplayName = ServiceName;
            this.Axis360InventoryServiceInstaller.ServiceName = DisplayName;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.Axis360InventoryServiceProcessInstaller,
            this.Axis360InventoryServiceInstaller});
        }

        #endregion

        private string ServiceName
        {
            get
            {
                return (ConfigurationManager.AppSettings["ServiceName"] == null ? "TS360Axis360InventoryService" : ConfigurationManager.AppSettings["ServiceName"].ToString());
            }
        }

        private string DisplayName
        {
            get
            {
                return (ConfigurationManager.AppSettings["DisplayName"] == null ? "TS360Axis360InventoryService" : ConfigurationManager.AppSettings["DisplayName"].ToString());
            }
        }

        private System.ServiceProcess.ServiceProcessInstaller Axis360InventoryServiceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller Axis360InventoryServiceInstaller;
    }
}