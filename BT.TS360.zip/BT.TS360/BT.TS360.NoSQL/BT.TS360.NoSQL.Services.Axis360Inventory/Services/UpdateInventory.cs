﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using BT.TS360.NoSQL.Services.Lists;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Services.Axis360Inventory.Helper;
using BT.TS360.NoSQL.Data;
using BTNextGen.Elmah;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Collections.Concurrent;
using System.Net;
using System.Data;
using System.Data.OleDb;
using Microsoft.WindowsAPICodePack.Shell;
using Microsoft.WindowsAPICodePack.Shell.PropertySystem;
using BT.TS360.NoSQL.Data.DAL;

namespace BT.TS360.NoSQL.Services.Axis360Inventory.Services
{
    class UpdateInventory
    {
        ThreadedLogger _threadedLogger;
        static Emailer _emailer;
        ExceptionLogger _exceptionLogger;
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        public async Task Main(string lastRunDateString)
        {
            DateTime lastRunDate;
            DateTime.TryParse(lastRunDateString, out lastRunDate);
            _exceptionLogger = new ExceptionLogger(AppSettings.ExceptionLoggingConnectionString);
            try
            {
                _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix);
                _threadedLogger.Write("Start Main", FileLoggingLevel.INFO);
                _emailer = new Emailer(AppSettings.EmailSMTPServer);
                if (!string.IsNullOrEmpty(AppSettings.GetInventoryFromAxis) && string.Equals(AppSettings.GetInventoryFromAxis, "true", StringComparison.OrdinalIgnoreCase))
                {
                    if (!string.IsNullOrEmpty(AppSettings.GetFullInventory) && string.Equals(AppSettings.GetFullInventory, "true", StringComparison.OrdinalIgnoreCase))
                    {
                        lastRunDate = DateTime.MinValue;
                    }
                    _threadedLogger.Write("Begin GetInventoryFromAxis", FileLoggingLevel.INFO);
                    var accessToken = await Axis360InventoryHelper.GetAccessToken();
                    var pageToken = "";
                    var batchSize = AppSettings.AxisBatchSize;
                    var totalInventoryRecords = 0;
                    if (accessToken != null && !string.IsNullOrWhiteSpace(accessToken.AccessValue))
                    {
                        do
                        {
                            var inventoryResponse = await Axis360InventoryHelper.GetAxis360InventoryByDate(lastRunDate, accessToken.AccessValue, pageToken, batchSize);
                            if (inventoryResponse != null && inventoryResponse.Status != null)
                            {
                                if (string.Equals(inventoryResponse.Status.Code, "0000", StringComparison.OrdinalIgnoreCase) && inventoryResponse.LibraryInventoryList != null && inventoryResponse.LibraryInventoryList.Any())
                                {
                                    await mongoDBHelper.SetInventory(inventoryResponse.LibraryInventoryList);
                                    pageToken = inventoryResponse.PageToken;
                                    totalInventoryRecords += inventoryResponse.LibraryInventoryList.Count();
                                    _threadedLogger.Write("Updated " + inventoryResponse.LibraryInventoryList.Count() + " inventory records and a total of " + totalInventoryRecords + " inventory records. Next pageToken:" + pageToken, FileLoggingLevel.INFO);
                                }
                                else
                                {
                                    pageToken = "";
                                    _threadedLogger.Write("GetInventoryResponse Code: " + inventoryResponse.Status.Code + " & Message: " + inventoryResponse.Status.Message, FileLoggingLevel.INFO);
                                }
                            }
                            else
                            {
                                pageToken = "";
                                _threadedLogger.Write("Error with response Response or Status is null", FileLoggingLevel.ERROR);
                            }
                        }
                        while (!string.IsNullOrWhiteSpace(pageToken));
                    }
                    _threadedLogger.Write("Updated a total of " + totalInventoryRecords + " inventory records", FileLoggingLevel.INFO);
                    _threadedLogger.Write("End GetInventoryFromAxis", FileLoggingLevel.INFO);
                }
                _threadedLogger.Write("End Main", FileLoggingLevel.INFO);
            }
            catch (Exception exception)
            {
                _threadedLogger.Write(exception.Message, FileLoggingLevel.ERROR);
                _exceptionLogger.LogError(exception, "Axis360InventoryService", "Main");
            }
        }
    }
}