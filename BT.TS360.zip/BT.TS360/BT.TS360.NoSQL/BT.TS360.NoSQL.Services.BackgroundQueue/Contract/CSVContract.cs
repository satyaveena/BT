﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Contract
{
    public class CSVData
    {
        public string OrganId { get; set; }
        public string TechnicalCenterId { get; set; }
        public string RegionId { get; set; }
        public string BranchId { get; set; }
        public string SeriesID { get; set; }
        public string SeriesName { get; set; }
        public string Quantity  { get; set; }
        public string CustOrderNo  { get; set; }
        public string StartCode  { get; set; }
        public string StartDate  { get; set; }
        public string Cycle  { get; set; } 
        public string Binding1 { get; set; }
        public string Preference1 { get; set; }
        public string PB_Qty1 { get; set; }
        public string Binding2 { get; set; }
        public string Preference2 { get; set; }
        public string PB_Qty2 { get; set; }
        public string SpecialInstructions  { get; set; }
    }
}
