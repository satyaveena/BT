﻿using System;
using System.IO;
using System.Configuration;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Common
{
    public class Logging
    {
        public void WriteLog(string Message)
        {
            StreamWriter sw = null;

            try
            {
                string sPathName = AppSettings.ErrorLogLocation;
                string sNow = string.Format("{0:yyyy-MM-dd hh:mm:ss tt}", DateTime.Now);
                string sLogFormat = sNow + " ==> ";
                string sToday = string.Format("{0:yyyy-MM-dd}", DateTime.Now);

                sw = new StreamWriter(sPathName + sToday + ".txt", true);

                sw.WriteLine(sLogFormat + Message);
                sw.Flush();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sw != null)
                {
                    sw.Dispose();
                    sw.Close();
                }
            }
        }
    }
}

