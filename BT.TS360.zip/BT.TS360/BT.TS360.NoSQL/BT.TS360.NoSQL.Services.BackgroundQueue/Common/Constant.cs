﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Common
{
    public static class Constant
    {
        //Common Constant
        public static string APPLICATION_NAME = "TS360BackgroundQueue";
        public static string UPDATED_USER_NAME = "BackgroundQueueService";

        //Log
        public static string START_SERVICE = "Start Background Queue service.";
        public static string STOP_SERVICE = "Stop Background Queue service.";
        public static string ON_START_FUNCTION = "On Start";
        public static string ON_STOP_FUNCTION = "On Stop";
        public static string BATCH_EXPORT_REQUESTS_COMPLETED = "Completed to get Batch Export requests.";
        public static string BATCH_EXPORT_REQUESTS_NO_ITEM = "There is no Batch Export requests.";
        public static string CHANGE_REQUESTS_GET_COMPLETED = "Completed to get Change Requests.";
        public static string CHANGE_REQUESTS_NO_ITEM = "There is no Change Requests.";
        public static string CHANGE_REQUESTS_UPDATE_COMPLETED = "Completed to update Change Requests.";
        public static string BACKGROUND_QUEUE_UPDATE_COMPLETED = "Completed to update Background Queue.";
        public static string FILL_DATA_TO_CSV_COMPLETED = "Completed to fill data to CSV.";
        public static string EXCEPTION_SEND_MAIL = "Exception mail sent.";
        public static string SEND_MAIL_ATTACHMENT = "Mail attachment sent.";
    }
}
