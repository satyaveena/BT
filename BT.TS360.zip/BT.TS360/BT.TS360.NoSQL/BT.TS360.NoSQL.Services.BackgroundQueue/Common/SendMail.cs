﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Configuration;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Common
{
    public class SendMail
    {
        static Logging log = new Logging();
        static string from = AppSettings.EmailFrom;
        static MailAddress emailFrom = new MailAddress(from);

        public static void SendEmailExceptionGeneric(string exceptionMessage, string methodName)
        {
            try
            {
                    string emailToList = AppSettings.EmailTo;                    

                    MailMessage mail = new MailMessage();
                    mail.From = emailFrom;

                    if (emailToList.Contains(';'))
                    {
                        var email_ToList = emailToList.Split(';');
                        foreach (var emailTo in email_ToList)
                        {
                            if (!string.IsNullOrEmpty(emailTo))
                                mail.To.Add(emailTo);
                        }
                    }
                    else
                        mail.To.Add(emailToList);

                    mail.Subject = AppSettings.Environment + " - " + methodName;
                    mail.Priority = MailPriority.High;

                    mail.Body = exceptionMessage;

                    SmtpClient client = new SmtpClient(AppSettings.EmailSMTPServer);
                    client.UseDefaultCredentials = true;
                    client.Send(mail);
                    log.WriteLog(Constant.EXCEPTION_SEND_MAIL);
            }
            catch (Exception ex)
            {
                log.WriteLog("Exception from send mail exception: " + ex.Message);
                throw ex;
            }
        }

        public static void SendEmailAttachment(string emailToList, string emailCCList, string emailSubject, string emailBody, Attachment attachment)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = emailFrom;

                if (emailToList.Contains(';'))
                {
                    var email_ToList = emailToList.Split(';');
                    foreach (var emailTo in email_ToList)
                    {
                        if (!string.IsNullOrEmpty(emailTo))
                            mail.To.Add(emailTo);
                    }
                }
                else
                    mail.To.Add(emailToList);

                mail.IsBodyHtml = true;

                if (emailCCList.Contains(';'))
                {
                    var email_CCList = emailCCList.Split(';');
                    foreach (var emailCC in email_CCList)
                    {
                        if (!string.IsNullOrEmpty(emailCC))
                            mail.CC.Add(emailCC);
                    }
                }
                else
                    mail.CC.Add(emailCCList);


                mail.Subject = emailSubject;
                mail.Body = emailBody;
                mail.Attachments.Add(attachment);
               
                SmtpClient client = new SmtpClient(AppSettings.EmailSMTPServer);
                client.UseDefaultCredentials = true;            
                client.Send(mail);                
            }
            catch (Exception ex)
            {
                log.WriteLog("Exception from send mail attachment: " + ex.Message);
                throw ex;
            }
        }
    }
}
