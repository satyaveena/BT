﻿using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.DAM;
using BT.TS360.NoSQL.Data.Common.Models;
using BT.TS360.NoSQL.Services.BackgroundQueue.Common;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Helper
{
    class MongoHelper
    {
        IMongoClient _client;
        IMongoDatabase _dbCommon;
        IMongoCollection<Data.BackgroundQueue> _backgroundQueue;
        IMongoDatabase _dbStandingOrders;
        IMongoCollection<ChangeRequests> _changeRequests;

        ChangeRequestManager changeRequestManager = new ChangeRequestManager();
        
        int sleepDuration = AppSettings.MongoRetrySleepDuration;
        static Logging log = new Logging();

        public MongoHelper()
        {
            string connection = AppSettings.MongoDBConnectionString;
            _client = new MongoClient(connection);

            _dbCommon = _client.GetDatabase(AppSettings.MongoDBCommon);
            _backgroundQueue = _dbCommon.GetCollection<Data.BackgroundQueue>(AppSettings.MongoBackgroundQueueCollection);

            _dbStandingOrders = _client.GetDatabase(AppSettings.MongoDBStandingOrders);
            _changeRequests = _dbStandingOrders.GetCollection<ChangeRequests>(AppSettings.MongoChangeRequestCollection);
        }

        public async Task<List<Data.BackgroundQueue>> GetBatchExportRequest()
        {
            var response = new List<Data.BackgroundQueue>();
            int retries = AppSettings.MongoRetryCount;
            while (retries > 0)
            {
                try
                {
                    var builder = Builders<Data.BackgroundQueue>.Filter;
                    var filter = builder.Eq("JobType", "BatchExport") & builder.Eq("InProcessState", "New");
                    response = await _backgroundQueue.Find<Data.BackgroundQueue>(filter).ToListAsync<Data.BackgroundQueue>();
                    log.WriteLog(Constant.BATCH_EXPORT_REQUESTS_COMPLETED);
                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(sleepDuration);
                    if (retries < 1)
                    {
                        response = null;
                        log.WriteLog("Exception from Get Batch Export Request: " + ex.Message);
                        throw ex;
                    }
                }
            }
            return response;
        }

        public async Task<BatchExportResponse> RequestStatusBatchExport(ObjectId profileID, string orgID)
        {
            var data = await changeRequestManager.RequestStatusBatchExport(_changeRequests, orgID, profileID, Constant.UPDATED_USER_NAME, "", sleepDuration, AppSettings.MongoRetryCount);
            return data;
        }

        public async Task<List<ChangeRequests>> GetChangeRequest(ObjectId profileID)
        {
            int retries = AppSettings.MongoRetryCount;
            var response = new List<ChangeRequests>();
            while (retries > 0)
            {
                try
                {
                    var builder = Builders<ChangeRequests>.Filter;
                    var filter = builder.Eq("ProfileID", ObjectId.Parse(profileID.ToString())) &
                                    builder.Eq("RequestStatus", "New") &
                                    builder.Eq("RequestType", "Add") &
                                    builder.Eq("ChangeRequestType", "ProfiledSeries");
                    response = await _changeRequests.Find<ChangeRequests>(filter).ToListAsync<ChangeRequests>();
                    log.WriteLog(Constant.CHANGE_REQUESTS_GET_COMPLETED);
                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(sleepDuration);
                    if (retries < 1)
                    {
                        response = null;
                        throw ex;
                    }
                }
            }
            return response;
        }

        public async Task UpdateChangeRequest(ChangeRequests request)
        {
            int retries = AppSettings.MongoRetryCount;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<ChangeRequests>.Filter.Eq("_id", request.ChangeRequestID);
                    var update = Builders<ChangeRequests>.Update.Set("RequestStatus", "Completed").Set("FootprintInformation.UpdatedBy", "BackgroundQueueService").Set("FootprintInformation.UpdatedDate", DateTime.Now);
                    var result = await _changeRequests.UpdateManyAsync(filter, update);
                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(sleepDuration);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }
        }

        public async Task UpdateBackgroundQueue(Data.BackgroundQueue request)
        {
            int retries = AppSettings.MongoRetryCount;
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<Data.BackgroundQueue>.Filter.Eq("_id", request.BackgroundQueueID);
                    var update = Builders<Data.BackgroundQueue>.Update.Set("InProcessState", "Success").Set("FootprintInformation.UpdatedBy", Constant.UPDATED_USER_NAME).Set("FootprintInformation.UpdatedDate", DateTime.Now);
                    var result = await _backgroundQueue.UpdateManyAsync(filter, update);
                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(sleepDuration);
                    if (retries < 1)
                    {
                        log.WriteLog("Exception from Update Background Queue: " + ex.Message);
                        throw ex;
                    }
                }
            }
        }
    }
}
