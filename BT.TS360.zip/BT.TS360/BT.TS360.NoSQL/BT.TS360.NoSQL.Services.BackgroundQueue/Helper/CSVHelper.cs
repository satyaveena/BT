﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data;
using System.IO;
using BT.TS360.NoSQL.Services.BackgroundQueue.Contract;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Helper
{
    class CSVHelper
    {
        private string delimiter = ",";

        public List<string> GetCSVHeader()
        {
            var csvHeader = new List<string>()
            {
                "OrganId",
                "TechnicalCenterId",
                "RegionId",
                "BranchId",
                "SeriesID",
                "Series Name",
                "Quantity",
                "CustOrderNo",
                "Start_code",
                "StartDate",
                "Cycle",
                "Binding #1",
                "Preference #1",
                "PBi_Qty #1",
                "Binding  #2",
                "Preference #2",
                "PB_Qty #2",
                "Special Instructions"
            };
            return csvHeader;
        }

        public List<string> GetCSVRowData(EmailElements emailElements, ChangeRequests request)
        {
            CSVData data = new CSVData();

            string accountNumber = emailElements.AccountNumber;

            if (!String.IsNullOrEmpty(accountNumber))
            {
                data.OrganId = accountNumber.Substring(0, 6);
                data.TechnicalCenterId = accountNumber.Substring(6, 7);
                data.RegionId = accountNumber.Substring(13, 1);
                data.BranchId = accountNumber.Substring(14, 6);
            }

            var profiledSeriesChangeRequest = request.ProfiledSeriesChangeRequest;
            if (profiledSeriesChangeRequest != null)
            {
                data.SeriesID = profiledSeriesChangeRequest.SeriesID;
                data.SpecialInstructions = profiledSeriesChangeRequest.SpecialInstruction;
            }

            var redundantSeriesInformation = request.RedundantSeriesInformation;
            if (redundantSeriesInformation != null)
                    data.SeriesName = redundantSeriesInformation.Name;
            
            var purchaseOrders = profiledSeriesChangeRequest.PurchaseOrders;
            if (purchaseOrders != null && purchaseOrders[0] != null)
            {
                var PO = purchaseOrders[0];
                data.CustOrderNo = PO.POLineNumber;
                data.StartCode = "D";

                if (PO.StartNextAvailableTitle && string.IsNullOrEmpty(PO.StartDate))
                {
                    data.StartDate = "Next";
                }
                else
                {
                    DateTime dt;
                    if (DateTime.TryParseExact(PO.StartDate, "MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt))
                    {
                        data.StartDate = dt.ToString("yyyy/MM");
                    }
                    else
                    {
                        data.StartDate = PO.StartDate;
                    }
                }

                data.Cycle = PO.ShippingPreference;
                if (!string.IsNullOrEmpty(PO.FormatPreferencePrimary))
                {
                    data.Quantity = string.Empty;
                    data.Binding1 = PO.FormatPreferencePrimary;
                    data.Preference1 = "1st";
                    data.PB_Qty1 = PO.FormatPreferencePrimaryQuantity.ToString();
                    if (!string.IsNullOrEmpty(PO.FormatPreferenceSecondary) && PO.FormatPreferenceSecondary != "null")
                    {
                        data.Binding2 = PO.FormatPreferenceSecondary;
                        data.Preference2 = "2nd";
                        data.PB_Qty2 = PO.FormatPreferenceSecondaryQuantity.ToString();
                    }
                    else
                    {
                        data.Binding2 = string.Empty;
                        data.Preference2 = string.Empty;
                        data.PB_Qty2 = string.Empty;
                    }
                }
                else
                {
                    data.Quantity = PO.FormatPreferencePrimaryQuantity.ToString();
                    data.Binding1 = string.Empty;
                    data.Preference1 = string.Empty;
                    data.PB_Qty1 = string.Empty;
                    data.Binding2 = string.Empty;
                    data.Preference2 = string.Empty;
                    data.PB_Qty2 = string.Empty;
                }
            }

            var csvRowData = new List<string>
            {
                data.OrganId,
                data.TechnicalCenterId,
                data.RegionId,
                data.BranchId,
                data.SeriesID,
                data.SeriesName,
                data.Quantity,
                data.CustOrderNo,
                data.StartCode,
                data.StartDate,
                data.Cycle,
                data.Binding1,
                data.Preference1,
                data.PB_Qty1,
                data.Binding2,
                data.Preference2,
                data.PB_Qty2,
                data.SpecialInstructions
            };

            return csvRowData;
        }

        public string FillDataToCSV(string userName, EmailElements emailElements, List<string> csvHeader, List<List<string>> csvData)
        {
            var firstNameInitial = string.Empty;
            var lastNameInitial = string.Empty;

            if (!String.IsNullOrEmpty(userName))
            {
                var firstLastName = userName.Split(' ');
                firstNameInitial = firstLastName[0].Substring(0, 1);
                if (firstLastName.Count() > 1)
                    lastNameInitial = firstLastName[1].Substring(0, 1);
            }

            string fileName = firstNameInitial.ToUpper() + lastNameInitial.ToUpper() + "_" +
                                emailElements.AccountNumber + "_" +
                                DateTime.Now.Date.ToString("MMddyyyy") + "_" +
                                emailElements.ProfileName.Split(' ').First() + ".csv";

            string path = WriteToFile(fileName, csvHeader, csvData);
            return path;
        }

        public string WriteToFile(string fileName, List<string> csvHeader, List<List<string>> csvData)
        {
            string location = AppSettings.CSVLocation;
            if (!Directory.Exists(location))
                throw new DirectoryNotFoundException("CSV Location is not found: " + location);

            string path = Path.Combine(location, fileName);

            StringBuilder sb = new StringBuilder();
            WriteCSVHeader(sb, csvHeader);
            foreach (var csvRowData in csvData)
            {
                WriteCSVData(sb, csvRowData);
            }
            File.WriteAllText(path, sb.ToString());
            return path;
        }

        private void WriteCSVHeader(StringBuilder sb, List<string> csvHeader)
        {
            var header = new List<string>();

            foreach (var column in csvHeader)
            {
                header.Add(column);
            }
            sb.AppendLine(string.Join(delimiter, header));
        }

        public void WriteCSVData(StringBuilder sb, List<string> csvRowData)
        {
            var body = new List<string>();

            foreach (var data in csvRowData)
            {
                if (!string.IsNullOrEmpty(data))
                {
                    if (data.Contains(","))
                    {
                        sb.AppendFormat("\"{0}\",", data);
                    }
                    else
                    {
                        sb.AppendFormat("=\"" + data + "\"");
                        sb.AppendFormat(",");
                    }
                }
                else
                    sb.AppendFormat("{0},", string.Empty);
            }
            sb.Append(Environment.NewLine);
        }
    }
}
