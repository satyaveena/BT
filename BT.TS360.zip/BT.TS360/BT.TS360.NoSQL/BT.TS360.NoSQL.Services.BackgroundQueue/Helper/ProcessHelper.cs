﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Services.BackgroundQueue.Common;
using System.IO;
using System.Net.Mail;

namespace BT.TS360.NoSQL.Services.BackgroundQueue.Helper
{
    class ProcessHelper
    {
        ExceptionLogger _exceptionLogger = new ExceptionLogger(AppSettings.ExceptionLoggingConnectionString);
        MongoHelper mongoHelper = new MongoHelper();
        CSVHelper csvHelper = new CSVHelper();
        static Logging log = new Logging();

        public ProcessHelper()
        {}

        public async Task StartProcess()
        {
            try
            {
                var listRequest = await mongoHelper.GetBatchExportRequest();

                if (listRequest != null && listRequest.Count > 0)
                {
                    foreach (var item in listRequest)
                    {
                        var emailSettings = item.EmailSettings;
                        var emailElements = emailSettings.EmailElements;
                        var userName = item.FootprintInformation.CreatedBy;

                        if (emailSettings != null && emailElements != null)
                        {
                            var changeRequest = await mongoHelper.RequestStatusBatchExport(emailElements.ProfileID, emailElements.OrganizationID);
                            if (changeRequest != null && changeRequest.ChangeRequestList != null && changeRequest.TotalItems > 0)
                            {
                                List<string> csvHeader = new List<string>();
                                List<List<string>> csvData = new List<List<string>>();
                                List<string> csvRowData = new List<string>();

                                foreach (var request in changeRequest.ChangeRequestList)
                                {
                                    csvRowData = csvHelper.GetCSVRowData(emailElements, request);
                                    csvData.Add(csvRowData);
                                }
                                csvHeader = csvHelper.GetCSVHeader();

                                log.WriteLog(Constant.CHANGE_REQUESTS_UPDATE_COMPLETED);

                                //Fill data to CSV
                                string path = csvHelper.FillDataToCSV(userName, emailElements, csvHeader, csvData);
                                log.WriteLog(Constant.FILL_DATA_TO_CSV_COMPLETED);

                                //Update background queue
                                await mongoHelper.UpdateBackgroundQueue(item);
                                log.WriteLog(Constant.BACKGROUND_QUEUE_UPDATE_COMPLETED);

                                //Send mail with CSV
                                var emailBody = GenerateEmailBody(emailElements, userName);
                                var attachment = new Attachment(path);
                                SendMail.SendEmailAttachment(emailSettings.To, AppSettings.EmailBT, emailSettings.Subject, emailBody, attachment);
                                log.WriteLog(Constant.SEND_MAIL_ATTACHMENT);
                            }
                            else
                                log.WriteLog(Constant.CHANGE_REQUESTS_NO_ITEM);
                        }
                    }
                }
                else
                    log.WriteLog(Constant.BATCH_EXPORT_REQUESTS_NO_ITEM);
            }
            catch (Exception ex)
            {
                //log in DB
                _exceptionLogger.LogError(ex, Constant.APPLICATION_NAME, Constant.ON_START_FUNCTION);

                //send mail for exception and log to location
                SendMail.SendEmailExceptionGeneric(ex.Message, Constant.ON_START_FUNCTION);
            }
        }

        public string GenerateEmailBody(EmailElements element, string userName)
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Format("<div>Hello {0},</div><br>", userName));
            sb.AppendLine(string.Format("<div><span>Please see the attached batch export for </span><span style='font-weight:bold' > {0} ({1})</span></div><br><br>", element.ProfileName, element.AccountNumber));
            sb.AppendLine(string.Format("<div>Regards,</div><br>"));
            sb.AppendLine(string.Format("<div>Baker & Taylor Team</div>"));            
            return sb.ToString();
        }

        
    }
}
