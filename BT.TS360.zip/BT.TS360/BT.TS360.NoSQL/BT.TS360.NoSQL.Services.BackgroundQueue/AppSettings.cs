﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BT.TS360.NoSQL.Services.BackgroundQueue
{
    public class AppSettings
    {
        #region MailSettings

        public static string EmailFrom
        {
            get { return ConfigurationManager.AppSettings["EmailFrom"].ToString(); }
        }

        public static string EmailTo
        {
            get { return ConfigurationManager.AppSettings["EmailTo"].ToString(); }
        }

        public static string EmailSMTPServer
        {
            get { return ConfigurationManager.AppSettings["EmailSMTPServer"].ToString(); }
        }

        public static string EmailBT
        {
            get { return ConfigurationManager.AppSettings["EmailBT"].ToString(); }
        }

        #endregion

        #region LoggingSettings

        public static string ExceptionLoggingConnectionString
        {
            get { return ConfigurationManager.AppSettings["ExceptionLoggingConnectionString"].ToString(); }
        }

        public static string ErrorLogLocation
        {
            get { return ConfigurationManager.AppSettings["ErrorLogLocation"].ToString(); }
        }

        #endregion LoggingSettings

        #region CommonSettings

        public static string Environment
        {
            get { return ConfigurationManager.AppSettings["Environment"].ToString(); }
        }

        public static string TimeIntervalToCheck
        {
            get { return ConfigurationManager.AppSettings["TimeIntervalToCheck"].ToString(); }
        }

        public static string CSVLocation
        {
            get { return ConfigurationManager.AppSettings["CSVLocation"].ToString(); }
        }

        #endregion


        #region MongoSettings

        public static string MongoDBConnectionString
        {
            get { return ConfigurationManager.AppSettings["MongoDBConnectionString"].ToString(); }
        }

        public static int MongoRetryCount
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MongoRetryCount"]); }
        }

        public static int MongoRetrySleepDuration
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MongoRetrySleepDuration"]); }
        }

        public static string MongoDBCommon
        {
            get { return ConfigurationManager.AppSettings["MongoDBCommon"]; }
        }

        public static string MongoBackgroundQueueCollection
        {
            get { return ConfigurationManager.AppSettings["MongoBackgroundQueueCollection"]; }
        }

        public static string MongoDBStandingOrders
        {
            get { return ConfigurationManager.AppSettings["MongoDBStandingOrders"]; }
        }

        public static string MongoChangeRequestCollection
        {
            get { return ConfigurationManager.AppSettings["MongoChangeRequestCollection"]; }
        }

        #endregion MongoSettings        
    }
}
