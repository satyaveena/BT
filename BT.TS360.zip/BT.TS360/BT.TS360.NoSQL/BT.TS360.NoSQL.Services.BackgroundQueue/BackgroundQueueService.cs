﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Services.BackgroundQueue.Common;
using MongoDB.Driver;
using MongoDB.Bson;
using BT.TS360.NoSQL.Data.Common.Helper;
using System.Timers;
using BT.TS360.NoSQL.Services.BackgroundQueue.Helper;

namespace BT.TS360.NoSQL.Services.BackgroundQueue
{
    public partial class BackgroundQueueService : ServiceBase
    {
        static Logging log = new Logging();       
        ExceptionLogger _exceptionLogger = new ExceptionLogger(AppSettings.ExceptionLoggingConnectionString);
        ProcessHelper processHelper = new ProcessHelper();

        public BackgroundQueueService()
        {
            InitializeComponent();
        }

        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args)
        {
            try
            {
                log.WriteLog(Constant.START_SERVICE);

                //Excute every minutes 
                var timer = new System.Timers.Timer();
                Int32 TimeIntervalToCheck = Convert.ToInt32(AppSettings.TimeIntervalToCheck);
                timer.Interval = TimeIntervalToCheck;
                timer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimerElapsed);
                timer.Enabled = true;
            }
            catch (Exception ex)
            {
                //log in DB
                _exceptionLogger.LogError(ex, Constant.APPLICATION_NAME, Constant.ON_START_FUNCTION);
                
                //send mail for exception and log to location
                SendMail.SendEmailExceptionGeneric(ex.Message, Constant.ON_START_FUNCTION);
            }
        }

        public void Stop(string[] args) { OnStop(); }

        protected override void OnStop()
        {
            try
            {
                log.WriteLog(Constant.STOP_SERVICE);
                var timer = new System.Timers.Timer();
                timer.Stop();
                timer.Dispose();
            }
            catch (Exception ex)
            {
                //log in DB
                _exceptionLogger.LogError(ex, Constant.APPLICATION_NAME, Constant.ON_STOP_FUNCTION);

                //send mail for exception and log to location
                SendMail.SendEmailExceptionGeneric(ex.Message, Constant.ON_STOP_FUNCTION);
            }
        }

        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {            
            Main();
        }

        public async Task Main()
        {
            await processHelper.StartProcess();
        }
    }
}
