﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using System.Collections.Specialized;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Axis360;
using BT.TS360.NoSQL.Services.Axis360Inventory;

namespace BT.TS360.NoSQL.Services.Axis360Inventory.Helper
{
    public class Axis360InventoryHelper
    {

        #region Members
        private static string VendorUserName
        {
            get
            {
                return AppSettings.Axis360VendorUserName;
            }
        }
        private static string VendorPassword
        {
            get
            {
                return AppSettings.Axis360VendorPassword;
            }
        }
        private static string LibraryId
        {
            get
            {
                return AppSettings.Axis360LibraryId;
            }
        }

        private static string Axis360ApiURL
        {
            get
            {
                return AppSettings.Axis360ApiURL;
            }
        }
        #endregion

        private async static Task<Axis360Token> GetAccessToken()
        {
            Axis360Token token;
            DateTime now = DateTime.Now;
            var authorizationString = string.Format("{0}:{1}:{2}", VendorUserName, VendorPassword, LibraryId);
            var encodedAuthorizationString = Convert.ToBase64String(Encoding.Unicode.GetBytes(authorizationString));
            NameValueCollection parameters = new NameValueCollection();
            var jss = new JavaScriptSerializer();
            using (HttpClient client = new HttpClient())
            {
                token = new Axis360Token();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", encodedAuthorizationString);
                var response = await client.PostAsJsonAsync(Axis360ApiURL + ".svc/accesstoken", parameters);
                if (response.IsSuccessStatusCode)
                {
                    var stringRes = await response.Content.ReadAsStringAsync();
                    var data = jss.Deserialize<IDictionary<string, string>>(stringRes);

                    if (data.ContainsKey("access_token"))
                        token.AccessValue = data["access_token"];
                    var tokenDuration = 0;
                    if (data.ContainsKey("expires_in"))
                        int.TryParse(data["expires_in"], out tokenDuration);
                    token.TokenDurationInSeconds = tokenDuration;
                    if (data.ContainsKey("token_type"))
                        token.TokenType = data["token_type"];
                    token.CreatedDate = now;
                }
            }

            return token;

        }

        public async static Task<Axis360InventoryResponse> GetAxis360InventoryByDate(DateTime modifiedSince)
        {
            var axis360InventoryResponse = new Axis360InventoryResponse(); ;
            var jss = new JavaScriptSerializer();
            jss.MaxJsonLength = int.MaxValue;
            string address = string.Format(Axis360ApiURL + "/getalllibraryinventory/?modifiedDate={0}", modifiedSince);

            var accessToken = await GetAccessToken();
            if (accessToken != null)
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Authorization", accessToken.AccessValue);
                    client.DefaultRequestHeaders.Add("Library", "nolibraryId");
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = await client.GetAsync(address);

                    if (response.IsSuccessStatusCode)
                    {
                        var stringRes = await response.Content.ReadAsStringAsync();
                        axis360InventoryResponse = jss.Deserialize<Axis360InventoryResponse>(stringRes);
                    }
                }
            }
            return axis360InventoryResponse;

        }

        private static Axis360InventoryResponse BindAxis360InventoryData(Axis360InventoryResponse axis360InventoryResponse)
        {
            return axis360InventoryResponse;
        }
    }

}
