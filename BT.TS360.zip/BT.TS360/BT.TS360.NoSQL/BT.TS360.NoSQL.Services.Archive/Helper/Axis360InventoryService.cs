﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Timers;
using System.Configuration;
using System.Data.OleDb;
using System.Xml.Serialization;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Bson.Serialization;
using BTNextGen.Elmah;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Services.Lists.Services;
using BT.TS360.NoSQL.Services.Lists.Helper;
using BT.TS360.NoSQL.Services.Lists;
using System.Configuration; 

namespace BT.TS360.NoSQL.Services.Lists
{
    public partial class ListService : ServiceBase
    {

        ThreadedLogger _threadedLogger;
        static Emailer _emailer;
        ExceptionLogger _exceptionLogger;


        int _intervalMilliseconds;

        static string _emailTo;
        static string _currentEnvironment;

        static Boolean _InProcess = false;

        private System.Timers.Timer _timer;
        private System.Timers.Timer timer1 = null;
        public ListService()
        {
            InitializeComponent();
        }


        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args)
        {
            InitAppSettings();

            timer1 = new System.Timers.Timer();
            Int32 TimeIntervalToCheck = Convert.ToInt32(AppSettings.TimeIntervalToCheck);
            this.timer1.Interval = TimeIntervalToCheck;
            this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(OnTimerElapsed);
            timer1.Enabled = true;

            _threadedLogger.Write("Lists Service started", FileLoggingLevel.INFO);
            _emailer.Send(_emailTo, string.Format("Lists Service: " + _currentEnvironment + " [" + Environment.MachineName + "]"), "Service Started " + DateTime.Now.ToString());
        }

        public void Stop(string[] args) { OnStop(); }

        protected override void OnStop()
        {

            _threadedLogger.Write("Lists Service STOPPED", FileLoggingLevel.INFO);
            _emailer.Send(_emailTo, string.Format("Lists Service: " + _currentEnvironment + " [" + Environment.MachineName + "]"), "Service Stopped " + DateTime.Now.ToString());

            _timer.Stop();
            this._timer.Dispose();
        }


        private void InitAppSettings()
        {
            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix);
            _emailer = new Emailer(AppSettings.EmailSMTPServer);
            _emailTo = AppSettings.EmailTo_Technical;
            _currentEnvironment = AppSettings.CurrentEnvironment;
            _exceptionLogger = new ExceptionLogger(AppSettings.ExceptionLoggingConnectionString);
        }


        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            UpdateLists updateListsMain = new UpdateLists();
            string TimeToExecuteHour = AppSettings.TimeToExecuteHour;
            string TimeToExecuteHourCurrent = DateTime.Now.Hour.ToString();

            if (TimeToExecuteHour == TimeToExecuteHourCurrent)
            {
                string TimeLastUpdated = AppSettings.TimeLastUpdated;
                string TimeLastUpdatedCurrent = DateTime.Now.ToShortDateString();

                if (TimeLastUpdated != TimeLastUpdatedCurrent)
                {
                    System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                    config.AppSettings.Settings.Remove("TimeLastUpdated");
                    config.AppSettings.Settings.Add("TimeLastUpdated", TimeLastUpdatedCurrent);
                    config.Save(ConfigurationSaveMode.Modified);
                    ConfigurationManager.RefreshSection("appSettings");
                    if (!_InProcess)
                    {
                        _InProcess = true;
                        //  Do Work
                        updateListsMain.Main();

                        _InProcess = false;

                    }
                }
            }
        }
    }
}

