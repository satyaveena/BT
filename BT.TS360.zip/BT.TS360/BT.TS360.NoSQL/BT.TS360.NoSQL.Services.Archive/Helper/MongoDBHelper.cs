﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using System.Threading;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.Services.Archive.Helper
{
    class MongoDBHelper
    {
        IMongoClient _client;
        IMongoDatabase _databaseStandingOrders;
        IMongoCollection<BsonDocument> _changeRequestsHistory;
        IMongoCollection<BsonDocument> _changeRequests;

        int retryWaitTime = AppSettings.RetryWaitTime;
        int inventoryBatchSize = AppSettings.InventoryBatchSize;
       static ThreadedLogger _threadedLogger;

        DateTime _today;

        public MongoDBHelper()
        {
            string connection = AppSettings.MongoDBConnectionString;
            _client = new MongoClient(connection);
            _databaseStandingOrders = _client.GetDatabase(AppSettings.DatabaseNameStandingOrders);
            _changeRequests = _databaseStandingOrders.GetCollection<BsonDocument>(AppSettings.ChangeRequestsCollectionName);
            _changeRequestsHistory = _databaseStandingOrders.GetCollection<BsonDocument>(AppSettings.ChangeRequestsHistoryCollectionName);
            _today = DateTime.Today;

            _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix);
        }

        public async Task<List<BsonDocument>> GetChangeRequestsForArchive()
        {
            int retries = AppSettings.MaxConnectionRetries;
            var response = new List<BsonDocument>();
            var archiveStatuses = new List<string>();
            archiveStatuses.Add(CommonConstants.ChangeRequestStatus.Deleted);
            archiveStatuses.Add(CommonConstants.ChangeRequestStatus.Loaded);
            archiveStatuses.Add(CommonConstants.ChangeRequestStatus.Removed);

            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BsonDocument>.Filter.Lt("FootprintInformation.UpdatedDate", DateTime.UtcNow.AddHours(-24))
                        & Builders<BsonDocument>.Filter.In("RequestStatus", archiveStatuses);
                        
                    response = await _changeRequests.Find<BsonDocument>(filter).ToListAsync();

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
            return response;
        }


        internal async Task ArchiveChangeRequests(List<BsonDocument> changeRequestsToArchive)
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {

                    await _changeRequestsHistory.InsertManyAsync(changeRequestsToArchive);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }

        internal async Task DeleteChangeRequests(List<ObjectId> changeRequestObjectIds)
        {
            var filter = Builders<BsonDocument>.Filter.In("_id", changeRequestObjectIds);
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {

                    var response = await _changeRequests.DeleteManyAsync(filter);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }
    }

    
}
