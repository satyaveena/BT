﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BT.TS360.NoSQL.Services.Archive
{
    public class AppSettings
    {

        #region ServiceSettings
        public static string ArchiveChangeRequests
        {
            get { return ConfigurationManager.AppSettings["ArchiveChangeRequests"].ToString(); }
        }

        public static string ArchiveChangeRequestsFrequencyInHours
        {
            get { return ConfigurationManager.AppSettings["ArchiveChangeRequestsFrequencyInHours"].ToString(); }
        }
        #endregion ServiceSettings


        #region LoggingSettings
        //values pertain to logging (3 types of logging: file, email and elmah)

        public static string CurrentEnvironment
        {
            get { return ConfigurationManager.AppSettings["CurrentEnvironment"].ToString(); }
        }

        public static string EmailTo_Technical
        {
            get { return ConfigurationManager.AppSettings["EmailTo_Technical"].ToString(); }
        }

        public static string EmailTo_Business
        {
            get { return ConfigurationManager.AppSettings["EmailTo_Business"].ToString(); }
        }

        public static string EmailSMTPServer
        {
            get { return ConfigurationManager.AppSettings["EmailSMTPServer"].ToString(); }
        }


        public static string ExceptionLoggingConnectionString
        {
            get { return ConfigurationManager.AppSettings["ExceptionLoggingConnectionString"].ToString(); }
        }

        public static string LogFolder
        {
            get { return ConfigurationManager.AppSettings["LogFolder"].ToString(); }
        }

        public static string LogFilePrefix
        {
            get { return ConfigurationManager.AppSettings["LogFilePrefix"].ToString(); }
        }

        public static string TimeIntervalToCheck
        {
            get { return ConfigurationManager.AppSettings["TimeIntervalToCheck"].ToString(); }
        }

        public static string TimeLastUpdated
        {
            get { return ConfigurationManager.AppSettings["TimeLastUpdated"].ToString(); }
        }

        public static string TimeToExecuteHour
        {
            get { return ConfigurationManager.AppSettings["TimeToExecuteHour"].ToString(); }
        }

        #endregion LoggingSettings



      

        #region MongoSettings

        public static string MongoDBConnectionString
        {
            get { return ConfigurationManager.AppSettings["MongoDBConnectionString"].ToString(); }
        }

        public static int MaxConnectionRetries
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MaxConnectionRetries"]); }
        }

        public static int RetryWaitTime
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RetryWaitTime"]); }
        }

        public static int InventoryBatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["InventoryBatchSize"]); }
        }
        public static string LocalListsFileFolder
        {
            get { return ConfigurationManager.AppSettings["LocalListsFileFolder"]; }
        }

        public const string DatabaseNameStandingOrders = "StandingOrders";
        public const string ChangeRequestsCollectionName = "ChangeRequests";
        public const string ChangeRequestsHistoryCollectionName = "ChangeRequestsHistory";




        #endregion MongoSettings
        
    }
}
