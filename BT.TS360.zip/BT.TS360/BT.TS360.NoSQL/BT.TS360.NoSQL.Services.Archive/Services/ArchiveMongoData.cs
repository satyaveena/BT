﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Timers;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using BT.TS360.NoSQL.Services.Archive.Helper;
using BT.TS360.NoSQL.Data;
using BTNextGen.Elmah;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Collections.Concurrent;
using System.Net;
using System.Data;
using System.Data.OleDb;
using Microsoft.WindowsAPICodePack.Shell;
using Microsoft.WindowsAPICodePack.Shell.PropertySystem;
using BT.TS360.NoSQL.Data.DAL;

namespace BT.TS360.NoSQL.Services.Archive.Services
{
    class ArchiveMongoData
    {
        ThreadedLogger _threadedLogger;
        static Emailer _emailer;
        ExceptionLogger _exceptionLogger;
        MongoDBHelper mongoDBHelper = new MongoDBHelper();

        public async Task Main(string lastRunDateString)
        {
            DateTime lastRunDate;
            DateTime.TryParse(lastRunDateString, out lastRunDate);
            _exceptionLogger = new ExceptionLogger(AppSettings.ExceptionLoggingConnectionString);
            try
            {
                _threadedLogger = new ThreadedLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix);
                _threadedLogger.Write("Start Main", FileLoggingLevel.INFO);
                _emailer = new Emailer(AppSettings.EmailSMTPServer);
                if (!string.IsNullOrEmpty(AppSettings.ArchiveChangeRequests) && string.Equals(AppSettings.ArchiveChangeRequests, "true", StringComparison.OrdinalIgnoreCase))
                {
                    _threadedLogger.Write("Begin Archive ChangeRequests", FileLoggingLevel.INFO);

                    var changeRequestsToArchive = await mongoDBHelper.GetChangeRequestsForArchive();
                    if (changeRequestsToArchive != null && changeRequestsToArchive.Any())
                    {
                        var changeRequestObjectIds = GetObjectIdsFromChangeRequests(changeRequestsToArchive);
                        changeRequestsToArchive = AddArchiveDate(changeRequestsToArchive);
                        await mongoDBHelper.ArchiveChangeRequests(changeRequestsToArchive);
                        await mongoDBHelper.DeleteChangeRequests(changeRequestObjectIds);
                        _threadedLogger.Write("Archived " + changeRequestsToArchive.Count() + " ChangeRequests", FileLoggingLevel.INFO);
                    }
                    _threadedLogger.Write("End Archive ChangeRequests", FileLoggingLevel.INFO);
                }

                _threadedLogger.Write("End Main", FileLoggingLevel.INFO);
            }
            catch (Exception exception)
            {
                _threadedLogger.Write(exception.Message, FileLoggingLevel.ERROR);
                _exceptionLogger.LogError(exception, "ArchiveService", "Main");
            }
        }

        private List<BsonDocument> AddArchiveDate(List<BsonDocument> changeRequestsToArchive)
        {
            var now = DateTime.Now;
            foreach(var document in changeRequestsToArchive)
            {
                document.Add("ArchiveDate", now);
            }
            return changeRequestsToArchive;
        }

        private List<ObjectId> GetObjectIdsFromChangeRequests(List<BsonDocument> changeRequestsToArchive)
        {
            var objectIdList = new List<ObjectId>();
            foreach(var document in changeRequestsToArchive)
            {
                if (document.Contains("_id"))
                    objectIdList.Add(document["_id"].AsObjectId);
            }
            return objectIdList;
        }
    }
}