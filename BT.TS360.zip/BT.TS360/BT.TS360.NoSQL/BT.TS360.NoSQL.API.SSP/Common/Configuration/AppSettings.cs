﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace BT.TS360.NoSQL.API.SSP.Common.Configuration
{
    public class AppSettings
    {
        public static string MongoDBConnectionString
        {
            get { return ConfigurationManager.AppSettings["MongoDBConnectionString"].ToString(); }
        }

        public static int SuperWarehouseInventoryThreshold
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["SuperWarehouseInventoryThreshold"]); }
        }

        public static int MaxConnectionRetries
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MaxConnectionRetries"]); }
        }

        public static int RetryWaitTime
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RetryWaitTime"]); }
        }

        public static int ProductTitleMaxInput
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["ProductTitleMaxInput"]); }
        }

        public static string ExceptionLoggingConnectionString
        {
            get { return ConfigurationManager.AppSettings["ExceptionLoggingConnectionString"].ToString(); }
        }

        public static string Ts360SiteUrl
        {
            get { return ConfigurationManager.AppSettings["TS360SiteUrl"]; }
        }

        public static string AllowedHeaderForAuthentication
        {
            get { return ConfigurationManager.AppSettings["AllowedHeaderForAuthentication"]; }
        }

        public static string AllowedMethodForAuthentication
        {
            get { return ConfigurationManager.AppSettings["AllowedMethodForAuthentication"]; }
        }

        public static string PassPhraseForAuthentication
        {
            get { return ConfigurationManager.AppSettings["PassPhraseForAuthentication"]; }
        }

        public static string AuthValueForAuthentication
        {
            get { return ConfigurationManager.AppSettings["AuthValueForAuthentication"]; }
        }

        public static string CcCloudImageConnectionstring
        {
            get { return ConfigurationManager.AppSettings["ContenCafeCloudImage_ConnectionString"]; }
        }

        public static string CcCloudImageNextgenSystemid
        {
            get { return ConfigurationManager.AppSettings["ContenCafeCloudImage_NextGen_SystemId"]; }
        }

        public static string CcCloudImage_Size_Small
        {
            get { return ConfigurationManager.AppSettings["ContenCafeCloudImage_Size_Small"]; }
        }

        public static string CcCloudImage_Size_Medium
        {
            get { return ConfigurationManager.AppSettings["ContenCafeCloudImage_Size_Medium"]; }
        }

        public static string CcCloudImage_Size_Large
        {
            get { return ConfigurationManager.AppSettings["ContenCafeCloudImage_Size_Large"]; }
        }

        public static string OrderStatusEmailTo
        {
            get { return ConfigurationManager.AppSettings["OrderStatusEmailTo"]; }
        }

        public static string ProfileRequestEmailTo
        {
            get { return ConfigurationManager.AppSettings["ProfileRequestEmailTo"]; }
        }

        public static string SeriesInquiryRequestEmailTo
        {
            get { return ConfigurationManager.AppSettings["SeriesInquiryRequestEmailTo"]; }
        }

        public static string MissingSalesTerritoryEmailTo
        {
            get { return ConfigurationManager.AppSettings["MissingSalesTerritoryEmailTo"]; }
        }

        public static string StandingOrdersEmailPrefix
        {
            get { return ConfigurationManager.AppSettings["StandingOrdersEmailPrefix"]; }
        }

        public static string SearchServiceName
        {
            get { return ConfigurationManager.AppSettings["SearchServiceName"]; }
        }

        public static string SearchServiceQueryApiKey
        {
            get { return ConfigurationManager.AppSettings["SearchServiceQueryApiKey"]; }
        }

        public static string ProfiledSeriesIndexName
        {
            get { return ConfigurationManager.AppSettings["ProfiledSeriesIndexName"]; }
        }

        public static string SeriesIndexName
        {
            get { return ConfigurationManager.AppSettings["SeriesIndexName"]; }
        }

        public static string ProfilesIndexName
        {
            get { return ConfigurationManager.AppSettings["ProfilesIndexName"]; }
        }

        public static bool AzureSearchValidateServerCertificate
        {
            get { return ConfigurationManager.AppSettings["AzureSearchValidateServerCertificate"].ToLower() == "true"; }
        }

        public static int AzureSearchQueuePriority
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["AzureSearchQueuePriority"]); }
        }

        public static int BackgroundQueuePriority
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["BackgroundQueuePriority"]); }
        }

        public static string BatchExportRequestEmailTo
        {
            get { return ConfigurationManager.AppSettings["BatchExportRequestEmailTo"]; }
        }
    }
}