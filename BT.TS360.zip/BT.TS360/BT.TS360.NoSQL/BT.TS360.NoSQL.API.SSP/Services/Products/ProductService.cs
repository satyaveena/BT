﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using System.Threading;
using BT.TS360.NoSQL.API.SSP.Models.Products;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Driver;
using BT.TS360.NoSQL.API.SSP.Common.Configuration;
using BT.TS360.NoSQL.SSP.API.Models;

namespace BT.TS360.NoSQL.API.SSP.Services.Products
{
    public class ProductService
    {
        readonly IMongoCollection<BsonDocument> _iProductsCollection;

        public ProductService()
        {
            var client = new MongoClient(ConnectionString);
            var iProductsDatabase = client.GetDatabase(CommonConstants.ProductsDatabaseName);
            _iProductsCollection = iProductsDatabase.GetCollection<BsonDocument>(CommonConstants.ProductsCollectionName);
        }

        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }

        internal async Task<NoSqlServiceResult<List<ProductTitle>>> RetrieveTitles(RetrieveTitlesRequest input )
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<ProductTitle>> { Status = NoSqlServiceStatus.Success, Data = new List<ProductTitle>() };
            if (input == null || input.IsbnUpcs == null || input.IsbnUpcs.Count == 0)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "400";
                noSqlServiceResult.ErrorMessage = "ISBN/UPC list is required or invalid input parameter.";
                return noSqlServiceResult;
            }

            if (input.IsbnUpcs.Count > AppSettings.ProductTitleMaxInput)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "401";
                noSqlServiceResult.ErrorMessage = "Input ISBN/UPC list is over " + AppSettings.ProductTitleMaxInput.ToString() + " items limitation.";
                return noSqlServiceResult;
            }

            List<ProductTitle> dataList = new List<ProductTitle>();
             
            foreach (var itm in input.IsbnUpcs)
            {

                if (string.IsNullOrEmpty(itm.IsbnUpc))
                {
                    dataList.Add(new ProductTitle{ Status= ItemStatus.Fail, ErrorMessage= "IsbnUpc is empty. This required value." });
                    continue;
                }
                if (!itm.BTSKUType.HasValue)
                {
                    dataList.Add(new ProductTitle { Status = ItemStatus.Fail, ErrorMessage = "BTSKUType is invalid.", IsbnUpc = itm.IsbnUpc });
                    continue;
                }
                 
                var product = await RetrieveTitle(itm);
                dataList.Add(product);
            }
            noSqlServiceResult.Data = dataList;
            return noSqlServiceResult;
        }

        private async Task<ProductTitle> RetrieveTitle(ProductTitleRequest input)
        {
            string title = "";
            BTSKUType outPutBTSKUType = BTSKUType.ISBN10;
            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                BsonDocument bsonDoc = null;
                FilterDefinition<BsonDocument> filter = null;

                switch (input.BTSKUType)
                {
                    case BTSKUType.ISBN13:
                        filter = Builders<BsonDocument>.Filter.Eq("ISBN", input.IsbnUpc);
                        break;
                    case BTSKUType.ISBN10:
                        filter = Builders<BsonDocument>.Filter.Eq("ISBN10", input.IsbnUpc);
                        break;
                    case BTSKUType.UPC:
                        filter = Builders<BsonDocument>.Filter.Eq("UPC", input.IsbnUpc);
                        break;
                }

                if (filter == null)
                    return new ProductTitle { IsbnUpc = input.IsbnUpc, Title = title };


                while (retries > 0)
                {
                    try
                    {
                        bsonDoc = await _iProductsCollection.Find(filter).FirstOrDefaultAsync();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                if (bsonDoc == null)
                {
                    return new ProductTitle { Status= ItemStatus.Fail, ErrorMessage="Product not found.", IsbnUpc = input.IsbnUpc };
                }

                title = (bsonDoc.Contains("Title")) ? bsonDoc["Title"].AsString : "";
            }
            catch (Exception ex)
            {
                var logger = new LoggerService();
                var msg = string.Format("Can't retrieve title for isbnUpc='{0}' and BTSKUType='{1}'" + input.IsbnUpc, input.BTSKUType);

                logger.LogError(ex, "RetrieveTitle", msg);
            }
            return new ProductTitle { IsbnUpc = input.IsbnUpc, Title = title};

        }

    }
}