﻿
using BT.TS360.NoSQL.API.SSP.Models.Products;
using BT.TS360.NoSQL.API.SSP.Services.Products;
using BT.TS360.NoSQL.SSP.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace BT.TS360.NoSQL.API.SSP.Controllers
{
    [Authorize]
    public class ProductsController : ApiController
    {
        private readonly ProductService _productService;

        public ProductsController()
        {
            this._productService = new ProductService();
        }

        [HttpPost]
        [Route("products/retrievetitles")]
        public async Task<NoSqlServiceResult<List<ProductTitle>>> RetrieveTitles([FromBody] RetrieveTitlesRequest input)
        {
            return await _productService.RetrieveTitles(input);
        }
    }
}
