﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Security.OAuth;
using Owin;

[assembly: OwinStartup(typeof(BT.TS360.NoSQL.API.SSP.App_Start.Startup))]

namespace BT.TS360.NoSQL.API.SSP.App_Start
{
    public class Startup
    {
        public void ConfigureAuthClient(IAppBuilder app)
        {
            app.UseCors(CorsOptions.AllowAll);
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions { });
        }

        public void Configuration(IAppBuilder app)
        {
            ConfigureAuthClient(app);
        }
    }
}
