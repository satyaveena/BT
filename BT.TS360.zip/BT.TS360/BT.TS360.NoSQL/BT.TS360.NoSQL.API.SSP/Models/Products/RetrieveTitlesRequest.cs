﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.SSP.Models.Products
{
    public enum BTSKUType
    {
        ISBN13,
        ISBN10,
        UPC
    }

    [DataContract]
    public class RetrieveTitlesRequest
    {
        [DataMember]
        public List<ProductTitleRequest> IsbnUpcs { get; set; }
    }

    [DataContract]
    public class ProductTitleRequest
    {
        [DataMember]
        public string IsbnUpc { get; set; }

        [DataMember]
        public BTSKUType? BTSKUType { get; set; }

    }
}