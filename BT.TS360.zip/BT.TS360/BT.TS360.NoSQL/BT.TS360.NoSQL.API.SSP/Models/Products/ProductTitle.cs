﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.SSP.Models.Products
{
    public enum ItemStatus
    {
        Success = 0,
        Fail = 1
    }

    [DataContract]
    public class ProductTitle
    {
        [DataMember]
        public string IsbnUpc { get; set; }
        
        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public ItemStatus Status { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }
    }
}