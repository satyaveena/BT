﻿using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Helper;
using MongoDB.Bson;
using MongoDB.Driver;
using BasketsPurge.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BasketsPurge
{
    class Program
    {
        static MongoDBHelper mongoDBHelper;
        static MessageHelper messageHelper;
        static SQLDBHelper sqlDBHelper;

        static void Main(string[] args)
        {
            messageHelper = new MessageHelper(AppSettings.ExceptionLoggingConnectionString, AppSettings.LogFolder,
                AppSettings.LogFilePrefix, AppSettings.EmailSMTPServer, AppSettings.EmailTo,
                AppSettings.ServiceName, AppSettings.CurrentEnvironment + " [" + Environment.MachineName + "]", AppSettings.VerboseLogging);

            mongoDBHelper = new MongoDBHelper();
            sqlDBHelper = new SQLDBHelper();

            // Baskets Purge from SQL
            BasketsPurgeFromSql();

            // Baskets Purge From MongoDB
            BasketsPurgeFromMongoDB();
        }

        private static void BasketsPurgeFromSql()
        {
            try
            {
                messageHelper.HandleMessage(null, "BasketsPurgeFromSql", "Task Started", FileLoggingLevel.STATE);
                bool hasBaskets = false;
                List<ObjectId> dupeCheckItemsToDelete;
                List<UpdateOneModel<DupeCheck>> updateModelsList;
                List<ReplaceOneModel<DupeCheck>> replaceModelList;

                do
                {
                    var basketsDataset = sqlDBHelper.GetBasketsToPurge();
                    dupeCheckItemsToDelete = new List<ObjectId>();
                    updateModelsList = new List<UpdateOneModel<DupeCheck>>();
                    replaceModelList = new List<ReplaceOneModel<DupeCheck>>();
                
                    if (basketsDataset != null && basketsDataset.Tables != null && basketsDataset.Tables.Count > 0 && basketsDataset.Tables[0].Rows.Count > 0)
                    {
                        hasBaskets = true;

                        List<string> ltBasketSummaryIds = basketsDataset.Tables[0].AsEnumerable()
                           .Select(r => r.Field<string>("BasketSummaryID"))
                           .ToList();

                        DupeCheckAndUpdateOrDeleteItem(dupeCheckItemsToDelete, updateModelsList, replaceModelList, ltBasketSummaryIds);

                        DeleteAndUpdateStatus(dupeCheckItemsToDelete, ltBasketSummaryIds, updateModelsList, replaceModelList, "BasketsPurgeFromSql");

                        if (basketsDataset != null && basketsDataset.Tables != null && basketsDataset.Tables[0].Rows.Count > 0)
                        {
                            sqlDBHelper.SetPurgedBaskets(basketsDataset.Tables[0]);
                            messageHelper.HandleMessage(null, "BasketsPurgeFromSql-SQL", "Deleted " + ltBasketSummaryIds.Count() + " Baskets in SQL", FileLoggingLevel.INFO);
                        }
                    }
                    else
                    {
                        hasBaskets = false;
                    }
                }
                while (hasBaskets);

                messageHelper.HandleMessage(null, "BasketsPurgeFromSql", "Task Stopped", FileLoggingLevel.STATE);
            }
            catch (Exception exception)
            {
                messageHelper.HandleMessage(exception, "BasketsPurgeFromSql", exception.Message, FileLoggingLevel.ERROR);
            }
        }

        private static void BasketsPurgeFromMongoDB()
        {
            try
            {
                messageHelper.HandleMessage(null, "BasketsPurgeFromMongoDB", "Task Started", FileLoggingLevel.STATE);
                bool hasBaskets = false;
                List<ObjectId> dupeCheckItemsToDelete;
                List<UpdateOneModel<DupeCheck>> updateModelsList;
                List<ReplaceOneModel<DupeCheck>> replaceModelList;

                do
                {
                    var basketsList = mongoDBHelper.GetBasketsToPurge();
                    dupeCheckItemsToDelete = new List<ObjectId>();
                    updateModelsList = new List<UpdateOneModel<DupeCheck>>();
                    replaceModelList = new List<ReplaceOneModel<DupeCheck>>();
                   
                    if (basketsList != null && basketsList.Any())
                    {
                        hasBaskets = true;

                        List<string> ltBasketSummaryIds = basketsList.Select(x=> x.BasketSummaryID).ToList();
                            
                        DupeCheckAndUpdateOrDeleteItem(dupeCheckItemsToDelete, updateModelsList, replaceModelList, ltBasketSummaryIds);

                        DeleteAndUpdateStatus(dupeCheckItemsToDelete, ltBasketSummaryIds, updateModelsList, replaceModelList, "BasketsPurgeFromMongo");
                    }
                    else
                    {
                        hasBaskets = false;
                    }
                }
                while (hasBaskets);

                messageHelper.HandleMessage(null, "BasketsPurgeFromMongoDB", "Task Stopped", FileLoggingLevel.STATE);
            }
            catch (Exception exception)
            {
                messageHelper.HandleMessage(exception, "BasketsPurgeFromMongoDB", exception.Message, FileLoggingLevel.ERROR);
            }
        }

        private static void DupeCheckAndUpdateOrDeleteItem(List<ObjectId> dupeCheckItemsToDelete, List<UpdateOneModel<DupeCheck>> updateModelsList, List<ReplaceOneModel<DupeCheck>> replaceModelList, 
            List<string> batchBasketSummaryIDs)
        {
            var dupeCheckItems = mongoDBHelper.GetDupeCheckItem(batchBasketSummaryIDs);
            // max size - batch size * 9,999 ( max products per cart)
            

            if (dupeCheckItems != null && dupeCheckItems.Any())
            {
                foreach (var dupeCheckItem in dupeCheckItems)
                {
                    dupeCheckItem.DownloadedBasketSummary = dupeCheckItem.DownloadedBasketSummary.Select(x => x)
                        .Where(y => batchBasketSummaryIDs.All(s => !s.Equals(y.BasketSummaryID, StringComparison.OrdinalIgnoreCase))).ToList();

                    if (dupeCheckItem.DownloadedBasketSummary != null && dupeCheckItem.DownloadedBasketSummary.Any())
                    {
                        //Replace document with modified document
                        replaceModelList.Add(GetUpdateModelForDupeCheck(dupeCheckItem));
                    }
                    else
                    {
                        if (dupeCheckItem.Accounts != null && dupeCheckItem.Accounts.Any())
                        {
                            //Unset DownloadedBasketSummary field
                            updateModelsList.Add(GetUpdateModelForUnsetDownloadedBasketSummary(dupeCheckItem.DupeCheckID));
                        }
                        else
                        {
                            //Delete Document
                            dupeCheckItemsToDelete.Add(dupeCheckItem.DupeCheckID);
                        }
                    }
                }
            }
        }

        private static void DeleteAndUpdateStatus(List<ObjectId> dupeCheckItemsToDelete, List<string> basketSummaryIds,
            List<UpdateOneModel<DupeCheck>> updateModelsList, List<ReplaceOneModel<DupeCheck>> replaceModelList, string source)
        {
            if (basketSummaryIds != null && basketSummaryIds.Any())
            {
                mongoDBHelper.DeleteBasketLines(basketSummaryIds);
                messageHelper.HandleMessage(null, source, "Deleted " + basketSummaryIds.Count() + " Baskets", FileLoggingLevel.INFO);
            }

            if (replaceModelList.Any())
            {
                mongoDBHelper.ReplaceDupeCheckItems(replaceModelList);
                messageHelper.HandleMessage(null, source, "Replaced " + replaceModelList.Count() + " DupeCheckItems", FileLoggingLevel.INFO);
            }

            if (updateModelsList.Any())
            {
                mongoDBHelper.UpdateDupeCheckItems(updateModelsList);
                messageHelper.HandleMessage(null, source, "Updated " + updateModelsList.Count() + " DupeCheckItems", FileLoggingLevel.INFO);
            }

            if (dupeCheckItemsToDelete.Any())
            {
                mongoDBHelper.DeleteDupeCheckItems(dupeCheckItemsToDelete);
                messageHelper.HandleMessage(null, source, "Deleted " + dupeCheckItemsToDelete.Count() + " DupeCheckItems", FileLoggingLevel.INFO);
            }
        }

        private static ReplaceOneModel<DupeCheck> GetUpdateModelForDupeCheck(DupeCheck dupeCheckItem)
        {
            return new ReplaceOneModel<DupeCheck>(Builders<DupeCheck>.Filter.Eq("_id", dupeCheckItem.DupeCheckID), dupeCheckItem);
        }

        private static UpdateOneModel<DupeCheck> GetUpdateModelForUnsetDownloadedBasketSummary(ObjectId objectId)
        {
            return new UpdateOneModel<DupeCheck>(
                    Builders<DupeCheck>.Filter.Eq("_id", objectId),
                    Builders<DupeCheck>.Update.Unset("DownloadedBasketSummary"));
        }
    }
}