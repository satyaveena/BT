﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using System.Threading;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson.Serialization.Conventions;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace BasketsPurge.Helper
{
    class SQLDBHelper
    {
        string _connectionString = AppSettings.OrdersConnectionString;

        public SQLDBHelper()
        {
        }

        internal DataSet GetBasketsToPurge()
        {
            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@BatchSize", AppSettings.BatchSize));
            alParams.Add(new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, -1) { Direction = ParameterDirection.Output });
            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));

            return DatabaseHelper.ExecuteProcedure("procCustomerSupportGetPurgedBaskets", arr, new SqlConnection(_connectionString));
        }

        internal void SetPurgedBaskets(DataTable BatchConfirmation)
        {
            ArrayList alParams = new ArrayList();
            alParams.Add(new SqlParameter("@DeletedBaskets", BatchConfirmation));
            alParams.Add(new SqlParameter("@ErrorMessage", SqlDbType.NVarChar, -1) { Direction = ParameterDirection.Output });

            SqlParameter[] arr = (SqlParameter[])alParams.ToArray(typeof(SqlParameter));
            DatabaseHelper.ExecuteNonQuery("procCustomerSupportSetPurgedBaskets", arr, new SqlConnection(_connectionString));

            return;
        }
    }
}