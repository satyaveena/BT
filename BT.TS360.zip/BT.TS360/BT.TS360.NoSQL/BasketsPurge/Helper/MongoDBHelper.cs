﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using System.Threading;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson.Serialization.Conventions;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace BasketsPurge.Helper
{
    class MongoDBHelper
    {
        IMongoClient _client;
        IMongoDatabase _databaseBaskets;
        IMongoCollection<BasketLineItem> _basketLineItems;
        IMongoCollection<DupeCheck> _dupeCheck;
        int retryWaitTime = AppSettings.RetryWaitTime;

        public MongoDBHelper()
        {
            string connection = AppSettings.MongoDBConnectionString;
            _client = new MongoClient(connection);
            _databaseBaskets = _client.GetDatabase(AppSettings.DatabaseNameOrders);
            _basketLineItems = _databaseBaskets.GetCollection<BasketLineItem>(AppSettings.BasketLinesCollectionName);
            _dupeCheck = _databaseBaskets.GetCollection<DupeCheck>(AppSettings.DupeCheckCollectionName);
        }
        
        internal List<BasketLineItem> GetBasketsToPurge()
        {
            int retries = AppSettings.MaxConnectionRetries;
            var response = new List<BasketLineItem>();
            int MonthsToDeleteBaskets = AppSettings.MonthsToDeleteBaskets;
            DateTime dateTime = DateTime.Today.AddMonths(-MonthsToDeleteBaskets);

            var dateToRemove = new DateTime(dateTime.Year, dateTime.Month, dateTime.Day);
            while (retries > 0)
            {
                try
                {
                    var filter = Builders<BasketLineItem>.Filter.Lt("DownloadedDateTime", dateToRemove);
                    response = _basketLineItems.Find<BasketLineItem>(filter).Limit(AppSettings.BatchSize)
                        .ToList().GroupBy(a => a.BasketSummaryID).Select(s => new BasketLineItem() { BasketSummaryID = s.Key }).ToList();

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }
            return response;
        }

        internal List<DupeCheck> GetDupeCheckItem(List<string> lstBasketSummaryIds)
        {
            int retries = AppSettings.MaxConnectionRetries;
            var dupeCheckItem = new List<DupeCheck>();

            while (retries > 0)
            {
                try
                {
                    var filter = Builders<DupeCheck>.Filter.In("DownloadedBasketSummary.BasketSummaryID", lstBasketSummaryIds);
                    dupeCheckItem = _dupeCheck.Find<DupeCheck>(filter).ToList();

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }

            return dupeCheckItem;
        }

        internal void ReplaceDupeCheckItems(List<ReplaceOneModel<DupeCheck>> replaceModelList)
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var response = _dupeCheck.BulkWrite(replaceModelList);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }
        }

        internal void UpdateDupeCheckItems(List<UpdateOneModel<DupeCheck>> updateModelsList)
        {
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    var response = _dupeCheck.BulkWrite(updateModelsList);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }
        }

        internal void DeleteDupeCheckItems(List<ObjectId> dupeCheckItemsToDelete)
        {
            int retries = AppSettings.MaxConnectionRetries;
            var filter = Builders<DupeCheck>.Filter.In("_id", dupeCheckItemsToDelete);
            while (retries > 0)
            {
                try
                {
                    var response = _dupeCheck.DeleteMany(filter);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }
        }

        internal void DeleteBasketLines(List<string> list)
        {
            int retries = AppSettings.MaxConnectionRetries;
            var filter = Builders<BasketLineItem>.Filter.In("BasketSummaryID", list);
            while (retries > 0)
            {
                try
                {
                    var response = _basketLineItems.DeleteMany(filter);

                    break;
                }
                catch (Exception ex)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw ex;
                    }
                }
            }
        }
    }
}