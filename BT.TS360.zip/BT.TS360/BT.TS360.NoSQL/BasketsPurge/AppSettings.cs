﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BasketsPurge
{
    public class AppSettings
    {

        public static int BatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["BatchSize"]); }
        }
        
        public static int MonthsToDeleteBaskets
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MonthsToDeleteBaskets"]); }
        }
        //values pertain to logging (3 types of logging: file, email and elmah)

        public static string CurrentEnvironment
        {
            get { return ConfigurationManager.AppSettings["CurrentEnvironment"].ToString(); }
        }

        public static string EmailTo
        {
            get { return ConfigurationManager.AppSettings["EmailTo"].ToString(); }
        }

        public static string EmailSMTPServer
        {
            get { return ConfigurationManager.AppSettings["EmailSMTPServer"].ToString(); }
        }

        public static string ExceptionLoggingConnectionString
        {
            get { return ConfigurationManager.AppSettings["ExceptionLoggingConnectionString"].ToString(); }
        }

        public static string OrdersConnectionString
        {
            get { return ConfigurationManager.AppSettings["OrdersConnectionString"].ToString(); }
        }

        public static string LogFolder
        {
            get { return ConfigurationManager.AppSettings["LogFolder"].ToString(); }
        }

        public static string LogFilePrefix
        {
            get { return ConfigurationManager.AppSettings["LogFilePrefix"].ToString(); }
        }

        public static string TimeIntervalToCheck
        {
            get { return ConfigurationManager.AppSettings["TimeIntervalToCheck"].ToString(); }
        }

        public static string ServiceName
        {
            get { return ConfigurationManager.AppSettings["ServiceName"].ToString(); }
        }

        public static bool VerboseLogging
        {
            get { return Convert.ToBoolean(ConfigurationManager.AppSettings["VerboseLogging"]); }
        }


        #region MongoSettings

        public static string MongoDBConnectionString
        {
            get { return ConfigurationManager.AppSettings["MongoDBConnectionString"].ToString(); }
        }

        public static int MaxConnectionRetries
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MaxConnectionRetries"]); }
        }

        public static int RetryWaitTime
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RetryWaitTime"]); }
        }

        public const string DatabaseNameOrders = "Orders";
        public const string BasketLinesCollectionName = "BasketLineItems";
        public const string DupeCheckCollectionName = "DupeCheck";
        #endregion MongoSettings       

    }
}