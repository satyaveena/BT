﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;
using BT.TS360.NoSQL.API.Common.Configuration;

namespace BT.TS360.NoSQL.API
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            var cors = new EnableCorsAttribute(AppSettings.Ts360SiteUrl, AppSettings.AllowedHeaderForAuthentication,
                AppSettings.AllowedMethodForAuthentication);
            config.EnableCors(cors);

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "products/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
