﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models
{
    public class NoSqlResponse<T>
    {
        public long TotalItems { get; set; }

        public List<T> ItemList { get; set; }
    }
}