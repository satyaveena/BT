﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.API.Models
{
    public class CartFacetsResponse
    {
        public List<CartFacetsGroup> CartFacetsGroupResults { get; set; }
        public string MatchingBTKeys { get; set; }
    }

    public class BTKeyCartInventoryFacetsResult
    {
        public string BTKey { get; set; }

        public int LineItem { get; set; }
    }

    public class CartFacetsGroup
    {
        public string DisplayName { get; set; }

        public string Value { get; set; }

        public List<CartFacet> Facets { get; set; }

        public CartFacetsGroup(string value, string displayName)
        {
            Value = value;
            DisplayName = displayName;
            Facets = new List<CartFacet>();
        }
    }

    public class CartFacet
    {
        public string DisplayName { get; set; }

        public string Value { get; set; }

        public int ItemCount { get; set; }

        public CartFacet(string value, string displayName, int itemCount)
        {
            Value = value;
            DisplayName = displayName;
            ItemCount = itemCount;
        }
    }
}
