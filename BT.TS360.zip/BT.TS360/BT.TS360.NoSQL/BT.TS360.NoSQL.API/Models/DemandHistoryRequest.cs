﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models
{
    public class DemandHistoryRequest
    {
        public string BTKey { get; set; }
        public int? PageIndex { get; set; }
        public string PrimaryWareHouseCode { get; set; }
        public string SecondaryWareHouseCode { get; set; }
    }
}