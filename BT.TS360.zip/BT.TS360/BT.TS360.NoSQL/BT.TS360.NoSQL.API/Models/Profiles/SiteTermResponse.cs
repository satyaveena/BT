﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.Profiles
{
    [DataContract]
    public class SiteTermResponse
    {
        [DataMember]
        public SiteTermCategory[] SiteTermResult { get; set; }
    }

    [DataContract]
    public class SiteTermCategory
    {
        [DataMember]
        public string Category { get; set; }

        [DataMember]
        public string CategoryLiteral { get; set; }

        [DataMember]
        public SiteTermItem[] SiteTermObjectList { get; set; }

    }

    [DataContract]
    public class SiteTermItem
    {
        [DataMember]
        public string Value { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string SearchValue { get; set; }

        [DataMember]
        public List<SiteTermItem> Children { get; set; }

        public SiteTermItem(string value, string name)
        {
            this.Value = value;
            this.Name = name;
        }

        public SiteTermItem(string value, string name, string searchvalue, List<SiteTermItem> children)
        {
            this.Value = value;
            this.Name = name;
            this.SearchValue = searchvalue;
            this.Children = children;
        }

    }
}