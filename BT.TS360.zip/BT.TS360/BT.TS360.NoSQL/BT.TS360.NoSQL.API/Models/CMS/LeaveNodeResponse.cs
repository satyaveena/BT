﻿using System;
using System.Collections.Generic;

namespace BT.TS360.NoSQL.API.Models.CMS
{
    public class LeaveNodeResponse
    {
        public List<LeaveNodeDetailsResponse> LeaveNodes { get; set; }
        public long TotalItems { get; set; }
    }

    public class LeaveNodeDetailsResponse
    {
        public string Id { get; set; }
        public string Literal { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Sequence { get; set; }
        public int Status { get; set; }
        public string PublicLink { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public int ContentLength { get; set; }
        public byte[] Content { get; set; }
    }
}