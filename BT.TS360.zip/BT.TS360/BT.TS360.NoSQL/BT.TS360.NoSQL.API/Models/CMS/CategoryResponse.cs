﻿using System.Collections.Generic;

namespace BT.TS360.NoSQL.API.Models.CMS
{
    public class CategoryResponse
    {
        public List<CategoryDetailsResponse> Categories { get; set; }
        public List<LeaveNodeDetailsResponse> LeaveNodes { get; set; }
        public long TotalItems { get; set; }
    }

    public class CategoryDetailsResponse
    {
        public string Id { get; set; }
        public string ParentId { get; set; }
        public string ParentLiteral { get; set; }
        public string Literal { get; set; }
        public string ImageURL { get; set; }
        public int Status { get; set; }
        public int Sequence { get; set; }
        public int? ChildCount { get; set; }
        public List<CategoryDetailsResponse> ChildCategories { get; set; }
        public List<LeaveNodeDetailsResponse> LeaveNodes { get; set; }
    }
}