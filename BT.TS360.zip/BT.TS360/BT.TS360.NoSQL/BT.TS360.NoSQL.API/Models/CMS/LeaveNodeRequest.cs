﻿using System;

namespace BT.TS360.NoSQL.API.Models.CMS
{
    public class LeaveNodeRequest
    {
        public string CategoryId { get; set; }
        public string Literal { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Sequence { get; set; }
        public int Status { get; set; }
        public string PublicLink { get; set; }
        public string FileName { get; set; }
        public object FileContent { get; set; }
    }
}