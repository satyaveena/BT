﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.API.Models.Axis360
{
    [DataContract]
    public class Axis360CheckInventoryResponse
    {
        [DataMember]
        public List<Axis360InventoryItem> Axis360InventoryItemList { get; set; }
    }

    [DataContract]
    public class Axis360InventoryItem
    {
        [DataMember]
        public string ISBN { get; set; }
        [DataMember]
        public bool HasInventory { get; set; }
    }
}