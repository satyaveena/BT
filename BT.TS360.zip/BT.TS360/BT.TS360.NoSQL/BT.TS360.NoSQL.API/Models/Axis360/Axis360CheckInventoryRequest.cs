﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.Axis360
{
    public class Axis360CheckInventoryRequest
    {
        public string Axis360CustomerID { get; set; }
        public List<string> ISBNList { get; set; }
    }

}