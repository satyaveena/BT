﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.API.Models
{
    public class CartFacetsRequest
    {
        public CartInventoryFacetsBTKeys[] BTKeys { get; set; }

        public bool DEIEnabled { get; set; }

        public bool VIPEnabled { get; set; }

        public string MarketType { get; set; }

        public string CountryCode { get; set; }

        public string BookPrimaryWareHouseCode { get; set; }

        public string BookSecondaryWareHouseCode { get; set; }

        public string EntertainmentPrimaryWareHouseCode { get; set; }

        public string EntertainmentSecondaryWareHouseCode { get; set; }

        public string FacetPath { get; set; }
    }

    public class CartInventoryFacetsBTKeys
    {
        public string BTKey { get; set; }

        public string LEIndicator { get; set; }

        public string AccountInventoryType { get; set; }

        public string InventoryReserveNumber { get; set; }

        public int PagePosition { get; set; }
    }
}
