﻿using BT.TS360.NoSQL.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.Orders
{
    [DataContract]
    public class UpdateOrderAccountRequest
    {
        [DataMember]
        public string OrganizationID { get; set; }

        [DataMember]
        public List<string> ShipToAccountNumbers { get; set; }

        [DataMember]
        public string UpdateStatus { get; set; }
    }
   
}