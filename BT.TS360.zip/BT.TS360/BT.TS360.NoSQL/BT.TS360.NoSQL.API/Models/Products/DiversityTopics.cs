﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class DiversityTopic
    {
        [DataMember]
        public string TopicTitle;
        [DataMember]
        public string TopicCode;
        [DataMember]
        public List<DEIAnalizeData> DEIAnalizeData;
    }

    [DataContract]
    public class DEIAnalizeData
    {
        [DataMember]
        public string Name;
        [DataMember]
        public string Audience;
        [DataMember]
        public bool IsFiction;
        [DataMember]
        public int Percentage;
        [DataMember]
        public int Count;
    }



}