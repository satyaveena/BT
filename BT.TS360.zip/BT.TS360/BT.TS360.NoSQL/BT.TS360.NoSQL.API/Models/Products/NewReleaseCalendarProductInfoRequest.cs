﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class NewReleaseCalendarProductInfoRequest
    {
        [DataMember]
        public List<string> BTKeys { get; set; }
    }

}