﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BT.TS360.NoSQL.API.Models.Contents
{
    [DataContract]
    public class ContentListReponse
    {
        [DataMember]
        public ContentListItem[] ContentListListing { get; set; }
    }


    [DataContract]
    public class ContentListItem
    {
        [DataMember]
        public string ID { get; set; }

        [DataMember]
        public string Literal { get; set; }

        [DataMember]
        public string ChildCount { get; set; }

        [DataMember]
        public bool LeafIndicator { get; set; }

        [DataMember]
        public bool HideLink { get; set; }

        [DataMember]
        public string FilePathURL { get; set; }

        [DataMember]
        public string SearchPathURL { get; set; }

        [DataMember]
        public List<ContentListItem> Children { get; set; }
    }
}