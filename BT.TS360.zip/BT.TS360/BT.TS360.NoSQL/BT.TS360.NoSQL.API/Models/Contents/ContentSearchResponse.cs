﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BT.TS360.NoSQL.API.Models.Contents
{
     [DataContract]
    public class ContentSearchResponse
    {
        [DataMember]
        public string ItemType { get; set; }

        [DataMember]
        public List<string> ListItems { get; set; }
    }
}