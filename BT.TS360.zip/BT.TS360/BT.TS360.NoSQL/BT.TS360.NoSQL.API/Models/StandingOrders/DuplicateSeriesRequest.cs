﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class DuplicateSeriesRequest
    {
        public string OrganizationId { get; set; }
        public List<string> SeriesIdList { get; set; }
        public string ProfileId { get; set; }
    }

}