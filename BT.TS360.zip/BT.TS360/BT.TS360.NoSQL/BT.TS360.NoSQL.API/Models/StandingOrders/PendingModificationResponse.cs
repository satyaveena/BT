﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;

using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class PendingModificationResponse
    {
        [DataMember]
        public long TotalItems { get; set; }
        [DataMember]
        public List<ProfiledSeriesChangeRequestDetails> ProfiledSeriesChangeRequest { get; set; }
        
        [DataMember]
        public string AccountNumber { get; set; }

        [DataMember]
        public string ProfileName { get; set; }
        [DataMember]
        public string ProfileStatus { get; set; }
        
        [DataMember]
        public string SalesName { get; set; }

        [DataMember]
        public string SalesPhone { get; set; }

        [DataMember]
        public string SalesEmail { get; set; }

        [DataMember]
        public long TotalNew { get; set; } // total new requests

        [DataMember]
        public long TotalInProcess { get; set; } // total in process requests

        [DataMember]
        public long TotalRemoved { get; set; } // total remvoed requests

        [DataMember]
        public long TotalCompleted { get; set; } // total completed requests
        
        [DataMember]
        public long TotalAddNew { get; set; } // total new requests in "Add" type

        
    }

    [DataContract]
    public class ProfiledSeriesChangeRequestDetails
    {
        [DataMember]
        public string ChangeRequestId { get; set; }

        [DataMember]
        public string ProfiledSeriesId { get; set; }

        [DataMember]
        public string SeriesID { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string ProfileId { get; set; }
        [DataMember]
        public string ProfileName { get; set; }
        [DataMember]
        public string AccountNumber { get; set; }
        [DataMember]
        public string Programs { get; set; }
        [DataMember]
        public DateTime DateRequested { get; set; }

        [DataMember]
        public string DateRequestedDateString
        {
            get
            {
                return DateRequested.ToString(CommonConstants.DefaultDateTimeFormat);
            }
            set { var temp = value; }
        }
        [DataMember]
        public string DateRequestedTimeString
        {
            get
            {
                return DateRequested.ToString(CommonConstants.DefaultTimeFormat);
            }
            set { var temp = value; }
        }
        [DataMember]
        public int TotalQuantity { get; set; }

        [DataMember]
        public int OriginalStateTotalQuantity { get; set; }

        [DataMember]
        public string RequestType { get; set; }

        [DataMember]
        public string RequestStatus { get; set; }

        [DataMember]
        public string Cycle { get; set; }

        [DataMember]
        public List<PO> PurchaseOrders { get; set; }

        [DataMember]
        public List<PO> OriginalStatePurchaseOrders { get; set; }

        [DataMember]
        public List<POGrid> PurchaseOrderGrids { get; set; }
        
        [DataMember]
        public string Notes { get; set; }

        [DataMember]
        public string SpecialInstruction { get; set; }

        [DataMember]
        public bool IsDisplayOriginalStatePurchaseOrder { get; set; }

        [DataMember]
        public FootprintInformation FootprintInformation { get; set; }
        
    }

    /*[DataContract]
    public class ChangeRequestDetailsPO
    {

        [DataMember]
        public ObjectId PurchaseOrderID { get; set; }
        [DataMember]
        public string POLineNumber { get; set; }
        [DataMember]                            
        public string POLineNumberProposed { get; set; }
        
        [BsonIgnoreIfNull]
        [DataMember]
        public string StartDate { get; set; }  
        [BsonIgnoreIfNull]
        [DataMember]
        public string ShippingPreference { get; set; }  
        [BsonIgnoreIfNull]
        [DataMember]
        public string Status { get; set; }
        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferencePrimary { get; set; }  
        [BsonIgnoreIfNull]
        [DataMember]
        public int FormatPreferencePrimaryQuantity { get; set; }  
        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferenceSecondary { get; set; } 
        [BsonIgnoreIfNull]
        [DataMember]
        public int FormatPreferenceSecondaryQuantity { get; set; } 
        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferenceString { get; set; } 
        
        [BsonIgnoreIfNull]
        [DataMember]
        public FootprintInformation FootprintInformation { get; set; }

        [BsonIgnoreIfNull]
        [DataMember]
        public bool StartNextAvailableTitle { get; set; }

        [BsonIgnoreIfNull]
        [DataMember]
        public string FormatPreferenceDisplayText { get; set; }

  

    }*/
}