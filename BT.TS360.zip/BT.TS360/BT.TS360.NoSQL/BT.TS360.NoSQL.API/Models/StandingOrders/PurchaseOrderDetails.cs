﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class PurchaseOrderDetails
    {
        [DataMember]
        public List<PO> PurchaseOrders { get; set; }

        [DataMember]
        public string ProfiledSeriesId { get; set; }

        [DataMember]
        public string Note { get; set; }
        
    }
}