﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class SeriesActionRequest
    {
        [DataMember]
        public string OrganizationID { get; set; }

        [DataMember]
        public string OrganizationName { get; set; }

        [DataMember]
        public string ProfileID { get; set; }

        [DataMember]
        public string Reasons { get; set; }

        [DataMember]
        public string Notes { get; set; }

        [DataMember]
        public int NoteOption { get; set; }

        [DataMember]
        public SeriesItem[] SeriesListing { get; set; }

        [DataMember]
        public string UserName { get; set; }
        
        [DataMember]
        public string UserId { get; set; }

        [DataMember]
        public string ProfileName { get; set; }

        [DataMember]
        public string SalesTerritory { get; set; }

        [DataMember]
        public string ERPAccountNumber { get; set; }    
    }

   
}