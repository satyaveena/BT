﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class SeriesProfileResponse
    {
        [DataMember]
        public string ProfileName { get; set; }

        [DataMember]
        public string ProgramType { get; set; }

        [DataMember]
        public string ProfileType { get; set; }

        [DataMember]
        public int? TotalSeries { get; set; }

        [DataMember]
        public int? TotalCopies { get; set; }

        [DataMember]
        public string SalesTerritory { get; set; }

        [DataMember]
        public string ERPAccountNumber { get; set; }

        [DataMember]
        public string Status { get; set; }
        
        [DataMember]
        public List<string> PONumberList { get; set; }

        [DataMember]
        public DateTime UpdatedDate { get; set; }

        [DataMember]
        public string UpdatedBy { get; set; }

        [DataMember]
        public string SalesName { get; set; }

        [DataMember]
        public string SalesPhone { get; set; }

        [DataMember]
        public string SalesEmail { get; set; }
    }
}