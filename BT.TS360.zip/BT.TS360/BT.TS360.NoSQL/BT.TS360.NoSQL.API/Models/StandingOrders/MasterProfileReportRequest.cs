﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class MasterProfileReportRequest
    {
        public string OrganizationName { get; set; }
        public string OrganizationId { get; set; }
        public string ReportType { get; set; }
        public string LoginName { get; set; }
        public string UserId { get; set; }
    }
}