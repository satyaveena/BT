﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class DuplicateSeriesDetailsResponse
    {
        [DataMember]
        public Series SeriesInformation{ get; set;}
        [DataMember]
        public List<ProfiledSeries> ProfiledSeriesList { get; set; }
    }
}