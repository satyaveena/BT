﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class ChangeRequestProfileRequest
    {
        public bool NewCatalogingAndProcessing { get; set; }
        public string ProfileType { get; set; }
        public string Programs { get; set; }
        public string NewProfileName { get; set; }
        public int TotalCopies { get; set; }
        public int TotalSeries { get; set; }
        public string ProfileName { get; set; }
        public string ProfileId { get; set; }
        public string ERPAccountNumber { get; set; }
        public string SalesTerritory { get; set; }
        public string SubmittedByUserName { get; set; }
        public string SubmittedByUserId { get; set; }
        public string OrganizationName { get; set; }
        public string OrganizationId { get; set; }
        public string RequestType { get; set; }
        public string Instructions { get; set; }
        public string ContactName { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string State { get; set; }
        public List<NotificationUser> NotificationUsers { get; set; }
        public List<NotificationUser> NewNotificationUsers { get; set; } //Karine: TFS#23709
        public List<string> AreasOfInterest { get; set; }

    }

}