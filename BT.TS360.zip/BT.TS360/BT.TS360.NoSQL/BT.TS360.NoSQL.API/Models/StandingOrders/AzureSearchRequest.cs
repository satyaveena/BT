﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
     [DataContract]
    public class AzureSearchRequest
    {
        public string UserID { get; set; }

        public string OrganizationID { get; set; }

        public string SearchField { get; set; }
        
        public string SearchValue { get; set; }

        public string SortOnField { get; set; }

        public string SortOnDirection { get; set; }

        public int PageNumber { get; set; }

        public int? PageSize { get; set; }

        public string SearchSeriesQuery { get; set; }

        public string SearchRefinersQuery { get; set; }

        public string PublicationCategoryId { get; set; }

        public string PublicationSubcategoryId { get; set; }

        public string ContentListID { get; set; }

        public string ProductType { get; set; }
    }
}