﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class RequestStatusQueueResponse
    {
        [DataMember]
        public List<ChangeRequests> ChangeRequestList { get; set; }
     
        [DataMember]
        public List<string> AccountRepNameList { get; set; }

        [DataMember]
        public List<string> RequestedByList { get; set; } // submitted by

        [DataMember]
        public List<string> ProfileNameList { get; set; }
        [DataMember]
        public List<string> AccountNumberList { get; set; }

        [DataMember]
        public List<string> OrgNameList { get; set; }

        [DataMember]
        public bool RequestStatusQueueHasActiveRequests { get; set; }

        [DataMember]
        public long TotalItems { get; set; }

        [DataMember]
        public long TotalNew { get; set; }

        [DataMember]
        public long TotalInProcess { get; set; }

        [DataMember]
        public long TotalRemoved { get; set; }

        [DataMember]
        public long TotalCompleted { get; set; }

    }
}