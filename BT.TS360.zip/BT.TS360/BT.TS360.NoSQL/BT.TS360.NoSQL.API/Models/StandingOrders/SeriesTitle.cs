﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class SeriesTitle
    {
        public string BTKey { get; set; }
        public string TitleLongName { get; set; }
        public string TitleShortName { get; set; }

    }

}