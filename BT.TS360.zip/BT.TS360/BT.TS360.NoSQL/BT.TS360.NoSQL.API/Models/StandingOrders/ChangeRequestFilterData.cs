﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class ChangeRequestFilterDataRequest
    {
        public string ProfileId { get; set; }
        public string OrganizationId { get; set; }
        public string SearchKeyword { get; set; }
        public string FilterType { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }

    public class ChangeRequestFilterDataResponse
    {
        public List<string> DataList { get; set; }
    }

}