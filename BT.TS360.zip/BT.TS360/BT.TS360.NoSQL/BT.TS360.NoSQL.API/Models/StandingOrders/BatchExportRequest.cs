﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class BatchExportRequest
    {
        public string OrganizationId { get; set; }
        public string ProfileId { get; set; }
        public string SubmittedByUserName { get; set; }
        public string SubmittedByUserId { get; set; }
    }
}