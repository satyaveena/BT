﻿using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using Microsoft.Azure.Search.Models;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class SeriesListResponse
    {
        [DataMember]
        public long? Count { get; set; }

        [DataMember]

        public SeriesItem[] SeriesListing { get; set; }

        [DataMember]

        public FacetSearchResult[] FacetListing { get; set; }

        [DataMember]
        public FacetResults Facets { get; set; }
    }

    [DataContract]
    public class FacetSearchResult
    {
        [DataMember]
        public string FacetKey { get; set; }

        [DataMember]
        public string DisplayText { get; set; }

        [DataMember]
        public FacetSearchItem[] FacetSearchItem { get; set; }

        [DataMember]
        public long? Count { get; set; }
    }

    [DataContract]
    public class FacetSearchItem
    {
        [DataMember]
        public string FacetValue { get; set; }

        [DataMember]
        public string FacetText { get; set; }

        [DataMember]
        public long? Count { get; set; }

        [DataMember]
        public int Sequence { get; set; }

    }

    [DataContract]
    public class SeriesItem
    {
        [DataMember]
        public string SeriesID { get; set; }

        [DataMember]
        public string SeriesName { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public string RequestStatus { get; set; }

        [DataMember]
        public string Publisher { get; set; }

        [DataMember]
        public string Frequency { get; set; }

        [DataMember]
        public string ProgramType { get; set; }

        [DataMember]
        public string Format { get; set; }

        [DataMember]
        public string Audience { get; set; }

        [DataMember]
        public string LastIssueISBN { get; set; }
        
        [DataMember]
        public string LastIssueBTKey { get; set; }

        [DataMember]
        public string LastIssueName { get; set; }

        [DataMember]
        public DateTime? LastIssuePublishDate { get; set; }

        [DataMember]
        public decimal? LastIssueListPrice { get; set; }

        [DataMember]
        public string LastIssueEdition { get; set; }

        [DataMember]
        public string ImageSmallUrl
        {
            get
            {
                return ContentCafeHelper.GetJacketImageUrl(LastIssueISBN, ImageSize.Small, !string.IsNullOrEmpty(LastIssueISBN));
            }
            set { var temp = value; }
        }

        [DataMember]
        public string ImageMediumUrl
        {
            get
            {
                return ContentCafeHelper.GetJacketImageUrl(LastIssueISBN, ImageSize.Medium, !string.IsNullOrEmpty(LastIssueISBN));
            }
            set { var temp = value; }
        }

        [DataMember]
        public string ImageLargeUrl
        {
            get
            {
                return ContentCafeHelper.GetJacketImageUrl(LastIssueISBN, ImageSize.Large, !string.IsNullOrEmpty(LastIssueISBN));
            }
            set { var temp = value; }
        }

        [DataMember]
        public string ProfiledSeriesId { get; set; }

        [DataMember]
        public string ProfileID { get; set; }

        [DataMember]
        public string ProfileName { get; set; }

        [DataMember]
        public string ShippingAccountNumber { get; set; }

        [DataMember]
        public string StartDataType { get; set; }

        [DataMember]
        public SeriesPurchaseOrder[] PurchaseOrders { get; set; }

        [DataMember]
        public SeriesPOQuantity[] POQuantityList { get; set; }

        [DataMember]
        public string SalesTerritory { get; set; }

        [DataMember]
        public bool HasRelatedSeries { get; set; }

        [DataMember]
        public List<string> RelatedSeriesIDs { get; set; }

        [DataMember]
        public List<string> ProfileIDListByOrg { get; set; }

        [DataMember]
        public string Distributor { get; set; }

        [DataMember]
        public bool HasBindingPreferences { get; set; }

        [DataMember]
        public List<BindingPreference> BindingPreferences { get; set; }

        [DataMember]
        public List<string> Programs { get; set; }

        [DataMember]
        public string PO1FormatPreferenceLiteral { get; set; }

        [DataMember]
        public int POCount { get; set; }

        [DataMember]
        public int? TotalPrimaryQuantity { get; set; }
    }

    [DataContract]
    public class SeriesPurchaseOrder
    {
        [DataMember]
        public string PurchaseOrderID { get; set; }
        
        [DataMember]
        public string POLineNumber { get; set; }

        [DataMember]
        public string StartDate { get; set; }  
        
        [DataMember]
        public string ShippingPreference { get; set; }  
        
        [DataMember]
        public string Status { get; set; }
        
        [DataMember]
        public string FormatPreferencePrimary { get; set; }  
        
        [DataMember]
        public int FormatPreferencePrimaryQuantity { get; set; }  
        
        [DataMember]
        public string FormatPreferenceSecondary { get; set; } 
        
        [DataMember]
        public int FormatPreferenceSecondaryQuantity { get; set; } 
        
        [DataMember]
        public string FormatPreferenceString { get; set; } 
        
    }

    [DataContract]
    public class SeriesPOQuantity
    {
        [DataMember]
        public string POLineNumber { get; set; }

        [DataMember]
        public int FormatPreferencePrimaryQuantity { get; set; }  
    }
}