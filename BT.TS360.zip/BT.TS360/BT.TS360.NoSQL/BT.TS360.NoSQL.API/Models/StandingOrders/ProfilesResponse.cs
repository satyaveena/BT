﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;
using Microsoft.Azure.Search.Models;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class ProfilesResponse
    {
        [DataMember]
        public long TotalItems { get; set; }
        [DataMember]
        public List<ProfileDetailsResponse> Profiles { get; set; }
        [DataMember]
        public FacetResults Facets { get; set; }
    }

    [DataContract]
    public class ProfileDetailsResponse
    {
        [DataMember]
        public string ProfileId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string ProfileType { get; set; }
        [DataMember]
        public DateTime? CreatedDate { get; set; }

        [DataMember]
        public string CreatedDateString
        {
            get
            {
                if (!CreatedDate.HasValue) return "";

                return CreatedDate.Value.ToString(CommonConstants.DefaultDateTimeFormat);
            }
            set { var temp = value; }
        }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public string AccountId { get; set; }
        [DataMember]
        public string AccountNumber { get; set; }
        [DataMember]
        public string AccountType { get; set; }
        [DataMember]
        public string ProgramId { get; set; }
        [DataMember]
        public string ProgramName { get; set; }
        [DataMember]
        public List<string> Programs { get; set; }
        [DataMember]
        public int TotalSeries { get; set; }
        [DataMember]
        public int TotalCopies { get; set; }
        [DataMember]
        public DateTime? UpdatedDate { get; set; }
        [DataMember]
        public string LastUpdatedString
        {
            get
            {
                if (!UpdatedDate.HasValue) return "";

                return UpdatedDate.Value.ToString(CommonConstants.DefaultDateTimeFormat);
            }
            set { var temp = value; }
        }
        [DataMember]
        public string PendingStatus { get; set; }
        [DataMember]
        public string PendingRequestType { get; set; }
        [DataMember]
        public string PrimaryContactName { get; set; }
        [DataMember]
        public string Phone { get; set; }
        [DataMember]
        public string Fax { get; set; }
        [DataMember]
        [EmailAddress(ErrorMessage = "Not a valid email")]
        public string Email { get; set; }
        [DataMember]
        public string ShipToAddress { get; set; }
        [DataMember]
        public string San { get; set; }
        [DataMember]
        public string Notes { get; set; }
        [DataMember]
        public string UpdatedBy { get; set; }

        [DataMember]
        public string Line1 { get; set; }
        [DataMember]
        public string Line2 { get; set; }
        [DataMember]
        public string Line3 { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string Zipcode { get; set; }
        [DataMember]
        public List<string> NotificationUsers { get; set; }
        [DataMember]
        public string SalesTerritory { get; set; }
        [DataMember]
        public string Status { get; set; }


        [DataMember]
        public string SalesName { get; set; }

        [DataMember]
        public string SalesPhone { get; set; }

        [DataMember]
        public string SalesEmail { get; set; }
    }

    [DataContract]
    public class Address
    {
        [DataMember]
        public string PrimaryAddress { get; set; }
        [DataMember]
        public string Address1 { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string ZipCode { get; set; }
    }

    [DataContract]
    public class AreaResponse
    {
        [DataMember]
        public string AreaId { get; set; }
        [DataMember]
        public string AreaName { get; set; }
        [DataMember]
        public string ParentAreaId { get; set; }
        [DataMember]
        public string ParentAreaName { get; set; }
    }

    [DataContract]
    public class ProfileListResponse
    {
        [DataMember]
        public List<ProfileListDetails> Profiles { get; set; }
    }
    [DataContract]
    public class ProfileListDetails
    {
        [DataMember]
        public string ProfileId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string AccountNumber { get; set; }
        [DataMember]
        public List<string> Programs { get; set; }
        [DataMember]
        public string SalesTerritory { get; set; }
        [DataMember]
        public string Status { get; set; }
    }
}