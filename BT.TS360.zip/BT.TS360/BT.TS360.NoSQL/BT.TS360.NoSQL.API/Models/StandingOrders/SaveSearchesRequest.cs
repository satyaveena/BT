﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class SaveSearchesRequest
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string SearchName { get; set; }
        public string SaveSearchesID { get; set; }
        public string SearchSeriesQuery { get; set; }
        public string SearchRefinerQuery { get; set; }
        public bool isOverwrite { get; set; }
    }
}