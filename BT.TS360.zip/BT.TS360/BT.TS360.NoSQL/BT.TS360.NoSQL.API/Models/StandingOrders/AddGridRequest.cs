﻿using BT.TS360.NoSQL.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class AddGridRequest
    {
        [DataMember]
        public string OrganizationID { get; set; }

        [DataMember]
        public string OrganizationName { get; set; }

        [DataMember]
        public string ProfileID { get; set; }

        [DataMember]
        public string UserName { get; set; }
        
        [DataMember]
        public string UserId { get; set; }

        [DataMember]
        public string ProfileName { get; set; }

        [DataMember]
        public string SalesTerritory { get; set; }

        [DataMember]
        public string ERPAccountNumber { get; set; }
        
        [DataMember]
        public string ChangeType { get; set; }
        
        [DataMember]
        public List<AddGridRequestGridLine> PurchaseOrderGrids { get; set; }   
    }

    [DataContract]
    public class AddGridRequestGridLine
    {
        [DataMember]
        public string AgencyCode { get; set; }

        [DataMember]
        public string ItemType { get; set; }

        [DataMember]
        public string Collection { get; set; }

        [DataMember]
        public string UserCode1 { get; set; }

        [DataMember]
        public string UserCode2 { get; set; }

        [DataMember]
        public string UserCode3 { get; set; }

        [DataMember]
        public string UserCode4 { get; set; }

        [DataMember]
        public string UserCode5 { get; set; }

        [DataMember]
        public string UserCode6 { get; set; }

        [DataMember]
        public string CallNumber { get; set; }

        [DataMember]
        public int Quantity { get; set; }
    }

   
}