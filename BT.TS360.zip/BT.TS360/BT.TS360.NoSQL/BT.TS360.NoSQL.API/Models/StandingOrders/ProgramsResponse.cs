﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;
using Microsoft.Azure.Search.Models;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class ProgramsResponse
    {
        [DataMember]
        public long TotalItems { get; set; }
        [DataMember]
        public List<ProgramResponse> Programs { get; set; }
    }

    [DataContract]
    public class ProgramResponse
    {
        [DataMember]
        public string ProgramName { get; set; }
        [DataMember]
        public string ProgramId { get; set; }
        [DataMember]
        public long TotalProfiles { get; set; }
    }
}