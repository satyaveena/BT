﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class BatchExportBackgroundRequest
    {
        public string OrganizationId { get; set; }

        public string ProfileId { get; set; }

        public string OrganziationName { get; set; }

        public string ProfileName { get; set; }

        public string AccountNumber { get; set; }

        public string SubmittedByUserName { get; set; }
    }
}