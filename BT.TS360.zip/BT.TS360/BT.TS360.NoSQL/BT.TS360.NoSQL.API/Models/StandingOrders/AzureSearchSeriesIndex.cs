﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class AzureSearchSeriesIndexRoot
    {
        [DataMember]
        public List<AzureSearchSeriesIndex> IndexDocument { get; set; }
    }
 
    [DataContract]
    public class AzureSearchSeriesIndex
    {
        
        [DataMember]
        public string SeriesID { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public string Publisher { get; set; }

        [DataMember]
        public string Frequency { get; set; }

     
        [DataMember]
        public string Format { get; set; }

        [DataMember]
        public string Audience { get; set; }

        [DataMember]
        public string ISBN { get; set; }

        [DataMember]
        public string BTKey { get; set; }

        [DataMember]
        public string Edition { get; set; }

        [DataMember]
        public DateTime PublicationDate { get; set; }

        [DataMember]
        public decimal ListPrice { get; set; }

        [DataMember]
        public List<string> Programs { get; set; }

        [DataMember]
        public string ProgramsForSort { get; set; }

        [DataMember]
        public List<string> ProfileOrgIDList { get; set; }  //ProfiledSeries.OrganizationID|ProfiledSeries.ProfileID|ProfiledSeries.RequestStatus

        [DataMember]
        public bool HasRelatedSeries { get; set; }

        [DataMember]
        public string StartDataType { get; set; }

        // Karine: removed: from PBI##25138
        /*[DataMember]
        public List<string> POQuantityList { get; set; }*/

        [DataMember]
        public string Distributor { get; set; }

        [DataMember]
        public List<string> RelatedSeriesIDs { get; set; }

        [DataMember]
        public bool HasBindingPreferences { get; set; }

        [DataMember]
        public List<BindingPreference> BindingPreferences { get; set; }

    }
}