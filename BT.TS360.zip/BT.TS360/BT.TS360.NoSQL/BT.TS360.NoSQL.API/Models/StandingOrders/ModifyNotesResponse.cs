﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;
using Microsoft.Azure.Search.Models;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class ModifyNotesResponse
    {
        [DataMember]
        public string ProfiledSeriesID { get; set; }

        [DataMember]
        public string SeriesID { get; set; }

        [DataMember]
        public string Note { get; set; }

    }
}