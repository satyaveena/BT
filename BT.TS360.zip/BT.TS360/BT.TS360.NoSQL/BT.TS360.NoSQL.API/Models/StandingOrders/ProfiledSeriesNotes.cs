﻿using BT.TS360.NoSQL.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class ProfiledSeriesNotes
    {
        public string ProfiledSeriesID { get; set; }
        public string SeriesID { get; set; }
        public string RequestStatus { get; set; }
        public string Note { get; set; }
        public FootprintInformation FootprintInformation { get; set; }



    }
}