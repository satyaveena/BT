﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class DuplicateSeriesResponse
    {
        [DataMember]
        public List<SeriesDuplicate> SeriesDuplicateList { get; set; }
    }

    [DataContract]
    public class SeriesDuplicate
    {
        [DataMember]
        public string SeriesId { get; set; }
        [DataMember]
        public bool IsDupe { get; set; }
    }
}