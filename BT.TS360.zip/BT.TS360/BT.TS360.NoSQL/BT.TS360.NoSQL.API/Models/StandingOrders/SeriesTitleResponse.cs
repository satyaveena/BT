﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class SeriesTitleResponse
    {
        [DataMember]
        public SeriesTitle[] SeriesTitleListing { get; set; }

        [DataMember]
        public long TotalTitles { get; set; }
    }

    [DataContract]
    public class SeriesTitle
    {
        [DataMember]
        public string SeriesId { get; set; }

        [DataMember]
        public string BTKey { get; set; }

        [DataMember]
        public string TitleLongName { get; set; }

        [DataMember]
        public string TitleShortName { get; set; }

        [DataMember]
        public string Publisher { get; set; }

        [DataMember]
        public DateTime? PublishDateTime { get; set; }

        [DataMember]
        public string Edition { get; set; }

        [DataMember]
        public string ISBN { get; set; }

        [DataMember]
        public string InventoryStatus { get; set; }

        [DataMember]
        public decimal? ListPrice { get; set; }

        [DataMember]
        public string ImageSmallUrl
        {
            get
            {
                return ContentCafeHelper.GetJacketImageUrl(ISBN, ImageSize.Small, !string.IsNullOrEmpty(ISBN));
            }
            set { var temp = value; }
        }

        [DataMember]
        public string ImageMediumUrl
        {
            get
            {
                return ContentCafeHelper.GetJacketImageUrl(ISBN, ImageSize.Medium, !string.IsNullOrEmpty(ISBN));
            }
            set { var temp = value; }
        }

        [DataMember]
        public string ImageLargeUrl
        {
            get
            {

                return ContentCafeHelper.GetJacketImageUrl(ISBN, ImageSize.Large, !string.IsNullOrEmpty(ISBN));
            }
            set { var temp = value; }
        }

        [DataMember]
        public string Programs { get; set; }

        [DataMember]
        public List<string> ProgramsList { get; set; }

        [DataMember]
        public string Audiences { get; set; }

        [DataMember]
        public string LatestIssueName { get; set; }

        [DataMember]
        public string Cycle { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public string Annotations { get; set; }

        [DataMember]
        public string PhysicalFormat { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public string FormatIconClass
        {
            get
            {
                var cssClass = string.Empty;
                switch (this.ProductCode)
                {
                    case ProductCodeConstants.EBOOK:
                        cssClass = "icon-ebook";
                        break;
                    case ProductCodeConstants.BOOK:
                        if (this.PhysicalFormat == ProductFormatConstants.Book_PreLoaded_Audio_Player)
                        {
                            cssClass = "icon-preloaded-audio";
                            break;
                        }
                        else
                        {
                            cssClass = "icon-book";
                        }
                        break;
                    default:
                        cssClass = string.Empty;
                        break;
                }
                return cssClass;
            }
        }

        [DataMember]
        public string Format { get; set; }

        [DataMember]
        public string PrimaryResponsibleParty { get; set; }
        
        [DataMember]
        public string StartDataType { get; set; }

        [DataMember]
        public string ReportCode { get; set; }

        [DataMember]
        public bool HasRelatedSeries { get; set; }

        [DataMember]
        public List<string> RelatedSeriesIDs { get; set; }

        [DataMember]
        public bool HasBindingPreferences { get; set; }

        [DataMember]
        public List<BindingPreference> BindingPreferences { get; set; }
    }

}