﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class SeriesListRequest    
    {
        public string OrganizationID { get; set; } // #24982

        public string ProfileID { get; set; }

        public string SeriesID { get; set; }

        public string SortOnField { get; set; }

        public string SortOnDirection { get; set; }

        public int PageNumber { get; set; }

        public int PageSize { get; set; }

        public List<ProfiledSeriesFacet> Facets { get; set; }

        public string KeywordType { get; set; }

        public string KeywordValue { get; set; }

        public string PONumber { get; set; }

        public bool? EnableGetProfileIDByOrg { get; set; } // #24982
    }

    public class ProfiledSeriesFacet
    {
        public string FacetValue { get; set; }
        public string FacetId { get; set; }
    }
}