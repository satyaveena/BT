﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class SearchSavedSearchRequest
    {
        public string SavedSearchID { get; set; }

        public string UserID { get; set; }

        public string SortOnField { get; set; }

        public string SortOnDirection { get; set; }

        public int PageNumber { get; set; }

        public int PageSize { get; set; }
    }
}