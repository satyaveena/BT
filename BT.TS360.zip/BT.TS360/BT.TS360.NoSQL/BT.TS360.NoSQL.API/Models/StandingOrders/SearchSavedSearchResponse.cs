﻿using BT.TS360.NoSQL.API.Common.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
     [DataContract]
    public class SearchSavedSearchResponse
    {
         [DataMember]
         public SearchSeriesItem[] SearchSeriesItemListing { get; set; }
    }

     [DataContract]
     public class SearchSeriesItem
     {
         [DataMember]
         public string SavedSearchID { get; set; }

         /*[DataMember]
         public string UserID { get; set; }*/

         [DataMember]
         public string SearchName { get; set; }

         [DataMember]
         public string[] ProgramType { get; set; }

         [DataMember]
         public string[] Format { get; set; }

         [DataMember]
         public string[] SeriesStatus { get; set; }

         [DataMember]
         public string[] AreasOfInterest { get; set; }

         [DataMember]
         public string[] SeriesAudience { get; set; }

         [DataMember]
         public SearchTermCriteria[] SearchTermCriteria { get; set; }

         [DataMember]
         public string LastDateUpdated { get; set; }

         [DataMember]
         public string LastIssuePublishDateValue { get; set; }
         
         [DataMember]
         public string[] LastIssuePublishDateRange { get; set; }

         [DataMember]
         public decimal LastIssueListPriceMinimum { get; set; }

         [DataMember]
         public decimal LastIssueListPriceMaximum { get; set; }

         [DataMember]
         public string[] SeriesWithinProfile { get; set; }

         [DataMember]
         public DateTime PublishDateFrom { get; set; }

         [DataMember]
         public DateTime PublishDateThrough { get; set; }
         // help method

         [DataMember]
         public bool HasFilter { get; set; }

         [DataMember]
         public string ProgramTypeText
         {
             get
             {
                string programTypeText = "";

                if (ProgramType != null && ProgramType.Length > 0)
                {
                    bool hasAllElements = (ProgramType.Length == SearchConstants.SiteTerm.PROGRAM_TYPES.Length);
                    foreach (string str in ProgramType)
                    {
                        if (hasAllElements && !SearchConstants.SiteTerm.PROGRAM_TYPES.Contains(str))
                        {
                            hasAllElements = false;
                        }

                        programTypeText += ((programTypeText != "" ? ",": "") + str);
                    }

                    if (hasAllElements)
                    {
                        programTypeText = "All";
                    }
                }

                return programTypeText;
             }
         }


         [DataMember]
         public string FormatText
         {
             get
             {
                 string formatText = "";

                 if (Format != null && Format.Length > 0)
                 {
                     bool hasAllElements = (Format.Length == SearchConstants.SiteTerm.SERIES_FORMAT.Length);
                     foreach (string str in Format)
                     {
                         if (hasAllElements && !SearchConstants.SiteTerm.SERIES_FORMAT.Contains(str))
                         {
                             hasAllElements = false;
                         }

                         formatText += ((formatText != "" ? "," : "") + str);
                     }

                     if (hasAllElements)
                     {
                         formatText = "All";
                     }
                 }

                 return formatText;
             }
         }

         [DataMember]
         public string SeriesStatusText
         {
             get
             {
                 string seriesStatusText = "";

                 if (SeriesStatus != null && SeriesStatus.Length > 0)
                 {
                     bool hasAllElements = (SeriesStatus.Length == SearchConstants.SiteTerm.SERIES_STATUS.Length);
                     foreach (string str in SeriesStatus)
                     {
                         if (hasAllElements && !SearchConstants.SiteTerm.SERIES_STATUS.Contains(str))
                         {
                             hasAllElements = false;
                         }
                         seriesStatusText += ((seriesStatusText != "" ? "," : "") + str);
                     }

                     if (hasAllElements)
                     {
                         seriesStatusText = "All";
                     }
                 }
                 return seriesStatusText;
             }
         }

         [DataMember]
         public string SeriesAudienceText
         {
             get
             {
                 string seriesAudienceText = "";

                 if (SeriesAudience != null && SeriesAudience.Length > 0)
                 {
                     bool hasAllElements = (SeriesAudience.Length == SearchConstants.SiteTerm.SERIES_AUDIENCE.Length);
                     foreach (string str in SeriesAudience)
                     {
                         if (hasAllElements && !SearchConstants.SiteTerm.SERIES_AUDIENCE.Contains(str))
                         {
                             hasAllElements = false;
                         }
                         seriesAudienceText += ((seriesAudienceText != "" ? "," : "") + str);
                     }

                     if (hasAllElements)
                     {
                         seriesAudienceText = "All";
                     }
                 }
                 return seriesAudienceText;
             }
         }

         [DataMember]
         public string AreasOfInterestText
         {
             get
             {
                 string areasOfInterestText = "";

                 if (AreasOfInterest != null && AreasOfInterest.Length > 0)
                 {
                     bool hasAllElements = (AreasOfInterest.Length == SearchConstants.SiteTerm.AREA_OF_INTEREST.Length);
                     foreach (string str in AreasOfInterest)
                     {
                         if (hasAllElements && !SearchConstants.SiteTerm.AREA_OF_INTEREST.Contains(str))
                         {
                             hasAllElements = false;
                         }
                         areasOfInterestText += ((areasOfInterestText != "" ? "," : "") + str);
                     }

                     if (hasAllElements)
                     {
                         areasOfInterestText = "All";
                     }
                 }
                 return areasOfInterestText;
             }
         }

         [DataMember]
         public string LastIssueListPriceText
         {
             get
             {
                 string lastIssueListPriceText = "";

                 if (LastIssueListPriceMinimum > 0 && LastIssueListPriceMaximum > 0)
                 {
                     lastIssueListPriceText = String.Format("{0:C} to {1:C}", LastIssueListPriceMinimum, LastIssueListPriceMaximum); 
                 }

                 return lastIssueListPriceText;
             }
         }

     }

     [DataContract]
     public class SearchTermCriteria
     {
         [DataMember]
         public string Attribute { get; set; } // Series/Author Name , Series ID

         [DataMember]
         public string SearchType { get; set; } // Containts

         [DataMember]
         public string SearchTermValue { get; set; }

         [DataMember]
         public string SearchJoin { get; set; } // AND, OR

         [DataMember]
         public int Sequence { get; set; }
     }
}