﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class ProfileOrderStatusRequest
    {
        public string OrganizationName { get; set; }
        public string OrganizationPhone { get; set; }
        public string ProfileName { get; set; }
        public string AccountNumber { get; set; }
        public string UserEmail { get; set; }
        public string LoginName { get; set; }
        
    }
}