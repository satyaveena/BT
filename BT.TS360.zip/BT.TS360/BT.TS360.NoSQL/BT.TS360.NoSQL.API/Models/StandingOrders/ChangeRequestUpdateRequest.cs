﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class ChangeRequestUpdateRequest
    {
        public List<ProfileChangeRequestUpdate> ProfileChangeRequestUpdateList { get; set; }
        public List<ProfiledSeriesChangeRequestUpdate> ProfiledSeriesChangeRequestUpdateList { get; set; }
        public string UpdatedBy { get; set; }
    }

    public class ProfileChangeRequestUpdate
    {
        public string RequestStatus { get; set; }
        public string RequestType { get; set; }
        public string ChangeRequestId { get; set; }
        public string ProfileId { get; set; }
        public List<NotificationUser> NotificationUsers { get; set; }
    }

    public class ProfiledSeriesChangeRequestUpdate
    {
        public string RequestStatus { get; set; }
        public string RequestType { get; set; }
        public string ChangeRequestId { get; set; }
        public string ProfiledSeriesId { get; set; }
    }
}