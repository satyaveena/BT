﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class EmailProfileRequest
    {
        public string EmailTo { get; set; }
        public string Subject { get; set; }
        public string Notes { get; set; }
        public bool CompressFile { get; set; }
        public string OrganizationName { get; set; }
        public string ProfileId { get; set; }
        public string SubmittedByUserName { get; set; }
    }
}

