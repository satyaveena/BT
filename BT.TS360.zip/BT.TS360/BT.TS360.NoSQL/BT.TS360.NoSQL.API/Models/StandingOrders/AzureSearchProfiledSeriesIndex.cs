﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class AzureSearchProfiledSeriesIndexRoot
    {
        [DataMember]
        public List<AzureSearchProfiledSeriesIndex> Document { get; set; }
    }

    [DataContract]
    public class AzureSearchProfiledSeriesIndex
    {
        [DataMember]
        public string ProfiledSeriesID { get; set; }

        [DataMember]
        public string SeriesID { get; set; }

        [DataMember]
        public string SeriesName { get; set; }

        [DataMember]
        public string ProfileName { get; set; }

        [DataMember]
        public string ShippingAccountNumber { get; set; }
       
        [DataMember]
        public string SeriesStatus { get; set; }

        [DataMember]
        public string RequestStatus { get; set; }

        [DataMember]
        public string Publisher { get; set; }

        [DataMember]
        public string Frequency { get; set; }

        /*[DataMember]
        public string[] SeriesPrograms { get; set; }*/

        [DataMember]
        public string Format { get; set; }

        [DataMember]
        public string Audience { get; set; }

        [DataMember]
        public string ISBN { get; set; }

        [DataMember]
        public string Edition { get; set; }

        [DataMember]
        public string PublicationDate { get; set; }

        [DataMember]
        public string ListPrice { get; set; }

    }
}