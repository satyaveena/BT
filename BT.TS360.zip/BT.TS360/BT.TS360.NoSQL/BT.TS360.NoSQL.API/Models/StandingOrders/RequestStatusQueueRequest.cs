﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class RequestStatusQueueRequest
    {

        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SortBy { get; set; }
        public string SortDirection { get; set; }
        public List<string> RequestStatus { get; set; }
        public List<string> RequestType { get; set; }
        public List<string> OrganizationLocationFilters { get; set; }
        public List<string> AccountRepName { get; set; }
        public List<string> RequestedBy { get; set; } // submitted by
        public List<string> ProfileName { get; set; }
        public List<string> AccountNumber { get; set; }
        public List<string> OrgName { get; set; }

    }
}