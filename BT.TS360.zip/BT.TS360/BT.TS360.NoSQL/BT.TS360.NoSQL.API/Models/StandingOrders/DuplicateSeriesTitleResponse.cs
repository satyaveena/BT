﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    [DataContract]
    public class DuplicateSeriesTitleResponse
    {
        [DataMember]
        public List<SeriesDuplicateTitle> SeriesDuplicateTitleList { get; set; }
    }

    [DataContract]
    public class SeriesDuplicateTitle
    {
        [DataMember]
        public string BTKey { get; set; }
        [DataMember]
        public string DuplicateProfiledSeriesIdList { get; set; }
        [DataMember]
        public List<string> SeriesIdList { get; set; }
    }
}