﻿using BT.TS360.NoSQL.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class EditProfiledSeriesListRequest
    {
        public EditProfiledSeriesRequest[] EditProfiledSeriesRequests { get; set; }
    }

    public class EditProfiledSeriesRequest
    {
        public string ProfileId { get; set; }
        public string OrganizationName { get; set; }
        public string OrganizationId { get; set; }
        public string ProfileName { get; set; }
        public string ERPAccountNumber { get; set; }
        public string SalesTerritory { get; set; }
        public string SeriesId { get; set; }
        public string SeriesName { get; set; }
        public string Frequency { get; set; }
        public string Programs { get; set; }
        public string NewNotes { get; set; }
        public string NewSpecialInstruction { get; set; }
        public string SubmittedByUserName { get; set; }
        public string SubmittedByUserId { get; set; }
        public List<PO> NewPurchaseOrders { get; set; }
        public string OldNotes { get; set; }
        public string OldSpecialInstruction { get; set; }
        public List<PO> OldPurchaseOrders { get; set; }
        public string ProfiledSeriesId { get; set; }
        public string RequestType { get; set; }
    }

}