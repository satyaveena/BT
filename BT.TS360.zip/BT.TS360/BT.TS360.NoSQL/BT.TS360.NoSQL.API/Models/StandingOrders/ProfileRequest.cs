﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Models.StandingOrders
{
    public class ProfileRequest
    {
        public string OrgId { get; set; }
        public string OrgName { get; set; }
        public string ProfileId { get; set; }
        public string ProfileName { get; set; }
        public string ProfileType { get; set; }
        public bool CatalogAndProcessing { get; set; }
        public string ContactName { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string Notes { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string CreatedByUserId { get; set; }

        public List<string> AreasOfInterest { get; set; }

        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Line3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }

        public string TsUserName { get; set; }
        public List<NotificationUser> NotificationUsers { get; set; }
        public string SalesTerritory { get; set; }
    }

    public class AreaOfInterest
    {
        public string AreaId { get; set; }
        public string AreaName { get; set; }
        public string ParentAreaId { get; set; }
        public string ParentAreaName { get; set; }
    }

}