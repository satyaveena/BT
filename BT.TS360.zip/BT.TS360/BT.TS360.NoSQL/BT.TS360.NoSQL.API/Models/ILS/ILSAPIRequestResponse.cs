﻿using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.ILS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.ILS
{
    [DataContract]
    public class ILSAPIRequestResponse
    {
        [DataMember]
        public DateTime RequestDateTime { get; set; }
        [DataMember]
        public DateTime ResponseDateTime { get; set; }
        [DataMember]
        public string BasketSummaryId { get; set; }
        [DataMember]
        public List<LineItemAPILogDetails> ILSLineItemLogs { get; set; }
        [DataMember]
        public string ErrorType { get; set; }
        [DataMember]
        public string ErrorDescription { get; set; }
        [DataMember]
        public string NewCartId { get; set; }
        [DataMember]
        public string ILSStatus { get; set; }
    }


}