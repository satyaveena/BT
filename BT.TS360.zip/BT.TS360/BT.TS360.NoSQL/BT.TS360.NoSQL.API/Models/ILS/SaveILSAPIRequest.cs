﻿using BT.TS360.NoSQL.Data.ILS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Models.ILS
{
    public class SaveILSAPIRequest
    {
        public string BasketSummaryId { get; set; }
        public string ILSStatus { get; set; }
        public string NewCartId { get; set; }
        public string UserId { get; set; }
        public DateTime RequestDateTime { get; set; }
        public DateTime ResponseDateTime { get; set; }
        public string ErrorType { get; set; }
        public string ErrorDescription { get; set; }
        public List<LineItemAPILogDetails> ILSLineItemLogs { get; set; }


    }
}