﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.API.Common.Configuration;

namespace BT.TS360.NoSQL.API.Services
{
    public class DemandHistoryService: IDemandHistoryService
    {
        MongoClient _client;
        MongoServer _server;
        MongoDatabase _database;
        MongoCollection<BsonDocument> _product;


        public DemandHistoryService(string connection)
        {

            _client = new MongoClient(connection);
            _server = _client.GetServer();
            _database = _server.GetDatabase(CommonConstants.ProductsDatabaseName);
            _product = _database.GetCollection<BsonDocument>(CommonConstants.ProductsCollectionName);
        
        }

        public NoSqlServiceResult<DemandHistoryResponse> GetDemandHistory(DemandHistoryRequest request)
        {
            var noSqlServiceResult = new NoSqlServiceResult<DemandHistoryResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                var pageIndex = request.PageIndex ?? 1;
                int pageSize = 12;
                int? prePublicationDemand = null;
                int? postPublicationDemand = null;
                int publicationDate = 0;
                string primaryWarehouse = ConvertWareHouseCode(request.PrimaryWareHouseCode);
                string secondaryWarehouse = ConvertWareHouseCode(request.SecondaryWareHouseCode);

                if (request.BTKey == null)
                {
                    return FormatErrorResponse(DemandHistoryErrorCode.MISSING_BTKEY_CODE);
                }
                DemandHistoryResponse demandHistoryResult = new DemandHistoryResponse();
                var query = Query.EQ("_id", request.BTKey);
                BsonDocument productsDocument = null;
                int retries = AppSettings.MaxConnectionRetries;
                int retryWaitTime = AppSettings.RetryWaitTime;
                while (retries > 0)
                {
                    try
                    {
                        productsDocument = _product.FindOne(query);
                        break;
                    }
                    catch
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }
                //BsonDocument productsDocument = _product.FindOne(query);
                if (productsDocument == null)
                {
                    return FormatErrorResponse(DemandHistoryErrorCode.PRODUCT_NOT_FOUND);
                }
                Product product = null;
                product = BindDemand(productsDocument, out publicationDate);

                if (product != null && product.DemandData != null && product.DemandData.Count > 0)
                {

                    var demandList = product.DemandData.ToList();
                    if (publicationDate > 0)
                    {
                        postPublicationDemand = demandList.Sum(x => int.Parse(x.Period) >= publicationDate ? x.Quantity : 0);
                        prePublicationDemand = demandList.Sum(x => int.Parse(x.Period) < publicationDate ? x.Quantity : 0);
                    }

                    demandHistoryResult.DemandHistoryResults = getDemandHistoryPeriod(pageIndex, pageSize, demandList, primaryWarehouse, secondaryWarehouse);
                    demandHistoryResult.PostPublicationDemand = postPublicationDemand;
                    demandHistoryResult.PrePublicationDemand = prePublicationDemand;
                }

                noSqlServiceResult.Status = NoSqlServiceStatus.Success;
                noSqlServiceResult.Data = demandHistoryResult;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new DemandHistoryResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999";
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "DemandHistoryService", request.ToJson());
            }

            return noSqlServiceResult;
        }

        public Product BindDemand(BsonDocument bsdoc, out int publicationDate)
        {
            Product product = new Product();
            publicationDate = 0;
            if (bsdoc.Contains("PublicationDate"))
            {
                product.PublicationDate = bsdoc["PublicationDate"].AsNullableDateTime;

                if (product.PublicationDate.HasValue)
                    int.TryParse(product.PublicationDate.Value.ToString("yyyyMM"), out publicationDate);
            }
            
            List<Demand> DemandList = new List<Demand>();
            if (bsdoc.Contains("DemandData"))
            {
                BsonArray baInventory = bsdoc["DemandData"].AsBsonArray;
                foreach (BsonValue value in baInventory)
                {
                    Demand demand = BsonSerializer.Deserialize<Demand>(value.ToJson());
                    DemandList.Add(demand);
                }
            }

            product.DemandData = DemandList;
            return product;
        }

        public DemandHistoryPeriod[] getDemandHistoryPeriod(int pageIndex, int pageSize, List<Demand> demandList, string primaryWarehouse, string secondaryWarehouse)
        {
            var groupedDemandList = demandList.GroupBy(b => b.Period).OrderByDescending(x => x.Key).ToList();
            List<DemandHistoryPeriod> demandHistoryResultsList = new List<DemandHistoryPeriod>();
            foreach (var demand in groupedDemandList.Skip((pageIndex - 1) * pageSize).Take(pageSize))
            {
                var demandHistoryPeriod = new DemandHistoryPeriod();
                demandHistoryPeriod.DemandPeriod = demand.Key;
                List<DemandHistoryWareHouses> WareHouses = new List<DemandHistoryWareHouses>();
                foreach (var DemandWarehouse in demand)
                {
                    var wareHouse = new DemandHistoryWareHouses();
                    wareHouse.DemandQuantity = DemandWarehouse.Quantity ?? 0;
                    wareHouse.WarehouseID = DemandWarehouse.WarehouseCode == CommonConstants.WarehouseConstants.RNO ? CommonConstants.WarehouseConstants.REN : DemandWarehouse.WarehouseCode;
                    wareHouse.WarehouseType = " ";
                    if (!string.IsNullOrEmpty(primaryWarehouse) && primaryWarehouse == wareHouse.WarehouseID)
                    {
                        wareHouse.WarehouseType = "P";
                    }
                    if (!string.IsNullOrEmpty(secondaryWarehouse) && secondaryWarehouse == wareHouse.WarehouseID)
                    {
                        wareHouse.WarehouseType = "S";
                    }
                    WareHouses.Add(wareHouse);
                }
                demandHistoryPeriod.WareHouses = WareHouses.ToArray();
                demandHistoryResultsList.Add(demandHistoryPeriod);

            }
            if (demandHistoryResultsList.Count() > 0)
                return demandHistoryResultsList.ToArray();
            else
                return null;
        }

        private NoSqlServiceResult<DemandHistoryResponse> FormatErrorResponse(string errCode)
        {
            var noSqlServiceResult = new NoSqlServiceResult<DemandHistoryResponse> { Status = NoSqlServiceStatus.Fail };

            noSqlServiceResult.ErrorCode = errCode;
            noSqlServiceResult.Data = new DemandHistoryResponse();

            return noSqlServiceResult;
        }

        private string ConvertWareHouseCode(string wareHouseCode)
        {
            if (!string.IsNullOrEmpty(wareHouseCode) && string.Equals(wareHouseCode, CommonConstants.WarehouseConstants.RNO))
                return CommonConstants.WarehouseConstants.REN;
            else
                return wareHouseCode;
        }
    }
}