﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;
using System.Threading;

using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.API.Models.ILS;
using BT.TS360.NoSQL.Data.ILS;

namespace BT.TS360.NoSQL.API.Services.ILS
{
    public class ILSService
    {
        readonly IMongoCollection<ILSAPIRequest> _ILSAPIRequestLog;
        readonly IMongoCollection<BsonDocument> _ILSAPIRequestLogBson;

        public ILSService()
        {
            var client = new MongoClient(ConnectionString);
            var iCommonDatabase = client.GetDatabase(CommonConstants.CommonDatabaseName);

            _ILSAPIRequestLog = iCommonDatabase.GetCollection<ILSAPIRequest>(CommonConstants.ILSAPIRequestCollectionName);
            _ILSAPIRequestLogBson = iCommonDatabase.GetCollection<BsonDocument>(CommonConstants.ILSAPIRequestCollectionName);
        }

        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }

        public async Task<NoSqlServiceResult<ILSAPIRequestResponse>> GetILSAPIRequest(string basketSummaryId)
        {
            var response = new NoSqlServiceResult<ILSAPIRequestResponse> { Status = NoSqlServiceStatus.Success };
            try
            {

                var ilsAPIRequestResponse = new ILSAPIRequestResponse();
                var sort = Builders<ILSAPIRequest>.Sort.Descending("RequestDateTime");
                var filter = Builders<ILSAPIRequest>.Filter.Eq("BasketSummaryId", basketSummaryId);

                var ilsAPIRequest = await GetILSAPIRequestFromMongo(filter, sort);

                if (ilsAPIRequest != null)
                {

                    if (ilsAPIRequest.ErrorType != "Information")
                    {
                        ilsAPIRequestResponse.ILSLineItemLogs = ilsAPIRequest.ILSLineItemLogs.Where(s=>s.ErrorType != "Information").ToList();
                        ilsAPIRequestResponse.RequestDateTime = ilsAPIRequest.RequestDateTime;
                        ilsAPIRequestResponse.ResponseDateTime = ilsAPIRequest.ResponseDateTime;
                        ilsAPIRequestResponse.BasketSummaryId = ilsAPIRequest.BasketSummaryId;
                        ilsAPIRequestResponse.ErrorType = ilsAPIRequest.ErrorType;
                        ilsAPIRequestResponse.ErrorDescription = ilsAPIRequest.ErrorDescription;
                        ilsAPIRequestResponse.NewCartId = ilsAPIRequest.NewCartId;
                        ilsAPIRequestResponse.ILSStatus = ilsAPIRequest.ILSStatus;
                        response.Data = ilsAPIRequestResponse;
                    }
                }
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ILSService GetILSAPIRequest", string.Format("Message: {0}, Stack Trace: {1}",
                    exception.Message, exception.StackTrace));
            }
            return response;
        }

        public async Task<NoSqlServiceResult<ILSOrderValidationResponseStatus>> GetILSOrderValidationResponseStatus(string basketSummaryId)
        {
            var response = new NoSqlServiceResult<ILSOrderValidationResponseStatus> { Status = NoSqlServiceStatus.Success };
            try
            {

                var ilsAPIRequestResponse = new ILSAPIRequestResponse();

                var ilsAPILogDoc = await GetILSOrderValidationResponseStatusFromMongo(basketSummaryId);

                if (ilsAPILogDoc != null)
                {
                    if (ilsAPILogDoc.Contains(MongoDBFields.PROCESSING_STATUS))
                    {
                        // get Response document by ProcessingStatus
                        BsonDocument responseDoc = null;
                        var processingStatus = ilsAPILogDoc[MongoDBFields.PROCESSING_STATUS].AsString;
                        switch (processingStatus)
                        {
                            case ILSProcessingStatusConstants.VALIDATION_FAILED:
                            case ILSProcessingStatusConstants.VALIDATION_RESPONSE:  // ValidationResponse status
                                if (ilsAPILogDoc.Contains(MongoDBFields.VALIDATION_RESPONSE))
                                    responseDoc = ilsAPILogDoc[MongoDBFields.VALIDATION_RESPONSE].AsBsonDocument;
                                break;
                            case ILSProcessingStatusConstants.ORDERING_VALIDATION_FAILED:
                            case ILSProcessingStatusConstants.ORDERING_RESULT_RESPONSE:
                            case ILSProcessingStatusConstants.ORDERING_RESPONSE:  // OrderResponse status
                                if (ilsAPILogDoc.Contains(MongoDBFields.ORDER_RESPONSE))
                                    responseDoc = ilsAPILogDoc[MongoDBFields.ORDER_RESPONSE].AsBsonDocument;
                                break;
                        }

                        // response Data
                        if (responseDoc != null)
                        {
                            response.Data = BsonSerializer.Deserialize<ILSOrderValidationResponseStatus>(responseDoc);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ILSService GetILSOrderValidationResponseStatus", string.Format("Message: {0}, Stack Trace: {1}",
                    exception.Message, exception.StackTrace));
            }
            return response;
        }

        /// <summary>
        /// Gets ILS ValidationRequest and ValidationResponse objects.
        /// </summary>
        /// <param name="basketSummaryId"></param>
        /// <returns></returns>
        public async Task<NoSqlServiceResult<ILSValidationRequestResponse>> GetILSILSValidationRequestResponse(string basketSummaryId)
        {
            var response = new NoSqlServiceResult<ILSValidationRequestResponse> { Status = NoSqlServiceStatus.Success };
            response.Data = new ILSValidationRequestResponse();

            try
            {
                var ilsAPIRequestResponse = new ILSAPIRequestResponse();

                var ilsAPILogDoc = await GetILSOrderValidationResponseStatusFromMongo(basketSummaryId, includeValidationRequest: true);

                if (ilsAPILogDoc != null)
                {
                    // get Validation Request document by ProcessingStatus
                    if (ilsAPILogDoc.Contains(MongoDBFields.VALIDATION_REQUEST))
                    {
                        var requestDoc = ilsAPILogDoc[MongoDBFields.VALIDATION_REQUEST].AsBsonDocument;
                        response.Data.ValidationRequest = BsonSerializer.Deserialize<ILSValidationRequest>(requestDoc);
                    }

                    BsonDocument validationResponse = null;
                    var processingStatus = ilsAPILogDoc[MongoDBFields.PROCESSING_STATUS].AsString;

                    if (processingStatus == ILSProcessingStatusConstants.ORDERING_VALIDATION_FAILED
                        && ilsAPILogDoc.Contains(MongoDBFields.ORDER_RESPONSE))
                    {
                        validationResponse = ilsAPILogDoc[MongoDBFields.ORDER_RESPONSE].AsBsonDocument;
                    }
                    // get Validation Response document by ProcessingStatus
                    else if (ilsAPILogDoc.Contains(MongoDBFields.VALIDATION_RESPONSE))
                    {
                        validationResponse = ilsAPILogDoc[MongoDBFields.VALIDATION_RESPONSE].AsBsonDocument;
                    }

                    if (validationResponse != null)
                        response.Data.ValidationResponse = BsonSerializer.Deserialize<ILSOrderValidationResponseStatus>(validationResponse);
                }
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ILSService GetILSILSValidationRequestResponse", string.Format("Message: {0}, Stack Trace: {1}",
                    exception.Message, exception.StackTrace));
            }

            return response;
        }


        public async Task<NoSqlServiceResult<bool>> SaveILSAPIRequest(SaveILSAPIRequest saveILSAPIRequest)
        {
            var response = new NoSqlServiceResult<bool> { Data = true, Status = NoSqlServiceStatus.Success };
            var ilsAPIRequest = new ILSAPIRequest();
            var now = DateTime.Now;
            try
            {
                ilsAPIRequest.Id = ObjectId.GenerateNewId();
                ilsAPIRequest.RequestDateTime = saveILSAPIRequest.RequestDateTime;
                ilsAPIRequest.ResponseDateTime = saveILSAPIRequest.ResponseDateTime;
                ilsAPIRequest.BasketSummaryId = saveILSAPIRequest.BasketSummaryId;
                ilsAPIRequest.ILSLineItemLogs = saveILSAPIRequest.ILSLineItemLogs;
                ilsAPIRequest.ErrorType = saveILSAPIRequest.ErrorType;
                ilsAPIRequest.ErrorDescription = saveILSAPIRequest.ErrorDescription;
                ilsAPIRequest.NewCartId = saveILSAPIRequest.NewCartId;
                ilsAPIRequest.ILSStatus = saveILSAPIRequest.ILSStatus;
                ilsAPIRequest.FootprintInformation = new FootprintInformation();
                ilsAPIRequest.FootprintInformation.CreatedDate = now;
                ilsAPIRequest.FootprintInformation.CreatedByUserID = saveILSAPIRequest.UserId;
                ilsAPIRequest.FootprintInformation.UpdatedDate = now;
                ilsAPIRequest.FootprintInformation.UpdatedByUserID = saveILSAPIRequest.UserId;
               
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                while (retries > 0)
                {
                    try
                    {
                        await _ILSAPIRequestLog.InsertOneAsync(ilsAPIRequest);
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ILSService SaveILSAPIRequest", string.Format("Message: {0}, Stack Trace: {1}",
                    exception.Message, exception.StackTrace));
            }

            return response;
        }


    
        private async Task<ILSAPIRequest> GetILSAPIRequestFromMongo(FilterDefinition<ILSAPIRequest> filter, SortDefinition<ILSAPIRequest> sort)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new ILSAPIRequest();
            while (retries > 0)
            {
                try
                {
                    response = await _ILSAPIRequestLog.Find<ILSAPIRequest>(filter).Sort(sort).Limit(1).FirstOrDefaultAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }

        private async Task<BsonDocument> GetILSOrderValidationResponseStatusFromMongo(string basketSummaryId, bool includeValidationRequest = false)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new BsonDocument();

            var sort = Builders<BsonDocument>.Sort.Descending("FootprintInformation.UpdatedDate");

            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq(MongoDBFields.EXTERNAL_ID, basketSummaryId);

            filter = filter & builder.In(MongoDBFields.PROCESSING_STATUS, new List<string> { ILSProcessingStatusConstants.VALIDATION_FAILED,
                                                                                ILSProcessingStatusConstants.ORDERING_VALIDATION_FAILED,
                                                                                ILSProcessingStatusConstants.ORDERING_RESPONSE,
                                                                                ILSProcessingStatusConstants.ORDERING_RESULT_RESPONSE});

            var projection = Builders<BsonDocument>.Projection.Include(MongoDBFields.PROCESSING_STATUS)
                                                              .Include(MongoDBFields.VALIDATION_RESPONSE)
                                                              .Include(MongoDBFields.ORDER_RESPONSE);

            if (includeValidationRequest)
                projection = projection.Include(MongoDBFields.VALIDATION_REQUEST);

            while (retries > 0)
            {
                try
                {
                    response = await _ILSAPIRequestLogBson.Find<BsonDocument>(filter).Project(projection).Sort(sort).Limit(1).FirstOrDefaultAsync();
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }
    }
}