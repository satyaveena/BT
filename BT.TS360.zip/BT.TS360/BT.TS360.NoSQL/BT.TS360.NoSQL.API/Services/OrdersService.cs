﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;
using System.Threading;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using BT.TS360.NoSQL.Data.AzureSearch;

using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.API.Models.Orders;

namespace BT.TS360.NoSQL.API.Services
{
    public class OrdersService
    {
        readonly IMongoCollection<BsonDocument> _iOrderLinesCollection;

        public OrdersService()
        {
            var client = new MongoClient(ConnectionString);
            var iOrdersDatabase = client.GetDatabase(CommonConstants.OrdersDatabaseName);

            _iOrderLinesCollection = iOrdersDatabase.GetCollection<BsonDocument>(CommonConstants.OrderLinesCollectionName);

        }

        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }

        internal async Task<NoSqlServiceResult<bool>> UpdateOrderAccount(UpdateOrderAccountRequest request)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateUpdateOrderAccountRequest(request);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }

                var filter = Builders<BsonDocument>.Filter.In("ShipToAccountNumber", request.ShipToAccountNumbers);
                var update = Builders<BsonDocument>.Update.Set("FootprintInformation.UpdatedDate", DateTime.Now)
                                                    .Set("FootprintInformation.UpdatedBy", "OrderService");

                if (string.Equals(request.UpdateStatus, "Add", StringComparison.OrdinalIgnoreCase))
                {
                    update = update.Set("NeedsDupeCheckUpdate", true)
                        .Set("OrganizationID", request.OrganizationID);
                }
                else
                {
                    update = update.Set("NeedsDupeCheckAccountUpdate", true);
                }
                int retries = AppSettings.MaxConnectionRetries;
                int retryWaitTime = AppSettings.RetryWaitTime;
                while (retries > 0)
                {
                    try
                    {
                        var result = await _iOrderLinesCollection.UpdateManyAsync(filter, update);
                        break;
                    }
                    catch (Exception ex)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999";
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "UpdateOrderAccount");
            }
            return noSqlServiceResult;
        }


        private string ValidateUpdateOrderAccountRequest(UpdateOrderAccountRequest request)
        {
            if (request == null)
            {
                return "Request is required";
            }

            if (string.IsNullOrEmpty(request.OrganizationID))
            {
                return "Organization Id is required";

            }

            if (request.ShipToAccountNumbers == null || request.ShipToAccountNumbers.Count < 1)
            {
                return "Shipping Account is required";

            }

            if (!string.Equals(request.UpdateStatus, "Add", StringComparison.OrdinalIgnoreCase) && !string.Equals(request.UpdateStatus, "Delete", StringComparison.OrdinalIgnoreCase))
            {
                return "Invalid Update Type: " + request.UpdateStatus;

            }
            return null;
        }
    }
}
