﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Web;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;

using System.Threading.Tasks;

namespace BT.TS360.NoSQL.API.Services
{
    public class InventoryDemandService: IInventoryDemandService
    {
        IMongoClient _client;
        IMongoDatabase _database;
        IMongoCollection<BsonDocument> _product;

        public InventoryDemandService() : this("") { }
        

        public InventoryDemandService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                //connection = "mongodb://BTDevSQL02:27017";
                connection = AppSettings.MongoDBConnectionString;
            }

            _client = new MongoClient(connection);
            _database = _client.GetDatabase(CommonConstants.ProductsDatabaseName);
            _product = _database.GetCollection<BsonDocument>(CommonConstants.ProductsCollectionName);
        
        }

        public async Task<NoSqlServiceResult<InventoryDemandResponse>> GetInventory(InventoryDemandRequest request)
        {
            var noSqlServiceResult = new NoSqlServiceResult<InventoryDemandResponse> { Status = NoSqlServiceStatus.Success };

            try
            {

                // Validation
                string error = Validate(request);

                if (!string.IsNullOrEmpty(error))
                {
                    return (FormatErrorResponse(error));
                }

                InventoryDemandResponse inventoryResult = new InventoryDemandResponse();

                bool isVIPEnabled = IsVIPEnabled(request.VIPEnabled);
                bool isDisplaySuperWarehouse = IsDisplaySuperWarehouse(isVIPEnabled, request.MarketType, request.CountryCode);

                int retries = AppSettings.MaxConnectionRetries;
                int retryWaitTime = AppSettings.RetryWaitTime;

                List<Product> productResults = new List<Product>();
                List<BsonDocument> productsDocumentList = new List<BsonDocument>();

                var filter = Builders<BsonDocument>.Filter.In("_id", new BsonArray(request.BTKeys.Select(b => b.BTKey).ToArray()));

                while (retries > 0)
                {
                    try
                    {
                        productsDocumentList = await _product.Find(filter).ToListAsync<BsonDocument>();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }


                foreach (var document in productsDocumentList)
                {
                    // process document
                    Product mProduct = BindProduct(document);
                    productResults.Add(mProduct);
                }

                IEnumerable<string> notExistProductList = request.BTKeys.Select(req => req.BTKey).ToArray().Except(productResults.Select( m => m.BTKEY).ToArray());
                foreach (string notExistBTKey in notExistProductList)
                {
                    Product nProduct = BindProduct(notExistBTKey);
                    productResults.Add(nProduct);
                }

                BTKeyInventoryResult[] btKeyInventoryResultList = new BTKeyInventoryResult[productResults.Count()];
                int btkeyCount = 0;

                foreach (Product product in productResults)
                {
                    BTKeyInventoryResult btKeyInventoryResult = new BTKeyInventoryResult();
                    btKeyInventoryResult.BTKey = product.BTKEY;

                    var requestBTKey = request.BTKeys.Where(b => b.BTKey == product.BTKEY).FirstOrDefault();

                    btKeyInventoryResult.LineItem = requestBTKey.PagePosition; 
                    string leIndicator = requestBTKey.LEIndicator; 
                    string accountInventoryType = requestBTKey.AccountInventoryType; 
                    string inventoryReserveNumber = requestBTKey.InventoryReserveNumber; 

                    string inventoryStatus = String.Empty;
                    BTKeyWarehouseResult[] btKeyWarehouseResultList  =
                        AppendInventoryDemand(product, request.Warehouses.Select(w => w.WarehouseID).ToList(), isVIPEnabled, isDisplaySuperWarehouse, leIndicator, accountInventoryType, inventoryReserveNumber, 
                        request.BookPrimaryWarehouseCode, request.BookSecondaryWarehouseCode, request.EntertainmentPrimaryWarehouseCode, request.EntertainmentSecondaryWarehouseCode, request.MarketType, request.CountryCode, out inventoryStatus);
                    btKeyInventoryResult.InventoryStatus = inventoryStatus;
                    btKeyInventoryResult.TotalLast30Demand = (product.ThirtyDayDemandTotalQty.HasValue ? product.ThirtyDayDemandTotalQty.Value : 0);

                    btKeyInventoryResult.VIPTitle = (string.IsNullOrEmpty(request.VIPEnabled) || request.VIPEnabled == "0")?
                                                        string.Empty :
                                                        (btKeyWarehouseResultList.Where(v => (v.WarehouseId == WarehouseConstants.VIE || 
                                                                                                v.WarehouseId == WarehouseConstants.VIM ||
                                                                                                v.WarehouseId == WarehouseConstants.SUP)).Select(s => (s.InStockForRequest.HasValue ? s.InStockForRequest : 0) ).Sum() > 0 ? "1" : "0");
                    btKeyInventoryResult.Warehouses = btKeyWarehouseResultList;
                    btKeyInventoryResult.HasDemand = request.OnItemDetail ? 
                                                        (product.HasDemandHistory.HasValue? product.HasDemandHistory.Value: false) : 
                                                        false;
                    btKeyInventoryResultList[btkeyCount] = btKeyInventoryResult;
                    btkeyCount++;

                }// end for each loop

                inventoryResult.InventoryResults = btKeyInventoryResultList.OrderBy( b => b.LineItem).ToArray();
                noSqlServiceResult.Data = inventoryResult;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new InventoryDemandResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "InventoryDemandServices", request.ToJson());
            }

            return noSqlServiceResult;
        }


        public Product BindProduct(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            //Product p = BsonSerializer.Deserialize<Product>(bsdoc.ToJson());

            Product p = new Product();

            if (bsdoc.Contains("_id"))
                p.BTKEY = bsdoc["_id"].AsString;

            if (bsdoc.Contains("ProductCode"))
                p.ProductCode = bsdoc["ProductCode"].AsString;

            if (bsdoc.Contains("RightToVend"))
                p.RightToVend = bsdoc["RightToVend"].AsNullableBoolean;

            if (bsdoc.Contains("ReportCode"))
                p.ReportCode = bsdoc["ReportCode"].AsString;

            if (bsdoc.Contains("PublicationDate"))
            {
                p.PublicationDate = bsdoc["PublicationDate"].AsNullableDateTime;
                if (p.PublicationDate.HasValue)
                {
                    p.PublicationDate = p.PublicationDate.Value.Date;
                }
            }
            if (bsdoc.Contains("ThirtyDayDemandTotalQty"))
                p.ThirtyDayDemandTotalQty = bsdoc["ThirtyDayDemandTotalQty"].AsNullableInt32;

            List<Inventory> inventoryList = new List<Inventory>();
            List<ThirtyDayDemand> demandList = new List<ThirtyDayDemand>();

            if (bsdoc.Contains("InventoryData"))
            {
                BsonArray baInventory = bsdoc["InventoryData"].AsBsonArray;

                foreach (BsonValue value in baInventory)
                {
                    Inventory inventory = BsonSerializer.Deserialize<Inventory>(value.ToJson());

                   inventoryList.Add(inventory);
                }
            }

            p.HasDemandHistory = (bsdoc.Contains("DemandData"));

            if (bsdoc.Contains("ThirtyDayDemandData"))
            {
                BsonArray baThirtyDayDemand = bsdoc["ThirtyDayDemandData"].AsBsonArray;

                var last30Days = baThirtyDayDemand.ToList();

                foreach (BsonValue value in last30Days)
                {
                    ThirtyDayDemand demand = BsonSerializer.Deserialize<ThirtyDayDemand>(value.ToJson());

                    demandList.Add(demand);
                }
            }

            p.InventoryData = inventoryList;
            p.ThirtyDayDemandData = demandList;

            return p;
        }


        public Product BindProduct(string btKey)
        {
            Product p = new Product();

            p.BTKEY = btKey;
            p.InventoryData = new List<Inventory>();
            p.ThirtyDayDemandData = new List<ThirtyDayDemand>();

            return p;
        }

        public string Validate(InventoryDemandRequest request)
        {
            // check null BTKeys: ErrorCode: 1
            if (request.BTKeys == null || request.BTKeys.Count() == 0)
            {
                return InventoryDemandErrorCode.EMPTY_BTKEY_CODE;
            }

            // check invalid LE indicator: ErrorCode: 2
            if (request.BTKeys.Where(b => b.LEIndicator != "0" && b.LEIndicator != "1").Count() > 0)
            {
                return InventoryDemandErrorCode.INVALID_LE_INDICATOR_CODE;
            }

            // check empty warehouses: ErrorCode: 3
            if (request.Warehouses == null || request.Warehouses.Count() == 0)
            {
                return InventoryDemandErrorCode.EMPTY_WAREHOUSES_CODE;
            }

            // check invalid VIP Enabled: ErrorCode: 4
            if (request.VIPEnabled != null && 
                (request.VIPEnabled != "0" && request.VIPEnabled != "1"))
            {
                return InventoryDemandErrorCode.INVALID_VIP_ENABLED_CODE;
            }

            // check invalid Market Type: ErrorCode: 5
            if (request.VIPEnabled != null &&
                request.VIPEnabled == "1" &&
                request.MarketType == null )
            {
                return InventoryDemandErrorCode.INVALID_MARKET_TYPES_CODE;
            }

            // check invalid Market Type: ErrorCode: 5
            if (request.VIPEnabled != null &&
                request.VIPEnabled == "1" &&
                request.MarketType !=  null &&
                request.MarketType != ((int)MarketType.Retail).ToString() &&
                request.MarketType != ((int)MarketType.AcademicLibrary).ToString() &&
                request.MarketType != ((int)MarketType.PublicLibrary).ToString() && 
                request.MarketType != ((int)MarketType.SchoolLibrary).ToString() )
            {
                return InventoryDemandErrorCode.INVALID_MARKET_TYPES_CODE;
            }

            // check country code: ErrorCode: 6
            if (request.CountryCode == null)
            {
                return InventoryDemandErrorCode.EMPTY_COUNTRY_CODE;
            }

            return null;
        }


        private bool IsDisplaySuperWarehouse(bool isVIPEnabled, string marketType, string countryCode)
        {
            bool retVal = false;

            if (isVIPEnabled)
            {
                if (!string.IsNullOrEmpty(marketType))
                {
                    if (
                            marketType == ((int)MarketType.AcademicLibrary).ToString() ||
                            marketType == ((int)MarketType.PublicLibrary).ToString() ||
                            marketType == ((int)MarketType.SchoolLibrary).ToString() ||
                            (marketType == ((int)MarketType.Retail).ToString() && !IsUSCountry(countryCode))
                        )
                       
                    {
                        retVal = true;
                    }
                }
            }
            return retVal;
        }

        private bool IsVIPEnabled(string vipEnabled)
        {
            return (!string.IsNullOrEmpty(vipEnabled) && vipEnabled == "1");
        }

        private bool IsUSCountry(string countryCode)
        {
            bool isUS = false;

            if (!string.IsNullOrEmpty(countryCode))
            {
                isUS = (countryCode == "US" || countryCode == "USA");
            }
            return isUS;

        }

        private bool IsIngramSuperWarehouse(string marketType, string countryCode)
        {
            bool retVal = false;

            if (!string.IsNullOrEmpty(marketType))
            {
                if (
                        marketType == ((int)MarketType.AcademicLibrary).ToString() ||
                        marketType == ((int)MarketType.PublicLibrary).ToString() ||
                        marketType == ((int)MarketType.SchoolLibrary).ToString() ||
                        (marketType == ((int)MarketType.Retail).ToString() && !IsUSCountry(countryCode))
                    )
                {
                    retVal = true;
                }
            }
          
            return retVal;
        }

        private bool IsValidAccountInventoryType(string inventoryAccountType, string requestInventoryAccountType)
        {
            if (string.IsNullOrEmpty(inventoryAccountType) ||
                     inventoryAccountType.Replace(" ", "") == "" ||
                     inventoryAccountType == "A")
            {
                return true;
            }
            else
            {
                if (!string.IsNullOrEmpty(requestInventoryAccountType) && requestInventoryAccountType.Length > 1)
                {
                    return (inventoryAccountType.IndexOfAny(requestInventoryAccountType.ToCharArray()) > -1);
                }
                else if (requestInventoryAccountType == inventoryAccountType)
                {
                    return true;
                }
            }

            return false;
        }

        private bool IsValidInventoryReserveNumber(string customerNumber, string requestInventoryReserveNumber)
        {
            if (string.IsNullOrEmpty(customerNumber) ||
                customerNumber.Replace(" ", "") == "" ||
                customerNumber == requestInventoryReserveNumber)
            {
                return true;
            }

            return false;
        }

        private BTKeyWarehouseResult[] AppendInventoryDemand(Product p, List<string> lstWarehouses, bool isVIPEnabled, bool isDisplaySuperWarehouse, string leIndicator, string accountInventoryType, string inventoryReserveNumber, 
            string bookPrimaryWarehouseCode, string bookSecondaryWarehouseCode,
            string entertainmentPrimaryWarehouseCode, string entertainmentSecondaryWarehouseCode,
            string marketType, string countryCode,
            out string inventoryStatus)
        {
            if (lstWarehouses.Where(s => (s == WarehouseConstants.RNO || s == WarehouseConstants.REN)).Count() > 1)
            {
                lstWarehouses.RemoveAll(str => str.Contains(WarehouseConstants.RNO));
            }
            
            SortedDictionary<string, BTKeyWarehouseResult> dictWareHouseResult = new SortedDictionary<string, BTKeyWarehouseResult>();

            bool rightToVend = false;
            if (p.RightToVend.HasValue)
            {
                rightToVend = p.RightToVend.Value;
            }

            foreach (string whCode in lstWarehouses)
            {
                // RNO into REN
                string warehouseCode = whCode.Replace(WarehouseConstants.RNO, WarehouseConstants.REN);

                if (
                        (warehouseCode == WarehouseConstants.VIE || warehouseCode == WarehouseConstants.VIM) &&
                        (isDisplaySuperWarehouse || !isVIPEnabled)
                    )
                {
                    continue;
                }

                if (
                      (warehouseCode == WarehouseConstants.COM && (p.ProductCode == ProductCodeConstants.MOVIE || p.ProductCode == ProductCodeConstants.MUSIC))
                  )
                {
                    continue;
                }

                // EBOOK with RightToVend flag ON: Set 9999 In Stock Request
                if (!dictWareHouseResult.ContainsKey(warehouseCode))
                {
                    dictWareHouseResult.Add(warehouseCode,
                        (rightToVend && p.ProductCode == ProductCodeConstants.EBOOK ? 
                                    new BTKeyWarehouseResult(warehouseCode, InventoryDemandGeneral.EBOOK_INVENTORY_IN_STOCK_REQUEST) : 
                                    new BTKeyWarehouseResult(warehouseCode)));
                }
            }

            int? vipOnOrderQTY = 0;
            int? vipAvailableQTY = 0;
            int? vipLast30DaysDemand = 0;

            int? viiOnOrderQTY= 0;
            int? viiAvailableQTY = 0;
            int? viiLast30DaysDemand = 0;
            bool isIngram = false;

            if (p.ProductCode == ProductCodeConstants.EBOOK)
            {
                vipAvailableQTY = isDisplaySuperWarehouse && rightToVend ? InventoryDemandGeneral.EBOOK_INVENTORY_IN_STOCK_REQUEST : 0;
            } 
            else
            {
                List<Inventory> lsFilteredInventory =
                    p.InventoryData.Where(i => IsValidAccountInventoryType(i.InventoryType, accountInventoryType)
                                            && IsValidInventoryReserveNumber(i.CustomerNumber, inventoryReserveNumber)).Select(res => { return res; }).ToList();

                foreach (Inventory inventory in lsFilteredInventory)
                {
                    string inventoryWarehouseCode = inventory.WarehouseCode.Replace(WarehouseConstants.RNO, WarehouseConstants.REN);

                    if (dictWareHouseResult.ContainsKey(inventoryWarehouseCode))
                    {
                        BTKeyWarehouseResult btKeyWarehouseResult = dictWareHouseResult[inventoryWarehouseCode];

                        btKeyWarehouseResult.OnOrderQuantity += inventory.OnOrderQTY;
                        btKeyWarehouseResult.InStockForRequest += (leIndicator == "0" ? inventory.AvailableQTY : inventory.LEAQTY);

                        dictWareHouseResult[inventoryWarehouseCode] = btKeyWarehouseResult;
                    }
                    else if (inventoryWarehouseCode == WarehouseConstants.VII)
                    {
                        isIngram = true;
                        viiOnOrderQTY += inventory.OnOrderQTY;
                        viiAvailableQTY += (leIndicator == "0" ? inventory.AvailableQTY : inventory.LEAQTY);
                    }
                    else if (
                                isDisplaySuperWarehouse &&
                                (inventoryWarehouseCode == WarehouseConstants.VIE || inventoryWarehouseCode == WarehouseConstants.VIM) &&
                                lstWarehouses.Any(str => str.Contains(inventoryWarehouseCode))
                            )
                    {
                        vipOnOrderQTY += inventory.OnOrderQTY;
                        vipAvailableQTY += (leIndicator == "0" ? inventory.AvailableQTY : inventory.LEAQTY);
                    }

                }

            }

            foreach (ThirtyDayDemand demand in p.ThirtyDayDemandData)
            {
                string demandWarehouseCode = demand.WarehouseCode.Replace(WarehouseConstants.RNO, WarehouseConstants.REN);

                if (dictWareHouseResult.ContainsKey(demandWarehouseCode))
                {
                    BTKeyWarehouseResult btKeyWarehouseResult = dictWareHouseResult[demandWarehouseCode];

                    btKeyWarehouseResult.Last30DayDemand = demand.Quantity;

                    dictWareHouseResult[demandWarehouseCode] = btKeyWarehouseResult;
                }
                else if (demandWarehouseCode == WarehouseConstants.VII)
                {
                    viiLast30DaysDemand += demand.Quantity;
                }
                else if (isDisplaySuperWarehouse && (demandWarehouseCode == WarehouseConstants.VIE || demandWarehouseCode == WarehouseConstants.VIM))
                {
                    vipLast30DaysDemand += demand.Quantity;
                }
            }

            if (isIngram && (p.ProductCode == ProductCodeConstants.MOVIE || p.ProductCode == ProductCodeConstants.MUSIC))
            {
                bool isIngramSuperWarehouse = IsIngramSuperWarehouse(marketType, countryCode);

                if (dictWareHouseResult.ContainsKey(WarehouseConstants.VIM))
                {
                    dictWareHouseResult.Remove(WarehouseConstants.VIM);
                }

                if (isIngramSuperWarehouse && dictWareHouseResult.ContainsKey(WarehouseConstants.VIE))
                { 
                    dictWareHouseResult.Remove(WarehouseConstants.VIE);
                }

                string vipCode = (isIngramSuperWarehouse) ? WarehouseConstants.SUP : WarehouseConstants.VIM;
                BTKeyWarehouseResult vipResult = new BTKeyWarehouseResult(vipCode);

                vipResult.InStockForRequest = viiAvailableQTY;
                vipResult.Last30DayDemand = viiLast30DaysDemand;
                vipResult.OnOrderQuantity = viiOnOrderQTY;

                dictWareHouseResult.Add(vipCode, vipResult);
            }
            else if (
                    isDisplaySuperWarehouse && 
                    vipAvailableQTY >= AppSettings.SuperWarehouseInventoryThreshold &&
                    lstWarehouses.Any(str => str.Contains( WarehouseConstants.VIE) || str.Contains(WarehouseConstants.VIM))
                )
            {
                BTKeyWarehouseResult superWarehouseResult = new BTKeyWarehouseResult(WarehouseConstants.SUP);
                superWarehouseResult.InStockForRequest = vipAvailableQTY;
                superWarehouseResult.Last30DayDemand = vipLast30DaysDemand;
                superWarehouseResult.OnOrderQuantity = vipOnOrderQTY;

                dictWareHouseResult.Add(WarehouseConstants.SUP, superWarehouseResult);
            }

            // Processing inventory status
            BTKeyWarehouseResult[] btKeyWarehouseResultList = (BTKeyWarehouseResult[])dictWareHouseResult.Values.ToArray();
            int totalAvailableQty = 0;

            if (!string.IsNullOrEmpty(p.ProductCode))
            {
                if (p.ProductCode == ProductCodeConstants.BOOK)
                {
                    totalAvailableQty = btKeyWarehouseResultList.Where(w => w.WarehouseId == bookPrimaryWarehouseCode ||
                                                                        w.WarehouseId == bookSecondaryWarehouseCode
                                                                    ).Sum(i => (i.InStockForRequest.HasValue ? i.InStockForRequest.Value : 0));
                }
                else if (p.ProductCode == ProductCodeConstants.MOVIE || p.ProductCode == ProductCodeConstants.MUSIC)
                {
                    totalAvailableQty = btKeyWarehouseResultList.Where(w => w.WarehouseId == entertainmentPrimaryWarehouseCode ||
                                                                       w.WarehouseId == entertainmentSecondaryWarehouseCode
                                                                   ).Sum(i => (i.InStockForRequest.HasValue ? i.InStockForRequest.Value : 0));
                }
                
                else if (p.ProductCode == ProductCodeConstants.EBOOK)
                {

                    totalAvailableQty = btKeyWarehouseResultList.Sum(i => (i.InStockForRequest.HasValue ? i.InStockForRequest.Value : 0));
                }
            }

            if (isIngram && totalAvailableQty == 0)
            {
                totalAvailableQty = btKeyWarehouseResultList.Where(w => w.WarehouseId == WarehouseConstants.VII 
                                                                    ).Sum(i => (i.InStockForRequest.HasValue ? i.InStockForRequest.Value : 0));
            }
            else if (isVIPEnabled && totalAvailableQty == 0)
            {
                totalAvailableQty = btKeyWarehouseResultList.Where(w => w.WarehouseId == WarehouseConstants.VIE ||
                                                                        w.WarehouseId == WarehouseConstants.VIM ||
                                                                        w.WarehouseId == WarehouseConstants.SUP
                                                                    ).Sum(i => (i.InStockForRequest.HasValue ? i.InStockForRequest.Value : 0));
            }
            
            inventoryStatus = GetInventoryStatus(p, totalAvailableQty);
            
            return btKeyWarehouseResultList;
        }

        private string GetInventoryStatus(Product p, int totalAvailableQty)
        {
            if (string.IsNullOrEmpty(p.ProductCode))
                return string.Empty;
            var today = DateTime.Today;
            if (p.ProductCode == ProductCodeConstants.EBOOK)
            {
                return GetEBookInventoryStatus(p);
            }
            else if (totalAvailableQty > 0)
            {
                return InventoryStatus.INSTOCK;
            }
            else if (p.ProductCode == ProductCodeConstants.BOOK)
            {
                // Book only
                if (string.IsNullOrEmpty(p.ReportCode))
                {
                    return (p.PublicationDate.HasValue && p.PublicationDate > today) ? InventoryStatus.AvailableToPreOrder : InventoryStatus.AvailableToBackOrder;
                }
                else if (p.ReportCode.ToUpper() == ReportCodeConstants.PUBLISHER_OUT_OF_STOCK)
                {
                    return InventoryStatus.AvailableToBackOrder;
                }
                else if (p.ReportCode.ToUpper() == ReportCodeConstants.NOT_YET_PUBLISHED)
                {
                    return InventoryStatus.AvailableToPreOrder;
                }
            }
            else
            {
                // Entertaninment

                if (string.IsNullOrEmpty(p.ReportCode))
                {
                    if ((!p.PublicationDate.HasValue) ||
                        (p.PublicationDate.HasValue && p.PublicationDate > today))
                    {
                        return InventoryStatus.AvailableToPreOrder;
                    }
                    else
                    {
                        return InventoryStatus.AvailableToBackOrder;
                    }
                }
                else
                {
                    if (p.ReportCode.ToUpper() == ReportCodeConstants.SUPPLIER_OUT_OF_STOCK)
                    {
                        return InventoryStatus.AvailableToBackOrder;
                    }
                    else if (p.ReportCode.ToUpper() == ReportCodeConstants.NOT_YET_PUBLISHED)
                    {
                        return InventoryStatus.AvailableToPreOrder;
                    }
                }
            }

            return string.Empty;
        }

        private string GetEBookInventoryStatus(Product p)
        {
            string eBookInventoryStatus = string.Empty;
            var today = DateTime.Today;
            if (p.PublicationDate.HasValue && p.PublicationDate > today && string.IsNullOrEmpty(p.ReportCode))
            {
                eBookInventoryStatus = InventoryStatus.AvailableToPreOrder;
            }
            else if (!string.IsNullOrEmpty(p.ReportCode) && p.ReportCode.ToUpper() == ReportCodeConstants.NOT_YET_PUBLISHED)
            {
                eBookInventoryStatus = InventoryStatus.AvailableToPreOrder;
            }
            else if (p.PublicationDate.HasValue && p.PublicationDate <= today && string.IsNullOrEmpty(p.ReportCode))
            {
                eBookInventoryStatus = InventoryStatus.AVAILABLE;
            }
            else if (p.PublicationDate.HasValue && p.PublicationDate <= today && !string.IsNullOrEmpty(p.ReportCode) && p.ReportCode.ToUpper() == ReportCodeConstants.PUBLISHER_OUT_OF_STOCK)
            {
                eBookInventoryStatus = InventoryStatus.AvailableToBackOrder;
            }
            else if (p.PublicationDate.HasValue && p.PublicationDate > today && !string.IsNullOrEmpty(p.ReportCode) && p.ReportCode.ToUpper() == ReportCodeConstants.PUBLISHER_OUT_OF_STOCK)
            {
                eBookInventoryStatus = string.Empty;
            }
            else if (!string.IsNullOrEmpty(p.ReportCode))
            {
                // put switch condition here for better code maintanance in case of the business requirement adjustment
                switch (p.ReportCode.ToUpper())
                {
                    case ReportCodeConstants.PUBLISHER_OUT_OF_STOCK_INDEFINITELY:
                        eBookInventoryStatus = string.Empty;
                        break;
                    case ReportCodeConstants.APPLY_DIRECT:
                        eBookInventoryStatus = string.Empty;
                        break;
                    case ReportCodeConstants.PUBLICATION_CANCELLED:
                        eBookInventoryStatus = string.Empty;
                        break;
                    case ReportCodeConstants.OUT_OF_PRINT:
                        eBookInventoryStatus = string.Empty;
                        break;
                    case ReportCodeConstants.UNABLE_TO_LOCATE_PUBLISHER:
                        eBookInventoryStatus = string.Empty;
                        break;
                    case ReportCodeConstants.PUBLISHER_OUT_OF_BUSINESS:
                        eBookInventoryStatus = string.Empty;
                        break;
                    default:
                        eBookInventoryStatus = string.Empty;
                        break;
                }

            }
            else
            {
                eBookInventoryStatus = string.Empty;
            }

            return eBookInventoryStatus;

        }
        private NoSqlServiceResult<InventoryDemandResponse> FormatErrorResponse(string errCode)
        {
            var noSqlServiceResult = new NoSqlServiceResult<InventoryDemandResponse> { Status = NoSqlServiceStatus.Fail };

            noSqlServiceResult.ErrorCode = errCode;

            return noSqlServiceResult;
        }

    }
}