﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;
using System.Threading.Tasks;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.Profiles;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;

namespace BT.TS360.NoSQL.API.Services.Profiles
{
    public class SiteTermService
    {
        IMongoClient _client;
        IMongoDatabase _database;
        IMongoCollection<BsonDocument> _siteTerms;

        public SiteTermService() : this("") { }

        public SiteTermService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                connection = AppSettings.MongoDBConnectionString;
            }

            _client = new MongoClient(connection);

            _database = _client.GetDatabase(CommonConstants.ProfilesDatabaseName);
            _siteTerms = _database.GetCollection<BsonDocument>(CommonConstants.SiteTermCollectionName);

        }

        public async Task<NoSqlServiceResult<SiteTermResponse>> GetSiteTerm(string siteTermType)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SiteTermResponse> { Status = NoSqlServiceStatus.Success };
            List<SiteTermCategory> listSiteTermCategory = new List<SiteTermCategory>();
            List<SiteTermItem> listSiteTermItem = new List<SiteTermItem>();
            SiteTermCategory siteTermCategory = new SiteTermCategory();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonSiteTerm = new List<BsonDocument>();

                SiteTermResponse siteTermResponse = new SiteTermResponse();

                var filter = Builders<BsonDocument>.Filter.In("SiteTermType", new string[] { siteTermType });
                var sort = Builders<BsonDocument>.Sort.Ascending("Category").Ascending("SiteTermAttributes.Sequence");

                while (retries > 0)
                {
                    try
                    {
                        bsonSiteTerm = await _siteTerms.Find(filter).Sort(sort).ToListAsync<BsonDocument>();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                foreach (var document in bsonSiteTerm)
                {
                    SiteTerm siteTerm = BindSiteTerm(document);

                    siteTermCategory = new SiteTermCategory();
                    listSiteTermItem = new List<SiteTermItem>();

                    siteTermCategory.Category = siteTerm.Category;

                    foreach (SiteTermObject siteTermAttribute in siteTerm.SiteTermAttributes)
                    {
                        listSiteTermItem.Add(new SiteTermItem(siteTermAttribute.Value, siteTermAttribute.Name));
                    }

                    siteTermCategory.SiteTermObjectList = listSiteTermItem.ToArray();
                    listSiteTermCategory.Add(siteTermCategory);
                }

                siteTermResponse.SiteTermResult = listSiteTermCategory.ToArray();
                noSqlServiceResult.Data = siteTermResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SiteTermResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetSiteTerm", siteTermType);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<SiteTermCategory>> GetSiteTermByCategry(string category)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SiteTermCategory> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonSiteTerm = new List<BsonDocument>();

                List<SiteTermItem> listSiteTermItem = new List<SiteTermItem>();
                SiteTermCategory siteTermCategory = new SiteTermCategory();

                var filter = Builders<BsonDocument>.Filter.Eq("Category", category);
                var sort = Builders<BsonDocument>.Sort.Ascending("SiteTermAttributes.Sequence");

                while (retries > 0)
                {
                    try
                    {
                        bsonSiteTerm = await _siteTerms.Find(filter).Sort(sort).ToListAsync<BsonDocument>();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                if (bsonSiteTerm != null && bsonSiteTerm.Count > 0)
                {
                    SiteTerm siteTerm = BindSiteTerm(bsonSiteTerm.First<BsonDocument>());

                    siteTermCategory.Category = siteTerm.Category;

                    foreach (SiteTermObject siteTermAttribute in siteTerm.SiteTermAttributes)
                    {
                        List<SiteTermItem> Children = new List<SiteTermItem>();

                        if (siteTermAttribute.Children != null && siteTermAttribute.Children.Count > 0)
                        {
                            foreach (SiteTermObject siteTermChildren in siteTermAttribute.Children)
                            {
                                Children.Add(new SiteTermItem(siteTermChildren.Value, siteTermChildren.Name, siteTermChildren.SearchValue, new List<SiteTermItem>()));
                            }
                        }
                        listSiteTermItem.Add(new SiteTermItem(siteTermAttribute.Value, siteTermAttribute.Name, siteTermAttribute.SearchValue, Children));
                    }

                    siteTermCategory.SiteTermObjectList = listSiteTermItem.ToArray();

                }

                noSqlServiceResult.Data = siteTermCategory;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SiteTermCategory();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetSiteTermByCategory", category);
            }

            return noSqlServiceResult;
        }

        // Get Area of Interest
        public async Task<NoSqlServiceResult<SiteTermResponse>> GetAreaOfInterest()
        {
            var noSqlServiceResult = new NoSqlServiceResult<SiteTermResponse> { Status = NoSqlServiceStatus.Success };
            List<SiteTermCategory> listSiteTermCategory = new List<SiteTermCategory>();

            try
            {
                SiteTermResponse siteTermResponse = new SiteTermResponse();

                var data = await GetSiteTermByCategry("SeriesAreaOfInterestAdultFiction");
                data.Data.CategoryLiteral = "Adult Fiction Series";
                listSiteTermCategory.Add(data.Data);

                data = await GetSiteTermByCategry("SeriesAreaOfInterestAdultSeries");
                data.Data.CategoryLiteral = "Adult Series";
                listSiteTermCategory.Add(data.Data);

                data = await GetSiteTermByCategry("SeriesAreaOfInterestAward");
                data.Data.CategoryLiteral = "Awards";
                listSiteTermCategory.Add(data.Data);

                data = await GetSiteTermByCategry("SeriesAreaOfInterestChildrenSeries");
                data.Data.CategoryLiteral = "Children's Series";
                listSiteTermCategory.Add(data.Data);

                data = await GetSiteTermByCategry("SeriesAreaOfInterestGraphicNovel");
                data.Data.CategoryLiteral = "Graphic Novels";
                listSiteTermCategory.Add(data.Data);

                data = await GetSiteTermByCategry("SeriesAreaOfInterestPopularAuthor");
                data.Data.CategoryLiteral = "Popular Authors";
                listSiteTermCategory.Add(data.Data);

                data = await GetSiteTermByCategry("SeriesAreaOfInterestTeenSeries");
                data.Data.CategoryLiteral = "Teen Series";
                listSiteTermCategory.Add(data.Data);

                siteTermResponse.SiteTermResult = listSiteTermCategory.ToArray();
                noSqlServiceResult.Data = siteTermResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SiteTermResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetAreaOfInterest", "");
            }

            return noSqlServiceResult;
        }
        private SiteTerm BindSiteTerm(BsonDocument bsdoc)
        {
            SiteTerm st = new SiteTerm();

            if (bsdoc.Contains("Category"))
                st.Category = bsdoc["Category"].AsString;

            List<SiteTermObject> siteTermObjectList = new List<SiteTermObject>();
            if (bsdoc.Contains("SiteTermAttributes"))
            {
                BsonArray baSiteTermAttributes = bsdoc["SiteTermAttributes"].AsBsonArray;

                foreach (BsonValue value in baSiteTermAttributes)
                {
                    SiteTermObject siteTermObject = BsonSerializer.Deserialize<SiteTermObject>(value.ToJson());

                    siteTermObjectList.Add(siteTermObject);
                }
            }

            st.SiteTermAttributes = siteTermObjectList;

            return st;
        }
    }
}