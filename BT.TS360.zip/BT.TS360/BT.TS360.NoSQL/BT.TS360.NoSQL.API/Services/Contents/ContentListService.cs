﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.Contents;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using System.Threading;
using System.Threading.Tasks;
using BT.TS360.NoSQL.API.Models.CMS;

namespace BT.TS360.NoSQL.API.Services.Contents
{
    public class ContentListService
    {
        IMongoClient _client;
        IMongoDatabase _database;
        IMongoCollection<BsonDocument> _lists;

        private const string TITLE_SEARCH_PAGE = "/_layouts/CommerceServer/searchresults.aspx?contentListID={0}&contentListName={1}";
        private const string SERIES_SEARCH_PAGE = "/_layouts/CommerceServer/SeriesSearchResults.aspx?contentListID={0}&contentListName={1}";

        public ContentListService() : this("") { }

        public ContentListService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                connection = AppSettings.MongoDBConnectionString;
            }

            _client = new MongoClient(connection);

            _database = _client.GetDatabase(CommonConstants.CommonDatabaseName);
            _lists = _database.GetCollection<BsonDocument>(CommonConstants.ListsCollectionName);
            
        }
        

        public async Task<NoSqlServiceResult<ContentListReponse>> GetRootCategory(string categoryLiteral)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ContentListReponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonCategory = new List<BsonDocument>();

                var filter = Builders<BsonDocument>.Filter.Eq("Literal", categoryLiteral);
                

                while (retries > 0)
                {
                    try
                    {
                        bsonCategory = await _lists.Find(filter).Limit(1).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                if (bsonCategory.Count == 1) 
                {
                    // process document
                    Lists mongoList = BindList(bsonCategory[0]);

                    var listData = await GetLists(mongoList._id.ToString());
                    return listData;
                }

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ContentListReponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetRootCategory", categoryLiteral);
            }



            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<ContentListReponse>> GetLists(string id)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ContentListReponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonLists = new List<BsonDocument>();

                ContentListReponse contentListReponse = new ContentListReponse();
                ArrayList ltContentList = new ArrayList();

                var filter = Builders<BsonDocument>.Filter.Eq("ParentID", ObjectId.Parse(id));
                var sort = Builders<BsonDocument>.Sort.Ascending("Sequence");


                while (retries > 0)
                {
                    try
                    {
                        bsonLists = await _lists.Find(filter).Sort(sort).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                foreach (var document in bsonLists)
                {
                    // process document
                    Lists mongoList = BindList(document);

                    if (mongoList != null)
                    {
                        ContentListItem contentListItem = new ContentListItem();

                        contentListItem.ID = mongoList._id.ToString();
                        contentListItem.Literal = mongoList.Literal;
                        contentListItem.ChildCount = mongoList.ChildCount.HasValue? mongoList.ChildCount.Value.ToString() : "";
                        contentListItem.LeafIndicator = mongoList.LeafIndicator.HasValue ? mongoList.LeafIndicator.Value : false;
                        if (mongoList.FileInformation != null)
                        { 
                            contentListItem.FilePathURL = mongoList.FileInformation.FilePathURL;
                        }

                        if (contentListItem.LeafIndicator)
                        {
                            contentListItem.SearchPathURL = "";

                            if (mongoList.ItemType == "Series ID")
                            {
                                contentListItem.SearchPathURL = string.Format(SERIES_SEARCH_PAGE, contentListItem.ID, HttpUtility.UrlEncode(contentListItem.Literal)) ;
                            }
                            else if (mongoList.ItemType == "ISBN")
                            {
                                contentListItem.SearchPathURL = string.Format(TITLE_SEARCH_PAGE, contentListItem.ID, HttpUtility.UrlEncode(contentListItem.Literal));
                            }

                        }

                        ltContentList.Add(contentListItem);
                    }
                }

                contentListReponse.ContentListListing = (ContentListItem[])ltContentList.ToArray(typeof(ContentListItem));
                noSqlServiceResult.Data = contentListReponse;

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ContentListReponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetLists", id);
            }

            return noSqlServiceResult;

        }

        public async Task<NoSqlServiceResult<ContentListReponse>> GetAllLists(string id)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ContentListReponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                ContentListReponse contentListReponse = new ContentListReponse();
                ArrayList ltContentList = new ArrayList();
                var bsonLists = await GetListsFromMongo(id);

                foreach (var document in bsonLists)
                {
                    // process document
                    Lists mongoList = BindList(document);

                    if (mongoList != null)
                    {
                        ContentListItem contentListItem = BindContentListItem(mongoList);
                        if(!contentListItem.LeafIndicator)
                        {
                            contentListItem.Children = await GetChildLists(contentListItem.ID);
                        }
                        ltContentList.Add(contentListItem);
                    }
                }

                contentListReponse.ContentListListing = (ContentListItem[])ltContentList.ToArray(typeof(ContentListItem));
                noSqlServiceResult.Data = contentListReponse;

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ContentListReponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetLists", id);
            }

            return noSqlServiceResult;

        }

        public async Task<List<ContentListItem>> GetChildLists(string id)
        {
            var bsonLists = await GetListsFromMongo(id);
            var contentListItemList = new List<ContentListItem>();
            foreach (var document in bsonLists)
            {
                Lists mongoList = BindList(document);
                ContentListItem contentListItem = BindContentListItem(mongoList);
                if (!contentListItem.LeafIndicator)
                {
                    contentListItem.Children = await GetChildLists(contentListItem.ID);
                }
                contentListItemList.Add(contentListItem);
            }

            return contentListItemList;
        }

        private ContentListItem BindContentListItem(Lists mongoList)
        {
            ContentListItem contentListItem = new ContentListItem();
            contentListItem.ID = mongoList._id.ToString();
            contentListItem.Literal = mongoList.Literal;
            contentListItem.ChildCount = mongoList.ChildCount.HasValue ? mongoList.ChildCount.Value.ToString() : "";
            contentListItem.LeafIndicator = mongoList.LeafIndicator.HasValue ? mongoList.LeafIndicator.Value : false;
            contentListItem.HideLink = mongoList.HideLink;
            if (mongoList.FileInformation != null)
            {
                contentListItem.FilePathURL = mongoList.FileInformation.FilePathURL;
            }

            if (contentListItem.LeafIndicator)
            {
                contentListItem.SearchPathURL = "";

                if (mongoList.ItemType == "Series ID")
                {
                    contentListItem.SearchPathURL = string.Format(SERIES_SEARCH_PAGE, contentListItem.ID, HttpUtility.UrlEncode(contentListItem.Literal));
                }
                else if (mongoList.ItemType == "ISBN")
                {
                    contentListItem.SearchPathURL = string.Format(TITLE_SEARCH_PAGE, contentListItem.ID, HttpUtility.UrlEncode(contentListItem.Literal));
                }

            }
            return contentListItem;
        }

        private async Task<List<BsonDocument>> GetListsFromMongo(string id)
        {
            List<BsonDocument> bsonLists = new List<BsonDocument>();

            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var filter = Builders<BsonDocument>.Filter.Eq("ParentID", ObjectId.Parse(id));
            var sort = Builders<BsonDocument>.Sort.Ascending("Sequence");


            while (retries > 0)
            {
                try
                {
                    bsonLists = await _lists.Find(filter).Sort(sort).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return bsonLists;
        }

        public async Task<NoSqlServiceResult<ContentSearchResponse>> GetSearchItem(string id)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ContentSearchResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonLists = new List<BsonDocument>();

                ContentSearchResponse contentSearchResponse = new ContentSearchResponse();

                var filter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(id));
                

                while (retries > 0)
                {
                    try
                    {
                        bsonLists = await _lists.Find(filter).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                if (bsonLists != null && bsonLists.Count >= 1)
                {
                    var document = bsonLists[0];
                    // process document
                    Lists mongoList = BindList(document);

                    if (mongoList != null)
                    {
                        contentSearchResponse.ItemType = mongoList.ItemType;
                        contentSearchResponse.ListItems = mongoList.ListItems;
                    }
                    
                }

                noSqlServiceResult.Data = contentSearchResponse;

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ContentSearchResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetSearchItem", id);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<ContentListReponse>> GetFeaturedLists(string header)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ContentListReponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonLists = new List<BsonDocument>();

                ContentListReponse contentListReponse = new ContentListReponse();
                ArrayList ltContentList = new ArrayList();

                var filter = Builders<BsonDocument>.Filter.Eq("FeaturedListType", header);
                var sort = Builders<BsonDocument>.Sort.Ascending("FeaturedListSequence");


                while (retries > 0)
                {
                    try
                    {
                        bsonLists = await _lists.Find(filter).Sort(sort).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                foreach (var document in bsonLists)
                {
                    // process document
                    Lists mongoList = BindList(document);

                    if (mongoList != null)
                    {
                        ContentListItem contentListItem = new ContentListItem();

                        contentListItem.ID = mongoList._id.ToString();
                        contentListItem.Literal = mongoList.FeaturedListLiteral;
                        contentListItem.ChildCount = mongoList.ChildCount.HasValue ? mongoList.ChildCount.Value.ToString() : "";

                        contentListItem.SearchPathURL = "";

                        if (mongoList.ItemType == "Series ID")
                        {
                            contentListItem.SearchPathURL = string.Format(SERIES_SEARCH_PAGE, contentListItem.ID, HttpUtility.UrlEncode(contentListItem.Literal));
                        }
                        else if (mongoList.ItemType == "ISBN")
                        {
                            contentListItem.SearchPathURL = string.Format(TITLE_SEARCH_PAGE, contentListItem.ID, HttpUtility.UrlEncode(contentListItem.Literal));
                        }

                        ltContentList.Add(contentListItem);
                    }
                }

                contentListReponse.ContentListListing = (ContentListItem[])ltContentList.ToArray(typeof(ContentListItem));
                noSqlServiceResult.Data = contentListReponse;

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ContentListReponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetFeaturedLists", header);
            }

            return noSqlServiceResult;
        }

        private Lists BindList(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            //Product p = BsonSerializer.Deserialize<Product>(bsdoc.ToJson());

            Lists l = new Lists();

            if (bsdoc.Contains("_id"))
                l._id = bsdoc["_id"].AsObjectId;

            if (bsdoc.Contains("Literal"))
                l.Literal = bsdoc["Literal"].AsString;

            if (bsdoc.Contains("ChildCount"))
                l.ChildCount = bsdoc["ChildCount"].AsNullableInt32;

            if (bsdoc.Contains("LeafIndicator"))
                l.LeafIndicator = bsdoc["LeafIndicator"].AsNullableBoolean;

            if (bsdoc.Contains("HideLink"))
                l.HideLink = bsdoc["HideLink"].AsBoolean;

            if (bsdoc.Contains("FileInformation"))
            {
                var fileInformation = BsonSerializer.Deserialize<FileInformation>(bsdoc["FileInformation"].ToJson());

                if (fileInformation != null)
                {
                    l.FileInformation = fileInformation;
                }
            }


            if (bsdoc.Contains("ItemType"))
                l.ItemType = bsdoc["ItemType"].AsString;

            if (bsdoc.Contains("ListItems"))
                l.ListItems = BsonSerializer.Deserialize<List<string>>(bsdoc["ListItems"].ToJson());

            if (bsdoc.Contains("FeaturedListLiteral"))
                l.FeaturedListLiteral =  bsdoc["FeaturedListLiteral"].AsString;

            return l ;
        }


        internal async Task<NoSqlServiceResult<CategoryResponse>> GetPublicationCategoryList(string literal)
        {
            var noSqlServiceResult = new NoSqlServiceResult<CategoryResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                var categoryResponse = new CategoryResponse();
                categoryResponse.Categories = new List<CategoryDetailsResponse>();

                CategoryDetailsResponse publicationDetails = await GetPublicationDetails(literal);
                if (publicationDetails != null && publicationDetails.Id != null)
                {
                    List<CategoryDetailsResponse> categoryDetails = await GetCategoryDetails(publicationDetails.Id);
                    List<CategoryDetailsResponse> subCategoryDetails = await GetSubCategoryDetails(categoryDetails.Select(x => x.Id));

                    var subCategoryGrouped = subCategoryDetails.GroupBy(x => x.ParentId);
                    foreach (var subCategoryGroupedDetails in subCategoryGrouped)
                    {
                        foreach (var categoryDetail in categoryDetails)
                        {
                            if (categoryDetail.Id == subCategoryGroupedDetails.Key)
                            {
                                categoryDetail.ChildCategories = new List<CategoryDetailsResponse>();
                                categoryDetail.ChildCategories.AddRange(subCategoryGroupedDetails);
                                break;
                            }
                        }
                    }
                    publicationDetails.ChildCategories = categoryDetails;
                    categoryResponse.Categories = new List<CategoryDetailsResponse>();
                    categoryResponse.Categories.Add(publicationDetails);
                }
                noSqlServiceResult.Data = categoryResponse;

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new CategoryResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPublicationCategoryList", literal);
            }

            return noSqlServiceResult;

        }

        private async Task<List<CategoryDetailsResponse>> GetSubCategoryDetails(IEnumerable<string> categoryIds)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            List<ObjectId> categoryObjectIds = new List<ObjectId>();
            foreach(var categoryId in categoryIds)
            {
                categoryObjectIds.Add(ObjectId.Parse(categoryId));
            }

            List<CategoryDetailsResponse> categoryDetailsResponseList = new List<CategoryDetailsResponse>();
            var filter = Builders<BsonDocument>.Filter.In("ParentID", categoryObjectIds);
            List<BsonDocument> bsonCategoryDocuments = new List<BsonDocument>();

            while (retries > 0)
            {
                try
                {
                    bsonCategoryDocuments = await _lists.Find(filter).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
            foreach (var categoryDocument in bsonCategoryDocuments)
            {
                categoryDetailsResponseList.Add(BindNodeDetails(categoryDocument));
            }

            return categoryDetailsResponseList;
        }

        private async Task<List<CategoryDetailsResponse>> GetCategoryDetails(string publicationId)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            List<CategoryDetailsResponse> categoryDetailsResponseList = new List<CategoryDetailsResponse>();
            var filter = Builders<BsonDocument>.Filter.Eq("ParentID", ObjectId.Parse(publicationId));
            var sort = Builders<BsonDocument>.Sort.Ascending("Sequence");
            List<BsonDocument> bsonCategoryDocuments = new List<BsonDocument>();

            while (retries > 0)
            {
                try
                {
                    bsonCategoryDocuments = await _lists.Find(filter).Sort(sort).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
            foreach (var categoryDocument in bsonCategoryDocuments)
            {
                categoryDetailsResponseList.Add(BindNodeDetails(categoryDocument));
            }

            return categoryDetailsResponseList;
        }

        private async Task<CategoryDetailsResponse> GetPublicationDetails(string literal)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            var filter = Builders<BsonDocument>.Filter.Eq("Literal", literal);
            var sort = Builders<BsonDocument>.Sort.Ascending("Sequence");
            var publicationDocument = new BsonDocument();

            while (retries > 0)
            {
                try
                {
                    publicationDocument = await _lists.Find(filter).Sort(sort).FirstOrDefaultAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            var publicationDetails = BindNodeDetails(publicationDocument);

            return publicationDetails;
        }

        private CategoryDetailsResponse BindNodeDetails(BsonDocument nodeDocument)
        {
            var nodeDetails = new CategoryDetailsResponse();
            if (nodeDocument != null)
            {
                if (nodeDocument.Contains("_id"))
                    nodeDetails.Id = nodeDocument["_id"].AsObjectId.ToString();

                if (nodeDocument.Contains("ParentID"))
                    nodeDetails.ParentId = nodeDocument["ParentID"].AsObjectId.ToString();

                if (nodeDocument.Contains("ParentLiteral"))
                    nodeDetails.ParentLiteral = nodeDocument["ParentLiteral"].AsString;

                if (nodeDocument.Contains("Literal"))
                    nodeDetails.Literal = nodeDocument["Literal"].AsString;

                if (nodeDocument.Contains("ChildCount"))
                    nodeDetails.ChildCount = nodeDocument["ChildCount"].AsNullableInt32;

                if (nodeDocument.Contains("ImageURL"))
                    nodeDetails.ImageURL = nodeDocument["ImageURL"].AsString;
            }
            return nodeDetails;
        }


        internal async Task<List<string>> getPublicationSubcategorySeriesIds(string publicationSubcategoryId)
        {
            var publicationSubcategorySeriesIds = new List<string>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var filter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(publicationSubcategoryId));
                var categoryDocuments = new List<BsonDocument>();

                while (retries > 0)
                {
                    try
                    {
                        categoryDocuments = await _lists.Find(filter).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                publicationSubcategorySeriesIds = BindNodeProductIds(categoryDocuments);

            }
            catch (Exception ex)
            {
                LoggerService logger = new LoggerService();
                logger.LogError(ex, "getPublicationSubcategorySeriesIds", publicationSubcategoryId);
            }

            return publicationSubcategorySeriesIds;
        }

        private List<string> BindNodeProductIds(List<BsonDocument> nodeDocuments)
        {
            var productIds = new List<string>();
            foreach (var nodeDocument in nodeDocuments)
            {
                if (nodeDocument.Contains("ListItems"))
                {
                    BsonArray baPrograms = nodeDocument["ListItems"].AsBsonArray;

                    foreach (BsonValue value in baPrograms)
                    {
                        productIds.Add(value.ToString());
                    }
                }
            }
            return productIds;
        }

        internal async Task<List<string>> getPublicationCategorySeriesIds(string publicationCategoryId)
        {
            var publicationSubcategorySeriesIds = new List<string>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var filter = Builders<BsonDocument>.Filter.Eq("ParentID", ObjectId.Parse(publicationCategoryId));
                var categoryDocuments = new List<BsonDocument>();

                while (retries > 0)
                {
                    try
                    {
                        categoryDocuments = await _lists.Find(filter).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                publicationSubcategorySeriesIds = BindNodeProductIds(categoryDocuments);

            }
            catch (Exception ex)
            {
                LoggerService logger = new LoggerService();
                logger.LogError(ex, "getPublicationCategorySeriesIds", publicationCategoryId);
            }

            return publicationSubcategorySeriesIds;
        }

        internal async Task<NoSqlServiceResult<CategoryDetailsResponse>> GetCategoryById(string id)
        {
            var noSqlServiceResult = new NoSqlServiceResult<CategoryDetailsResponse> { Status = NoSqlServiceStatus.Success };

             try
             {
                 int retryWaitTime = AppSettings.RetryWaitTime;
                 int retries = AppSettings.MaxConnectionRetries;

                 var filter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(id));
                 var sort = Builders<BsonDocument>.Sort.Ascending("Sequence");
                 var categoryDocument = new BsonDocument();

                 while (retries > 0)
                 {
                     try
                     {
                         categoryDocument = await _lists.Find(filter).Sort(sort).FirstOrDefaultAsync<BsonDocument>();

                         break;
                     }
                     catch (Exception)
                     {
                         retries--;
                         Thread.Sleep(retryWaitTime);
                         if (retries < 1)
                         {
                             throw;
                         }
                     }
                 }

                 noSqlServiceResult.Data = BindNodeDetails(categoryDocument);
             }
             catch (Exception ex)
             {
                 noSqlServiceResult.Data = new CategoryDetailsResponse();
                 noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                 noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                 noSqlServiceResult.ErrorMessage = ex.Message;

                 LoggerService logger = new LoggerService();
                 logger.LogError(ex, "GetCategoryById", id);
             }

            return noSqlServiceResult;
        }
    }

}