﻿using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Services
{
    public class CartFacetsBuilder
    {
        private List<Product> _products;
        private NameValueCollection _facetFilters;

        const string AUDIENCE_LEVEL_KEY = "audiencelevel";
        const string JUVENILE = "juvenile";
        const string TEEN = "teen";
        const string ADULT = "adult";
        const string STARTWITH_CHILDREN = "Children's - ";
        const string STARTWITH_TEEN = "Teen - ";
        readonly string[] AdultItems = { "General Adult", "Professional", "Scholarly/Associate", "Scholarly/Undergraduate", "Scholarly/Graduate", "Vocational/Technical" };

        const string FICTION_NONFICTION_KEY = "fictionnonfiction";
        const string FICTION = "fiction";
        const string NON_FICTION = "nonfiction";
        readonly string[] FictionCodes = { "FI", "EF", "JF" };
        readonly string[] NonFictionCodes = { "NF", "EN", "JN" };

        const string DIVERSITY_TOPIC = "diversitytopic";
        const string NOT_DIVERSE = "notdiverse";
        const string ALL_DIVERSE = "alldiverse";

        public const string INVENTORY_KEY = "Inventory";

        public CartFacetsBuilder(List<Product> products, NameValueCollection filters)
        {
            _products = products;
            _facetFilters = filters;
        }

        /// <summary>
        /// Builds facets from Product results.
        /// </summary>
        /// <param name="inventoryParam">Used to filter products.</param>
        /// <returns></returns>
        public List<CartFacetsGroup> BuildCartFacets(CartFacetsRequest inventoryParam, out string matchingBTKeys)
        {
            var results = new List<CartFacetsGroup>();
            matchingBTKeys = string.Empty;

            if (_products != null)
            {
                // filter products by facetpath (ex. "audiencelevel=adult&fictionnonfiction=fiction&diversitytopic=asia")
                _products = FilterProducts();

                // build audience facets
                var audienceFacetGroup = BuildAudienceFacets();
                if (audienceFacetGroup != null && audienceFacetGroup.Facets.Count > 0)
                    results.Add(audienceFacetGroup);

                // build fiction/non-fiction facets
                var fictionFacetGroup = BuildFictionNonFictionFacets();
                if (fictionFacetGroup != null && fictionFacetGroup.Facets.Count > 0)
                    results.Add(fictionFacetGroup);

                // build DiversityTopic facets
                if (inventoryParam.DEIEnabled)
                {
                    var deiGroup = BuildDiversityTopicFacets();
                    if (deiGroup != null && deiGroup.Facets.Count > 0)
                        results.Add(deiGroup);
                }

                // build inventory facets
                var inventoryFacetGroup = BuildInventoryFacets(inventoryParam, out matchingBTKeys);
                if (inventoryFacetGroup != null && inventoryFacetGroup.Facets.Count > 0)
                    results.Add(inventoryFacetGroup);
            }

            return results;
        }

        // Filters products by facet param
        private List<Product> FilterProducts()
        {
            List<Product> results = _products;

            if (_facetFilters != null && _facetFilters.Count > 0)
            {
                // filter by audience
                var audienceFilter = _facetFilters.Get(AUDIENCE_LEVEL_KEY);
                if (!string.IsNullOrEmpty(audienceFilter))
                {
                    switch (audienceFilter.ToLower())
                    {
                        case JUVENILE:
                            results = results.Where(p => !string.IsNullOrEmpty(p.Audience) && p.Audience.StartsWith(STARTWITH_CHILDREN, StringComparison.OrdinalIgnoreCase)).ToList();
                            break;
                        case TEEN:
                            results = results.Where(p => !string.IsNullOrEmpty(p.Audience) && p.Audience.StartsWith(STARTWITH_TEEN, StringComparison.OrdinalIgnoreCase)).ToList();
                            break;
                        case ADULT:
                            results = results.Where(p => (p.ProductCode == ProductCodeConstants.BOOK || p.ProductCode == ProductCodeConstants.EBOOK)
                                                         && (string.IsNullOrEmpty(p.Audience) || AdultItems.Contains(p.Audience, StringComparer.OrdinalIgnoreCase))).ToList();
                            break;
                    }
                }

                // filter by fiction/nonfiction
                var fictionFilter = _facetFilters.Get(FICTION_NONFICTION_KEY);
                if (!string.IsNullOrEmpty(fictionFilter))
                {
                    switch (fictionFilter.ToLower())
                    {
                        case FICTION:
                            results = results.Where(p => FictionCodes.Contains(p.BookTypeClassificationCode, StringComparer.OrdinalIgnoreCase)).ToList();
                            break;
                        case NON_FICTION:
                            results = results.Where(p => NonFictionCodes.Contains(p.BookTypeClassificationCode, StringComparer.OrdinalIgnoreCase)).ToList();
                            break;
                    }
                }

                // filter by multiple Diversity Topics
                var diversityTopicFilter = _facetFilters.Get(DIVERSITY_TOPIC);
                if (!string.IsNullOrEmpty(diversityTopicFilter))
                {
                    var filterValues = diversityTopicFilter.ToLower().Split(',').Distinct().ToList();
                    var notDiverseItem = filterValues.FirstOrDefault(p => p.Equals(NOT_DIVERSE, StringComparison.OrdinalIgnoreCase));
                    if (notDiverseItem != null)
                    {
                        // filter not-diverse topic
                        results = results.Where(p => p.DiversityClassification == null || p.DiversityClassification.Count == 0).ToList();
                        filterValues.Remove(notDiverseItem);
                    }
                    else
                    {
                        // filter all diverse topics
                        var allDiverseItem = filterValues.FirstOrDefault(p => p.Equals(ALL_DIVERSE, StringComparison.OrdinalIgnoreCase));
                        if (allDiverseItem != null)
                        {
                            results = results.Where(p => p.DiversityClassification != null && p.DiversityClassification.Count > 0).ToList();
                            filterValues.Remove(allDiverseItem);
                        }
                    }

                    if (filterValues.Count > 0)
                    {
                        // filter topics
                        foreach (var filterItem in filterValues)
                        {
                            results = results.Where(p => (p.DiversityClassification != null &&
                                                              p.DiversityClassification.Any(topic => topic.ClassificationCode.Equals(filterItem, StringComparison.OrdinalIgnoreCase))))
                                                 .ToList();
                        }
                    }
                }
            }

            return results;
        }

        // Build Audience Level facets for juvenile, teen and adult
        private CartFacetsGroup BuildAudienceFacets()
        {
            int juvenileCount = 0;
            int teenCount = 0;
            int adultCount = 0;
            
            foreach (var product in _products)
            {
                var audience = product.Audience;
                if (!string.IsNullOrEmpty(audience) && audience.StartsWith(STARTWITH_CHILDREN, StringComparison.OrdinalIgnoreCase))
                    juvenileCount++;
                else if (!string.IsNullOrEmpty(audience) && audience.StartsWith(STARTWITH_TEEN, StringComparison.OrdinalIgnoreCase))
                    teenCount++;
                else if ((product.ProductCode == ProductCodeConstants.BOOK || product.ProductCode == ProductCodeConstants.EBOOK)
                         && (string.IsNullOrEmpty(audience) || AdultItems.Contains(audience, StringComparer.OrdinalIgnoreCase)))
                    adultCount++;
            }

            var audienceFacetsGroup = new CartFacetsGroup(AUDIENCE_LEVEL_KEY, "Audience Level");
            // juvenile facet
            if (juvenileCount > 0)
                audienceFacetsGroup.Facets.Add(new CartFacet(JUVENILE, "Juvenile", juvenileCount));

            // teen facet
            if (teenCount > 0)
                audienceFacetsGroup.Facets.Add(new CartFacet(TEEN, "Teen", teenCount));

            // adult facet
            if (adultCount > 0)
                audienceFacetsGroup.Facets.Add(new CartFacet(ADULT, "Adult", adultCount));

            return audienceFacetsGroup;
        }

        // Build Fiction/Non-Fiction facets
        private CartFacetsGroup BuildFictionNonFictionFacets()
        {
            if (_products != null && _products.Count > 0)
            {
                int fictionCount = 0;
                int nonFictionCount = 0;

                foreach (var product in _products)
                {
                    var bookTypeCode = product.BookTypeClassificationCode;
                    if (FictionCodes.Contains(bookTypeCode, StringComparer.OrdinalIgnoreCase))
                        fictionCount++;
                    else if (NonFictionCodes.Contains(bookTypeCode, StringComparer.OrdinalIgnoreCase))
                        nonFictionCount++;
                }

                var facetsGroup = new CartFacetsGroup(FICTION_NONFICTION_KEY, "Fiction/Non-Fiction");
                // fiction facet
                if (fictionCount > 0)
                    facetsGroup.Facets.Add(new CartFacet(FICTION, "Fiction", fictionCount));

                // non-fiction facet
                if (nonFictionCount > 0)
                    facetsGroup.Facets.Add(new CartFacet(NON_FICTION, "Non-Fiction", nonFictionCount));

                return facetsGroup;
            }

            return null;
        }

        // Build DiversityTopic facets
        private CartFacetsGroup BuildDiversityTopicFacets()
        {
            var facetsGroup = new CartFacetsGroup(DIVERSITY_TOPIC, "Diversity Topic");
            var notDiverseCount = 0;

            if (_products != null && _products.Count > 0)
            {
                var deiDiverseItems = _products.Where(p => p.DiversityClassification != null && p.DiversityClassification.Count > 0);
                var deiItemsCount = deiDiverseItems.Count();
                if (deiItemsCount > 0)
                {
                    var groupedDeiItems = deiDiverseItems.SelectMany(p => p.DiversityClassification, (p, topic) => new { p.BTKEY, topic.ClassificationCode, topic.ClassificationName })
                                           .GroupBy(p => new { p.ClassificationCode, p.ClassificationName }, p => p.BTKEY)
                                           .Select(g => new { g.Key.ClassificationCode, g.Key.ClassificationName, Count = g.Count() });
                    foreach (var groupedItem in groupedDeiItems)
                    {
                        // facet
                        facetsGroup.Facets.Add(new CartFacet(groupedItem.ClassificationCode, groupedItem.ClassificationName, groupedItem.Count));
                    }

                    // sort by count
                    facetsGroup.Facets = facetsGroup.Facets.OrderByDescending(p => p.ItemCount).ToList();
                }

                notDiverseCount = _products.Count - deiItemsCount;
            }

            // add Not Diverse facet at top
            facetsGroup.Facets.Insert(0, new CartFacet(NOT_DIVERSE, "Not Diverse", notDiverseCount));

            return facetsGroup;
        }
        
        // Build inventory facets
        private CartFacetsGroup BuildInventoryFacets(CartFacetsRequest inventoryParam, out string matchingBTKeys)
        {
            matchingBTKeys = string.Empty;

            if (_products != null && _products.Count > 0)
            {
                int NotAvailable = 0;
                int AvailableInPrimaryWarehouse = 0;
                int AvailableInSecondaryWarehouse = 0;
                int AvailableInOtherWarehouse = 0;
                int AvailableInVIPWarehouse = 0;
                bool NotAvailableFacet = false;
                bool AvailableInPrimaryFacet = false;
                bool AvailableInSecondaryFacet = false;
                bool AvailableInVIPFacet = false;
                bool AvailableInOtherFacet = false;
                bool IgnoreFacets = true;
                string MatchingBTKeys = string.Empty;

                var btKeyCartInventoryFacetsResultList = new List<BTKeyCartInventoryFacetsResult>();
                string BookPrimaryWarehouse = ConvertWareHouseCode(inventoryParam.BookPrimaryWareHouseCode);
                string BookSecondaryWarehouse = ConvertWareHouseCode(inventoryParam.BookSecondaryWareHouseCode);
                string EntertainmentPrimaryWarehouse = ConvertWareHouseCode(inventoryParam.EntertainmentPrimaryWareHouseCode);
                string EntertainmentSecondaryWarehouse = ConvertWareHouseCode(inventoryParam.EntertainmentSecondaryWareHouseCode);

                if (_facetFilters != null)
                {
                    // filter by Inventory
                    //var nvCollection = HttpUtility.ParseQueryString(inventoryParam.FacetPath);
                    var inventoryFilter = _facetFilters.Get(INVENTORY_KEY);

                    if (!string.IsNullOrEmpty(inventoryFilter))
                    {
                        IgnoreFacets = false;
                        switch (inventoryFilter)
                        {
                            case CartInventoryFacets.Not_Available_for_Shipping:
                                NotAvailableFacet = true;
                                break;
                            case CartInventoryFacets.Available_in_Primary_Warehouse:
                                AvailableInPrimaryFacet = true;
                                break;
                            case CartInventoryFacets.Available_in_Secondary_Warehouse:
                                AvailableInSecondaryFacet = true;
                                break;
                            case CartInventoryFacets.Available_in_VIP_warehouses:
                                AvailableInVIPFacet = true;
                                break;
                            case CartInventoryFacets.Available_in_Other_Warehouses:
                                AvailableInOtherFacet = true;
                                break;
                        }
                    }

                }

                foreach (var product in _products)
                {
                    string primaryWarehouse = string.Empty;
                    string secondaryWarehouse = string.Empty;
                    bool matchesFacet = IgnoreFacets; //Set to True if no facet path is sent with request.
                    bool isEBook = false;
                    var currentBTKey = inventoryParam.BTKeys.Where(b => b.BTKey == product.BTKEY).FirstOrDefault();
                    string accountInventoryType = currentBTKey.AccountInventoryType;
                    string leIndicator = string.IsNullOrEmpty(currentBTKey.LEIndicator) ? "0" : currentBTKey.LEIndicator;
                    string inventoryReserveNumber = currentBTKey.InventoryReserveNumber ?? string.Empty;
                    int pagePosition = currentBTKey.PagePosition;
                    int tempNotAvailable = 0;
                    int tempAvailableInPrimaryWarehouse = 0;
                    int tempAvailableInSecondaryWarehouse = 0;
                    int tempAvailableInVIPWarehouse = 0;
                    int tempAvailableInOtherWarehouse = 0;

                    if (product.ProductCode == ProductCodeConstants.BOOK)
                    {
                        primaryWarehouse = BookPrimaryWarehouse;
                        secondaryWarehouse = BookSecondaryWarehouse;
                    }
                    else if (product.ProductCode == ProductCodeConstants.MOVIE || product.ProductCode == ProductCodeConstants.MUSIC)
                    {
                        primaryWarehouse = EntertainmentPrimaryWarehouse;
                        secondaryWarehouse = EntertainmentSecondaryWarehouse;
                    }
                    else if (product.ProductCode == ProductCodeConstants.EBOOK)
                    {
                        isEBook = true;
                        bool rightToVend = false;
                        if (product.RightToVend.HasValue)
                        {
                            rightToVend = product.RightToVend.Value;
                        }

                        if (product.PublicationDate.HasValue && product.PublicationDate < DateTime.Today && rightToVend)
                        {
                            tempAvailableInPrimaryWarehouse++;
                            if (AvailableInPrimaryFacet)
                                matchesFacet = true;
                        }
                        else
                        {
                            tempNotAvailable++;
                            if (NotAvailableFacet)
                                matchesFacet = true;
                        }
                    }

                    foreach (var inventory in product.InventoryData)
                    {
                        if (string.Equals(inventory.WarehouseCode, CommonConstants.WarehouseConstants.RNO))
                        {
                            inventory.WarehouseCode = CommonConstants.WarehouseConstants.REN;
                            break;
                        }
                    }

                    if (!isEBook)
                    {
                        bool isAvailable = false;
                        if (product.ReportCode == ReportCodeConstants.PRODUCT_CANCELLED || product.ReportCode == ReportCodeConstants.APPLY_DIRECT
                            || product.ReportCode == ReportCodeConstants.OUT_OF_PRINT || product.ReportCode == ReportCodeConstants.PERMANENTLY_OUT_OF_STOCK)
                        {
                            tempNotAvailable++;
                            if (NotAvailableFacet)
                                matchesFacet = true;
                        }
                        if (product.InventoryData.Any(y => y.WarehouseCode == primaryWarehouse && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                        {
                            tempAvailableInPrimaryWarehouse++;
                            isAvailable = true;
                            if (AvailableInPrimaryFacet)
                                matchesFacet = true;
                        }

                        if (product.InventoryData.Any(y => y.WarehouseCode == secondaryWarehouse && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                        {
                            tempAvailableInSecondaryWarehouse++;
                            isAvailable = true;
                            if (AvailableInSecondaryFacet)
                                matchesFacet = true;
                        }

                        if ((inventoryParam.VIPEnabled && product.InventoryData.Any(y => (y.WarehouseCode == CommonConstants.WarehouseConstants.VIE || y.WarehouseCode == CommonConstants.WarehouseConstants.VIM) && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0) ||
                            ((product.ProductCode == ProductCodeConstants.MOVIE || product.ProductCode == ProductCodeConstants.MUSIC) && product.InventoryData.Any(y => (y.WarehouseCode == CommonConstants.WarehouseConstants.VII) && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                            )
                        {
                            tempAvailableInVIPWarehouse++;
                            isAvailable = true;
                            if (AvailableInVIPFacet)
                                matchesFacet = true;
                        }

                        if (product.InventoryData.Any(y => y.WarehouseCode != primaryWarehouse && y.WarehouseCode != secondaryWarehouse && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                        {
                            tempAvailableInOtherWarehouse++;
                            isAvailable = true;
                            if (AvailableInOtherFacet)
                                matchesFacet = true;
                        }

                        if (!isAvailable)
                        {
                            tempNotAvailable++;
                            if (NotAvailableFacet)
                                matchesFacet = true;
                        }
                    }

                    if (matchesFacet)
                    {
                        var inventoryFacetItem = new BTKeyCartInventoryFacetsResult
                        {
                            BTKey = product.BTKEY,
                            LineItem = pagePosition
                        };
                        btKeyCartInventoryFacetsResultList.Add(inventoryFacetItem);

                        NotAvailable += tempNotAvailable;
                        AvailableInPrimaryWarehouse += tempAvailableInPrimaryWarehouse;
                        AvailableInSecondaryWarehouse += tempAvailableInSecondaryWarehouse;
                        AvailableInVIPWarehouse += tempAvailableInVIPWarehouse;
                        AvailableInOtherWarehouse += tempAvailableInOtherWarehouse;
                    }
                }

                // create group of facets
                var facetsGroup = new CartFacetsGroup(INVENTORY_KEY, "Inventory");

                // notAvailable facet
                if (NotAvailable > 0)
                {
                    facetsGroup.Facets.Add(new CartFacet(CartInventoryFacets.Not_Available_for_Shipping,
                                                         CartInventoryFacets.Not_Available_for_Shipping.Replace('_', ' '),
                                                         NotAvailable));
                }
                // availableInPrimaryWarehouse facet
                if (AvailableInPrimaryWarehouse > 0)
                {
                    facetsGroup.Facets.Add(new CartFacet(CartInventoryFacets.Available_in_Primary_Warehouse,
                                                         CartInventoryFacets.Available_in_Primary_Warehouse.Replace('_', ' '),
                                                         AvailableInPrimaryWarehouse));
                }
                // availableInSecondaryWarehouse facet
                if (AvailableInSecondaryWarehouse > 0)
                {
                    facetsGroup.Facets.Add(new CartFacet(CartInventoryFacets.Available_in_Secondary_Warehouse,
                                                         CartInventoryFacets.Available_in_Secondary_Warehouse.Replace('_', ' '),
                                                         AvailableInSecondaryWarehouse));
                }
                // availableInOtherWarehouse facet
                if (AvailableInOtherWarehouse > 0)
                {
                    facetsGroup.Facets.Add(new CartFacet(CartInventoryFacets.Available_in_Other_Warehouses,
                                                         CartInventoryFacets.Available_in_Other_Warehouses.Replace('_', ' '),
                                                         AvailableInOtherWarehouse));
                }
                // availableInVIPWarehouse facet
                if (AvailableInVIPWarehouse > 0)
                {
                    facetsGroup.Facets.Add(new CartFacet(CartInventoryFacets.Available_in_VIP_warehouses,
                                                         CartInventoryFacets.Available_in_VIP_warehouses.Replace('_', ' '),
                                                         AvailableInVIPWarehouse));
                }

                matchingBTKeys = string.Join(";", btKeyCartInventoryFacetsResultList.OrderBy(b => b.LineItem).Select(x => x.BTKey).ToArray());

                return facetsGroup;
            }

            return null;
        }

        private string ConvertWareHouseCode(string wareHouseCode)
        {
            if (!string.IsNullOrEmpty(wareHouseCode) && string.Equals(wareHouseCode, CommonConstants.WarehouseConstants.RNO))
                return CommonConstants.WarehouseConstants.REN;
            else
                return wareHouseCode;
        }

        private bool IsValidAccountInventoryType(string inventoryAccountType, string requestInventoryAccountType)
        {
            if (string.IsNullOrEmpty(inventoryAccountType) ||
                    inventoryAccountType.Replace(" ", "") == "" ||
                    inventoryAccountType == "A")
            {
                return true;
            }
            else
            {
                if (!string.IsNullOrEmpty(requestInventoryAccountType) && requestInventoryAccountType.Length > 1)
                {
                    return (inventoryAccountType.IndexOfAny(requestInventoryAccountType.ToCharArray()) > -1);
                }
                else if (requestInventoryAccountType == inventoryAccountType)
                {
                    return true;
                }
            }

            return false;
        }

        private bool IsValidInventoryReserveNumber(string customerNumber, string requestInventoryReserveNumber)
        {
            if (string.IsNullOrEmpty(customerNumber) ||
                customerNumber.Replace(" ", "") == "" ||
                customerNumber == requestInventoryReserveNumber)
            {
                return true;
            }

            return false;
        }
    }
}