﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Web;

namespace BT.TS360.NoSQL.API.Services
{
    class CartFacetsService : ICartFacetsService
    {
        MongoClient _client;
        MongoServer _server;
        MongoDatabase _database;
        MongoCollection<BsonDocument> _product;


        public CartFacetsService(string connection)
        {

            _client = new MongoClient(connection);
            _server = _client.GetServer();
            _database = _server.GetDatabase(CommonConstants.ProductsDatabaseName);
            _product = _database.GetCollection<BsonDocument>(CommonConstants.ProductsCollectionName);
        
        }

        /*
        public NoSqlServiceResult<CartFacetsResponse> GetCartInventoryFacets(CartFacetsRequest request)
        {

            var noSqlServiceResult = new NoSqlServiceResult<CartFacetsResponse> { Status = NoSqlServiceStatus.Success };
            var today = DateTime.Today;
            try
            {
                // Validation
                request.MarketType = "1";
                request.CountryCode = "USA";
                string error = Validate(request);

                if (!string.IsNullOrEmpty(error))
                {
                    return (FormatErrorResponse(error));
                }

                int NotAvailable = 0;
                int AvailableInPrimaryWarehouse = 0;
                int AvailableInSecondaryWarehouse = 0;
                int AvailableInOtherWarehouse = 0;
                int AvailableInVIPWarehouse = 0;
                bool NotAvailableFacet = false;
                bool AvailableInPrimaryFacet = false;
                bool AvailableInSecondaryFacet = false;
                bool AvailableInVIPFacet = false;
                bool AvailableInOtherFacet = false;
                bool IgnoreFacets = true;
                string MatchingBTKeys = string.Empty;
                List<BTKeyCartInventoryFacetsResult> btKeyCartInventoryFacetsResultList = new List<BTKeyCartInventoryFacetsResult>();
                string BookPrimaryWarehouse = ConvertWareHouseCode(request.BookPrimaryWareHouseCode);
                string BookSecondaryWarehouse = ConvertWareHouseCode(request.BookSecondaryWareHouseCode);
                string EntertainmentPrimaryWarehouse = ConvertWareHouseCode(request.EntertainmentPrimaryWareHouseCode);
                string EntertainmentSecondaryWarehouse = ConvertWareHouseCode(request.EntertainmentSecondaryWareHouseCode);

                if (!string.IsNullOrEmpty(request.FacetPath))
                {
                    IgnoreFacets = false;
                    switch (request.FacetPath)
                    {
                        case CartInventoryFacets.Not_Available_for_Shipping:
                            NotAvailableFacet = true;
                            break;
                        case CartInventoryFacets.Available_in_Primary_Warehouse:
                            AvailableInPrimaryFacet = true;
                            break;
                        case CartInventoryFacets.Available_in_Secondary_Warehouse:
                            AvailableInSecondaryFacet = true;
                            break;
                        case CartInventoryFacets.Available_in_VIP_warehouses:
                            AvailableInVIPFacet = true;
                            break;
                        case CartInventoryFacets.Available_in_Other_Warehouses:
                            AvailableInOtherFacet = true;
                            break;
                    }

                }
                

                CartFacetsResponse cartInventoryFacetsResult = new CartFacetsResponse();

                bool isVIPEnabled = IsVIPEnabled(request.VIPEnabled);

                // query Mongodb Products by btkeys
                var productResults = QueryProductsFromMongoDB(request.BTKeys);

                // process facets
                foreach (Product product in productResults)
                {
                    string primaryWarehouse = string.Empty;
                    string secondaryWarehouse = string.Empty;
                    bool matchesFacet = IgnoreFacets; //Set to True if no facet path is sent with request.
                    bool isEBook = false;
                    var currentBTKey = request.BTKeys.Where(b => b.BTKey == product.BTKEY).FirstOrDefault();
                    string accountInventoryType = currentBTKey.AccountInventoryType;
                    string leIndicator = currentBTKey.LEIndicator;
                    string inventoryReserveNumber = currentBTKey.InventoryReserveNumber;
                    int pagePosition = currentBTKey.PagePosition;
                    int tempNotAvailable = 0;
                    int tempAvailableInPrimaryWarehouse = 0;
                    int tempAvailableInSecondaryWarehouse = 0;
                    int tempAvailableInVIPWarehouse = 0;
                    int tempAvailableInOtherWarehouse = 0;
                    if (product.ProductCode == ProductCodeConstants.BOOK)
                    {
                        primaryWarehouse = BookPrimaryWarehouse;
                        secondaryWarehouse = BookSecondaryWarehouse;
                    }
                    else if (product.ProductCode == ProductCodeConstants.MOVIE || product.ProductCode == ProductCodeConstants.MUSIC)
                    {
                        primaryWarehouse = EntertainmentPrimaryWarehouse;
                        secondaryWarehouse = EntertainmentSecondaryWarehouse;
                    }
                    else if (product.ProductCode == ProductCodeConstants.EBOOK)
                    {
                        isEBook = true;
                        bool rightToVend = false;
                        if (product.RightToVend.HasValue)
                        {
                            rightToVend = product.RightToVend.Value;
                        }

                        if (product.PublicationDate.HasValue && product.PublicationDate < today && rightToVend)
                        {
                            tempAvailableInPrimaryWarehouse++;
                            if (AvailableInPrimaryFacet)
                                matchesFacet = true;
                        }
                        else
                        {
                            tempNotAvailable++;
                            if (NotAvailableFacet)
                                matchesFacet = true;
                        }
                    }
                    foreach (var inventory in product.InventoryData)
                    {
                        if (string.Equals(inventory.WarehouseCode, CommonConstants.WarehouseConstants.RNO))
                        {
                            inventory.WarehouseCode = CommonConstants.WarehouseConstants.REN;
                            break;
                        }
                    }
                    if (!isEBook)
                    {
                        bool isAvailable = false;
                        if (product.ReportCode == ReportCodeConstants.PRODUCT_CANCELLED || product.ReportCode == ReportCodeConstants.APPLY_DIRECT
                            || product.ReportCode == ReportCodeConstants.OUT_OF_PRINT || product.ReportCode == ReportCodeConstants.PERMANENTLY_OUT_OF_STOCK)
                        {
                            tempNotAvailable++;
                            if (NotAvailableFacet)
                                matchesFacet = true;
                        }
                        if (product.InventoryData.Any(y => y.WarehouseCode == primaryWarehouse && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                        {
                            tempAvailableInPrimaryWarehouse++;
                            isAvailable = true;
                            if (AvailableInPrimaryFacet)
                                matchesFacet = true;
                        }

                        if (product.InventoryData.Any(y => y.WarehouseCode == secondaryWarehouse && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                        {
                            tempAvailableInSecondaryWarehouse++;
                            isAvailable = true;
                            if (AvailableInSecondaryFacet)
                                matchesFacet = true;
                        }

                        if (
                            (isVIPEnabled && product.InventoryData.Any(y => (y.WarehouseCode == CommonConstants.WarehouseConstants.VIE || y.WarehouseCode == CommonConstants.WarehouseConstants.VIM) && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0) ||
                            ((product.ProductCode == ProductCodeConstants.MOVIE || product.ProductCode == ProductCodeConstants.MUSIC) && product.InventoryData.Any(y => (y.WarehouseCode == CommonConstants.WarehouseConstants.VII) && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0) 
                            )
                        {
                            tempAvailableInVIPWarehouse++;
                            isAvailable = true;
                            if (AvailableInVIPFacet)
                                matchesFacet = true;
                        }

                        if (product.InventoryData.Any(y => y.WarehouseCode != primaryWarehouse && y.WarehouseCode != secondaryWarehouse && IsValidAccountInventoryType(y.InventoryType, accountInventoryType) && IsValidInventoryReserveNumber(y.CustomerNumber, inventoryReserveNumber) && (leIndicator == "0" ? y.AvailableQTY ?? 0 : y.LEAQTY ?? 0) > 0) && tempNotAvailable == 0)
                        {
                            tempAvailableInOtherWarehouse++;
                            isAvailable = true;
                            if (AvailableInOtherFacet)
                                matchesFacet = true;
                        }

                        if (!isAvailable)
                        {
                            tempNotAvailable++;
                            if (NotAvailableFacet)
                                matchesFacet = true;
                        }
                    }
                    if (matchesFacet)
                    {
                        BTKeyCartInventoryFacetsResult btKeyCartInventoryFacetsResult = new BTKeyCartInventoryFacetsResult();
                        btKeyCartInventoryFacetsResult.BTKey = product.BTKEY;
                        btKeyCartInventoryFacetsResult.LineItem = pagePosition;
                        btKeyCartInventoryFacetsResultList.Add(btKeyCartInventoryFacetsResult);
                        NotAvailable += tempNotAvailable;
                        AvailableInPrimaryWarehouse += tempAvailableInPrimaryWarehouse;
                        AvailableInSecondaryWarehouse += tempAvailableInSecondaryWarehouse;
                        AvailableInVIPWarehouse += tempAvailableInVIPWarehouse;
                        AvailableInOtherWarehouse += tempAvailableInOtherWarehouse;
                    }
                }
                

                cartInventoryFacetsResult.CartInventoryFacetsResults = GetCartInventoryFacetsResults(NotAvailable, AvailableInPrimaryWarehouse, AvailableInSecondaryWarehouse, AvailableInOtherWarehouse, AvailableInVIPWarehouse);
                cartInventoryFacetsResult.MatchingBTKeys = string.Join(";", btKeyCartInventoryFacetsResultList.OrderBy(b => b.LineItem).Select(x => x.BTKey).ToArray());
                noSqlServiceResult.Data = cartInventoryFacetsResult;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new CartFacetsResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999";
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "CartInventoryFacetsServices", request.ToJson());
            }

            return noSqlServiceResult;
        }
        */

        public NoSqlServiceResult<CartFacetsResponse> GetCartFacets(CartFacetsRequest request)
        {

            var noSqlServiceResult = new NoSqlServiceResult<CartFacetsResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                // Validation
                request.MarketType = "1";
                request.CountryCode = "USA";
                string error = Validate(request);

                if (!string.IsNullOrEmpty(error))
                {
                    return (FormatErrorResponse(error));
                }

                // query Mongodb Products by btkeys
                var productResults = QueryProductsFromMongoDB(request.BTKeys);

                // build facets
                string matchingBTKeys;

                var facetPath = request.FacetPath ?? string.Empty;
                var queryStrings = HttpUtility.ParseQueryString(facetPath.Replace(';', '&'));

                var facetsBuilder = new CartFacetsBuilder(productResults, filters: queryStrings);
                var facetGroups = facetsBuilder.BuildCartFacets(request, out matchingBTKeys);

                var cartFacetsResult = new CartFacetsResponse()
                {
                    CartFacetsGroupResults = facetGroups,
                    MatchingBTKeys = matchingBTKeys
                };

                // return data
                noSqlServiceResult.Data = cartFacetsResult;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new CartFacetsResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999";
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "CartFacetsServices", request.ToJson());
            }

            return noSqlServiceResult;
        }

        private string Validate(CartFacetsRequest request)
        {
            //check null request
            if(request == null)
            {
                return CartInventoryFacetsErrorCode.NULL_REQUEST;
            }
            // check null BTKeys: ErrorCode: 1
            if (request.BTKeys == null || request.BTKeys.Count() == 0)
            {
                return CartInventoryFacetsErrorCode.EMPTY_BTKEY_CODE;
            }

            // check invalid LE indicator: ErrorCode: 2
            if (request.BTKeys.Any(b => b.LEIndicator != null && b.LEIndicator != "0" && b.LEIndicator != "1"))
            {
                return CartInventoryFacetsErrorCode.INVALID_LE_INDICATOR_CODE;
            }

            //// check invalid VIP Enabled: ErrorCode: 3
            //if (request.VIPEnabled != null &&
            //    (request.VIPEnabled != "0" && request.VIPEnabled != "1"))
            //{
            //    return CartInventoryFacetsErrorCode.INVALID_VIP_ENABLED_CODE;
            //}

            // check invalid Market Type: ErrorCode: 4
            if (request.VIPEnabled && request.MarketType == null)
            {
                return CartInventoryFacetsErrorCode.INVALID_MARKET_TYPES_CODE;
            }

            // check invalid Market Type: ErrorCode: 4
            if (request.VIPEnabled && request.MarketType != null &&
                request.MarketType != ((int)MarketType.Retail).ToString() &&
                request.MarketType != ((int)MarketType.AcademicLibrary).ToString() &&
                request.MarketType != ((int)MarketType.PublicLibrary).ToString() &&
                request.MarketType != ((int)MarketType.SchoolLibrary).ToString())
            {
                return CartInventoryFacetsErrorCode.INVALID_MARKET_TYPES_CODE;
            }

            // check country code: ErrorCode: 5
            if (request.CountryCode == null)
            {
                return CartInventoryFacetsErrorCode.EMPTY_COUNTRY_CODE;
            }

            return null;
        }

        private List<Product> QueryProductsFromMongoDB(CartInventoryFacetsBTKeys[] cartItems)
        {
            List<Product> productResults = new List<Product>();

            if (cartItems != null & cartItems.Count() > 0)
            {
                var query = Query.In("_id", new BsonArray(cartItems.Select(b => b.BTKey).ToArray()));

                int retries = AppSettings.MaxConnectionRetries;
                int retryWaitTime = AppSettings.RetryWaitTime;
                var documentList = new List<BsonDocument>();

                while (retries > 0)
                {
                    try
                    {
                        var fields = Fields.Include("_id", "ProductCode", "RightToVend", "ReportCode", "PublicationDate"
                                                    , "InventoryData.WarehouseCode", "InventoryData.CustomerNumber", "InventoryData.InventoryType", "InventoryData.AvailableQTY", "InventoryData.LEAQTY"
                                                    , "Audience", "BookTypeClassificationCode", "DiversityClassification");
                        documentList = _product.Find(query).SetFields(fields).ToList<BsonDocument>();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);

                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                // convert BsonDocument items to Products
                foreach (BsonDocument item in documentList)
                {
                    Product product = BindProduct(item);
                    productResults.Add(product);
                }
            }

            return productResults;
        }
        
        private bool IsVIPEnabled(string vipEnabled)
        {
            return (!string.IsNullOrEmpty(vipEnabled) && vipEnabled == "1");
        }

        private NoSqlServiceResult<CartFacetsResponse> FormatErrorResponse(string errCode)
        {
            var noSqlServiceResult = new NoSqlServiceResult<CartFacetsResponse> { Status = NoSqlServiceStatus.Fail };

            noSqlServiceResult.ErrorCode = errCode;

            return noSqlServiceResult;
        }

        private Product BindProduct(BsonDocument bsdoc)
        {
            Product p = new Product();

            if (bsdoc.Contains("_id"))
                p.BTKEY = bsdoc["_id"].AsString;

            if (bsdoc.Contains("ProductCode"))
                p.ProductCode = bsdoc["ProductCode"].AsString;

            if (bsdoc.Contains("RightToVend"))
                p.RightToVend = bsdoc["RightToVend"].AsNullableBoolean;

            if (bsdoc.Contains("ReportCode"))
                p.ReportCode = bsdoc["ReportCode"].AsString;

            if (bsdoc.Contains("PublicationDate"))
                p.PublicationDate = bsdoc["PublicationDate"].AsNullableDateTime;

            if (bsdoc.Contains("Audience"))
                p.Audience = bsdoc["Audience"].AsString;

            if (bsdoc.Contains("BookTypeClassificationCode"))
                p.BookTypeClassificationCode = bsdoc["BookTypeClassificationCode"].AsString;

            if (bsdoc.Contains("DiversityClassification"))
            {
                p.DiversityClassification = new List<DiversityClassification>();
                var bsonDiversityClassifications = bsdoc["DiversityClassification"].AsBsonArray;
                foreach (BsonDocument bsonItem in bsonDiversityClassifications)
                {
                    var topicItem = new DiversityClassification();
                    if (bsonItem.Contains("ClassificationCode"))
                    {
                        topicItem.ClassificationCode = bsonItem["ClassificationCode"].AsString;
                    }
                    if (bsonItem.Contains("ClassificationName"))
                    {
                        topicItem.ClassificationName = bsonItem["ClassificationName"].AsString;
                    }

                    // add diversity topic
                    p.DiversityClassification.Add(topicItem);
                }
            }

            List<Inventory> inventoryList = new List<Inventory>();

            if (bsdoc.Contains("InventoryData"))
            {
                BsonArray baInventory = bsdoc["InventoryData"].AsBsonArray;
                foreach (BsonDocument value in baInventory)
                {
                    Inventory inventory = new Inventory();
                    if (value.Contains("WarehouseCode"))
                    {
                        inventory.WarehouseCode = value["WarehouseCode"].AsString;
                    }
                    if (value.Contains("CustomerNumber"))
                    {
                        inventory.CustomerNumber = value["CustomerNumber"].AsString;
                    }
                    if (value.Contains("InventoryType"))
                    {
                        inventory.InventoryType = value["InventoryType"].AsString;
                    }
                    if (value.Contains("AvailableQTY"))
                    {
                        inventory.AvailableQTY = value["AvailableQTY"].AsInt32;
                    }
                    if (value.Contains("LEAQTY"))
                    {
                        inventory.LEAQTY = value["LEAQTY"].AsInt32;
                    }
                    inventoryList.Add(inventory);
                }
            }

            p.InventoryData = inventoryList;

            return p;
        }
    }
}
