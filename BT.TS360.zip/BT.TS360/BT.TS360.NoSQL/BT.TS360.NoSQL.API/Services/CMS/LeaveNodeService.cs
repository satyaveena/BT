﻿using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Services.Interfaces;

namespace BT.TS360.NoSQL.API.Services.CMS
{
    public class LeaveNodeService : ILeaveNodeService
    {
        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }
    }
}