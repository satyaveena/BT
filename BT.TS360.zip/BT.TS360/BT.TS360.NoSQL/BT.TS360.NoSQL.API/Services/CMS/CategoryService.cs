﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.CMS;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Driver;

namespace BT.TS360.NoSQL.API.Services.CMS
{
    public class CategoryService: ICategoryService
    {
        readonly IMongoCollection<BsonDocument> _iCategoriesCollection;

        public CategoryService()
        {
            var client = new MongoClient(ConnectionString);
            var iDatabase = client.GetDatabase(CommonConstants.CmsDatabaseName);

            _iCategoriesCollection = iDatabase.GetCollection<BsonDocument>(CommonConstants.CategoryCollectionName);
        }

        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }

        public async Task<NoSqlServiceResult<CategoryResponse>> GetCategories(CategoryRequest request)
        {
            var response = new CategoryResponse();

            var skipDocs = (request.PageNumber - 1) * request.PageSize;

            var sort = Builders<BsonDocument>.Sort.Ascending(request.SortBy);

            if (request.SortDirection.ToLower() == "desc")
            {
                sort = Builders<BsonDocument>.Sort.Descending(request.SortBy);
            }

            FilterDefinition<BsonDocument> filter = null;

            if (!string.IsNullOrEmpty(request.CategoryId))
            {
                filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(request.CategoryId));
            }

            List<BsonDocument> categories;
            long totalDocs = 0;

            if (filter != null)
            {
                categories = await _iCategoriesCollection.Find(filter).ToListAsync();

                if (categories != null)
                {
                    var childCats = categories[0]["ChildCategories"] as BsonArray;
                    var leaveNodes = categories[0]["LeaveNodes"] as BsonArray;
                    
                    if (childCats == null || childCats.Count == 0)
                    {
                        totalDocs = 0;
                        response.Categories = null;
                    }
                    else
                    {
                        response.Categories = childCats.Select(childCat => ConvertCategoryToCategoryResponse(childCat as BsonDocument)).ToList();
                        totalDocs = childCats.Count;    
                    }

                    if (leaveNodes == null || leaveNodes.Count == 0)
                    {
                        response.LeaveNodes = null;
                    }
                    else
                    {
                        response.LeaveNodes = leaveNodes.Select(node => ConvertLeaveNodeToResponse(node as BsonDocument)).ToList();
                    }
                }
            }
            else
            {
                categories = await _iCategoriesCollection.Find(_ => true).Skip(skipDocs).Limit(request.PageSize).Sort(sort).ToListAsync();

                var categoriesResponse = categories.Select(ConvertCategoryToCategoryResponse).ToList();

                response.LeaveNodes = null; // no nodes for root item
                response.Categories = categoriesResponse;
                totalDocs = await _iCategoriesCollection.CountAsync(_ => true);
            }
            
            response.TotalItems = totalDocs;

            return new NoSqlServiceResult<CategoryResponse> { Data = response, Status = NoSqlServiceStatus.Success };
        }

        private CategoryDetailsResponse ConvertCategoryToCategoryResponse(BsonDocument bsonDoc)
        {
            if (bsonDoc == null) return null;

            var result = new CategoryDetailsResponse();

            result.Id = bsonDoc["_id"].ToString();
            result.Literal = bsonDoc.Contains("Literal") ? bsonDoc["Literal"].AsString : "";

            int intVal;
            if (bsonDoc.Contains("Status") && int.TryParse(bsonDoc["Status"].ToString(), out intVal))
            {
                result.Status = intVal;
            }

            if (bsonDoc.Contains("Sequence") && int.TryParse(bsonDoc["Sequence"].ToString(), out intVal))
            {
                result.Sequence = intVal;
            }

            result.ChildCategories = new List<CategoryDetailsResponse>();
            if (bsonDoc.Contains("ChildCategories"))
            {
                var arrCats = bsonDoc["ChildCategories"] as BsonArray;
                if (arrCats != null)
                {
                    foreach (var arrCat in arrCats)
                    {
                        var catRes = ConvertCategoryToCategoryResponse(arrCat as BsonDocument);
                        if (catRes != null)
                        {
                            result.ChildCategories.Add(catRes);
                        }
                    }
                }
            }

            result.LeaveNodes = new List<LeaveNodeDetailsResponse>();
            if (!bsonDoc.Contains("LeaveNodes")) return result;

            var arr = bsonDoc["LeaveNodes"] as BsonArray;
            if (arr == null) return result;

            foreach (var arrCat in arr)
            {
                var catRes = ConvertLeaveNodeToResponse(arrCat as BsonDocument);
                if (catRes != null)
                {
                    result.LeaveNodes.Add(catRes);
                }
            }

            return result;

        }

        private LeaveNodeDetailsResponse ConvertLeaveNodeToResponse(BsonDocument bsonDoc)
        {
            if (bsonDoc == null) return null;
            var result = new LeaveNodeDetailsResponse();

            result.Id = bsonDoc["_id"].ToString();
            result.Literal = bsonDoc.Contains("Literal") ? bsonDoc["Literal"].ToString() : "";
            result.PublicLink = bsonDoc.Contains("PublicLink") ? bsonDoc["PublicLink"].ToString() : "";
            result.FileName = bsonDoc.Contains("FileName") ? bsonDoc["FileName"].ToString() : "";

            int intVal;
            if (bsonDoc.Contains("Status") && int.TryParse(bsonDoc["Status"].ToString(), out intVal))
            {
                result.Status = intVal;
            }

            if (bsonDoc.Contains("Sequence") && int.TryParse(bsonDoc["Sequence"].ToString(), out intVal))
            {
                result.Sequence = intVal;
            }

            DateTime dt;
            if (bsonDoc.Contains("StartDate") && DateTime.TryParse(bsonDoc["StartDate"].ToString(), out dt))
            {
                result.StartDate = dt;
            }

            if (bsonDoc.Contains("EndDate") && DateTime.TryParse(bsonDoc["EndDate"].ToString(), out dt))
            {
                result.EndDate = dt;
            }

            return result;
        }

        public async Task<NoSqlServiceResult<bool>> UpdateCategory(CategoryRequest request)
        {
            var response = new NoSqlServiceResult<bool> { Data = true, Status = NoSqlServiceStatus.Success };

            try
            {
                var filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(request.CategoryId));
                var categories = await _iCategoriesCollection.Find(filter).Limit(1).ToListAsync();

                if (categories == null || categories.Count == 0)
                {
                    response.Data = false;
                    return response;
                }

                var update = Builders<BsonDocument>.Update.Set("Literal", request.Literal)
                        .Set("ChildCategories", categories[0]["ChildCategories"].AsBsonArray)
                        .Set("LeaveNodes", categories[0]["LeaveNodes"].AsBsonArray)
                        .Set("Status", request.Status)
                        .Set("Sequence", request.Sequence);

                await _iCategoriesCollection.UpdateOneAsync(filter, update);
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                //var logger = new LoggerService();
                //logger.LogError(exception, "ProfileService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", profile.ToJson(),
                //    exception.Message, exception.StackTrace));
            }

            return response;
        }

        public async Task<NoSqlServiceResult<bool>> AddCategory(CategoryRequest request)
        {
            var response = new NoSqlServiceResult<bool> { Data = true, Status = NoSqlServiceStatus.Success };

            try
            {
                var bsonDoc = new BsonDocument();
                bsonDoc.Add("_id", ObjectId.GenerateNewId());
                bsonDoc.Add("Literal", new BsonString(request.Literal));
                bsonDoc.Add("ChildCategories", new BsonArray());
                bsonDoc.Add("LeaveNodes", new BsonArray());
                bsonDoc.Add("Status", new BsonInt32(0));
                bsonDoc.Add("Sequence", request.Sequence);

                if (string.IsNullOrEmpty(request.ParentCategoryId))
                {
                    await _iCategoriesCollection.InsertOneAsync(bsonDoc);
                }
                else
                {
                    var filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(request.ParentCategoryId));
                    var categories = await _iCategoriesCollection.Find(filter).Limit(1).ToListAsync();

                    if (categories == null || categories.Count == 0)
                    {
                        response.Data = false;
                        return response;
                    }

                    var newChilds = categories[0]["ChildCategories"].AsBsonArray;
                    newChilds.Add(bsonDoc);

                    var update = Builders<BsonDocument>.Update.Set("Literal", categories[0]["Literal"].AsString)
                        .Set("ChildCategories", newChilds)
                        .Set("LeaveNodes", categories[0]["LeaveNodes"].AsBsonArray)
                        .Set("Status", categories[0]["Status"].AsInt32)
                        .Set("Sequence", categories[0]["Sequence"].AsInt32);

                    await _iCategoriesCollection.UpdateOneAsync(filter, update);
                }
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                //var logger = new LoggerService();
                //logger.LogError(exception, "ProfileService.CreateProfile", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", profile.ToJson(),
                //    exception.Message, exception.StackTrace));
            }

            return response;
        }

        public async Task<NoSqlServiceResult<bool>> AddNode(LeaveNodeRequest request, System.Web.HttpPostedFile hpf)
        {
            var response = new NoSqlServiceResult<bool> { Data = true, Status = NoSqlServiceStatus.Success };

            try
            {
                var bsonDoc = new BsonDocument();
                bsonDoc.Add("_id", ObjectId.GenerateNewId());
                bsonDoc.Add("Literal", new BsonString(request.Literal));
                bsonDoc.Add("Status", new BsonInt32(0));
                bsonDoc.Add("Sequence", new BsonInt32(request.Sequence));
                bsonDoc.Add("StartDate", new BsonDateTime(request.StartDate));
                bsonDoc.Add("EndDate", new BsonDateTime(request.EndDate));
                bsonDoc.Add("PublicLink", new BsonString(request.PublicLink));
                bsonDoc.Add("FileName", new BsonString(hpf.FileName));
                bsonDoc.Add("ContentLength", new BsonInt32(hpf.ContentLength));
                bsonDoc.Add("ContentType", new BsonString(hpf.ContentType));
                bsonDoc.Add("FileContent", new BsonBinaryData(ReadToEnd(hpf.InputStream)));

                var filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(request.CategoryId));
                var categories = await _iCategoriesCollection.Find(filter).Limit(1).ToListAsync();

                if (categories == null || categories.Count == 0)
                {
                    response.Data = false;
                    return response;
                }

                var newChilds = categories[0]["LeaveNodes"].AsBsonArray;
                newChilds.Add(bsonDoc);

                var update = Builders<BsonDocument>.Update.Set("Literal", categories[0]["Literal"].AsString)
                        .Set("ChildCategories", categories[0]["ChildCategories"].AsBsonArray)
                        .Set("LeaveNodes", newChilds)
                        .Set("Status", categories[0]["Status"].AsInt32)
                        .Set("Sequence", categories[0]["Sequence"].AsInt32);

                await _iCategoriesCollection.UpdateOneAsync(filter, update);
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                //var logger = new LoggerService();
                //logger.LogError(exception, "ProfileService.CreateProfile", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", profile.ToJson(),
                //    exception.Message, exception.StackTrace));
            }

            return response;
        }

        public LeaveNodeDetailsResponse GetFileContent(string catId, string nodeId)
        {
            LeaveNodeDetailsResponse result = null;

            var filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(catId));

            var categories = _iCategoriesCollection.Find(filter).ToList();

            if (categories != null)
            {
                var leaveNodes = categories[0]["LeaveNodes"] as BsonArray;

                if (leaveNodes != null)
                {
                    foreach (var leaveNode in leaveNodes)
                    {
                        if (nodeId == leaveNode["_id"].ToString())
                        {
                            var bsonData = leaveNode["FileContent"].AsBsonBinaryData;

                            if (bsonData != null)
                            {
                                result = new LeaveNodeDetailsResponse();
                                result.Content = bsonData.Bytes;
                                result.ContentLength = leaveNode["ContentLength"].AsInt32;
                                result.ContentType = leaveNode["ContentType"].AsString;
                                result.FileName = leaveNode["FileName"].AsString;
                            }

                            break;
                        }
                    }
                }
            }
            return result;
        }

        private byte[] ReadToEnd(System.IO.Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }
    }
}