﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Web;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;

using System.Threading.Tasks;
using BT.TS360.NoSQL.API.Models.Axis360;

namespace BT.TS360.NoSQL.API.Services
{
    public class Axis360InventoryService
    {
        IMongoClient _client;
        IMongoDatabase _database;
        IMongoCollection<BsonDocument> _axis360Inventory;

        public Axis360InventoryService() : this("") { }


        public Axis360InventoryService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                connection = AppSettings.MongoDBConnectionString;
            }

            _client = new MongoClient(connection);
            _database = _client.GetDatabase(CommonConstants.Axis360DatabaseName);
            _axis360Inventory = _database.GetCollection<BsonDocument>(CommonConstants.Axis360InventoryCollectionName);
        
        }

        public async Task<NoSqlServiceResult<Axis360CheckInventoryResponse>> CheckForInventory(Axis360CheckInventoryRequest request)
        {
            var noSqlServiceResult = new NoSqlServiceResult<Axis360CheckInventoryResponse> { Status = NoSqlServiceStatus.Success };

            try
            {

                if (request != null && !string.IsNullOrEmpty(request.Axis360CustomerID) && request.ISBNList != null && request.ISBNList.Any())
                {

                    Axis360CheckInventoryResponse axis360CheckInventoryResult = new Axis360CheckInventoryResponse();

                    int retries = AppSettings.MaxConnectionRetries;
                    int retryWaitTime = AppSettings.RetryWaitTime;

                    List<Axis360InventoryItem> Axis360InventoryItemList = new List<Axis360InventoryItem>();
                    List<BsonDocument> axis360InventoryDocumentList = new List<BsonDocument>();

                    var filter = Builders<BsonDocument>.Filter.In("ISBN", request.ISBNList) & Builders<BsonDocument>.Filter.Eq("CustomerID", request.Axis360CustomerID);

                    while (retries > 0)
                    {
                        try
                        {
                            axis360InventoryDocumentList = await _axis360Inventory.Find(filter).ToListAsync<BsonDocument>();
                            break;
                        }
                        catch (Exception)
                        {
                            retries--;
                            Thread.Sleep(retryWaitTime);
                            if (retries < 1)
                            {
                                throw;
                            }
                        }
                    }


                    foreach (var axis360InventoryDocument in axis360InventoryDocumentList)
                    {

                        Axis360InventoryItem axis360InventoryItem = BindAxis360InventoryItem(axis360InventoryDocument, request.ISBNList);
                        Axis360InventoryItemList.Add(axis360InventoryItem);
                    }

                    axis360CheckInventoryResult.Axis360InventoryItemList = Axis360InventoryItemList;
                    noSqlServiceResult.Data = axis360CheckInventoryResult;
                }
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new Axis360CheckInventoryResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "Axis360 Inventory CheckForInventory", request.ToJson());
            }

            return noSqlServiceResult;
        }


        public Axis360InventoryItem BindAxis360InventoryItem(BsonDocument bsdoc, List<string> isbnList)
        {

            Axis360InventoryItem axis360InventoryItem = new Axis360InventoryItem();

            if (bsdoc.Contains("ISBN"))
            {
                axis360InventoryItem.ISBN = bsdoc["ISBN"].AsString;
                var state = "";
                if (bsdoc.Contains("State"))
                    state = bsdoc["State"].AsString;
                axis360InventoryItem.HasInventory = string.Equals(state, "A", StringComparison.OrdinalIgnoreCase);
            }

            return axis360InventoryItem;
        }

    }
}