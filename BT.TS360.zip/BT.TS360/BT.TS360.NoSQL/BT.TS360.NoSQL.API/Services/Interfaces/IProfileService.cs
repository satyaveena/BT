﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using MongoDB.Bson;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Services.Interfaces
{
    public interface IProfileService
    {
        string ConnectionString { get; }
    }
}