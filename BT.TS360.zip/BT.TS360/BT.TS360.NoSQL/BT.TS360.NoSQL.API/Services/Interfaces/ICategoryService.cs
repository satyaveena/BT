﻿namespace BT.TS360.NoSQL.API.Services.Interfaces
{
    public interface ICategoryService
    {
        string ConnectionString { get; }
    }
}
