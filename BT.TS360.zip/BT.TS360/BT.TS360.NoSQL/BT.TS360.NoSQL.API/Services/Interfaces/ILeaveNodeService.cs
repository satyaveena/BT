﻿namespace BT.TS360.NoSQL.API.Services.Interfaces
{
    public interface ILeaveNodeService
    {
        string ConnectionString { get; }
    }
}
