﻿using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.Data;
using MongoDB.Bson;

namespace BT.TS360.NoSQL.API.Services.Interfaces
{
    public interface ICartFacetsService
    {
        NoSqlServiceResult<CartFacetsResponse> GetCartFacets(CartFacetsRequest request);
    }
}
