﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Models;

namespace BT.TS360.NoSQL.API.Services.Interfaces
{
    public interface IDemandHistoryService
    {
        NoSqlServiceResult<DemandHistoryResponse> GetDemandHistory(DemandHistoryRequest demandHistoryRequest);
    }
}