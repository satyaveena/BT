﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Web;

using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using Microsoft.Spatial;

using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Exceptions;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.Contents;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using System.Threading;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;

using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json;
using BT.TS360.NoSQL.API.Services.Contents;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.API.Common.Helper;

namespace BT.TS360.NoSQL.API.Services.StandingOrders
{
    public class SearchService
    {
        IMongoClient _client;
        IMongoDatabase _database;
        IMongoCollection<BsonDocument> _savedSearches;

        private static SearchServiceClient _searchClient;
        private static ISearchIndexClient _profiledSeriesIndexClient;
        private static ISearchIndexClient _seriesIndexClient;
        private ContentListService contentListService;

        private const string PROFILENAME_COUNT_FORMAT = "{0}|{1}";

        public SearchService() : this("") { }

        public SearchService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                //connection = "mongodb://BTDevSQL02:27017";
                connection = AppSettings.MongoDBConnectionString;
            }

            _client = new MongoClient(connection);
         
            // standing orders
            _database = _client.GetDatabase(CommonConstants.StandingOrdersDatabaseName);
            _savedSearches = _database.GetCollection<BsonDocument>(CommonConstants.SavedSearchesCollectionName);
            contentListService = new ContentListService();
            // Azure Search
            string searchServiceName = AppSettings.SearchServiceName;
            string apiKey = AppSettings.SearchServiceQueryApiKey;

            // Create an HTTP reference to the catalog index
            _searchClient = new SearchServiceClient(searchServiceName, new SearchCredentials(apiKey));
            _seriesIndexClient = _searchClient.Indexes.GetClient(AppSettings.SeriesIndexName);
            _profiledSeriesIndexClient = _searchClient.Indexes.GetClient(AppSettings.ProfiledSeriesIndexName);
        }

        public async Task<NoSqlServiceResult<SearchSavedSearchResponse>> GetUserSavedSearches(SearchSavedSearchRequest savedSearchRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SearchSavedSearchResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonSavedSearches = new List<BsonDocument>();

                SearchSavedSearchResponse savedSearchResponse = new SearchSavedSearchResponse();
                ArrayList ltSavedSearchListing = new ArrayList();

                string sortField = ConvertToSavedSearchesSortField(savedSearchRequest.SortOnField);

                var builder = Builders<BsonDocument>.Filter;
                var filter = builder.Eq("UserID", savedSearchRequest.UserID);

                if (!string.IsNullOrEmpty(savedSearchRequest.SavedSearchID))
                {
                    filter = filter & builder.Eq("_id", ObjectId.Parse(savedSearchRequest.SavedSearchID));
                }

                var sort = Builders<BsonDocument>.Sort.Ascending(sortField);

                if (savedSearchRequest.SortOnDirection == "desc")
                {
                    sort = Builders<BsonDocument>.Sort.Descending(sortField);
                }
                
                while (retries > 0)
                {
                    try
                    {
                        bsonSavedSearches = await _savedSearches.Find(filter).Sort(sort).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                foreach (var document in bsonSavedSearches)
                {
                    // process document
                    SavedSearches mongoSavedSearches = BindSavedSearches(document);

                    SearchSeriesItem searchSeriesItem = new SearchSeriesItem();
                    searchSeriesItem.SearchName = mongoSavedSearches.SearchName;

                    ArrayList lstSearchTermCriteria = new ArrayList();

                    if (document.Contains("_id"))
                    {
                        searchSeriesItem.SavedSearchID = document["_id"].AsObjectId.ToString();
                    }

                    if (mongoSavedSearches.ProgramTypes != null)
                    { 
                        searchSeriesItem.ProgramType = (string[])mongoSavedSearches.ProgramTypes.ToArray();
                    }

                    if (mongoSavedSearches.FormatTypes != null)
                    { 
                        searchSeriesItem.Format = (string[])mongoSavedSearches.FormatTypes.ToArray();
                    }

                    if (mongoSavedSearches.SeriesStatus != null)
                    { 
                        searchSeriesItem.SeriesStatus = (string[])mongoSavedSearches.SeriesStatus.ToArray();
                    }

                    if (mongoSavedSearches.AreasOfInterest != null)
                    { 
                        searchSeriesItem.AreasOfInterest = (string[])mongoSavedSearches.AreasOfInterest.ToArray();
                    }

                    if (mongoSavedSearches.Audience != null)
                    { 
                        searchSeriesItem.SeriesAudience = (string[])mongoSavedSearches.Audience.ToArray();
                    }
                   
                    if (mongoSavedSearches.FootprintInformation != null && mongoSavedSearches.FootprintInformation.UpdatedDate != null)
                    {
                        searchSeriesItem.LastDateUpdated = mongoSavedSearches.FootprintInformation.UpdatedDate.ToString("MM/dd/yyyy");
                    }

                    if (mongoSavedSearches.LastIssueListPriceMinimum.HasValue)
                    {
                        searchSeriesItem.LastIssueListPriceMinimum = mongoSavedSearches.LastIssueListPriceMinimum.Value;
                    }

                    if (mongoSavedSearches.LastIssueListPriceMaximum.HasValue)
                    {
                        searchSeriesItem.LastIssueListPriceMaximum = mongoSavedSearches.LastIssueListPriceMaximum.Value;
                    }

                    if (mongoSavedSearches.SearchTerms != null)
                    { 
                        foreach (SearchTerms searchTerm in mongoSavedSearches.SearchTerms)
                        {
                            lstSearchTermCriteria.Add(new SearchTermCriteria { 
                                                    Attribute = searchTerm.SearchTerm, 
                                                    SearchJoin = searchTerm.SearchJoin, 
                                                    SearchTermValue = searchTerm.SearchCriteria, 
                                                    SearchType = searchTerm.SearchType });
                        
                        }

                        searchSeriesItem.SearchTermCriteria = (SearchTermCriteria[])lstSearchTermCriteria.ToArray(typeof(SearchTermCriteria));
                    }

                    searchSeriesItem.HasFilter = (mongoSavedSearches.ProgramTypes != null && mongoSavedSearches.ProgramTypes.Count > 0) ||
                                                    (mongoSavedSearches.FormatTypes != null && mongoSavedSearches.FormatTypes.Count > 0) ||
                                                    (mongoSavedSearches.SeriesStatus != null && mongoSavedSearches.SeriesStatus.Count > 0) ||
                                                    (mongoSavedSearches.AreasOfInterest != null && mongoSavedSearches.AreasOfInterest.Count > 0) ||
                                                    (mongoSavedSearches.LastIssueListPriceMinimum.HasValue && mongoSavedSearches.LastIssueListPriceMaximum.HasValue);

                    ltSavedSearchListing.Add(searchSeriesItem);
                }

                savedSearchResponse.SearchSeriesItemListing = (SearchSeriesItem[])ltSavedSearchListing.ToArray(typeof(SearchSeriesItem));
                noSqlServiceResult.Data = savedSearchResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SearchSavedSearchResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetUserSavedSearches", savedSearchRequest.UserID);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<bool>> DeleteSavedSearch(SearchSavedSearchRequest searchActionRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            
            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;

                int retries = AppSettings.MaxConnectionRetries;

                var filter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(searchActionRequest.SavedSearchID));

                while (retries > 0)
                {
                    try
                    {
                        await _savedSearches.DeleteOneAsync(filter);

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                noSqlServiceResult.Data = true;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = false;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "DeleteSavedSearch", searchActionRequest.SavedSearchID);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<SeriesListResponse>> AzureSearch(AzureSearchRequest searchRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesListResponse> { Status = NoSqlServiceStatus.Success };
            SeriesListResponse seriesListResponse = new SeriesListResponse();
            ArrayList ltSeriesListing = new ArrayList();
            ArrayList ltFacetListing = new ArrayList();
            var seriesIds = new List<string>();

            try
            {
                SearchSeriesItem searchSeriesItem = new SearchSeriesItem();

                if (searchRequest.SearchSeriesQuery != null)
                { 
                    searchSeriesItem = JsonConvert.DeserializeObject<SearchSeriesItem>(searchRequest.SearchSeriesQuery);
                }

                SearchSeriesItem searchRefinersItem = new SearchSeriesItem();
                if (searchRequest.SearchRefinersQuery != null)
                {
                    searchRefinersItem = JsonConvert.DeserializeObject<SearchSeriesItem>(searchRequest.SearchRefinersQuery);
                }

                if(!string.IsNullOrEmpty(searchRequest.PublicationCategoryId))
                {
                    seriesIds = await contentListService.getPublicationCategorySeriesIds(searchRequest.PublicationCategoryId);
                }
                else if(!string.IsNullOrEmpty(searchRequest.PublicationSubcategoryId))
                {
                    seriesIds = await contentListService.getPublicationSubcategorySeriesIds(searchRequest.PublicationSubcategoryId);
                }

                string searchText = string.IsNullOrEmpty(searchRequest.SearchValue) ? "*" : searchRequest.SearchValue;
                if(string.Equals("Series ID", searchRequest.SearchField, StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(searchText))
                {
                    searchText = searchText.TrimStart('0');
                }

                var response = await SearchSeries(searchText, searchRequest.SearchField,
                                            searchSeriesItem, searchRefinersItem, "", 
                                            searchRequest.SortOnField,
                                            searchRequest.SortOnDirection, searchRequest.PageNumber, searchRequest.PageSize, seriesIds, searchRequest.ContentListID, searchRequest.ProductType);

                if (response == null)
                {
                    noSqlServiceResult.Data = new SeriesListResponse();
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                    noSqlServiceResult.ErrorMessage = "Search Error! Please contact administrator.";

                    return noSqlServiceResult;
                }

                seriesListResponse.Count = response.Count;

                foreach (KeyValuePair<string, IList<FacetResult>> kvp in response.Facets)
                {
                    FacetSearchResult facetSearchResult = new FacetSearchResult();


                     
                     facetSearchResult.DisplayText = BindSearchFacetDisplay(kvp.Key);

                     ArrayList ltFacetSearchItem = new ArrayList();

                     if (string.Equals(kvp.Key, "ProfileOrgIDList", StringComparison.OrdinalIgnoreCase))
                     {
                         ltFacetSearchItem = BuildSeriesWithinProfileFacet(kvp.Value, searchRequest.OrganizationID);
                         facetSearchResult.FacetKey = "SeriesWithinProfile";
                         if (ltFacetSearchItem.Count > 0)
                         {
                             facetSearchResult.FacetSearchItem = (FacetSearchItem[])ltFacetSearchItem.ToArray(typeof(FacetSearchItem));
                             facetSearchResult.Count = facetSearchResult.FacetSearchItem.Sum(fv => fv.Count);

                             ltFacetListing.Add(facetSearchResult);
                         }
                     }
                     else
                     {
                         facetSearchResult.FacetKey = kvp.Key;

                         foreach (FacetResult facetResult in kvp.Value)
                         {
                             FacetSearchItem facetSearchItem = new FacetSearchItem();

                             facetSearchItem.Count = facetResult.Count;
                             facetSearchItem.FacetValue = facetResult.Value.ToString();
                             facetSearchItem.FacetText = facetResult.Value.ToString();

                             ltFacetSearchItem.Add(facetSearchItem);
                         }
                         if (ltFacetSearchItem.Count > 0)
                         {
                             facetSearchResult.FacetSearchItem = (FacetSearchItem[])ltFacetSearchItem.ToArray(typeof(FacetSearchItem));
                             facetSearchResult.Count = kvp.Value.Sum(fv => fv.Count);

                             ltFacetListing.Add(facetSearchResult);
                         }
                     }

                     
                }

                ArrayList ltSeriesInProfile = new ArrayList();

                foreach (var searchResult in response.Results)
                {
                    var seriesItem = BindSeriesItem(searchResult.Document, searchRequest.OrganizationID);
                    ltSeriesListing.Add(seriesItem);
                }

                seriesListResponse.SeriesListing = (SeriesItem[])ltSeriesListing.ToArray(typeof(SeriesItem));
                seriesListResponse.FacetListing = (FacetSearchResult[])ltFacetListing.ToArray(typeof(FacetSearchResult));
                noSqlServiceResult.Data = seriesListResponse;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;

                noSqlServiceResult.Data = new SeriesListResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "AzureSearch", "");
            }

            return noSqlServiceResult;
        }

        private SeriesItem BindSeriesItem(SeriesSearchResultItem seriesSearchResultItem, string organizationID)
        {
            var seriesItem = new SeriesItem();
            seriesItem.SeriesID = seriesSearchResultItem.SeriesID;
            seriesItem.SeriesName = seriesSearchResultItem.Name;
            seriesItem.Status = seriesSearchResultItem.Status;
            seriesItem.Publisher = seriesSearchResultItem.Publisher;
            seriesItem.Frequency = seriesSearchResultItem.Frequency;


            seriesItem.ProgramType = string.IsNullOrEmpty(seriesSearchResultItem.ProgramsForSort) ? "" : seriesSearchResultItem.ProgramsForSort.Replace(",", ", ");
            seriesItem.Format = seriesSearchResultItem.Format;
            seriesItem.Audience = seriesSearchResultItem.Audience;

            seriesItem.LastIssueISBN = seriesSearchResultItem.ISBN;
            seriesItem.LastIssueBTKey = seriesSearchResultItem.BTKey;
            seriesItem.LastIssueEdition = seriesSearchResultItem.Edition;
            if (seriesSearchResultItem.PublicationDate.HasValue)
            {
                seriesItem.LastIssuePublishDate = seriesSearchResultItem.PublicationDate.Value.DateTime;
            }
            seriesItem.LastIssueListPrice = seriesSearchResultItem.ListPrice;

            seriesItem.HasRelatedSeries = seriesSearchResultItem.HasRelatedSeries.HasValue ? seriesSearchResultItem.HasRelatedSeries.Value : false;
            seriesItem.RelatedSeriesIDs = seriesSearchResultItem.RelatedSeriesIDs;
            seriesItem.StartDataType = seriesSearchResultItem.StartDataType;
            seriesItem.Distributor = seriesSearchResultItem.Distributor;
            seriesItem.HasBindingPreferences = seriesSearchResultItem.HasBindingPreferences.HasValue ? seriesSearchResultItem.HasBindingPreferences.Value: false;
            seriesItem.Programs = seriesSearchResultItem.Programs;

            if (seriesItem.HasBindingPreferences)
            {
                var bindingPreferences = new List<BindingPreference>();
                var bindingPreference = new BindingPreference();
                bindingPreference.Literal = seriesSearchResultItem.BindingPreferenceLiteral1;
                bindingPreference.PrimaryPreference = seriesSearchResultItem.BindingPreferencePrimaryPreference1;
                bindingPreference.SecondaryPreference = seriesSearchResultItem.BindingPreferenceSecondaryPreference1;
                bindingPreference.HasMultiplePreference = seriesSearchResultItem.BindingPreferenceHasMultiplePreference1.HasValue ? seriesSearchResultItem.BindingPreferenceHasMultiplePreference1.Value : false;
                bindingPreferences.Add(bindingPreference);

                bindingPreference = new BindingPreference();
                bindingPreference.Literal = seriesSearchResultItem.BindingPreferenceLiteral2;
                bindingPreference.PrimaryPreference = seriesSearchResultItem.BindingPreferencePrimaryPreference2;
                bindingPreference.SecondaryPreference = seriesSearchResultItem.BindingPreferenceSecondaryPreference2;
                bindingPreference.HasMultiplePreference = seriesSearchResultItem.BindingPreferenceHasMultiplePreference2.HasValue ? seriesSearchResultItem.BindingPreferenceHasMultiplePreference2.Value : false;
                bindingPreferences.Add(bindingPreference);

                bindingPreference = new BindingPreference();
                bindingPreference.Literal = seriesSearchResultItem.BindingPreferenceLiteral3;
                bindingPreference.PrimaryPreference = seriesSearchResultItem.BindingPreferencePrimaryPreference3;
                bindingPreference.SecondaryPreference = seriesSearchResultItem.BindingPreferenceSecondaryPreference3;
                bindingPreference.HasMultiplePreference = seriesSearchResultItem.BindingPreferenceHasMultiplePreference3.HasValue ? seriesSearchResultItem.BindingPreferenceHasMultiplePreference3.Value : false;
                bindingPreferences.Add(bindingPreference);

                bindingPreference = new BindingPreference();
                bindingPreference.Literal = seriesSearchResultItem.BindingPreferenceLiteral4;
                bindingPreference.PrimaryPreference = seriesSearchResultItem.BindingPreferencePrimaryPreference4;
                bindingPreference.SecondaryPreference = seriesSearchResultItem.BindingPreferenceSecondaryPreference4;
                bindingPreference.HasMultiplePreference = seriesSearchResultItem.BindingPreferenceHasMultiplePreference4.HasValue ? seriesSearchResultItem.BindingPreferenceHasMultiplePreference4.Value : false;
                bindingPreferences.Add(bindingPreference);
                
                seriesItem.BindingPreferences = bindingPreferences.OrderByDescending(x => x.HasMultiplePreference).ThenBy(x => x.Literal).ToList();
            }

            
            seriesItem.ProfileIDListByOrg = new List<string>();

            if (seriesSearchResultItem.ProfileOrgIDList != null)
            {
                List<string> profileOrgIDList = seriesSearchResultItem.ProfileOrgIDList.FindAll(fo => fo.StartsWith(organizationID));

                if (profileOrgIDList != null && profileOrgIDList.Count > 0)
                {
                    for (int p = 0; p < profileOrgIDList.Count; p++)
                    {
                        // format orgid | profile id | request status | profile name
                        string[] profileOrgIDItems = profileOrgIDList[p].Split('|');

                        if (profileOrgIDItems != null && profileOrgIDItems.Length >= 4)
                        {
                            if (p == 0)
                            {
                                seriesItem.ProfileID = profileOrgIDItems[1];
                                seriesItem.RequestStatus = profileOrgIDItems[2].Trim();

                            }

                            if (!string.IsNullOrEmpty(profileOrgIDItems[1]))
                            {
                                if (!seriesItem.ProfileIDListByOrg.Contains(profileOrgIDItems[1]))
                                {
                                    seriesItem.ProfileIDListByOrg.Add(profileOrgIDItems[1]);
                                }
                            }
                        } // end profileOrgIDItems
                    } // end for: seek org id
                } // profileOrgIDList
            } // end profiledSeriesIndex.ProfileOrgIDList
            return seriesItem;
        }

        private ArrayList BuildSeriesWithinProfileFacet(IList<FacetResult> facetList, string organizationID)
        {
            ArrayList ltFacetSearchItem = new ArrayList();
            foreach (FacetResult facetResult in facetList)
            {
                if (facetResult.Value.ToString().StartsWith(organizationID))
                {
                    string[] profileOrgIDItems = facetResult.Value.ToString().Split('|');
                    if (profileOrgIDItems != null && profileOrgIDItems.Length >= 4)
                    {
                        FacetSearchItem facetSearchItem = new FacetSearchItem();
                        facetSearchItem.FacetText = profileOrgIDItems[3];
                        facetSearchItem.FacetValue = profileOrgIDItems[1];
                        facetSearchItem.Count = facetResult.Count;
                        ltFacetSearchItem.Add(facetSearchItem);
                    }
                }
            }
            return ltFacetSearchItem;
        }

        public async Task<NoSqlServiceResult<bool>> AddSaveSearches(SaveSearchesRequest saveSearchesRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };

            try
            {
                var builder = Builders<BsonDocument>.Filter;
                var filter = builder.Eq("UserID", saveSearchesRequest.UserID) & builder.Eq("SearchName", saveSearchesRequest.SearchName);

                var savedSearchResult = _savedSearches.Find(filter);
                long count = savedSearchResult.ToList().Count;

                if (count == 0)
                {
                    await InsertSavedSearches(GetSaveSearchesRequest(saveSearchesRequest));
                }
                else
                {
                    if (saveSearchesRequest.isOverwrite)
                    {
                        var savedSearch = savedSearchResult.First();

                        SavedSearches searchRequest = GetSaveSearchesRequest(saveSearchesRequest);
                        searchRequest.FootprintInformation.CreatedBy = savedSearch["FootprintInformation"]["CreatedBy"].AsString;
                        searchRequest.FootprintInformation.CreatedDate = savedSearch["FootprintInformation"]["CreatedDate"].ToUniversalTime();
                        searchRequest.FootprintInformation.CreatedByUserID = savedSearch["FootprintInformation"]["CreatedByUserID"].AsString;

                        await ReplaceSavedSearches(savedSearch["_id"].AsObjectId, searchRequest);
                    }
                    else
                    {
                        throw new SavedSeriesSearchException();
                    }
                }

            }
            catch (SavedSeriesSearchException ssse)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = ssse.ErrorCode;
                noSqlServiceResult.ErrorMessage = ssse.ErrorMessage;

                // Error code returned to UI for error handling

                /*LoggerService logger = new LoggerService();
                logger.LogError(ssse, "saveSearchesRequest", saveSearchesRequest.ToString());*/
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "saveSearchesRequest", saveSearchesRequest.ToString());
            }
            return noSqlServiceResult;

        }

        private string MapSaveProgramType(string fromProgramType)
        {
            string programType = fromProgramType;

            if (fromProgramType == "Automatically Yours")
            {
                programType = "Automatically Yours(AY)";
            }
            else if (fromProgramType == "Children and Teens")
            {
                programType = "Children and Teens(CATS)";
            }
            else if (fromProgramType == "Continuations")
            {
                programType = "Continuations(CONTIN)";
            }

            return programType;

        }
        private string BindSearchFacetDisplay(string key)
        {
            string retVal = "";

            if (key == "Programs")
                retVal = SearchConstants.AzureSearchFilterDisplay.PROGRAM;
            else if (key == "Status")
                retVal = SearchConstants.AzureSearchFilterDisplay.STATUS;
            else if (key == "Format")
                retVal = SearchConstants.AzureSearchFilterDisplay.FORMAT;
            else if (key == "Audience")
                retVal = SearchConstants.AzureSearchFilterDisplay.AUDIENCE;
            else if (key == "PublicationDateRange")
                retVal = SearchConstants.AzureSearchFilterDisplay.PUBLISHED_DATE;
            else if (key == "ProfileOrgIDList")
                retVal = SearchConstants.AzureSearchFilterDisplay.SERIES_WITHIN_PROFILE;

            return retVal;
        }
        private string SplitStringFromList(List<string> splitString)
        {
            string result = "";


            if (splitString != null && splitString.Count > 0)
            {
                foreach (string s in splitString)
                {
                    result += ((string.IsNullOrEmpty(result) ? "" : ", ") + s);

                }
            }
            return result;

        }

        private async Task<DocumentSearchResult<SeriesSearchResultItem>> SearchSeries(string searchText, string searchField, SearchSeriesItem searchSeriesItemRequest, SearchSeriesItem searchRefinersRequest, 
                                                    string pubReleaseDateFacet, 
                                                    string sortType, string sortOnDirection, int currentPage,
                                                    int? pageSize, List<string> seriesIds, string contentListID, string productType)
        {

            string searchQuery = null;
            // Execute search based on query string
            try
            {
                SearchParameters sp = new SearchParameters()
                {
                    SearchMode = SearchMode.All,
                    QueryType = QueryType.Full,
                    Top = pageSize,
                    Skip = (currentPage - 1) * pageSize,
                    Select = new List<String>() { 
                        "SeriesID", "Name", "Status", 
                        "Publisher", "Frequency", "Format", "Audience",
                        "ISBN", "Edition", "ListPrice",
                        "PublicationDate", "Programs", "ProgramsForSort",
                        "ProfileOrgIDList", "BTKey", "HasRelatedSeries", "RelatedSeriesIDs", "StartDataType",
                        "Distributor", "HasBindingPreferences", "BindingPreferenceLiteral1", "BindingPreferencePrimaryPreference1", "BindingPreferenceSecondaryPreference1", "BindingPreferenceHasMultiplePreference1", 
                        "BindingPreferenceLiteral2", "BindingPreferencePrimaryPreference2", "BindingPreferenceSecondaryPreference2", "BindingPreferenceHasMultiplePreference2",
                        "BindingPreferenceLiteral3", "BindingPreferencePrimaryPreference3", "BindingPreferenceSecondaryPreference3", "BindingPreferenceHasMultiplePreference3",
                        "BindingPreferenceLiteral4", "BindingPreferencePrimaryPreference4", "BindingPreferenceSecondaryPreference4", "BindingPreferenceHasMultiplePreference4"
                    },
                    // Add count
                    IncludeTotalResultCount = true,
                    //Facets = new List<String>() { "Programs", "Status", "Format", "Audience", "PublicationDate"}
                    Facets = new List<String>() { "Programs", "Status", "Format", "Audience", "PublicationDateRange", "ProfileOrgIDList,count:10000" }
                };
                // Define the sort type
                if (sortType == "SeriesName")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "Name", sortOnDirection=="desc"?"desc":"") };
                }
                else if (sortType == "SeriesID")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "SeriesID", sortOnDirection == "desc" ? "desc" : "") };
                }
                else if (sortType == "ProgramType")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "ProgramsForSort", sortOnDirection == "desc" ? "desc" : "") };
                }
                else if (sortType == "Frequency")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "Frequency", sortOnDirection == "desc" ? "desc" : "") };
                }
                else if (sortType == "LastIssuePublishDate")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "PublicationDate", sortOnDirection == "desc" ? "desc" : "") };
                }
                else if (sortType == "LastIssueListPrice")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "ListPrice", sortOnDirection == "desc" ? "desc" : "") };
                }
                else if (sortType == "Publisher")
                {
                    sp.OrderBy = new List<String>() { string.Format("{0} {1}", "Publisher", sortOnDirection == "desc" ? "desc" : "") };
                }

                // Add filtering
                string tmpfilter = null;
                string filter = null;
                if (seriesIds != null && seriesIds.Any())
                {
                    if (string.IsNullOrEmpty(searchField))
                        searchQuery = "*";
                    int counter = 0;
                    foreach (var seriesId in seriesIds)
                    {
                        if (counter == 0)
                        {
                            filter += "(SeriesID eq '" + seriesId + "'";
                        }
                        else if (counter == (seriesIds.Count() - 1))
                        {
                            filter += " or SeriesID eq '" + seriesId + "')";
                        }
                        else
                        {
                            filter += " or SeriesID eq '" + seriesId + "'";
                        }
                        counter++;
                    }
                }


                if (!string.IsNullOrEmpty(contentListID))
                {
                    tmpfilter += "ContentListIDList/any(t: t eq '" + contentListID + "')";
                    filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                }
                else if (!string.IsNullOrEmpty(productType))
                {
                    var productTypeList = productType.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries).Select(Int32.Parse).ToList();
                    if (productTypeList.Count == 1)
                    {
                        tmpfilter += "ProductType/any(s: s eq '" + (ProductTypes)productTypeList[0] + "')";

                    }
                    else
                    {
                        tmpfilter += "ProductType/any(s: ";
                        var isFirst = true;
                        foreach (var type in productTypeList)
                        {
                            if (isFirst)
                            {
                                tmpfilter += "s eq '" + (ProductTypes)type + "'";
                                isFirst = false;
                            }
                            else
                            {
                                tmpfilter += " or s eq '" + (ProductTypes)type + "'";
                            }
                        }
                        tmpfilter += ")";

                    }

                    filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                }

                // Advanced Search Request
                if (searchSeriesItemRequest != null)
                {
                    // Search query with criteria
                    if (searchSeriesItemRequest.SearchTermCriteria != null)
                    {
                        tmpfilter = "";
                        foreach (SearchTermCriteria searchTermCriteria in searchSeriesItemRequest.SearchTermCriteria)
                        {
                            if (searchTermCriteria.Attribute == "ISBN")
                            {
                                if (!string.IsNullOrEmpty(tmpfilter))
                                {
                                    tmpfilter += searchTermCriteria.SearchJoin.ToUpper();
                                }

                                switch (searchTermCriteria.SearchType)
                                {
                                    case "Exact":
                                        tmpfilter += "(ISBNList/any(t: t eq '" + searchTermCriteria.SearchTermValue + "')";
                                        tmpfilter += " or ISBN10List/any(t: t eq '" + searchTermCriteria.SearchTermValue + "'))";
                                        break;
                                    case "Contains":
                                        //tmpfilter += "ISBNList/any(t: t eq '/.*" + searchTermCriteria.SearchTermValue + ".*/')";
                                        if (!string.IsNullOrEmpty(searchQuery))
                                        {
                                            searchQuery += string.Format(" {0} ", searchTermCriteria.SearchJoin.ToUpper());
                                        }
                                        searchQuery += ("(ISBNList:/.*" + searchTermCriteria.SearchTermValue + ".*/");
                                        searchQuery += (" OR ISBN10List:/.*" + searchTermCriteria.SearchTermValue + ".*/)");
                                        break;
                                    case "Ends With":
                                        //tmpfilter += "ISBNList/any(t: t eq '/.*" + searchTermCriteria.SearchTermValue + "')";
                                        if (!string.IsNullOrEmpty(searchQuery))
                                        {
                                            searchQuery += string.Format(" {0} ", searchTermCriteria.SearchJoin.ToUpper());
                                        }
                                        searchQuery += ("(ISBNList:/.*" + searchTermCriteria.SearchTermValue + "/");
                                        searchQuery += (" OR ISBN10List:/.*" + searchTermCriteria.SearchTermValue + "/)");
                                        break;
                                    case "Begins With":
                                        if (!string.IsNullOrEmpty(searchQuery))
                                        {
                                            searchQuery += string.Format(" {0} ", searchTermCriteria.SearchJoin.ToUpper());
                                        }
                                        searchQuery += ("(ISBNList:/" + searchTermCriteria.SearchTermValue + ".*/");
                                        searchQuery += (" OR ISBN10List:/" + searchTermCriteria.SearchTermValue + ".*/)");
                                        break;
                                    default:
                                        break;
                                }
                            } // end ISBN
                            else
                            {
                                if (!string.IsNullOrEmpty(searchQuery))
                                {
                                    searchQuery += string.Format(" {0} ", searchTermCriteria.SearchJoin.ToUpper());
                                }
                                var searchTermValue = searchTermCriteria.SearchTermValue.Replace("#apos#", "'").Replace("#quote#", "");
                                if (!string.IsNullOrEmpty(searchTermValue))
                                {
                                    searchTermValue = CommonHelper.RemoveSpecialCharacters(searchTermValue);
                                }
                                if (string.Equals(searchTermCriteria.Attribute, "Series ID", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(searchTermValue))
                                {
                                    searchTermValue = searchTermValue.TrimStart('0');
                                }

                                var keywordTokenizerAttributes = MapKeywordTokenizer(searchTermCriteria.Attribute);
                                var arrKeywordTokenizerAttributes = keywordTokenizerAttributes.Split(',');
                                for (int k = 0; k < arrKeywordTokenizerAttributes.Length; k++)
                                {
                                    if (k == 0 && arrKeywordTokenizerAttributes.Length > 1)
                                    {
                                        searchQuery += " ( ";
                                    }

                                    if (k > 0)
                                    {
                                        searchQuery += " OR ";
                                    }

                                    if (searchTermCriteria.SearchType == "Exact")
                                    {
                                        searchQuery += (arrKeywordTokenizerAttributes[k] + ":/" + searchTermValue + "/");
                                        //searchQuery += (MapKeywordTokenizer(searchTermCriteria.Attribute) + ":/" + searchTermValue + "/");
                                    }
                                    else if (searchTermCriteria.SearchType == "Contains")
                                    {
                                        searchQuery += (arrKeywordTokenizerAttributes[k] + ":/.*" + searchTermValue + ".*/");
                                        //searchQuery += (MapKeywordTokenizer(searchTermCriteria.Attribute) + ":/.*" + searchTermValue + ".*/");
                                    }
                                    else if (searchTermCriteria.SearchType == "Ends With")
                                    {
                                        searchQuery += (arrKeywordTokenizerAttributes[k] + ":/.*" + searchTermValue + "/");
                                        //searchQuery += (MapKeywordTokenizer(searchTermCriteria.Attribute) + ":/.*" + searchTermValue + "/");
                                    }
                                    else if (searchTermCriteria.SearchType == "Begins With")
                                    {
                                        searchQuery += (arrKeywordTokenizerAttributes[k] + ":/" + searchTermValue + ".*/");
                                        //searchQuery += (MapKeywordTokenizer(searchTermCriteria.Attribute) + ":/" + searchTermValue + ".*/");
                                    }

                                    if (k == arrKeywordTokenizerAttributes.Length - 1 && arrKeywordTokenizerAttributes.Length > 1)
                                    {
                                        searchQuery += " ) ";
                                    }
                                } // end for arrKeyworkdTokenizer
                            } // end else
                        } //foreach

                        if (!string.IsNullOrEmpty(tmpfilter))
                        { 
                            filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                        }
                    } // search term criteria

                    //
                    // filter search
                    //

                    // filter search: Program Type

                    if (searchSeriesItemRequest.ProgramType != null && searchSeriesItemRequest.ProgramType.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string programType in searchSeriesItemRequest.ProgramType)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Programs/any(t: t eq '" + MapProgramType(programType) + "')";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                    if (searchRefinersRequest.ProgramType != null && searchRefinersRequest.ProgramType.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string programType in searchRefinersRequest.ProgramType)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Programs/any(t: t eq '" + programType + "')";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }
                    

                    // filter search: Series Status
                    if (searchRefinersRequest.SeriesStatus != null && searchRefinersRequest.SeriesStatus.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string seriesStatus in searchRefinersRequest.SeriesStatus)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Status eq '" + seriesStatus + "'";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }
                    else if (searchSeriesItemRequest.SeriesStatus != null && searchSeriesItemRequest.SeriesStatus.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string seriesStatus in searchSeriesItemRequest.SeriesStatus)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Status eq '" + seriesStatus + "'";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                    // filter search: Areas of Interest
                    if (searchSeriesItemRequest.AreasOfInterest != null && searchSeriesItemRequest.AreasOfInterest.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string areaOfInterest in searchSeriesItemRequest.AreasOfInterest)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "AreasOfInterest/any(t: t eq '" + areaOfInterest.Replace("#apos#", "''").Replace("#quote#", "") + "')";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                    // filter search: Series Audience
                    if (searchRefinersRequest.SeriesAudience != null && searchRefinersRequest.SeriesAudience.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string seriesAudience in searchRefinersRequest.SeriesAudience)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Audience eq '" + seriesAudience + "'";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }
                    else if (searchSeriesItemRequest.SeriesAudience != null && searchSeriesItemRequest.SeriesAudience.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string seriesAudience in searchSeriesItemRequest.SeriesAudience)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Audience eq '" + seriesAudience + "'";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                    // filter search: Series Format
                    if (searchRefinersRequest.Format != null && searchRefinersRequest.Format.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string format in searchRefinersRequest.Format)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Format eq '" + format + "'";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }
                    else if (searchSeriesItemRequest.Format != null && searchSeriesItemRequest.Format.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string format in searchSeriesItemRequest.Format)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "Format eq '" + format + "'";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                    // filter search: Min. price / Max. price
                    if (
                        (searchSeriesItemRequest.LastIssueListPriceMinimum != null && searchSeriesItemRequest.LastIssueListPriceMinimum > 0) ||
                        (searchSeriesItemRequest.LastIssueListPriceMaximum != null && searchSeriesItemRequest.LastIssueListPriceMaximum > 0)
                       )
                    {
                        tmpfilter = "";
                        if (searchSeriesItemRequest.LastIssueListPriceMinimum != null && searchSeriesItemRequest.LastIssueListPriceMinimum > 0)
                        {
                            tmpfilter = "ListPrice ge " + searchSeriesItemRequest.LastIssueListPriceMinimum;
                        }

                        if (searchSeriesItemRequest.LastIssueListPriceMaximum != null && searchSeriesItemRequest.LastIssueListPriceMaximum > 0)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " and ";
                            }

                            tmpfilter += "ListPrice le " + searchSeriesItemRequest.LastIssueListPriceMaximum;
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                    // filter search: pub. date
                    if (searchRefinersRequest.LastIssuePublishDateRange != null && searchRefinersRequest.LastIssuePublishDateRange.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string lastIssuePublishDateRange in searchRefinersRequest.LastIssuePublishDateRange)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += BuildFilterPublishDateRange(lastIssuePublishDateRange);
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }
                    else if (searchSeriesItemRequest.LastIssuePublishDateValue != null && searchSeriesItemRequest.LastIssuePublishDateValue.Length > 0 && !string.Equals(searchSeriesItemRequest.LastIssuePublishDateValue, "Custom", StringComparison.OrdinalIgnoreCase))
                    {
                        tmpfilter = BuildFilterPublishDateRange(searchSeriesItemRequest.LastIssuePublishDateValue);
                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" {0} ", tmpfilter));
                    }
                    else if (string.Equals(searchSeriesItemRequest.LastIssuePublishDateValue, "Custom", StringComparison.OrdinalIgnoreCase))
                    {
                        if(searchSeriesItemRequest.PublishDateFrom > DateTime.MinValue && searchSeriesItemRequest.PublishDateThrough > DateTime.MinValue)
                        {
                            filter += (string.IsNullOrEmpty(filter) ? "" : " and ") + " (PublicationDate ge " + searchSeriesItemRequest.PublishDateFrom.ToString("yyyy-MM-dd") + " and PublicationDate le " + searchSeriesItemRequest.PublishDateThrough.ToString("yyyy-MM-dd") + ") ";
                        }
                        else if(searchSeriesItemRequest.PublishDateFrom > DateTime.MinValue)
                        {
                            filter += (string.IsNullOrEmpty(filter) ? "" : " and ") + " (PublicationDate ge " + searchSeriesItemRequest.PublishDateFrom.ToString("yyyy-MM-dd") + ") ";
                        }
                        else
                        {
                            filter += (string.IsNullOrEmpty(filter) ? "" : " and ") + " (PublicationDate le " + searchSeriesItemRequest.PublishDateThrough.ToString("yyyy-MM-dd") + ") ";
                        }
                    
                   }

                    // filter search: Series Within Profile

                    if (searchRefinersRequest.SeriesWithinProfile != null && searchRefinersRequest.SeriesWithinProfile.Length > 0)
                    {
                        tmpfilter = "";
                        foreach (string seriesWithinProfile in searchRefinersRequest.SeriesWithinProfile)
                        {
                            if (!string.IsNullOrEmpty(tmpfilter))
                            {
                                tmpfilter += " or ";
                            }

                            tmpfilter += "ProfileIDList/any(t: t eq '" + seriesWithinProfile + "')";
                        }

                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));
                    }

                }//end advanced search

                if (!string.IsNullOrEmpty(searchField))
                {
                    if (searchField == "ISBN")
                    {
                        tmpfilter = "ISBNList/any(t: t eq '" + searchText + "')";
                        tmpfilter += " or ISBN10List/any(t: t eq '" + searchText + "')";
                        filter += ((string.IsNullOrEmpty(filter) ? "" : " and ") + string.Format(" ( {0} )", tmpfilter));

                    } // end ISBN
                    else
                    {
                        if(!string.IsNullOrEmpty(searchText))
                        {
                            searchText = CommonHelper.RemoveSpecialCharacters(searchText);
                        }
                        if (string.IsNullOrEmpty(searchQuery) && searchField != "Publisher/Distributor")
                        {
                            sp.SearchFields = new List<String>() { MapKeywordTokenizer(searchField) };
                            searchQuery = "/.*" + searchText + ".*/";
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(searchQuery))
                            { 
                                searchQuery += " AND ";
                            }

                            var keywordTokenizerAttributes = MapKeywordTokenizer(searchField);
                            var arrKeywordTokenizerAttributes = keywordTokenizerAttributes.Split(',');
                            for (int k = 0; k < arrKeywordTokenizerAttributes.Length; k++)
                            {
                                if (k == 0 && arrKeywordTokenizerAttributes.Length > 1)
                                {
                                    searchQuery += " ( ";
                                }

                                if (k > 0)
                                {
                                    searchQuery += " OR ";
                                }

                                searchQuery += (arrKeywordTokenizerAttributes[k] + ":/.*" + searchText + ".*/");
                                //searchQuery += MapKeywordTokenizer(searchField) + ":/.*" + searchText + ".*/";

                                if (k == arrKeywordTokenizerAttributes.Length - 1 && arrKeywordTokenizerAttributes.Length > 1)
                                {
                                    searchQuery += " ) ";
                                }
                            }
                        }
                    }
                }

                sp.Filter = filter;

                if (!AppSettings.AzureSearchValidateServerCertificate)
                {
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                }

                return await _seriesIndexClient.Documents.SearchAsync<SeriesSearchResultItem>(searchQuery, sp);
                
                //DocumentSearchResult<ProfilesSearchResultItem> searchResponse = await _profilesIndexClient.Documents.SearchAsync<ProfilesSearchResultItem>("Test", sp);
                /*DocumentSearchResult<AzureSearchSeriesIndex> searchResponse = _seriesIndexClient.Documents.Search<AzureSearchSeriesIndex>(searchText, sp);
                return searchResponse;*/
                

            }
            catch (Exception ex)
            {
                //Console.WriteLine("Error querying index: {0}\r\n", ex.Message.ToString());

                string msg = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "SearchSeries", "");
            }
            return null;

        }

        public async Task<NoSqlServiceResult<bool>> EmailSeriesInquiryRequest(EmailSeriesInquiryRequest emailSeriesInquiryRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };

            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                var emailToList = AppSettings.SeriesInquiryRequestEmailTo.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        mail.To.Add(emailTo);
                }
                mail.Subject = AppSettings.StandingOrdersEmailPrefix + "Series Inquiry";
                mail.Body = GetSeriesInquiryRequestEmailBody(emailSeriesInquiryRequest);
                mail.IsBodyHtml = true;

                client.Send(mail);

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "EmailSeriesInquiryRequest", "");
            }

            return noSqlServiceResult;
        }


        private string GetSeriesInquiryRequestEmailBody(EmailSeriesInquiryRequest emailSeriesInquiryRequest)
        {
            string emailBody = string.Empty;
            using (StreamReader reader = new StreamReader(HttpRuntime.AppDomainAppPath + @"Common\EmailTemplates\SeriesInquiryEmailTemplate.txt"))
            {
                emailBody = reader.ReadToEnd();
            }

            emailBody = emailBody.Replace("{ORGANIZATION_NAME}", emailSeriesInquiryRequest.OrganizationName);
            emailBody = emailBody.Replace("{CONTACT_PHONE}", emailSeriesInquiryRequest.OrgPhoneNumber);
            emailBody = emailBody.Replace("{USER_EMAIL}", emailSeriesInquiryRequest.UserEmail);
            emailBody = emailBody.Replace("{USER_LOGIN}", emailSeriesInquiryRequest.UserName);
            //emailBody = emailBody.Replace("{TITLE}", emailSeriesInquiryRequest.SeriesAuthor);
            emailBody = emailBody.Replace("{SERIES_AUHTOR}", emailSeriesInquiryRequest.SeriesAuthor);
            emailBody = emailBody.Replace("{ISBN}", emailSeriesInquiryRequest.ISBN);
            emailBody = emailBody.Replace("{PUBLISHER}", emailSeriesInquiryRequest.Publisher);
            emailBody = emailBody.Replace("{PUBLICATION_DATE}", emailSeriesInquiryRequest.PublicationDate);
            emailBody = emailBody.Replace("{LIST_PRICE}", emailSeriesInquiryRequest.ListPrice);
            emailBody = emailBody.Replace("{FORMAT}", emailSeriesInquiryRequest.Format);
            emailBody = emailBody.Replace("{EDITION_VOLUME}", emailSeriesInquiryRequest.Edition);
            emailBody = emailBody.Replace("{NOTE}", emailSeriesInquiryRequest.Notes);

            return emailBody;
        }

        private string MapSeriesColumn(string fromColumn)
        {
            string col = "";

            if (fromColumn == "Publisher/Distributor")
            {
                col = "Publisher";
            }
            else if (fromColumn == "Series/Author Name")
            {
                col = "Name";
            }
            else if (fromColumn == "Series ID")
            {
                col = "SeriesID";
            }
            // special handling for ISBN
            /*else if (fromColumn == "ISBN")
            {
                col = "ISBN";
            }*/

            return col;
           
        }
        private string MapKeywordTokenizer(string fromColumn)
        {
            string keywordTokenizer = "";

            if (fromColumn == "Publisher/Distributor")
            {
                keywordTokenizer = "PublisherKeyword,DistributorNoPunctuation";
            }
            else if (fromColumn == "Series/Author Name")
            {
                keywordTokenizer = "NameKeyword";
            }
            else if (fromColumn == "Series ID")
            {
                keywordTokenizer = "SeriesID";
            }

            return keywordTokenizer;
        }

        private string MapProgramType(string fromProgramType)
        {
            string programType = "";

            if (fromProgramType == "Automatically Yours(AY)")
            {
                programType = "Automatically Yours";
            }
            else if (fromProgramType == "Children and Teens(CATS)")
            {
                programType = "Children and Teens";
            }
            else if (fromProgramType == "Continuations(CONTIN)")
            {
                programType = "Continuations";
            }

            return programType;

        }

        /*private string MapPublicationRange(string fromPubValue)
        {
            string publicationRange = "";

            if (fromPubValue == "30D")
            {
                publicationRange = "Within next 30 Days";
            }
            else if (fromPubValue == "60D")
            {
                publicationRange = "Within next 60 Days";
            }
            else if (fromPubValue == "90D")
            {
                publicationRange = "Within next 90 Days";
            }
            else if (fromPubValue == "180D")
            {
                publicationRange = "Within next 180 Days";
            }
            else if (fromPubValue == "30D-")
            {
                publicationRange = "Within previous 30 Days";
            }
            else if (fromPubValue == "60D-")
            {
                publicationRange = "Within previous 60 Days";
            }
            else if (fromPubValue == "90D-")
            {
                publicationRange = "Within previous 90 Days";
            }
            else if (fromPubValue == "180D-")
            {
                publicationRange = "Within previous 180 Days";
            }

            return publicationRange;

        }*/

        /*private ArrayList BuildPublicationDateFacet(IList<FacetResult> facetResults)
        {
            ArrayList ltFacetPubDate = new ArrayList();
            string[] sortPubRange = new string[] { "30D", "60D", "90D", "180D", "30D-", "60D-", "90D-", "180D-" };
            
            Hashtable htPubDateRange = new Hashtable();
            
            DateTime today = DateTime.Today;

            htPubDateRange.Add("30D", 0);
            htPubDateRange.Add("60D", 0);
            htPubDateRange.Add("90D", 0);
            htPubDateRange.Add("180D", 0);
            htPubDateRange.Add("30D-", 0);
            htPubDateRange.Add("60D-", 0);
            htPubDateRange.Add("90D-", 0);
            htPubDateRange.Add("180D-", 0);

            foreach (FacetResult facetResult in facetResults)
            {
                DateTimeOffset dateOffset = DateTimeOffset.Parse(facetResult.Value.ToString());

                DateTime pubDate = dateOffset.DateTime ;
                long? facetCount = facetResult.Count;

                if (pubDate >= today && pubDate <= DateTime.Today.AddDays(30))
                {
                    object currValue = htPubDateRange["30D"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["30D"] = newCount;
                }

                if (pubDate >= today && pubDate <= DateTime.Today.AddDays(60))
                {
                    object currValue = htPubDateRange["60D"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["60D"] = newCount;
                }

                if (pubDate >= today && pubDate <= DateTime.Today.AddDays(90))
                {
                    object currValue = htPubDateRange["90D"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["90D"] = newCount;
                }

                if (pubDate >= today && pubDate <= DateTime.Today.AddDays(180))
                {
                    object currValue = htPubDateRange["180D"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["180D"] = newCount;
                }

                if (pubDate >= DateTime.Today.AddDays(-30) && pubDate <= today )
                {
                    object currValue = htPubDateRange["30D-"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["30D-"] = newCount;
                }

                if (pubDate >= DateTime.Today.AddDays(-60) && pubDate <= today)
                {
                    object currValue = htPubDateRange["60D-"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["60D-"] = newCount;
                }

                if (pubDate >= DateTime.Today.AddDays(-90) && pubDate <= today)
                {
                    object currValue = htPubDateRange["90D-"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["90D-"] = newCount;
                }

                if (pubDate >= DateTime.Today.AddDays(-180) && pubDate <= today)
                {
                    object currValue = htPubDateRange["180D-"];
                    long newCount = Convert.ToInt32(currValue) + facetCount.Value;
                    htPubDateRange["180D-"] = newCount;
                }
                
            }

            foreach (DictionaryEntry entry in htPubDateRange)
            {
                if (Convert.ToInt32(entry.Value) > 0)
                {
                    FacetSearchItem facetSearchItem = new FacetSearchItem();

                    facetSearchItem.Count = Convert.ToInt32(entry.Value);
                    facetSearchItem.FacetValue = entry.Key.ToString();
                    facetSearchItem.FacetText = MapPublicationRange(entry.Key.ToString());
                    facetSearchItem.Sequence = Array.IndexOf(sortPubRange, entry.Key.ToString());

                    ltFacetPubDate.Add(facetSearchItem);
                }
            }

            htPubDateRange.Clear();

            if (ltFacetPubDate.Count > 0)
                ltFacetPubDate = new ArrayList(ltFacetPubDate.Cast<FacetSearchItem>().OrderBy(r => r.Sequence).ToList<FacetSearchItem>());

            return ltFacetPubDate;

        }*/
        private string BuildFilterPublishDateRange(string fromDateValue)
        {
            string publishDateRange = "";
            string publishDateFormat = "(PublicationDate ge {0} and PublicationDate le {1})";

            if (fromDateValue == "30D" || fromDateValue == SearchConstants.PublicationDateRange.NEXT_30_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat, 
                                                    DateTime.Today.ToString("yyyy-MM-dd"), 
                                                    DateTime.Today.AddDays(30).ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "60D" || fromDateValue == SearchConstants.PublicationDateRange.NEXT_60_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                    DateTime.Today.ToString("yyyy-MM-dd"),
                                                    DateTime.Today.AddDays(60).ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "90D" || fromDateValue == SearchConstants.PublicationDateRange.NEXT_90_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                    DateTime.Today.ToString("yyyy-MM-dd"),
                                                    DateTime.Today.AddDays(90).ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "180D" || fromDateValue == SearchConstants.PublicationDateRange.NEXT_180_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                    DateTime.Today.ToString("yyyy-MM-dd"),
                                                    DateTime.Today.AddDays(180).ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "30D-" || fromDateValue == SearchConstants.PublicationDateRange.PREV_30_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                   DateTime.Today.AddDays(-30).ToString("yyyy-MM-dd"),
                                                   DateTime.Today.ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "60D-" || fromDateValue == SearchConstants.PublicationDateRange.PREV_60_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                   DateTime.Today.AddDays(-60).ToString("yyyy-MM-dd"),
                                                   DateTime.Today.ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "90D-" || fromDateValue == SearchConstants.PublicationDateRange.PREV_90_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                   DateTime.Today.AddDays(-90).ToString("yyyy-MM-dd"),
                                                   DateTime.Today.ToString("yyyy-MM-dd"));
            }
            else if (fromDateValue == "180D-" || fromDateValue == SearchConstants.PublicationDateRange.PREV_180_DAYS)
            {
                publishDateRange = string.Format(publishDateFormat,
                                                   DateTime.Today.AddDays(-180).ToString("yyyy-MM-dd"),
                                                   DateTime.Today.ToString("yyyy-MM-dd"));
            }
            return publishDateRange;

        }
        /*private DocumentSearchResult SearchProfiledSeries(string searchText, string bisacSubjectsFacet, string formatFacet, string pubReleaseDateFacet, string sortType, int currentPage)
        {
            try
            {
                SearchParameters sp = new SearchParameters()
                {
                    SearchMode = SearchMode.Any,
                    Top = 30,
                    Skip = currentPage - 1,
                    Select = new List<String>() { 
                        "SeriesID", "SeriesName", "ProfiledSeriesID",  "SeriesStatus", "RequestStatus",
                        "Publisher", "Frequency", "Format", "Audience",
                        "ISBN", "Edition", "PublicationDate", "ListPrice",
                        "ProfileName", "ShippingAccountNumber"
                    },
                    IncludeTotalResultCount = true,
                    
                };
                if (sortType == "featured")
                {
                    
                }

                // Add filtering
                string filter = null;

                sp.Filter = filter;

                if (!AppSettings.AzureSearchValidateServerCertificate)
                { 
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                }

                return _profiledSeriesIndexClient.Documents.Search(searchText, sp);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error querying index: {0}\r\n", ex.Message.ToString());
            }
            return null;
        }*/

        private SavedSearches GetSaveSearchesRequest(SaveSearchesRequest saveSearchesRequest)
        {
            SavedSearches savedSearches = new SavedSearches();

            savedSearches.UserID = saveSearchesRequest.UserID;
            savedSearches.SearchName = saveSearchesRequest.SearchName;

            if (saveSearchesRequest.SearchSeriesQuery != null || saveSearchesRequest.SearchRefinerQuery != null)
            {
                SearchSeriesItem searchSeriesItem = new SearchSeriesItem();
                SearchSeriesItem searchRefinerItem = new SearchSeriesItem();

                if (saveSearchesRequest.SearchSeriesQuery != null)
                    searchSeriesItem = JsonConvert.DeserializeObject<SearchSeriesItem>(saveSearchesRequest.SearchSeriesQuery);

                if (saveSearchesRequest.SearchRefinerQuery != null)
                    searchRefinerItem = JsonConvert.DeserializeObject<SearchSeriesItem>(saveSearchesRequest.SearchRefinerQuery);

                if (searchRefinerItem.ProgramType != null && searchRefinerItem.ProgramType.Length > 0)
                {
                    savedSearches.ProgramTypes = searchRefinerItem.ProgramType.Select(s => s.Replace(s, MapSaveProgramType(s))).ToList();
                }

                else if (searchSeriesItem.ProgramType != null && searchSeriesItem.ProgramType.Length > 0)
                    savedSearches.ProgramTypes = searchSeriesItem.ProgramType.ToList();

                if (searchRefinerItem.Format != null && searchRefinerItem.Format.Length > 0)
                    savedSearches.FormatTypes = searchRefinerItem.Format.ToList();
                else if (searchSeriesItem.Format != null && searchSeriesItem.Format.Length > 0)
                    savedSearches.FormatTypes = searchSeriesItem.Format.ToList();

                if (searchRefinerItem.SeriesStatus != null && searchRefinerItem.SeriesStatus.Length > 0)
                    savedSearches.SeriesStatus = searchRefinerItem.SeriesStatus.ToList();
                else if (searchSeriesItem.SeriesStatus != null && searchSeriesItem.SeriesStatus.Length > 0)
                    savedSearches.SeriesStatus = searchSeriesItem.SeriesStatus.ToList();

                if (searchSeriesItem.AreasOfInterest != null && searchSeriesItem.AreasOfInterest.Length > 0)
                    savedSearches.AreasOfInterest = searchSeriesItem.AreasOfInterest.Select(a => a.Replace("#apos#", "'").Replace("#quote#", "")).ToList();

                if (searchRefinerItem.SeriesAudience != null && searchRefinerItem.SeriesAudience.Length > 0)
                    savedSearches.Audience = searchRefinerItem.SeriesAudience.ToList();
                else if (searchSeriesItem.SeriesAudience != null && searchSeriesItem.SeriesAudience.Length > 0)
                    savedSearches.Audience = searchSeriesItem.SeriesAudience.ToList();

                if (searchSeriesItem.LastIssueListPriceMinimum > 0)
                    savedSearches.LastIssueListPriceMinimum = searchSeriesItem.LastIssueListPriceMinimum;
                else
                    savedSearches.LastIssueListPriceMinimum = null;

                if (searchSeriesItem.LastIssueListPriceMaximum > 0)
                    savedSearches.LastIssueListPriceMaximum = searchSeriesItem.LastIssueListPriceMaximum;
                else
                    savedSearches.LastIssueListPriceMaximum = null;

                savedSearches.LastIssuePublishDate = null;

                if (searchSeriesItem.SearchTermCriteria != null)
                {
                    List<SearchTerms> searchTermsList = new List<SearchTerms>();
                    foreach (SearchTermCriteria searchTermCriteria in searchSeriesItem.SearchTermCriteria)
                    { 
                        SearchTerms searchTerm = new SearchTerms();
                        searchTerm.SearchCriteria = searchTermCriteria.SearchTermValue.Replace("#apos#", "'").Replace("#quote#", "");
                        searchTerm.SearchJoin = searchTermCriteria.SearchJoin;
                        searchTerm.SearchTerm = searchTermCriteria.Attribute;
                        searchTerm.SearchType = searchTermCriteria.SearchType;

                        searchTermsList.Add(searchTerm);
                    }

                    if (searchTermsList.Count > 0)
                    {
                        savedSearches.SearchTerms = searchTermsList;
                    }
                }
            }

            var now = DateTime.Now;
            var footprintInformation = new FootprintInformation();
            footprintInformation.CreatedBy = saveSearchesRequest.UserName;
            footprintInformation.CreatedDate = now;
            footprintInformation.CreatedByUserID = saveSearchesRequest.UserID;
            footprintInformation.UpdatedBy = saveSearchesRequest.UserName;
            footprintInformation.UpdatedDate = now;
            footprintInformation.UpdatedByUserID = saveSearchesRequest.UserID;

            savedSearches.FootprintInformation = footprintInformation;

            return savedSearches;
        }

        private SavedSearches BindSavedSearches(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            SavedSearches ss = new SavedSearches();

            if (bsdoc.Contains("SearchName"))
                ss.SearchName = bsdoc["SearchName"].AsString;

            if (bsdoc.Contains("ProgramTypes"))
                ss.ProgramTypes = BsonSerializer.Deserialize<List<string>>(bsdoc["ProgramTypes"].ToJson());

            if (bsdoc.Contains("FormatTypes"))
                ss.FormatTypes = BsonSerializer.Deserialize<List<string>>(bsdoc["FormatTypes"].ToJson());

            if (bsdoc.Contains("SeriesStatus"))
                ss.SeriesStatus = BsonSerializer.Deserialize<List<string>>(bsdoc["SeriesStatus"].ToJson());

            if (bsdoc.Contains("AreasOfInterest"))
                ss.AreasOfInterest = BsonSerializer.Deserialize<List<string>>(bsdoc["AreasOfInterest"].ToJson());

            if (bsdoc.Contains("Audience"))
                ss.Audience = BsonSerializer.Deserialize<List<string>>(bsdoc["Audience"].ToJson());

            if (bsdoc.Contains("SearchTerms"))
                ss.SearchTerms = BsonSerializer.Deserialize<List<SearchTerms>>(bsdoc["SearchTerms"].ToJson());

            if (bsdoc.Contains("LastIssuePublishDate"))
                ss.LastIssuePublishDate = bsdoc["LastIssuePublishDate"].AsDateTime;

            if (bsdoc.Contains("LastIssueListPriceMinimum"))
                ss.LastIssueListPriceMinimum = Convert.ToDecimal(bsdoc["LastIssueListPriceMinimum"]);

            if (bsdoc.Contains("LastIssueListPriceMaximum"))
                ss.LastIssueListPriceMaximum = Convert.ToDecimal(bsdoc["LastIssueListPriceMaximum"]);

            if (bsdoc.Contains("FootprintInformation"))
                ss.FootprintInformation = BsonSerializer.Deserialize<FootprintInformation>(bsdoc["FootprintInformation"].ToJson());

     
            return ss;
        }

        private string ConvertToSavedSearchesSortField(string uiField)
        {
            // SearchName, LastDateUpdated
            string mongoField = "SearchName";

            switch (uiField)
            {
                case "SearchName":
                    mongoField = "SearchName";
                    break;
                case "LastDateUpdated":
                    mongoField = "FootprintInformation.UpdatedDate";
                    break;
                default:
                    mongoField = "SearchName";
                    break;
            }

            return mongoField;

        }

        #region Mongo query
        private async Task<bool> InsertSavedSearches(SavedSearches savedSearches)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    await _savedSearches.InsertOneAsync(savedSearches.ToBsonDocument<SavedSearches>());
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return true;
        }

        private async Task<bool> ReplaceSavedSearches(ObjectId savedSearchID, SavedSearches savedSearches)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("_id", savedSearchID);

            while (retries > 0)
            {
                try
                {
                    await _savedSearches.ReplaceOneAsync( filter, savedSearches.ToBsonDocument<SavedSearches>(), new UpdateOptions { IsUpsert = true });
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return true;
        }

        
        #endregion Mongo query
    }
}
