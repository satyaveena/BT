﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data.Common.Models;

using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

using System.Threading;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;
using BT.TS360.NoSQL.API.Common.Helper;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using BT.TS360.NoSQL.Data.AzureSearch;
using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.DAM;

using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace BT.TS360.NoSQL.API.Services.StandingOrders
{
    public class SeriesService
    {
        IMongoClient _client;
        IMongoDatabase _database;
        IMongoDatabase _dbProducts;
        IMongoDatabase _commonDatabase;

        IMongoCollection<BsonDocument> _series;
        IMongoCollection<BsonDocument> _profiledSeries;
        IMongoCollection<BsonDocument> _profiles;
        IMongoCollection<BsonDocument> _products;
        IMongoCollection<BsonDocument> _iCustomerAccountRepCollection;
        IMongoCollection<BsonDocument> _iProfilesCollection;
        IMongoCollection<BackgroundQueue> _backgroundQueue;
        IMongoCollection<AzureSearchQueueItem> _azureSearchQueue;
        
        IMongoCollection<ChangeRequests> _changeRequests;
        SearchServiceClient _serviceClient;
        ISearchIndexClient _profiledSeriesIndexClient;
        ISearchIndexClient _profilesIndexClient;
        AzureSearchQueueHelper azureSearchQueueHelper;

        public SeriesService() : this("") { }

        public SeriesService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                //connection = "mongodb://BTDevSQL02:27017";
                connection = AppSettings.MongoDBConnectionString;
            }

            _client = new MongoClient(connection);
         
            // standing orders
            _database = _client.GetDatabase(CommonConstants.StandingOrdersDatabaseName);
            _series = _database.GetCollection<BsonDocument>(CommonConstants.SeriesCollectionName);
            _profiledSeries = _database.GetCollection<BsonDocument>(CommonConstants.ProfiledSeriesCollectionName);
            _profiles = _database.GetCollection<BsonDocument>(CommonConstants.ProfilesCollectionName);
            _changeRequests = _database.GetCollection<ChangeRequests>(CommonConstants.ChangeRequestsCollectionName);
            _iCustomerAccountRepCollection = _database.GetCollection<BsonDocument>(CommonConstants.CustomerAccountRepCollectionName);
            _iProfilesCollection = _database.GetCollection<BsonDocument>(CommonConstants.ProfilesCollectionName);

            _commonDatabase = _client.GetDatabase(CommonConstants.CommonDatabaseName);
            _backgroundQueue = _commonDatabase.GetCollection<BackgroundQueue>(CommonConstants.BackgroundQueueCollectionName);
          
            _dbProducts = _client.GetDatabase(CommonConstants.ProductsDatabaseName);
            _products = _dbProducts.GetCollection<BsonDocument>(CommonConstants.ProductsCollectionName);
            _serviceClient = new SearchServiceClient(AppSettings.SearchServiceName, new SearchCredentials(AppSettings.SearchServiceQueryApiKey));
            _profiledSeriesIndexClient = _serviceClient.Indexes.GetClient(AppSettings.ProfiledSeriesIndexName);
            _profilesIndexClient = _serviceClient.Indexes.GetClient(AppSettings.ProfilesIndexName);
            _azureSearchQueue = _commonDatabase.GetCollection<AzureSearchQueueItem>(CommonConstants.AzureSearchQueueCollectionName);

            azureSearchQueueHelper = new AzureSearchQueueHelper(connection, AppSettings.RetryWaitTime, AppSettings.MaxConnectionRetries);
        
        }

        /*public NoSqlServiceResult<SeriesResponse> GetSeries(string id)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesResponse> { Status = NoSqlServiceStatus.Success };

            SeriesResponse seriesResponse = new SeriesResponse();// GetSeriesBuildSample(id);
            noSqlServiceResult.Data = seriesResponse;

            return noSqlServiceResult;
        }*/

        /*private SeriesResponse GetSeriesBuildSample(string id)
        {
            SeriesResponse seriesResponse = new SeriesResponse();
            seriesResponse.SeriesID = id;
            seriesResponse.SeriesStatus = "";

            List<SeriesTitle> listSeriesTitle = new List<SeriesTitle>();

            listSeriesTitle.Add(new SeriesTitle
            {
                TitleLongName = "College Handbook 2016",
                TitleShortName = "College Board"
            });

            listSeriesTitle.Add(new SeriesTitle
            {
                TitleLongName = "College Handbook 2016",
                TitleShortName = "College Board"
            });

            return seriesResponse;

        }*/
        
        public async Task<NoSqlServiceResult<SeriesProfileResponse>> GetSeriesProfile(string id)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesProfileResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                var searchText = "id:/" + id + "/";
                var searchParameters = GetProfileSearchParameters(id);
                SeriesProfileResponse seriesProfileResponse = new SeriesProfileResponse();

                if (!AppSettings.AzureSearchValidateServerCertificate)
                {
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                }

                DocumentSearchResult<ProfilesSearchResultItem> searchResponse = await _profilesIndexClient.Documents.SearchAsync<ProfilesSearchResultItem>(searchText, searchParameters);

                if (searchResponse != null)
                {
                    foreach (var result in searchResponse.Results)
                    {
                        var profile = ConvertProfilesSearchResultItemToSeriesProfileResponse(result.Document);
                    
                        seriesProfileResponse.ProfileName = profile.Name;
                        seriesProfileResponse.ProgramType = SplitString(profile.Programs);
                        seriesProfileResponse.ProfileType = profile.ProfileType;
                        seriesProfileResponse.TotalSeries = profile.SummaryInformation.TotalSeries;
                        seriesProfileResponse.TotalCopies = profile.SummaryInformation.TotalCopies;
                        seriesProfileResponse.SalesTerritory = profile.SalesTerritory;
                        seriesProfileResponse.ERPAccountNumber = profile.ShippingAccountNumber;
                        seriesProfileResponse.Status = profile.Status;

                        seriesProfileResponse.PONumberList = profile.PONumberList;

                        if (profile.FootprintInformation != null)
                        {
                            seriesProfileResponse.UpdatedBy = profile.FootprintInformation.UpdatedBy;
                            seriesProfileResponse.UpdatedDate = profile.FootprintInformation.UpdatedDate;
                        }

                        break;
                    }
                    
                }
                // end

                if (!string.IsNullOrEmpty(seriesProfileResponse.SalesTerritory))
                {
                    var salesfilter = Builders<BsonDocument>.Filter.Eq("SalesTerritory", seriesProfileResponse.SalesTerritory.Trim());
                    var salesResult = await _iCustomerAccountRepCollection.Find(salesfilter).Limit(1).ToListAsync();

                    if (salesResult.Count > 0)
                    {
                        var customerAccountRep = new CustomerAccountRep
                        {
                            SalesName = salesResult[0]["SalesName"].ToString(),
                            SalesPhone = salesResult[0]["SalesPhone"].ToString(),
                            SalesEmail = salesResult[0]["SalesEmail"].ToString()
                        };

                        seriesProfileResponse.SalesName = customerAccountRep.SalesName;
                        seriesProfileResponse.SalesPhone = customerAccountRep.SalesPhone;
                        seriesProfileResponse.SalesEmail = customerAccountRep.SalesEmail;
                    }
                }

                noSqlServiceResult.Data = seriesProfileResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SeriesProfileResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetSeriesProfile", id);
            }

            return noSqlServiceResult;
        }

        private SearchParameters GetProfileSearchParameters(string profileID)
        {
            var searchParameters = new SearchParameters();

            searchParameters.Select = new List<String>() { 
                        "Name", "Programs",
                        "ProfileType", "TotalCopies", "TotalSeries",
                        "ShippingAccountNumber", "SalesTerritory", "Status", 
                        "CreatedBy", "UpdatedBy", "CreatedDate", "UpdatedDate",
                        "PONumberList"
            };
            searchParameters.SearchMode = SearchMode.All;
            searchParameters.QueryType = QueryType.Full;
            
            return searchParameters;
        }

        public async Task<NoSqlServiceResult<SeriesListResponse>> GetRelatedSeries(List<string> relatedSeriesIDs)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesListResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;
                
                List<BsonDocument> bsonSeries = new List<BsonDocument>();

                SeriesListResponse seriesListResponse = new SeriesListResponse();
                ArrayList ltSeriesListing = new ArrayList();
                if (relatedSeriesIDs != null && relatedSeriesIDs.Any())
                {
                    var filter = Builders<BsonDocument>.Filter.In("SeriesID", relatedSeriesIDs) & Builders<BsonDocument>.Filter.Eq("Status", "Active");


                    while (retries > 0)
                    {
                        try
                        {
                            bsonSeries = await _series.Find(filter).Limit(6).ToListAsync<BsonDocument>();

                            break;
                        }
                        catch (Exception)
                        {
                            retries--;
                            Thread.Sleep(retryWaitTime);
                            if (retries < 1)
                            {
                                throw;
                            }
                        }
                    }

                    foreach (var document in bsonSeries)
                    {
                        // process document
                        Series mongoSeries = BindSeries(document);

                        if (mongoSeries != null)
                        {
                            SeriesItem seriesItem = new SeriesItem();

                            seriesItem.SeriesID = mongoSeries.SeriesID;
                            seriesItem.SeriesName = mongoSeries.Name;
                            seriesItem.Publisher = mongoSeries.Publisher;
                            seriesItem.Frequency = mongoSeries.Frequency;
                            seriesItem.ProgramType = SplitString(mongoSeries.Programs);
                            seriesItem.Programs = mongoSeries.Programs;
                            seriesItem.Format = mongoSeries.Format;
                            seriesItem.Audience = mongoSeries.Audience;
                            seriesItem.LastIssueISBN = mongoSeries.LatestIssueInformation.ISBN;
                            seriesItem.LastIssueEdition = mongoSeries.LatestIssueInformation.Edition;
                            seriesItem.StartDataType = mongoSeries.StartDataType;
                            if (mongoSeries.LatestIssueInformation.PublicationDate > DateTime.MinValue)
                            {
                                seriesItem.LastIssuePublishDate = mongoSeries.LatestIssueInformation.PublicationDate;
                            }
                            if (mongoSeries.LatestIssueInformation.ListPrice > 0)
                            {
                                seriesItem.LastIssueListPrice = mongoSeries.LatestIssueInformation.ListPrice;
                            }

                            ltSeriesListing.Add(seriesItem);
                        }
                    }
                }

                seriesListResponse.SeriesListing = (SeriesItem[])ltSeriesListing.ToArray(typeof(SeriesItem));
                noSqlServiceResult.Data = seriesListResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SeriesListResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetRelatedSeries", "1");
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<SeriesTitleResponse>> GetSeriesTitle(string seriesID)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesTitleResponse> { Status = NoSqlServiceStatus.Success };


            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                List<BsonDocument> bsonSeriesTitle = new List<BsonDocument>();
                SeriesTitleResponse seriesTitleResponse = new SeriesTitleResponse();
                ArrayList ltSeriesTitle = new ArrayList();

                //var filter1 = Builders<Product>.Filter.ElemMatch(p => p.SeriesInformation, si => si.SeriesID == seriesID);
                //var filter = Builders<Product>.Filter.ElemMatch(p => p.SeriesInformation, si => si.SeriesID == seriesID).ToBsonDocument();
                var filter = Builders<BsonDocument>.Filter.Eq("SeriesInformation.SeriesID", seriesID);
                var sort = Builders<BsonDocument>.Sort.Descending("PublicationDate");
                
                while (retries > 0)
                {
                    try
                    {
                        var cursor = _products.Find(filter);
                        seriesTitleResponse.TotalTitles = await cursor.CountAsync();
                        bsonSeriesTitle = await cursor.Sort(sort).Limit(6).ToListAsync<BsonDocument>();

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                foreach (var document in bsonSeriesTitle)
                {
                    // process document
                    Product mongoProduct = BindProduct(document);

                    if (mongoProduct != null)
                    {
                        SeriesTitle seriesTitle = new SeriesTitle();

                        seriesTitle.BTKey = mongoProduct.BTKEY;
                        seriesTitle.TitleLongName = mongoProduct.Title;
                        seriesTitle.Publisher = mongoProduct.Publisher;
                        seriesTitle.PublishDateTime = mongoProduct.PublicationDate;
                        seriesTitle.Edition = mongoProduct.Edition;
                        seriesTitle.ISBN = mongoProduct.ISBN;
                        seriesTitle.InventoryStatus = "";
                        seriesTitle.ListPrice = mongoProduct.ListPrice;
                        seriesTitle.PhysicalFormat = mongoProduct.PhysicalFormat;
                        seriesTitle.PrimaryResponsibleParty = mongoProduct.PrimaryResponsibleParty;
                        seriesTitle.ProductCode = mongoProduct.ProductCode;
                        seriesTitle.ReportCode = mongoProduct.ReportCode;
                        ltSeriesTitle.Add(seriesTitle);
                    }
                }

                seriesTitleResponse.SeriesTitleListing = (SeriesTitle[])ltSeriesTitle.ToArray(typeof(SeriesTitle));
                noSqlServiceResult.Data = seriesTitleResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SeriesTitleResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetSeriesTitle", seriesID);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<SeriesTitle>> GetSeriesDetailsById(string id, bool userSeriesCheckDup)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesTitle> { Status = NoSqlServiceStatus.Success, Data = new SeriesTitle() };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var bsonDocs = new List<BsonDocument>();

                var filter = Builders<BsonDocument>.Filter.Eq("SeriesID", id);

                while (retries > 0)
                {
                    try
                    {
                        bsonDocs = await _series.Find(filter).Limit(1).ToListAsync();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                var seriesTitle = new SeriesTitle();

                foreach (var document in bsonDocs)
                {
                    if (document.Contains("SeriesID"))
                    {
                        seriesTitle.SeriesId = document["SeriesID"].AsString;
                    }
                    if (document.Contains("Name"))
                    {
                        seriesTitle.TitleLongName = document["Name"].AsString;
                    }
                    if (document.Contains("Status"))
                    {
                        seriesTitle.InventoryStatus = document["Status"].AsString;
                    }
                    if (document.Contains("Publisher"))
                    {
                        seriesTitle.Publisher = document["Publisher"].AsString;
                    }
                    if (document.Contains("Frequency"))
                    {
                        seriesTitle.Cycle = document["Frequency"].AsString;
                    }
                    if (document.Contains("Status"))
                    {
                        seriesTitle.Status = document["Status"].AsString;
                    }

                    if (document.Contains("Annotations"))
                    {
                        seriesTitle.Annotations = document["Annotations"].AsString;
                    }

                    if (document.Contains("Format"))
                    {
                        seriesTitle.Format = document["Format"].AsString;
                    }
                    if (document.Contains("Audience"))
                    {
                        seriesTitle.Audiences = document["Audience"].AsString;
                    }

                    seriesTitle.StartDataType = document.Contains("StartDataType") ? document["StartDataType"].AsString : string.Empty;

                    if (document.Contains("Programs"))
                    {
                        var arrProgram = document["Programs"] as BsonArray;
                        if (arrProgram != null)
                        {
                            seriesTitle.Programs = string.Join(", ", arrProgram.OrderBy(a => a.AsString).ToList());
                            seriesTitle.ProgramsList = arrProgram.Select(a => a.AsString).ToList();
                        }
                    }

                    if (document.Contains("HasRelatedSeries"))
                    {
                        seriesTitle.HasRelatedSeries = document["HasRelatedSeries"].AsBoolean;
                    }

                    if (document.Contains("RelatedSeriesIDs"))
                    {
                        BsonArray baRelatedSeriesIDs = document["RelatedSeriesIDs"].AsBsonArray;
                        var relatedSeriesIDs = BsonSerializer.Deserialize<List<string>>(baRelatedSeriesIDs.ToJson());
                        seriesTitle.RelatedSeriesIDs = relatedSeriesIDs;
                    }

                    if (document.Contains("LatestIssueInformation"))
                    {
                        var latestIssInfo = BsonSerializer.Deserialize<LatestIssueInformation>(document["LatestIssueInformation"].ToJson());
                        if (latestIssInfo != null)
                        {
                            seriesTitle.Edition = latestIssInfo.Edition;
                            seriesTitle.LatestIssueName = latestIssInfo.Title;
                            seriesTitle.ISBN = latestIssInfo.ISBN;
                            seriesTitle.BTKey = latestIssInfo.BTKey;
                            if (latestIssInfo.PublicationDate > DateTime.MinValue)
                            {
                                seriesTitle.PublishDateTime = latestIssInfo.PublicationDate;
                            }
                            if (latestIssInfo.ListPrice > 0)
                            {
                                seriesTitle.ListPrice = latestIssInfo.ListPrice;
                            }
                        }
                    }
                    if (document.Contains("HasBindingPreferences"))
                    {
                        seriesTitle.HasBindingPreferences = document["HasBindingPreferences"].AsBoolean;
                    }
                    if (seriesTitle.HasBindingPreferences && document.Contains("BindingPreferences"))
                    {
                        seriesTitle.BindingPreferences = BsonSerializer.Deserialize<List<BindingPreference>>(document["BindingPreferences"].ToJson());
                        if (seriesTitle.BindingPreferences.Any())
                        {
                            seriesTitle.BindingPreferences = seriesTitle.BindingPreferences.OrderByDescending(x => x.HasMultiplePreference).ThenBy(x => x.Literal).ToList();
                        }
                    }

                    break;
                }

                noSqlServiceResult.Data = seriesTitle;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SeriesTitle();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                var logger = new LoggerService();
                logger.LogError(ex, "GetSeriesDetailsById", id);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<List<string>>> CreateDisableSeriesRequest(SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<string>> { Status = NoSqlServiceStatus.Success };
            List<string> updatedSeriesIDs = new List<string>();
            List<string> updatedProfiledSeriesIDs = new List<string>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                
                foreach (SeriesItem seriesItem in seriesActionRequest.SeriesListing)
                {
                    int retries = AppSettings.MaxConnectionRetries;

                    ChangeRequests changeRequest = new ChangeRequests();
                    changeRequest.ProfileID = ObjectId.Parse(seriesActionRequest.ProfileID);
                    changeRequest.ProfiledSeriesID = ObjectId.Parse(seriesItem.ProfiledSeriesId);
                    changeRequest.ChangeType = ChangeRequestChangeType.ProfiledSeries;
                    changeRequest.RequestType = ChangeRequestRequestType.DeleteSeries;
                    changeRequest.RequestStatus = ChangeRequestStatus.Open;
                    changeRequest.OrganizationID = seriesActionRequest.OrganizationID;
                    changeRequest.OrganizationName = seriesActionRequest.OrganizationName;
                    changeRequest.ProfileName = seriesActionRequest.ProfileName;
                    changeRequest.ERPAccountNumber = seriesActionRequest.ERPAccountNumber;
                    changeRequest.SalesTerritory = seriesActionRequest.SalesTerritory;
                    if(string.IsNullOrWhiteSpace(changeRequest.SalesTerritory))
                    {
                        CommonHelper.SendMissingSalesTerritoryEmail();
                    }
                    else
                    {
                        ChangeRequestManager changeRequestManager = new ChangeRequestManager();
                        changeRequest.AccountRepName = changeRequestManager.GetAccountRepName(_iCustomerAccountRepCollection, changeRequest.SalesTerritory);
                    }

                    ProfiledSeriesChangeRequest profiledSeriesChangeRequest = new ProfiledSeriesChangeRequest();
                    profiledSeriesChangeRequest.SeriesID = seriesItem.SeriesID;
                    profiledSeriesChangeRequest.DisabledReason = seriesActionRequest.Reasons;
                    changeRequest.ProfiledSeriesChangeRequest = profiledSeriesChangeRequest;

                    RedundantSeriesData redundantSeriesData = new RedundantSeriesData();
                    redundantSeriesData.Audience = seriesItem.Audience;
                    redundantSeriesData.Format = seriesItem.Format;
                    redundantSeriesData.Frequency = seriesItem.Frequency;

                    //  latestinformation

                    redundantSeriesData.Name = seriesItem.SeriesName;
                    if (!string.IsNullOrEmpty(seriesItem.ProgramType))
                    {
                        redundantSeriesData.Programs = seriesItem.ProgramType.Split(',').ToList();
                    }
                    redundantSeriesData.Publisher = seriesItem.Publisher;
                    changeRequest.RedundantSeriesInformation = redundantSeriesData;

                    DateTime now = DateTime.Now;

                    FootprintInformation footprintInformation = new FootprintInformation();
                    footprintInformation.CreatedBy = seriesActionRequest.UserName;
                    footprintInformation.CreatedDate = now;
                    footprintInformation.CreatedByUserID = seriesActionRequest.UserId;
                    footprintInformation.UpdatedBy = seriesActionRequest.UserName;
                    footprintInformation.UpdatedDate = now;

                    changeRequest.FootprintInformation = footprintInformation;

                    while (retries > 0)
                    {
                        try
                        {
                            await _changeRequests.InsertOneAsync(changeRequest);
                            break;
                        }
                        catch (Exception)
                        {
                            retries--;
                            Thread.Sleep(retryWaitTime);
                            if (retries < 1)
                            {
                                throw;
                            }
                        }
                    }

                    var builder = Builders<BsonDocument>.Filter;
                    var filter = builder.Eq("ProfileID", ObjectId.Parse(seriesActionRequest.ProfileID)) & builder.Eq("SeriesID", seriesItem.SeriesID);
                    var update = Builders<BsonDocument>.Update.Set("RequestStatus", ChangeRequestStatus.Open);
                    var result = await _profiledSeries.UpdateOneAsync(filter, update);
                    
                    updatedSeriesIDs.Add(seriesItem.SeriesID);
                    updatedProfiledSeriesIDs.Add(seriesItem.ProfiledSeriesId);
                }  // end loop for each series
                await azureSearchQueueHelper.UpdateAzureSearchQueue(updatedProfiledSeriesIDs, "ProfiledSeries", "Upsert", seriesActionRequest.UserName, AppSettings.AzureSearchQueuePriority);
                noSqlServiceResult.Data = updatedSeriesIDs;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = new List<string>();

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "CreateDisableSeriesRequest", seriesActionRequest.ProfileID);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<List<string>>> CreateDeleteSeriesRequest(SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<string>> { Status = NoSqlServiceStatus.Success };
            List<string> updatedSeriesIDs = new List<string>();
            List<string> updatedProfiledSeriesIDs = new List<string>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;

                foreach (SeriesItem seriesItem in seriesActionRequest.SeriesListing)
                {
                    int retries = AppSettings.MaxConnectionRetries;

                    ChangeRequests changeRequest = new ChangeRequests();
                    changeRequest.ProfileID = ObjectId.Parse(seriesActionRequest.ProfileID);
                    changeRequest.ProfiledSeriesID = ObjectId.Parse(seriesItem.ProfiledSeriesId);
                    changeRequest.ChangeType = ChangeRequestChangeType.ProfiledSeries;
                    changeRequest.RequestType = ChangeRequestRequestType.DeleteSeries;
                    changeRequest.RequestStatus = ChangeRequestStatus.Open;
                    changeRequest.OrganizationID = seriesActionRequest.OrganizationID;
                    changeRequest.OrganizationName = seriesActionRequest.OrganizationName;
                    changeRequest.ProfileName = seriesActionRequest.ProfileName;
                    changeRequest.ERPAccountNumber = seriesActionRequest.ERPAccountNumber;
                    changeRequest.SalesTerritory = seriesActionRequest.SalesTerritory;
                    if (string.IsNullOrWhiteSpace(changeRequest.SalesTerritory))
                    {
                        CommonHelper.SendMissingSalesTerritoryEmail();
                    }
                    else
                    {
                        ChangeRequestManager changeRequestManager = new ChangeRequestManager();
                        changeRequest.AccountRepName =  changeRequestManager.GetAccountRepName(_iCustomerAccountRepCollection, changeRequest.SalesTerritory);
                    }
                    ProfiledSeriesChangeRequest profiledSeriesChangeRequest = new ProfiledSeriesChangeRequest();
                    profiledSeriesChangeRequest.SeriesID = seriesItem.SeriesID;
                    //profiledSeriesChangeRequest.DeleteReason = seriesActionRequest.Reasons;
                    changeRequest.ProfiledSeriesChangeRequest = profiledSeriesChangeRequest;

                    if (seriesItem.PurchaseOrders != null)
                    {
                        List<PO> originalPO = new List<PO>();
                        foreach (SeriesPurchaseOrder oPurchaseOrder in seriesItem.PurchaseOrders)
                        {
                            if (!string.IsNullOrEmpty(oPurchaseOrder.PurchaseOrderID))
                            {
                                PO opo = new PO();
                                
                                opo.PurchaseOrderID = new ObjectId(oPurchaseOrder.PurchaseOrderID);
                                opo.FormatPreferencePrimary = oPurchaseOrder.FormatPreferencePrimary;
                                opo.FormatPreferencePrimaryQuantity = oPurchaseOrder.FormatPreferencePrimaryQuantity;
                                opo.FormatPreferenceSecondary = oPurchaseOrder.FormatPreferenceSecondary;
                                opo.FormatPreferenceSecondaryQuantity = oPurchaseOrder.FormatPreferenceSecondaryQuantity;
                                opo.POLineNumber = oPurchaseOrder.POLineNumber;
                                opo.ShippingPreference = oPurchaseOrder.ShippingPreference;
                                opo.StartDate = oPurchaseOrder.StartDate;

                                originalPO.Add(opo);
                            }
                        }

                        ProfiledSeriesChangeRequest profiledSeriesOriginalState = new ProfiledSeriesChangeRequest();
                        profiledSeriesOriginalState.PurchaseOrders = originalPO;
                        changeRequest.ProfiledSeriesOriginalState = profiledSeriesOriginalState;
                    }
                    
                    RedundantSeriesData redundantSeriesData = new RedundantSeriesData();
                    redundantSeriesData.Audience = seriesItem.Audience;
                    redundantSeriesData.Format = seriesItem.Format;
                    redundantSeriesData.Frequency = seriesItem.Frequency;

                    //  latestinformation

                    redundantSeriesData.Name = seriesItem.SeriesName;
                    if (!string.IsNullOrEmpty(seriesItem.ProgramType))
                    {
                        redundantSeriesData.Programs = seriesItem.ProgramType.Split(',').ToList();
                    }
                    redundantSeriesData.Publisher = seriesItem.Publisher;
                    changeRequest.RedundantSeriesInformation = redundantSeriesData;

                    DateTime now = DateTime.Now;

                    FootprintInformation footprintInformation = new FootprintInformation();
                    footprintInformation.CreatedBy = seriesActionRequest.UserName;
                    footprintInformation.CreatedDate = now;
                    footprintInformation.CreatedByUserID = seriesActionRequest.UserId;
                    footprintInformation.UpdatedBy = seriesActionRequest.UserName;
                    footprintInformation.UpdatedDate = now;

                    changeRequest.FootprintInformation = footprintInformation;

                    while (retries > 0)
                    {
                        try
                        {
                            await _changeRequests.InsertOneAsync(changeRequest);
                            break;
                        }
                        catch (Exception)
                        {
                            retries--;
                            Thread.Sleep(retryWaitTime);
                            if (retries < 1)
                            {
                                throw;
                            }
                        }
                    }

                    var builder = Builders<BsonDocument>.Filter;
                    var filter = builder.Eq("ProfileID", ObjectId.Parse(seriesActionRequest.ProfileID)) & builder.Eq("SeriesID", seriesItem.SeriesID);
                    var update = Builders<BsonDocument>.Update.Set("RequestStatus", ChangeRequestStatus.Open);
                    var result = await _profiledSeries.UpdateOneAsync(filter, update);

                    updatedSeriesIDs.Add(seriesItem.SeriesID);
                    updatedProfiledSeriesIDs.Add(seriesItem.ProfiledSeriesId);
                }  // end loop for each series
                await azureSearchQueueHelper.UpdateAzureSearchQueue(updatedProfiledSeriesIDs, "ProfiledSeries", "Upsert", seriesActionRequest.UserName, AppSettings.AzureSearchQueuePriority);
                noSqlServiceResult.Data = updatedSeriesIDs;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = new List<string>();

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "CreateDisableSeriesRequest", seriesActionRequest.ProfileID);
            }

            return noSqlServiceResult;
        }
        public async Task<NoSqlServiceResult<List<string>>> CreateSeriesModifyNotesRequest(SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<string>> { Status = NoSqlServiceStatus.Success };
            List<string> updatedSeriesIDs = new List<string>();
            List<string> updatedProfiledSeriesIDs = new List<string>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;

                foreach (SeriesItem seriesItem in seriesActionRequest.SeriesListing)
                {
                    int retries = AppSettings.MaxConnectionRetries;

                    ChangeRequests changeRequest = new ChangeRequests();
                    changeRequest.ProfileID = ObjectId.Parse(seriesActionRequest.ProfileID);
                    changeRequest.ProfiledSeriesID = ObjectId.Parse(seriesItem.ProfiledSeriesId);
                    changeRequest.ChangeType = ChangeRequestChangeType.ProfiledSeries;
                    changeRequest.RequestType = ChangeRequestRequestType.ModifySeries;
                    changeRequest.RequestStatus = ChangeRequestStatus.Open;
                    changeRequest.OrganizationID = seriesActionRequest.OrganizationID;
                    changeRequest.OrganizationName = seriesActionRequest.OrganizationName;
                    changeRequest.ProfileName = seriesActionRequest.ProfileName;
                    changeRequest.ERPAccountNumber = seriesActionRequest.ERPAccountNumber;
                    changeRequest.SalesTerritory = seriesActionRequest.SalesTerritory;
                    if (string.IsNullOrWhiteSpace(changeRequest.SalesTerritory))
                    {
                        CommonHelper.SendMissingSalesTerritoryEmail();
                    }
                    else
                    {
                        ChangeRequestManager changeRequestManager = new ChangeRequestManager();
                        changeRequest.AccountRepName = changeRequestManager.GetAccountRepName(_iCustomerAccountRepCollection, changeRequest.SalesTerritory);
                    }

                    changeRequest.NotesChangeType = ((ModifyNoteOption)seriesActionRequest.NoteOption).ToString();

                    ProfiledSeriesChangeRequest profiledSeriesChangeRequest = new ProfiledSeriesChangeRequest();
                    profiledSeriesChangeRequest.SeriesID = seriesItem.SeriesID;
                    profiledSeriesChangeRequest.Notes = seriesActionRequest.Notes;
                    changeRequest.ProfiledSeriesChangeRequest = profiledSeriesChangeRequest;

                    RedundantSeriesData redundantSeriesData = new RedundantSeriesData();
                    redundantSeriesData.Audience = seriesItem.Audience;
                    redundantSeriesData.Format = seriesItem.Format;
                    redundantSeriesData.Frequency = seriesItem.Frequency;

                    //  latestinformation

                    redundantSeriesData.Name = seriesItem.SeriesName;
                    if (!string.IsNullOrEmpty(seriesItem.ProgramType))
                    {
                        redundantSeriesData.Programs = seriesItem.ProgramType.Split(',').ToList();
                    }
                    redundantSeriesData.Publisher = seriesItem.Publisher;
                    changeRequest.RedundantSeriesInformation = redundantSeriesData;

                    DateTime now = DateTime.Now;

                    FootprintInformation footprintInformation = new FootprintInformation();
                    footprintInformation.CreatedBy = seriesActionRequest.UserName;
                    footprintInformation.CreatedDate = now;
                    footprintInformation.CreatedByUserID = seriesActionRequest.UserId;
                    footprintInformation.UpdatedBy = seriesActionRequest.UserName;
                    footprintInformation.UpdatedDate = now;

                    changeRequest.FootprintInformation = footprintInformation;

                    while (retries > 0)
                    {
                        try
                        {
                            await _changeRequests.InsertOneAsync(changeRequest);

                            break;
                        }
                        catch (Exception)
                        {
                            retries--;
                            Thread.Sleep(retryWaitTime);
                            if (retries < 1)
                            {
                                throw;
                            }
                        }
                    }

                    var builder = Builders<BsonDocument>.Filter;
                    var filter = builder.Eq("ProfileID", ObjectId.Parse(seriesActionRequest.ProfileID)) & builder.Eq("SeriesID", seriesItem.SeriesID);
                    var update = Builders<BsonDocument>.Update.Set("RequestStatus", ChangeRequestStatus.Open);
                    var result = await _profiledSeries.UpdateOneAsync(filter, update);

                    updatedSeriesIDs.Add(seriesItem.SeriesID);
                    updatedProfiledSeriesIDs.Add(seriesItem.ProfiledSeriesId);
                }  // end loop for each series
                await azureSearchQueueHelper.UpdateAzureSearchQueue(updatedProfiledSeriesIDs, "ProfiledSeries", "Upsert", seriesActionRequest.UserName, AppSettings.AzureSearchQueuePriority);
                noSqlServiceResult.Data = updatedSeriesIDs;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = new List<string>();

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "CreateSeriesModifyNotesRequest", seriesActionRequest.ProfileID);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<List<ModifyNotesResponse>>> ModifySeriesNotes(SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<ModifyNotesResponse>> { Status = NoSqlServiceStatus.Success };
            List<ModifyNotesResponse> updatedProfiledSeries = new List<ModifyNotesResponse>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;

                var profiledSeriesObjectIdList = new List<ObjectId>();
                foreach (SeriesItem seriesItem in seriesActionRequest.SeriesListing)
                {
                    var profiledSeriesObjectId = new ObjectId();
                    if (ObjectId.TryParse(seriesItem.ProfiledSeriesId, out profiledSeriesObjectId))
                    {
                        profiledSeriesObjectIdList.Add(profiledSeriesObjectId);
                    }
                }

                var profiledSerieslist = await GetProfiledSeries(profiledSeriesObjectIdList);

                foreach (ProfiledSeriesNotes profileSeriesItem in profiledSerieslist)
                {
                    int retries = AppSettings.MaxConnectionRetries;

                    if (string.IsNullOrEmpty(profileSeriesItem.RequestStatus))
                    {
                        string updateNote = string.Empty;
                        var NotesChangeType = ((ModifyNoteOption)seriesActionRequest.NoteOption);
                        switch (NotesChangeType)
                        {
                            case ModifyNoteOption.APPEND:
                                {
                                    updateNote = profileSeriesItem.Note + " " + seriesActionRequest.Notes;
                                    break;
                                }
                            case ModifyNoteOption.REPLACE:
                                {
                                    updateNote = seriesActionRequest.Notes;
                                    break;
                                }
                            default:
                                break;
                        }

                        var profiledSeriesObjectId = new ObjectId();
                        if (ObjectId.TryParse(profileSeriesItem.ProfiledSeriesID, out profiledSeriesObjectId))
                        {

                            var filter = Builders<BsonDocument>.Filter.Eq("_id", profiledSeriesObjectId);
                            var footprintInfo = new BsonDocument
                                  {
                                      {"UpdatedBy", seriesActionRequest.UserName},
                                      {"UpdatedDate", new BsonDateTime(DateTime.Now)},
                                      {"CreatedBy", profileSeriesItem.FootprintInformation.CreatedBy},
                                      {"CreatedDate", profileSeriesItem.FootprintInformation.CreatedDate}
                                  };

                            var update = Builders<BsonDocument>.Update.Set("Note", updateNote.Trim()).Set("FootprintInformation", footprintInfo);

                            while (retries > 0)
                            {
                                try
                                {
                                    await _profiledSeries.UpdateOneAsync(filter, update);
                                    break;
                                }
                                catch (Exception)
                                {
                                    retries--;
                                    Thread.Sleep(retryWaitTime);
                                    if (retries < 1)
                                    {
                                        throw;
                                    }
                                }
                            }
                            updatedProfiledSeries.Add(new ModifyNotesResponse() { ProfiledSeriesID = profileSeriesItem.ProfiledSeriesID.ToString(), SeriesID = profileSeriesItem.SeriesID.ToString(), Note = updateNote });
                        }
                    }
                } //foreach
                var listofIds = updatedProfiledSeries.Select(p => p.ProfiledSeriesID).ToList();
                if (listofIds != null && listofIds.Count > 0)
                    await azureSearchQueueHelper.UpdateAzureSearchQueue(listofIds, "ProfiledSeries", "Update", seriesActionRequest.UserName, AppSettings.AzureSearchQueuePriority);
                noSqlServiceResult.Data = updatedProfiledSeries;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = new List<ModifyNotesResponse>();

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "ModifySeriesNotes", seriesActionRequest.ProfileID);
            }

            return noSqlServiceResult;
        }


        private string ConvertToProfiledSeriesField(string uiField)
        {
            // SeriesID, SeriesName, LastIssuePublishDate, LastIssueListPrice, ProgramType, Frequency
            string azureField = "SeriesID";
            
            switch (uiField)
            {
                case "SeriesID":
                    azureField = "SeriesID";
                    break;
                case "SeriesName":
                    azureField = "SeriesName";
                    break;
                case "LastIssuePublishDate":
                    azureField = "PublicationDate";
                    break;
                case "LastIssueListPrice":
                    azureField = "ListPrice";
                    break;
                case "ProgramType":
                    azureField = "SeriesProgramsForSort";
                    break;
                case "Frequency":
                    azureField = "Frequency";
                    break;
                default:
                    azureField = "SeriesID";
                    break;
            }

            return azureField;

        }
        private ProfiledSeries BindProfiledSeries(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            //Product p = BsonSerializer.Deserialize<Product>(bsdoc.ToJson());

            ProfiledSeries ps = new ProfiledSeries();

            if (bsdoc.Contains("_id"))
                ps.ProfiledSeriesID = bsdoc["_id"].AsObjectId;

            if (bsdoc.Contains("SeriesID"))
                ps.SeriesID = bsdoc["SeriesID"].AsString;

            if (bsdoc.Contains("ProfileID"))
                ps.ProfileID = bsdoc["ProfileID"].AsObjectId;

            if (bsdoc.Contains("RequestStatus"))
                ps.RequestStatus = bsdoc["RequestStatus"].AsString;

            if (bsdoc.Contains("TotalPrimaryQuantity"))
                ps.TotalPrimaryQuantity = bsdoc["TotalPrimaryQuantity"].AsInt32;

            if (bsdoc.Contains("RedundantSeriesInformation"))
                ps.RedundantSeriesInformation = BsonSerializer.Deserialize<RedundantSeriesData>(bsdoc["RedundantSeriesInformation"].ToJson());

            if (bsdoc.Contains("RedundantProfileInformation"))
                ps.RedundantProfileInformation = BsonSerializer.Deserialize<RedundantProfileData>(bsdoc["RedundantProfileInformation"].ToJson());

            if (bsdoc.Contains("PurchaseOrders"))
                ps.PurchaseOrders = BsonSerializer.Deserialize<List<PO>>(bsdoc["PurchaseOrders"].ToJson());

            if (bsdoc.Contains("FootprintInformation"))
                ps.FootprintInformation = BsonSerializer.Deserialize<FootprintInformation>(bsdoc["FootprintInformation"].ToJson());

            if (bsdoc.Contains("Note"))
                ps.Note = bsdoc["Note"].AsString;

            return ps;
        }
        
        // bind Profile Data
        private Profile BindSeriesProfile(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            //Product p = BsonSerializer.Deserialize<Product>(bsdoc.ToJson());

            Profile p = new Profile();

            if (bsdoc.Contains("Name"))
                p.Name = bsdoc["Name"].AsString;

            List<string> lstPrograms = new List<string>();

            if (bsdoc.Contains("Programs"))
            {
                 BsonArray baPrograms = bsdoc["Programs"].AsBsonArray;

                 foreach (BsonValue value in baPrograms)
                 {
                     lstPrograms.Add(value.ToString());
                 }

                 p.Programs = lstPrograms;
            }

            if (bsdoc.Contains("ProfileType"))
                p.ProfileType = bsdoc["ProfileType"].AsString;

            //SummaryInformation
            p.SummaryInformation = new SummaryInformation();
            if (bsdoc.Contains("SummaryInformation"))
            {
                SummaryInformation summaryInformation = BsonSerializer.Deserialize<SummaryInformation>(bsdoc["SummaryInformation"].ToJson());

                p.SummaryInformation = summaryInformation;
            }

            /*if (bsdoc.Contains("TotalSeries"))
                p.TotalSeries = bsdoc["TotalSeries"].AsNullableInt32;

            if (bsdoc.Contains("TotalCopies"))
                p.TotalCopies = bsdoc["TotalCopies"].AsNullableInt32;*/
            p.ShippingAccountNumber = bsdoc.Contains("ShippingAccountNumber") ? bsdoc["ShippingAccountNumber"].AsString : "";
            p.SalesTerritory = bsdoc.Contains("SalesTerritory") ? bsdoc["SalesTerritory"].AsString : "";
            p.Status = bsdoc.Contains("Status") ? bsdoc["Status"].AsString : "";

            if (bsdoc.Contains("FootprintInformation"))
            {
                p.FootprintInformation = BsonSerializer.Deserialize<FootprintInformation>(bsdoc["FootprintInformation"].ToJson());
            }

            return p;
        }

        private Profile ConvertProfilesSearchResultItemToSeriesProfileResponse(ProfilesSearchResultItem profilesSearchResultItem)
        {
            if (profilesSearchResultItem == null) return null;
            
            Profile p = new Profile();

            p.Name = profilesSearchResultItem.Name;
            p.Programs = profilesSearchResultItem.Programs;
            p.ProfileType = profilesSearchResultItem.ProfileType;

            SummaryInformation summaryInformation = new SummaryInformation();
            summaryInformation.TotalCopies = profilesSearchResultItem.TotalCopies ?? 0;
            summaryInformation.TotalSeries = profilesSearchResultItem.TotalSeries ?? 0;
            p.SummaryInformation = summaryInformation;

            if (!string.IsNullOrEmpty(profilesSearchResultItem.ShippingAccountNumber))
            {
                p.ShippingAccountNumber = profilesSearchResultItem.ShippingAccountNumber;
            }

            p.SalesTerritory = profilesSearchResultItem.SalesTerritory;
            p.Status = profilesSearchResultItem.Status;

            FootprintInformation footprintInformation = new FootprintInformation();
            footprintInformation.CreatedBy = profilesSearchResultItem.CreatedBy;
            footprintInformation.UpdatedBy = profilesSearchResultItem.UpdatedBy;
            if (profilesSearchResultItem.CreatedDate.HasValue)
            {
                var createdDate = profilesSearchResultItem.CreatedDate.Value;
                footprintInformation.CreatedDate = createdDate.DateTime;
            }
            if (profilesSearchResultItem.UpdatedDate.HasValue)
            {
                var updatedDate = profilesSearchResultItem.UpdatedDate.Value;
                footprintInformation.UpdatedDate = updatedDate.DateTime;
            }

            p.FootprintInformation = footprintInformation;

            p.PONumberList = new List<string>();
            if (profilesSearchResultItem.PONumberList != null && profilesSearchResultItem.PONumberList.Count > 0)
            {
                p.PONumberList = profilesSearchResultItem.PONumberList;
            }
            
            return p;
        }
        private Series BindSeries(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            //Product p = BsonSerializer.Deserialize<Product>(bsdoc.ToJson());

            Series s = new Series();

            if (bsdoc.Contains("SeriesID"))
               s.SeriesID = bsdoc["SeriesID"].AsString;

            if (bsdoc.Contains("Name"))
                s.Name = bsdoc["Name"].AsString;

            if (bsdoc.Contains("Programs"))
            {
                List<string> lstPrograms = new List<string>();

                BsonArray baPrograms = bsdoc["Programs"].AsBsonArray;

                foreach (BsonValue value in baPrograms)
                {
                    lstPrograms.Add(value.ToString());
                }

                s.Programs = lstPrograms;
            }

            if (bsdoc.Contains("Frequency"))
                s.Frequency = bsdoc["Frequency"].AsString;

            if (bsdoc.Contains("Publisher"))
                s.Publisher = bsdoc["Publisher"].AsString;

            if (bsdoc.Contains("Format"))
                s.Format = bsdoc["Format"].AsString;

            if (bsdoc.Contains("Audience"))
                s.Audience = bsdoc["Audience"].AsString;;

            s.StartDataType = bsdoc.Contains("StartDataType") ? bsdoc["StartDataType"].AsString : string.Empty;

            if (bsdoc.Contains("LatestIssueInformation"))
                s.LatestIssueInformation = BsonSerializer.Deserialize<LatestIssueInformation>(bsdoc["LatestIssueInformation"].ToJson());

            return s;
        }

        private Product BindProduct(BsonDocument bsdoc)
        {

            // Performance improvement
            // use manual deserialization instead of auto deserialization

            //Product p = BsonSerializer.Deserialize<Product>(bsdoc.ToJson());

            Product p = new Product();

            if (bsdoc.Contains("_id"))
                p.BTKEY = bsdoc["_id"].AsString;

            if (bsdoc.Contains("ISBN"))
                p.ISBN = bsdoc["ISBN"].AsString;

            if (bsdoc.Contains("Title"))
                p.Title = bsdoc["Title"].AsString;

            if (bsdoc.Contains("Publisher"))
                p.Publisher = bsdoc["Publisher"].AsString;

            if (bsdoc.Contains("ListPrice"))
                p.ListPrice = Convert.ToDecimal(bsdoc["ListPrice"]);

            if (bsdoc.Contains("PublicationDate"))
                p.PublicationDate = bsdoc["PublicationDate"].AsNullableDateTime;

            if (bsdoc.Contains("Edition"))
                p.Edition = bsdoc["Edition"].AsString;

            if (bsdoc.Contains("PhysicalFormat"))
                p.PhysicalFormat = bsdoc["PhysicalFormat"].AsString;

            if (bsdoc.Contains("PrimaryResponsibleParty"))
                p.PrimaryResponsibleParty = bsdoc["PrimaryResponsibleParty"].AsString;

            if (bsdoc.Contains("ProductCode"))
                p.ProductCode = bsdoc["ProductCode"].AsString;

            if (bsdoc.Contains("ReportCode"))
                p.ReportCode = bsdoc["ReportCode"].AsString;

            List<SeriesProducts> seriesProductList = new List<SeriesProducts>();
            if (bsdoc.Contains("SeriesProducts"))
            {
                BsonArray baSeriesProduct = bsdoc["SeriesProducts"].AsBsonArray;

                foreach (BsonValue value in baSeriesProduct)
                {
                    SeriesProducts seriesProduct = BsonSerializer.Deserialize<SeriesProducts>(value.ToJson());

                    seriesProductList.Add(seriesProduct);
                }
            }

            p.SeriesInformation = seriesProductList;

            return p;
        }
        public async Task<NoSqlServiceResult<long>> GetPendingModificationsCountByOrg(string organizationId)
        {
           var noSqlServiceResult = new NoSqlServiceResult<long> { Status = NoSqlServiceStatus.Success };
            try
            {
                FilterDefinition<ChangeRequests> filter = Builders<ChangeRequests>.Filter.Eq("OrganizationID", organizationId)
                 & Builders<ChangeRequests>.Filter.Eq("ChangeType", ChangeRequestChangeType.ProfiledSeries)
                 & Builders<ChangeRequests>.Filter.In("RequestStatus", CommonHelper.GetChangeRequestDisplayStatuses());

                noSqlServiceResult.Data = await GetProfiledSeriesChangeRequestsCount(filter);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = 0;
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPendingModificationsCountByOrg");
            }
            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<PendingModificationResponse>> GetPendingModifications(PendingModificationRequest pendingModificationRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<PendingModificationResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidatePendingModificationRequest(pendingModificationRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetPendingModificationsData(pendingModificationRequest, profileObjectId);

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new PendingModificationResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPendingModifcations");
            }
            return noSqlServiceResult;
        }

        private async Task<PendingModificationResponse> GetPendingModificationsData(PendingModificationRequest pendingModificationRequest, ObjectId profileObjectId)
        {
            

            var ProfiledSeriesChangeRequestList = new List<ChangeRequests>();
            var pendingModificationResponse = new PendingModificationResponse();
            var ProfiledSeriesChangeRequestDetailsList = new List<ProfiledSeriesChangeRequestDetails>();

            var filter = GetProfiledSeriesChangeRequestFilter(pendingModificationRequest, profileObjectId);
            var sort = GetProfiledSeriesChangeRequestSort(pendingModificationRequest.SortBy, pendingModificationRequest.SortDirection);
            var skipDocs = (pendingModificationRequest.PageNumber - 1) * pendingModificationRequest.PageSize;

            var response = await GetProfiledSeriesChangeRequests(filter, sort, skipDocs, pendingModificationRequest.PageSize);
            ProfiledSeriesChangeRequestList = response.ItemList;

            foreach (ChangeRequests changeRequest in ProfiledSeriesChangeRequestList)
            {
                ProfiledSeriesChangeRequestDetailsList.Add(GetprofiledSeriesChangeRequestDetailsFromChangeRequest(changeRequest));
            }

            pendingModificationResponse.TotalItems = response.TotalItems;
            pendingModificationResponse.ProfiledSeriesChangeRequest = ProfiledSeriesChangeRequestDetailsList;

            var pfilter = Builders<BsonDocument>.Filter.Eq("_id", profileObjectId);

            var results = await _iProfilesCollection.Find(pfilter).Limit(1).ToListAsync();

            if (results != null && results.Count > 0)
            {
                if (results[0].Contains("SalesTerritory"))
                {
                    string salesTerritory = results[0]["SalesTerritory"].AsString;

                    if (!string.IsNullOrEmpty(salesTerritory))
                    {
                        var salesfilter = Builders<BsonDocument>.Filter.Eq("SalesTerritory", salesTerritory.Trim());
                        var salesResult = await _iCustomerAccountRepCollection.Find(salesfilter).Limit(1).ToListAsync();

                        if (salesResult.Count > 0)
                        {
                            var customerAccountRep = new CustomerAccountRep
                            {
                                SalesName = salesResult[0]["SalesName"].ToString(),
                                SalesPhone = salesResult[0]["SalesPhone"].ToString(),
                                SalesEmail = salesResult[0]["SalesEmail"].ToString()
                            };

                            pendingModificationResponse.SalesName = customerAccountRep.SalesName;
                            pendingModificationResponse.SalesPhone = customerAccountRep.SalesPhone;
                            pendingModificationResponse.SalesEmail = customerAccountRep.SalesEmail;
                        }
                    }
                }

                pendingModificationResponse.ProfileName = results[0].Contains("ProfileName") ? results[0]["ProfileName"].AsString : "";
                pendingModificationResponse.ProfileStatus = results[0].Contains("Status") ? results[0]["Status"].AsString : "";
                
                if (results[0].Contains("CompassAccountNumber"))
                {
                     pendingModificationResponse.AccountNumber = results[0]["CompassAccountNumber"].AsString ;
                }
                else if (results[0].Contains("ShippingAccountNumber"))
                {
                     pendingModificationResponse.AccountNumber = results[0]["ShippingAccountNumber"].AsString ;
                }
                else if (results[0].Contains("ERPAccountNumber"))
                {
                    pendingModificationResponse.AccountNumber = results[0]["ERPAccountNumber"].AsString;
                }
            }

            var groupResponse = await GroupChangeRequestsRequestStatus(pendingModificationRequest, profileObjectId);

            foreach (var element in groupResponse)
            {
                if (element.Key == ChangeRequestStatus.Open)
                    pendingModificationResponse.TotalNew = element.Value;
                else if (element.Key == ChangeRequestStatus.InProgress)
                    pendingModificationResponse.TotalInProcess = element.Value;
                else if (element.Key == ChangeRequestStatus.Removed)
                    pendingModificationResponse.TotalRemoved = element.Value;
                else if (element.Key == ChangeRequestStatus.Completed)
                    pendingModificationResponse.TotalCompleted = element.Value;
            }

            pendingModificationResponse.TotalAddNew = await GetChangeRequestsRequestAddNewCount(pendingModificationRequest, profileObjectId);

            return pendingModificationResponse;
        }

        private SortDefinition<ChangeRequests> GetProfiledSeriesChangeRequestSort(string sortBy, string sortDirection)
        {
            if (string.Equals(ChangeRequestSortOption.RequestedModification, sortBy, StringComparison.OrdinalIgnoreCase))
            {
                return sortDirection.ToLower() == "desc" ? Builders<ChangeRequests>.Sort.Descending(sortBy).Descending(ChangeRequestSortOption.DateRequested)
                : Builders<ChangeRequests>.Sort.Ascending(sortBy).Descending(ChangeRequestSortOption.DateRequested);
            }
            else
            {
                return sortDirection.ToLower() == "desc" ? Builders<ChangeRequests>.Sort.Descending(sortBy)
                : Builders<ChangeRequests>.Sort.Ascending(sortBy);
            }
        }

        private FilterDefinition<ChangeRequests> GetChangeRequestFilter(ChangeRequestFilterDataRequest changeRequestFilterDataRequest, ObjectId profileObjectId)
        {
            FilterDefinition<ChangeRequests> filter = Builders<ChangeRequests>.Filter.Eq("ChangeType", ChangeRequestChangeType.ProfiledSeries)
                & Builders<ChangeRequests>.Filter.In("RequestStatus", CommonHelper.GetChangeRequestDisplayStatuses()) ;

            if (!string.IsNullOrEmpty(changeRequestFilterDataRequest.ProfileId))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("ProfileID", profileObjectId);
            }

            if (!string.IsNullOrEmpty(changeRequestFilterDataRequest.OrganizationId))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("OrganizationID", changeRequestFilterDataRequest.OrganizationId);
            }

            return filter;
        }
        private FilterDefinition<ChangeRequests> GetProfiledSeriesChangeRequestFilter(PendingModificationRequest pendingModificationRequest, ObjectId profileObjectId)
        {
            FilterDefinition<ChangeRequests> filter = Builders<ChangeRequests>.Filter.Eq("ChangeType", ChangeRequestChangeType.ProfiledSeries);

            if (!string.IsNullOrEmpty(pendingModificationRequest.ProfileId))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("ProfileID", profileObjectId);
            }

            if (!string.IsNullOrEmpty(pendingModificationRequest.OrganizationId))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("OrganizationID", pendingModificationRequest.OrganizationId);
            }

            if (pendingModificationRequest.RequestStatus != null && pendingModificationRequest.RequestStatus.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("RequestStatus", pendingModificationRequest.RequestStatus);
            }
            else
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("RequestStatus", CommonHelper.GetChangeRequestDisplayStatuses());
            }

            if (pendingModificationRequest.RequestType != null && pendingModificationRequest.RequestType.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("RequestType", pendingModificationRequest.RequestType);
            }

            if (pendingModificationRequest.RequestedBy != null && pendingModificationRequest.RequestedBy.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("FootprintInformation.CreatedBy", pendingModificationRequest.RequestedBy);
            }

            if (pendingModificationRequest.SeriesName != null && pendingModificationRequest.SeriesName.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("RedundantSeriesInformation.Name", pendingModificationRequest.SeriesName); //RedundantSeriesInformation.Name
            }

            if (pendingModificationRequest.SeriesID != null && pendingModificationRequest.SeriesID.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("ProfiledSeriesChangeRequest.SeriesID", pendingModificationRequest.SeriesID); //ProfiledSeriesChangeRequest.SeriesID
            }

            if (pendingModificationRequest.Frequency != null && pendingModificationRequest.Frequency.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("RedundantSeriesInformation.Frequency", pendingModificationRequest.Frequency); 
            }

            if (pendingModificationRequest.ProfileName != null && pendingModificationRequest.ProfileName.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("ProfileName", pendingModificationRequest.ProfileName);
            }

            if (pendingModificationRequest.AccountNumber != null && pendingModificationRequest.AccountNumber.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("ERPAccountNumber", pendingModificationRequest.AccountNumber);
            }

            return filter;
        }

        private ProfiledSeriesChangeRequestDetails GetprofiledSeriesChangeRequestDetailsFromChangeRequest(ChangeRequests changeRequest)
        {
            var profiledSeriesChangeRequest = new ProfiledSeriesChangeRequestDetails();
            profiledSeriesChangeRequest.ProfileId = changeRequest.ProfileID.ToString();
            profiledSeriesChangeRequest.ProfileName = changeRequest.ProfileName;
            profiledSeriesChangeRequest.AccountNumber = changeRequest.ERPAccountNumber;

            if (changeRequest.ProfiledSeriesChangeRequest != null)
            {
                profiledSeriesChangeRequest.SeriesID = changeRequest.ProfiledSeriesChangeRequest.SeriesID;
                
                if (changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders != null && changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders.Any())
                {
                    foreach (var purchaseOrder in changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders)
                    {
                        if (purchaseOrder.StartNextAvailableTitle)
                        {
                            purchaseOrder.StartDate = "Next Available Title";
                        }

                        if (!string.IsNullOrEmpty(purchaseOrder.FormatPreferencePrimary) && !string.IsNullOrEmpty(purchaseOrder.FormatPreferenceSecondary) &&
                                purchaseOrder.FormatPreferencePrimary != "null" && purchaseOrder.FormatPreferenceSecondary != "null")
                        {
                            purchaseOrder.FormatPreferenceString = MapFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary) + " 1st, " + MapFormatPreferenceAbbr(purchaseOrder.FormatPreferenceSecondary) + " 2nd";
                        }
                        else
                        {
                            purchaseOrder.FormatPreferenceString = ReplaceFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary);
                        }
                    }
                }

                profiledSeriesChangeRequest.PurchaseOrders = changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders;

                profiledSeriesChangeRequest.Notes = changeRequest.ProfiledSeriesChangeRequest.Notes;
                profiledSeriesChangeRequest.SpecialInstruction = changeRequest.ProfiledSeriesChangeRequest.SpecialInstruction;
                profiledSeriesChangeRequest.ChangeRequestId = changeRequest.ChangeRequestID.ToString();
                profiledSeriesChangeRequest.ProfiledSeriesId = changeRequest.ProfiledSeriesID.ToString();
            }

            if (changeRequest.FootprintInformation != null)
            {
                profiledSeriesChangeRequest.DateRequested = changeRequest.FootprintInformation.CreatedDate;
            }

            if (changeRequest.RedundantSeriesInformation != null)
            {
                profiledSeriesChangeRequest.Cycle = changeRequest.RedundantSeriesInformation.Frequency;
                profiledSeriesChangeRequest.Name = changeRequest.RedundantSeriesInformation.Name;
                profiledSeriesChangeRequest.Programs = ConvertProgramTypeList(changeRequest.RedundantSeriesInformation.Programs);
            }
            profiledSeriesChangeRequest.TotalQuantity = changeRequest.TotalQuantity.HasValue ? changeRequest.TotalQuantity.Value : 0;
            profiledSeriesChangeRequest.OriginalStateTotalQuantity = (changeRequest.ProfiledSeriesOriginalState != null && changeRequest.ProfiledSeriesOriginalState.PurchaseOrders != null) ? changeRequest.ProfiledSeriesOriginalState.PurchaseOrders.Sum(p => p.FormatPreferencePrimaryQuantity) : 0;
            profiledSeriesChangeRequest.RequestType = changeRequest.RequestType;
            profiledSeriesChangeRequest.RequestStatus = changeRequest.RequestStatus;
            
            
            if (changeRequest.ProfiledSeriesOriginalState != null && changeRequest.ProfiledSeriesOriginalState.PurchaseOrders != null && changeRequest.ProfiledSeriesOriginalState.PurchaseOrders.Any())
            {
                foreach (var purchaseOrder in changeRequest.ProfiledSeriesOriginalState.PurchaseOrders)
                {
                    if (purchaseOrder.StartNextAvailableTitle)
                    {
                        purchaseOrder.StartDate = "Next Available Title";
                    }

                    if (!string.IsNullOrEmpty(purchaseOrder.FormatPreferencePrimary) && !string.IsNullOrEmpty(purchaseOrder.FormatPreferenceSecondary) &&
                              purchaseOrder.FormatPreferencePrimary != "null" && purchaseOrder.FormatPreferenceSecondary != "null")
                    {
                        purchaseOrder.FormatPreferenceString = MapFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary) + " 1st, " + MapFormatPreferenceAbbr(purchaseOrder.FormatPreferenceSecondary) + " 2nd";
                    }
                    else
                    {
                        purchaseOrder.FormatPreferenceString = ReplaceFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary);
                    }
                }

                profiledSeriesChangeRequest.OriginalStatePurchaseOrders = changeRequest.ProfiledSeriesOriginalState.PurchaseOrders;
            }
            else
            {

                profiledSeriesChangeRequest.OriginalStatePurchaseOrders = new List<PO>();
            }
    
            
            profiledSeriesChangeRequest.IsDisplayOriginalStatePurchaseOrder = (changeRequest.RequestType == ChangeRequestRequestType.DeleteSeries);
            profiledSeriesChangeRequest.FootprintInformation = changeRequest.FootprintInformation;

            return profiledSeriesChangeRequest;
        }

        private async Task<NoSqlResponse<ChangeRequests>> GetProfiledSeriesChangeRequests(FilterDefinition<ChangeRequests> filter, SortDefinition<ChangeRequests> sort, int skipDocs, int pageSize)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new NoSqlResponse<ChangeRequests>();

            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    response.TotalItems = await cursor.CountAsync();
                    response.ItemList = await cursor.Sort(sort).Skip(skipDocs).Limit(pageSize).ToListAsync<ChangeRequests>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }

        private async Task<long> GetProfiledSeriesChangeRequestsCount(FilterDefinition<ChangeRequests> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            long response = 0;

            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    response = await cursor.CountAsync();
                
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }

        private async Task<NoSqlResponse<ChangeRequests>> GetProfiledSeriesChangeRequests(FilterDefinition<ChangeRequests> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new NoSqlResponse<ChangeRequests>();

            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    response.TotalItems = await cursor.CountAsync();
                    response.ItemList = await cursor.ToListAsync<ChangeRequests>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }
        private string ConvertProgramTypeList(List<string> ProgramList)
        {
            if (ProgramList != null)
            {
                ProgramList.Sort();
                return string.Join(" / ", ProgramList);
            }
            return "";
        }


       
        #region sample data
        public NoSqlServiceResult<SeriesListResponse> BuildSampleSeriesLists(string profileID)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesListResponse> { Status = NoSqlServiceStatus.Success };

            SeriesListResponse seriesListResponse = new SeriesListResponse();

            ArrayList ltSeriesListing = new ArrayList();

            ltSeriesListing.Add(new SeriesItem
            {
                SeriesID = "1",
                SeriesName = "College Handbook",
                Status = "Active",
                Publisher = "CollegeBoard",
                Frequency = "Biennial",
                ProgramType = "Continuations",
                Format = "Paperback",
                Audience = "Older Teens & Adults",
                LastIssueISBN = "9781605873978",
                LastIssueName = "College Handbook 2016",
                LastIssuePublishDate = new DateTime(2015, 7, 7),
                LastIssueListPrice = 33.99m,
                LastIssueEdition = "53"
            });

            ltSeriesListing.Add(new SeriesItem
            {
                SeriesID = "2",
                SeriesName = "College Handbook2",
                Status = "Active",
                Publisher = "CollegeBoard2",
                Frequency = "Biennial2",
                ProgramType = "Continuations",
                Format = "Paperback2",
                Audience = "Older Teens & Adults2",
                LastIssueISBN = "9781402769009",
                LastIssueName = "College Handbook 2017",
                LastIssuePublishDate = new DateTime(2015, 7, 8),
                LastIssueListPrice = 34.99m,
                LastIssueEdition = "53"
            });

            ltSeriesListing.Add(new SeriesItem
            {
                SeriesID = "3",
                SeriesName = "College Handbook3",
                Status = "Active",
                Publisher = "CollegeBoard3",
                Frequency = "Biennial3",
                ProgramType = "Continuations",
                Format = "Paperback3",
                Audience = "Older Teens & Adults3",
                LastIssueISBN = "9781448921270",
                LastIssueName = "College Handbook 2018",
                LastIssuePublishDate = new DateTime(2015, 7, 9),
                LastIssueListPrice = 35.99m,
                LastIssueEdition = "54"
            });

            seriesListResponse.SeriesListing = (SeriesItem[])ltSeriesListing.ToArray(typeof(SeriesItem));

            noSqlServiceResult.Data = seriesListResponse;

            return noSqlServiceResult;
        }
        #endregion sample data

        #region util
        
        private string SplitString(List<string> splitString)
        {
            string result = "";


            if (splitString != null && splitString.Count > 0)
            {
                foreach (string s in splitString)
                {
                    result += ((string.IsNullOrEmpty(result) ? "" : ", ") + s);

                }
            }
            return result;

        }

        public string ValidateChangeRequestFilterDataRequest(ChangeRequestFilterDataRequest request, out ObjectId profiledObjectId)
        {
            profiledObjectId = new ObjectId();
            if (request == null)
            {
                return "Request is required";
            }

            if (string.IsNullOrEmpty(request.ProfileId) && string.IsNullOrEmpty(request.OrganizationId))
            {
                return "Profile Id or Organization Id is required";

            }

            if (!string.IsNullOrEmpty(request.ProfileId) && !ObjectId.TryParse(request.ProfileId, out profiledObjectId))
            {
                return "Invalid Profile Id";

            }
            return null;
        }

        public string ValidatePendingModificationRequest(PendingModificationRequest request, out ObjectId profiledObjectId)
        {
            profiledObjectId = new ObjectId();
            if (request == null)
            {
                return "Request is required";
            }

            if (string.IsNullOrEmpty(request.ProfileId) && string.IsNullOrEmpty(request.OrganizationId))
            {
                return "Profile Id or Organization Id is required";

            }
 
            if (!string.IsNullOrEmpty(request.ProfileId) && !ObjectId.TryParse(request.ProfileId, out profiledObjectId))
            {
                return "Invalid Profile Id";

            }
            return null;
        }
        # endregion util

        internal async Task<NoSqlServiceResult<DuplicateSeriesResponse>> GetDuplicateSeries(DuplicateSeriesRequest duplicateSeriesRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<DuplicateSeriesResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateDuplicateSeriesRequest(duplicateSeriesRequest);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetDuplicateSeriesData(duplicateSeriesRequest);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new DuplicateSeriesResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetDuplicateSeries");
            }
            return noSqlServiceResult;
        }

        private async Task<DuplicateSeriesResponse> GetDuplicateSeriesData(DuplicateSeriesRequest duplicateSeriesRequest)
        {
            var profileObjectId = new ObjectId();
            if (!string.IsNullOrEmpty(duplicateSeriesRequest.ProfileId))
            {
                ObjectId.TryParse(duplicateSeriesRequest.ProfileId, out profileObjectId);
            }
            var duplicateSeriesResponse = new DuplicateSeriesResponse();
            var seriesDuplicateList = new List<SeriesDuplicate>();
            var profiledSeriesList = new List<ProfiledSeries>();
            var filter = Builders<BsonDocument>.Filter.In("SeriesID", duplicateSeriesRequest.SeriesIdList)
                & Builders<BsonDocument>.Filter.Eq("RedundantProfileInformation.OrganizationID", duplicateSeriesRequest.OrganizationId)
                 & Builders<BsonDocument>.Filter.Ne("ProfileID", profileObjectId);
            var profiledSeriesDocumentList = await GetProfiledSeries(filter);

            foreach (var document in profiledSeriesDocumentList)
            {
                ProfiledSeries mongoProfiledSeries = BindProfiledSeries(document);
                profiledSeriesList.Add(mongoProfiledSeries);
            }

            foreach (var seriesId in duplicateSeriesRequest.SeriesIdList)
            {
                var seriesDuplicate = new SeriesDuplicate();
                seriesDuplicate.SeriesId = seriesId;
                seriesDuplicate.IsDupe = profiledSeriesList.Any(x => x.SeriesID.Equals(seriesId, StringComparison.OrdinalIgnoreCase));
                seriesDuplicateList.Add(seriesDuplicate);
            }
            duplicateSeriesResponse.SeriesDuplicateList = seriesDuplicateList;
            return duplicateSeriesResponse;
        }

        private async Task<List<BsonDocument>> GetProfiledSeries(FilterDefinition<BsonDocument> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var profiledSeriesDocumentList = new List<BsonDocument>();
            while (retries > 0)
            {
                try
                {
                    profiledSeriesDocumentList = await _profiledSeries.Find<BsonDocument>(filter).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return profiledSeriesDocumentList;
        }

        internal async Task<NoSqlServiceResult<DuplicateSeriesDetailsResponse>> GetDuplicateSeriesDetails(DuplicateSeriesDetailsRequest duplicateSeriesDetailsRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<DuplicateSeriesDetailsResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateDuplicateSeriesDetailsRequest(duplicateSeriesDetailsRequest);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetDuplicateSeriesDetailsData(duplicateSeriesDetailsRequest);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new DuplicateSeriesDetailsResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetDuplicateSeriesDetails");
            }
            return noSqlServiceResult;
        }

        private async Task<DuplicateSeriesDetailsResponse> GetDuplicateSeriesDetailsData(DuplicateSeriesDetailsRequest duplicateSeriesDetailsRequest)
        {
            var duplicateSeriesDetailsResponse = new DuplicateSeriesDetailsResponse();
            var seriesDuplicateList = new List<SeriesDuplicate>();
            var profiledSeriesList = new List<ProfiledSeries>();
            var seriesInformation = new Series();
            var filter = Builders<BsonDocument>.Filter.Eq("SeriesID", duplicateSeriesDetailsRequest.SeriesId)
                & Builders<BsonDocument>.Filter.Eq("RedundantProfileInformation.OrganizationID", duplicateSeriesDetailsRequest.OrganizationId)
                 & Builders<BsonDocument>.Filter.Ne("_id", duplicateSeriesDetailsRequest.ProfileId);
            var profiledSeriesDocumentList = await GetProfiledSeries(filter);
            var hasSeriesInformation = false;
            foreach (var document in profiledSeriesDocumentList)
            {
                ProfiledSeries mongoProfiledSeries = BindProfiledSeries(document);
                if (mongoProfiledSeries != null)
                {
                    if (!hasSeriesInformation && mongoProfiledSeries.RedundantSeriesInformation != null)
                    {
                        seriesInformation.SeriesID = mongoProfiledSeries.SeriesID;
                        seriesInformation.Name = mongoProfiledSeries.RedundantSeriesInformation.Name;
                        if (mongoProfiledSeries.RedundantSeriesInformation.Programs != null)
                        {
                            seriesInformation.Programs = mongoProfiledSeries.RedundantSeriesInformation.Programs;
                            seriesInformation.Programs.Sort();
                        }
                        seriesInformation.Frequency = mongoProfiledSeries.RedundantSeriesInformation.Frequency;
                        seriesInformation.LatestIssueInformation = mongoProfiledSeries.RedundantSeriesInformation.LatestIssueInformation;
                        hasSeriesInformation = true;
                    }
                    if (mongoProfiledSeries.RedundantProfileInformation != null && mongoProfiledSeries.RedundantProfileInformation.Status != null)
                    {
                        mongoProfiledSeries.RedundantProfileInformation.Status = mongoProfiledSeries.RedundantProfileInformation.Status.Equals("Active", StringComparison.OrdinalIgnoreCase) ? "N" : "Y";
                    }
                    else
                    {
                        mongoProfiledSeries.RedundantProfileInformation.Status = "Y";
                    }
                }
                profiledSeriesList.Add(mongoProfiledSeries);
            }

            duplicateSeriesDetailsResponse.ProfiledSeriesList = profiledSeriesList;
            duplicateSeriesDetailsResponse.SeriesInformation = seriesInformation;
            return duplicateSeriesDetailsResponse;
        }

        internal async Task<NoSqlServiceResult<bool>> EmailSeries(EmailSeriesRequest emailSeriesRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateEmailSeriesRequest(emailSeriesRequest);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                MailMessage mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                var emailToList = emailSeriesRequest.EmailTo.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        mail.To.Add(emailTo);
                }
                if (emailSeriesRequest.SendCopyToUser)
                {
                    mail.To.Add(emailSeriesRequest.UserEmail);
                }
                mail.Subject = emailSeriesRequest.Subject;
                mail.Body = GetEmailSeriesEmailBody(emailSeriesRequest.SeriesInformation, emailSeriesRequest.Notes);
                mail.IsBodyHtml = true;

                client.Send(mail);
            }
            catch (Exception exception)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ProfileService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", emailSeriesRequest.ToJson(),
                    exception.Message, exception.StackTrace));
            }
            return noSqlServiceResult;
        }

        private string GetEmailSeriesEmailBody(SeriesTitle seriesInformation, string notes)
        {
            string emailBody = string.Empty;
            using (StreamReader reader = new StreamReader(HttpRuntime.AppDomainAppPath + @"Common\EmailTemplates\EmailSeriesEmailTemplate.txt"))
            {
                emailBody = reader.ReadToEnd();
            }
            emailBody = emailBody.Replace("{SERIES_NAME}", seriesInformation.TitleLongName);
            emailBody = emailBody.Replace("{STATUS}", seriesInformation.Status);
            emailBody = emailBody.Replace("{SERIES_ID}", seriesInformation.SeriesId);
            emailBody = emailBody.Replace("{PUBLISHER}", seriesInformation.Publisher);
            emailBody = emailBody.Replace("{PROGRAM_TYPE}", seriesInformation.Programs);
            emailBody = emailBody.Replace("{FORMAT}", seriesInformation.Format);
            emailBody = emailBody.Replace("{FREQUENCY}", seriesInformation.Cycle);
            emailBody = emailBody.Replace("{AUDIENCE}", seriesInformation.Audiences);
            emailBody = emailBody.Replace("{NAME}", seriesInformation.LatestIssueName);
            emailBody = emailBody.Replace("{EDITION}", seriesInformation.Edition);
            emailBody = emailBody.Replace("{ANNOTATION}", seriesInformation.Annotations);
            emailBody = emailBody.Replace("{NOTES}", notes);
            if (seriesInformation.ListPrice.HasValue && seriesInformation.ListPrice.Value > 0)
            {
                emailBody = emailBody.Replace("{LIST_PRICE}", seriesInformation.ListPrice.Value.ToString("C"));
            }
            else
            {
                emailBody = emailBody.Replace("{LIST_PRICE}", "");
            }
            if (seriesInformation.PublishDateTime.HasValue && seriesInformation.PublishDateTime > DateTime.MinValue)
            {
                emailBody = emailBody.Replace("{PUBLISH_DATE}", seriesInformation.PublishDateTime.Value.ToString(CommonConstants.DefaultDateTimeFormat));
            }
            else
            {
                emailBody = emailBody.Replace("{PUBLISH_DATE}", "");
            }


            return emailBody;
        }

        internal async Task<NoSqlServiceResult<DuplicateSeriesTitleResponse>> GetDuplicateSeriesIdByTitle(DuplicateSeriesTitleRequest duplicateSeriesTitleRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<DuplicateSeriesTitleResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidateDuplicateSeriesTitleRequest(duplicateSeriesTitleRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetDuplicateSeriesIdData(duplicateSeriesTitleRequest, profileObjectId);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new DuplicateSeriesTitleResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetDuplicateSeriesIdByTitle");
            }
            return noSqlServiceResult;
        }

        private async Task<DuplicateSeriesTitleResponse> GetDuplicateSeriesIdData(DuplicateSeriesTitleRequest duplicateSeriesTitleRequest, ObjectId profileObjectId)
        {
            var duplicateSeriesTitleResponse = new DuplicateSeriesTitleResponse();

            var filter = Builders<BsonDocument>.Filter.In("_id", duplicateSeriesTitleRequest.BTKeyList);
            var productDocumentList = await GetProductsByBTKey(filter);

            var seriesDuplicateTitleList = new List<SeriesDuplicateTitle>();
            var seriesIdList = new List<string>();
            foreach (var productDocument in productDocumentList)
            {
                var seriesDuplicateTitle = getProductDetailsFromProductDocument(productDocument);
                seriesDuplicateTitleList.Add(seriesDuplicateTitle);
                seriesIdList.AddRange(seriesDuplicateTitle.SeriesIdList);

            }
            var profiledSeriesDocuments = await getProfiledSeriesDocumentBySeriesId(seriesIdList, duplicateSeriesTitleRequest, profileObjectId);
            var duplicateProfiledSeriesList = new List<DuplicateProfiledSeries>();
            foreach (var profiledSeries in profiledSeriesDocuments)
            {
                var duplicateProfiledSeries = new DuplicateProfiledSeries();
                if (profiledSeries.Contains("_id"))
                    duplicateProfiledSeries.ProfiledSeriesId = profiledSeries["_id"].AsObjectId.ToString();
                if (profiledSeries.Contains("SeriesID"))
                    duplicateProfiledSeries.SeriesId = profiledSeries["SeriesID"].AsString;
                duplicateProfiledSeriesList.Add(duplicateProfiledSeries);
            }
            foreach (var seriesDuplicateTitle in seriesDuplicateTitleList)
            {
                foreach (var duplicateProfiledSeries in duplicateProfiledSeriesList)
                {
                    if (seriesDuplicateTitle.SeriesIdList.Contains(duplicateProfiledSeries.SeriesId))
                    {
                        seriesDuplicateTitle.DuplicateProfiledSeriesIdList += duplicateProfiledSeries.ProfiledSeriesId +";";
                    }
                }
            }
            duplicateSeriesTitleResponse.SeriesDuplicateTitleList = seriesDuplicateTitleList;
            return duplicateSeriesTitleResponse;
        }

        private async Task<List<BsonDocument>> getProfiledSeriesDocumentBySeriesId(List<string> seriesIdList, DuplicateSeriesTitleRequest duplicateSeriesTitleRequest, ObjectId profileObjectId)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var profiledSeriesList = new List<BsonDocument>();
            var duplicateProfiledSeriesIdList = new List<string>();
            var filter = Builders<BsonDocument>.Filter.In("SeriesID", seriesIdList)
                & Builders<BsonDocument>.Filter.Eq("RedundantProfileInformation.OrganizationID", duplicateSeriesTitleRequest.OrganizationId)
                & Builders<BsonDocument>.Filter.Ne("ProfileID", profileObjectId);
            var projection = Builders<BsonDocument>.Projection.Include("SeriesID");
            while (retries > 0)
            {
                try
                {
                    profiledSeriesList = await _profiledSeries.Find<BsonDocument>(filter).Project(projection).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }


            return profiledSeriesList;
        }

        private async Task<List<BsonDocument>> getProfiledSeriesDocumentBySeriesId(List<string> seriesIdList, DuplicateSeriesTitleRequest duplicateSeriesTitleRequest)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var profiledSeriesList = new List<BsonDocument>();
            var duplicateProfiledSeriesIdList = new List<string>();
            var filter = Builders<BsonDocument>.Filter.In("SeriesID", seriesIdList)
                & Builders<BsonDocument>.Filter.Eq("RedundantProfileInformation.OrganizationID", duplicateSeriesTitleRequest.OrganizationId);

            var projection = Builders<BsonDocument>.Projection.Include("ProfileID").Include("SeriesID").Include("TotalPrimaryQuantity")
                .Include("RedundantProfileInformation.Name").Include("RedundantProfileInformation.ProfileType").Include("RedundantProfileInformation.Programs").Include("RedundantProfileInformation.ShippingAccountNumber").Include("RedundantProfileInformation.Status")
                .Include("RedundantSeriesInformation.Name")
                .Include("PurchaseOrders.FormatPreferencePrimary").Include("PurchaseOrders.FormatPreferencePrimaryQuantity")
                .Include("PurchaseOrders.FormatPreferenceSecondary").Include("PurchaseOrders.FormatPreferenceSecondaryQuantity")
                .Include("PurchaseOrders.POLineNumber").Include("PurchaseOrders.StartDate").Include("PurchaseOrders.ShippingPreference"); 
            while (retries > 0)
            {
                try
                {
                    profiledSeriesList = await _profiledSeries.Find<BsonDocument>(filter).Project(projection).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }


            return profiledSeriesList;
        }

        private SeriesDuplicateTitle getProductDetailsFromProductDocument(BsonDocument productDocument)
        {
            var seriesDuplicateTitle = new SeriesDuplicateTitle();
            var seriesIdList = new List<string>();
            seriesDuplicateTitle.SeriesIdList = seriesIdList;
            seriesDuplicateTitle.DuplicateProfiledSeriesIdList = string.Empty;
            if (productDocument.Contains("_id"))
                seriesDuplicateTitle.BTKey = productDocument["_id"].AsString;
            if (productDocument.Contains("SeriesInformation"))
            {
                var seriesInformationDocuments = productDocument["SeriesInformation"].AsBsonArray;
                foreach (var value in seriesInformationDocuments)
                {
                    var seriesProducts = BsonSerializer.Deserialize<SeriesProducts>(value.ToJson());
                    seriesIdList.Add(seriesProducts.SeriesID);
                }
                seriesDuplicateTitle.SeriesIdList = seriesIdList;
            }
            return seriesDuplicateTitle;
        }

        private async Task<List<BsonDocument>> GetProductsByBTKey(FilterDefinition<BsonDocument> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var productList = new List<BsonDocument>();
            var projection = Builders<BsonDocument>.Projection.Include("SeriesInformation");
            while (retries > 0)
            {
                try
                {
                    productList = await _products.Find<BsonDocument>(filter).Project(projection).ToListAsync<BsonDocument>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return productList;
        }

        internal async Task<NoSqlServiceResult<List<ProfiledSeries>>> GetDuplicateSeriesDetailsByTitle(string duplicateProfiledSeriesIdList)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<ProfiledSeries>> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateDuplicateSeriesDetailsTitleRequest(duplicateProfiledSeriesIdList);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetDuplicateSeriesDetailsTitleData(duplicateProfiledSeriesIdList);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new List<ProfiledSeries>();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetDuplicateSeriesDetailsByTitle");
            }
            return noSqlServiceResult;
        }

        private async Task<List<ProfiledSeries>> GetEtsDuplicateSeriesDetailData(DuplicateSeriesTitleRequest duplicateSeriesTitleRequest)
        {
            var duplicateSeriesTitleResponse = new DuplicateSeriesTitleResponse();

            var filter = Builders<BsonDocument>.Filter.In("_id", duplicateSeriesTitleRequest.BTKeyList);
            var productDocumentList = await GetProductsByBTKey(filter);

            var seriesDuplicateTitleList = new List<SeriesDuplicateTitle>();
            var seriesIdList = new List<string>();
            foreach (var productDocument in productDocumentList)
            {
                var seriesDuplicateTitle = getProductDetailsFromProductDocument(productDocument);
                seriesDuplicateTitleList.Add(seriesDuplicateTitle);
                seriesIdList.AddRange(seriesDuplicateTitle.SeriesIdList);

            }
            var profiledSeriesDocuments = await getProfiledSeriesDocumentBySeriesId(seriesIdList, duplicateSeriesTitleRequest);
            var profiledSeriesList = new List<ProfiledSeries>();
            foreach (var profiledSeriesDocument in profiledSeriesDocuments)
            {
                var profiledSeries = BindProfiledSeries(profiledSeriesDocument);
                if (profiledSeries.RedundantProfileInformation != null && profiledSeries.RedundantProfileInformation.Status != null)
                {
                    profiledSeries.RedundantProfileInformation.Status = profiledSeries.RedundantProfileInformation.Status.Equals("Active", StringComparison.OrdinalIgnoreCase) ? "N" : "Y";
                }
                //else //comment out because profiledSeries.RedundantProfileInformation == null throws NULL exception
                //{
                //    profiledSeries.RedundantProfileInformation.Status = "Y";
                //}
                profiledSeriesList.Add(profiledSeries);
            }

            return profiledSeriesList;
        }

        internal async Task<NoSqlServiceResult<List<ProfiledSeries>>> GetEtsDuplicateSeriesDetails(DuplicateSeriesTitleRequest duplicateSeriesTitleRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<ProfiledSeries>> { Status = NoSqlServiceStatus.Success };
            try
            {
                noSqlServiceResult.Data = await GetEtsDuplicateSeriesDetailData(duplicateSeriesTitleRequest);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new List<ProfiledSeries>();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetDuplicateSeriesDetailsByTitle");
            }
            return noSqlServiceResult;
        }

        private async Task<List<ProfiledSeries>> GetDuplicateSeriesDetailsTitleData(string duplicateProfiledSeriesIdList)
        {
            var duplicateSeriesTitleResponse = new DuplicateSeriesTitleResponse();

            var filter = Builders<BsonDocument>.Filter.In("_id", ConvertToObjectIdList(duplicateProfiledSeriesIdList));
            var profiledSeriesDocumentList = await GetProfiledSeries(filter);
            var profiledSeriesList = new List<ProfiledSeries>();
            foreach (var profiledSeriesDocument in profiledSeriesDocumentList)
            {
                var profiledSeries = BindProfiledSeries(profiledSeriesDocument);
                if (profiledSeries.RedundantProfileInformation != null && profiledSeries.RedundantProfileInformation.Status != null)
                {
                    profiledSeries.RedundantProfileInformation.Status = profiledSeries.RedundantProfileInformation.Status.Equals("Active", StringComparison.OrdinalIgnoreCase) ? "N" : "Y";
                }
                else
                {
                    profiledSeries.RedundantProfileInformation.Status = "Y";
                }
                profiledSeriesList.Add(profiledSeries);

            }
            return profiledSeriesList;
        }

        private List<ObjectId> ConvertToObjectIdList(string duplicateProfiledSeriesIdList)
        {
            var profiledSeriesIdList = duplicateProfiledSeriesIdList.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            var profiledSeriesObjectIdList = new List<ObjectId>();
            foreach (var profileId in profiledSeriesIdList)
            {
                var profiledSeriesObjectId = new ObjectId();
                if (ObjectId.TryParse(profileId, out profiledSeriesObjectId))
                {
                    profiledSeriesObjectIdList.Add(profiledSeriesObjectId);

                }
            }
            return profiledSeriesObjectIdList;

        }

        #region Validation
        private string ValidateEmailSeriesRequest(EmailSeriesRequest emailSeriesRequest)
        {
            if (emailSeriesRequest == null)
            {
                return "Request is required";
            }
            if (emailSeriesRequest.EmailTo == null)
            {
                return "Email to is required";
            }
            if (emailSeriesRequest.SendCopyToUser && emailSeriesRequest.UserEmail == null)
            {
                return "Users email is required";
            }
            if (emailSeriesRequest.SeriesInformation == null)
            {
                return "Series information is required";
            }
            return null;
        }

        private string ValidateDuplicateSeriesDetailsRequest(DuplicateSeriesDetailsRequest duplicateSeriesDetailsRequest)
        {
            if (duplicateSeriesDetailsRequest == null)
            {
                return "Request is required";
            }
            if (duplicateSeriesDetailsRequest.SeriesId == null)
            {
                return "Series Id is required";
            }
            if (duplicateSeriesDetailsRequest.OrganizationId == null)
            {
                return "Organization Id is required";
            }
            return null;
        }

        private string ValidateDuplicateSeriesRequest(DuplicateSeriesRequest duplicateSeriesRequest)
        {
            if (duplicateSeriesRequest == null)
            {
                return "Request is required";
            }
            if (duplicateSeriesRequest.OrganizationId == null)
            {
                return "Organization Id is required";
            }
            if (duplicateSeriesRequest.SeriesIdList == null || duplicateSeriesRequest.SeriesIdList.Count < 1)
            {
                return "Series Id List is required";;
            }
            return null;
        }

        private string ValidateDuplicateSeriesDetailsTitleRequest(string duplicateProfiledSeriesIdList)
        {
            if (string.IsNullOrEmpty(duplicateProfiledSeriesIdList))
            {
                return "Request is required";
            }
            return null;

        }

        private string ValidateDuplicateSeriesTitleRequest(DuplicateSeriesTitleRequest duplicateSeriesTitleRequest, out ObjectId profileObjectId)
        {
            profileObjectId = new ObjectId();
            if (duplicateSeriesTitleRequest == null)
            {
                return "Request is required";
            }
            if (duplicateSeriesTitleRequest.BTKeyList == null || duplicateSeriesTitleRequest.BTKeyList.Count < 1)
            {
                return "BT Key List is required";
            }
            if (duplicateSeriesTitleRequest.OrganizationId ==  null)
            {
                return "Organization Id is required";
            }
            if (!string.IsNullOrEmpty(duplicateSeriesTitleRequest.ProfileId) && !ObjectId.TryParse(duplicateSeriesTitleRequest.ProfileId, out profileObjectId))
            {
                return "Invalid Profile Id";

            }
            return null;
        }

        private string ValidateGetPurchaseOrderDetails(List<string> profiledSeriesIdList)
        {
            if (profiledSeriesIdList == null || !profiledSeriesIdList.Any())
            {
                return "Request is required";
            }
            return null;

        }
        #endregion

        internal async Task<NoSqlServiceResult<bool>> EditProfiledSeries(EditProfiledSeriesRequest editProfiledSeriesRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };

            try
            {
                await InsertChangeRequest(GetEditProfiledSeriesChangeRequest(editProfiledSeriesRequest));
                if (string.Equals(ChangeRequestRequestType.ModifySeries, editProfiledSeriesRequest.RequestType, StringComparison.OrdinalIgnoreCase))
                {
                    await UpdateProfiledSeriesRequestStatus(editProfiledSeriesRequest.ProfiledSeriesId, ChangeRequestStatus.Open);
                    await azureSearchQueueHelper.UpdateAzureSearchQueue(editProfiledSeriesRequest.ProfiledSeriesId, "ProfiledSeries", "Upsert", editProfiledSeriesRequest.SubmittedByUserName, AppSettings.AzureSearchQueuePriority);
                }

                noSqlServiceResult.Data = true;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = false;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "EditProfiledSeries", editProfiledSeriesRequest.ToString());
            }
            return noSqlServiceResult;
        }

        private async Task<bool> UpdateProfiledSeriesRequestStatus(string profiledSeriesId, string requestStatus)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    var builder = Builders<BsonDocument>.Filter;
                    var filter = builder.Eq("_id", ObjectId.Parse(profiledSeriesId));
                    var update = Builders<BsonDocument>.Update.Set("RequestStatus", requestStatus);
                    var result = await _profiledSeries.UpdateOneAsync(filter, update);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return true;
        }

        private async Task<bool> InsertChangeRequest(ChangeRequests changeRequest)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    await _changeRequests.InsertOneAsync(changeRequest);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return true;
        }

        public async Task<NoSqlServiceResult<bool>> CheckIfAddSeriesRequestExists(string organizationID, string profileID, string seriesID)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };

            try
            {

                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var builder = Builders<ChangeRequests>.Filter;
                var filter = builder.Eq("OrganizationID", organizationID) &
                                builder.Eq("ProfileID", ObjectId.Parse(profileID)) &
                                builder.Eq("ProfiledSeriesChangeRequest.SeriesID", seriesID) &
                                builder.Eq("RequestStatus", "New") &
                                builder.Eq("RequestType", "Add");

                var result = new List<ChangeRequests>();
                var response = false;

                while (retries > 0)
                {
                    try
                    {
                        var cursor = _changeRequests.Find<ChangeRequests>(filter);
                        result = await cursor.ToListAsync<ChangeRequests>();
                        response = result.Count > 0;

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                noSqlServiceResult.Data = response;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = false;

                LoggerService logger = new LoggerService();
                var inputData = string.Format("OrgID={0}, ProfileID={1}, SeriesID={2}", organizationID, profileID, seriesID);
                logger.LogError(ex, "CheckIfChangeRequestExistAddSeries", inputData);
            }
            return noSqlServiceResult;
        }
        
        private ChangeRequests GetEditProfiledSeriesChangeRequest(EditProfiledSeriesRequest editProfiledSeriesRequest)
        {
            var changeRequest = new ChangeRequests();
            var profileChangeRequest = new ProfileChangeRequest();
            var profiledSeriesChangeRequest = new ProfiledSeriesChangeRequest();
            var profiledSeriesOriginalState = new ProfiledSeriesChangeRequest();
            var redundantSeriesData = new RedundantSeriesData();
            profiledSeriesChangeRequest.PurchaseOrders = editProfiledSeriesRequest.NewPurchaseOrders;
            profiledSeriesChangeRequest.Notes = editProfiledSeriesRequest.NewNotes;
            profiledSeriesChangeRequest.SpecialInstruction = editProfiledSeriesRequest.NewSpecialInstruction;
            profiledSeriesChangeRequest.SeriesID = editProfiledSeriesRequest.SeriesId;
            redundantSeriesData.Name = editProfiledSeriesRequest.SeriesName;
            redundantSeriesData.Frequency = editProfiledSeriesRequest.Frequency;
            if (!string.IsNullOrEmpty(editProfiledSeriesRequest.Programs))
            {
                redundantSeriesData.Programs = editProfiledSeriesRequest.Programs.Split(',').ToList();
            }

            if (string.Equals(ChangeRequestRequestType.ModifySeries, editProfiledSeriesRequest.RequestType, StringComparison.OrdinalIgnoreCase))
            {
                profiledSeriesOriginalState.PurchaseOrders = editProfiledSeriesRequest.OldPurchaseOrders;
                profiledSeriesOriginalState.Notes = editProfiledSeriesRequest.OldNotes;
                profiledSeriesOriginalState.SpecialInstruction = editProfiledSeriesRequest.OldSpecialInstruction;
                changeRequest.ProfiledSeriesID = ObjectId.Parse(editProfiledSeriesRequest.ProfiledSeriesId);
                changeRequest.ProfiledSeriesOriginalState = profiledSeriesOriginalState;
            }

            var now = DateTime.Now;
            var footprintInformation = new FootprintInformation();
            footprintInformation.CreatedBy = editProfiledSeriesRequest.SubmittedByUserName;
            footprintInformation.CreatedDate = now;
            footprintInformation.CreatedByUserID = editProfiledSeriesRequest.SubmittedByUserId;
            footprintInformation.UpdatedBy = editProfiledSeriesRequest.SubmittedByUserName;
            footprintInformation.UpdatedDate = now;
            footprintInformation.UpdatedByUserID = editProfiledSeriesRequest.SubmittedByUserId;

            changeRequest.FootprintInformation = footprintInformation;
            changeRequest.ProfiledSeriesChangeRequest = profiledSeriesChangeRequest;
            changeRequest.RedundantSeriesInformation = redundantSeriesData;

            changeRequest.ChangeType = ChangeRequestChangeType.ProfiledSeries;
            changeRequest.RequestType = editProfiledSeriesRequest.RequestType;
            changeRequest.ERPAccountNumber = editProfiledSeriesRequest.ERPAccountNumber;
            changeRequest.SalesTerritory = editProfiledSeriesRequest.SalesTerritory;
            changeRequest.RequestStatus = ChangeRequestStatus.Open;
            changeRequest.ProfileName = editProfiledSeriesRequest.ProfileName;
            changeRequest.ProfileID = ObjectId.Parse(editProfiledSeriesRequest.ProfileId);
            changeRequest.OrganizationName = editProfiledSeriesRequest.OrganizationName;
            changeRequest.OrganizationID = editProfiledSeriesRequest.OrganizationId;

            if(string.IsNullOrWhiteSpace(changeRequest.SalesTerritory))
            {
                CommonHelper.SendMissingSalesTerritoryEmail();
            }
            else
            {
                ChangeRequestManager changeRequestManager = new ChangeRequestManager();
                changeRequest.AccountRepName = changeRequestManager.GetAccountRepName(_iCustomerAccountRepCollection, changeRequest.SalesTerritory);
            }
            return changeRequest;
        }

        public async Task<List<ProfiledSeries>> GetProfiledSeriesByProfile(ObjectId profiledId)
        {
            var profiledSeriesList = new List<ProfiledSeries>();
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            List<BsonDocument> bsonProfiledSeries = new List<BsonDocument>();

            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("ProfileID", profiledId);
            
            while (retries > 0)
            {
                try
                {

                    bsonProfiledSeries = await _profiledSeries.Find(filter).ToListAsync<BsonDocument>();
                    
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            foreach (var document in bsonProfiledSeries)
            {
                // process document
                ProfiledSeries mongoProfiledSeries = BindProfiledSeries(document);
                profiledSeriesList.Add(mongoProfiledSeries);
            }

            return profiledSeriesList;
        }

        internal async Task<NoSqlServiceResult<List<string>>> AddGridsFromTemplate(AddGridRequest addGridRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<string>> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidateAddGridRequest(addGridRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                var profiledSeriesList = await GetProfiledSeriesByProfile(profileObjectId);
                noSqlServiceResult.Data = await CreateAddGridsChangeRequest(profiledSeriesList, addGridRequest);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999";
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "AddGridsFromTemplate");
            }
            return noSqlServiceResult;
        }

        private async Task<List<string>> CreateAddGridsChangeRequest(List<ProfiledSeries> profiledSeriesList, AddGridRequest addGridRequest)
        {
            var changeRequestList = new List<ChangeRequests>();
            var updatedProfiledSeriesObjectIdList = new List<ObjectId>();
            var updatedProfiledSeriesList = new List<string>();
            DateTime now = DateTime.Now;
            var result = true;

            FootprintInformation footprintInformation = new FootprintInformation();
            footprintInformation.CreatedBy = addGridRequest.UserName;
            footprintInformation.CreatedDate = now;
            footprintInformation.CreatedByUserID = addGridRequest.UserId;
            footprintInformation.UpdatedBy = addGridRequest.UserName;
            footprintInformation.UpdatedDate = now;
            var totalRequestQuantity = 0;
            var POGridList = new List<POGrid>();
            if (addGridRequest != null && addGridRequest.PurchaseOrderGrids != null)
            {
                foreach (var gridLine in addGridRequest.PurchaseOrderGrids)
                {
                    totalRequestQuantity += gridLine.Quantity;
                    var poGrid = new POGrid();
                    poGrid.Quantity = gridLine.Quantity;
                    poGrid.ItemTypeID = gridLine.ItemType;
                    poGrid.AgencyCodeID = gridLine.AgencyCode;
                    poGrid.CallNumberText = gridLine.CallNumber;
                    poGrid.CollectionID = gridLine.Collection;
                    poGrid.FootprintInformation = footprintInformation;
                    POGridList.Add(poGrid);       
                }
            }
            var salesTerritoryMissing = false;
            foreach(var profiledSeries in profiledSeriesList)
            {
                if (profiledSeries.PurchaseOrders != null && profiledSeries.PurchaseOrders.Count < 2 && string.IsNullOrEmpty(profiledSeries.RequestStatus))
                {
                    var totalQty = 0;
                    updatedProfiledSeriesList.Add(profiledSeries.SeriesID);
                    updatedProfiledSeriesObjectIdList.Add(profiledSeries.ProfiledSeriesID);
                    ChangeRequests changeRequest = new ChangeRequests();
                    changeRequest.ProfileID = ObjectId.Parse(addGridRequest.ProfileID);
                    changeRequest.ProfiledSeriesID = profiledSeries.ProfiledSeriesID;
                    changeRequest.ChangeType = ChangeRequestChangeType.ProfiledSeries;
                    changeRequest.RequestType = ChangeRequestRequestType.ModifySeries;
                    changeRequest.RequestStatus = ChangeRequestStatus.Open;
                    changeRequest.OrganizationID = addGridRequest.OrganizationID;
                    changeRequest.OrganizationName = addGridRequest.OrganizationName;
                    changeRequest.ProfileName = addGridRequest.ProfileName;
                    changeRequest.ERPAccountNumber = addGridRequest.ERPAccountNumber;
                    changeRequest.SalesTerritory = addGridRequest.SalesTerritory;
                    if(string.IsNullOrWhiteSpace(changeRequest.SalesTerritory))
                    {
                        salesTerritoryMissing = true;
                    }
                    else
                    {
                        ChangeRequestManager changeRequestManager = new ChangeRequestManager();
                        changeRequest.AccountRepName =  changeRequestManager.GetAccountRepName(_iCustomerAccountRepCollection, changeRequest.SalesTerritory);
                    }
                    ProfiledSeriesChangeRequest profiledSeriesChangeRequestOriginal = new ProfiledSeriesChangeRequest();
                    profiledSeriesChangeRequestOriginal.SeriesID = profiledSeries.SeriesID;
                    profiledSeriesChangeRequestOriginal.Notes = profiledSeries.Note;
                    profiledSeriesChangeRequestOriginal.PurchaseOrders = profiledSeries.PurchaseOrders;
                    changeRequest.ProfiledSeriesOriginalState = profiledSeriesChangeRequestOriginal;
                    var profiledSeriesChangeRequest = profiledSeriesChangeRequestOriginal;
                    changeRequest.RedundantSeriesInformation = profiledSeries.RedundantSeriesInformation;
                    changeRequest.FootprintInformation = footprintInformation;
                    var purchaseOrders = profiledSeries.PurchaseOrders;
                    var purchaseOrder = new PO();
                    if (profiledSeries.PurchaseOrders == null || profiledSeries.PurchaseOrders.Count == 0)
                    {
                        
                        purchaseOrder.FootprintInformation = footprintInformation;
                    }
                    else
                    {
                        purchaseOrder = purchaseOrders[0];
                    }

                    if(purchaseOrder.PurchaseOrderGrids != null  && string.Equals(addGridRequest.ChangeType, "Append", StringComparison.OrdinalIgnoreCase))
                    {
                        purchaseOrder.PurchaseOrderGrids.AddRange(POGridList);
                    }
                    else
                    {
                        purchaseOrder.PurchaseOrderGrids = POGridList;
                    }


                    totalQty = purchaseOrder.PurchaseOrderGrids.Sum(x => x.Quantity ?? 0);
                    purchaseOrder.FormatPreferencePrimaryQuantity = totalQty;
                    purchaseOrders = new List<PO>();
                    purchaseOrders.Add(purchaseOrder);
                    profiledSeriesChangeRequest.PurchaseOrders = purchaseOrders;
                    changeRequest.ProfiledSeriesChangeRequest = profiledSeriesChangeRequest;
                    changeRequestList.Add(changeRequest);
                }

            }

            if(salesTerritoryMissing)
            {
                CommonHelper.SendMissingSalesTerritoryEmail();
            }
            if (changeRequestList.Any() && updatedProfiledSeriesObjectIdList.Any())
            {
                var updateChangeRequestResult = await UpdateManyChangeRequest(changeRequestList, updatedProfiledSeriesObjectIdList);
                await azureSearchQueueHelper.UpdateAzureSearchQueue(updatedProfiledSeriesList, "ProfiledSeries", "Upsert", addGridRequest.UserName, AppSettings.AzureSearchQueuePriority);
            }
            return updatedProfiledSeriesList;
            
        }

        private async Task<bool> UpdateManyChangeRequest(List<ChangeRequests> changeRequestList, List<ObjectId> updatedProfiledSeriesObjectIdList)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {

                try
                {
                    await _changeRequests.InsertManyAsync(changeRequestList);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            retries = AppSettings.MaxConnectionRetries;
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.In("_id", updatedProfiledSeriesObjectIdList);
            var update = Builders<BsonDocument>.Update.Set("RequestStatus", ChangeRequestStatus.Open);
            while (retries > 0)
            {

                try
                {
                    var result = await _profiledSeries.UpdateManyAsync(filter, update);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }


            return true;
        }

        private string ValidateAddGridRequest(AddGridRequest addGridRequest, out ObjectId profiledObjectId)
        {
            profiledObjectId = new ObjectId();
            if (addGridRequest == null)
            {
                return "Request is required";
            }

            if (string.IsNullOrEmpty(addGridRequest.ProfileID))
            {
                return "Profile Id is required";

            }

            if (!ObjectId.TryParse(addGridRequest.ProfileID, out profiledObjectId))
            {
                return "Invalid Profile Id";

            }
            return null;
        }

        public async Task<NoSqlServiceResult<SeriesListResponse>> GetSeriesListsBySearch(SeriesListRequest seriesListRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<SeriesListResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                var seriesListResponse = new SeriesListResponse();
                var searchText = GetProfiledSeriesSearchText(seriesListRequest.KeywordValue, seriesListRequest.KeywordType);
                var searchParameters = GetProfiledSeriesSearchParameters(seriesListRequest);
                var profilesResponse = new List<ProfileDetailsResponse>();
                ArrayList ltSeriesListing = new ArrayList();

                DocumentSearchResult<ProfiledSeriesSearchResultItem> searchResponse = await _profiledSeriesIndexClient.Documents.SearchAsync<ProfiledSeriesSearchResultItem>(searchText, searchParameters);

                if (searchResponse != null)
                {
                    foreach (var result in searchResponse.Results)
                    {
                        var profiledSeries = ConvertProfiledSeriesSearchResultItemToProfileResponse(result.Document, seriesListRequest.EnableGetProfileIDByOrg, seriesListRequest.OrganizationID);
                        ltSeriesListing.Add(profiledSeries);
                    }

                    seriesListResponse.Facets = searchResponse.Facets;
                    seriesListResponse.Count = searchResponse.Count.HasValue ? searchResponse.Count.Value : 0;
                }

                seriesListResponse.SeriesListing = (SeriesItem[])ltSeriesListing.ToArray(typeof(SeriesItem));
                noSqlServiceResult.Data = seriesListResponse;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new SeriesListResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetSeriesListsBySearch", seriesListRequest.ProfileID);
            }

            return noSqlServiceResult;
        }

        public async Task<NoSqlServiceResult<List<string>>> GetPendingProfiles(string orgId, string seriesID)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<string>> { Status = NoSqlServiceStatus.Success };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var builder = Builders<ChangeRequests>.Filter;
                var filter = builder.Eq("OrganizationID", orgId) &
                                builder.Eq("ProfiledSeriesChangeRequest.SeriesID", seriesID) &
                                builder.In("RequestStatus", CommonHelper.GetChangeRequestPendingStatuses());

                var result = new List<ChangeRequests>();
                var response = new List<string>();

                while (retries > 0)
                {
                    try
                    {
                        var cursor = _changeRequests.Find<ChangeRequests>(filter);
                        result = await cursor.ToListAsync<ChangeRequests>();

                        if (result.Count > 0)
                        {
                            response = result.GroupBy(res => res.ProfileID)
                                        .Select(grp => grp.First().ProfileID.ToString())
                                        .ToList();

                        }

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

                noSqlServiceResult.Data = response;
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;
                noSqlServiceResult.Data = new List<string>();

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPendingProfiles", orgId + ", " + seriesID);

            }

            return noSqlServiceResult;
        }

        private string GetProfiledSeriesSearchText(string keywordValue, string keywordType)
        {
            if (string.IsNullOrEmpty(keywordValue))
                return "*";
            if(string.Equals(keywordType, "SeriesID", StringComparison.OrdinalIgnoreCase))
            {
                keywordValue = keywordValue.TrimStart('0');
            }
            switch (keywordType)
            {
                case "SeriesID":
                case "SeriesNameNoPunctuation":
                    return "/.*" + CommonHelper.RemoveSpecialCharacters(keywordValue) + ".*/";
                case "PublicationDate":
                    DateTime dateTime = new DateTime();
                    DateTime.TryParse(keywordValue, out dateTime);
                    return "/" + dateTime.ToString("M/d/yyyy").Replace("/","\\/") + ".*/";
                case "ListPrice":
                    return "'" + keywordValue.Replace("$", "") + "'";
                case "AreasOfInterest":
                    return "/.*" + keywordValue + ".*/";
                case "POLineNumberList":
                    return "/.*" + keywordValue + ".*/";
                case "PublisherDistributor":
                    return "/.*" + keywordValue + ".*/";
                case "POQuantityList":
                    return "/.*" + keywordValue + ".*/";
                default:
                    return "*";
            }
        }

        private SeriesItem ConvertProfiledSeriesSearchResultItemToProfileResponse(ProfiledSeriesSearchResultItem profiledSeriesSearchResultItem, bool? enableGetProfileIDByOrg, string orgID)
        {
            if (profiledSeriesSearchResultItem == null) return null;
            SeriesItem seriesItem = new SeriesItem();

            seriesItem.ProfiledSeriesId = profiledSeriesSearchResultItem.ObjectId;
            seriesItem.SeriesID = profiledSeriesSearchResultItem.SeriesID;
            seriesItem.SeriesName = profiledSeriesSearchResultItem.SeriesName;
            seriesItem.Status = profiledSeriesSearchResultItem.SeriesStatus;
            seriesItem.RequestStatus = profiledSeriesSearchResultItem.RequestStatus;
            seriesItem.Publisher = profiledSeriesSearchResultItem.Publisher;
            seriesItem.Frequency = profiledSeriesSearchResultItem.Frequency;
            seriesItem.ProgramType = SplitString(profiledSeriesSearchResultItem.SeriesPrograms);
            seriesItem.Programs = profiledSeriesSearchResultItem.SeriesPrograms;
            seriesItem.Format = profiledSeriesSearchResultItem.Format;
            seriesItem.Audience = profiledSeriesSearchResultItem.Audience;
            seriesItem.StartDataType = ""; // schema: redundantSeriesData->StartDateType


            seriesItem.LastIssueISBN = profiledSeriesSearchResultItem.ISBN;
            seriesItem.LastIssueEdition = profiledSeriesSearchResultItem.Edition;
            seriesItem.LastIssueBTKey = profiledSeriesSearchResultItem.BTKey;
            seriesItem.LastIssueName = profiledSeriesSearchResultItem.Title;
            if (!string.IsNullOrEmpty(profiledSeriesSearchResultItem.PublicationDate))
            {
                seriesItem.LastIssuePublishDate = Convert.ToDateTime(profiledSeriesSearchResultItem.PublicationDate);
            }
            if (!string.IsNullOrEmpty(profiledSeriesSearchResultItem.ListPrice))
            {
                seriesItem.LastIssueListPrice = decimal.Parse(profiledSeriesSearchResultItem.ListPrice);
            }

            seriesItem.ProfileName = profiledSeriesSearchResultItem.ProfileName;
            seriesItem.ShippingAccountNumber = profiledSeriesSearchResultItem.ShippingAccountNumber;
            var seriesPurchaseOrderList = new List<SeriesPurchaseOrder>();
            if (profiledSeriesSearchResultItem.POQuantityList != null)
            {
                foreach (var poQuantity in profiledSeriesSearchResultItem.POQuantityList)
                {
                    var poQuantitySplit = poQuantity.Split('|');
                    var seriesPurchaseOrder = new SeriesPurchaseOrder();
                    seriesPurchaseOrder.POLineNumber = poQuantitySplit[0];
                    seriesPurchaseOrder.FormatPreferencePrimaryQuantity = int.Parse(poQuantitySplit[1]);
                    seriesPurchaseOrderList.Add(seriesPurchaseOrder);
                }
            }
            seriesItem.PurchaseOrders = seriesPurchaseOrderList.ToArray();
            seriesItem.SalesTerritory = profiledSeriesSearchResultItem.SalesTerritory; // Karine 1/27/2017: need to wait for the profile load or real time sync in place
            seriesItem.HasRelatedSeries = profiledSeriesSearchResultItem.HasRelatedSeries;
            seriesItem.RelatedSeriesIDs = profiledSeriesSearchResultItem.RelatedSeriesIDs;
            seriesItem.Distributor = profiledSeriesSearchResultItem.Distributor;
            seriesItem.HasBindingPreferences = profiledSeriesSearchResultItem.HasBindingPreferences;
            if (seriesItem.HasBindingPreferences)
            {
                var bindingPreferences = new List<BindingPreference>();
                var bindingPreference = new BindingPreference();
                bindingPreference.Literal = profiledSeriesSearchResultItem.BindingPreferenceLiteral1;
                bindingPreference.PrimaryPreference = profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference1;
                bindingPreference.SecondaryPreference = profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference1;
                bindingPreference.HasMultiplePreference = profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference1;
                bindingPreferences.Add(bindingPreference);

                bindingPreference = new BindingPreference();
                bindingPreference.Literal = profiledSeriesSearchResultItem.BindingPreferenceLiteral2;
                bindingPreference.PrimaryPreference = profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference2;
                bindingPreference.SecondaryPreference = profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference2;
                bindingPreference.HasMultiplePreference = profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference2;
                bindingPreferences.Add(bindingPreference);

                bindingPreference = new BindingPreference();
                bindingPreference.Literal = profiledSeriesSearchResultItem.BindingPreferenceLiteral3;
                bindingPreference.PrimaryPreference = profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference3;
                bindingPreference.SecondaryPreference = profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference3;
                bindingPreference.HasMultiplePreference = profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference3;
                bindingPreferences.Add(bindingPreference);

                bindingPreference = new BindingPreference();
                bindingPreference.Literal = profiledSeriesSearchResultItem.BindingPreferenceLiteral4;
                bindingPreference.PrimaryPreference = profiledSeriesSearchResultItem.BindingPreferencePrimaryPreference4;
                bindingPreference.SecondaryPreference = profiledSeriesSearchResultItem.BindingPreferenceSecondaryPreference4;
                bindingPreference.HasMultiplePreference = profiledSeriesSearchResultItem.BindingPreferenceHasMultiplePreference4;
                bindingPreferences.Add(bindingPreference);

                seriesItem.BindingPreferences = bindingPreferences.OrderByDescending(x => x.HasMultiplePreference).ThenBy(x => x.Literal).ToList();
            }
            if (enableGetProfileIDByOrg.HasValue && enableGetProfileIDByOrg.Value && !string.IsNullOrEmpty(orgID))
            {
                seriesItem.ProfileIDListByOrg = GetAssignedProfiles(orgID, seriesItem.SeriesID);

            }

            seriesItem.POCount = profiledSeriesSearchResultItem.POCount;
            seriesItem.PO1FormatPreferenceLiteral = profiledSeriesSearchResultItem.PO1FormatPreferenceLiteral;
            seriesItem.TotalPrimaryQuantity = profiledSeriesSearchResultItem.TotalPrimaryQuantity;
            
            return seriesItem;
        }

        private SearchParameters GetProfiledSeriesSearchParameters(SeriesListRequest seriesListRequest)
        {
            var searchParameters = new SearchParameters();

            if (!string.IsNullOrEmpty(seriesListRequest.KeywordValue))
            {
                if (seriesListRequest.KeywordType == "PublisherDistributor")
                    searchParameters.SearchFields = new string[] { "Publisher", "Distributor" };
                else if (seriesListRequest.KeywordType == "SeriesNameNoPunctuation")
                    searchParameters.SearchFields = new string[] { "SeriesNameNoPunctuation", "AuthorNoPunctuation" };
                else
                    searchParameters.SearchFields = new string[] { seriesListRequest.KeywordType };
           
            }

            string sortField = ConvertToProfiledSeriesField(seriesListRequest.SortOnField);
            searchParameters.SearchMode = SearchMode.All;
            searchParameters.QueryType = QueryType.Full;
            searchParameters.IncludeTotalResultCount = true;
            searchParameters.Filter = GetProfiledSeriesSearchFilter(seriesListRequest);
            searchParameters.OrderBy = new string[] { sortField + " " + seriesListRequest.SortOnDirection.ToLower() };
            searchParameters.Top = seriesListRequest.PageSize;
            searchParameters.Skip = (seriesListRequest.PageNumber - 1) * seriesListRequest.PageSize;
            searchParameters.Facets = new List<string> { "SeriesStatus", "RequestType", "Format", "Frequency","Audience" };
            searchParameters.IncludeTotalResultCount = true;

            return searchParameters;
        }

        private string GetProfiledSeriesSearchFilter(SeriesListRequest seriesListRequest)
        {
            var filter = "ProfileID eq '" + seriesListRequest.ProfileID + "'";

            if (!string.IsNullOrEmpty(seriesListRequest.SeriesID))
                filter = "SeriesID eq '" + seriesListRequest.SeriesID + "'";

            filter += GetProfiledSeriesSearchFacetsFilter(seriesListRequest.Facets);
            filter += GetProfiledSeriesPONumberFilter(seriesListRequest.PONumber);
            
            return filter;
        }

        private string GetProfiledSeriesSearchFacetsFilter(List<ProfiledSeriesFacet> facets)
        {
            var filter = string.Empty;
            if (facets != null && facets.Any())
            {
                foreach (var facet in facets)
                {
                    filter += " and " + facet.FacetId + " eq '" + facet.FacetValue + "'";
                }
            }
            return filter;
        }

        private string GetProfiledSeriesPONumberFilter(string poNumber)
        {
            var filter = string.Empty;

            if (!string.IsNullOrEmpty(poNumber))
            {
                filter += " and POLineNumberList/any(t: t eq '" + poNumber + "')";
            }
            
            return filter;
        }

        internal async Task<NoSqlServiceResult<List<PurchaseOrderDetails>>> GetPurchaseOrderDetails(List<string> profiledSeriesIdList)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<PurchaseOrderDetails>> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateGetPurchaseOrderDetails(profiledSeriesIdList);

                var profiledSeriesObjectIdList = new List<ObjectId>();

                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }

                foreach (var profileId in profiledSeriesIdList)
                {
                    var profiledSeriesObjectId = new ObjectId();
                    if (ObjectId.TryParse(profileId, out profiledSeriesObjectId))
                    {
                        profiledSeriesObjectIdList.Add(profiledSeriesObjectId);

                    }
                }

                noSqlServiceResult.Data = await GetPurchaseOrderDetailsData(profiledSeriesObjectIdList);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new List<PurchaseOrderDetails>();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPurchaseOrderDetails");
            }
            return noSqlServiceResult;
        }


        private async Task<List<PurchaseOrderDetails>> GetPurchaseOrderDetailsData(List<ObjectId> profiledSeriesObjectIdList)
        {
            var purchaseOrderDetailsList = new List<PurchaseOrderDetails>();

            var filter = Builders<BsonDocument>.Filter.In("_id", profiledSeriesObjectIdList);
            var profiledSeriesDocumentList = await GetProfiledSeries(filter);
            foreach (var profiledSeriesDocument in profiledSeriesDocumentList)
            {
                var profiledSeries = BindProfiledSeries(profiledSeriesDocument);
                var purchaseOrderDetails = new PurchaseOrderDetails();
                purchaseOrderDetails.ProfiledSeriesId = profiledSeries.ProfiledSeriesID.ToString();
                purchaseOrderDetails.PurchaseOrders = profiledSeries.PurchaseOrders;
                purchaseOrderDetails.Note = profiledSeries.Note;
                purchaseOrderDetailsList.Add(purchaseOrderDetails);

            }
            return purchaseOrderDetailsList;
        }

        private async Task<List<ProfiledSeriesNotes>> GetProfiledSeries(List<ObjectId> profiledSeriesObjectIdList)
        {
            var profiledSeriesNotesList = new List<ProfiledSeriesNotes>();
            var filter = Builders<BsonDocument>.Filter.In("_id", profiledSeriesObjectIdList);
            var profiledSeriesDocumentList = await GetProfiledSeries(filter);
            foreach (var profiledSeriesDocument in profiledSeriesDocumentList)
            {
                var profiledSeries = BindProfiledSeries(profiledSeriesDocument);
                profiledSeriesNotesList.Add(new ProfiledSeriesNotes() { ProfiledSeriesID = profiledSeries.ProfiledSeriesID.ToString(), SeriesID = profiledSeries.SeriesID, RequestStatus = profiledSeries.RequestStatus, Note = profiledSeries.Note, FootprintInformation = profiledSeries.FootprintInformation });
            }
            return profiledSeriesNotesList;
        }

        internal async Task<NoSqlServiceResult<List<PurchaseOrderDetails>>> GetPurchaseOrderDetails(string profileID, string seriesID)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<PurchaseOrderDetails>> { Status = NoSqlServiceStatus.Success };

            try
            {
                noSqlServiceResult.Data = await GetPurchaseOrderDetailsData(profileID, seriesID);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new List<PurchaseOrderDetails>();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPurchaseOrderDetails");
            }
            return noSqlServiceResult;

        }

        private async Task<List<PurchaseOrderDetails>> GetPurchaseOrderDetailsData(string profileID, string seriesID)
        {
            var purchaseOrderDetailsList = new List<PurchaseOrderDetails>();

            var filter = Builders<BsonDocument>.Filter.Eq("SeriesID", seriesID)
                & Builders<BsonDocument>.Filter.Eq("ProfileID", ObjectId.Parse(profileID));

            var profiledSeriesDocumentList = await GetProfiledSeries(filter);

            foreach (var profiledSeriesDocument in profiledSeriesDocumentList)
            {
                var profiledSeries = BindProfiledSeries(profiledSeriesDocument);
                var purchaseOrderDetails = new PurchaseOrderDetails();
                purchaseOrderDetails.ProfiledSeriesId = profiledSeries.ProfiledSeriesID.ToString();
                purchaseOrderDetails.PurchaseOrders = profiledSeries.PurchaseOrders;
                purchaseOrderDetailsList.Add(purchaseOrderDetails);

            }
            return purchaseOrderDetailsList;
        }

        private List<string> GetAssignedProfiles(string orgId, string seriesID)
        {
            var result = new List<BsonDocument>();
            var response = new List<string>();

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var builder = Builders<BsonDocument>.Filter;
                var filter = builder.Eq("SeriesID", seriesID) &
                                builder.Eq("RedundantProfileInformation.OrganizationID", orgId) &
                                builder.Eq("RedundantProfileInformation.Status", "Active");

                while (retries > 0)
                {
                    try
                    {
                        var cursor = _profiledSeries.Find(filter);
                        result = cursor.ToList<BsonDocument>();

                        if (result.Count > 0)
                        {
                            response = result.GroupBy(res => res["ProfileID"])
                                        .Select(grp => grp.First()["ProfileID"].ToString())
                                        .ToList();
                        }

                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetAssignedProfiles", orgId + ", " + seriesID);
            }

            return response;
        }

        internal async Task<NoSqlServiceResult<RequestStatusQueueResponse>> GetRequestStatusQueue(RequestStatusQueueRequest requestStatusQueueRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<RequestStatusQueueResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                noSqlServiceResult.Data = await GetRequestStatusQueueData(requestStatusQueueRequest);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new RequestStatusQueueResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetRequestStatusQueue");
            }
            return noSqlServiceResult;
        }

        private async Task<RequestStatusQueueResponse> GetRequestStatusQueueData(RequestStatusQueueRequest requestStatusQueueRequest)
        {
            var requestStatusQueueResponse = new RequestStatusQueueResponse();

            //var filter = new BsonDocument();
            var filter = GetRequestStatusQueueFilter(requestStatusQueueRequest);
            var sort = GetRequestStatusQueueSort(requestStatusQueueRequest.SortBy, requestStatusQueueRequest.SortDirection);
            var skipDocs = (requestStatusQueueRequest.PageNumber - 1) * requestStatusQueueRequest.PageSize;

            requestStatusQueueResponse.RequestStatusQueueHasActiveRequests = await HasActiveChangeRequest(GetActiveRequestStatusQueueFilter());
            if (requestStatusQueueResponse.RequestStatusQueueHasActiveRequests)
            {
                var response = await GetChangeRequests(filter, sort, skipDocs, requestStatusQueueRequest.PageSize);
                requestStatusQueueResponse.ChangeRequestList = response.ItemList;
                requestStatusQueueResponse.TotalItems = response.TotalItems;

                if (requestStatusQueueResponse.ChangeRequestList != null && requestStatusQueueResponse.ChangeRequestList.Any())
                {
                    foreach (var changeRequest in requestStatusQueueResponse.ChangeRequestList)
                    {
                        if (string.Equals(changeRequest.ChangeType, ChangeRequestChangeType.ProfiledSeries, StringComparison.OrdinalIgnoreCase))
                        {
                            if (changeRequest.ProfiledSeriesChangeRequest != null && changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders != null)
                            {
                                foreach (var purchaseOrder in changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders)
                                {
                                    if (purchaseOrder.StartNextAvailableTitle)
                                    {
                                        purchaseOrder.StartDate = "Next Available Title";
                                    }

                                    if (!string.IsNullOrEmpty(purchaseOrder.FormatPreferencePrimary) && !string.IsNullOrEmpty(purchaseOrder.FormatPreferenceSecondary) &&
                                            purchaseOrder.FormatPreferencePrimary != "null" && purchaseOrder.FormatPreferenceSecondary != "null")
                                    {
                                        purchaseOrder.FormatPreferenceString = MapFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary) + " 1st, " + MapFormatPreferenceAbbr(purchaseOrder.FormatPreferenceSecondary) + " 2nd";
                                    }
                                    else
                                    {
                                        purchaseOrder.FormatPreferenceString = ReplaceFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary);
                                    }
                                }
                            }

                            if (changeRequest.ProfiledSeriesOriginalState != null && changeRequest.ProfiledSeriesOriginalState.PurchaseOrders != null)
                            {
                                foreach (var purchaseOrder in changeRequest.ProfiledSeriesOriginalState.PurchaseOrders)
                                {
                                    if (purchaseOrder.StartNextAvailableTitle)
                                    {
                                        purchaseOrder.StartDate = "Next Available Title";
                                    }

                                    if (!string.IsNullOrEmpty(purchaseOrder.FormatPreferencePrimary) && !string.IsNullOrEmpty(purchaseOrder.FormatPreferenceSecondary) &&
                                        purchaseOrder.FormatPreferencePrimary != "null" && purchaseOrder.FormatPreferenceSecondary != "null")
                                    {
                                        purchaseOrder.FormatPreferenceString = MapFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary) + " 1st, " + MapFormatPreferenceAbbr(purchaseOrder.FormatPreferenceSecondary) + " 2nd";
                                    }
                                    else
                                    {
                                        purchaseOrder.FormatPreferenceString = ReplaceFormatPreferenceAbbr(purchaseOrder.FormatPreferencePrimary);
                                    }
                                }
                            }
                        }
                    }
              
                   
                }
            }

            var groupResponse = await GroupChangeRequestsRequestStatus();

            foreach (var element in groupResponse)
            {
                if (element.Key == ChangeRequestStatus.Open)
                    requestStatusQueueResponse.TotalNew = element.Value;
                else if (element.Key == ChangeRequestStatus.InProgress)
                    requestStatusQueueResponse.TotalInProcess = element.Value;
                else if (element.Key == ChangeRequestStatus.Removed)
                    requestStatusQueueResponse.TotalRemoved = element.Value;
                else if (element.Key == ChangeRequestStatus.Completed)
                    requestStatusQueueResponse.TotalCompleted = element.Value;
            }

            return requestStatusQueueResponse;
        }

        private FilterDefinition<ChangeRequests> GetRequestStatusQueueFilter(RequestStatusQueueRequest requestStatusQueueRequest)
        {
            FilterDefinition<ChangeRequests> filter;
        
            if (requestStatusQueueRequest.RequestStatus != null && requestStatusQueueRequest.RequestStatus.Any())
            {
                filter = Builders<ChangeRequests>.Filter.In("RequestStatus", requestStatusQueueRequest.RequestStatus);
            }
            else
            {
                filter = Builders<ChangeRequests>.Filter.In("RequestStatus", CommonHelper.GetChangeRequestDisplayStatuses());
            }
            
            if (requestStatusQueueRequest.OrganizationLocationFilters != null && requestStatusQueueRequest.OrganizationLocationFilters.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("SalesTerritory", requestStatusQueueRequest.OrganizationLocationFilters);
            }

        
            if (requestStatusQueueRequest.ProfileName != null && requestStatusQueueRequest.ProfileName.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("ProfileName", requestStatusQueueRequest.ProfileName);
            }

            if (requestStatusQueueRequest.AccountNumber != null && requestStatusQueueRequest.AccountNumber.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("ERPAccountNumber", requestStatusQueueRequest.AccountNumber);
            }
            
            if (requestStatusQueueRequest.OrgName != null && requestStatusQueueRequest.OrgName.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("OrganizationName", requestStatusQueueRequest.OrgName);
            }

            if (requestStatusQueueRequest.RequestType != null && requestStatusQueueRequest.RequestType.Any())
            {
                filter = filter &  Builders<ChangeRequests>.Filter.In("RequestType", requestStatusQueueRequest.RequestType);
            }

            if (requestStatusQueueRequest.AccountRepName != null && requestStatusQueueRequest.AccountRepName.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("AccountRepName", requestStatusQueueRequest.AccountRepName);
            }

            if (requestStatusQueueRequest.RequestedBy != null && requestStatusQueueRequest.RequestedBy.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("FootprintInformation.CreatedBy", requestStatusQueueRequest.RequestedBy);
            }

            return filter;
        }

        private FilterDefinition<ChangeRequests> GetActiveRequestStatusQueueFilter()
        {
            return Builders<ChangeRequests>.Filter.Nin("RequestStatus", CommonHelper.GetChangeRequestSystemStatuses());
        }

        private async Task<List<KeyValuePair<string, int>>> GroupChangeRequestsRequestStatus()
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            List<ChangeRequests> changeRequestsGroup = new List<ChangeRequests>();
            var groupByList = new List<KeyValuePair<string, int>>();

            while (retries > 0)
            {
                try
                {
                    var filter = Builders<ChangeRequests>.Filter.In("RequestStatus", CommonHelper.GetChangeRequestDisplayStatuses());
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);

                    changeRequestsGroup = await cursor.ToListAsync<ChangeRequests>();

                    groupByList = changeRequestsGroup.GroupBy(s => s.RequestStatus)
                                    .Select(g => new KeyValuePair<string, int>(g.Key, g.Count())).ToList();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return groupByList;
        }

        private async Task<List<KeyValuePair<string, int>>> GroupChangeRequestsRequestStatus(PendingModificationRequest pendingModificationRequest, ObjectId profileObjectId)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            List<ChangeRequests> changeRequestsGroup = new List<ChangeRequests>();
            var groupByList = new List<KeyValuePair<string, int>>();

            while (retries > 0)
            {
                try
                {
                    var filter = Builders<ChangeRequests>.Filter.Eq("ChangeType", ChangeRequestChangeType.ProfiledSeries)
                                    & Builders<ChangeRequests>.Filter.In("RequestStatus", CommonHelper.GetChangeRequestDisplayStatuses());

                    
                    if (!string.IsNullOrEmpty(pendingModificationRequest.ProfileId))
                    {
                        filter = filter & Builders<ChangeRequests>.Filter.Eq("ProfileID", profileObjectId);
                    }

                    if (!string.IsNullOrEmpty(pendingModificationRequest.OrganizationId))
                    {
                        filter = filter & Builders<ChangeRequests>.Filter.Eq("OrganizationID", pendingModificationRequest.OrganizationId);
                    }

                    var cursor = _changeRequests.Find<ChangeRequests>(filter);

                    changeRequestsGroup = await cursor.ToListAsync<ChangeRequests>();

                    groupByList = changeRequestsGroup.GroupBy(s => s.RequestStatus)
                                    .Select(g => new KeyValuePair<string, int>(g.Key, g.Count())).ToList();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return groupByList;
        }


        private async Task<long> GetChangeRequestsRequestAddNewCount(PendingModificationRequest pendingModificationRequest, ObjectId profileObjectId)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            long retVal = 0;

            while (retries > 0)
            {
                try
                {
                    var filter = Builders<ChangeRequests>.Filter.Eq("ChangeType", ChangeRequestChangeType.ProfiledSeries)
                                    & Builders<ChangeRequests>.Filter.Eq("RequestStatus", ChangeRequestStatus.Open)
                                    & Builders<ChangeRequests>.Filter.Eq("RequestType", ChangeRequestRequestType.AddSeries);

                    if (!string.IsNullOrEmpty(pendingModificationRequest.ProfileId))
                    {
                        filter = filter & Builders<ChangeRequests>.Filter.Eq("ProfileID", profileObjectId);
                    }

                    if (!string.IsNullOrEmpty(pendingModificationRequest.OrganizationId))
                    {
                        filter = filter & Builders<ChangeRequests>.Filter.Eq("OrganizationID", pendingModificationRequest.OrganizationId);
                    }

                    var cursor = _changeRequests.Find<ChangeRequests>(filter);

                    retVal = await cursor.CountAsync();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return retVal;
        }
        private async Task<NoSqlResponse<ChangeRequests>> GetChangeRequests(FilterDefinition<ChangeRequests> filter, SortDefinition<ChangeRequests> sort, int skipDocs, int pageSize)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new NoSqlResponse<ChangeRequests>();
            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    
                    response.TotalItems = await cursor.CountAsync();
                    response.ItemList = await cursor.Sort(sort).Skip(skipDocs).Limit(pageSize).ToListAsync<ChangeRequests>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }

         private async Task<NoSqlResponse<ChangeRequests>> GetChangeRequests(FilterDefinition<ChangeRequests> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new NoSqlResponse<ChangeRequests>();
            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);

                    response.TotalItems = await cursor.CountAsync();
                    response.ItemList = await cursor.ToListAsync<ChangeRequests>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;

        }

        private async Task<bool> HasActiveChangeRequest(FilterDefinition<ChangeRequests> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new List<ChangeRequests>();
            var hasActiveChangeRequests = false;
            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    hasActiveChangeRequests = cursor.Any();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return hasActiveChangeRequests;
        }

        private SortDefinition<ChangeRequests> GetRequestStatusQueueSort(string sortBy, string sortDirection)
        {
            if (string.Equals(ChangeRequestSortOption.RequestedModification, sortBy, StringComparison.OrdinalIgnoreCase))
            {
                return sortDirection.ToLower() == "desc" ? Builders<ChangeRequests>.Sort.Descending(sortBy).Descending(ChangeRequestSortOption.DateRequested)
                : Builders<ChangeRequests>.Sort.Ascending(sortBy).Descending(ChangeRequestSortOption.DateRequested);
            }
            else
            {
                return sortDirection.ToLower() == "desc" ? Builders<ChangeRequests>.Sort.Descending(sortBy)
                : Builders<ChangeRequests>.Sort.Ascending(sortBy);
            }
        }

        internal async Task<NoSqlServiceResult<RequestStatusQueueResponse>> GetRequestStatusQueue(RequestStatusQueueRequest requestStatusQueueRequest, string filterType)
        {
            var noSqlServiceResult = new NoSqlServiceResult<RequestStatusQueueResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                noSqlServiceResult.Data = await GetRequestStatusQueueFilterList(requestStatusQueueRequest, filterType);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new RequestStatusQueueResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetRequestStatusQueue - Filter List");
            }
            return noSqlServiceResult;
        }
        private async Task<RequestStatusQueueResponse> GetRequestStatusQueueFilterList(RequestStatusQueueRequest requestStatusQueueRequest, string filterType)
        {
            var requestStatusQueueResponse = new RequestStatusQueueResponse();

            var filter = GetRequestStatusQueueFilter(requestStatusQueueRequest);
            
            requestStatusQueueResponse.RequestStatusQueueHasActiveRequests = await HasActiveChangeRequest(GetActiveRequestStatusQueueFilter());
            if (requestStatusQueueResponse.RequestStatusQueueHasActiveRequests)
            {
                var response = await GetChangeRequests(filter);
                requestStatusQueueResponse.ChangeRequestList = response.ItemList;
                requestStatusQueueResponse.TotalItems = response.TotalItems;

                if (requestStatusQueueResponse.ChangeRequestList != null && requestStatusQueueResponse.ChangeRequestList.Any())
                {
                    if (filterType == Common.Constants.RequestQueueFilerType.AccountRepName)
                        requestStatusQueueResponse.AccountRepNameList = requestStatusQueueResponse.ChangeRequestList.Select(p => p.AccountRepName).Distinct().OrderBy(p => p).ToList();
                    else if (filterType == Common.Constants.RequestQueueFilerType.RequestedBy)
                        requestStatusQueueResponse.RequestedByList = requestStatusQueueResponse.ChangeRequestList.Select(p => p.FootprintInformation.CreatedBy).Distinct().OrderBy(p => p).ToList();
                    else if (filterType == Common.Constants.RequestQueueFilerType.ProfileName)
                        requestStatusQueueResponse.ProfileNameList = requestStatusQueueResponse.ChangeRequestList.Select(p => p.ProfileName).Distinct().OrderBy(p => p).ToList();
                    else if (filterType == Common.Constants.RequestQueueFilerType.AccountNumber)
                        requestStatusQueueResponse.AccountNumberList = requestStatusQueueResponse.ChangeRequestList.Select(p => p.ERPAccountNumber).Distinct().OrderBy(p => p).ToList();
                    else if (filterType == Common.Constants.RequestQueueFilerType.OrganizationName)
                        requestStatusQueueResponse.OrgNameList = requestStatusQueueResponse.ChangeRequestList.Where(p => p.OrganizationName != null && p.OrganizationName != "").Select(p => p.OrganizationName).Distinct().OrderBy(p => p).ToList();

                    requestStatusQueueResponse.ChangeRequestList = new List<ChangeRequests>(); // reset it as filtering list doesn't need change request details, improve the network traffic
                }
            }

            return requestStatusQueueResponse;
        }

        internal async Task<NoSqlServiceResult<bool>> UpdateChangeRequest(ChangeRequestUpdateRequest changeRequestUpdateRequest)
        {
            var result = new NoSqlServiceResult<bool>();
            var updateChangeRequestDocumentList = new List<BsonDocument>();
            var now = DateTime.Now;
            var profileIdList = new List<string>();
            var profiledSeriesIdList = new List<string>();
            if (changeRequestUpdateRequest.ProfileChangeRequestUpdateList != null && changeRequestUpdateRequest.ProfileChangeRequestUpdateList.Count > 0)
            {
                foreach (var profileChangeRequestUpdate in changeRequestUpdateRequest.ProfileChangeRequestUpdateList)
                {
                    var changeRequestFilter = Builders<ChangeRequests>.Filter.Eq("_id", ObjectId.Parse(profileChangeRequestUpdate.ChangeRequestId));
                    var changeRequestUpdate = Builders<ChangeRequests>.Update.Set("RequestStatus", profileChangeRequestUpdate.RequestStatus)
                        .Set("FootprintInformation.UpdatedDate", now)
                        .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                    await _changeRequests.UpdateOneAsync(changeRequestFilter, changeRequestUpdate);

                    if (!string.Equals(ChangeRequestRequestType.NewProfile, profileChangeRequestUpdate.RequestType, StringComparison.OrdinalIgnoreCase))
                    {
                        profileIdList.Add(profileChangeRequestUpdate.ProfileId);
                        UpdateDefinition<BsonDocument> profileUpdate;
                        var profileFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(profileChangeRequestUpdate.ProfileId));
                        if (string.Equals(ChangeRequestStatus.Removed, profileChangeRequestUpdate.RequestStatus, StringComparison.OrdinalIgnoreCase))
                        {
                            profileUpdate = Builders<BsonDocument>.Update.Unset("RequestStatus")
                                .Unset("RequestType")
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);

                            await _iProfilesCollection.UpdateOneAsync(profileFilter, profileUpdate);
                        }
                        /*else if (string.Equals(ChangeRequestRequestType.ModifyUsers, profileChangeRequestUpdate.RequestType, StringComparison.OrdinalIgnoreCase) &&
                            string.Equals(ChangeRequestStatus.Loaded, profileChangeRequestUpdate.RequestStatus, StringComparison.OrdinalIgnoreCase))
                        {
                            ProfileNotificationUsersUpdateRequest profileNotificationUsersUpdateRequest = new ProfileNotificationUsersUpdateRequest();
                            profileNotificationUsersUpdateRequest.UserIdList = profileChangeRequestUpdate.NotificationUsers.Select(u => u.UserID).ToList();
                            profileNotificationUsersUpdateRequest.ProfileId = profileChangeRequestUpdate.ProfileId;
                            profileNotificationUsersUpdateRequest.UpdatedBy = changeRequestUpdateRequest.UpdatedBy;

                            await SetNotificationUsersByProfileId(profileNotificationUsersUpdateRequest, ObjectId.Parse(profileChangeRequestUpdate.ProfileId));
                        }*/
                        else
                        {
                            profileUpdate = Builders<BsonDocument>.Update.Set("RequestStatus", profileChangeRequestUpdate.RequestStatus)
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);

                            await _iProfilesCollection.UpdateOneAsync(profileFilter, profileUpdate);
                        }

                    }
                }
            }

            if (changeRequestUpdateRequest.ProfiledSeriesChangeRequestUpdateList != null && changeRequestUpdateRequest.ProfiledSeriesChangeRequestUpdateList.Count > 0)
            {
                foreach (var profiledSeriesChangeRequestUpdate in changeRequestUpdateRequest.ProfiledSeriesChangeRequestUpdateList)
                {
                    var changeRequestFilter = Builders<ChangeRequests>.Filter.Eq("_id", ObjectId.Parse(profiledSeriesChangeRequestUpdate.ChangeRequestId));
                    var changeReqestUpdate = Builders<ChangeRequests>.Update.Set("RequestStatus", profiledSeriesChangeRequestUpdate.RequestStatus)
                        .Set("FootprintInformation.UpdatedDate", now)
                        .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                    await _changeRequests.UpdateOneAsync(changeRequestFilter, changeReqestUpdate);
                    if (!string.Equals(ChangeRequestRequestType.AddSeries, profiledSeriesChangeRequestUpdate.RequestType, StringComparison.OrdinalIgnoreCase))
                    {
                        profiledSeriesIdList.Add(profiledSeriesChangeRequestUpdate.ProfiledSeriesId);
                        UpdateDefinition<BsonDocument> profiledSeriesUpdate;
                        var profiledSeriesFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(profiledSeriesChangeRequestUpdate.ProfiledSeriesId));
                        if (string.Equals(ChangeRequestStatus.Removed, profiledSeriesChangeRequestUpdate.RequestStatus, StringComparison.OrdinalIgnoreCase))
                        {
                            profiledSeriesUpdate = Builders<BsonDocument>.Update.Unset("RequestStatus")
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                        }
                        else
                        {
                            profiledSeriesUpdate = Builders<BsonDocument>.Update.Set("RequestStatus", profiledSeriesChangeRequestUpdate.RequestStatus)
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                        }
                        await _profiledSeries.UpdateOneAsync(profiledSeriesFilter, profiledSeriesUpdate);
                    }
                }
            }

            //var azureSearchQueueItemList = getAzureSearchQueueItemFromList(profileIdList, "Profiles", "Upsert", changeRequestUpdateRequest.UpdatedBy);
            var azureSearchQueueItemList = getAzureSearchQueueItemFromList(profiledSeriesIdList, "ProfiledSeries", "Upsert", changeRequestUpdateRequest.UpdatedBy);
            if (azureSearchQueueItemList.Any())
            {
                await InsertAzureSearchQueueItems(azureSearchQueueItemList);
            }

            return result;
        }

        public async Task<NoSqlServiceResult<ChangeRequestFilterDataResponse>> GetPendingModifications(ChangeRequestFilterDataRequest changeRequestFilterDataRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ChangeRequestFilterDataResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidateChangeRequestFilterDataRequest(changeRequestFilterDataRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetchangeRequestFilterList(changeRequestFilterDataRequest, profileObjectId);

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ChangeRequestFilterDataResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetPendingModifcations - ChangeRequestFilterDataRequest");
            }
            return noSqlServiceResult;
        }


        private async Task<ChangeRequestFilterDataResponse> GetchangeRequestFilterList(ChangeRequestFilterDataRequest changeRequestFilterDataRequest, ObjectId profileObjectId)
        {


            var ProfiledSeriesChangeRequestList = new List<ChangeRequests>();
            var ChangeRequestFilterDataResponse = new ChangeRequestFilterDataResponse();
            var ProfiledSeriesChangeRequestDetailsList = new List<ProfiledSeriesChangeRequestDetails>();

            var filter = GetChangeRequestFilter(changeRequestFilterDataRequest, profileObjectId);
          
            var response = await GetProfiledSeriesChangeRequests(filter);
            ProfiledSeriesChangeRequestList = response.ItemList;

            foreach (ChangeRequests changeRequest in ProfiledSeriesChangeRequestList)
            {
                ProfiledSeriesChangeRequestDetailsList.Add(GetprofiledSeriesChangeRequestDetailsFromChangeRequest(changeRequest));
            }

            var skipDocs = (changeRequestFilterDataRequest.PageNumber - 1) * changeRequestFilterDataRequest.PageSize;

            if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.SeriesName)
            {
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.Name).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList() :
                    ProfiledSeriesChangeRequestDetailsList.Where(p => p.Name.IndexOf(changeRequestFilterDataRequest.SearchKeyword, StringComparison.OrdinalIgnoreCase) >= 0).Select(p => p.Name).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            else if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.SeriesID)
            {
                // seriesID - use contains, as it's number instead of "indexOf"
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.SeriesID).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList():
                    ProfiledSeriesChangeRequestDetailsList.Where(p => p.SeriesID.Contains(changeRequestFilterDataRequest.SearchKeyword)).Select(p => p.SeriesID).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            else if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.RequestedBy)
            {
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.FootprintInformation.CreatedBy).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList():
                    ProfiledSeriesChangeRequestDetailsList.Where(p => p.FootprintInformation.CreatedBy.IndexOf(changeRequestFilterDataRequest.SearchKeyword, StringComparison.OrdinalIgnoreCase) >= 0).Select(p => p.FootprintInformation.CreatedBy).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            else if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.Frequency)
            {
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.Cycle).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList():
                    ProfiledSeriesChangeRequestDetailsList.Where(p => p.Cycle.IndexOf(changeRequestFilterDataRequest.SearchKeyword, StringComparison.OrdinalIgnoreCase) >= 0).Select(p => p.Cycle).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            else if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.ProfileName)
            {
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.ProfileName).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList():
                    ProfiledSeriesChangeRequestDetailsList.Where(p => p.ProfileName.IndexOf(changeRequestFilterDataRequest.SearchKeyword, StringComparison.OrdinalIgnoreCase) >= 0).Select(p => p.ProfileName).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            else if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.AccountNumber)
            {
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.AccountNumber).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList() :
                     ProfiledSeriesChangeRequestDetailsList.Where(p => p.AccountNumber.IndexOf(changeRequestFilterDataRequest.SearchKeyword, StringComparison.OrdinalIgnoreCase) >= 0).Select(p => p.AccountNumber).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            else if (changeRequestFilterDataRequest.FilterType == Common.Constants.PendingModificationFilerType.RequestStatus)
            {
                ChangeRequestFilterDataResponse.DataList = string.IsNullOrEmpty(changeRequestFilterDataRequest.SearchKeyword) ?
                    ProfiledSeriesChangeRequestDetailsList.Select(p => p.RequestStatus).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList() :
                     ProfiledSeriesChangeRequestDetailsList.Where(p => p.RequestStatus.IndexOf(changeRequestFilterDataRequest.SearchKeyword, StringComparison.OrdinalIgnoreCase) >= 0).Select(p => p.RequestStatus).Distinct().OrderBy(p => p).Skip(skipDocs).Take(changeRequestFilterDataRequest.PageSize).ToList();
            }
            return ChangeRequestFilterDataResponse;
        }

        
        private List<AzureSearchQueueItem> getAzureSearchQueueItemFromList(List<string> profileSeriesIds, string collectionName, string changeType, string requestedBy)
        {
            var azureSearchQueueItemList = new List<AzureSearchQueueItem>();
            var footprintInformation = new FootprintInformation();
            var now = DateTime.Now;
            footprintInformation.CreatedBy = requestedBy;
            footprintInformation.CreatedDate = now;
            footprintInformation.UpdatedBy = requestedBy;
            footprintInformation.UpdatedDate = now;
            foreach (var profileId in profileSeriesIds)
            {
                var azureSearchQueueItem = new AzureSearchQueueItem();

                azureSearchQueueItem.ObjectId = ObjectId.Parse(profileId);
                azureSearchQueueItem.ChangeType = changeType;
                azureSearchQueueItem.CollectionName = collectionName;
                azureSearchQueueItem.Priority = AppSettings.AzureSearchQueuePriority;
                azureSearchQueueItem.InProcessState = 0;
                azureSearchQueueItem.IsRealTime = true;
                azureSearchQueueItem.FootprintInformation = footprintInformation;
                azureSearchQueueItemList.Add(azureSearchQueueItem);
            }
            return azureSearchQueueItemList;
        }

        private async Task InsertAzureSearchQueueItems(List<AzureSearchQueueItem> azureSearchQueueItemList)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    await _azureSearchQueue.InsertManyAsync(azureSearchQueueItemList);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

        }

        internal async Task<NoSqlServiceResult<bool>> SaveBatchExportToBackground(BatchExportBackgroundRequest batchExportBackgroundRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidateSaveBatchExportToBackgroundRequest(batchExportBackgroundRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }

                var batchExportbackgroundQueueItem = GetBackgroundQueueItemFromBatchExportRequest(batchExportBackgroundRequest, profileObjectId);
                await InsertBackgroundQueueItem(batchExportbackgroundQueueItem);

            }
            catch (Exception exception)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "SeriesService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", batchExportBackgroundRequest.ProfileId,
                    exception.Message, exception.StackTrace));
            }
            return noSqlServiceResult;
        }

        private string ValidateSaveBatchExportToBackgroundRequest(BatchExportBackgroundRequest batchExportBackgroundRequest, out ObjectId profileObjectId)
        {
            profileObjectId = new ObjectId();

            if (string.IsNullOrEmpty(batchExportBackgroundRequest.ProfileId) && string.IsNullOrEmpty(batchExportBackgroundRequest.OrganizationId))
            {
                return "Profile Id or Organization Id is required";
            }

            if (batchExportBackgroundRequest.OrganziationName == null)
            {
                return "OrganziationName is required";
            }

            if (batchExportBackgroundRequest.AccountNumber == null)
            {
                return "AccountNumber is required";
            }

            if (!string.IsNullOrEmpty(batchExportBackgroundRequest.ProfileId) && batchExportBackgroundRequest.ProfileName == null)
            {
                return "ProfileName is required";
            }

            if (batchExportBackgroundRequest.SubmittedByUserName == null)
            {
                return "Submitted By User Name is required";
            }

            if (!string.IsNullOrEmpty(batchExportBackgroundRequest.ProfileId) && !ObjectId.TryParse(batchExportBackgroundRequest.ProfileId, out profileObjectId))
            {
                return "Invalid Profile Id";
            }
            return null;
        }

        private BackgroundQueue GetBackgroundQueueItemFromBatchExportRequest(BatchExportBackgroundRequest batchExportBackgroundRequest, ObjectId profileObjectId)
        {
            var now = DateTime.Now;
            var backgroundQueueItem = new BackgroundQueue();
            var emailSettings = new EmailSettings();
            var emailElements = new EmailElements();
            var footprintInformation = new FootprintInformation();

            emailSettings.Subject = string.Format("TSSO – Batch Export – {0} – {1}", batchExportBackgroundRequest.OrganziationName, batchExportBackgroundRequest.ProfileName);
            emailSettings.To = AppSettings.BatchExportRequestEmailTo;

            if (!profileObjectId.Equals(ObjectId.Empty))
                emailElements.ProfileID = profileObjectId;

            if (!string.IsNullOrEmpty(batchExportBackgroundRequest.OrganizationId))
                emailElements.OrganizationID = batchExportBackgroundRequest.OrganizationId;

            emailElements.AccountNumber = batchExportBackgroundRequest.AccountNumber;
            emailElements.OrganizationName = batchExportBackgroundRequest.OrganziationName;
            emailElements.ProfileName = batchExportBackgroundRequest.ProfileName;
            emailSettings.EmailElements = emailElements;

            footprintInformation.CreatedBy = batchExportBackgroundRequest.SubmittedByUserName;
            footprintInformation.CreatedDate = now;
            footprintInformation.UpdatedBy = batchExportBackgroundRequest.SubmittedByUserName;
            footprintInformation.UpdatedDate = now;

            backgroundQueueItem.EmailSettings = emailSettings;
            backgroundQueueItem.JobType = "BatchExport";
            backgroundQueueItem.Priority = AppSettings.BackgroundQueuePriority;
            backgroundQueueItem.InProcessState = "New";
            backgroundQueueItem.FootprintInformation = footprintInformation;

            return backgroundQueueItem;
        }

        private async Task InsertBackgroundQueueItem(BackgroundQueue backgroundQueueItem)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    await _backgroundQueue.InsertOneAsync(backgroundQueueItem);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }
        public async Task<NoSqlServiceResult<BatchExportRealtimeResponse>> RequestStatusBatchExport(BatchExportRequest batchExportRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<BatchExportRealtimeResponse> { Status = NoSqlServiceStatus.Success };

            try
            {
                ObjectId profiledObjectId = new ObjectId();

                if (string.IsNullOrEmpty(batchExportRequest.ProfileId) && string.IsNullOrEmpty(batchExportRequest.OrganizationId))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = "Profile Id or Organization Id is required"; ;
                    return noSqlServiceResult;
                }

                if (!string.IsNullOrEmpty(batchExportRequest.ProfileId) && !ObjectId.TryParse(batchExportRequest.ProfileId, out profiledObjectId))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = "Invalid Profile Id";
                    return noSqlServiceResult;
                }

                ChangeRequestManager changeRequestManager = new ChangeRequestManager();
                //noSqlServiceResult.Data = await changeRequestManager.RequestStatusBatchExport(_changeRequests, profiledObjectId, batchExportRequest.SubmittedByUserName, batchExportRequest.SubmittedByUserId, AppSettings.RetryWaitTime, AppSettings.MaxConnectionRetries);
                BatchExportResponse ber = await changeRequestManager.RequestStatusBatchExport(_changeRequests, batchExportRequest.OrganizationId, profiledObjectId, batchExportRequest.SubmittedByUserName, batchExportRequest.SubmittedByUserId, AppSettings.RetryWaitTime, AppSettings.MaxConnectionRetries);

                noSqlServiceResult.Data = changeRequestManager.GenerateBatchExportRealtimeFile(batchExportRequest.OrganizationId, ber, batchExportRequest.SubmittedByUserName);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new BatchExportRealtimeResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "RequestStatusBatchExport");
            }
            return noSqlServiceResult;
        }

        private string MapFormatPreferenceAbbr(string original)
        {
            string strAbbr = original;

            switch (original)
            {
                case "Hardcover":
                    strAbbr = "HRD";
                    break;
                case "Library":
                    strAbbr = "LIB";
                    break;
                case "Paperback":
                    strAbbr = "PAP";
                    break;
                case "Abridged":
                    strAbbr = "ABR";
                    break;
                case "Unabridged":
                    strAbbr = "UNABR";
                    break;
                default:
                    strAbbr = original;
                    break;
            }
            return strAbbr;
        }

        private string ReplaceFormatPreferenceAbbr(string original)
        {
            bool isValidString = (!string.IsNullOrEmpty(original) && original != "null");

            if (!isValidString)
                return original;

            bool hasSplitChar = original.Contains(',');

            if (!hasSplitChar)
                return original;
         
            string strAbbr = original.Replace("Hardcover", "HRD").Replace("Library", "LIB").Replace("Paperback", "PAP").Replace("Abridged", "ABR").Replace("Unabridged", "UNABR");
            
         
            return strAbbr;
        }
    }
}
