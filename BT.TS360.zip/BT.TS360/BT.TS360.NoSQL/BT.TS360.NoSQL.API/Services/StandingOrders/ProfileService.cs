﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;
using System.Threading;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using BT.TS360.NoSQL.Data.AzureSearch;

using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using BT.TS360.NoSQL.Data.Common.Helper;

namespace BT.TS360.NoSQL.API.Services.StandingOrders
{
    public class ProfileService : IProfileService
    {
        readonly IMongoCollection<BsonDocument> _iProfilesCollection;
        readonly IMongoCollection<BsonDocument> _iChangeRequestsCollection;
        readonly IMongoCollection<BsonDocument> _iProfiledSeriesCollection;
        readonly IMongoCollection<ChangeRequests> _changeRequests;
        readonly IMongoCollection<AzureSearchQueueItem> _azureSearchQueue;
        readonly IMongoCollection<BackgroundQueue> _backgroundQueue;
        readonly SearchServiceClient _serviceClient;
        readonly ISearchIndexClient _profilesIndexClient;
        readonly AzureSearchQueueHelper azureSearchQueueHelper;
        readonly IMongoCollection<BsonDocument> _iCustomerAccountRepCollection;

        public ProfileService()
        {
            var client = new MongoClient(ConnectionString);
            var iDatabase = client.GetDatabase(CommonConstants.StandingOrdersDatabaseName);
            var iCommonDatabase = client.GetDatabase(CommonConstants.CommonDatabaseName);

            _iProfilesCollection = iDatabase.GetCollection<BsonDocument>(CommonConstants.ProfilesCollectionName);
            _iChangeRequestsCollection = iDatabase.GetCollection<BsonDocument>(CommonConstants.ChangeRequestsCollectionName);
            _iProfiledSeriesCollection = iDatabase.GetCollection<BsonDocument>(CommonConstants.ProfiledSeriesCollectionName);
            _changeRequests = iDatabase.GetCollection<ChangeRequests>(CommonConstants.ChangeRequestsCollectionName);
            _azureSearchQueue = iCommonDatabase.GetCollection<AzureSearchQueueItem>(CommonConstants.AzureSearchQueueCollectionName);
            _backgroundQueue = iCommonDatabase.GetCollection<BackgroundQueue>(CommonConstants.BackgroundQueueCollectionName);
            _iCustomerAccountRepCollection = iDatabase.GetCollection<BsonDocument>(CommonConstants.CustomerAccountRepCollectionName);

            string searchServiceName = AppSettings.SearchServiceName;

            string apiKey = AppSettings.SearchServiceQueryApiKey;

            _serviceClient = new SearchServiceClient(AppSettings.SearchServiceName, new SearchCredentials(AppSettings.SearchServiceQueryApiKey));

            _profilesIndexClient = _serviceClient.Indexes.GetClient(AppSettings.ProfilesIndexName);
            azureSearchQueueHelper = new AzureSearchQueueHelper(ConnectionString, AppSettings.RetryWaitTime, AppSettings.MaxConnectionRetries);
        }

        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }

        public async Task<NoSqlServiceResult<ProfilesResponse>> GetProfiles(SearchProfilesRequest profilesRequest)
        {
            var response = new ProfilesResponse();

            var skipDocs = (profilesRequest.PageNumber - 1) * profilesRequest.PageSize;

            var sort = Builders<BsonDocument>.Sort.Ascending(profilesRequest.SortBy);
            if (profilesRequest.SortDirection.ToLower() == "desc")
            {
                sort = Builders<BsonDocument>.Sort.Descending(profilesRequest.SortBy);
            }

            var filter = Builders<BsonDocument>.Filter.Eq("OrganizationID", profilesRequest.OrgId);

            var profiles = await _iProfilesCollection.Find(filter).Skip(skipDocs).Limit(profilesRequest.PageSize).Sort(sort).ToListAsync();
            var totalDocs = await _iProfilesCollection.CountAsync(filter);

            var profilesResponse = new List<ProfileDetailsResponse>();

            foreach (var profileBsonDoc in profiles)
            {
                var pro = ConvertProfileBsonToProfileResponse(profileBsonDoc);

                profilesResponse.Add(pro);
            }

            response.Profiles = profilesResponse;
            response.TotalItems = totalDocs;

            return new NoSqlServiceResult<ProfilesResponse> { Data = response, Status = NoSqlServiceStatus.Success };
        }

        public async Task<NoSqlServiceResult<ProfilesResponse>> GetProfilesBySearch(SearchProfilesRequest profilesRequest)
        {
            var response = new ProfilesResponse();

            try
            {
                var keywordValue = profilesRequest.KeywordValue;
                if (!string.IsNullOrEmpty(keywordValue))
                {
                    keywordValue = CommonHelper.RemoveSpecialCharacters(keywordValue);
                }
                if (string.Equals(profilesRequest.KeywordType, "SeriesIDList", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(keywordValue))
                {
                    keywordValue = keywordValue.TrimStart('0');
                }
                var searchText = string.IsNullOrEmpty(keywordValue) ? "*" : "/.*" + keywordValue + ".*/";
                var searchParameters = GetProfileSearchParameters(profilesRequest);
                var profilesResponse = new List<ProfileDetailsResponse>();

                if (!AppSettings.AzureSearchValidateServerCertificate)
                {
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                }

                DocumentSearchResult<ProfilesSearchResultItem> searchResponse = await _profilesIndexClient.Documents.SearchAsync<ProfilesSearchResultItem>(searchText, searchParameters);

                if (searchResponse != null)
                {
                    foreach (var result in searchResponse.Results)
                    {
                        var profile = ConvertProfilesSearchResultItemToProfileResponse(result.Document);
                        profilesResponse.Add(profile);
                    }

                    response.Facets = searchResponse.Facets;
                    response.Profiles = profilesResponse;
                    response.TotalItems = searchResponse.Count.HasValue ? searchResponse.Count.Value : 0;
                }
            }
            catch (Exception ex)
            {
                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetProfilesBySearch", "");

                return new NoSqlServiceResult<ProfilesResponse> { Data = response, Status = NoSqlServiceStatus.Fail };
            }

            return new NoSqlServiceResult<ProfilesResponse> { Data = response, Status = NoSqlServiceStatus.Success };
        }

        private SearchParameters GetProfileSearchParameters(SearchProfilesRequest profilesRequest)
        {
            var searchParameters = new SearchParameters();

            if (!string.IsNullOrEmpty(profilesRequest.KeywordValue))
            {
                searchParameters.SearchFields = new string[] { profilesRequest.KeywordType };
            }
            searchParameters.SearchMode = SearchMode.All;
            searchParameters.QueryType = QueryType.Full;
            searchParameters.IncludeTotalResultCount = true;
            searchParameters.Filter = GetProfileSearchFilter(profilesRequest);
            searchParameters.OrderBy = new string[] { "Status asc", profilesRequest.SortBy + " " + profilesRequest.SortDirection.ToLower() };
            searchParameters.Top = profilesRequest.PageSize;
            searchParameters.Skip = (profilesRequest.PageNumber - 1) * profilesRequest.PageSize;
            searchParameters.Facets = new List<string> { "RequestType", "Status", "UpdatedDateRange,sort:-value" };

            return searchParameters;

        }

        private string GetProfileSearchFilter(SearchProfilesRequest profilesRequest)
        {
            var filter = "OrganizationID eq '" + profilesRequest.OrgId + "'";
            filter += GetProfileSearchFacetsFilter(profilesRequest.Facets);
            filter += GetProfileSearchProfileFilter(profilesRequest);
            return filter;
        }

        private string GetProfileSearchProfileFilter(SearchProfilesRequest profilesRequest)
        {
            var filter = string.Empty;
            if (!string.IsNullOrEmpty(profilesRequest.SpecificProgramId) && !string.Equals("All Programs", profilesRequest.SpecificProgramId, StringComparison.OrdinalIgnoreCase))
            {
                filter = " and Programs/any(t: t eq '" + profilesRequest.SpecificProgramId + "')";
            }
            return filter;
        }

        private string GetProfileSearchFacetsFilter(List<ProfileFacet> facets)
        {
            var filter = string.Empty;
            if (facets != null && facets.Any())
            {
                foreach (var facet in facets)
                {
                    if (string.Equals("UpdatedDateRange", facet.FacetId, StringComparison.OrdinalIgnoreCase))
                    {
                        filter += " and " + facet.FacetId + "/any(t: t eq '" + facet.FacetValue + "')";
                    }
                    else
                    {
                        filter += " and " + facet.FacetId + " eq '" + facet.FacetValue + "'";
                    }

                }
            }
            return filter;
        }



        private ProfileDetailsResponse ConvertProfilesSearchResultItemToProfileResponse(ProfilesSearchResultItem profilesSearchResultItem)
        {
            if (profilesSearchResultItem == null) return null;

            var pro = new ProfileDetailsResponse
            {
                ProfileId = profilesSearchResultItem.ObjectId,
                Name = profilesSearchResultItem.Name,
                ProfileType = profilesSearchResultItem.ProfileType,
                AccountType = profilesSearchResultItem.AccountType,
                San = profilesSearchResultItem.SAN,
                Notes = profilesSearchResultItem.Notes
            };

            pro.PendingRequestType = profilesSearchResultItem.RequestType ?? string.Empty;
            pro.PendingStatus = profilesSearchResultItem.RequestStatus ?? string.Empty;
            pro.Status = profilesSearchResultItem.Status;

            pro.AccountNumber = "";
            if (!string.IsNullOrEmpty(profilesSearchResultItem.CompassAccountNumber))
            {
                pro.AccountNumber = profilesSearchResultItem.CompassAccountNumber;
            }
            else if (!string.IsNullOrEmpty(profilesSearchResultItem.ShippingAccountNumber))
            {
                pro.AccountNumber = profilesSearchResultItem.ShippingAccountNumber;
            }

            pro.AccountId = profilesSearchResultItem.ShippingAccountID;
            var arrPro = profilesSearchResultItem.Programs;
            if (arrPro != null)
            {
                pro.Programs = arrPro;
                pro.ProgramName = string.Join(", ", arrPro.ToList());
            }

            pro.TotalCopies = profilesSearchResultItem.TotalCopies ?? 0;
            pro.TotalSeries = profilesSearchResultItem.TotalSeries ?? 0;

            pro.PrimaryContactName = profilesSearchResultItem.PrimaryContact;
            pro.Phone = profilesSearchResultItem.Phone;
            pro.Fax = profilesSearchResultItem.Fax;
            pro.Email = profilesSearchResultItem.eMail;

            pro.Line1 = profilesSearchResultItem.Line1;
            pro.Line2 = profilesSearchResultItem.Line2;
            pro.Line3 = profilesSearchResultItem.Line3;
            pro.City = profilesSearchResultItem.City;
            pro.State = profilesSearchResultItem.State;
            pro.Zipcode = profilesSearchResultItem.Zipcode;

            pro.CreatedBy = profilesSearchResultItem.CreatedBy;
            pro.UpdatedBy = profilesSearchResultItem.UpdatedBy;
            if (profilesSearchResultItem.CreatedDate.HasValue)
            {
                var createdDate = profilesSearchResultItem.CreatedDate.Value;
                pro.CreatedDate = createdDate.DateTime;
            }
            if (profilesSearchResultItem.UpdatedDate.HasValue)
            {
                var updatedDate = profilesSearchResultItem.UpdatedDate.Value;
                pro.UpdatedDate = updatedDate.DateTime;
            }
            pro.NotificationUsers = profilesSearchResultItem.NotificationUsers;

            pro.SalesTerritory = profilesSearchResultItem.SalesTerritory;

            return pro;
        }

        private static ProfileDetailsResponse ConvertProfileBsonToProfileResponse(BsonDocument profileBsonDoc)
        {
            if (profileBsonDoc == null) return null;

            var pro = new ProfileDetailsResponse
            {
                ProfileId = profileBsonDoc["_id"].ToString(),
                Name = profileBsonDoc["Name"].AsString,
                ProfileType = profileBsonDoc["ProfileType"].AsString,
                AccountType = profileBsonDoc["AccountType"].AsString,
                San = profileBsonDoc["SAN"].AsString,
                Notes = profileBsonDoc["Notes"].AsString
            };

            pro.PendingRequestType = profileBsonDoc.Contains("RequestType") ? profileBsonDoc["RequestType"].AsString : "";
            pro.PendingStatus = profileBsonDoc.Contains("RequestStatus") ? profileBsonDoc["RequestStatus"].AsString : "";
            pro.Status = profileBsonDoc.Contains("Status") ? profileBsonDoc["Status"].AsString : "";

            pro.AccountNumber = "";
            if (profileBsonDoc.Contains("CompassAccountNumber"))
            {
                pro.AccountNumber = profileBsonDoc["CompassAccountNumber"].AsString;
            }
            else if (profileBsonDoc.Contains("ERPAccountNumber"))
            {
                pro.AccountNumber = profileBsonDoc["ERPAccountNumber"].AsString;
            }
            if (profileBsonDoc.Contains("ShippingAccountID"))
            {
                pro.AccountId = profileBsonDoc["ShippingAccountID"].AsString;
            }
            var arrPro = profileBsonDoc["Programs"] as BsonArray;
            if (arrPro != null)
            {
                pro.ProgramName = string.Join(", ", arrPro.ToList());
            }

            pro.TotalCopies = 0;
            pro.TotalSeries = 0;
            if (profileBsonDoc.Contains("SummaryInformation"))
            {
                var summaryInformation = BsonSerializer.Deserialize<SummaryInformation>(profileBsonDoc["SummaryInformation"].ToJson());

                if (summaryInformation != null)
                {
                    pro.TotalCopies = summaryInformation.TotalCopies ?? 0;
                    pro.TotalSeries = summaryInformation.TotalSeries ?? 0;
                }
            }

            if (profileBsonDoc.Contains("ContactInformation"))
            {
                var contactInformation = BsonSerializer.Deserialize<ContactInformation>(profileBsonDoc["ContactInformation"].ToJson());

                if (contactInformation != null)
                {
                    pro.PrimaryContactName = contactInformation.PrimaryContact;
                    pro.Phone = contactInformation.Phone;
                    pro.Fax = contactInformation.Fax;
                    pro.Email = contactInformation.eMail;
                }
            }

            if (profileBsonDoc.Contains("AddressInformation"))
            {
                var addressInformation = BsonSerializer.Deserialize<AddressInformation>(profileBsonDoc["AddressInformation"].ToJson());

                if (addressInformation != null)
                {
                    pro.Line1 = addressInformation.Line1;
                    pro.Line2 = addressInformation.Line2;
                    pro.Line3 = addressInformation.Line3;
                    pro.City = addressInformation.City;
                    pro.State = addressInformation.State;
                    pro.Zipcode = addressInformation.Zipcode;
                }
            }

            if (profileBsonDoc.Contains("FootprintInformation"))
            {
                var footprintInformation = BsonSerializer.Deserialize<FootprintInformation>(profileBsonDoc["FootprintInformation"].ToJson());

                if (footprintInformation != null)
                {
                    pro.CreatedBy = footprintInformation.CreatedBy;
                    pro.UpdatedBy = footprintInformation.UpdatedBy;
                    pro.CreatedDate = footprintInformation.CreatedDate;
                    pro.UpdatedDate = footprintInformation.UpdatedDate;
                }
            }
            if (profileBsonDoc.Contains("NotificationUsers"))
            {
                pro.NotificationUsers = BsonSerializer.Deserialize<List<string>>(profileBsonDoc["NotificationUsers"].ToJson());
            }
            if (profileBsonDoc.Contains("SalesTerritory"))
            {
                pro.SalesTerritory = profileBsonDoc["SalesTerritory"].AsString;
            }

            return pro;
        }

        public async Task<NoSqlServiceResult<ProfileDetailsResponse>> GetProfileById(string profileId)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(profileId));

            var results = await _iProfilesCollection.Find(filter).Limit(1).ToListAsync();

            ProfileDetailsResponse profileDetailsResponse = (ConvertProfileBsonToProfileResponse(results[0]));


            if (!string.IsNullOrEmpty(profileDetailsResponse.SalesTerritory))
            {
                var salesfilter = Builders<BsonDocument>.Filter.Eq("SalesTerritory", profileDetailsResponse.SalesTerritory.Trim());
                var salesResult = await _iCustomerAccountRepCollection.Find(salesfilter).Limit(1).ToListAsync();

                if (salesResult.Count > 0)
                {
                    var customerAccountRep = new CustomerAccountRep
                    {
                        SalesName = salesResult[0]["SalesName"].ToString(),
                        SalesPhone = salesResult[0]["SalesPhone"].ToString(),
                        SalesEmail = salesResult[0]["SalesEmail"].ToString()
                    };

                    profileDetailsResponse.SalesName = customerAccountRep.SalesName;
                    profileDetailsResponse.SalesPhone = customerAccountRep.SalesPhone;
                    profileDetailsResponse.SalesEmail = customerAccountRep.SalesEmail;
                }
            }
            var response = new NoSqlServiceResult<ProfileDetailsResponse>
            {
                Data = profileDetailsResponse,
                Status = NoSqlServiceStatus.Success
            };
            return response;
        }

        public async Task<NoSqlServiceResult<bool>> UpdateProfile(ProfileRequest profile)
        {
            var response = new NoSqlServiceResult<bool> { Data = true, Status = NoSqlServiceStatus.Success };
            try
            {
                var filter = Builders<BsonDocument>.Filter.Eq("_id", new ObjectId(profile.ProfileId));

                var update = Builders<BsonDocument>.Update.Set("Name", profile.ProfileName);

                var contactInfo = new BsonDocument
                                  {
                                      {"PrimaryContact", profile.ContactName},
                                      {"Phone", profile.Phone ?? ""},
                                      {"Fax", profile.Fax ?? ""},
                                      {"eMail", profile.Email}
                                  };

                update.Set("ContactInformation", contactInfo);

                var footprintInfo = new BsonDocument
                                  {
                                      {"UpdatedBy", profile.TsUserName},
                                      {"UpdatedDate", new BsonDateTime(DateTime.Now)},
                                      {"CreatedBy", profile.CreatedBy},
                                      {"CreatedDate", profile.CreatedDate}
                                  };

                update.Set("FootPrintInformation", footprintInfo);

                await _iProfilesCollection.UpdateOneAsync(filter, update);
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ProfileService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", profile.ToJson(),
                    exception.Message, exception.StackTrace));
            }

            return response;
        }

        public async Task<NoSqlServiceResult<bool>> CreateProfile(ProfileRequest newProfileRequest)
        {
            var response = new NoSqlServiceResult<bool> { Data = true, Status = NoSqlServiceStatus.Success };

            try
            {
                EmailNewProfileRequest(newProfileRequest);
            }
            catch (Exception exception)
            {
                response.Status = NoSqlServiceStatus.Fail;
                response.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ProfileService.CreateProfile", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", newProfileRequest.ToJson(),
                    exception.Message, exception.StackTrace));
            }

            return response;
        }

        private void EmailNewProfileRequest(ProfileRequest newProfileRequest)
        {
            MailMessage mail = new MailMessage();
            SmtpClient client = new SmtpClient();
            var emailToList = AppSettings.ProfileRequestEmailTo.Split(';');
            foreach (var emailTo in emailToList)
            {
                if (!string.IsNullOrEmpty(emailTo))
                    mail.To.Add(emailTo);
            }
            mail.Subject = AppSettings.StandingOrdersEmailPrefix + "New Profile Requested";
            mail.Body = GetNewProfileChangeRequestEmailBody(newProfileRequest);
            mail.IsBodyHtml = true;

            client.Send(mail);
        }

        public NoSqlServiceResult<List<AreaResponse>> GetAreas()
        {
            // dummy data
            var result = new List<AreaResponse>();

            var area = new AreaResponse
            {
                AreaId = "adult_fiction_series",
                AreaName = "Adult Fiction Series",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_fiction_series_fiction",
                AreaName = "Fiction",
                ParentAreaId = "adult_fiction_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_fiction_series_fiction_romance",
                AreaName = "Fiction - Romance",
                ParentAreaId = "adult_fiction_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_fiction_series_fiction_science_fiction",
                AreaName = "Fiction - Science Fiction",
                ParentAreaId = "adult_fiction_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "awards",
                AreaName = "Awards",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "awards_awards",
                AreaName = "Awards",
                ParentAreaId = "awards",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "popular_author",
                AreaName = "Popular Authors",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "popular_author_inspirational_authors",
                AreaName = "Inspirational Authors",
                ParentAreaId = "popular_author",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "popular_author_large_print_authors",
                AreaName = "Large Print Authors",
                ParentAreaId = "popular_author",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "popular_author_popular_authors",
                AreaName = "Popular Authors",
                ParentAreaId = "popular_author",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "popular_author_spoken_word_audio_authors",
                AreaName = "Spoken Word Audio Authors",
                ParentAreaId = "popular_author",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series",
                AreaName = "Adult Series",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_agricultural_and_veterinary_sciences",
                AreaName = "Agricultural and Veterinary Sciences",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_american_studies",
                AreaName = "American Studies (United States and Canada)",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_anthropology",
                AreaName = "Anthropology",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_antiques_collectibles",
                AreaName = "Antiques & Collectibles",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_archaeology",
                AreaName = "Archaeology",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_architecture",
                AreaName = "Architecture",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_area_studies",
                AreaName = "Area Studies",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_art",
                AreaName = "Art",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_automotive",
                AreaName = "Automotive",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "adult_series_bibliographies_general",
                AreaName = "Bibliographies General",
                ParentAreaId = "adult_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "children_series",
                AreaName = "Children's Series",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "children_series_children_fiction",
                AreaName = "Children's Fiction",
                ParentAreaId = "children_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "children_series_children_non_fiction",
                AreaName = "Children's Non-Fiction",
                ParentAreaId = "children_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "children_series_easy_readers",
                AreaName = "Easy Readers",
                ParentAreaId = "children_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "children_series_picture_books",
                AreaName = "Picture Books",
                ParentAreaId = "children_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "graphic_novels",
                AreaName = "Graphic Novels",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "graphic_novels_graphic_novels",
                AreaName = "Graphic Novels",
                ParentAreaId = "graphic_novels",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "teen_series",
                AreaName = "Teen Series",
                ParentAreaId = "",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "teen_series_teen_fiction",
                AreaName = "Teen Fiction",
                ParentAreaId = "teen_series",
                ParentAreaName = ""
            };
            result.Add(area);

            area = new AreaResponse
            {
                AreaId = "teen_series_teen_notification",
                AreaName = "Teen Notification",
                ParentAreaId = "teen_series",
                ParentAreaName = ""
            };
            result.Add(area);

            var response = new NoSqlServiceResult<List<AreaResponse>> { Data = result, Status = NoSqlServiceStatus.Success };
            return response;

            //TODO: call to Mongo DB for real data
        }

        public async Task<NoSqlServiceResult<ProfileListResponse>> GetProfileListByOrg(string organizationId)
        {
            var noSqlServiceResult = new NoSqlServiceResult<ProfileListResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                if (string.IsNullOrEmpty(organizationId))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = "Organization Id Required.";
                    return noSqlServiceResult;
                }
                noSqlServiceResult.Data = await GetProfileListData(organizationId);

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new ProfileListResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetProfileListByOrg");
            }
            return noSqlServiceResult;
        }

        private async Task<ProfileListResponse> GetProfileListData(string organizationId)
        {
            var profileListResponse = new ProfileListResponse();
            var profileDetailsResponseList = new List<ProfileListDetails>();

            var filter = Builders<BsonDocument>.Filter.Eq("OrganizationID", organizationId);
            var sort = Builders<BsonDocument>.Sort.Ascending("Name");
            var projection = Builders<BsonDocument>.Projection.Include("Name").Include("ShippingAccountNumber").Include("SalesTerritory").Include("Programs").Include("Status");
            var profileList = await _iProfilesCollection.Find<BsonDocument>(filter).Project(projection).Sort(sort).ToListAsync();

            foreach (BsonDocument profile in profileList)
            {
                profileDetailsResponseList.Add(GetProfileDetailsResponseFromProfile(profile));
            }
            profileListResponse.Profiles = profileDetailsResponseList;
            return profileListResponse;
        }

        private ProfileListDetails GetProfileDetailsResponseFromProfile(BsonDocument profile)
        {
            var ProfileListDetails = new ProfileListDetails();


            if (profile.Contains("_id"))
                ProfileListDetails.ProfileId = profile["_id"].AsObjectId.ToString();

            if (profile.Contains("Name"))
                ProfileListDetails.Name = profile["Name"].AsString;

            if (profile.Contains("ShippingAccountNumber"))
                ProfileListDetails.AccountNumber = profile["ShippingAccountNumber"].AsString;

            if (profile.Contains("Status"))
                ProfileListDetails.Status = profile["Status"].AsString;

            if (profile.Contains("SalesTerritory"))
                ProfileListDetails.SalesTerritory = profile["SalesTerritory"].AsString;

            if (profile.Contains("Programs"))
            {
                var arrProgram = profile["Programs"] as BsonArray;
                if (arrProgram != null)
                {
                    ProfileListDetails.Programs = arrProgram.Select(a => a.AsString).ToList();
                }
            }

            return ProfileListDetails;
        }

        internal NoSqlServiceResult<bool> RequestMasterOrderStatus(MasterOrderStatusRequest masterOrderStatusRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateMasterOrderStatusRequest(masterOrderStatusRequest);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                MailMessage mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                var emailToList = AppSettings.OrderStatusEmailTo.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        mail.To.Add(emailTo);
                }
                mail.Subject = AppSettings.StandingOrdersEmailPrefix + "Order Status Report Request";
                mail.Body = GetMasterOrderStatusEmailBody(masterOrderStatusRequest);
                mail.IsBodyHtml = true;

                client.Send(mail);
            }
            catch (Exception exception)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ProfileService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", masterOrderStatusRequest.ToJson(),
                    exception.Message, exception.StackTrace));
            }
            return noSqlServiceResult;
        }

        private string GetMasterOrderStatusEmailBody(MasterOrderStatusRequest masterOrderStatusRequest)
        {
            string emailBody = string.Empty;
            using (StreamReader reader = new StreamReader(HttpRuntime.AppDomainAppPath + @"Common\EmailTemplates\MasterOrderStatusEmailTemplate.txt"))
            {
                emailBody = reader.ReadToEnd();
            }

            emailBody = emailBody.Replace("{ORGANIZATION_NAME}", masterOrderStatusRequest.OrganizationName);
            emailBody = emailBody.Replace("{ORGANIZATION_PHONE_NUMBER}", masterOrderStatusRequest.OrganizationPhone);
            emailBody = emailBody.Replace("{USER_EMAIL}", masterOrderStatusRequest.UserEmail);
            emailBody = emailBody.Replace("{TS360_LOGIN}", masterOrderStatusRequest.LoginName);

            return emailBody;
        }

        internal NoSqlServiceResult<bool> RequestProfileOrderStatus(ProfileOrderStatusRequest profileOrderStatusRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateProfileOrderStatusRequest(profileOrderStatusRequest);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                MailMessage mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                var emailToList = AppSettings.OrderStatusEmailTo.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        mail.To.Add(emailTo);
                }
                mail.Subject = AppSettings.StandingOrdersEmailPrefix + "Order Status Report Request";
                mail.Body = GetProfileOrderStatusEmailBody(profileOrderStatusRequest);
                mail.IsBodyHtml = true;

                client.Send(mail);
            }
            catch (Exception exception)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ProfileService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", profileOrderStatusRequest.ToJson(),
                    exception.Message, exception.StackTrace));
            }
            return noSqlServiceResult;
        }

        private string GetProfileOrderStatusEmailBody(ProfileOrderStatusRequest profileOrderStatusRequest)
        {
            string emailBody = string.Empty;
            using (StreamReader reader = new StreamReader(HttpRuntime.AppDomainAppPath + @"Common\EmailTemplates\ProfileOrderStatusEmailTemplate.txt"))
            {
                emailBody = reader.ReadToEnd();
            }

            emailBody = emailBody.Replace("{ORGANIZATION_NAME}", profileOrderStatusRequest.OrganizationName);
            emailBody = emailBody.Replace("{ORGANIZATION_PHONE_NUMBER}", profileOrderStatusRequest.OrganizationPhone);
            emailBody = emailBody.Replace("{PROFILE_NAME}", profileOrderStatusRequest.ProfileName);
            emailBody = emailBody.Replace("{ACCOUNT_NUMBER}", profileOrderStatusRequest.AccountNumber);
            emailBody = emailBody.Replace("{USER_EMAIL}", profileOrderStatusRequest.UserEmail);
            emailBody = emailBody.Replace("{TS360_LOGIN}", profileOrderStatusRequest.LoginName);

            return emailBody;
        }

        internal async Task<NoSqlServiceResult<bool>> SetProfileOrganizationId(ProfileShippingAccountRequest profileShippingAccountRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                var error = ValidateProfileShippingAccountRequest(profileShippingAccountRequest);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                var updateProfiledSeriesOrganizationStatus = false;
                var updateProfileOrganizationStatus = await SetProfileOrganizationIdByShippingAccount(profileShippingAccountRequest);
                if (updateProfileOrganizationStatus)
                {
                    updateProfiledSeriesOrganizationStatus = await SetProfiledSeriesOrganizationIdByShippingAccount(profileShippingAccountRequest);
                }

                if (!updateProfiledSeriesOrganizationStatus || !updateProfiledSeriesOrganizationStatus)
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = "Update failed";
                    return noSqlServiceResult;
                }

            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "SetProfileOrganizationId");
            }
            return noSqlServiceResult;
        }

        private async Task<bool> SetProfiledSeriesOrganizationIdByShippingAccount(ProfileShippingAccountRequest profileShippingAccountRequest)
        {
            var filter = Builders<BsonDocument>.Filter.In("RedundantProfileInformation.ShippingAccountNumber", profileShippingAccountRequest.ShippingAccountNumbers);
            var update = Builders<BsonDocument>.Update.Set("RedundantProfileInformation.OrganizationID", profileShippingAccountRequest.OrganizationId);

            var result = await _iProfiledSeriesCollection.UpdateManyAsync(filter, update);
            return true;
        }

        private async Task<bool> SetProfileOrganizationIdByShippingAccount(ProfileShippingAccountRequest profileShippingAccountRequest)
        {
            var filter = Builders<BsonDocument>.Filter.In("ShippingAccountNumber", profileShippingAccountRequest.ShippingAccountNumbers);
            var update = Builders<BsonDocument>.Update.Set("OrganizationID", profileShippingAccountRequest.OrganizationId);

            var result = await _iProfilesCollection.UpdateManyAsync(filter, update);
            return true;
        }

        internal async Task<NoSqlServiceResult<bool>> UpdateProfileNotificationUsers(ProfileNotificationUsersUpdateRequest profileNotificationUsersUpdateRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidateProfileNotificationUsersUpdateRequest(profileNotificationUsersUpdateRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                var updateProfileNotificationUsersStatus = await SetNotificationUsersByProfileId(profileNotificationUsersUpdateRequest, profileObjectId);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "UpdateProfileNotificationUsers");
            }
            return noSqlServiceResult;
        }

        private async Task<bool> SetNotificationUsersByProfileId(ProfileNotificationUsersUpdateRequest profileNotificationUsersUpdateRequest, ObjectId profileObjectId)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("_id", profileObjectId);
            UpdateDefinition<BsonDocument> update;
            var now = DateTime.Now;

            if (profileNotificationUsersUpdateRequest.UserIdList != null && profileNotificationUsersUpdateRequest.UserIdList.Count > 0)
            {
                update = Builders<BsonDocument>.Update.Set("NotificationUsers", profileNotificationUsersUpdateRequest.UserIdList)
                                                    .Unset("RequestStatus")
                                                    .Unset("RequestType")
                                                    .Set("FootprintInformation.UpdatedDate", now)
                                                    .Set("FootprintInformation.UpdatedBy", profileNotificationUsersUpdateRequest.UpdatedBy);
            }
            else
            {
                update = Builders<BsonDocument>.Update.Unset("NotificationUsers")
                                .Unset("RequestStatus")
                                .Unset("RequestType")
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", profileNotificationUsersUpdateRequest.UpdatedBy);
            }

            var result = await _iProfilesCollection.UpdateManyAsync(filter, update);
            return true;
        }
        #region Validation
        private string ValidateProfileShippingAccountRequest(ProfileShippingAccountRequest profileShippingAccountRequest)
        {
            if (profileShippingAccountRequest == null)
            {
                return "Request is required";
            }

            if (string.IsNullOrEmpty(profileShippingAccountRequest.OrganizationId))
            {
                return "Organization Id is required";

            }

            if (profileShippingAccountRequest.ShippingAccountNumbers == null || profileShippingAccountRequest.ShippingAccountNumbers.Count < 1)
            {
                return "Shipping Account is required";

            }
            return null;
        }

        private string ValidateProfileOrderStatusRequest(ProfileOrderStatusRequest profileOrderStatusRequest)
        {
            if (profileOrderStatusRequest == null)
            {
                return "Request is required";
            }
            return null;
        }

        private string ValidateMasterOrderStatusRequest(MasterOrderStatusRequest masterOrderStatusRequest)
        {
            if (masterOrderStatusRequest == null)
            {
                return "Request is required";
            }
            return null;
        }

        private string ValidateProfileNotificationUsersUpdateRequest(ProfileNotificationUsersUpdateRequest profileNotificationUsersUpdateRequest, out ObjectId profileObjectId)
        {
            profileObjectId = new ObjectId();
            if (profileNotificationUsersUpdateRequest == null)
            {
                return "Request is required";
            }

            if (string.IsNullOrEmpty(profileNotificationUsersUpdateRequest.ProfileId))
            {
                return "Profile Id is required";

            }
            if (!ObjectId.TryParse(profileNotificationUsersUpdateRequest.ProfileId, out profileObjectId))
            {
                return "Invalid Profile Id";

            }
            return null;
        }
        #endregion

        /*
        internal async Task<NoSqlServiceResult<RequestStatusQueueResponse>> GetRequestStatusQueue(RequestStatusQueueRequest requestStatusQueueRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<RequestStatusQueueResponse> { Status = NoSqlServiceStatus.Success };
            try
            {
                noSqlServiceResult.Data = await GetRequestStatusQueueData(requestStatusQueueRequest);
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new RequestStatusQueueResponse();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetRequestStatusQueue");
            }
            return noSqlServiceResult;
        }

        private async Task<RequestStatusQueueResponse> GetRequestStatusQueueData(RequestStatusQueueRequest requestStatusQueueRequest)
        {
            var requestStatusQueueResponse = new RequestStatusQueueResponse();


            //var filter = new BsonDocument();
            var filter = GetRequestStatusQueueFilter(requestStatusQueueRequest);
            var sort = GetRequestStatusQueueSort(requestStatusQueueRequest.SortBy, requestStatusQueueRequest.SortDirection);

            requestStatusQueueResponse.RequestStatusQueueHasActiveRequests = await HasActiveChangeRequest(GetActiveRequestStatusQueueFilter());
            if (requestStatusQueueResponse.RequestStatusQueueHasActiveRequests)
            {
                requestStatusQueueResponse.ChangeRequestList = await GetChangeRequests(filter, sort);
                if (requestStatusQueueResponse.ChangeRequestList != null && requestStatusQueueResponse.ChangeRequestList.Any())
                {
                    foreach(var changeRequest in requestStatusQueueResponse.ChangeRequestList)
                    {
                        if (string.Equals(changeRequest.ChangeType, ChangeRequestChangeType.ProfiledSeries, StringComparison.OrdinalIgnoreCase)) 
                        {
                            if (changeRequest.ProfiledSeriesChangeRequest != null && changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders != null)
                            {
                                foreach (var purchaseOrder in changeRequest.ProfiledSeriesChangeRequest.PurchaseOrders)
                                {
                                    if (purchaseOrder.StartNextAvailableTitle)
                                    {
                                        purchaseOrder.StartDate = "Next Available Title";
                                    }
                                }
                            }

                            if (changeRequest.ProfiledSeriesOriginalState != null && changeRequest.ProfiledSeriesOriginalState.PurchaseOrders != null)
                            {
                                foreach (var purchaseOrder in changeRequest.ProfiledSeriesOriginalState.PurchaseOrders)
                                {
                                    if (purchaseOrder.StartNextAvailableTitle)
                                    {
                                        purchaseOrder.StartDate = "Next Available Title";
                                    }
                                }
                            }
                        }
                    }
                    requestStatusQueueResponse.OrganizationList = requestStatusQueueResponse.ChangeRequestList.Select(p => p.OrganizationName).Distinct().OrderBy(p => p).ToList();
                    requestStatusQueueResponse.ProfileNameAccountNumberDetailsList = requestStatusQueueResponse.ChangeRequestList.GroupBy(p => new { p.ERPAccountNumber, p.ProfileName }).Select(p => p.First()).Select(p => new ProfileNameAccountNumberDetails { ProfileName = p.ProfileName, AccountNumber = p.ERPAccountNumber }).OrderBy(p => p.ProfileName).ToList();
                }
            }

            return requestStatusQueueResponse;
        }

        private FilterDefinition<ChangeRequests> GetRequestStatusQueueFilter(RequestStatusQueueRequest requestStatusQueueRequest)
        {
            FilterDefinition<ChangeRequests> filter;
            if (string.Equals(requestStatusQueueRequest.RequestStatus, "All"))
            {
                filter = Builders<ChangeRequests>.Filter.Nin("RequestStatus", CommonHelper.GetChangeRequestSystemStatuses());
            }
            else
            {
                    filter = Builders<ChangeRequests>.Filter.Eq("RequestStatus", requestStatusQueueRequest.RequestStatus);
                }
            if (requestStatusQueueRequest.OrganizationLocationFilters != null && requestStatusQueueRequest.OrganizationLocationFilters.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("SalesTerritory", requestStatusQueueRequest.OrganizationLocationFilters);
            } 

            if (requestStatusQueueRequest.OrganizationNameFilters != null && requestStatusQueueRequest.OrganizationNameFilters.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("OrganizationName", requestStatusQueueRequest.OrganizationNameFilters);
            }

            if (requestStatusQueueRequest.ProfileNameAccountNumberDetailsFilters != null && requestStatusQueueRequest.ProfileNameAccountNumberDetailsFilters.Any())
            {
                filter = filter & Builders<ChangeRequests>.Filter.In("ProfileName", requestStatusQueueRequest.ProfileNameAccountNumberDetailsFilters.Select(p => p.ProfileName).ToList())
                    & Builders<ChangeRequests>.Filter.In("ERPAccountNumber", requestStatusQueueRequest.ProfileNameAccountNumberDetailsFilters.Select(p => p.AccountNumber).ToList());
            }

            if (!string.Equals(requestStatusQueueRequest.RequestType, "All"))
            {
                filter = filter & Builders<ChangeRequests>.Filter.Eq("RequestType", requestStatusQueueRequest.RequestType);
            }
            return filter;
        }

        private FilterDefinition<ChangeRequests> GetActiveRequestStatusQueueFilter()
        {
            return Builders<ChangeRequests>.Filter.Nin("RequestStatus", CommonHelper.GetChangeRequestSystemStatuses());
        }

        private async Task<List<ChangeRequests>> GetChangeRequests(FilterDefinition<ChangeRequests> filter, SortDefinition<ChangeRequests> sort)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new List<ChangeRequests>();
            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    response = await cursor.Sort(sort).ToListAsync<ChangeRequests>();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return response;
        }

        private async Task<bool> HasActiveChangeRequest(FilterDefinition<ChangeRequests> filter)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            var response = new List<ChangeRequests>();
            var hasActiveChangeRequests = false;
            while (retries > 0)
            {
                try
                {
                    var cursor = _changeRequests.Find<ChangeRequests>(filter);
                    hasActiveChangeRequests = cursor.Any();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return hasActiveChangeRequests;
        }

        private SortDefinition<ChangeRequests> GetRequestStatusQueueSort(string sortBy, string sortDirection)
        {
            if (string.Equals(ChangeRequestSortOption.RequestedModification, sortBy, StringComparison.OrdinalIgnoreCase))
            {
                return sortDirection.ToLower() == "desc" ? Builders<ChangeRequests>.Sort.Descending(sortBy).Descending(ChangeRequestSortOption.DateRequested)
                : Builders<ChangeRequests>.Sort.Ascending(sortBy).Descending(ChangeRequestSortOption.DateRequested);
            }
            else
            {
                return sortDirection.ToLower() == "desc" ? Builders<ChangeRequests>.Sort.Descending(sortBy)
                : Builders<ChangeRequests>.Sort.Ascending(sortBy);
            }
        }
        */
        /*internal async Task<NoSqlServiceResult<bool>> UpdateChangeRequest(ChangeRequestUpdateRequest changeRequestUpdateRequest)
        {
            var result = new NoSqlServiceResult<bool>();
            var updateChangeRequestDocumentList = new List<BsonDocument>();
            var now = DateTime.Now;
            var profileIdList = new List<string>();
            var profiledSeriesIdList = new List<string>();
            if (changeRequestUpdateRequest.ProfileChangeRequestUpdateList != null && changeRequestUpdateRequest.ProfileChangeRequestUpdateList.Count > 0)
            {
                foreach (var profileChangeRequestUpdate in changeRequestUpdateRequest.ProfileChangeRequestUpdateList)
                {
                    var changeRequestFilter = Builders<ChangeRequests>.Filter.Eq("_id", ObjectId.Parse(profileChangeRequestUpdate.ChangeRequestId));
                    var changeRequestUpdate = Builders<ChangeRequests>.Update.Set("RequestStatus", profileChangeRequestUpdate.RequestStatus)
                        .Set("FootprintInformation.UpdatedDate", now)
                        .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                    await _changeRequests.UpdateOneAsync(changeRequestFilter, changeRequestUpdate);
                    
                    if (!string.Equals(ChangeRequestRequestType.NewProfile, profileChangeRequestUpdate.RequestType, StringComparison.OrdinalIgnoreCase))
                    {
                        profileIdList.Add(profileChangeRequestUpdate.ProfileId);
                        UpdateDefinition<BsonDocument> profileUpdate;
                        var profileFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(profileChangeRequestUpdate.ProfileId));
                        if (string.Equals(ChangeRequestStatus.Removed, profileChangeRequestUpdate.RequestStatus, StringComparison.OrdinalIgnoreCase))
                        {
                            profileUpdate = Builders<BsonDocument>.Update.Unset("RequestStatus")
                                .Unset("RequestType")
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);

                            await _iProfilesCollection.UpdateOneAsync(profileFilter, profileUpdate);
                        }
                        else if (string.Equals(ChangeRequestRequestType.ModifyUsers, profileChangeRequestUpdate.RequestType, StringComparison.OrdinalIgnoreCase) &&
                            string.Equals(ChangeRequestStatus.Loaded, profileChangeRequestUpdate.RequestStatus, StringComparison.OrdinalIgnoreCase))
                        {
                            ProfileNotificationUsersUpdateRequest profileNotificationUsersUpdateRequest = new ProfileNotificationUsersUpdateRequest();
                            profileNotificationUsersUpdateRequest.UserIdList = profileChangeRequestUpdate.NotificationUsers.Select(u => u.UserID).ToList();
                            profileNotificationUsersUpdateRequest.ProfileId = profileChangeRequestUpdate.ProfileId;
                            profileNotificationUsersUpdateRequest.UpdatedBy = changeRequestUpdateRequest.UpdatedBy;

                            await SetNotificationUsersByProfileId(profileNotificationUsersUpdateRequest, ObjectId.Parse(profileChangeRequestUpdate.ProfileId));
                        }
                        else
                        {
                            profileUpdate = Builders<BsonDocument>.Update.Set("RequestStatus", profileChangeRequestUpdate.RequestStatus)
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);

                            await _iProfilesCollection.UpdateOneAsync(profileFilter, profileUpdate);
                        }

                    }
                }
            }

            if (changeRequestUpdateRequest.ProfiledSeriesChangeRequestUpdateList != null && changeRequestUpdateRequest.ProfiledSeriesChangeRequestUpdateList.Count > 0)
            {
                foreach (var profiledSeriesChangeRequestUpdate in changeRequestUpdateRequest.ProfiledSeriesChangeRequestUpdateList)
                {
                    var changeRequestFilter = Builders<ChangeRequests>.Filter.Eq("_id", ObjectId.Parse(profiledSeriesChangeRequestUpdate.ChangeRequestId));
                    var changeReqestUpdate = Builders<ChangeRequests>.Update.Set("RequestStatus", profiledSeriesChangeRequestUpdate.RequestStatus)
                        .Set("FootprintInformation.UpdatedDate", now)
                        .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                    await _changeRequests.UpdateOneAsync(changeRequestFilter, changeReqestUpdate);
                    if (!string.Equals(ChangeRequestRequestType.AddSeries, profiledSeriesChangeRequestUpdate.RequestType, StringComparison.OrdinalIgnoreCase))
                    {
                        profiledSeriesIdList.Add(profiledSeriesChangeRequestUpdate.ProfiledSeriesId);
                        UpdateDefinition<BsonDocument> profiledSeriesUpdate;
                        var profiledSeriesFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(profiledSeriesChangeRequestUpdate.ProfiledSeriesId));
                        if (string.Equals(ChangeRequestStatus.Removed, profiledSeriesChangeRequestUpdate.RequestStatus, StringComparison.OrdinalIgnoreCase))
                        {
                            profiledSeriesUpdate = Builders<BsonDocument>.Update.Unset("RequestStatus")
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                        }
                        else
                        {
                            profiledSeriesUpdate = Builders<BsonDocument>.Update.Set("RequestStatus", profiledSeriesChangeRequestUpdate.RequestStatus)
                                .Set("FootprintInformation.UpdatedDate", now)
                                .Set("FootprintInformation.UpdatedBy", changeRequestUpdateRequest.UpdatedBy);
                        }
                        await _iProfiledSeriesCollection.UpdateOneAsync(profiledSeriesFilter, profiledSeriesUpdate);
                    }
                }
            }

            var azureSearchQueueItemList = getAzureSearchQueueItemFromList(profileIdList, "Profiles", "Upsert", changeRequestUpdateRequest.UpdatedBy);
            azureSearchQueueItemList.AddRange(getAzureSearchQueueItemFromList(profiledSeriesIdList, "ProfiledSeries", "Upsert", changeRequestUpdateRequest.UpdatedBy));
            if (azureSearchQueueItemList.Any())
            {
                await InsertAzureSearchQueueItems(azureSearchQueueItemList);
            }

            return result;
        }
        */
        private async Task<bool> UpdateChangeRequests(List<BsonDocument> updateDocumentList)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    await _iChangeRequestsCollection.InsertManyAsync(updateDocumentList);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return true;
        }

        private async Task<bool> UpdateProfileRequestStatus(string profileId, string requestStatus, string requestType)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    var builder = Builders<BsonDocument>.Filter;
                    var filter = builder.Eq("_id", ObjectId.Parse(profileId));
                    var update = Builders<BsonDocument>.Update.Set("RequestStatus", requestStatus)
                        .Set("RequestType", requestType);
                    var result = await _iProfilesCollection.UpdateOneAsync(filter, update);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return true;
        }

        private async Task<bool> InsertChangeRequest(ChangeRequests changeRequest)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            if (changeRequest != null)
            {
                if (string.IsNullOrWhiteSpace(changeRequest.SalesTerritory))
                {
                    CommonHelper.SendMissingSalesTerritoryEmail();
                }
                while (retries > 0)
                {
                    try
                    {
                        await _changeRequests.InsertOneAsync(changeRequest);
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }

            }
            return true;
        }

        internal async Task<NoSqlServiceResult<bool>> CreateProfileChangeRequest(ChangeRequestProfileRequest changeRequestProfileRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };

            try
            {
                if (string.Equals(changeRequestProfileRequest.RequestType, ChangeRequestRequestType.CopyProfile, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(changeRequestProfileRequest.RequestType, ChangeRequestRequestType.DeleteProfile, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(changeRequestProfileRequest.RequestType, ChangeRequestRequestType.DisableProfile, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(changeRequestProfileRequest.RequestType, ChangeRequestRequestType.ModifyUsers, StringComparison.OrdinalIgnoreCase))
                {
                    await EmailProfileChangeRequest(changeRequestProfileRequest);
                }
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                LoggerService logger = new LoggerService();
                logger.LogError(ex, "createProfileChangeRequest", changeRequestProfileRequest.ToString());
            }
            return noSqlServiceResult;
        }

        private async Task InsertAzureSearchQueueItems(List<AzureSearchQueueItem> azureSearchQueueItemList)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            while (retries > 0)
            {
                try
                {
                    await _azureSearchQueue.InsertManyAsync(azureSearchQueueItemList);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

        }

        private List<AzureSearchQueueItem> getAzureSearchQueueItemFromList(List<string> profileIds, string collectionName, string changeType, string requestedBy)
        {
            var azureSearchQueueItemList = new List<AzureSearchQueueItem>();
            var footprintInformation = new FootprintInformation();
            var now = DateTime.Now;
            footprintInformation.CreatedBy = requestedBy;
            footprintInformation.CreatedDate = now;
            footprintInformation.UpdatedBy = requestedBy;
            footprintInformation.UpdatedDate = now;
            foreach (var profileId in profileIds)
            {
                var azureSearchQueueItem = new AzureSearchQueueItem();

                azureSearchQueueItem.ObjectId = ObjectId.Parse(profileId);
                azureSearchQueueItem.ChangeType = changeType;
                azureSearchQueueItem.CollectionName = collectionName;
                azureSearchQueueItem.Priority = AppSettings.AzureSearchQueuePriority;
                azureSearchQueueItem.InProcessState = 0;
                azureSearchQueueItem.IsRealTime = true;
                azureSearchQueueItem.FootprintInformation = footprintInformation;
                azureSearchQueueItemList.Add(azureSearchQueueItem);
            }
            return azureSearchQueueItemList;
        }

        private async Task<bool> EmailProfileChangeRequest(ChangeRequestProfileRequest changeRequestProfileRequest)
        {
            MailMessage mail = new MailMessage();
            SmtpClient client = new SmtpClient();
            var emailToList = AppSettings.ProfileRequestEmailTo.Split(';');
            foreach (var emailTo in emailToList)
            {
                if (!string.IsNullOrEmpty(emailTo))
                    mail.To.Add(emailTo);
            }
            if (string.Equals(changeRequestProfileRequest.RequestType, ChangeRequestRequestType.DisableProfile, StringComparison.OrdinalIgnoreCase))
            {
                mail.Subject = AppSettings.StandingOrdersEmailPrefix + "Temporarily Suspend Shipments Requested";
            }
            else
            {
                mail.Subject = AppSettings.StandingOrdersEmailPrefix + changeRequestProfileRequest.RequestType + " Requested";
            }

            mail.Body = GetCopyProfileChangeRequestEmailBody(changeRequestProfileRequest); // Copy Profile, Delete Profile and Disable Profile are using the same email template
            mail.IsBodyHtml = true;

            client.Send(mail);
            return true;
        }

        private string GetCopyProfileChangeRequestEmailBody(ChangeRequestProfileRequest changeRequestProfileRequest)
        {
            string emailBody = string.Empty;
            using (StreamReader reader = new StreamReader(HttpRuntime.AppDomainAppPath + @"Common\EmailTemplates\CopyProfileRequestEmailTemplate.txt"))
            {
                emailBody = reader.ReadToEnd();
            }

            emailBody = emailBody.Replace("{ORGANIZATION_NAME}", changeRequestProfileRequest.OrganizationName);
            emailBody = emailBody.Replace("{PROFILE_NAME}", changeRequestProfileRequest.ProfileName);
            emailBody = emailBody.Replace("{ACCOUNT_NUMBER}", changeRequestProfileRequest.ERPAccountNumber);

            if (string.Equals(changeRequestProfileRequest.RequestType, ChangeRequestRequestType.ModifyUsers, StringComparison.OrdinalIgnoreCase))
            {
                emailBody = emailBody.Replace("{PROFILE_TYPE}", ProfileType.Notification);
                emailBody = emailBody.Replace("{NOTIFICATION_USERS}", GetNotificationUsersEmailTemplate(changeRequestProfileRequest.NewNotificationUsers, ProfileType.Notification));
            }
            else
            {
                emailBody = emailBody.Replace("{PROFILE_TYPE}", changeRequestProfileRequest.ProfileType);
                emailBody = emailBody.Replace("{NOTIFICATION_USERS}", GetNotificationUsersEmailTemplate(changeRequestProfileRequest.NotificationUsers, changeRequestProfileRequest.ProfileType));
            }

            emailBody = emailBody.Replace("{CATALOGING_AND_PROCESSING}", changeRequestProfileRequest.NewCatalogingAndProcessing ? "Yes" : "No");
            emailBody = emailBody.Replace("{PRIMARY_CONTACT_NAME}", changeRequestProfileRequest.ContactName);
            emailBody = emailBody.Replace("{STATE}", changeRequestProfileRequest.State);
            emailBody = emailBody.Replace("{PHONE}", changeRequestProfileRequest.Phone);
            emailBody = emailBody.Replace("{FAX}", changeRequestProfileRequest.Fax);
            emailBody = emailBody.Replace("{EMAIL}", changeRequestProfileRequest.Email);
            emailBody = emailBody.Replace("{SUBMITTED_BY}", changeRequestProfileRequest.SubmittedByUserName);
            return emailBody;
        }

        private string GetNewProfileChangeRequestEmailBody(ProfileRequest profileRequest)
        {
            string emailBody = string.Empty;
            using (StreamReader reader = new StreamReader(HttpRuntime.AppDomainAppPath + @"Common\EmailTemplates\NewProfileRequestEmailTemplate.txt"))
            {
                emailBody = reader.ReadToEnd();
            }

            emailBody = emailBody.Replace("{ORGANIZATION_NAME}", profileRequest.OrgName);
            emailBody = emailBody.Replace("{PROFILE_NAME}", profileRequest.ProfileName);
            emailBody = emailBody.Replace("{PROFILE_TYPE}", profileRequest.ProfileType);
            emailBody = emailBody.Replace("{NOTIFICATION_USERS}", GetNotificationUsersEmailTemplate(profileRequest.NotificationUsers, profileRequest.ProfileType));
            emailBody = emailBody.Replace("{CATALOGING_AND_PROCESSING}", profileRequest.CatalogAndProcessing ? "Yes" : "No");
            emailBody = emailBody.Replace("{AREAS_OF_INTEREST}", string.Join(", ", profileRequest.AreasOfInterest));
            emailBody = emailBody.Replace("{PRIMARY_CONTACT_NAME}", profileRequest.ContactName);
            emailBody = emailBody.Replace("{PHONE}", profileRequest.Phone);
            emailBody = emailBody.Replace("{STATE}", profileRequest.State);
            emailBody = emailBody.Replace("{FAX}", profileRequest.Fax);
            emailBody = emailBody.Replace("{EMAIL}", profileRequest.Email);
            emailBody = emailBody.Replace("{INSTRUCTIONS}", profileRequest.Notes);
            emailBody = emailBody.Replace("{SUBMITTED_BY}", profileRequest.CreatedBy);
            return emailBody;
        }

        private string GetNotificationUsersEmailTemplate(List<NotificationUser> notificationUserList, string profileType)
        {
            var notificationUsersEmailTemplate = string.Empty;
            if (string.Equals(profileType, ProfileType.Notification, StringComparison.OrdinalIgnoreCase))
            {
                notificationUsersEmailTemplate = @"<tr>
	<td><b>Users to Receive Notification Carts:</b></td> 
	<td style=""border-bottom: 1px solid black; padding-left: 10px; font-weight: bold;""> 
                                        <label>User Name</label>&nbsp; 
                                    </td>
                                    <td style=""border-bottom: 1px solid black; font-weight: bold;""> 
                                        <label>Login ID</label>&nbsp; 
    </td>
</tr>";
                if (notificationUserList != null && notificationUserList.Any())
                {
                    foreach (var notificationUser in notificationUserList)
                    {
                        notificationUsersEmailTemplate += @"<tr>
                                    <td></td>
                                    <td style=""padding-left: 10px;"">
                                        <span style=""text-align: left; word-wrap: break-word; width: 100px;"">" + notificationUser.UserAlias + @"</span>
                                    </td>
                                    <td>
                                        <span style=""display: block; overflow: hidden; text-align: left; word-wrap: break-word;"">" + notificationUser.UserName + @"</span>
                                    </td>
                                </tr>";
                    }
                }
            }

            return notificationUsersEmailTemplate;
        }
        private ChangeRequests GetProfileChangeRequest(ChangeRequestProfileRequest changeRequestProfileRequest)
        {
            var changeRequest = new ChangeRequests();
            var profileChangeRequest = new ProfileChangeRequest();

            profileChangeRequest.ProfileType = changeRequestProfileRequest.ProfileType;
            if (!string.IsNullOrEmpty(changeRequestProfileRequest.Programs))
            {
                profileChangeRequest.Programs = changeRequestProfileRequest.Programs.Split(',').ToList();
            }

            if (string.Equals(ChangeRequestRequestType.CopyProfile, changeRequestProfileRequest.RequestType, StringComparison.OrdinalIgnoreCase))
            {
                profileChangeRequest.NewProfileName = changeRequestProfileRequest.NewProfileName;
                profileChangeRequest.CatalogingAndProcessing = changeRequestProfileRequest.NewCatalogingAndProcessing ? "Yes" : "No";
            }
            else
            {
                profileChangeRequest.CatalogingAndProcessing = "No";
            }

            profileChangeRequest.Instructions = changeRequestProfileRequest.Instructions;
            profileChangeRequest.TotalCopies = changeRequestProfileRequest.TotalCopies;
            profileChangeRequest.TotalSeries = changeRequestProfileRequest.TotalSeries;

            var now = DateTime.Now;
            var footprintInformation = new FootprintInformation();
            footprintInformation.CreatedBy = changeRequestProfileRequest.SubmittedByUserName;
            footprintInformation.CreatedDate = now;
            footprintInformation.CreatedByUserID = changeRequestProfileRequest.SubmittedByUserId;
            footprintInformation.UpdatedBy = changeRequestProfileRequest.SubmittedByUserName;
            footprintInformation.UpdatedDate = now;
            footprintInformation.UpdatedByUserID = changeRequestProfileRequest.SubmittedByUserId;

            if (changeRequestProfileRequest.NotificationUsers != null && changeRequestProfileRequest.NotificationUsers.Count > 0)
            {
                var profileOriginalChangeRequest = new ProfileChangeRequest();
                profileOriginalChangeRequest.NotificationUsers = changeRequestProfileRequest.NotificationUsers;
                changeRequest.ProfileOriginalState = profileOriginalChangeRequest;
            }

            if (changeRequestProfileRequest.NewNotificationUsers != null && changeRequestProfileRequest.NewNotificationUsers.Count > 0)
            {
                profileChangeRequest.NotificationUsers = changeRequestProfileRequest.NewNotificationUsers;
            }

            changeRequest.ProfileChangeRequest = profileChangeRequest;
            changeRequest.FootprintInformation = footprintInformation;
            changeRequest.RequestType = ChangeRequestChangeType.Profile;
            changeRequest.ProfileName = changeRequestProfileRequest.ProfileName;
            changeRequest.ProfileID = ObjectId.Parse(changeRequestProfileRequest.ProfileId);
            changeRequest.RequestType = changeRequestProfileRequest.RequestType;
            changeRequest.ERPAccountNumber = changeRequestProfileRequest.ERPAccountNumber;
            changeRequest.SalesTerritory = changeRequestProfileRequest.SalesTerritory;
            changeRequest.RequestStatus = ChangeRequestStatus.Open;
            changeRequest.OrganizationName = changeRequestProfileRequest.OrganizationName;
            changeRequest.OrganizationID = changeRequestProfileRequest.OrganizationId;

            return changeRequest;
        }

        private string GetPendingStatus(string requestType)
        {
            switch (requestType)
            {
                case ChangeRequestRequestType.DisableProfile:
                    return "Pending Disable";
                case ChangeRequestRequestType.DeleteProfile:
                    return "Pending Deletion";
                case ChangeRequestRequestType.CopyProfile:
                    return "Pending Copy";
                case ChangeRequestRequestType.ModifyUsers:
                    return "Modify Users";
                default:
                    return "Pending Modification";
            }
        }


        public async Task<NoSqlServiceResult<ProgramsResponse>> GetProgramsBySearch(ProgramsRequest programsRequest)
        {
            var response = new ProgramsResponse();

            try
            {
                var searchText = "*";
                var searchParameters = GetProgramSearchParameters(programsRequest);
                var profilesResponse = new List<ProfileDetailsResponse>();
                var programs = new List<ProgramResponse>();

                if (!AppSettings.AzureSearchValidateServerCertificate)
                {
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                }

                DocumentSearchResult<ProfilesSearchResultItem> searchResponse = await _profilesIndexClient.Documents.SearchAsync<ProfilesSearchResultItem>(searchText, searchParameters);

                if (searchResponse != null)
                {
                    foreach (var facet in searchResponse.Facets)
                    {
                        var facetId = facet.Key;
                        if (string.Equals(facetId, "Programs", StringComparison.OrdinalIgnoreCase))
                        {
                            foreach (var facetValue in facet.Value)
                            {
                                var programResponse = new ProgramResponse();
                                programResponse.ProgramId = facetValue.Value.ToString();
                                programResponse.ProgramName = facetValue.Value.ToString();
                                programResponse.TotalProfiles = facetValue.Count.HasValue ? facetValue.Count.Value : 0;
                                programs.Add(programResponse);
                            }
                        }
                    }

                    response.Programs = programs;
                    response.TotalItems = searchResponse.Count.HasValue ? searchResponse.Count.Value : 0;
                }

            }
            catch (Exception ex)
            {
                LoggerService logger = new LoggerService();
                logger.LogError(ex, "GetProgramsBySearch", "");

                return new NoSqlServiceResult<ProgramsResponse> { Data = response, Status = NoSqlServiceStatus.Fail };

            }
            return new NoSqlServiceResult<ProgramsResponse> { Data = response, Status = NoSqlServiceStatus.Success };
        }

        private SearchParameters GetProgramSearchParameters(ProgramsRequest programsRequest)
        {
            var searchParameters = new SearchParameters();
            searchParameters.SearchMode = SearchMode.All;
            searchParameters.QueryType = QueryType.Full;
            searchParameters.IncludeTotalResultCount = true;
            searchParameters.Filter = "OrganizationID eq '" + programsRequest.OrgId + "'";
            searchParameters.Facets = new List<string> { "Programs" };

            return searchParameters;
        }

        internal async Task<NoSqlServiceResult<bool>> EmailProfile(EmailProfileRequest emailProfileRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                ObjectId profileObjectId;
                var error = ValidateEmailProfileRequest(emailProfileRequest, out profileObjectId);
                if (!string.IsNullOrEmpty(error))
                {
                    noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                    noSqlServiceResult.ErrorMessage = error;
                    return noSqlServiceResult;
                }
                var emailProfileBackgroundQueueItem = GetBackgroundQueueItemFromEmailProfileRequest(emailProfileRequest, profileObjectId);
                await InsertBackgroundQueueItem(emailProfileBackgroundQueueItem);

            }
            catch (Exception exception)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "ProfileService", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", emailProfileRequest.ToJson(),
                    exception.Message, exception.StackTrace));
            }
            return noSqlServiceResult;
        }

        private async Task InsertBackgroundQueueItem(BackgroundQueue backgroundQueueItem)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;
            while (retries > 0)
            {
                try
                {
                    await _backgroundQueue.InsertOneAsync(backgroundQueueItem);
                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }
        }

        private BackgroundQueue GetBackgroundQueueItemFromEmailProfileRequest(EmailProfileRequest emailProfileRequest, ObjectId profileObjectId)
        {
            var now = DateTime.Now;
            var backgroundQueueItem = new BackgroundQueue();
            var reportSettings = new ReportSettings();
            var emailSettings = new EmailSettings();
            var footprintInformation = new FootprintInformation();

            reportSettings.OrgName = emailProfileRequest.OrganizationName;
            reportSettings.ProfileID = profileObjectId;
            reportSettings.ReportType = "Email Profile";
            emailSettings.Note = emailProfileRequest.Notes;
            emailSettings.Subject = emailProfileRequest.Subject;
            emailSettings.To = emailProfileRequest.EmailTo;
            emailSettings.CompressFile = emailProfileRequest.CompressFile;
            footprintInformation.CreatedBy = emailProfileRequest.SubmittedByUserName;
            footprintInformation.CreatedDate = now;
            footprintInformation.UpdatedBy = emailProfileRequest.SubmittedByUserName;
            footprintInformation.UpdatedDate = now;
            backgroundQueueItem.EmailSettings = emailSettings;
            backgroundQueueItem.ReportSettings = reportSettings;
            backgroundQueueItem.JobType = "Report";
            backgroundQueueItem.Priority = AppSettings.BackgroundQueuePriority;
            backgroundQueueItem.InProcessState = "New";
            backgroundQueueItem.FootprintInformation = footprintInformation;
            return backgroundQueueItem;
        }

        private string ValidateEmailProfileRequest(EmailProfileRequest emailProfileRequest, out ObjectId profileObjectId)
        {
            profileObjectId = new ObjectId();
            if (emailProfileRequest == null)
            {
                return "Request is required";
            }
            if (emailProfileRequest.EmailTo == null)
            {
                return "Email to is required";
            }
            if (!ObjectId.TryParse(emailProfileRequest.ProfileId, out profileObjectId))
            {
                return "Invalid Profile Id";
            }
            return null;
        }

        internal async Task<NoSqlServiceResult<bool>> RequestMasterProfileReport(MasterProfileReportRequest masterProfileReportRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<bool> { Status = NoSqlServiceStatus.Success };
            try
            {
                var masterProfileReportRequestBackgroundQueueItem = GetBackgroundQueueItemFromMasterProfileReportRequest(masterProfileReportRequest);
                await InsertBackgroundQueueItem(masterProfileReportRequestBackgroundQueueItem);

            }
            catch (Exception exception)
            {
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorMessage = exception.Message;
                var logger = new LoggerService();
                logger.LogError(exception, "RequestMasterProfileReport", string.Format("Param: {0}, Message: {1}, Stack Trace: {2}", masterProfileReportRequest.ToJson(),
                    exception.Message, exception.StackTrace));
            }
            return noSqlServiceResult;
        }

        private BackgroundQueue GetBackgroundQueueItemFromMasterProfileReportRequest(MasterProfileReportRequest masterProfileReportRequest)
        {
            var now = DateTime.Now;
            var backgroundQueueItem = new BackgroundQueue();
            var reportSettings = new ReportSettings();
            var footprintInformation = new FootprintInformation();

            reportSettings.OrgName = masterProfileReportRequest.OrganizationName;
            reportSettings.OrgID = masterProfileReportRequest.OrganizationId;
            reportSettings.ReportType = masterProfileReportRequest.ReportType;
            reportSettings.UserID = masterProfileReportRequest.UserId;
            footprintInformation.CreatedBy = masterProfileReportRequest.LoginName;
            footprintInformation.CreatedDate = now;
            footprintInformation.UpdatedBy = masterProfileReportRequest.LoginName;
            footprintInformation.UpdatedDate = now;
            backgroundQueueItem.ReportSettings = reportSettings;
            backgroundQueueItem.JobType = "Report";
            backgroundQueueItem.Priority = AppSettings.BackgroundQueuePriority;
            backgroundQueueItem.InProcessState = "New";
            backgroundQueueItem.FootprintInformation = footprintInformation;
            return backgroundQueueItem;
        }
    }
}
