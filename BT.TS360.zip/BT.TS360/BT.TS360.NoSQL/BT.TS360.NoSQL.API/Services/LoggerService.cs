﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Common.Configuration;

using BT.TS360.NoSQL.Data.Common.Helper;

namespace BT.TS360.NoSQL.API.Services
{
    public class LoggerService
    {
        string _connection;

        public LoggerService() : this("") { }

        public LoggerService(string connection)
        {
            if (string.IsNullOrWhiteSpace(connection))
            {
                _connection = AppSettings.ExceptionLoggingConnectionString;
            }
        }

        public void LogError(Exception exception, string source)
        {
            LogError(exception, source, "");
        }

        public void LogError(Exception exception, string source, string requestInJson)
        {
            /*var errorLog = new SqlErrorLog(_connection);
            errorLog.ApplicationName = "MongoDB-WebAPI";

            var error = new Error(exception);
            error.ApplicationName = errorLog.ApplicationName;
            error.Source = source;
            error.Type = exception.GetBaseException().GetType().ToString();

            // when logging replace double quote with single quote, as we have encoding issue when logging JSON in AllXML column
            // if we need to debug, simply get the details from WebHostHtmlMessage within AllXML, then use notepad or other text editor, replace two single quotes with one double quotes
            error.WebHostHtmlMessage = requestInJson.Replace("\"", "''");

            errorLog.Log(error);*/

            ExceptionLogger exceptionLogger = new ExceptionLogger(_connection);
            exceptionLogger.LogError(exception, "MongoDB-WebAPI", source, requestInJson);
        }
    }

}