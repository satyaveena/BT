﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Services.Interfaces;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Constants;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;
using System.Threading;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using BT.TS360.NoSQL.Data.AzureSearch;

using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using BT.TS360.NoSQL.Data.Common.Helper;

namespace BT.TS360.NoSQL.API.Services.StandingOrders
{
    public class ProductService
    {
        readonly IMongoCollection<BsonDocument> _iProductsCollection;

        public ProductService()
        {
            var client = new MongoClient(ConnectionString);
            var iProductsDatabase = client.GetDatabase(CommonConstants.ProductsDatabaseName);
            _iProductsCollection = iProductsDatabase.GetCollection<BsonDocument>(CommonConstants.ProductsCollectionName);
        }

        public string ConnectionString
        {
            get { return AppSettings.MongoDBConnectionString; }
        }

        internal async Task<NoSqlServiceResult<List<NewReleaseCalendarProductInfo>>> GetNewReleaseCalendarProductInfoBtKeys(List<string> btKeys)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<NewReleaseCalendarProductInfo>> { Status = NoSqlServiceStatus.Success, Data = new List<NewReleaseCalendarProductInfo>() };

            try
            {
                int retryWaitTime = AppSettings.RetryWaitTime;
                int retries = AppSettings.MaxConnectionRetries;

                var bsonDocs = new List<BsonDocument>();

                var filter = Builders<BsonDocument>.Filter.In("_id", btKeys);

                while (retries > 0)
                {
                    try
                    {
                        bsonDocs = await _iProductsCollection.Find(filter).ToListAsync();
                        break;
                    }
                    catch (Exception)
                    {
                        retries--;
                        Thread.Sleep(retryWaitTime);
                        if (retries < 1)
                        {
                            throw;
                        }
                    }
                }



                foreach (var document in bsonDocs)
                {
                    var newReleaseCalendarProductInfo = new NewReleaseCalendarProductInfo();
                    if (document.Contains("_id"))
                    {
                        newReleaseCalendarProductInfo.BTKey = document["_id"].AsString;
                    }
                    if (document.Contains("ProductType"))
                    {
                        newReleaseCalendarProductInfo.ProductType = document["ProductType"].AsString;
                    }
                    if (document.Contains("PreOrderDate"))
                    {
                        newReleaseCalendarProductInfo.PreOrderDate = document["PreOrderDate"].AsDateTime;
                    }


                    noSqlServiceResult.Data.Add(newReleaseCalendarProductInfo);
                }
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new List<NewReleaseCalendarProductInfo>();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; // will define the error code
                noSqlServiceResult.ErrorMessage = ex.Message;

                var logger = new LoggerService();
                logger.LogError(ex, "GetNewReleaseCalendarProductInfoBtKeys");
            }

            return noSqlServiceResult;
        }


        internal async Task<NoSqlServiceResult<List<DiversityTopic>>> GetDiversityTopicsAnalyzation(List<string> btKeys)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<DiversityTopic>> { Status = NoSqlServiceStatus.Success, Data = new List<DiversityTopic>() };

            try
            {

                var bsonDocs = await GetSummaryDiversityTopicBsonDocuments(btKeys);
                if (bsonDocs != null && bsonDocs.Count > 0)
                {
                    noSqlServiceResult.Data.Add(GetSummaryDiversityTopic(bsonDocs, btKeys.Count));
                    noSqlServiceResult.Data.AddRange(await GetDiversityTopicData(btKeys));
                }
            }
            catch (Exception ex)
            {
                noSqlServiceResult.Data = new List<DiversityTopic>();
                noSqlServiceResult.Status = NoSqlServiceStatus.Fail;
                noSqlServiceResult.ErrorCode = "9999"; //
                noSqlServiceResult.ErrorMessage = ex.Message;

                var logger = new LoggerService();
                logger.LogError(ex, "GetDiversityTopicsAnalyzation");
            }

            return noSqlServiceResult;
        }

        private async Task<List<BsonDocument>> GetSummaryDiversityTopicBsonDocuments(List<string> btKeys)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            var bsonDocs = new List<BsonDocument>();
            var filter = Builders<BsonDocument>.Filter;
            var query = filter.And(filter.In("_id", btKeys), filter.Exists("DiversityClassification"), filter.Exists("AudienceLevel"), filter.Exists("BookClassificationLiteral"));
            var aggregateOptions = new AggregateOptions { AllowDiskUse = true };
            while (retries > 0)
            {
                try
                {
                    bsonDocs = await _iProductsCollection.Aggregate<BsonDocument>(aggregateOptions)
                                .Match(query)
                                .Group(new BsonDocument
                                    {
                                                { "_id", 
                                        new BsonDocument
                                                {
                                                    { "AudienceLevel", "$AudienceLevel" }, 
                                                    { "BookClassificationLiteral", "$BookClassificationLiteral" }
                                                } }, 
                                                { "Count", 
                                        new BsonDocument("$sum", 1) }
                                     })
                                .ToListAsync();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return bsonDocs;
        }

        private DiversityTopic GetSummaryDiversityTopic(List<BsonDocument> bsonDocs, int btKeyCount)
        {

            var summaryDiversityTopic = new DiversityTopic();
            summaryDiversityTopic.TopicCode = "Unique";
            summaryDiversityTopic.TopicTitle = "Unique Diverse Titles";
            summaryDiversityTopic.DEIAnalizeData = new List<DEIAnalizeData>();
            int totalItems = 0;
            foreach (var doc in bsonDocs)
            {
                var deiAnalizeDataItem = new DEIAnalizeData();
                if (doc.Contains("_id"))
                {
                    var idDoc = doc["_id"].AsBsonDocument;
                    if (idDoc.Contains("AudienceLevel"))
                    {
                        deiAnalizeDataItem.Audience = idDoc["AudienceLevel"].AsString;
                    }
                    if (idDoc.Contains("BookClassificationLiteral"))
                    {
                        var literal = idDoc["BookClassificationLiteral"].AsString;
                        deiAnalizeDataItem.IsFiction = string.Equals(literal, "Fiction", StringComparison.OrdinalIgnoreCase);
                        deiAnalizeDataItem.Name = deiAnalizeDataItem.Audience + " " + literal;
                    }
                }
                if (doc.Contains("Count"))
                {
                    deiAnalizeDataItem.Count = doc["Count"].AsInt32;
                    totalItems += deiAnalizeDataItem.Count;
                    deiAnalizeDataItem.Percentage = (int)Math.Round(((double)deiAnalizeDataItem.Count / btKeyCount * 100), 0);

                }
                summaryDiversityTopic.DEIAnalizeData.Add(deiAnalizeDataItem);  
            }
            var totalDEIAnalizeDataItem = new DEIAnalizeData();
            totalDEIAnalizeDataItem.Name = "Total Diverse Items";
            totalDEIAnalizeDataItem.Count = totalItems;
            totalDEIAnalizeDataItem.Percentage = (int)Math.Round(((double)totalDEIAnalizeDataItem.Count / btKeyCount * 100), 0);
            summaryDiversityTopic.DEIAnalizeData.Add(totalDEIAnalizeDataItem);

            return summaryDiversityTopic;
        }

        private async Task<List<DiversityTopic>> GetDiversityTopicData(List<string> btKeys)
        {
            var diversityTopicList = new List<DiversityTopic>();
            var bsonDocs = await GetDiversityTopicBsonDocuments(btKeys);

            if(bsonDocs != null && bsonDocs.Count > 0)
            {
                diversityTopicList.AddRange(BindDiversityTopicData(bsonDocs, btKeys.Count));
            }
            return diversityTopicList;
        }

        private List<DiversityTopic> BindDiversityTopicData(List<BsonDocument> bsonDocs, int btKeyCount)
        {
            var diversityTopicList = new List<DiversityTopic>();
            foreach (var doc in bsonDocs)
            {
                var diversityTopic = new DiversityTopic();

                if (doc.Contains("_id"))
                {
                    diversityTopic.TopicTitle = doc["_id"].AsString;
                }
                if (doc.Contains("ClassificationCode"))
                {
                    diversityTopic.TopicCode = doc["ClassificationCode"].AsString;
                }

                diversityTopic.DEIAnalizeData = new List<DEIAnalizeData>();
                int totalItems = 0;
                if(doc.Contains("DiversityGroup"))
                {
                    var diversityGroupDocs = doc["DiversityGroup"].AsBsonArray;
                    foreach(BsonDocument diversityGroupDoc in diversityGroupDocs)
                    {
                        var deiAnalizeDataItem = new DEIAnalizeData();

                        if (diversityGroupDoc.Contains("AudienceLevel"))
                        {
                            deiAnalizeDataItem.Audience = diversityGroupDoc["AudienceLevel"].AsString;
                        }
                        if (diversityGroupDoc.Contains("BookClassificationLiteral"))
                        {
                            var literal = diversityGroupDoc["BookClassificationLiteral"].AsString;
                            deiAnalizeDataItem.IsFiction = string.Equals(literal, "Fiction", StringComparison.OrdinalIgnoreCase);
                            deiAnalizeDataItem.Name = deiAnalizeDataItem.Audience + " " + literal;
                        }
                        if (diversityGroupDoc.Contains("Count"))
                        {
                            deiAnalizeDataItem.Count = diversityGroupDoc["Count"].AsInt32;
                            totalItems += deiAnalizeDataItem.Count;
                            deiAnalizeDataItem.Percentage = (int)Math.Round(((double)deiAnalizeDataItem.Count / btKeyCount * 100), 0);

                        }

                        diversityTopic.DEIAnalizeData.Add(deiAnalizeDataItem);
                    }
                }

               

                var totalDEIAnalizeDataItem = new DEIAnalizeData();
                totalDEIAnalizeDataItem.Name = "Total " + diversityTopic.TopicTitle + " Items";
                totalDEIAnalizeDataItem.Count = totalItems;
                totalDEIAnalizeDataItem.Percentage = (int)Math.Round(((double)totalDEIAnalizeDataItem.Count / btKeyCount * 100), 0);
                diversityTopic.DEIAnalizeData.Add(totalDEIAnalizeDataItem);
                diversityTopicList.Add(diversityTopic);
            }

            return diversityTopicList;
        }

        private async Task<List<BsonDocument>> GetDiversityTopicBsonDocuments(List<string> btKeys)
        {
            int retryWaitTime = AppSettings.RetryWaitTime;
            int retries = AppSettings.MaxConnectionRetries;

            var bsonDocs = new List<BsonDocument>();
            var filter = Builders<BsonDocument>.Filter;
            var query = filter.And(filter.In("_id", btKeys), filter.Exists("DiversityClassification"), filter.Exists("AudienceLevel"), filter.Exists("BookClassificationLiteral"));
            var sort = Builders<BsonDocument>.Sort.Ascending("_id");
            var query2 = Builders<BsonDocument>.Filter.Eq("DiversityClassification.RegionCode", "NA");
            var aggregateOptions = new AggregateOptions { AllowDiskUse = true };
            while (retries > 0)
            {
                try
                {
                    bsonDocs = await _iProductsCollection.Aggregate<BsonDocument>(aggregateOptions)
                                .Match(query)
                                .Unwind("DiversityClassification")
                                .Match(query2)
                                .Group(new BsonDocument
                                    {
                                                { "_id", 
                                                new BsonDocument
                                                {
                                                    { "AudienceLevel", "$AudienceLevel" }, 
                                                    { "BookClassificationLiteral", "$BookClassificationLiteral" }, 
                                                    { "ClassificationName", "$DiversityClassification.ClassificationName" }
                                                } }, 
                                                { "ClassificationCode", 
                                                new BsonDocument("$first", "$DiversityClassification.ClassificationCode") }, 
                                                { "Count", 
                                                new BsonDocument("$sum", 1) }
                                    })
                                    .Group(new BsonDocument
                                    {
                                                { "_id", "$_id.ClassificationName" }, 
                                                { "DiversityGroup", 
                                                new BsonDocument("$addToSet", 
                                                new BsonDocument
                                                    {
                                                        { "AudienceLevel", "$_id.AudienceLevel" }, 
                                                        { "BookClassificationLiteral", "$_id.BookClassificationLiteral" }, 
                                                        { "ClassificationName", "$_id.ClassificationName" }, 
                                                        { "Count", "$Count" }
                                                    }) }, 
                                                { "ClassificationCode", 
                                                new BsonDocument("$first", "$ClassificationCode") }, 
                                                { "Count", 
                                                new BsonDocument("$sum", 1) }
                                    })
                                 .Sort(sort)
                                .ToListAsync();

                    break;
                }
                catch (Exception)
                {
                    retries--;
                    Thread.Sleep(retryWaitTime);
                    if (retries < 1)
                    {
                        throw;
                    }
                }
            }

            return bsonDocs;
        }
    }
}