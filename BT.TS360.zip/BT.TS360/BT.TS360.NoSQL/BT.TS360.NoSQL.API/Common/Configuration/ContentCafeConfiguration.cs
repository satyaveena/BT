﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace BT.TS360.NoSQL.API.Common.Configuration
{
    public class ContentCafeConfiguration
    {
        public const string NoImageSmallSize = "no-jacket-small.jpg";
        public const string NoImageMediumSize = "no-jacket-medium.jpg";
        public const string NoImageLargeSize = "no-jacket-large.jpg";

        public ContentCafeConfiguration()
        {
        }

        public string AccessKey
        {
            get
            {
                var systemId = string.Empty;
                var setting = AppSettings.CcCloudImageNextgenSystemid;
                if (setting != null)
                {
                    systemId = setting;
                }
                return systemId;
            }
        }

        public string ImageUrlFormat
        {
            get
            {
                string contentCafeImageUrl = string.Empty; ;

                var setting = AppSettings.CcCloudImageConnectionstring;
                if (setting != null)
                {
                    contentCafeImageUrl = setting;
                }

                return contentCafeImageUrl;
            }
        }

        public string GetImageSize(ImageSize imageSize)
        {
            string jacketSize;
            
            switch (imageSize)
            {
                case ImageSize.Medium:
                    jacketSize = AppSettings.CcCloudImage_Size_Medium;
                    break;
                case ImageSize.Large:
                    jacketSize = AppSettings.CcCloudImage_Size_Large;
                    break;
                default:
                    jacketSize = AppSettings.CcCloudImage_Size_Small;
                    break;
            }

            return jacketSize;
        }
    }

    public enum ImageSize
    {
        Small = 0,
        Medium = 1,
        Large = 2
    }

}
