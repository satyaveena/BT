﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Common.Constants
{
    public class SearchConstants
    {
        public class SearchErrorCode
        {
            public const string DUPLICATE_SAVED_SEARCH_NAME_CODE = "001";
            public const string DUPLICATE_SAVED_SEARCH_NAME_DESC = "Duplicate title for saved searches.";
            
        }

        public class AzureSearchFilterDisplay
        {

            public const string PROGRAM = "Program";
            public const string STATUS = "Series/Author Status";
            public const string FORMAT = "Format";
            public const string AUDIENCE = "Series Audience";
            public const string PUBLISHED_DATE = "Last Issue Published/Release";
            public const string SERIES_WITHIN_PROFILE = "Series within a Profile";

            public const string SERIES_WITHIN_PROFILE_KEY = "SeriesWithinProfile";
        }

        public class SiteTerm
        {
            public static readonly string[] SERIES_STATUS = { "Active", "Inactive" };

            public static readonly string[] PROGRAM_TYPES = { "Automatically Yours(AY)", "Children and Teens(CATS)", "Continuations(CONTIN)" };

            public static readonly string[] SERIES_FORMAT = {   "Book & CD- Audio", 
                                                                "Book & CD-ROM", 
                                                                "Book & DVD",
                                                                "CD ROM",
                                                                "eBook",
                                                                "Hardcover",
                                                                "Multiple formats available",
                                                                "Paperback",
                                                                "Reinforced Library",
                                                                "Ringbound",
                                                                "Spiral"};

            
            public static readonly string[] SERIES_AUDIENCE = { "Baby & toddlers Ages 1-2", 
                                                                "Preschool Ages 2-4", 
                                                                "Kindergarten Ages 5-6",
                                                                "Grades 1-2 Ages 6-7",
                                                                "Grades 2-3 Ages 7-8",
                                                                "Grades 3-4 Ages 8-9",
                                                                "Grades 4-6 Ages 9-11",
                                                                "Grades 7-9 Ages 12-14",
                                                                "Grades 10-12 Ages 15+",
                                                                "Older Teens & Adults" };

            public static readonly string[] AREA_OF_INTEREST = {    
                "Fiction",
                "Fiction - Romance",
                "Fiction - Science Fiction",
                "Adult Series",
                "Agricultural and Veterinary Sciences",
                "American Studies (United States and Canada)",
                "Anthropology",
                "Antiques & Collectibles",
                "Archaeology",
                "Architecture",
                "Area Studies",
                "Art",
                "Automotive",
                "Bibliographies General",
                "Biography & Autobiography",
                "Biological Sciences",
                "Business",
                "Business- Careers/Resumes",
                "Business- Personal Finance ",
                "Chemical Sciences",
                "Communication",
                "Computer Technology and Applications",
                "Cooking",
                "Crafts & Hobbies",
                "Earth Sciences",
                "Economics",
                "Education",
                "Engineering",
                "Environmental Science",
                "Gardening",
                "General Works",
                "Geography",
                "Health & Fitness",
                "History General",
                "Home Economics",
                "Humanities",
                "Language and Linguistics",
                "Law and Criminology",
                "Library and Information Science",
                "Literature",
                "Manufacturing",
                "Mathematics",
                "Medical Sciences",
                "Military Science",
                "Music",
                "Occupations and Careers",
                "Performing Arts",
                "Pets",
                "Photography",
                "Physical Sciences",
                "Poetry",
                "Political Sciences",
                "Psychology",
                "Publishing and the Book Trade",
                "Reference- Almanacs",
                "Reference- Directories",
                "Reference- Encyclopedias",
                "Reference- General",
                "Reference- Writing Skills",
                "Religion and Philosophy",
                "Sciences (General and Miscellaneous)",
                "Self-Help",
                "Social Sciences (General and Miscellaneous)",
                "Sociology",
                "Spanish and Bilingual",
                "Sports Recreation and Physical Education",
                "Study Aids- College Guides",
                "Study Aids- Financial Aid",
                "Study Aids- General",
                "Study Aids- Test Preparation",
                "Technology",
                "Transportation",
                "Travel- Africa",
                "Travel and Tourism",
                "Travel- Asia",
                "Travel- Australia",
                "Travel- Central America",
                "Travel- Europe",
                "Travel- Middle East",
                "Travel- North America",
                "Travel- South America",
                "Travel- US Midwest",
                "Travel- US New England",
                "Travel- US Northeast",
                "Travel- US Northwest",
                "Travel- US South",
                "Travel- US Southeast",
                "Travel- US Southwest",
                "Travel- US West",
                "Urban and Regional Planning",
                "Visual Arts",
                "Awards",
                "Children's Fiction",
                "Children's Non-Fiction",
                "Easy Readers",
                "Picture Books",
                "Graphic Novels",
                "Inspirational",
                "Large Print",
                "Print and Ebook",
                "Spoken Word Audio",
                "Teen Fiction",
                "Teen Nonfiction" }; // end AREA_OF_INTEREST
        }

        public class PublicationDateRange
        {
            public const string PREV_30_DAYS = "Within previous 30 Days";
            public const string PREV_60_DAYS = "Within previous 60 Days";
            public const string PREV_90_DAYS = "Within previous 90 Days";
            public const string PREV_180_DAYS = "Within previous 180 Days";

            public const string NEXT_30_DAYS = "Within next 30 Days";
            public const string NEXT_60_DAYS = "Within next 60 Days";
            public const string NEXT_90_DAYS = "Within next 90 Days";
            public const string NEXT_180_DAYS = "Within next 180 Days";
        }
    }
}