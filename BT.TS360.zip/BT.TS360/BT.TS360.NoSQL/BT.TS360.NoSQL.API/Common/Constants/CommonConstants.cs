﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Common.Constants
{
    public class ReportCodeConstants
    {
        public const string NOT_YET_PUBLISHED = "NOT YET PUBLISHED";

        public const string PUBLISHER_OUT_OF_STOCK = "PUBLISHER OUT OF STOCK";

        public const string SUPPLIER_OUT_OF_STOCK = "SUPPLIER OUT OF STOCK";

        public const string PRODUCT_CANCELLED = "PRODUCT CANCELLED";

        public const string APPLY_DIRECT = "APPLY DIRECT";

        public const string OUT_OF_PRINT = "OUT OF PRINT";

        public const string PERMANENTLY_OUT_OF_STOCK = "PERMANENTLY OUT OF STOCK";

        public const string PUBLICATION_CANCELLED = "PUBLICATION CANCELLED";

        public const string PUBLISHER_OUT_OF_BUSINESS = "PUBLISHER OUT OF BUSINESS";

        public const string PUBLISHER_OUT_OF_STOCK_INDEFINITELY = "PUBLISHER OUT OF STOCK INDEFINITELY";

        public const string UNABLE_TO_LOCATE_PUBLISHER = "UNABLE TO LOCATE PUBLISHER";
    }

    public class WarehouseConstants
    {
        public const string REN = "REN";
        public const string COM = "COM";
        public const string MOM = "MOM";
        public const string SOM = "SOM";
        public const string RNO = "RNO";
        public const string VIM = "VIM";
        public const string VIE = "VIE";
        public const string SUP = "VIP";
        public const string VII = "VII"; // Ingram
    }

    public class ProductFormatConstants
    {
        public const string Book_PreLoaded_Audio_Player = "Pre-Loaded Audio Player";
    }

    public class ProductMerchandiseCategoryConstants
    {
        public const string PRINT_ON_DEMAND = "PRINT ON DEMAND";
        public const string TEXTSTREAM_PRINT_ON_DEMAND = "TEXTSTREAM PRINT ON DEMAND";
    }

    public class MongoDBFields
    {
        public const string _ID = "_id";
        public const string EXTERNAL_ID = "ExternalID";
        public const string PROCESSING_STATUS = "ProcessingStatus";
        public const string VALIDATION_REQUEST = "ValidationRequest";
        public const string VALIDATION_RESPONSE = "ValidationResponse";
        public const string ORDER_RESPONSE = "OrderResponse";
    }

    public class ILSProcessingStatusConstants
    {
        public const string VALIDATION_RESPONSE = "Validation Response";
        public const string VALIDATION_FAILED = "Validation Failed";
        public const string ORDERING_VALIDATION_FAILED = "Ordering Validation Failed";
        public const string ORDERING_RESPONSE = "Ordering Response";
        public const string ORDERING_RESULT_RESPONSE = "Ordering Result Response";
    }
}