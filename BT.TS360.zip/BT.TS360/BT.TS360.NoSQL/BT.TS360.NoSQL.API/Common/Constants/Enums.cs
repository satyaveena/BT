﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Common.Constants
{
    public enum ModifyNoteOption { APPEND = 1, REPLACE = 2, REMOVE = 3 }   
}