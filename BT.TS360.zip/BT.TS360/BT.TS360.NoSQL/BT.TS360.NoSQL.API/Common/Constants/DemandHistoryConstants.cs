﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BT.TS360.NoSQL.API.Common.Constants
{
    public class DemandHistoryErrorCode
    {
        public const string MISSING_BTKEY_CODE = "1";

        public const string PRODUCT_NOT_FOUND = "2";
    }
}