﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.API.Common.Constants
{
    public class CartInventoryFacets
    {
        public const string Not_Available_for_Shipping = "Not_Available_for_Shipping";

        public const string Available_in_Primary_Warehouse = "Available_in_Primary_Warehouse";

        public const string Available_in_Secondary_Warehouse = "Available_in_Secondary_Warehouse";

        public const string Available_in_Other_Warehouses = "Available_in_Other_Warehouses";

        public const string Available_in_VIP_warehouses = "Available_in_VIP_warehouses";
    }

    public class CartInventoryFacetsErrorCode
    {
        public const string EMPTY_BTKEY_CODE = "1";

        public const string INVALID_LE_INDICATOR_CODE = "2";

        public const string INVALID_VIP_ENABLED_CODE = "3";

        public const string INVALID_MARKET_TYPES_CODE = "4";

        public const string EMPTY_COUNTRY_CODE = "5";

        public const string NULL_REQUEST = "6";
    }
}
