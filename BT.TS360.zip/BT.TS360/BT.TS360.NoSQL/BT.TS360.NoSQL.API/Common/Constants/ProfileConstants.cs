﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Models;

namespace BT.TS360.NoSQL.API.Common.Constants
{

    public class ProfileType
    {
        public const string Notification = "Notification";
        public const string AutoShipment = "Auto Shipment";
    }
    
}