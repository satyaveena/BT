﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Models;

namespace BT.TS360.NoSQL.API.Common.Constants
{
    public class InventoryDemandGeneral
    {
        public const int EBOOK_INVENTORY_IN_STOCK_REQUEST = 9999;
    }

    public class InventoryDemandErrorCode
    {
        public const string EMPTY_BTKEY_CODE = "1";

        public const string INVALID_LE_INDICATOR_CODE = "2";

        public const string EMPTY_WAREHOUSES_CODE = "3";

        public const string INVALID_VIP_ENABLED_CODE = "4";

        public const string INVALID_MARKET_TYPES_CODE = "5";

        public const string EMPTY_COUNTRY_CODE = "6";
    }

    public class InventoryStatus
    {
        public const string AVAILABLE = "Available";

        public const string INSTOCK = "In Stock";

        public const string AvailableToBackOrder = "Available to Backorder";

        public const string AvailableToPreOrder = "Available to Preorder";

    }

    public class ProductCodeConstants
    {
        public const string BOOK = "Book";

        public const string EBOOK = "EBook";

        public const string MUSIC = "Music";

        public const string MOVIE = "Movie";
    }
    
}