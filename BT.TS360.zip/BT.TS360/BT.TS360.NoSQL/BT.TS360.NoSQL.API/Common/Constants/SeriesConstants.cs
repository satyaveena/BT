﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Models;

namespace BT.TS360.NoSQL.API.Common.Constants
{

    public class ChangeRequestSortOption
    {
        public const string DateRequested = "RedundantSeriesInformation.Name";

        public const string RequestedModification = "RequestType";

        public const string SeriesName = "FootprintInformation.CreatedDate";
    }

    public class ChangeRequestStatus
    {
        public const string Open = "New";

        public const string InProgress = "In Process";

        //public const string OnHold = "On Hold";

        //public const string Done = "Done";

        public const string Deleted = "Deleted";

        public const string Loaded = "Loaded";

        public const string Removed = "Removed";

        public const string Completed = "Completed";
    }

    public class ChangeRequestChangeType
    {
        public const string ProfiledSeries = "ProfiledSeries";

        public const string Profile = "Profile";
    }

    public class ChangeRequestRequestType
    {

        public const string DeleteSeries = "Delete"; // "Delete Series"
        public const string ModifySeries = "Modify"; // "Modify Series"
        public const string DisableProfile = "Disable Profile";
        public const string CopyProfile = "Copy Profile";
        public const string DeleteProfile = "Delete Profile";
        public const string NewProfile = "New Profile";
        public const string ModifyUsers = "Modify Users";
        public const string AddSeries = "Add"; //"Add Series";
    }


    public class RequestQueueFilerType
    {

        public const string AccountRepName = "AccountRepName"; 
        public const string RequestedBy = "RequestedBy";
        public const string ProfileName = "ProfileName";
        public const string AccountNumber = "AccountNumber";
        public const string OrganizationName = "OrganizationName";
      
    }

    public class PendingModificationFilerType
    {

        public const string SeriesName = "SeriesName";
        public const string SeriesID = "SeriesId";
        public const string RequestedBy = "RequestedBy";
        public const string Frequency = "Frequency";
        public const string ProfileName = "ProfileName";
        public const string AccountNumber = "AccountNumber";
        public const string RequestStatus = "RequestStatus";

    }
}