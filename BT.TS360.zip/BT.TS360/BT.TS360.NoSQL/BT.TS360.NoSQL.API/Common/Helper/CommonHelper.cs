﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Constants;
using System.Net.Mail;
using BT.TS360.NoSQL.API.Services;

namespace BT.TS360.NoSQL.API.Common.Helper
{
    public static class CommonHelper
    {
        public static string GetHeaderValueFromRequest(HttpRequestMessage request, string headerKey)
        {
            IEnumerable<string> headerValues = request.Headers.GetValues(headerKey);
            return headerValues.FirstOrDefault();
        }

        public static List<string> GetChangeRequestSystemStatuses()
        {
            var SystemStatusList = new List<string>();
            SystemStatusList.Add(ChangeRequestStatus.Deleted);
            SystemStatusList.Add(ChangeRequestStatus.Loaded);
            SystemStatusList.Add(ChangeRequestStatus.Removed);
            return SystemStatusList;
        }

        public static List<string> GetChangeRequestPendingStatuses()
        {
            var SystemStatusList = new List<string>();
            SystemStatusList.Add(ChangeRequestStatus.Open);
            SystemStatusList.Add(ChangeRequestStatus.InProgress);
            //SystemStatusList.Add(ChangeRequestStatus.OnHold);
            //SystemStatusList.Add(ChangeRequestStatus.Done);
            return SystemStatusList;
        }


        public static List<string> GetChangeRequestDisplayStatuses()
        {
            var SystemStatusList = new List<string>();
            SystemStatusList.Add(ChangeRequestStatus.Open);
            SystemStatusList.Add(ChangeRequestStatus.InProgress);
            SystemStatusList.Add(ChangeRequestStatus.Removed);
            SystemStatusList.Add(ChangeRequestStatus.Completed);
            return SystemStatusList;
        }

        public static void SendMissingSalesTerritoryEmail()
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                var emailToList = AppSettings.MissingSalesTerritoryEmailTo.Split(';');
                foreach (var emailTo in emailToList)
                {
                    if (!string.IsNullOrEmpty(emailTo))
                        mail.To.Add(emailTo);
                }
                mail.Subject = AppSettings.StandingOrdersEmailPrefix + "Error – Request sent to Queue without Territory Assignment";
                mail.Body = "A request was sent to the queue without a territory assignment. To view request details please remove all territory filters.";

                client.Send(mail);
            }
            catch (Exception exception)
            {
                var logger = new LoggerService();
                logger.LogError(exception, "NoSQL SendMissingSalesTerritoryEmail", string.Format("Message: {0}, Stack Trace: {1}", exception.Message, exception.StackTrace));
            }
        }

        public static string RemoveSpecialCharacters(string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '?' || c == '*' || c == ' ')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }
    }

    public static class StringCipher
    {
        // This constant string is used as a "salt" value for the PasswordDeriveBytes function calls.
        // This size of the IV (in bytes) must = (keysize / 8).  Default keysize is 256, so the IV must be
        // 32 bytes long.  Using a 16 character string here gives us 32 bytes when converted to a byte array.
        private static readonly byte[] initVectorBytes = Encoding.ASCII.GetBytes(AppSettings.PassPhraseForAuthentication);

        // This constant is used to determine the keysize of the encryption algorithm.
        private const int keysize = 256;

        public static string Encrypt(string plainText, string passPhrase)
        {
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            using (var password = new PasswordDeriveBytes(passPhrase, null))
            {
                byte[] keyBytes = password.GetBytes(keysize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.Mode = CipherMode.CBC;
                    using (ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes))
                    {
                        using (var memoryStream = new MemoryStream())
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                            {
                                cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                byte[] cipherTextBytes = memoryStream.ToArray();
                                return Convert.ToBase64String(cipherTextBytes);
                            }
                        }
                    }
                }
            }
        }

        public static string Decrypt(string cipherText, string passPhrase)
        {
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            using (var password = new PasswordDeriveBytes(passPhrase, null))
            {
                byte[] keyBytes = password.GetBytes(keysize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.Mode = CipherMode.CBC;
                    using (ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes))
                    {
                        using (var memoryStream = new MemoryStream(cipherTextBytes))
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                                int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                                return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
                            }
                        }
                    }
                }
            }
        }
    }

    public static class MongoDbHelper
    {
        public static DateTime? ToNullableDateTime(object value)
        {
            if (string.IsNullOrEmpty(value.ToString())) return null;

            DateTime dt;
            if (DateTime.TryParse(value.ToString(), out dt))
            {
                return dt;
            }
            return null;
        }

        public static DateTime ToDateTime(string value)
        {
            DateTime dt;
            return DateTime.TryParse(value, out dt) ? dt : DateTime.Now;
        }
    }

    public class ContentCafeHelper
    {
        public static string GetJacketImageUrl(string identifierValue, ImageSize imageSize, bool hasJacket = true)
        {
            string imgUrl;

            if (hasJacket)
            {
                var ccConfiguration = new ContentCafeConfiguration();
                var jacketSize = ccConfiguration.GetImageSize(imageSize);

                imgUrl = string.Format(ccConfiguration.ImageUrlFormat, ccConfiguration.AccessKey, identifierValue, jacketSize);

            }
            else
            {
                imgUrl = "/_layouts/IMAGES/CSDefaultSite/assets/images/common/";
                switch (imageSize)
                {
                    case ImageSize.Medium:
                        imgUrl += ContentCafeConfiguration.NoImageMediumSize;
                        break;
                    case ImageSize.Large:
                        imgUrl += ContentCafeConfiguration.NoImageLargeSize;
                        break;
                    default:
                        imgUrl += ContentCafeConfiguration.NoImageSmallSize;
                        break;
                }
            }

            return imgUrl;
        }
    }

}