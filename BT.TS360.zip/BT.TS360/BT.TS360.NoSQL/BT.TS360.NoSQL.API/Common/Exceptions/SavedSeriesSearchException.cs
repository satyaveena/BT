﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using BT.TS360.NoSQL.API.Common.Constants;

namespace BT.TS360.NoSQL.API.Common.Exceptions
{
    public class SavedSeriesSearchException : Exception
    {
        public SavedSeriesSearchException() { }
        
        public string ErrorCode {
            get { return SearchConstants.SearchErrorCode.DUPLICATE_SAVED_SEARCH_NAME_CODE; }
        }

        public string ErrorMessage
        {
            get { return SearchConstants.SearchErrorCode.DUPLICATE_SAVED_SEARCH_NAME_DESC; }
        }
    }

    
}