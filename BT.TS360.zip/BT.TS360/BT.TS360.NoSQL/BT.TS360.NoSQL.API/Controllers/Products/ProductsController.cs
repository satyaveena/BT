﻿using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Services.StandingOrders;
using BT.TS360.NoSQL.Data.Common.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace BT.TS360.NoSQL.API.Controllers.Products
{
    public class ProductsController : ApiController
    {
        private readonly ProductService _productService;

        public ProductsController()
        {
            this._productService = new ProductService();
        }

        [HttpPost]
        [Route("products/NewReleaseCalendarProductInfo")]
        public async Task<NoSqlServiceResult<List<NewReleaseCalendarProductInfo>>> GetNewReleaseCalendarProductInfo([FromBody]NewReleaseCalendarProductInfoRequest newReleaseCalendarProductInfoRequest)
        {
            return await _productService.GetNewReleaseCalendarProductInfoBtKeys(newReleaseCalendarProductInfoRequest.BTKeys);
        }

        [HttpPost]
        [Route("products/DiversityTopicsAnalyzation")]
        public async Task<NoSqlServiceResult<List<DiversityTopic>>> DiversityTopicsAnalyzation([FromBody]DiversityTopicsAnalyzationRequest diversityTopicsAnalyzationRequest)
        {
            if (diversityTopicsAnalyzationRequest == null)
            {
                return new NoSqlServiceResult<List<DiversityTopic>> { Status = NoSqlServiceStatus.Fail, Data = new List<DiversityTopic>(), ErrorMessage = "Request Required" };
            }

            if (diversityTopicsAnalyzationRequest.BTKeys == null || diversityTopicsAnalyzationRequest.BTKeys.Count == 0)
            {
                return new NoSqlServiceResult<List<DiversityTopic>> { Status = NoSqlServiceStatus.Fail, Data = new List<DiversityTopic>(), ErrorMessage = "BTKey Required" };
            }
            return await _productService.GetDiversityTopicsAnalyzation(diversityTopicsAnalyzationRequest.BTKeys);
        }
    }
}
