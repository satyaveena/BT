﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Services;

namespace BT.TS360.NoSQL.API.Controllers
{
    public class CartFacetsController : ApiController
    {
        private static readonly CartFacetsService cartInventoryFacetsService = new CartFacetsService(AppSettings.MongoDBConnectionString);

        // POST api/<controller>
        public NoSqlServiceResult<CartFacetsResponse> Post([FromBody] CartFacetsRequest request)
        {
            return cartInventoryFacetsService.GetCartFacets(request);
        }
    }
}
