﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using BT.TS360.NoSQL.API.Services;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Common.Configuration;

namespace BT.TS360.NoSQL.API.Controllers
{
    public class DemandHistoryController : ApiController
    {
        private static readonly DemandHistoryService demandHistoryService = new DemandHistoryService(AppSettings.MongoDBConnectionString);

        // GET api/<controller>
        public NoSqlServiceResult<DemandHistoryResponse> Get(DemandHistoryRequest demandHistoryRequest)
        {
            return demandHistoryService.GetDemandHistory(demandHistoryRequest);
        }

        // POST api/<controller>
        public NoSqlServiceResult<DemandHistoryResponse> Post([FromBody] DemandHistoryRequest demandHistoryRequest)
        {
            return demandHistoryService.GetDemandHistory(demandHistoryRequest);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}