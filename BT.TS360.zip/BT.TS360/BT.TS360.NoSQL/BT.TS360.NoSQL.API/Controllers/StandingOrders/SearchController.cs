﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;

using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Services.StandingOrders;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;


namespace BT.TS360.NoSQL.API.Controllers.StandingOrders
{
    public class SearchController : ApiController
    {

        private static SearchService searchService = new SearchService();
        private static SeriesService seriesService = new SeriesService();

        [Route("standingorders/search")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: standingorders/search/list
        [HttpGet]
        [Route("standingorders/search/list")]
        public async Task<NoSqlServiceResult<SearchSavedSearchResponse>> List([FromUri]SearchSavedSearchRequest savedSearchRequest)
        {
            var data = await searchService.GetUserSavedSearches(savedSearchRequest);
            return data;

        }

        [HttpPost]
        [Route("standingorders/search/savedsearch/delete")]
        public async Task<NoSqlServiceResult<bool>> DeleteSavedSearch([FromBody]SearchSavedSearchRequest searchActionRequest)
        {
            var noSqlServiceResult = await searchService.DeleteSavedSearch(searchActionRequest);
            return noSqlServiceResult;
        }

        [HttpPost]
        [Route("standingorders/search/save")]
        public async Task<NoSqlServiceResult<bool>> SaveSavedSearch([FromBody]SaveSearchesRequest saveSearchesRequest)
        {
            var noSqlServiceResult = await searchService.AddSaveSearches(saveSearchesRequest);
            return noSqlServiceResult;
        }

        // GET: standingorders/search
        [HttpGet]
        [Route("standingorders/search/authorseries")]
        public async Task<NoSqlServiceResult<SeriesListResponse>> AuthorSeries([FromUri]AzureSearchRequest searchRequest)
        {
            var data = await searchService.AzureSearch(searchRequest);
            
            //var data = await seriesService.GetSeriesLists(seriesListRequest);
            return data;

        }

        [HttpPost]
        [Route("standingorders/search/submitseriesinquiry")]
        public async Task<NoSqlServiceResult<bool>> SubmitSeriesInquiry([FromBody]EmailSeriesInquiryRequest emailSeriesInquiryRequest)
        {
            var data = await searchService.EmailSeriesInquiryRequest(emailSeriesInquiryRequest);

            return data;
        }
    }
}
