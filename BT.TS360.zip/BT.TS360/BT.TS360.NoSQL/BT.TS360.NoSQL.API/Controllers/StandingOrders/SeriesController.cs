﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;

using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Services.StandingOrders;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.Data.Common.Models;


namespace BT.TS360.NoSQL.API.Controllers.StandingOrders
{
    public class SeriesController : ApiController
    {
        private static readonly SeriesService seriesService = new SeriesService();

        // TEST
        // GET: standingorders/series
        [Route("standingorders/series")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: standingorders/series/1
        /*[Route("standingorders/series/{id}")]
        public NoSqlServiceResult<SeriesResponse> Get(string id)
        {
            return seriesService.GetSeries(id);

        }*/

        // GET: standingorders/series/profile/1
        [HttpGet]
        [Route("standingorders/series/profile/{profileID}")]
        public async Task<NoSqlServiceResult<SeriesProfileResponse>> Profile(string profileID)
        {
            //return seriesService.GetSeriesProfile(profileID);

            var data = await seriesService.GetSeriesProfile(profileID);
            return data;

        }

        // GET: standingorders/series/list
        [HttpGet]
        [Route("standingorders/series/list")]
        public async Task<NoSqlServiceResult<SeriesListResponse>> List([FromUri]SeriesListRequest seriesListRequest)
        {
            //return seriesService.BuildSampleSeriesLists(profileID);

            var data = await seriesService.GetSeriesListsBySearch(seriesListRequest);
            return data;

        }

        // GET: standingorders/series/related
        [HttpGet]
        [Route("standingorders/series/related")]
        public async Task<NoSqlServiceResult<SeriesListResponse>> Related([FromUri]List<string> relatedSeriesIDs)
        {

            var data = await seriesService.GetRelatedSeries(relatedSeriesIDs);
            return data;

        }

        // GET: standingorders/series/title
        [HttpGet]
        [Route("standingorders/series/title/{seriesID}")]
        public async Task<NoSqlServiceResult<SeriesTitleResponse>> Title(string seriesID)
        {
            //return seriesService.BuildSampleSeriesLists(profileID);

            var data = await seriesService.GetSeriesTitle(seriesID);
            return data;

        }

        // POST: standingorders/series
        [Route("standingorders/series")]
        public void Post([FromBody]string value)
        {
        }

        [HttpGet]
        [Route("standingorders/pendingModifications")]
        public async Task<NoSqlServiceResult<PendingModificationResponse>> GetPendingModifications([FromUri]PendingModificationRequest pendingModificationRequest)
        {
            return await seriesService.GetPendingModifications(pendingModificationRequest);
        }

        [HttpGet]
        [Route("standingorders/pendingQueueOrganizationCount/{orgId}")]
        public async Task<NoSqlServiceResult<long>> GetPendingModificationsOrgCount(string orgId)
        {
            var data = await seriesService.GetPendingModificationsCountByOrg(orgId);
            return data;

        }

        [HttpGet]
        [Route("standingorders/pendingQueueFilter")]
        public async Task<NoSqlServiceResult<ChangeRequestFilterDataResponse>> pendingQueueFilterList([FromUri]ChangeRequestFilterDataRequest changeRequestFilterDataRequest)
        {
            return await seriesService.GetPendingModifications(changeRequestFilterDataRequest);
        }

        [HttpPost]
        [Route("standingorders/series/RequestStatusQueue")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> GetRequestStatusQueue([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await seriesService.GetRequestStatusQueue(requestStatusQueueRequest);
        }

        [HttpPost]
        [Route("standingorders/series/RequestQueueAccountRepNameList")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> RequestQueueAccountRepNameList([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await seriesService.GetRequestStatusQueue(requestStatusQueueRequest, Common.Constants.RequestQueueFilerType.AccountRepName);
        }

        [HttpPost]
        [Route("standingorders/series/RequestQueueRequestedByList")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> RequestQueueRequestedByList([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await seriesService.GetRequestStatusQueue(requestStatusQueueRequest, Common.Constants.RequestQueueFilerType.RequestedBy);
        }

        [HttpPost]
        [Route("standingorders/series/RequestQueueProfileNameList")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> RequestQueueProfileNameList([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await seriesService.GetRequestStatusQueue(requestStatusQueueRequest, Common.Constants.RequestQueueFilerType.ProfileName);
        }

        [HttpPost]
        [Route("standingorders/series/RequestQueueAccountNumberList")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> RequestQueueAccountNumberList([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await seriesService.GetRequestStatusQueue(requestStatusQueueRequest, Common.Constants.RequestQueueFilerType.AccountNumber);
        }

        [HttpPost]
        [Route("standingorders/series/RequestQueueOrgNameList")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> RequestQueueOrgNameList([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await seriesService.GetRequestStatusQueue(requestStatusQueueRequest, Common.Constants.RequestQueueFilerType.OrganizationName);
        }

        [HttpPost]
        [Route("standingorders/series/UpdateChangeRequest")]
        public async Task<NoSqlServiceResult<bool>> UpdateChangeRequest([FromBody]ChangeRequestUpdateRequest changeRequestUpdateRequest)
        {
            return await seriesService.UpdateChangeRequest(changeRequestUpdateRequest);

        }

        // GET: standingorders/series/id
        [HttpGet]
        [Route("standingorders/series/{id}")]
        public async Task<NoSqlServiceResult<SeriesTitle>> Get(string id, string userSeriesCheckDup)
        {
            var data = await seriesService.GetSeriesDetailsById(id, !string.IsNullOrEmpty(userSeriesCheckDup));
            return data;
        }

        [HttpPost]
        [Route("standingorders/series/disable")]
        public async Task<NoSqlServiceResult<List<string>>> Disable([FromBody]SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = await seriesService.CreateDisableSeriesRequest(seriesActionRequest);
            return noSqlServiceResult;
        }

        [HttpPost]
        [Route("standingorders/series/delete")]
        public async Task<NoSqlServiceResult<List<string>>> Delete([FromBody]SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = await seriesService.CreateDeleteSeriesRequest(seriesActionRequest);
            return noSqlServiceResult;
        }

        [HttpPost]
        [Route("standingorders/series/modifynotes")]
        public async Task<NoSqlServiceResult<List<ModifyNotesResponse>>> ModifyNotes([FromBody]SeriesActionRequest seriesActionRequest)
        {
            var noSqlServiceResult = await seriesService.ModifySeriesNotes(seriesActionRequest);//await seriesService.CreateSeriesModifyNotesRequest(seriesActionRequest);
            return noSqlServiceResult;
        }

        [HttpPost]
        [Route("standingorders/series/EditProfiledSeries")]
        public async Task<NoSqlServiceResult<bool>> EditProfiledSeries([FromBody]EditProfiledSeriesRequest editProfiledSeriesRequest)
        {
            return await seriesService.EditProfiledSeries(editProfiledSeriesRequest);
        }

        [HttpPost]
        [Route("standingorders/series/EditMultiProfiledSeries")]
        public async Task<NoSqlServiceResult<List<string>>> EditMultiProfiledSeries([FromBody]EditProfiledSeriesListRequest editProfiledSeriesListRequest)
        {
            var noSqlServiceResult = new NoSqlServiceResult<List<string>> { Status = NoSqlServiceStatus.Success };
            List<string> updatedSeriesIDs = new List<string>();

            for (int p = 0; p < editProfiledSeriesListRequest.EditProfiledSeriesRequests.Length; p++ )
            {
                await EditProfiledSeries(editProfiledSeriesListRequest.EditProfiledSeriesRequests[p]);
                updatedSeriesIDs.Add(editProfiledSeriesListRequest.EditProfiledSeriesRequests[p].SeriesId);
            }

            noSqlServiceResult.Data = updatedSeriesIDs;

            return noSqlServiceResult;
        }

        [HttpGet]
        [Route("standingorders/series/duplicateSeries")]
        public async Task<NoSqlServiceResult<DuplicateSeriesResponse>> GetDuplicateSeries([FromUri]DuplicateSeriesRequest duplicateSeriesRequest)
        {
            return await seriesService.GetDuplicateSeries(duplicateSeriesRequest);
        }

        [HttpGet]
        [Route("standingorders/series/duplicateSeriesDetails")]
        public async Task<NoSqlServiceResult<DuplicateSeriesDetailsResponse>> GetDuplicateSeriesDetails([FromUri]DuplicateSeriesDetailsRequest duplicateSeriesDetailsRequest)
        {
            return await seriesService.GetDuplicateSeriesDetails(duplicateSeriesDetailsRequest);
        }

        [HttpPost]
        [Route("standingorders/series/emailseries")]
        public async Task<NoSqlServiceResult<bool>> EmailSeries([FromBody]EmailSeriesRequest emailSeriesRequest)
        {
            return await seriesService.EmailSeries(emailSeriesRequest);
        }

        [HttpGet]
        [Route("standingorders/series/duplicateSeriesTitles")]
        public async Task<NoSqlServiceResult<DuplicateSeriesTitleResponse>> GetDuplicateSeriesIdByTitle([FromUri]DuplicateSeriesTitleRequest duplicateSeriesTitleRequest)
        {
            return await seriesService.GetDuplicateSeriesIdByTitle(duplicateSeriesTitleRequest);
        }

        [HttpGet]
        [Route("standingorders/series/duplicateSeriesDetailsByTitle")]
        public async Task<NoSqlServiceResult<List<ProfiledSeries>>> GetDuplicateSeriesDetailsByTitle([FromUri]string duplicateProfiledSeriesIdList)
        {
            return await seriesService.GetDuplicateSeriesDetailsByTitle(duplicateProfiledSeriesIdList);
        }

        [HttpPost]
        [Route("standingorders/series/etsDuplicateSeriesDetails")]
        public async Task<NoSqlServiceResult<List<ProfiledSeries>>> GetEtsDuplicateSeriesDetails(DuplicateSeriesTitleRequest duplicateSeriesTitleRequest)
        {
            return await seriesService.GetEtsDuplicateSeriesDetails(duplicateSeriesTitleRequest);
        }

        [HttpPost]
        [Route("standingorders/series/addGrids")]
        public async Task<NoSqlServiceResult<List<string>>> AddGridsFromTemplate([FromBody]AddGridRequest addGridRequest)
        {
            return await seriesService.AddGridsFromTemplate(addGridRequest);
        }

        [HttpGet]
        [Route("standingorders/series/getPurchaseOrderDetails")]
        public async Task<NoSqlServiceResult<List<PurchaseOrderDetails>>> GetPurchaseOrderDetails([FromUri]List<string> profiledSeriesIdList)
        {
            return await seriesService.GetPurchaseOrderDetails(profiledSeriesIdList);
        }

        [HttpGet]
        [Route("standingorders/series/searchPurchaseOrderDetails")]
        public async Task<NoSqlServiceResult<List<PurchaseOrderDetails>>> SearchPurchaseOrderDetails(string profileID, string seriesID)
        {
            return await seriesService.GetPurchaseOrderDetails(profileID, seriesID);
        }

        [HttpGet]
        [Route("standingorders/series/getPendingProfiles")]
        public async Task<NoSqlServiceResult<List<string>>> GetPendingProfileList(string organizationID, string seriesID)
        {
            return await seriesService.GetPendingProfiles(organizationID, seriesID);
        }


        [HttpPost]
        [Route("standingorders/series/SaveBatchExportToBackground")]
        public async Task<NoSqlServiceResult<bool>> SaveBatchExportToBackground(BatchExportBackgroundRequest batchExportBackgroundRequest)
        {
            return await seriesService.SaveBatchExportToBackground(batchExportBackgroundRequest);
        }

        [HttpPost]
        [Route("standingorders/series/RequestStatusBatchExport")]
        public async Task<NoSqlServiceResult<BatchExportRealtimeResponse>> RequestStatusBatchExport([FromBody]BatchExportRequest batchExportRequest)
        {
            return await seriesService.RequestStatusBatchExport(batchExportRequest);
        }

        [HttpGet]
        [Route("standingorders/series/checkIfAddSeriesRequestExists")]
        public async Task<NoSqlServiceResult<bool>> CheckIfAddSeriesRequestExists(string organizationID, string profileID, string seriesID)
        {
            return await seriesService.CheckIfAddSeriesRequestExists(organizationID, profileID, seriesID);
        }
    }
}
