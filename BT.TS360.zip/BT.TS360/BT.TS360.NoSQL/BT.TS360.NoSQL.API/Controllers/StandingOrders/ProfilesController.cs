﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BT.TS360.NoSQL.API.Common;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.StandingOrders;
using BT.TS360.NoSQL.API.Services.StandingOrders;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data;

namespace BT.TS360.NoSQL.API.Controllers.StandingOrders
{
    public class ProfilesController : ApiController
    {
        private static readonly ProfileService _profileService = new ProfileService();

        [HttpGet]
        [Route("standingorders/profiles")]
        public async Task<NoSqlServiceResult<ProfilesResponse>> GetProfiles([FromUri]SearchProfilesRequest profilesRequest)
        {
            //CheckingAuthentication();

            if (profilesRequest == null || string.IsNullOrEmpty(profilesRequest.OrgId))
            {
                var response = new NoSqlServiceResult<ProfilesResponse>
                {
                    Status = NoSqlServiceStatus.Fail,
                    ErrorMessage = "Profiles Request and Org Id is requred.",
                    Data = null
                };
                return response;
            }

            return await _profileService.GetProfilesBySearch(profilesRequest);
        }

        [HttpGet]
        [Route("standingorders/profiles/{id}")]
        public async Task<NoSqlServiceResult<ProfileDetailsResponse>> Get(string id)
        {
            //CheckingAuthentication();

            if (!string.IsNullOrEmpty(id)) return await _profileService.GetProfileById(id);

            var response = new NoSqlServiceResult<ProfileDetailsResponse>
                           {
                               Status = NoSqlServiceStatus.Fail,
                               ErrorMessage = "Profile ID is requred.",
                               Data = null
                           };
            return response;
        }

        [HttpPost]
        [Route("standingorders/profiles/updateprofile")]
        public async Task<NoSqlServiceResult<bool>> UpdateProfile([FromBody]ProfileRequest profile)
        {
            //CheckingAuthentication();

            if (profile == null)
            {
                profile = GetProfileFromRequest(Request);
            }

            return await _profileService.UpdateProfile(profile);
        }

        [HttpPost]
        [Route("standingorders/profiles/createprofile")]
        public async  Task<NoSqlServiceResult<bool>> PostProfile([FromBody]ProfileRequest profile)
        {
            //CheckingAuthentication();

            if (profile == null)
            {
                profile = GetProfileFromRequest(Request);
            }
            return await _profileService.CreateProfile(profile);
        }

        private ProfileRequest GetProfileFromRequest(HttpRequestMessage request)
        {
            if (request == null || request.RequestUri == null) return null;

            var nameValueColl = request.RequestUri.ParseQueryString();

            if(nameValueColl == null || nameValueColl.Count == 0) return null;

            var updatedBy = nameValueColl["CreatedBy"] ?? nameValueColl["TsUserName"] ?? "";

            var profile = new ProfileRequest
                          {
                              ProfileId = nameValueColl["ProfileId"],
                              OrgId = nameValueColl["OrgId"],
                              OrgName = nameValueColl["OrgName"],
                              ProfileName = nameValueColl["ProfileName"],
                              ProfileType = nameValueColl["ProfileType"],
                              CatalogAndProcessing = bool.Parse(nameValueColl["CatalogAndProcessing"]),
                              ContactName = nameValueColl["ContactName"],
                              Phone = nameValueColl["Phone"],
                              Fax = nameValueColl["Fax"],
                              Email = nameValueColl["Email"],
                              CreatedBy = updatedBy,
                              UpdatedBy = updatedBy,
                              CreatedDate = MongoDbHelper.ToDateTime(nameValueColl["CreatedDate"])
                          };

            if (!string.IsNullOrEmpty(nameValueColl["Areas"]))
            {
                profile.AreasOfInterest = nameValueColl["Areas"].Split(',').ToList();
            }

            return profile;
        }

        [HttpGet]
        [Route("standingorders/profiles/getareas")]
        public NoSqlServiceResult<List<AreaResponse>> Get()
        {
            //CheckingAuthentication();

            return _profileService.GetAreas();
        }

        [HttpGet]
        [Route("standingorders/profilelist/{organizationId}")]
        public async Task<NoSqlServiceResult<ProfileListResponse>> GetProfileList(string organizationId)
        {
            return await _profileService.GetProfileListByOrg(organizationId);
        }

        [HttpGet]
        [Route("standingorders/requestmasterorderstatus/")]
        public NoSqlServiceResult<bool> RequestMasterOrderStatus([FromUri]MasterOrderStatusRequest masterOrderStatusRequest)
        {
            return _profileService.RequestMasterOrderStatus(masterOrderStatusRequest);
        }

        [HttpGet]
        [Route("standingorders/requestprofileorderstatus/")]
        public NoSqlServiceResult<bool> RequestProfileOrderStatus([FromUri]ProfileOrderStatusRequest profileOrderStatusRequest)
        {
            return _profileService.RequestProfileOrderStatus(profileOrderStatusRequest);
        }

        [HttpGet]
        [Route("standingorders/requestmasterprofilereport/")]
        public async Task<NoSqlServiceResult<bool>> RequestMasterProfileReport([FromUri]MasterProfileReportRequest masterProfileReportRequest)
        {
            return await _profileService.RequestMasterProfileReport(masterProfileReportRequest);
        }

        [HttpGet]
        [Route("standingorders/setprofileorganizationid/")]
        public async Task<NoSqlServiceResult<bool>> SetProfileOrganizationId([FromUri]ProfileShippingAccountRequest profileShippingAccountRequest)
        {
            return await _profileService.SetProfileOrganizationId(profileShippingAccountRequest);
        }

        [HttpPost]
        [Route("standingorders/profiles/UpdateProfileNotificationUsers")]
        public async Task<NoSqlServiceResult<bool>> UpdateProfileNotificationUsers([FromBody]ProfileNotificationUsersUpdateRequest profileNotificationUsersUpdateRequest)
        {
            return await _profileService.UpdateProfileNotificationUsers(profileNotificationUsersUpdateRequest);
        }

       /* [HttpPost]
        [Route("standingorders/profiles/RequestStatusQueue")]
        public async Task<NoSqlServiceResult<RequestStatusQueueResponse>> GetRequestStatusQueue([FromBody]RequestStatusQueueRequest requestStatusQueueRequest)
        {
            return await _profileService.GetRequestStatusQueue(requestStatusQueueRequest);
        }*/

        /*[HttpPost]
        [Route("standingorders/profiles/UpdateChangeRequest")]
        public async Task<NoSqlServiceResult<bool>> UpdateChangeRequest([FromBody]ChangeRequestUpdateRequest changeRequestUpdateRequest)
        {
            return await _profileService.UpdateChangeRequest(changeRequestUpdateRequest);

        }*/

        [HttpPost]
        [Route("standingorders/profiles/CreateChangeRequest")]
        public async Task<NoSqlServiceResult<bool>> CreateChangeRequest([FromBody]ChangeRequestProfileRequest changeRequestProfileRequest)
        {
            var noSqlServiceResult = await _profileService.CreateProfileChangeRequest(changeRequestProfileRequest);
            return noSqlServiceResult;

        }

        [HttpGet]
        [Route("standingorders/programs")]
        public async Task<NoSqlServiceResult<ProgramsResponse>> GetPrograms([FromUri]ProgramsRequest programsRequest)
        {
            //CheckingAuthentication();

            if (programsRequest == null || string.IsNullOrEmpty(programsRequest.OrgId))
            {
                var response = new NoSqlServiceResult<ProgramsResponse>
                {
                    Status = NoSqlServiceStatus.Fail,
                    ErrorMessage = "Programs Request and Org Id is requred.",
                    Data = null
                };
                return response;
            }

            return await _profileService.GetProgramsBySearch(programsRequest);
        }

        [HttpPost]
        [Route("standingorders/profiles/emailprofile")]
        public async Task<NoSqlServiceResult<bool>> EmailProfile([FromBody]EmailProfileRequest emailProfileRequest)
        {
            return await _profileService.EmailProfile(emailProfileRequest);
        }
        #region Private

        private void CheckingAuthentication()
        {
            var authValue = CommonHelper.GetHeaderValueFromRequest(Request, "ts360authkey");
            if (string.IsNullOrEmpty(authValue))
            {
                throw new Exception("Bad Request.");
            }
            var decryptValue = StringCipher.Decrypt(authValue, AppSettings.PassPhraseForAuthentication);

            if (decryptValue != AppSettings.AuthValueForAuthentication)
            {
                throw new Exception("Invalid Auth Value.");
            }
        }


        #endregion
    }
}
