﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BT.TS360.NoSQL.API.Common;
using BT.TS360.NoSQL.API.Common.Configuration;
using BT.TS360.NoSQL.API.Common.Helper;
using BT.TS360.NoSQL.API.Models.Orders;
using BT.TS360.NoSQL.Data.Common.Constants;
using System.Threading.Tasks;
using BT.TS360.NoSQL.Data;
using BT.TS360.NoSQL.API.Services;
using BT.TS360.NoSQL.API.Models;

namespace BT.TS360.NoSQL.API.Controllers
{
    public class OrdersController : ApiController
    {
        private static readonly OrdersService _ordersService = new OrdersService();

        [HttpPost]
        [Route("orders/setorderaccount")]
        public async Task<NoSqlServiceResult<bool>> UpdateOrderAccount([FromBody]UpdateOrderAccountRequest request)
        {
            return await _ordersService.UpdateOrderAccount(request);
        }

    }
}
