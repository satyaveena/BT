﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;

using BT.TS360.NoSQL.API.Services.Profiles;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.Profiles;

namespace BT.TS360.NoSQL.API.Controllers.Profiles
{
    public class SiteTermController : ApiController
    {
        private static readonly SiteTermService siteTermService = new SiteTermService();

        [HttpGet]
        [Route("profiles/siteterm/{siteTermType}")]
        public async Task<NoSqlServiceResult<SiteTermResponse>> Get(string siteTermType)
        {
            var data = await siteTermService.GetSiteTerm(siteTermType);
            return data;
        }

        [HttpGet]
        [Route("profiles/siteterm/id/{category}")]
        public async Task<NoSqlServiceResult<SiteTermCategory>> GetByCategory(string category)
        {
            var data = await siteTermService.GetSiteTermByCategry(category);
            return data;
        }

        [HttpGet]
        [Route("profiles/siteterm/group/areaofinterest")]
        public async Task<NoSqlServiceResult<SiteTermResponse>> GetAreaOfInterest()
        {
            var data = await siteTermService.GetAreaOfInterest();
            return data;
        }
    }
}
