﻿using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Models.ILS;
using BT.TS360.NoSQL.API.Services.ILS;
using BT.TS360.NoSQL.Data.ILS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace BT.TS360.NoSQL.API.Controllers.ILS
{
    public class ILSController : ApiController
    {

        private readonly ILSService _ilsService;

        public ILSController()
        {
            this._ilsService = new ILSService();
        }

        [HttpGet]
        [Route("ils/apirequest/{basketSummaryId}")]
        public async Task<NoSqlServiceResult<ILSAPIRequestResponse>> GetILSAPIRequest(string basketSummaryId)
        {
            return await _ilsService.GetILSAPIRequest(basketSummaryId);
        }

        [HttpGet]
        [Route("ils/apirequest/response/{basketSummaryId}")]
        public async Task<NoSqlServiceResult<ILSOrderValidationResponseStatus>> GetILSOrderValidationResponseStatus(string basketSummaryId)
        {
            // get ILS response details by Processing Status
            return await _ilsService.GetILSOrderValidationResponseStatus(basketSummaryId);
        }

        [HttpGet]
        [Route("ils/apirequest/validation/response/{basketSummaryId}")]
        public async Task<NoSqlServiceResult<ILSValidationRequestResponse>> GetILSValidationRequestResponse(string basketSummaryId)
        {
            // get ILS request and response objects
            return await _ilsService.GetILSILSValidationRequestResponse(basketSummaryId);
        }

        [HttpPost]
        [Route("ils/saveapirequest")]
        public async Task<NoSqlServiceResult<bool>> SaveILSAPIRequest([FromBody]SaveILSAPIRequest saveILSAPIRequest)
        {
            return await _ilsService.SaveILSAPIRequest(saveILSAPIRequest);
        }

     
    }
}
