﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using BT.TS360.NoSQL.API.Services;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Common.Constants;

using System.Threading.Tasks;
using BT.TS360.NoSQL.API.Models.Axis360;

namespace BT.TS360.NoSQL.API.Controllers
{
    public class Axis360InventoryController : ApiController
    {
        private static readonly Axis360InventoryService axis360InventoryService = new Axis360InventoryService();

        [HttpPost]
        [Route("axis360inventory/checkforinventory")]
        public async Task<NoSqlServiceResult<Axis360CheckInventoryResponse>> CheckForInventory([FromBody] Axis360CheckInventoryRequest axis360CheckInventoryRequest)
        {
            var data = await axis360InventoryService.CheckForInventory(axis360CheckInventoryRequest);
            return data;
        }
    }
}