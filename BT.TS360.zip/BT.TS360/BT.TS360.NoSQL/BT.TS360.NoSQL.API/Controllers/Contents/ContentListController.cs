﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;

using BT.TS360.NoSQL.API.Models.Contents;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Services.Contents;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.API.Models.CMS;

namespace BT.TS360.NoSQL.API.Controllers.Contents
{
    public class ContentListController : ApiController
    {
        private static ContentListService contentListService = new ContentListService();

        [Route("contents/contentlist")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }


        // GET: contents/contentlist/
        [HttpGet]
        [Route("contents/contentlist/{parentID}")]
        public async Task<NoSqlServiceResult<ContentListReponse>> Get(string parentID)
        {
            var data = await contentListService.GetLists(parentID);
            return data;
        }

        // GET: contents/contentlist/
        [HttpGet]
        [Route("contents/fullcontentlist/{parentID}")]
        public async Task<NoSqlServiceResult<ContentListReponse>> GetAllLists(string parentID)
        {
            var data = await contentListService.GetAllLists(parentID);
            return data;
        }

        // GET: contents/contentlist/category
        [HttpGet]
        [Route("contents/contentlist/category/{literal}")]
        public async Task<NoSqlServiceResult<ContentListReponse>> Category(string literal)
        {
            var data = await contentListService.GetRootCategory(literal);
            return data;
        }

        // GET: contents/contentlist/category/featuredlist
        [HttpGet]
        [Route("contents/contentlist/category/featuredlist/{literal}")]
        public async Task<NoSqlServiceResult<ContentListReponse>> GetFeaturedList(string literal)
        {
            var data = await contentListService.GetFeaturedLists(literal);
            return data;
        }


        // GET: contents/contentlist/search
        [HttpGet]
        [Route("contents/contentlist/search/{contentListID}")]
        public async Task<NoSqlServiceResult<ContentSearchResponse>> GetSearchItems(string contentListID)
        {
            var data = await contentListService.GetSearchItem(contentListID);
            return data;
        }

        [HttpGet]
        [Route("contents/contentlist/Publication")]
        public async Task<NoSqlServiceResult<CategoryResponse>> GetPublicationCategoryList(string literal)
        {
            var data = await contentListService.GetPublicationCategoryList(literal);
            return data;
        }

        [HttpGet]
        [Route("contents/contentlist/category/id")]
        public async Task<NoSqlServiceResult<CategoryDetailsResponse>> GetCategoryById(string id)
        {
            return await contentListService.GetCategoryById(id);
        }

    }
}
