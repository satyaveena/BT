﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using BT.TS360.NoSQL.API.Services;
using BT.TS360.NoSQL.API.Models;
using BT.TS360.NoSQL.API.Common.Constants;

using System.Threading.Tasks;

namespace BT.TS360.NoSQL.API.Controllers
{
    public class InventoryDemandController : ApiController
    {
        private static readonly InventoryDemandService inventoryDemandService = new InventoryDemandService();
 
        // GET api/values
        // Put here for testing purpose
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

 

        // POST api/<controller>
        /*public NoSqlServiceResult<InventoryDemandResponse> Post([FromBody] InventoryDemandRequest inventorySearch)
        {
            return inventoryDemandService.GetInventory(inventorySearch);
        }*/

        // POST api/<controller>
        public async Task<NoSqlServiceResult<InventoryDemandResponse>> Post([FromBody] InventoryDemandRequest inventorySearch)
        {
            var data = await inventoryDemandService.GetInventory(inventorySearch);
            return data;
        }
    }
}