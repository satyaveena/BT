﻿namespace BT.TS360.NoSQL.Services.DateRangeCalculator
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateRangeCalculatorProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.dateRangeCalculatorInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // dateRangeCalculatorProcessInstaller
            // 
            this.dateRangeCalculatorProcessInstaller.Password = null;
            this.dateRangeCalculatorProcessInstaller.Username = null;
            // 
            // dateRangeCalculatorInstaller
            // 
            this.dateRangeCalculatorInstaller.Description = "Calculates date range buckets for TSSO data";
            this.dateRangeCalculatorInstaller.DisplayName = "TSSO DateRange Calculator";
            this.dateRangeCalculatorInstaller.ServiceName = "TSSO DateRange Calculator";
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.dateRangeCalculatorProcessInstaller,
            this.dateRangeCalculatorInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller dateRangeCalculatorProcessInstaller;
        private System.ServiceProcess.ServiceInstaller dateRangeCalculatorInstaller;
    }
}