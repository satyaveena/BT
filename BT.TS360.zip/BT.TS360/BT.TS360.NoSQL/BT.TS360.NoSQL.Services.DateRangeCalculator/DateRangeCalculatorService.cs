﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.IO;
using System.Configuration;


using BT.TS360.NoSQL.Data.Common.Helper;
using BT.TS360.NoSQL.Data.Common.Constants;
using BT.TS360.NoSQL.Services.DateRangeCalculator.Services;


namespace BT.TS360.NoSQL.Services.DateRangeCalculator
{
    public partial class DateRangeCalculatorService : ServiceBase
    {


        static FileLogger _logger;
        static Emailer _emailer;
        ExceptionLogger _exceptionLogger;

     
        int _intervalMinutes;
        string _serviceStartTime;
        string _serviceEndTime;

        static bool _enableSeriesDateRangeCalculations;
        static bool _enableProfilesDateRangeCalculations;

        static int _retries;
        static int _retryWaitTime;
        static int _loadBatchSize;

        static Boolean _InProcess = false;

        private System.Timers.Timer _timer;

        static string _emailTo;
        static string _environment;
  

        public DateRangeCalculatorService()
        {
            InitializeComponent();
        }

        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args)
        {


            InitAppSettings();

            _timer = new System.Timers.Timer(1);
            _timer.AutoReset = false;
            _timer.Enabled = true;
            _timer.Elapsed += OnTimerElapsed;
            _timer.Start();

            _logger.Write("DateRangeCalculator Service started", FileLoggingLevel.INFO);
            _emailer.Send(_emailTo, string.Format("DateRangeCalculator: " + _environment + " [" + Environment.MachineName + "]"), "Service Started " + DateTime.Now.ToString());

        }

        public void Stop(string[] args) { OnStop(); }

        protected override void OnStop()
        {
            _logger.Write("DateRangeCalculator Service Stopped", FileLoggingLevel.INFO);
            _emailer.Send(_emailTo, string.Format("DateRangeCalculator: " + _environment + " [" + Environment.MachineName + "]"), "Service Stopped " + DateTime.Now.ToString());

            _timer.Stop();
            this._timer.Dispose();
        }

        private void OnTimerElapsed(object source, ElapsedEventArgs e)
        {

            Services.DateRangeCalculatorService dateRangeCalculatorMain = new Services.DateRangeCalculatorService();

            DateTime currentDateTime = DateTime.Now;
            DateTime serviceStartDateTime = DateTime.Parse(string.Format("{0} {1}", currentDateTime.ToString("MM/dd/yyyy"), _serviceStartTime));
            DateTime serviceEndDateTime = DateTime.Parse(string.Format("{0} {1}", currentDateTime.ToString("MM/dd/yyyy"),_serviceEndTime));
            
            if (!_timer.AutoReset)
            {
                _timer.Interval = _intervalMinutes * 60 * 1000;
                _timer.AutoReset = true;
            }

            if (!(currentDateTime >= serviceStartDateTime && currentDateTime <= serviceEndDateTime))
            {
                return;
            }

            if (!_InProcess)
            {
                _InProcess = true;

                dateRangeCalculatorMain.Main();

                _InProcess = false;

            }
          
        }

        private void InitAppSettings()
        {
            _logger = new FileLogger(AppSettings.LogFolder, AppSettings.LogFilePrefix);

            _emailer = new Emailer(AppSettings.EmailSMTPServer);
            _emailTo = AppSettings.EmailTo;
            _environment = AppSettings.CurrentEnvironment;

            _exceptionLogger = new ExceptionLogger(AppSettings.ExceptionLoggingConnectionString);

            _intervalMinutes = AppSettings.IntervalMinutes;
            _serviceStartTime = AppSettings.ServiceStartTime;
            _serviceEndTime = AppSettings.ServiceEndTime;

            _retries = AppSettings.MaxConnectionRetries;
            _retryWaitTime = AppSettings.RetryWaitTime;
            _loadBatchSize = AppSettings.LoadBatchSize;

            _enableProfilesDateRangeCalculations = AppSettings.EnableProfilesDateRangeCalculations;
            _enableSeriesDateRangeCalculations = AppSettings.EnableSeriesDateRangeCalculations;
           
        }

    }
}
