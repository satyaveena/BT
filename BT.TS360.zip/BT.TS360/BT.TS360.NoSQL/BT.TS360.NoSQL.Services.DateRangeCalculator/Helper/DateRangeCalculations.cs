﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.TS360.NoSQL.Services.DateRangeCalculator.Helper
{
    public static class DateRangeCalculations
    {
        public static List<string> CalculateUpdatedDateRange(DateTime UpdatedDate)
        {
            List<string> newUpdatedDateRange = new List<string>();
            int totalDays = Convert.ToInt32((UpdatedDate.Date - DateTime.Now.Date).TotalDays);


            if (totalDays >= -30 && totalDays < 0)
            {
                newUpdatedDateRange.Add("30 Days");
            }

            if (totalDays >= -7 && totalDays <= 0)
            {
                newUpdatedDateRange.Add("7 Days");
            }

            return newUpdatedDateRange;



        }



        public static List<string> CalculatePublicationDateRange(DateTime? publicationDate)
        {
            List<string> newPublicationDateRange = new List<string>();
           
            if (publicationDate == null || !publicationDate.HasValue)
            {
                return newPublicationDateRange;
            }

            int totalDays = Convert.ToInt32((publicationDate.Value.Date - DateTime.Now.Date).TotalDays);


            if (totalDays <= 30 && totalDays >= 0)
            {
                newPublicationDateRange.Add("Within next 30 Days");
            }

            if (totalDays <= 60 && totalDays > 0)
            {
                newPublicationDateRange.Add("Within next 60 Days");
            }

            if (totalDays <= 90 && totalDays > 0)
            {
                newPublicationDateRange.Add("Within next 90 Days");
            }

            if (totalDays <= 180 && totalDays > 0)
            {
                newPublicationDateRange.Add("Within next 180 Days");
            }

            if (totalDays >= -30 && totalDays < 0)
            {
                newPublicationDateRange.Add("Within previous 30 Days");
            }

            if (totalDays >= -60 && totalDays < 0)
            {
                newPublicationDateRange.Add("Within previous 60 Days");
            }

            if (totalDays >= -90 && totalDays < 0)
            {
                newPublicationDateRange.Add("Within previous 90 Days");
            }

            if (totalDays >= -180 && totalDays < 0)
            {
                newPublicationDateRange.Add("Within previous 180 Days");
            }
         

            return newPublicationDateRange;

        }
    }
}
