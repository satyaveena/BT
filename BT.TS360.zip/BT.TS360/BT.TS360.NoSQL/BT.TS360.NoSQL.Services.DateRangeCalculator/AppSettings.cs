﻿using System;
using System.Configuration;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BT.TS360.NoSQL.Services.DateRangeCalculator
{
    public class AppSettings
    {

        #region ServiceSettings
        //values pertain to  how the service will running and it's timing interval

        public static int IntervalMinutes
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]); }
        }

        public static string ServiceStartTime
        {
            get { return ConfigurationManager.AppSettings["ServiceStartTime"]; }
        }

        public static string ServiceEndTime
        {
            get { return ConfigurationManager.AppSettings["ServiceEndTime"]; }
        }



        public static int LoadBatchSize
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["LoadBatchSize"]); }
        }

        public static bool EnableSeriesDateRangeCalculations
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableSeriesDateRangeCalculations"]); }
        }

        public static bool EnableProfilesDateRangeCalculations
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["EnableProfilesDateRangeCalculations"]); }
        }


        #endregion ServiceSettings


        #region LoggingSettings
        //values pertain to logging (3 types of logging: file, email and elmah)

        public static string CurrentEnvironment
        {
            get { return ConfigurationManager.AppSettings["CurrentEnvironment"].ToString(); }
        }

        public static string EmailTo
        {
            get { return ConfigurationManager.AppSettings["EmailTo"].ToString(); }
        }

        public static string EmailSMTPServer
        {
            get { return ConfigurationManager.AppSettings["EmailSMTPServer"].ToString(); }
        }


        public static string ExceptionLoggingConnectionString
        {
            get { return ConfigurationManager.AppSettings["ExceptionLoggingConnectionString"].ToString(); }
        }

        public static string LogFolder
        {
            get { return ConfigurationManager.AppSettings["LogFolder"].ToString(); }
        }

        public static string LogFilePrefix
        {
            get { return ConfigurationManager.AppSettings["LogFilePrefix"].ToString(); }
        }


        #endregion LoggingSettings




        #region MongoSettings

        public static string MongoDBConnectionString
        {
            get { return ConfigurationManager.AppSettings["MongoDBConnectionString"].ToString(); }
        }

        public static int MaxConnectionRetries
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["MaxConnectionRetries"]); }
        }

        public static int RetryWaitTime
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RetryWaitTime"]); }
        }

        public static int AzureSearchQueuePriority
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["AzureSearchQueuePriority"]); }
        }
        
        public const string DatabaseNameTSSO = "StandingOrders";
        public const string ProfilesCollectionName = "Profiles";
        public const string SeriesCollectionName = "Series";
        public const string ProfiledSeriesCollectionName = "ProfiledSeries";

        public const string DatabaseNameCommon = "Common";
        public const string AzureSearchQueueCollectionName = "AzureSearchQueue";
        //ChangeTypeAction for AzureSearchQueue
        public const string ChangeTypeAction = "Upsert";

        public const string ProfilesObjectIdName = "_id";
        public const string SeriesObjectIdName = "_id";
        public const string ProfiledSeriesObjectIdName = "_id";

        public const string ServiceUserName = "DateCalculator";

        #endregion MongoSettings
    }
}
