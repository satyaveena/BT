﻿$.support.cors = true;
var isDebug = false;

var app = angular.module('ts360CMS', []);

app.factory('commonFunctions', function () {
    return {
        redirectTo: function (url) {
            location.href = url;
        },
        scrollTop: function () {
            $('html, body').animate({ scrollTop: 0 }, 'fast');
        },
        showMessage: function(msg) {
            console.log(msg);
        },
        invokeAjaxFunction: function (serviceUrl, submittedData, ajaxType, callbackFunc, errorCallBackFunc) {
            $.ajax({
                type: ajaxType,
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                traditional: true,
                data: submittedData,
                url: serviceUrl,
                success: function(result) {
                    callbackFunc(result);
                } ,
                error: function(xhr, status, errorThrown) {
                    errorCallBackFunc(xhr, status, errorThrown);
                }
            });
        }
    };
});

app.factory('commonData', function () {
    return {
        'categories': null,
        'leavenodes': null,
        'selectedCategoryName': '',
        'selectedCategory': null
    };
});

app.controller('CategoryMainController', ['$scope', 'commonFunctions', 'commonData', '$rootScope', function ($scope, commonFunctions, commonData, $rootScope) {
    $rootScope.$on("CrossControllerFunction", function () {
        $scope.selectedCategoryName = commonData.selectedCategoryName;
        $scope.categories = commonData.categories;
        $scope.$apply();
    });

    $scope.bindingSelectedCategory = function () {
        $rootScope.$emit("bindingSelectedCategory", {});
    };

    $scope.webApiUrlAddCategory = isDebug ? 'http://localhost:5062/btcms/category/addcategory' : 'http://localhost:3031/btcms/category/addcategory';
    $scope.webApiUrlUpdateCategory = isDebug ? 'http://localhost:5062/btcms/category/updatecategory' : 'http://localhost:3031/btcms/category/updatecategory';

    $scope.newCatName = '';

    $scope.addCategory = function() {
        var catId = commonData.selectedCategory == null ? '' : commonData.selectedCategory.Id;
        var requestData = {
            ParentCategoryId: catId, Literal: $scope.newCatName, Status: 1,Sequence: 1
        };

        commonFunctions.invokeAjaxFunction($scope.webApiUrlAddCategory, JSON.stringify(requestData), "POST",
            function (result) {
                if (result.Status == 0) {
                    $scope.bindingSelectedCategory();
                    closeCategoryDlg();
                } else {
                    commonFunctions.showMessage(result.ErrorMessage);
                }
            },
            function (xhr, status, errorThrown) {
                commonFunctions.showMessage(status);
                commonFunctions.scrollTop();
                console.log(errorThrown + '\n' + status + '\n' + xhr.statusText);
            });
    };

    $scope.selectAll = function ($event) {
        if ($scope.categories == null || $scope.categories.length == 0) return;

        var checkbox = $event.target;

        for (var i = 0; i < $scope.categories.length; i++) {
            $scope.categories[i].IsChecked = checkbox.checked;
        }
    };

    $scope.showAddNewDialog = function (dlgId) {
        $scope.newCatName = '';
        showDialog(dlgId);
    };
}]);

app.controller('CategoryController', ['$scope', 'commonFunctions', 'commonData', '$rootScope', function ($scope, commonFunctions, commonData, $rootScope) {

    $scope.refreshMainController = function () {
        $rootScope.$emit("CrossControllerFunction", {});
    };

    $rootScope.$on("bindingSelectedCategory", function () {
        $scope.bindingSelectedCategory();
    });

    // Constants
    $scope.webApiAuthKey = "";
    $scope.webApiUrlGetCategories = isDebug ? 'http://localhost:5062/btcms/category/getcategories' : 'http://localhost:3031/btcms/category/getcategories';
    $scope.selectedCategory = null;

    commonData.selectedCategory = null;

    // Util functions
    $scope.initCategoryRequest = function() {
        var result = new Object();
        result.PageNumber = 1;
        result.PageSize = 50;
        result.CategoryId = "";
        result.SortBy = "Literal";
        result.SortDirection = "asc";
        return result;
    };

    $scope.convertToDateString = function (dtValue) {
        var inputDate = new Date(dtValue);
        var dd = inputDate.getDate();
        var mm = inputDate.getMonth() + 1; //January is 0!
        var yyyy = inputDate.getFullYear();

        if (dd < 10) {
            dd = '0' + dd;
        }

        if (mm < 10) {
            mm = '0' + mm;
        }

        return mm + '/' + dd + '/' + yyyy;
    };

    $scope.convertLeaveToCatObject = function(leaveNode) {
        var leaveNodeItem = new Object();
        leaveNodeItem.Id = leaveNode.Id;
        leaveNodeItem.Literal = leaveNode.Literal;
        leaveNodeItem.Status = leaveNode.Status;
        leaveNodeItem.PublicLink = leaveNode.PublicLink;
        leaveNodeItem.StartDate = leaveNode.StartDate;
        leaveNodeItem.StartDateString = $scope.convertToDateString(leaveNode.StartDate);
        leaveNodeItem.EndDate = leaveNode.EndDate;
        leaveNodeItem.EndDateString = $scope.convertToDateString(leaveNode.EndDate);
        leaveNodeItem.IsChecked = false;
        leaveNodeItem.FileName = leaveNode.FileName;
        return leaveNodeItem;
    };

    $scope.convertCategoryToCatObject = function(catItem) {
        var catClientItem = new Object();
        catClientItem.Id = catItem.Id;
        catClientItem.Literal = catItem.Literal;
        catClientItem.Status = catItem.Status;
        catClientItem.Sequence = catItem.Sequence;
        catClientItem.IsChecked = false;

        catClientItem.ChildCategories = new Array();

        if (typeof (catItem.ChildCategories) != 'undefined' && catItem.ChildCategories.length > 0) {
            for (var i = 0; i < catItem.ChildCategories.length; i++) {
                catClientItem.ChildCategories.push($scope.convertCategoryToCatObject(catItem.ChildCategories[i]));
            }
        }

        catClientItem.LeaveNodes = new Array();

        if (typeof (catItem.LeaveNodes) != 'undefined' && catItem.LeaveNodes.length > 0) {
            for (var i = 0; i < catItem.LeaveNodes.length; i++) {
                catClientItem.LeaveNodes.push($scope.convertLeaveToCatObject(catItem.LeaveNodes[i]));
            }
        }

        return catClientItem;
    };

    $scope.bindingRootCategory = function (cat) {
        commonData.selectedCategory = cat;
        $scope.selectedCategory = cat;
        $scope.CategoryRequest = $scope.initCategoryRequest();
        $scope.getCategories();
    };

    $scope.bindingCategory = function (cat) {
        $scope.selectedCategory = cat;

        $scope.bindingSelectedCategory();
    };

    $scope.bindingSelectedCategory = function () {

        var selectedCatName = $scope.selectedCategory == null ? "Category Management" : $scope.selectedCategory.Literal;

        commonData.selectedCategoryName = selectedCatName;
        commonData.selectedCategory = $scope.selectedCategory;

        $scope.CategoryRequest = $scope.createCategoryRequest();
        $scope.getDataForMainContent();
    };

    $scope.createCategoryRequest = function () {
        var result = new Object();
        result.PageNumber = 1;
        result.PageSize = 50;
        result.CategoryId = $scope.selectedCategory == null ? "" : $scope.selectedCategory.Id;
        result.SortBy = "Literal";
        result.SortDirection = "asc";
        return result;
    };

    //
    $scope.CategoryRequest = $scope.initCategoryRequest();

    // Get Cats 
    $scope.getCategories = function () {
        commonData.selectedCategoryName = "Category Management";
        commonFunctions.invokeAjaxFunction($scope.webApiUrlGetCategories, $scope.CategoryRequest, "GET",
            function(result) {
                if (result.Status == 0) {

                    $scope.categories = [];
                    commonData.categories = [];

                    var response = result.Data;

                    var listCats = response.Categories;
                    var i;
                    for (i = 0; i < listCats.length; i++) {
                        var catItem = $scope.convertCategoryToCatObject(listCats[i]);
                        catItem.IsRootDoc = $scope.selectedCategory == null;

                        $scope.categories.push(catItem);
                        commonData.categories.push(catItem);
                    }

                    $scope.$apply();
                    $scope.refreshMainController();
                } else {
                    commonFunctions.showMessage(result.ErrorMessage);
                }
            },
            function(xhr, status, errorThrown) {
                commonFunctions.showMessage(status);
                commonFunctions.scrollTop();
                console.log(errorThrown + '\n' + status + '\n' + xhr.statusText);
            });
    };

    $scope.getDataForMainContent = function () {
        commonFunctions.invokeAjaxFunction($scope.webApiUrlGetCategories, $scope.CategoryRequest, "GET",
            function (result) {
                if (result.Status == 0) {

                    commonData.categories = [];

                    var response = result.Data;
                    var i;

                    if (response.Categories != null) {
                        var listCats = response.Categories;
                        for (i = 0; i < listCats.length; i++) {
                            var catItem = $scope.convertCategoryToCatObject(listCats[i]);
                            commonData.categories.push(catItem);
                        }
                    }

                    commonData.leavenodes = [];
                    if (response.LeaveNodes != null) {
                        var nodes = response.LeaveNodes;
                        for (i = 0; i < nodes.length; i++) {
                            var nodeItem = $scope.convertLeaveToCatObject(nodes[i]);
                            commonData.leavenodes.push(nodeItem);
                        }
                    }

                    $scope.refreshMainController();
                } else {
                    commonFunctions.showMessage(result.ErrorMessage);
                }
            },
            function (xhr, status, errorThrown) {
                commonFunctions.showMessage(status);
                commonFunctions.scrollTop();
                console.log(errorThrown + '\n' + status + '\n' + xhr.statusText);
            });
    };

    // loading first time
    $scope.getCategories();

}]);

app.controller('LeaveNodeController', ['$scope', 'commonFunctions', 'commonData', '$rootScope', '$http', function ($scope, commonFunctions, commonData, $rootScope, $http) {
    $rootScope.$on("CrossControllerFunction", function () {
        $scope.selectedCategoryName = commonData.selectedCategoryName;
        $scope.leavenodes = commonData.leavenodes;
        $scope.$apply();
    });

    $scope.bindingSelectedCategory = function () {
        $rootScope.$emit("bindingSelectedCategory", {});
    };

    $scope.webApiUrlAddNode = isDebug ? 'http://localhost:5062/btcms/leavenode/addnode' : 'http://localhost:3031/btcms/leavenode/addnode';
    $scope.webApiUrlUpdateNode = isDebug ? 'http://localhost:5062/btcms/leavenode/updatenode' : 'http://localhost:3031/btcms/leavenode/updatenode';
    $scope.webApiUrlDeleteNode = isDebug ? 'http://localhost:5062/btcms/leavenode/deletenode' : 'http://localhost:3031/btcms/leavenode/deletenode';

    $scope.newNode = null;
    $scope.leaveNodeFile = null;

    $scope.initNewNode = function () {
        $scope.newNode = new Object();
        $scope.newNode.NodeName = "";
        $scope.newNode.StartDate = "";
        $scope.newNode.EndDate = "";
        $scope.newNode.Status = 0;
        $scope.newNode.Sequence = 0;
        $scope.newNode.PublicLink = "";
    };

    var formdata = new FormData();
    $scope.getTheFiles = function ($files) {
        angular.forEach($files, function (value, key) {
            formdata.append(key, value);
        });
    };

    $scope.addNode = function () {
        if (commonData.selectedCategory == null) {
            commonFunctions.showMessage('Please select category for adding.');
            return;
        }

        var catId = commonData.selectedCategory.Id;
        var requestData = {
            CategoryId: catId, Literal: $scope.newNode.NodeName, StartDate: new Date(), EndDate: new Date(), Status: 1, Sequence: 1,
            PublicLink: "http://ts360.baker-taylor.com"
        };

        formdata.append('CustomData', JSON.stringify(requestData));
        
        var request = {
            method: 'POST',
            url: $scope.webApiUrlAddNode,
            data: formdata,
            headers: {
                'Content-Type': undefined
            }
        };

        // SEND THE FILES.
        $http(request)
            .success(function (result) {
                if (result.Status == 0) {
                    $scope.bindingSelectedCategory();
                    closeNodeDlg();
                } else {
                    commonFunctions.showMessage(result.ErrorMessage);
                }
            })
            .error(function () {
            });
    };

    $scope.showFile = function (nodeId) {
        var catId = commonData.selectedCategory.Id;
        var showFileLink = isDebug ? 'http://localhost:5062/btcms/leavenode/getfile?catId=' + catId + '&nodeId' + nodeId :
            'http://localhost:3031/btcms/leavenode/getfile?catId=' + catId + '&nodeId' + nodeId;
        $scope.webApiUrlShowFile = showFileLink;
        
        var requestData = { };

        commonFunctions.invokeAjaxFunction($scope.webApiUrlShowFile, requestData, "GET",
            function (result) {
                
            },
            function (xhr, status, errorThrown) {
                commonFunctions.showMessage(status);
                commonFunctions.scrollTop();
                console.log(errorThrown + '\n' + status + '\n' + xhr.statusText);
            });
    };

    $scope.selectAll = function ($event) {
        if ($scope.leavenodes == null || $scope.leavenodes.length == 0) return;
        var checkbox = $event.target;
        for (var i = 0; i < $scope.leavenodes.length; i++) {
            $scope.leavenodes[i].IsChecked = checkbox.checked;
        }
    };

    $scope.showAddNewDialog = function (dlgId) {
        $scope.initNewNode();
        showDialog(dlgId);
    };

    // execution areas
    $scope.initNewNode();
}]);

app.directive('ngFiles', ['$parse', function ($parse) {
    function fn_link(scope, element, attrs) {
        var onChange = $parse(attrs.ngFiles);
        element.on('change', function (event) {
            onChange(scope, { $files: event.target.files });
        });
    };

    return {
        link: fn_link
    };
}]);