﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BT.TS360.CMS.WebAdmin.Startup))]
namespace BT.TS360.CMS.WebAdmin
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
