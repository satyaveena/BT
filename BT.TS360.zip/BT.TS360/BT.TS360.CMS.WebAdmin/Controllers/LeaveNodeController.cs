﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BT.TS360.CMS.WebAdmin.Controllers
{
    //[Authorize]
    public class LeaveNodeController : Controller
    {
        // GET: LeaveNode
        public ActionResult Index()
        {
            return View();
        }

        // GET: Leave Node Column Management
        public ActionResult LeaveNodeColumnMgt()
        {
            return View();
        }

        // GET: LeaveNode/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: LeaveNode/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: LeaveNode/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: LeaveNode/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: LeaveNode/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: LeaveNode/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: LeaveNode/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
