﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;

namespace DB2Call
{
    public class DB2BulkCopy
    {
        int m_ReturnCode;
        
        public void BulkCopyToSql(string NGConnectionString, string DB2ConnectionString, string NGTableName, string DB2StoredProcedureName, string CompanyCode, string SearchDate, out int ReturnCode)
        {

            using (SqlConnection NextGenStageConnection = new SqlConnection(NGConnectionString))
            {
                NextGenStageConnection.Open();

                DataTable NextGenDataTable =  new DataTable();
                
                
                         
              NextGenDataTable = GetDB2Data(DB2ConnectionString, DB2StoredProcedureName, CompanyCode, SearchDate);
              

                using (SqlBulkCopy NextGenBulkCopy = new SqlBulkCopy(NextGenStageConnection))
                {
                    NextGenBulkCopy.BulkCopyTimeout = 0; 
                    NextGenBulkCopy.DestinationTableName = NGTableName;
                    NextGenBulkCopy.WriteToServer(NextGenDataTable);
                }

                NextGenStageConnection.Close();
            }
            ReturnCode = m_ReturnCode;
        }

        DataTable GetDB2Data(string DB2ConnectionString, string DB2StoredProcedureName, string CompanyCode, string SearchDate)
        {
            OleDbConnection DB2Connection = new OleDbConnection(DB2ConnectionString);
            OleDbCommand DB2Command = new OleDbCommand();
            OleDbParameter CompanyCodeParam = new OleDbParameter();
            OleDbParameter SearchDateParam = new OleDbParameter();
            OleDbParameter ReturnCodeParam = new OleDbParameter();
            OleDbParameter testparam = new OleDbParameter();
            OleDbDataReader DB2DataReader;
            DataTable DB2DataTable = new DataTable();

            DB2Command.CommandText = DB2StoredProcedureName;
            DB2Command.CommandTimeout = 0;
            DB2Command.Parameters.Add("CD_COMPANY_CD", OleDbType.Char, 2).Value = CompanyCode;
            DB2Command.Parameters.Add("CD_CODE_NAME", OleDbType.Char, 26).Value = SearchDate;
        

            ReturnCodeParam.ParameterName = "ORETCODE";
            ReturnCodeParam.Direction = ParameterDirection.Output;
            ReturnCodeParam.OleDbType = OleDbType.Integer;
            ReturnCodeParam.Value = m_ReturnCode;
            DB2Command.Parameters.Add(ReturnCodeParam);

            DB2Command.CommandType = CommandType.StoredProcedure;

            DB2Command.Connection = DB2Connection;

            DB2Connection.Open();

            DB2DataReader = DB2Command.ExecuteReader();

          
            
            DB2DataTable.Load(DB2DataReader);

            DB2Connection.Close();

         m_ReturnCode = Convert.ToInt16(ReturnCodeParam.Value);
         return DB2DataTable;

        }
    }
}
