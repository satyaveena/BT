﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using DB2Call;
using System.Data.OleDb;

namespace OrdersInvoices
{

    public class OrdersInvoices
    {
        static int m_ReturnCode;
        static string OrdersConnectionString = ConfigurationManager.AppSettings.Get("OrdersConnectionString");
        static string StageConnectionString = ConfigurationManager.AppSettings.Get("StageConnectionString");
        static string DB2ConnectionString = ConfigurationManager.AppSettings.Get("DB2ConnectionString");
        static int SQLCommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings.Get("CommandTimeout"));

        static void Main(string[] args)
        {
            /*
            8 modules, one for each table
            OrderDetail/Delete
            OrderDetailStatus/Delete
            OrderHeader/Delete
            OrderSummary/Delete
            InvoiceDetail/Delete
            InvoiceSummary/Delete
            Package/Delete
            VASSundry/Delete
            */
            
            OrderDetail();
            OrderHeader();
            OrderSummary();
            OrderDetailStatus();
            InvoiceSummary();
            InvoiceDetail();
            Package();
            VASSundry();
        }

        static void ExceptionLogging(int ErrorCode, string ErrorMessage, string OCSTable)
        {
            string ExceptionLoggingConnectionString = ConfigurationManager.AppSettings.Get("ExceptionLoggingConnectionString");

            using (SqlConnection ExceptionLog = new SqlConnection(ExceptionLoggingConnectionString))
            {
                using (SqlCommand LogError = new SqlCommand("ELMAH_LogError", ExceptionLog))
                {
                    LogError.CommandType = CommandType.StoredProcedure;
                    LogError.CommandTimeout = SQLCommandTimeout;

                    LogError.Parameters.AddWithValue("@ErrorID", Guid.NewGuid());
                    LogError.Parameters.AddWithValue("@Application", "OCS Load");
                    LogError.Parameters.AddWithValue("@Host", Environment.MachineName);
                    LogError.Parameters.AddWithValue("@Type", "");
                    LogError.Parameters.AddWithValue("@Source", OCSTable);
                    LogError.Parameters.AddWithValue("@Message", ErrorMessage);
                    LogError.Parameters.AddWithValue("@User", "");
                    LogError.Parameters.AddWithValue("@StatusCode", ErrorCode);
                    LogError.Parameters.AddWithValue("@TimeUTC", DateTime.UtcNow);
                    LogError.Parameters.AddWithValue("@Sequence", 0);
                    LogError.Parameters.AddWithValue("@AllXML", "");

                    ExceptionLog.Open();
                    LogError.ExecuteNonQuery();
                    ExceptionLog.Close();
                }

            }

        }

        static void OrderDetail()
        {
            int OrderDetailReturnCode;
            string OrderDetailSearchDateBT;
            string OrderDetailSearchDateET;
            string OrderDetailTable = ConfigurationManager.AppSettings.Get("OrderDetailTable");
            string OrderDetailStoredProcBT = ConfigurationManager.AppSettings.Get("OrderDetailStoredProcBT");
            string OrderDetailStoredProcET = ConfigurationManager.AppSettings.Get("OrderDetailStoredProcET");

            int OrderDetailDeleteReturnCode;
            string OrderDetailSearchDateDeleteBT;
            string OrderDetailSearchDateDeleteET;
            string OrderDetailTableDelete = ConfigurationManager.AppSettings.Get("OrderDetailTableDelete");
            string OrderDetailStoredProcDeleteBT = ConfigurationManager.AppSettings.Get("OrderDetailStoredProcDeleteBT");
            string OrderDetailStoredProcDeleteET = ConfigurationManager.AppSettings.Get("OrderDetailStoredProcDeleteET");

            try
            {
                //Get Delete time stamps
                OrderDetailSearchDateDeleteET = GetTimeStamps(OrderDetailStoredProcDeleteET, "ET");
                OrderDetailSearchDateDeleteBT = GetTimeStamps(OrderDetailStoredProcDeleteBT, "BT");
                            
                //truncate the staging table
                ExecuteStoredProcedures("procTruncateOrderDetailDelete", StageConnectionString);

                //bulk copy order detail deletes, BT
                BulkCopyToSql(OrderDetailTableDelete, OrderDetailStoredProcDeleteBT, "BT", OrderDetailSearchDateDeleteBT, out OrderDetailDeleteReturnCode);

                if (OrderDetailDeleteReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailDeleteReturnCode, "Bulk copy error", "OrderDetail");
                }

                OrderDetailDeleteReturnCode = 0;

                //bulk copy order detail deletes, ET
                BulkCopyToSql(OrderDetailTableDelete, OrderDetailStoredProcDeleteET, "ET", OrderDetailSearchDateDeleteET, out OrderDetailDeleteReturnCode);

                if (OrderDetailDeleteReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailDeleteReturnCode, "Bulk copy error", "OrderDetail");
                }

                //get timestamps for order details
                OrderDetailSearchDateET = GetTimeStamps(OrderDetailStoredProcET, "ET");
                OrderDetailSearchDateBT = GetTimeStamps(OrderDetailStoredProcBT, "BT");

                //truncate staging table
                ExecuteStoredProcedures("procTruncateOrderDetail", StageConnectionString);

                //bulk copy order detail BT
                BulkCopyToSql(OrderDetailTable, OrderDetailStoredProcBT, "BT", OrderDetailSearchDateBT, out OrderDetailReturnCode);

                if (OrderDetailReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailDeleteReturnCode, "Bulk copy error", "OrderDetail");
                }

                OrderDetailReturnCode = 0;

                //bulkt copy order detail ET
                BulkCopyToSql(OrderDetailTable, OrderDetailStoredProcET, "ET", OrderDetailSearchDateET, out OrderDetailReturnCode);

                if (OrderDetailReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailDeleteReturnCode, "Bulk copy error", "OrderDetail");
                }

                //Run cleanup, validate, merge
                ExecuteStoredProcedures("procCleanUpOrderDetail", StageConnectionString);
                ExecuteStoredProcedures("procCleanUpOrderDetailDelete", StageConnectionString);
                ExecuteStoredProcedures("procValidateOrderDetail", StageConnectionString);
                ExecuteStoredProcedures("procMergeOrderDetail", StageConnectionString);

                //update timestamps
                UpdateTimeStamps(OrderDetailStoredProcDeleteBT, "BT", OrderDetailTableDelete);
                UpdateTimeStamps(OrderDetailStoredProcDeleteET, "ET", OrderDetailTableDelete);
                UpdateTimeStamps(OrderDetailStoredProcBT, "BT", OrderDetailTable);
                UpdateTimeStamps(OrderDetailStoredProcET, "ET", OrderDetailTable);

                //process deletes
                ExecuteStoredProcedures("procProcessOrderDetailDelete", StageConnectionString);
            }
            catch (Exception e)
            {
                string ErrorMessage = e.ToString();
                ExceptionLogging(-1, ErrorMessage, "OrderDetail");
            }
        }

        static void OrderDetailStatus()
        {
            int OrderDetailStatusReturnCode;
            string OrderDetailStatusSearchDateBT;
            string OrderDetailStatusSearchDateET;
            string OrderDetailStatusTable = ConfigurationManager.AppSettings.Get("OrderDetailStatusTable");
            string OrderDetailStatusStoredProcBT = ConfigurationManager.AppSettings.Get("OrderDetailStatusStoredProcBT");
            string OrderDetailStatusStoredProcET = ConfigurationManager.AppSettings.Get("OrderDetailStatusStoredProcET");

            int OrderDetailStatusDeleteReturnCode;
            string OrderDetailStatusSearchDateDeleteBT;
            string OrderDetailStatusSearchDateDeleteET;
            string OrderDetailStatusTableDelete = ConfigurationManager.AppSettings.Get("OrderDetailStatusTableDelete");
            string OrderDetailStatusStoredProcDeleteBT = ConfigurationManager.AppSettings.Get("OrderDetailStatusStoredProcDeleteBT");
            string OrderDetailStatusStoredProcDeleteET = ConfigurationManager.AppSettings.Get("OrderDetailStatusStoredProcDeleteET");

            try
            {
                //Get Delete time stamps
                OrderDetailStatusSearchDateDeleteET = GetTimeStamps(OrderDetailStatusStoredProcDeleteET, "ET");
                OrderDetailStatusSearchDateDeleteBT = GetTimeStamps(OrderDetailStatusStoredProcDeleteBT, "BT");

                //truncate the staging table
                ExecuteStoredProcedures("procTruncateOrderDetailStatusDelete", StageConnectionString);

                //bulk copy order detail status deletes, BT
                BulkCopyToSql(OrderDetailStatusTableDelete, OrderDetailStatusStoredProcDeleteBT, "BT", OrderDetailStatusSearchDateDeleteBT, out OrderDetailStatusDeleteReturnCode);

                if (OrderDetailStatusDeleteReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailStatusDeleteReturnCode, "Bulk copy error BT" ,  "OrderDetailStatusDelete");
                }

                OrderDetailStatusDeleteReturnCode = 0;

                //bulk copy order detail status deletes, ET
                BulkCopyToSql(OrderDetailStatusTableDelete, OrderDetailStatusStoredProcDeleteET, "ET", OrderDetailStatusSearchDateDeleteET, out OrderDetailStatusDeleteReturnCode);

                if (OrderDetailStatusDeleteReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailStatusDeleteReturnCode, "Bulk copy error ET", "OrderDetailStatusDelete");
                }

                //get timestamps for order detail statuss
                OrderDetailStatusSearchDateET = GetTimeStamps(OrderDetailStatusStoredProcET, "ET");
                OrderDetailStatusSearchDateBT = GetTimeStamps(OrderDetailStatusStoredProcBT, "BT");

                //truncate staging table
                ExecuteStoredProcedures("procTruncateOrderDetailStatus", StageConnectionString);

                //bulk copy order detail status BT
                BulkCopyToSql(OrderDetailStatusTable, OrderDetailStatusStoredProcBT, "BT", OrderDetailStatusSearchDateBT, out OrderDetailStatusReturnCode);

                if (OrderDetailStatusReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailStatusReturnCode, "Bulk copy error BT", "OrderDetailStatus");
                }

                OrderDetailStatusReturnCode = 0;

                //bulkt copy order detail status ET
                BulkCopyToSql(OrderDetailStatusTable, OrderDetailStatusStoredProcET, "ET", OrderDetailStatusSearchDateET, out OrderDetailStatusReturnCode);

                if (OrderDetailStatusReturnCode != 0)
                {
                    ExceptionLogging(OrderDetailStatusReturnCode, "Bulk copy error ET", "OrderDetailStatus");
                }

                //Run cleanup, validate, merge
                ExecuteStoredProcedures("procCleanUpOrderDetailStatus", StageConnectionString);
                ExecuteStoredProcedures("procCleanUpOrderDetailStatusDelete", StageConnectionString);
                ExecuteStoredProcedures("procValidateOrderDetailStatus", StageConnectionString);
                ExecuteStoredProcedures("procMergeOrderDetailStatus", StageConnectionString);

                //update timestamps
                UpdateTimeStamps(OrderDetailStatusStoredProcDeleteBT, "BT", OrderDetailStatusTableDelete);
                UpdateTimeStamps(OrderDetailStatusStoredProcDeleteET, "ET", OrderDetailStatusTableDelete);
                UpdateTimeStamps(OrderDetailStatusStoredProcBT, "BT", OrderDetailStatusTable);
                UpdateTimeStamps(OrderDetailStatusStoredProcET, "ET", OrderDetailStatusTable);

                //process deletes
                ExecuteStoredProcedures("procProcessOrderDetailStatusDelete", StageConnectionString);
            }
            catch
            {

            }
        }

        static void OrderHeader()
            {
                int OrderHeaderReturnCode;
                string OrderHeaderSearchDateBT;
                string OrderHeaderSearchDateET;
                string OrderHeaderTable = ConfigurationManager.AppSettings.Get("OrderHeaderTable");
                string OrderHeaderStoredProc = ConfigurationManager.AppSettings.Get("OrderHeaderStoredProc");

                int OrderHeaderDeleteReturnCode;
                string OrderHeaderSearchDateDeleteBT;
                string OrderHeaderSearchDateDeleteET;
                string OrderHeaderTableDelete = ConfigurationManager.AppSettings.Get("OrderHeaderTableDelete");
                string OrderHeaderStoredProcDelete = ConfigurationManager.AppSettings.Get("OrderHeaderStoredProcDelete");

                //Get Delete time stamps
                OrderHeaderSearchDateDeleteET = GetTimeStamps(OrderHeaderStoredProcDelete, "ET");
                OrderHeaderSearchDateDeleteBT = GetTimeStamps(OrderHeaderStoredProcDelete, "BT");

            try
            { 
                //truncate the staging table
                ExecuteStoredProcedures("procTruncateOrderHeaderDelete", StageConnectionString);

                //bulk copy order header deletes, BT
                BulkCopyToSql(OrderHeaderTableDelete, OrderHeaderStoredProcDelete, "BT", OrderHeaderSearchDateDeleteBT, out OrderHeaderDeleteReturnCode);

                if (OrderHeaderDeleteReturnCode != 0)
                {
                    ExceptionLogging(OrderHeaderDeleteReturnCode, "Bulk copy error BT", "OrderHeaderDelete");
                }

                OrderHeaderDeleteReturnCode = 0;

                //bulk copy order header deletes, ET
                BulkCopyToSql(OrderHeaderTableDelete, OrderHeaderStoredProcDelete, "ET", OrderHeaderSearchDateDeleteET, out OrderHeaderDeleteReturnCode);

                if (OrderHeaderDeleteReturnCode != 0)
                {
                    ExceptionLogging(OrderHeaderDeleteReturnCode, "Bulk copy error ET", "OrderHeaderDelete");
                }

                //get timestamps for order headers
                OrderHeaderSearchDateET = GetTimeStamps(OrderHeaderStoredProc, "ET");
                OrderHeaderSearchDateBT = GetTimeStamps(OrderHeaderStoredProc, "BT");

                //truncate staging table
                ExecuteStoredProcedures("procTruncateOrderHeader", StageConnectionString);

                //bulk copy order header BT
                BulkCopyToSql(OrderHeaderTable, OrderHeaderStoredProc, "BT", OrderHeaderSearchDateBT, out OrderHeaderReturnCode);

                if (OrderHeaderReturnCode != 0)
                {
                    ExceptionLogging(OrderHeaderReturnCode, "Bulk copy errror BT", "OrderHeader");
                }

                OrderHeaderReturnCode = 0;

                //bulkt copy order header ET
                BulkCopyToSql(OrderHeaderTable, OrderHeaderStoredProc, "ET", OrderHeaderSearchDateET, out OrderHeaderReturnCode);

                if (OrderHeaderReturnCode != 0)
                {
                    ExceptionLogging(OrderHeaderReturnCode, "Bulk copy ET", "OrderHeader");
                }

                //Run cleanup, validate, merge
                ExecuteStoredProcedures("procCleanUpOrderHeader", StageConnectionString);
                ExecuteStoredProcedures("procCleanUpOrderHeaderDelete", StageConnectionString);
                ExecuteStoredProcedures("procValidateOrderHeader", StageConnectionString);
                ExecuteStoredProcedures("procMergeOrderHeader", StageConnectionString);

                //update timestamps
                UpdateTimeStamps(OrderHeaderStoredProcDelete, "BT", OrderHeaderTableDelete);
                UpdateTimeStamps(OrderHeaderStoredProcDelete, "ET", OrderHeaderTableDelete);
                UpdateTimeStamps(OrderHeaderStoredProc, "BT", OrderHeaderTable);
                UpdateTimeStamps(OrderHeaderStoredProc, "ET", OrderHeaderTable);

                //process deletes
                ExecuteStoredProcedures("procProcessOrderHeaderDelete", StageConnectionString);
            }
            catch
            {

            }
        }

        static void OrderSummary()
        {
            int OrderSummaryReturnCode;
            string OrderSummarySearchDateBT;
            string OrderSummarySearchDateET;
            string OrderSummaryTable = ConfigurationManager.AppSettings.Get("OrderSummaryTable");
            string OrderSummaryStoredProc = ConfigurationManager.AppSettings.Get("OrderSummaryStoredProc");

            int OrderSummaryDeleteReturnCode;
            string OrderSummarySearchDateDeleteBT;
            string OrderSummarySearchDateDeleteET;
            string OrderSummaryTableDelete = ConfigurationManager.AppSettings.Get("OrderSummaryTableDelete");
            string OrderSummaryStoredProcDelete = ConfigurationManager.AppSettings.Get("OrderSummaryStoredProcDelete");

            //Get Delete time stamps
            OrderSummarySearchDateDeleteET = GetTimeStamps(OrderSummaryStoredProcDelete, "ET");
            OrderSummarySearchDateDeleteBT = GetTimeStamps(OrderSummaryStoredProcDelete, "BT");

            //truncate the staging table
            ExecuteStoredProcedures("procTruncateOrderSummaryDelete", StageConnectionString);

            //bulk copy order summary deletes, BT
            BulkCopyToSql(OrderSummaryTableDelete, OrderSummaryStoredProcDelete, "BT", OrderSummarySearchDateDeleteBT, out OrderSummaryDeleteReturnCode);

            if (OrderSummaryDeleteReturnCode != 0)
            {
                ExceptionLogging(OrderSummaryDeleteReturnCode, "Bulk copy error BT", "OrderSummaryDelete");
            }

            OrderSummaryDeleteReturnCode = 0;

            //bulk copy order summary deletes, ET
            BulkCopyToSql(OrderSummaryTableDelete, OrderSummaryStoredProcDelete, "ET", OrderSummarySearchDateDeleteET, out OrderSummaryDeleteReturnCode);

            if (OrderSummaryDeleteReturnCode != 0)
            {
                ExceptionLogging(OrderSummaryDeleteReturnCode, "Bulk copy error ET", "OrderSummaryDelete");
            }

            //get timestamps for order summarys
            OrderSummarySearchDateET = GetTimeStamps(OrderSummaryStoredProc, "ET");
            OrderSummarySearchDateBT = GetTimeStamps(OrderSummaryStoredProc, "BT");

            //truncate staging table
            ExecuteStoredProcedures("procTruncateOrderSummary", StageConnectionString);

            //bulk copy order summary BT
            BulkCopyToSql(OrderSummaryTable, OrderSummaryStoredProc, "BT", OrderSummarySearchDateBT, out OrderSummaryReturnCode);

            if (OrderSummaryReturnCode != 0)
            {
                ExceptionLogging(OrderSummaryDeleteReturnCode, "Bulk copy error BT", "OrderSummary");
            }

            OrderSummaryReturnCode = 0;

            //bulkt copy order summary ET
            BulkCopyToSql(OrderSummaryTable, OrderSummaryStoredProc, "ET", OrderSummarySearchDateET, out OrderSummaryReturnCode);

            if (OrderSummaryReturnCode != 0)
            {
                ExceptionLogging(OrderSummaryDeleteReturnCode, "Bulk copy error ET", "OrderSummary");
            }

            //Run cleanup, validate, merge
            ExecuteStoredProcedures("procCleanUpOrderSummary", StageConnectionString);
            ExecuteStoredProcedures("procCleanUpOrderSummaryDelete", StageConnectionString);
            ExecuteStoredProcedures("procValidateOrderSummary", StageConnectionString);
            ExecuteStoredProcedures("procMergeOrderSummary", StageConnectionString);

            //update timestamps
            UpdateTimeStamps(OrderSummaryStoredProcDelete, "BT", OrderSummaryTableDelete);
            UpdateTimeStamps(OrderSummaryStoredProcDelete, "ET", OrderSummaryTableDelete);
            UpdateTimeStamps(OrderSummaryStoredProc, "BT", OrderSummaryTable);
            UpdateTimeStamps(OrderSummaryStoredProc, "ET", OrderSummaryTable);

            //process deletes
            ExecuteStoredProcedures("procProcessOrderSummaryDelete", StageConnectionString);
        }


        static string GetTimeStamps (string OCSStoredProcedure, string CompanyCode)
        {
            
            string Timestamp;
            DateTime TimestampOutput;

            using (SqlConnection Orders = new SqlConnection(OrdersConnectionString))
            {

                using (SqlCommand GetOCSExtractTimestamps = new SqlCommand("procGetOCSExtractTimeStamp", Orders))
                {
                    //get ET delete timestamp
                    GetOCSExtractTimestamps.CommandType = CommandType.StoredProcedure;
                    GetOCSExtractTimestamps.Parameters.AddWithValue("@OCSStoredProcedure", OCSStoredProcedure);
                    GetOCSExtractTimestamps.Parameters.AddWithValue("@OCSCompanyCode", CompanyCode);
                    GetOCSExtractTimestamps.Parameters.Add("@OCSTimestamp", SqlDbType.DateTime2).Direction = ParameterDirection.Output;
                    GetOCSExtractTimestamps.CommandTimeout = SQLCommandTimeout;

                    Orders.Open();
                    GetOCSExtractTimestamps.ExecuteNonQuery();
                    TimestampOutput = Convert.ToDateTime(GetOCSExtractTimestamps.Parameters["@OCSTimestamp"].Value);
                    Orders.Close();
                }
            }

            Timestamp = TimestampOutput.ToString("yyyy-MM-dd-HH.mm.ss.0000");
            return Timestamp;
        }

        static void InvoiceSummary()
        {
            int InvoiceSummaryReturnCode;
            string InvoiceSummarySearchDateBT;
            string InvoiceSummarySearchDateET;
            string InvoiceSummaryTable = ConfigurationManager.AppSettings.Get("InvoiceSummaryTable");
            string InvoiceSummaryStoredProc = ConfigurationManager.AppSettings.Get("InvoiceSummaryStoredProc");

            int InvoiceSummaryDeleteReturnCode;
            string InvoiceSummarySearchDateDeleteBT;
            string InvoiceSummarySearchDateDeleteET;
            string InvoiceSummaryTableDelete = ConfigurationManager.AppSettings.Get("InvoiceSummaryTableDelete");
            string InvoiceSummaryStoredProcDelete = ConfigurationManager.AppSettings.Get("InvoiceSummaryStoredProcDelete");

            //Get Delete time stamps
            InvoiceSummarySearchDateDeleteET = GetTimeStamps(InvoiceSummaryStoredProcDelete, "ET");
            InvoiceSummarySearchDateDeleteBT = GetTimeStamps(InvoiceSummaryStoredProcDelete, "BT");

            //truncate the staging table
            ExecuteStoredProcedures("procTruncateInvoiceSummaryDelete", StageConnectionString);

            //bulk copy invoice summary deletes, BT
            BulkCopyToSql(InvoiceSummaryTableDelete, InvoiceSummaryStoredProcDelete, "BT", InvoiceSummarySearchDateDeleteBT, out InvoiceSummaryDeleteReturnCode);

            if (InvoiceSummaryDeleteReturnCode != 0)
            {
                ExceptionLogging(InvoiceSummaryDeleteReturnCode, "Bulk copy error BT", "InvoiceSummaryDelete");
            }

            InvoiceSummaryDeleteReturnCode = 0;

            //bulk copy invoice summary deletes, ET
            BulkCopyToSql(InvoiceSummaryTableDelete, InvoiceSummaryStoredProcDelete, "ET", InvoiceSummarySearchDateDeleteET, out InvoiceSummaryDeleteReturnCode);

            if (InvoiceSummaryDeleteReturnCode != 0)
            {
                ExceptionLogging(InvoiceSummaryDeleteReturnCode, "Bulk copy error ET", "InvoiceSummaryDelete");
            }

            //get timestamps for invoice summarys
            InvoiceSummarySearchDateET = GetTimeStamps(InvoiceSummaryStoredProc, "ET");
            InvoiceSummarySearchDateBT = GetTimeStamps(InvoiceSummaryStoredProc, "BT");

            //truncate staging table
            ExecuteStoredProcedures("procTruncateInvoiceSummary", StageConnectionString);

            //bulk copy invoice summary BT
            BulkCopyToSql(InvoiceSummaryTable, InvoiceSummaryStoredProc, "BT", InvoiceSummarySearchDateBT, out InvoiceSummaryReturnCode);

            if (InvoiceSummaryReturnCode != 0)
            {
                ExceptionLogging(InvoiceSummaryDeleteReturnCode, "Bulk copy error BT", "InvoiceSummary");
            }

            InvoiceSummaryReturnCode = 0;

            //bulkt copy invoice summary ET
            BulkCopyToSql(InvoiceSummaryTable, InvoiceSummaryStoredProc, "ET", InvoiceSummarySearchDateET, out InvoiceSummaryReturnCode);

            if (InvoiceSummaryReturnCode != 0)
            {
                ExceptionLogging(InvoiceSummaryDeleteReturnCode, "Bulk copy error ET", "InvoiceSummary");
            }

            //Run cleanup, validate, merge
            ExecuteStoredProcedures("procCleanUpInvoiceSummary", StageConnectionString);
            ExecuteStoredProcedures("procCleanUpInvoiceSummaryDelete", StageConnectionString);
            ExecuteStoredProcedures("procValidateInvoiceSummary", StageConnectionString);
            ExecuteStoredProcedures("procMergeInvoiceSummary", StageConnectionString);

            //update timestamps
            UpdateTimeStamps(InvoiceSummaryStoredProcDelete, "BT", InvoiceSummaryTableDelete);
            UpdateTimeStamps(InvoiceSummaryStoredProcDelete, "ET", InvoiceSummaryTableDelete);
            UpdateTimeStamps(InvoiceSummaryStoredProc, "BT", InvoiceSummaryTable);
            UpdateTimeStamps(InvoiceSummaryStoredProc, "ET", InvoiceSummaryTable);

            //process deletes
            ExecuteStoredProcedures("procProcessInvoiceSummaryDelete", StageConnectionString);
        }

        static void InvoiceDetail()
        {
            int InvoiceDetailReturnCode;
            string InvoiceDetailSearchDateBT;
            string InvoiceDetailSearchDateET;
            string InvoiceDetailTable = ConfigurationManager.AppSettings.Get("InvoiceDetailTable");
            string InvoiceDetailStoredProc = ConfigurationManager.AppSettings.Get("InvoiceDetailStoredProc");

            int InvoiceDetailDeleteReturnCode;
            string InvoiceDetailSearchDateDeleteBT;
            string InvoiceDetailSearchDateDeleteET;
            string InvoiceDetailTableDelete = ConfigurationManager.AppSettings.Get("InvoiceDetailTableDelete");
            string InvoiceDetailStoredProcDelete = ConfigurationManager.AppSettings.Get("InvoiceDetailStoredProcDelete");

            //Get Delete time stamps
            InvoiceDetailSearchDateDeleteET = GetTimeStamps(InvoiceDetailStoredProcDelete, "ET");
            InvoiceDetailSearchDateDeleteBT = GetTimeStamps(InvoiceDetailStoredProcDelete, "BT");

            //truncate the staging table
            ExecuteStoredProcedures("procTruncateInvoiceDetailDelete", StageConnectionString);

            //bulk copy invoice detail deletes, BT
            BulkCopyToSql(InvoiceDetailTableDelete, InvoiceDetailStoredProcDelete, "BT", InvoiceDetailSearchDateDeleteBT, out InvoiceDetailDeleteReturnCode);

            if (InvoiceDetailDeleteReturnCode != 0)
            {
                ExceptionLogging(InvoiceDetailDeleteReturnCode, "Bulk copy error BT", "InvoiceDetailDelete");
            }

            InvoiceDetailDeleteReturnCode = 0;

            //bulk copy invoice detail deletes, ET
            BulkCopyToSql(InvoiceDetailTableDelete, InvoiceDetailStoredProcDelete, "ET", InvoiceDetailSearchDateDeleteET, out InvoiceDetailDeleteReturnCode);

            if (InvoiceDetailDeleteReturnCode != 0)
            {
                ExceptionLogging(InvoiceDetailDeleteReturnCode, "Bulk copy error ET", "InvoiceDetailDelete");
            }

            //get timestamps for invoice details
            InvoiceDetailSearchDateET = GetTimeStamps(InvoiceDetailStoredProc, "ET");
            InvoiceDetailSearchDateBT = GetTimeStamps(InvoiceDetailStoredProc, "BT");

            //truncate staging table
            ExecuteStoredProcedures("procTruncateInvoiceDetail", StageConnectionString);

            //bulk copy invoice detail BT
            BulkCopyToSql(InvoiceDetailTable, InvoiceDetailStoredProc, "BT", InvoiceDetailSearchDateBT, out InvoiceDetailReturnCode);

            if (InvoiceDetailReturnCode != 0)
            {
                ExceptionLogging(InvoiceDetailDeleteReturnCode, "Bulk copy error BT", "InvoiceDetail");
            }

            InvoiceDetailReturnCode = 0;

            //bulkt copy invoice detail ET
            BulkCopyToSql(InvoiceDetailTable, InvoiceDetailStoredProc, "ET", InvoiceDetailSearchDateET, out InvoiceDetailReturnCode);

            if (InvoiceDetailReturnCode != 0)
            {
                ExceptionLogging(InvoiceDetailDeleteReturnCode, "Bulk copy error ET", "InvoiceDetail");
            }

            //Run cleanup, validate, merge
            ExecuteStoredProcedures("procCleanUpInvoiceDetail", StageConnectionString);
            ExecuteStoredProcedures("procCleanUpInvoiceDetailDelete", StageConnectionString);
            ExecuteStoredProcedures("procValidateInvoiceDetail", StageConnectionString);
            ExecuteStoredProcedures("procMergeInvoiceDetail", StageConnectionString);

            //update timestamps
            UpdateTimeStamps(InvoiceDetailStoredProcDelete, "BT", InvoiceDetailTableDelete);
            UpdateTimeStamps(InvoiceDetailStoredProcDelete, "ET", InvoiceDetailTableDelete);
            UpdateTimeStamps(InvoiceDetailStoredProc, "BT", InvoiceDetailTable);
            UpdateTimeStamps(InvoiceDetailStoredProc, "ET", InvoiceDetailTable);

            //process deletes
            ExecuteStoredProcedures("procProcessInvoiceDetailDelete", StageConnectionString);
        }

        static void Package()
        {
            int PackageReturnCode;
            string PackageSearchDateBT;
            string PackageSearchDateET;
            string PackageTable = ConfigurationManager.AppSettings.Get("PackageTable");
            string PackageStoredProc = ConfigurationManager.AppSettings.Get("PackageStoredProc");

            int PackageDeleteReturnCode;
            string PackageSearchDateDeleteBT;
            string PackageSearchDateDeleteET;
            string PackageTableDelete = ConfigurationManager.AppSettings.Get("PackageTableDelete");
            string PackageStoredProcDelete = ConfigurationManager.AppSettings.Get("PackageStoredProcDelete");

            //Get Delete time stamps
            PackageSearchDateDeleteET = GetTimeStamps(PackageStoredProcDelete, "ET");
            PackageSearchDateDeleteBT = GetTimeStamps(PackageStoredProcDelete, "BT");

            //truncate the staging table
            ExecuteStoredProcedures("procTruncatePackageDelete", StageConnectionString);

            //bulk copy package deletes, BT
            BulkCopyToSql(PackageTableDelete, PackageStoredProcDelete, "BT", PackageSearchDateDeleteBT, out PackageDeleteReturnCode);

            if (PackageDeleteReturnCode != 0)
            {
                ExceptionLogging(PackageDeleteReturnCode, "Bulk copy error BT", "PackageDelete");
            }

            PackageDeleteReturnCode = 0;

            //bulk copy package deletes, ET
            BulkCopyToSql(PackageTableDelete, PackageStoredProcDelete, "ET", PackageSearchDateDeleteET, out PackageDeleteReturnCode);

            if (PackageDeleteReturnCode != 0)
            {
                ExceptionLogging(PackageDeleteReturnCode, "Bulk copy error ET", "PackageDelete");
            }

            //get timestamps for packages
            PackageSearchDateET = GetTimeStamps(PackageStoredProc, "ET");
            PackageSearchDateBT = GetTimeStamps(PackageStoredProc, "BT");

            //truncate staging table
            ExecuteStoredProcedures("procTruncatePackage", StageConnectionString);

            //bulk copy package BT
            BulkCopyToSql(PackageTable, PackageStoredProc, "BT", PackageSearchDateBT, out PackageReturnCode);

            if (PackageReturnCode != 0)
            {
                ExceptionLogging(PackageDeleteReturnCode, "Bulk copy error BT", "Package");
            }

            PackageReturnCode = 0;

            //bulkt copy package ET
            BulkCopyToSql(PackageTable, PackageStoredProc, "ET", PackageSearchDateET, out PackageReturnCode);

            if (PackageReturnCode != 0)
            {
                ExceptionLogging(PackageDeleteReturnCode, "Bulk copy error ET", "Package");
            }

            //Run cleanup, validate, merge
            ExecuteStoredProcedures("procCleanUpPackage", StageConnectionString);
            ExecuteStoredProcedures("procCleanUpPackageDelete", StageConnectionString);
            ExecuteStoredProcedures("procValidatePackage", StageConnectionString);
            ExecuteStoredProcedures("procMergePackage", StageConnectionString);

            //update timestamps
            UpdateTimeStamps(PackageStoredProcDelete, "BT", PackageTableDelete);
            UpdateTimeStamps(PackageStoredProcDelete, "ET", PackageTableDelete);
            UpdateTimeStamps(PackageStoredProc, "BT", PackageTable);
            UpdateTimeStamps(PackageStoredProc, "ET", PackageTable);

            //process deletes
            ExecuteStoredProcedures("procProcessPackageDelete", StageConnectionString);
        }

        static void VASSundry()
        {
            int VASSundryReturnCode;
            string VASSundrySearchDateBT;
            string VASSundryTable = ConfigurationManager.AppSettings.Get("VASSundryTable");
            string VASSundryStoredProc = ConfigurationManager.AppSettings.Get("VASSundryStoredProc");

            int VASSundryDeleteReturnCode;
            string VASSundrySearchDateDeleteBT;
            string VASSundryTableDelete = ConfigurationManager.AppSettings.Get("VASSundryTableDelete");
            string VASSundryStoredProcDelete = ConfigurationManager.AppSettings.Get("VASSundryStoredProcDelete");

            //Get Delete time stamps
            VASSundrySearchDateDeleteBT = GetTimeStamps(VASSundryStoredProcDelete, "BT");

            //truncate the staging table
            ExecuteStoredProcedures("procTruncateVASSundryDelete", StageConnectionString);

            //bulk copy vassundry deletes, BT
            BulkCopyToSql(VASSundryTableDelete, VASSundryStoredProcDelete, "BT", VASSundrySearchDateDeleteBT, out VASSundryDeleteReturnCode);

            if (VASSundryDeleteReturnCode != 0)
            {
                ExceptionLogging(VASSundryDeleteReturnCode, "Bulk copy BT", "VasSundryDelete");
            }

            VASSundryDeleteReturnCode = 0;

            //get timestamps for vassundrys
            VASSundrySearchDateBT = GetTimeStamps(VASSundryStoredProc, "BT");

            //truncate staging table
            ExecuteStoredProcedures("procTruncateVASSundry", StageConnectionString);

            //bulk copy vassundry BT
            BulkCopyToSql(VASSundryTable, VASSundryStoredProc, "BT", VASSundrySearchDateBT, out VASSundryReturnCode);

            if (VASSundryReturnCode != 0)
            {
                ExceptionLogging(VASSundryReturnCode, "Bulk copy BT", "VasSundry");
            }

            VASSundryReturnCode = 0;

            //Run cleanup, validate, merge
            ExecuteStoredProcedures("procCleanUpVASSundry", StageConnectionString);
            ExecuteStoredProcedures("procCleanUpVASSundryDelete", StageConnectionString);
            ExecuteStoredProcedures("procValidateVASSundry", StageConnectionString);
            ExecuteStoredProcedures("procMergeVASSundry", StageConnectionString);

            //update timestamps
            UpdateTimeStamps(VASSundryStoredProcDelete, "BT", VASSundryTableDelete);
            UpdateTimeStamps(VASSundryStoredProc, "BT", VASSundryTable);

            //process deletes
            ExecuteStoredProcedures("procProcessVASSundryDelete", StageConnectionString);
        }

        static void UpdateTimeStamps (string OCSStoredProcedure, string CompanyCode, string Table)
        {
            using (SqlConnection Orders = new SqlConnection(OrdersConnectionString))
            {
                using (SqlCommand UpdateOCSTimestamps = new SqlCommand("procUpdateOCSExtractTimeStamp", Orders))
                {
                    UpdateOCSTimestamps.CommandType = CommandType.StoredProcedure;
                    UpdateOCSTimestamps.Parameters.AddWithValue("@OCSStoredProcedure", OCSStoredProcedure);
                    UpdateOCSTimestamps.Parameters.AddWithValue("@OCSCompanyCode", CompanyCode);
                    UpdateOCSTimestamps.Parameters.AddWithValue("@OrderInvoiceTable", Table);
                    UpdateOCSTimestamps.CommandTimeout = SQLCommandTimeout;

                    Orders.Open();
                    UpdateOCSTimestamps.ExecuteNonQuery();
                    Orders.Close();
                }
            }
        }

        static void ExecuteStoredProcedures (string StoredProc, string ConnectionString)
        {
            using (SqlConnection DBConn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand Cmd = new SqlCommand(StoredProc, DBConn))
                {
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.CommandTimeout = SQLCommandTimeout;
                    DBConn.Open();
                    Cmd.ExecuteNonQuery();
                    DBConn.Close();
                }
            }
        }

        static void BulkCopyToSql(string NGTableName, string DB2StoredProcedureName, string CompanyCode, string SearchDate, out int ReturnCode)
        {
            using (SqlConnection NextGenStageConnection = new SqlConnection(StageConnectionString))
            {
                NextGenStageConnection.Open();
                DataTable NextGenDataTable = new DataTable();

                NextGenDataTable = GetDB2Data(DB2StoredProcedureName, CompanyCode, SearchDate);

                using (SqlBulkCopy NextGenBulkCopy = new SqlBulkCopy(NextGenStageConnection))
                {
                    NextGenBulkCopy.BulkCopyTimeout = 0;
                    NextGenBulkCopy.DestinationTableName = NGTableName;
                    NextGenBulkCopy.WriteToServer(NextGenDataTable);
                }

                NextGenStageConnection.Close();
            }

            ReturnCode = m_ReturnCode;
        }

        static DataTable GetDB2Data(string DB2StoredProcedureName, string CompanyCode, string SearchDate)
        {
            OleDbConnection DB2Connection = new OleDbConnection(DB2ConnectionString);
            OleDbCommand DB2Command = new OleDbCommand();
            OleDbParameter ReturnCodeParam = new OleDbParameter();
            OleDbDataReader DB2DataReader;
            DataTable DB2DataTable = new DataTable();

            DB2Command.CommandText = DB2StoredProcedureName;
            DB2Command.CommandTimeout = 0;
            DB2Command.Parameters.Add("CD_COMPANY_CD", OleDbType.Char, 2).Value = CompanyCode;
            DB2Command.Parameters.Add("CD_CODE_NAME", OleDbType.Char, 26).Value = SearchDate;


            ReturnCodeParam.ParameterName = "ORETCODE";
            ReturnCodeParam.Direction = ParameterDirection.Output;
            ReturnCodeParam.OleDbType = OleDbType.Integer;
            ReturnCodeParam.Value = m_ReturnCode;
            DB2Command.Parameters.Add(ReturnCodeParam);

            DB2Command.CommandType = CommandType.StoredProcedure;
            DB2Command.Connection = DB2Connection;

            DB2Connection.Open();
            DB2DataReader = DB2Command.ExecuteReader();
            DB2DataTable.Load(DB2DataReader);
            DB2Connection.Close();
            m_ReturnCode = Convert.ToInt16(ReturnCodeParam.Value);

            return DB2DataTable;

        }
    }
}
